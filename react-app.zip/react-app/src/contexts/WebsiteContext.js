import { createContext } from 'react';
import _ from 'lodash';

export default createContext(_.get(window, 'vffCoreWebsite.spaContainer', {
  pageUrl: '/',
}));
