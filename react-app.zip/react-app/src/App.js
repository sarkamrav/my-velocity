import React, { useState, useEffect } from 'react';
import { BrowserRouter, Switch, Route } from 'react-router-dom';
import _ from 'lodash';

import Dashboard from './pages/Dashboard/Dashboard';
import UserContext from './contexts/UserContext';
import Loading from './components/Loading/Loading';
import CacheContext from './contexts/CacheContext';
import InformationAlert, { informationAlertTheme } from './components/InformationAlert/InformationAlert';
import A from './components/Button/A';
import ErrorBoundary from './components/ErrorBoundary/ErrorBoundary';
import { newRelicSection } from './utils/newRelic';
import PointsProDashboard from './pages/PointsPro/PointsProDashboard';

import styles from './App.css';

export default function App() {
  const [cache, setCache] = useState({});
  const [user, setUser] = useState(_.get(window, 'vffCoreWebsite.user', {}));

  function updateUser(e) {
    const { authenticated, ...rest } = e.data;

    if (authenticated) {
      setUser({
        loaded: true,
        authenticated,
        ...rest,
      });
    } else {
      setUser({
        loaded: true,
        authenticated,
        ...rest,
      });
    }
  }

  useEffect(() => {
    if (window.vffCoreWebsite.user) {
      updateUser({ data: window.vffCoreWebsite.user });
    } else {
      document.addEventListener('myProfile', updateUser);
    }

    return () => {
      document.removeEventListener('myProfile', updateUser);
    };
  }, []);

  function renderApp() {
    if (!user.loaded) {
      return <Loading containerClassName={styles.loadingContainer} />;
    }

    if (!user.authenticated && !user.memberDataLoadError) {
      return null;
    }

    if (!user.authenticated && user.memberDataLoadError) {
      return (
        <div className={styles.container}>
          <InformationAlert
            status={informationAlertTheme.danger}
            icon="exclamationCircleSolid"
            description="Sorry we're having issues with our system. Please refresh the page or try again later."
            cta={<A buttonType="secondary" onClick={() => window.location.reload()}>Refresh page</A>}
          />
        </div>
      );
    }

    return (
      <Switch>
        <Route path="/points-pro" component={PointsProDashboard} />
        <Route path="/" component={Dashboard} />
      </Switch>
    );
  }

  return (
    <ErrorBoundary section={newRelicSection.myVelocity}>
      <BrowserRouter>
        <CacheContext.Provider
          value={{ cache, setCache }}
        >
          <UserContext.Provider
            value={{ user }}
          >
            {renderApp()}
          </UserContext.Provider>
        </CacheContext.Provider>
      </BrowserRouter>
    </ErrorBoundary>
  );
}
