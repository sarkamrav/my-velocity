import each from 'lodash/each';
import get from 'lodash/get';
import startsWith from 'lodash/startsWith';
import qs from 'qs';

export function isCtaAvailable(ctaContainer) {
  return ctaContainer && ctaContainer.ctaLabel;
}

export function formatMembershipNumber(value) {
  if (!value) {
    return '';
  }
  return value.toString().replace(/(\d+)(\d{3})(\d{3})/g, '$1 $2 $3');
}

export function formatPoints(number) {
  return number.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
}

export function formatAdditionSubtraction(number) {
  if (number === 0) return number;

  const points = formatPoints(number);
  return number > 0 ? `+${points}` : points;
}

export function getNavigationHeight() {
  const headerMirror = document.getElementById('vff-header-mirror');
  return headerMirror ? headerMirror.offsetHeight : 0;
}

export function scrollToRef(ref, offset = 0) {
  if (ref.current) {
    window.scroll({
      top: ref.current.getBoundingClientRect().top + window.scrollY - getNavigationHeight() - offset,
      behavior: 'smooth',
    });
    setTimeout(() => ref.current.focus(), 500);
  }
}

export function getQueryParameter(parameterName, search) {
  const querystring = qs.parse(search, { ignoreQueryPrefix: true });
  return querystring[parameterName];
}

export default function syncText(input = '', tags = {}, openTag = '{{', closeTag = '}}') {
  let response = input;

  each(input.match(new RegExp(`${openTag}(.*?)${closeTag}`, 'g')), (value) => {
    const key = value.replace(openTag, '').replace(closeTag, '');
    const newValue = tags[key] || '';

    response = response.replace(new RegExp(`${openTag}${key}${closeTag}`, 'g'), newValue);
  });

  return response;
}

export function isEnableVipTier() {
  return get(window, 'vffCoreWebsite.websiteData.enableVipTierDesign', false);
}

export const CORE_COMPONENT_NAME = {
  accordionComparison: 'aem-accordion_comparison',
  imageTiles: 'aem-image-tiles',
  richTextContent: 'aem-rich-text',
  singleFeaturedContent: 'aem-single-featured-content',
  stripBanner: 'aem-strip-banner',
};

export const isProd = () => startsWith(window.location.host, 'experience.');

export const analyticsEventAction = {
  click: 'click',
  impression: 'impression',
};

export const analyticsEventName = {
  clickCta: 'click-cta',
  modalsImpression: 'modals-impression',
  trackerImpression: 'tracker-impression',
};

export const analyticsEventCategory = {
  tracker: 'tracker',
};

export const focusableCssSelector = 'a[href]:not([disabled]), button:not([disabled]), textarea:not([disabled]), input[type="text"]:not([disabled]), input[type="radio"]:not([disabled]), input[type="checkbox"]:not([disabled]), select:not([disabled])';

export const serverTimeZone = { zone: 'Australia/Brisbane' };

export const cardStatusInfo = {
  inactive: 'inactive', // pre-challenge
  completed: 'completed',
  pending: 'pending',
  active: 'active',
  missed: 'missed',
};

// Points Pro challenge status card status
export const CHALLENGE_STATUSES = {
  NOT_ACCEPTED: 'challengeNotAccepted', // Challenge not accepted and campaign not started
  ACCEPTED: 'challengeAccepted', // Challenge accepted and campaign not started
  ACTIVITY_STARTED: 'challengePreviouslyAccepted', // Challenge accepted and campaign started
  REGISTRATION_ENDED: 'challengeNotAcceptedBeforeTime', // Challenge not accepted and campaign started
  ACTIVITY_ENDED: 'challengeEnded', // Challenge accepted and Campaign ended
  INELIGIBLE: 'ineligibleMember', // member is not eligible
};

export const ACTIVATION_STATUSES = {
  REGISTERED: 'REGISTERED',
  ACTIVE: 'REGISTRABLE',
  INACTIVE: 'NON_REGISTRABLE',
};

export const dateDifference = (startDate, endDate) => endDate.diff(startDate).milliseconds;
