import tierRed from '../images/tier-red.png';
import tierSilver from '../images/tier-silver.png';
import tierGold from '../images/tier-gold.png';
import tierPlatinum from '../images/tier-platinum.png';
import tierVip from '../images/tier-vip.png';
import planeRed from '../images/plane-red.png';
import planeSilver from '../images/plane-silver.png';
import planeGold from '../images/plane-gold.png';
import planePlatinum from '../images/plane-platinum.png';
import planeVip from '../images/plane-vip.png';
import giftGold from '../images/gift-gold.png';
import giftPlatinum from '../images/gift-platinum.png';
import digitalCardTierRed from '../images/digital-card--tier-red.png';
import digitalCardTierSilver from '../images/digital-card--tier-silver.png';
import digitalCardTierGold from '../images/digital-card--tier-gold.png';
import digitalCardTierPlatinum from '../images/digital-card--tier-platinum.png';
import digitalCardTierBeyond from '../images/digital-card--tier-beyond.png';
import digitalCardTierVip from '../images/digital-card--tier-vip.png';

export const TIER = {
  R: 'Red',
  S: 'Silver',
  G: 'Gold',
  P: 'Platinum',
  V: 'VIP',
};

export const DIGITAL_CARD = {
  R: digitalCardTierRed,
  S: digitalCardTierSilver,
  G: digitalCardTierGold,
  P: digitalCardTierPlatinum,
  V: digitalCardTierVip,
  BEYOND: digitalCardTierBeyond, // new VIP card icon
};

export function getTier(tierInfo = {}) {
  switch (tierInfo.tierLevel) {
    case 'S': return 'Silver';
    case 'G': {
      switch (tierInfo.tierType) {
        case 'O': return 'Explore Gold';
        case 'A': return 'Trial Gold';
        case 'Q': return 'Pilot Gold';
        case 'D': return 'Discover Gold';
        default: return 'Gold'; // other gold sub tiers have same benefits as Gold Tier
                                // sub tiers are "SG", "FG", "CG", "PG", "TG", "ZG", "OG", "QG", "BG", "EG", "GG", "DG"
      }
    }
    case 'P': return 'Platinum';
    case 'V': return 'VIP';
    case 'R':
    default:
      return 'Red';
  }
}

export const TIER_CARD = {
  R: tierRed,
  S: tierSilver,
  G: tierGold,
  P: tierPlatinum,
  V: tierVip,
};

export const TIER_PLANE = {
  R: planeRed,
  S: planeSilver,
  G: planeGold,
  P: planePlatinum,
  V: planeVip,
};

export const SUB_TIER = {
  S: 'Standard',
  B: 'Board Member',
  E: 'Executive',
  X: 'Tier Pause',
  T: 'Tier Match',
  Z: 'Companion',
  O: 'Explore',
  Q: 'Pilot',
  P: 'Purchased',
  G: 'MOP',
  C: 'Corporate',
  F: 'Free of Charge',
  L: 'Lifetime VIP',
  N: 'Non-Fulfillment',
};

export function getNextGift(statusCredits = 0) {
  const giftGoldCreditsRequired = 1300;
  const giftPlatinumCreditsRequired = 1800;

  const goldGift = {
    tier: 'Gold',
    image: giftGold,
    requiredStatusCredits: giftGoldCreditsRequired,
  };

  if (statusCredits >= giftGoldCreditsRequired) {
    return {
      tier: 'Platinum',
      image: giftPlatinum,
      requiredStatusCredits: giftPlatinumCreditsRequired,
      achieved: statusCredits >= giftPlatinumCreditsRequired,
      priorGift: goldGift,
    };
  }

  return goldGift;
}
