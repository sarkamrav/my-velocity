import moment from 'moment';

import dashboard from './dashboard.mock.json';
import tierUpgrade from './tier-upgrade.mock.json';
import activityHistoryMock from './activity-history.mock.json';
import benefitsMock from './benefits.mock.json';
import promotions from './promotions.mock.json';
import carHirePostMock from './car-hire-post-success-response.mock.json';
import redeemedAwardCredits from './redeemed-award-credits.mock.json';
import redeemedAwardCreditsBusinessFlyer from './redeemed-award-credits--business-flyer.mock.json';
import mgmToken from './mgm-token.mock.json';

const startDate = moment().subtract(3, 'year').format('YYYY-MM-DD');
const redeemedAwardCreditsStartDate = moment().subtract(1, 'year').format('YYYY-MM-DD');
const endDate = moment().format('YYYY-MM-DD');
const summaryStartDate = moment().startOf('month').format('YYYY-MM-DD');
const summaryEndDate = moment().endOf('month').format('YYYY-MM-DD');
const activityHistoryAPI = `/loyalty/v2/experience/activities/me?startDate=${startDate}&endDate=${endDate}&pageOffset=0&pageLimit=10&include=summary&summaryStartDate=${summaryStartDate}&summaryEndDate=${summaryEndDate}`;
const redeemedAwardCreditsUri = `/loyalty/v2/experience/benefits/me/redeemedAwardCredits?startDate=${redeemedAwardCreditsStartDate}&endDate=${endDate}&benefitCode=BCUV&benefitCode=BCPU`;
const redeemedAwardCreditsForBusinessFlyerUri = `/loyalty/v2/experience/benefits/me/redeemedAwardCredits?startDate=${redeemedAwardCreditsStartDate}&endDate=${endDate}&benefitCode=BBFBCU`;

export default {
  vffApi: {
    get: {},
    post: {
      '/v1/dashboard': dashboard,
    },
  },
  vffV2Api: {
    get: {
      [activityHistoryAPI]: activityHistoryMock,
      [redeemedAwardCreditsUri]: redeemedAwardCredits,
      [redeemedAwardCreditsForBusinessFlyerUri]: redeemedAwardCreditsBusinessFlyer,
      '/loyalty/v2/promotions/registrations?excludeBAUoffers=true': promotions,
      '/loyalty/v2/experience/benefits/me': benefitsMock,
      '/loyalty/v2/activities/tier-upgrade': tierUpgrade,
      '/loyalty/v2/members/referrals': mgmToken,
    },
    post: {
      '/loyalty/v2/benefits/comp-partner-memberships': carHirePostMock,
    },
  },
};
