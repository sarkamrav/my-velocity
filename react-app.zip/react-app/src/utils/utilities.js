// Member data info can be defined here which can be utilized at required places like getEmailAddress(user)

import get from 'lodash/get';

export const getHasLoggedIn = user => get(user, 'authenticated', false);
export const getDashboardData = user => get(user, 'dashboard', []);
export const getLoyaltyMembershipID = user => get(user, 'member.loyaltyMembershipID', '');
export const getFirstName = user => get(user, 'member.firstName', '');
export const getLastName = user => get(user, 'member.lastName', '');
export const getCurrentPointsBalance = user => get(user, 'account.currentPointsBalance', 0);
export const getStatusCreditsBalance = user => get(user, 'account.statusCreditsBalance', 0);
export const getEligibleSectorsBalance = user => get(user, 'account.eligibleSectorsBalance', 0);
export const getJoinDate = user => get(user, 'account.joinDate', '');
export const getCurrentPointsBalanceExpiryDate = user => get(user, 'account.currentPointsBalanceExpiryDate', '');
export const getNearingExpiryDate = user => get(user, 'account.nearingExpiryDate', '');
export const getMainTierInfo = user => get(user, 'tiers.mainTierInfo', '');
export const getTierLevel = user => get(user, 'tiers.mainTierInfo.tierLevel', '');
export const getSubTierLevel = user => get(user, 'tiers.mainTierInfo.tierType', '');
export const getPeriodicTierInfo = user => get(user, 'tiers.periodicTierInfo', '');
export const getPeriodicTierLevel = user => get(user, 'tiers.periodicTierInfo.tierLevel', '');
export const getQualificationPeriodEndDate = user => get(user, 'tiers.periodicTierInfo.qualificationPeriodEndDate', '');
export const getQualificationPeriodStartDate = user => get(user, 'tiers.periodicTierInfo.qualificationPeriodStartDate', '');
export const getQualificationPeriodStatusCreditsBalance = user => get(user, 'tiers.periodicTierInfo.qualificationPeriodStatusCreditsBalance', 0);
export const getQualificationPeriodEligibleSectorsBalance = user => get(user, 'tiers.periodicTierInfo.qualificationPeriodEligibleSectorsBalance', '');
export const getUpgradeTierInfo = user => get(user, 'tiers.periodicTierInfo.upgradeTierInfo', '');
export const getUpgradeTierInfoLevel = user => get(user, 'tiers.periodicTierInfo.upgradeTierInfo.tierLevel', '');
export const getUpgradeTierCreditsRequired = user => get(user, 'tiers.periodicTierInfo.upgradeTierInfo.creditsRequired', 0);
export const getUpgradeTierSectorsRequired = user => get(user, 'tiers.periodicTierInfo.upgradeTierInfo.sectorsRequired', 0);
export const getDowngradeTierInfo = user => get(user, 'tiers.periodicTierInfo.downgradeTierInfo', '');
export const getDowngradeTierInfoLevel = user => get(user, 'tiers.periodicTierInfo.downgradeTierInfo.tierLevel', '');
export const getDowngradeTierCreditsRequired = user => get(user, 'tiers.periodicTierInfo.downgradeTierInfo.creditsRequired', 0);
export const getDowngradeTierSectorsRequired = user => get(user, 'tiers.periodicTierInfo.downgradeTierInfo.sectorsRequired', 0);

