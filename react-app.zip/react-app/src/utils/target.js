import axios from 'axios';
import cookie from 'cookie';
import _ from 'lodash';
import { setCookie } from './cookies';

const domain = 'https://virginaustralia.tt.omtrdc.net';
const client = 'virginaustralia';
const vffEdgeHostCookie = 'mboxEdgeClusterForVff';

function getmBoxIdFromCookie(cookieValue, name) {
  return _(_(cookieValue).split('|').filter(item => _.startsWith(item, name)).get('0'))
    .split('#')
    .get('1');
}

export async function getTarget(mbox) {
  const parsedCookies = cookie.parse(document.cookie);
  const mboxCookie = parsedCookies.mbox ? parsedCookies.mbox.toLowerCase() : '';

  const matched = _.keys(parsedCookies).filter(k => k.match(/AMCV_(.+?)AdobeOrg/));
  const tokenString = parsedCookies[matched];
  const tokenItems = _.split(tokenString, '|');

  const tntId = getmBoxIdFromCookie(mboxCookie, 'pc#');
  const sessionId = getmBoxIdFromCookie(mboxCookie, 'session#');
  const vffEdgeHostCookieValue = parsedCookies[vffEdgeHostCookie];

  try {
    const response = await axios.post(`${vffEdgeHostCookieValue ? `https://${vffEdgeHostCookieValue}` : domain}/rest/v1/delivery/?client=${client}&sessionId=${sessionId}`, {
      id: {
        tntId,
        marketingCloudVisitorId: _.get(tokenItems, '4', null),
      },
      experienceCloud: {
        audienceManager: {
          blob: _.get(tokenItems, '8', null),
          locationHint: _.get(tokenItems, '6', null),
        },
        analytics: {
          logging: 'client_side',
        },
      },
      context: {
        channel: 'web',
        address: {
          url: window.location.href,
        },
      },
      execute: {
        mboxes: [
          {
            name: mbox,
            index: 1,
          },
        ],
      },
    });

    const mboxEdgeCluster = _.get(response, 'data.edgeHost', null);
    const responseContent = _.get(response, 'data.execute.mboxes.0.options.0.content', null);

    if (!vffEdgeHostCookieValue && mboxEdgeCluster) {
      setCookie(vffEdgeHostCookie, mboxEdgeCluster, 30);
    }

    try {
      return JSON.parse(responseContent);
    } catch (e) {
      return responseContent;
    }
  } catch (err) {
    // Error parsing JSON from target
    return null;
  }
}

export function applyOffers() {
  /* eslint-disable */
  if (window?.adobe?.target?.getOffer) {
    adobe.target.getOffer({
      mbox: 'target-global-mbox',
      success(offer) {
        adobe.target.applyOffer({
          mbox: 'target-global-mbox',
          offer,
        });
      },
      error(status, error) {
        console.log('Error', status, error);
      },
    });
  }
  /* eslint-enable */
}
