import { useContext, useState, useEffect } from 'react';
import _ from 'lodash';
import qs from 'qs';

import { getApiActionName, getApiError, newRelicSection, sendToNewRelic } from './newRelic';
import mocks from './mocks/_index';
import CacheContext from '../contexts/CacheContext';

export function useApi(url, parameters = {}, callback = null) {
  const {
    endpoint = 'vffApi',
    method = 'get',
    options = null,
  } = parameters;
  const { cache = {}, setCache } = useContext(CacheContext);
  const cacheKey = `${url}${JSON.stringify(options)}`;
  const [loading, setLoading] = useState(!cache[cacheKey]);
  const [data, setData] = useState(cache[cacheKey]);
  const [error, setError] = useState(null);

  async function makeApiCall(newOptions) {
    try {
      const newCacheKey = `${url}${JSON.stringify(options)}`;

      if (!cache[newCacheKey] || newOptions.bypassCache) {
        setLoading(true);

        // Check to see if we need to load mocks
        const mock = _.get(
          mocks,
          `[${endpoint}][${method}][${url}${options && options.params
            ? qs.stringify(options.params, { addQueryPrefix: true })
            : ''}]`,
        );

        if (window.vffCoreWebsite.websiteData.useMocks && mock) {
          setData(mock);
        } else {
          const response = await window.vffCoreWebsite.coreApi[endpoint][method](url, newOptions);
          setCache(prev => ({
            ...prev,
            [cacheKey]: response.data,
          }));
          setData(response.data);

          if (callback) {
            callback(response.data);
          }
        }
      } else {
        setData(cache[cacheKey]);
      }
      setLoading(false);
    } catch (err) {
      setError(err);
      setLoading(false);

      sendToNewRelic(
        getApiActionName(window.vffCoreWebsite.coreApi[endpoint]?.defaults.baseURL, url),
        getApiError(newRelicSection.myVelocity, err),
      );
    }
  }

  function refetch(newOptions) {
    makeApiCall(newOptions || options);
  }

  useEffect(() => {
    makeApiCall(options);
  }, []);

  return { data, error, loading, refetch };
}
