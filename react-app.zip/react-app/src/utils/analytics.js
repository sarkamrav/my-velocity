export default {
  send: analytics => {
    window.vffCoreWebsite.coreAnalytics.send(analytics);
  },
};
