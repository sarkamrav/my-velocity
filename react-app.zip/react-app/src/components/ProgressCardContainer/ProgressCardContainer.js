import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import { cardStatusInfo } from '../../utils/common';

import styles from './ProgressCardContainer.css';

const ProgressCardContainer = ({ children, className, cardStatus }) => (
  <div className={cx(className, styles[cardStatus])}>
    {children}
  </div>
);

export default ProgressCardContainer;

ProgressCardContainer.propTypes = {
  children: PropTypes.node.isRequired,
  cardStatus: PropTypes.oneOf([cardStatusInfo.inactive, cardStatusInfo.completed, cardStatusInfo.pending, cardStatusInfo.active, cardStatusInfo.missed]).isRequired,
  className: PropTypes.string,
};

ProgressCardContainer.defaultProps = {
  className: '',
};
