import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import { cardStatusInfo } from '../../utils/common';

import styles from './ProgressBar.css';

export const heightTheme = {
  narrow: 'narrow',
  default: 'default',
};

function ProgressBar({ done, color, theme, className, cardStatus }) {
  const [style, setStyle] = useState(null);

  useEffect(() => {
    const newStyle = {
      opacity: 1,
      position: 'absolute',
      zIndex: 1,
      width: `${done}%`,
      height: 'inherit',
    };

    setStyle(newStyle);
  }, [done]);

  return (
    <div className={cx(styles.progress, className, styles[theme])}>
      <div className={cx(styles[cardStatus], styles[color])} style={style} />
    </div>
  );
}

export default ProgressBar;

ProgressBar.propTypes = {
  done: PropTypes.number,
  cardStatus: PropTypes.oneOf([cardStatusInfo.inactive, cardStatusInfo.completed, cardStatusInfo.pending, cardStatusInfo.active, cardStatusInfo.missed]).isRequired,
  theme: PropTypes.oneOf([heightTheme.default, heightTheme.narrow]),
  className: PropTypes.string,
  color: PropTypes.string,
};

ProgressBar.defaultProps = {
  done: 0,
  theme: heightTheme.default,
  className: '',
  color: '',
};
