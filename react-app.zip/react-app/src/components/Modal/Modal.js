import PropTypes from 'prop-types';
import React, { useEffect, useState, useRef } from 'react';
import ReactDOM from 'react-dom';
import cx from 'classnames';
import useTrapFocus from './useTrapFocus';
import ModalCloseButton, { modalButtonTheme } from './components/ModalCloseButton/ModalCloseButton';

import styles from './Modal.css';

export const modalTheme = {
  v2: 'v2',
  default: 'default',
  fullPageView: 'fullPageView',
};

function Modal({ children, withCloseButton, theme, onDismiss, 'aria-label': ariaLabel }) {
  const modalRef = useRef();
  const [isVisible, setIsVisible] = useState(false);

  // Handle keyboard shortcuts
  function handleKeyDown(event) {
    if (event.key === 'Escape') {
      onDismiss();
    }
  }

  useTrapFocus(modalRef);

  // Handle adding/removing global class
  useEffect(() => {
    const scrollBarWidth = window.innerWidth - document.body.clientWidth;
    const header = document.querySelector('header.src-features-Navigation-Navigation_header');
    const stickyFooter = document.querySelector('.src-features-Navigation-Navigation_stickyFooterContainer');

    function setPaddingRight(element, paddingWidth) {
      // eslint-disable-next-line no-param-reassign
      if (element) { element.style.paddingRight = `${paddingWidth}px`; }
    }

    document.body.classList.add('modal-open');
    if (scrollBarWidth) {
      setPaddingRight(document.body, scrollBarWidth);
      setPaddingRight(header, scrollBarWidth);
      setPaddingRight(stickyFooter, scrollBarWidth);
    }
    setIsVisible(true);

    return () => {
      document.body.classList.remove('modal-open');
      if (scrollBarWidth) {
        setPaddingRight(document.body, 0);
        setPaddingRight(header, 0);
        setPaddingRight(stickyFooter, 0);
      }
    };
  }, []);

  // Handle click outside
  useEffect(() => {
    function handleClickOutside(e) {
      if (modalRef.current && !modalRef.current.contains(e.target)) {
        onDismiss();
      }
    }

    document.body.addEventListener('click', handleClickOutside);

    return () => {
      document.body.removeEventListener('click', handleClickOutside);
    };
  }, []);

  // Handle focus when showing/hiding modal
  useEffect(() => {
    const initiallyFocusedElement = document.activeElement;

    modalRef.current.focus();

    return () => {
      if (initiallyFocusedElement) {
        initiallyFocusedElement.focus();
      }
    };
  }, []);

  const isVersionTwo = theme === modalTheme.v2;
  const isFullPageModal = theme === modalTheme.fullPageView;

  return ReactDOM.createPortal(
    <div
      className={cx(styles.overlay, { [styles.fullPageOverlay]: isFullPageModal }, {
        [styles.versionTwo]: isVersionTwo,
        [styles.visible]: isVisible,
      })}
    >
      {/* eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex,jsx-a11y/no-noninteractive-element-interactions */}
      <div
        ref={modalRef}
        className={cx(styles.modal, { [styles.fullPageViewModal]: isFullPageModal })}
        onKeyDown={handleKeyDown}
        tabIndex={-1}
        role="dialog"
        aria-modal="true"
        aria-label={ariaLabel}
      >
        {
          withCloseButton && (
            <ModalCloseButton
              className={cx(styles.closeButton, { [styles.fullPageCloseButton]: isFullPageModal })}
              onClick={onDismiss}
              theme={modalButtonTheme[theme]}
            />
          )
        }

        {children}
      </div>
    </div>,
    document.body,
  );
}

Modal.propTypes = {
  children: PropTypes.node.isRequired,
  onDismiss: PropTypes.func.isRequired,
  withCloseButton: PropTypes.bool,
  theme: PropTypes.string,
  'aria-label': PropTypes.string.isRequired,
};

Modal.defaultProps = {
  withCloseButton: true,
  theme: modalTheme.default,
};

export default Modal;
