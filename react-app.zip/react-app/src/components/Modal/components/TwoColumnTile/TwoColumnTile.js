import PropTypes from 'prop-types';
import React, { useEffect } from 'react';
import noop from 'lodash/noop';
import map from 'lodash/map';
import isEmpty from 'lodash/isEmpty';
import RichTextContent from '../../../RichTextContent/RichTextContent';
import Icon from '../../../Icon/Icon';
import { analyticsEventAction, analyticsEventName } from '../../../../utils/common';
import analytics from '../../../../utils/analytics';

import styles from './TwoColumnTile.css';

function TwoColumnTile({
  title,
  description,
  imageUrl,
  closeModalLabel,
  onModalClose,
  modalLinks,
  analyticsMetadataFromParent,
}) {
  const { click, impression } = analyticsEventAction;
  const { clickCta, modalsImpression } = analyticsEventName;

  useEffect(() => {
    analytics.send({
      eventAction: impression,
      eventName: modalsImpression,
      eventCategory: 'modals',
      eventElementName: 'welcomeModal',
      eventElementText: title || '',
    });
  }, [title, impression, modalsImpression]);

  const closeModal = () => {
    analytics.send({
      eventAction: click,
      eventName: clickCta,
      eventCategory: 'modals',
      eventElementName: 'welcomeModal',
      eventElementText: closeModalLabel,
    });
    onModalClose();
  };

  return (
    <div className={styles.container}>
      <div className={styles.content}>
        {
          title && (
            <div className={styles.title}>
              {title}
            </div>
          )
        }

        {
          description && (
            <RichTextContent
              className={styles.description}
              content={description}
            />
          )
        }

        {
          !isEmpty(modalLinks) && (
            <div className={styles.tileLinks}>
              {
                map(modalLinks, (link) => (
                  // eslint-disable-next-line react/jsx-no-target-blank
                  <a
                    className={styles.tileLink}
                    href={link.ctaUrl}
                    target={link.ctaOpenInNewTab ? '_blank' : '_self'}
                    rel={link.ctaOpenInNewTab ? 'noopener noreferrer' : null}
                    title={link.ctaTitle}
                    key={link.ctaLabel}
                    analytics-metadata={analyticsMetadataFromParent}
                  >
                    <div className={styles.tileLinkContent}>
                      {
                        link.ctaLabel && (
                          <span className={styles.tileLinkLabel}>
                            {link.ctaLabel}
                          </span>
                        )
                      }

                      {
                        link.ctaDescription && (
                          <span
                            className={styles.tileLinkDescription}
                          >
                            {link.ctaDescription}
                          </span>
                        )
                      }
                    </div>

                    <Icon name="chevronRight" className={styles.tileLinkIcon} size={24} />
                  </a>
                ))
              }
            </div>
          )
        }

        {
          closeModalLabel && (
            <button
              className={styles.backButton}
              onClick={closeModal}
            >
              {closeModalLabel}
            </button>
          )
        }
      </div>

      <div
        className={styles.imageContainer}
        style={{
          backgroundImage: `url(${imageUrl})`,
        }}
      />
    </div>
  );
}

TwoColumnTile.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
  imageUrl: PropTypes.string,
  closeModalLabel: PropTypes.string,
  onModalClose: PropTypes.func,
  modalLinks: PropTypes.arrayOf(PropTypes.shape({})),
  analyticsMetadataFromParent: PropTypes.string,
};

TwoColumnTile.defaultProps = {
  title: null,
  description: null,
  imageUrl: null,
  closeModalLabel: null,
  onModalClose: noop,
  modalLinks: null,
  analyticsMetadataFromParent: null,
};

export default TwoColumnTile;
