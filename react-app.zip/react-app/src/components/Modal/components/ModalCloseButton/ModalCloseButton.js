import PropTypes from 'prop-types';
import React from 'react';
import cx from 'classnames';
import Icon from '../../../Icon/Icon';

import styles from './ModalCloseButton.css';

export const modalButtonTheme = {
  default: 'default',
  v2: 'v2',
  fullPageView: 'fullPageView',
};

function ModalCloseButton({ onClick, className, theme, ariaLabel }) {
  const isVersionTwo = modalButtonTheme.v2 === theme;
  const isFullPageModal = modalButtonTheme.fullPageView === theme;
  return (
    <button
      className={cx(styles.button, {
        [styles.versionTwo]: isVersionTwo,
        [styles.fullPageView]: isFullPageModal,
      }, className)}
      onClick={onClick}
      aria-label={ariaLabel}
    >
      {
        theme === modalButtonTheme.default && <Icon name="crossClosedCircle" className={styles.icon} size={32} />
      }

      {
        theme === modalButtonTheme.v2 && <Icon name="vaCircleClosed" className={styles.icon} size={32} />
      }

      {
        theme === modalButtonTheme.fullPageView && <Icon name="vaCrossClosed" className={styles.fullPageIcon} size={58} />
      }
    </button>
  );
}

ModalCloseButton.propTypes = {
  onClick: PropTypes.func.isRequired,
  className: PropTypes.string,
  theme: PropTypes.string,
  ariaLabel: PropTypes.string,
};

ModalCloseButton.defaultProps = {
  className: '',
  theme: modalButtonTheme.default,
  ariaLabel: 'close modal',
};

export default ModalCloseButton;
