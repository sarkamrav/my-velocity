import { useEffect } from 'react';

/**
 * Traps focus within the given element
 *
 * @see https://hiddedevries.nl/en/blog/2017-01-29-using-javascript-to-trap-focus-in-an-element
 *
 * @param {React.Ref} elementRef
 */
export default function useTrapFocus(elementRef) {
  useEffect(() => {
    const KEYCODE_TAB = 9;

    function handleKeyDown(e) {
      const focusableElements = elementRef.current.querySelectorAll(
        'a[href]:not([disabled]), button:not([disabled]), textarea:not([disabled]), input[type="text"]:not([disabled]), input[type="radio"]:not([disabled]), input[type="checkbox"]:not([disabled]), select:not([disabled])',
      );

      const firstFocusableEl = focusableElements[0];
      const lastFocusableEl = focusableElements[focusableElements.length - 1];

      const isTabPressed = e.key === 'Tab' || e.keyCode === KEYCODE_TAB;

      if (!isTabPressed) {
        return;
      }

      if (e.shiftKey) {
        // Shift + Tab
        if (document.activeElement === firstFocusableEl) {
          lastFocusableEl.focus();
          e.preventDefault();
        }

      // Tab
      } else if (document.activeElement === lastFocusableEl) {
        firstFocusableEl.focus();
        e.preventDefault();
      }
    }

    if (elementRef.current) {
      elementRef.current.addEventListener('keydown', handleKeyDown);
    }

    return () => {
      if (elementRef.current) {
        elementRef.current.removeEventListener('keydown', handleKeyDown);
      }
    };
  }, [elementRef.current]);
}
