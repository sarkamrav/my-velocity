import React, { useCallback, useEffect, useRef, useState } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import Collapse from '../Collapse/Collapse';
import Button from '../Button/Button';
import Icon from '../Icon/Icon';

import styles from './RichTextContent.css';
import { focusableCssSelector } from '../../utils/common';

function RichTextContent({
  content,
  className,
  isExpandable,
  readMoreLabel,
  readLessLabel,
  truncateTextHeight,
  jsObjectKey,
  ...rest
}) {
  const elementRef = useRef();
  const [isExpanded, setIsExpanded] = useState(false);

  const richText = (
    <div
      ref={elementRef}
      className={cx('vff__rte', className)}
      dangerouslySetInnerHTML={{ __html: content }}
      {...rest}
    />
  );

  useEffect(() => {
    if (isExpandable) {
      const focusableElements = elementRef.current.querySelectorAll(focusableCssSelector);

      for (let i = 0, max = focusableElements.length; i < max; i += 1) {
        if (!isExpanded) {
          focusableElements[i].tabIndex = -1;
        } else {
          focusableElements[i].tabIndex = 0;
        }
      }
    }
  }, [isExpanded, content, isExpandable]);

  const onReadMoreClick = useCallback(() => {
    setIsExpanded((prevState) => !prevState);
  }, []);

  return (
    <>
      {isExpandable ? (
        <Collapse
          className={cx(styles.expandableRichTextContainer, {
            [styles.isExpanded]: isExpanded,
          })}
          initialHeight={truncateTextHeight}
          isOpen={isExpanded}
          id={jsObjectKey}
          duration={100}
        >
          {richText}

          <div className={styles.buttonContainer}>
            <Button
              buttonType="red-link"
              onClick={onReadMoreClick}
              aria-controls={jsObjectKey}
              aria-expanded={isExpanded}
            >
              {isExpanded ? readLessLabel : readMoreLabel}
              <Icon name="chevron" size={10} />
            </Button>
          </div>
        </Collapse>
      ) : (
        richText
      )}
    </>
  );
}

RichTextContent.propTypes = {
  content: PropTypes.string.isRequired,
  className: PropTypes.string,
  isExpandable: PropTypes.bool,
  readMoreLabel: PropTypes.string,
  readLessLabel: PropTypes.string,
  truncateTextHeight: PropTypes.number,
  jsObjectKey: PropTypes.string,
};

RichTextContent.defaultProps = {
  className: '',
  isExpandable: false,
  readMoreLabel: 'Read More',
  readLessLabel: 'Read Less',
  truncateTextHeight: 100,
  jsObjectKey: 'rich-text-dXNKBYrb',
};

export default RichTextContent;
