import React from 'react';
import renderer from 'react-test-renderer';

import RichTextContent from '../RichTextContent';

import { render, screen, fireEvent } from '../../../unitTest/test-utils';

describe('RichTextContent', () => {
  const richTextMock = {
    isExpandable: false,
    content: '<p>When you first join the program, your default membership status is&nbsp;Red&nbsp;(entry level). From there, you can upgrade to&nbsp;Silver,&nbsp;Gold, and then&nbsp;Platinum.</p> \n<p>Status Credits help determine your&nbsp;<b style="font-family: var(--fontFamily); font-size: var(--fontSizeMedium); color: var(--black);">Velocity membership level</b><span style="font-family: var(--fontFamily); font-size: var(--fontSizeMedium); font-weight: var(--fontWeightRegular); color: var(--black);">&nbsp;– Platinum, Gold, Silver and Red. The more Status Credits you have, the higher your membership tier. Each Status Credit you earn is valid for 12 months. They are different to Velocity Points in that they can only be earned in a </span><a title="How to Earn" href="https://experience.velocityfrequentflyer.com/the-basics/status#tab_how-to-earn">few ways.</a><br> </p> \n<p>As a Platinum, Gold or Silver Velocity member, you will receive all the benefits you expect from a world-class global frequent flyer program, plus a unique range of benefits tailored with our Platinum and Gold Velocity members in mind. The higher your level of membership, the greater the benefits you will receive.<a title="How to Earn" href="https://experience.velocityfrequentflyer.com/the-basics/status#tab_how-to-earn">few ways.</a><br> </p>',
    readMoreLabel: 'Read More',
    readLessLabel: 'Read Less',
    truncateTextHeight: 100,
  };

  beforeAll(() => {
    Object.defineProperty(window, 'matchMedia', {
      writable: true,
      value: jest.fn().mockImplementation(query => ({
        matches: false,
        media: query,
        onchange: null,
        addEventListener: jest.fn(),
        removeEventListener: jest.fn(),
        dispatchEvent: jest.fn(),
      })),
    });
  });

  describe('snapshot testing', () => {
    it('should render plain rich text', () => {
      const tree = renderer.create(
        <RichTextContent {...richTextMock} />,
      ).toJSON();

      expect(tree).toMatchSnapshot();
    });

    it('should render expamdable rich text', () => {
      const tree = renderer.create(
        <RichTextContent {...richTextMock} isExpandable />,
      ).toJSON();

      expect(tree).toMatchSnapshot();
    });
  });

  describe('expandable rich text', () => {
    let wrapper;
    let unmountWrapper;
    const elementClassName = '.mv__src-components-RichTextContent-RichTextContent_expandableRichTextContainer';

    beforeEach(() => {
      const { container, unmount } = render(<RichTextContent {...richTextMock} isExpandable />);
      wrapper = container;
      unmountWrapper = unmount;
    });

    afterEach(() => {
      unmountWrapper();
    });

    it('should render expandable rich text', () => {
      const expandableContainer = wrapper.querySelector(elementClassName);

      expect(expandableContainer).not.toBeNull();
    });

    it('should render read more/less button', () => {
      const readMoreButtonClass = '.mv__src-components-RichTextContent-RichTextContent_buttonContainer';
      const readMoreBotton = wrapper.querySelector(readMoreButtonClass);

      expect(readMoreBotton).not.toBeNull();
    });

    it('should expand expandableContent on read more button clicked', () => {
      const readMoreButton = screen.getByRole('button', { expanded: false, name: 'Read More' });

      fireEvent.click(readMoreButton);

      const expandedContent = wrapper.querySelector(`${elementClassName}.mv__src-components-RichTextContent-RichTextContent_isExpanded`);

      expect(expandedContent).not.toBeNull();
    });

    it('should change button name to read less on read more button clicked', () => {
      const readMoreButton = screen.getByRole('button', { expanded: false, name: 'Read More' });

      fireEvent.click(readMoreButton);

      expect(readMoreButton.textContent).toBe('Read Less');
    });
  });
});
