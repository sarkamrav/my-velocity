import PropTypes from 'prop-types';
import React, { useState } from 'react';
import AnimateHeight from 'react-animate-height';

/**
 * A component used to create regions of content that can expand/collapse with a
 * simple animation
 */
function Collapse({ isOpen, duration, children, initialHeight, ...restProps }) {
  const [userPrefersReducedMotion] = useState(
    () => window.matchMedia('(prefers-reduced-motion: reduce)').matches,
  );

  return (
    <AnimateHeight
      easing="ease-in-out"
      height={isOpen ? 'auto' : initialHeight}
      duration={userPrefersReducedMotion ? 0 : duration}
      {...restProps}
    >
      {children}
    </AnimateHeight>
  );
}

Collapse.defaultProps = {
  duration: 250,
  initialHeight: 0,
};

Collapse.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  duration: PropTypes.number,
  children: PropTypes.node.isRequired,
  initialHeight: PropTypes.number,
};

export default Collapse;
