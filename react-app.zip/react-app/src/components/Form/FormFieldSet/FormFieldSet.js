import cx from 'classnames';
import React from 'react';
import PropTypes from 'prop-types';
import styles from './FormFieldSet.css';

export const formFieldGroupTheme = {
  radioButton: 'radioButton',
  radioButtonWithCircle: 'radioButtonWithCircle',
  radioImageButton: 'radioImageButton',
};

function FormFieldSet({ children, label, isLabelVisuallyHidden, error, theme, className }) {
  return (
    <fieldset
      className={cx(styles.groupContainer, {
        [styles.hasError]: !!error,
        [styles.themeRadioButtonWithCircle]: theme === formFieldGroupTheme.radioButtonWithCircle,
        [styles.themeRadioButton]: theme === formFieldGroupTheme.radioButton,
        [styles.themeRadioImageButton]: theme === formFieldGroupTheme.radioImageButton,
      }, className)}
    >
      <legend
        className={cx(styles.groupLabel, {
          [styles.srOnly]: isLabelVisuallyHidden,
        })}
      >
        {label}
      </legend>

      <div className={styles.groupContent}>{children}</div>

      {
        error && <div className={styles.errorMessage}>{error}</div>
      }
    </fieldset>
  );
}

FormFieldSet.propTypes = {
  children: PropTypes.node.isRequired,
  label: PropTypes.string,
  error: PropTypes.string,
  theme: PropTypes.oneOf([
    formFieldGroupTheme.radioButton,
    formFieldGroupTheme.radioButtonWithCircle,
    formFieldGroupTheme.radioImageButton,
  ]),
  isLabelVisuallyHidden: PropTypes.bool,
  className: PropTypes.string,
};

FormFieldSet.defaultProps = {
  label: '',
  error: '',
  className: '',
  theme: formFieldGroupTheme.radioButton,
  isLabelVisuallyHidden: false,
};

export default FormFieldSet;
