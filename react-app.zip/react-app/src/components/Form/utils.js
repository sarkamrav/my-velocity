import forEach from 'lodash/forEach';

/**
 * Validates a form field, returning an error message if validate fails.
 *
 * @param {string} fieldValue - The current value for the field being validated
 * @param {function[]} validators - Validator functions for the field being validated
 * @returns {string} - An error message if there was an error, otherwise an empty string
 */
export function validateFormField(
  fieldValue,
  validators = [],
) {
  let error = '';

  // eslint-disable-next-line consistent-return
  forEach(validators || [], (validator) => {
    error = validator(fieldValue);

    if (error) {
      // Exit early on first found error
      return false;
    }
  });

  return error;
}
