import React, { useState } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import noop from 'lodash/noop';
import uniqueId from 'lodash/uniqueId';

import styles from './Radio.css';

function Radio({
  label,
  id,
  checked,
  value,
  className,
  name,
  imageUrl,
  onChange,
  onFocus,
  onBlur,
}) {
  const [radioId] = useState(id || uniqueId('radio_'));

  return (
    <div className={cx(styles.container, className)}>
      <input
        id={radioId}
        type="radio"
        name={name}
        value={value}
        className={styles.radio}
        onChange={onChange}
        onFocus={onFocus}
        onBlur={onBlur}
        checked={checked}
        aria-checked={checked}
      />
      <label className={styles.label} htmlFor={radioId}>
        {
          imageUrl && (
            <div className={styles.imageContainer}>
              <img className={styles.image} src={imageUrl} alt="" />
            </div>
          )
        }
        <span
          className={cx({
            [styles.srOnly]: !!imageUrl,
          })}
        >
          {label}
        </span>
      </label>
    </div>
  );
}

Radio.propTypes = {
  label: PropTypes.node,
  id: PropTypes.string,
  name: PropTypes.string,
  className: PropTypes.string,
  value: PropTypes.string,
  checked: PropTypes.bool,
  imageUrl: PropTypes.string,
  onChange: PropTypes.func,
  onFocus: PropTypes.func,
  onBlur: PropTypes.func,
};

Radio.defaultProps = {
  label: null,
  id: '',
  name: '',
  className: '',
  value: '',
  checked: false,
  imageUrl: '',
  onChange: noop,
  onFocus: noop,
  onBlur: noop,
};

export default Radio;
