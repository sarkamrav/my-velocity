import React, { useState } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import noop from 'lodash/noop';
import uniqueId from 'lodash/uniqueId';

import Icon from '../../Icon/Icon';
import RichTextContent from '../../RichTextContent/RichTextContent';

import styles from './Checkbox.css';

export const checkboxSize = {
  small: 'small',
  large: 'large',
};

function Checkbox({
  label,
  id,
  name,
  containerClassName,
  className,
  labelClassName,
  size,
  onFocus,
  onBlur,
  onChange,
  error,
  checked,
}) {
  const [checkboxId] = useState(id || uniqueId('checkbox_'));

  return (
    <div className={cx(styles.container, containerClassName, [styles[size]])}>
      <label className={cx(styles.label, className)} htmlFor={checkboxId}>
        <input
          id={checkboxId}
          type="checkbox"
          name={name}
          className={styles.checkboxInput}
          onChange={onChange}
          onFocus={onFocus}
          onBlur={onBlur}
          checked={checked}
        />
        <div className={styles.checkbox}>
          <Icon className={styles.icon} name="tick" />
        </div>
        <RichTextContent className={cx(styles.labelText, labelClassName)} content={label} />
      </label>

      {
        error && <div className={styles.errorMessage}>{error}</div>
      }
    </div>
  );
}

Checkbox.propTypes = {
  label: PropTypes.oneOfType([PropTypes.string, PropTypes.element]),
  id: PropTypes.string,
  containerClassName: PropTypes.string,
  className: PropTypes.string,
  labelClassName: PropTypes.string,
  error: PropTypes.string,
  name: PropTypes.string,
  size: PropTypes.oneOf([checkboxSize.small, checkboxSize.large]),
  onBlur: PropTypes.func,
  onChange: PropTypes.func,
  onFocus: PropTypes.func,
  checked: PropTypes.bool,
};

Checkbox.defaultProps = {
  label: '',
  id: '',
  containerClassName: '',
  name: '',
  className: '',
  labelClassName: '',
  error: '',
  size: checkboxSize.small,
  checked: false,
  onBlur: noop,
  onChange: noop,
  onFocus: noop,
};

export default Checkbox;
