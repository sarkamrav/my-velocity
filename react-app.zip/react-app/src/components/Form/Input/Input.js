import React, { forwardRef, useState } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import uniqueId from 'lodash/uniqueId';
import noop from 'lodash/noop';

import Icon from '../../Icon/Icon';

import styles from './Input.css';

function Input({
  containerRef,
  inputRef,
  className,
  id, label, value, onChange, prefix,
  error, onFocus, onBlur, icon, name,
  'aria-describedby': ariaDescribedby,
}) {
  const [inputId] = useState(id || uniqueId('input_'));
  const [focused, setFocused] = useState(false);

  const errorMessageContainerId = `${inputId}_error`;

  function handleFocus(e) {
    if (onFocus) onFocus(e);
    setFocused(true);
  }

  function handleBlur(e) {
    if (onBlur) onBlur(e);
    setFocused(false);
  }

  return (
    <div
      className={cx(styles.container, {
        [styles.hasError]: !!error,
        [styles.hasInput]: !!value,
        [styles.hasFocus]: focused,
      }, className)}
      ref={containerRef}
    >
      <label
        className={styles.label}
        htmlFor={inputId}
      >
        {label}
      </label>
      <div className={styles.inputContainer}>
        {
          prefix ? (
            <div className={styles.prefix}>{prefix}</div>
          ) : null
        }

        <input
          ref={inputRef}
          id={inputId}
          className={styles.input}
          value={value}
          name={name}
          onChange={onChange}
          autoComplete="off"
          aria-invalid={!!error}
          aria-describedby={cx(errorMessageContainerId, ariaDescribedby)}
          onFocus={handleFocus}
          onBlur={handleBlur}
        />

        {icon ? <Icon name={icon} size="extra-small" className={styles.icon} /> : null}
      </div>

      {
        error && <span role="alert" id={errorMessageContainerId} className={styles.message}>{error}</span>
      }
    </div>
  );
}

Input.propTypes = {
  className: PropTypes.string,
  label: PropTypes.string,
  id: PropTypes.string,
  value: PropTypes.string,
  name: PropTypes.string,
  onChange: PropTypes.func,
  onFocus: PropTypes.func,
  onBlur: PropTypes.func,
  prefix: PropTypes.string,
  error: PropTypes.string,
  tooltip: PropTypes.shape({}),
  icon: PropTypes.string,
  analyticsDataFromParent: PropTypes.shape({}),
  inputRef: PropTypes.shape({}),
  containerRef: PropTypes.shape({}),
  'aria-describedby': PropTypes.string,
};

Input.defaultProps = {
  className: '',
  label: '',
  id: '',
  value: '',
  name: '',
  prefix: null,
  error: null,
  onFocus: noop,
  onBlur: noop,
  onChange: noop,
  tooltip: null,
  icon: null,
  analyticsDataFromParent: {},
  inputRef: null,
  containerRef: null,
  'aria-describedby': '',
};

export default forwardRef((props, ref) => <Input {...props} containerRef={ref} />);
