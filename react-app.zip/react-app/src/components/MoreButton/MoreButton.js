import cx from 'classnames';
import PropTypes from 'prop-types';
import React from 'react';

import Icon from '../Icon/Icon';

import styles from './MoreButton.css';

function MoreButton({
  isShowingMore,
  readMoreLabel,
  readLessLabel,
  onClick,
  displayMode,
  contentId,
}) {
  const buttonLabel = isShowingMore ? readLessLabel : readMoreLabel;

  return (
    <div className={styles.container}>
      <button
        className={cx(styles.button, {
          [styles.dark]: displayMode === 'dark',
        })}
        onClick={onClick}
        aria-expanded={isShowingMore}
        aria-label={buttonLabel}
        aria-controls={contentId}
      >
        {buttonLabel}

        <Icon
          className={styles.icon}
          name={isShowingMore ? 'accordionOpen' : 'accordionClosed'}
          size={16}
        />
      </button>
    </div>
  );
}

MoreButton.propTypes = {
  isShowingMore: PropTypes.bool.isRequired,
  readMoreLabel: PropTypes.string,
  readLessLabel: PropTypes.string,
  contentId: PropTypes.string,
  onClick: PropTypes.func.isRequired,
  displayMode: PropTypes.oneOf(['light', 'dark']),
};

MoreButton.defaultProps = {
  displayMode: 'light',
  contentId: '',
  readMoreLabel: 'More',
  readLessLabel: 'Less',
};

export default MoreButton;
