import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import _ from 'lodash';
import styles from './Badge.css';

function Badge({ number, className }) {
  return (
    <span
      className={cx(styles.container, className)}
      data-count={_.clamp(number, 0, 99)}
    >
      {number}
    </span>
  );
}

Badge.propTypes = {
  number: PropTypes.number,
  className: PropTypes.string,
};

Badge.defaultProps = {
  number: 0,
  className: '',
};

export default Badge;
