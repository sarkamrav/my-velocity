import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import Icon from '../Icon/Icon';
import styles from './Button.css';

function A({ children, buttonType, className, linkClassName, ctaAsLink, target, title, ...rest }) {
  return (
    <a
      className={cx(
        styles.defaults,
        {
          [styles.button]: !ctaAsLink,
          [styles.anchor]: ctaAsLink,
        },
        [styles[`buttonType--${buttonType}`]],
        ctaAsLink ? linkClassName : className,
      )}
      target={target}
      rel={target === '_blank' ? 'noopener noreferrer' : null}
      title={title || children}
      {...rest}
    >
      {children}
      {
        ctaAsLink ? (
          <>&nbsp;<Icon className={styles.chevron} name="chevron" size={8} /></>
        ) : null
      }
    </a>
  );
}

A.propTypes = {
  children: PropTypes.node.isRequired,
  buttonType: PropTypes.oneOf(['primary', 'primary-transparent', 'secondary', 'secondary-transparent', 'tertiary', 'tertiary-transparent', 'red-link', 'black-link', 'white-link', 'purple-link']),
  className: PropTypes.string,
  linkClassName: PropTypes.string,
  ctaAsLink: PropTypes.bool,
  target: PropTypes.string,
  title: PropTypes.string,
};

A.defaultProps = {
  buttonType: 'black-link',
  className: '',
  linkClassName: '',
  ctaAsLink: false,
  target: '_self',
  title: null,
};

export default A;
