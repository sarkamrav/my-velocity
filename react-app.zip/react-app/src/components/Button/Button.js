import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import Loading from '../Loading/Loading';
import styles from './Button.css';

function Button({
  children, buttonType, className, loading,
  hideBorder, ...rest
}) {
  return (
    <button
      className={cx(
        styles.defaults, styles.button, [styles[`buttonType--${buttonType}`]], {
          [styles.hideBorder]: hideBorder,
        },
        className,
      )}
      {...rest}
    >
      {loading ? <Loading containerClassName={styles.loading} className={styles.loadingIndicator} /> : children}
    </button>
  );
}

Button.propTypes = {
  children: PropTypes.node.isRequired,
  buttonType: PropTypes.oneOf([
    'primary', 'primary-transparent',
    'secondary', 'secondary-transparent',
    'tertiary', 'tertiary-transparent',
    'red-link', 'black-link', 'purple-link',
  ]),
  className: PropTypes.string,
  loading: PropTypes.bool,
  hideBorder: PropTypes.bool,
};

Button.defaultProps = {
  buttonType: 'secondary',
  className: '',
  loading: false,
  hideBorder: false,
};

export default Button;
