import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import styles from './Loading.css';
import LoadingSvg from './Loading.svg';

function Loading({ className, containerClassName }) {
  return (
    <div className={cx(styles.loadingContainer, containerClassName)}>
      <LoadingSvg className={cx(styles.loading, className)} />
    </div>
  );
}

Loading.propTypes = {
  containerClassName: PropTypes.string,
  className: PropTypes.string,
};

Loading.defaultProps = {
  containerClassName: '',
  className: '',
};

export default Loading;
