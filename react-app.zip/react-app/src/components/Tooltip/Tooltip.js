import React, { useState, useEffect, useRef, useMemo } from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';
import uniqueId from 'lodash/uniqueId';
import { usePopper } from 'react-popper';
import cx from 'classnames';

import { useIsFirstRender } from '../../hooks/useIsFirstRender/useIsFirstRender';
import Icon from '../Icon/Icon';

import tooltipStyles from './Tooltip.css';

function Tooltip({ id, children, onAnalytics, buttonClass, tooltipContainerClass, buttonContent, isHoverable }) {
  const [isClicked, setIsClicked] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [tooltipId] = useState(id || (() => uniqueId('tooltipId_')));
  const [referenceElement, setReferenceElement] = useState(null);
  const [popperElement, setPopperElement] = useState(null);
  const [arrowElement, setArrowElement] = useState(null);
  const isFirstRender = useIsFirstRender();
  const { styles, attributes } = usePopper(referenceElement, popperElement, {
    modifiers: [
      { name: 'arrow', options: { element: arrowElement } },
      { name: 'offset', options: { offset: [0, 10] } },
      { name: 'preventOverflow',
        options: {
          padding: 24,
        },
      },
      {
        name: 'flip',
        options: {
          fallbackPlacements: ['top'],
        },
      },
    ],
    placement: 'bottom',
  });

  const isVisible = useMemo(() => isClicked || (isHoverable && isHovered),
    [isClicked, isHovered, isHoverable]);

  const containerRef = useRef();
  const timeoutRef = useRef();

  function closePopper() {
    setIsClicked(false);
  }

  function onBlurHandler() {
    timeoutRef.current = setTimeout(closePopper, 100);
  }

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
  };

  function onFocusHandler() {
    clearTimeout(timeoutRef.current);
  }

  function handleKeyDown(event) {
    if (event.key === 'Escape' && containerRef.current) {
      const button = containerRef.current.querySelector('button[aria-haspopup="dialog"]');

      if (button) {
        button.focus();
      }
      closePopper();
    }
  }

  function togglePopper() {
    setIsClicked((prev) => !prev);
  }

  useEffect(() => {
    if (!isFirstRender && isVisible) {
      onAnalytics({
        interactionType: 'expand',
      });
    }

    if (!isFirstRender && !isVisible) {
      onAnalytics({
        interactionType: 'collapse',
      });
    }
  }, [isVisible]);

  return (
    <>
      {/* eslint-disable-next-line jsx-a11y/no-static-element-interactions */}
      <div
        onBlur={onBlurHandler}
        onFocus={onFocusHandler}
        tabIndex="-1"
        onKeyDown={handleKeyDown}
        ref={containerRef}
      >
        <button
          type="button"
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
          ref={setReferenceElement}
          onClick={togglePopper}
          className={cx(tooltipStyles.button, buttonClass)}
          aria-expanded={isVisible}
          aria-haspopup="dialog"
          aria-controls={tooltipId}
        >
          {buttonContent || (
            <>
              <Icon name="info" size={24} aria-hidden />
              <span className="sr-only">Open tooltip</span>
            </>
          )}
        </button>
        {ReactDOM.createPortal(
          <div
            id={tooltipId}
            role="dialog"
            className={cx(
              tooltipStyles.popper,
              {
                [tooltipStyles.visible]: isVisible,
              },
              tooltipContainerClass,
            )}
            ref={setPopperElement}
            style={styles.popper}
            tabIndex="-1"
            {...attributes.popper}
          >
            <div
              className={tooltipStyles.arrow}
              ref={setArrowElement}
              style={styles.arrow}
              aria-hidden
            />
            <div className={tooltipStyles.container}>{children}</div>
          </div>,
          document.body,
        )}
      </div>
    </>
  );
}

Tooltip.propTypes = {
  id: PropTypes.string,
  children: PropTypes.node.isRequired,
  onAnalytics: PropTypes.func,
  buttonContent: PropTypes.node,
  buttonClass: PropTypes.string,
  tooltipContainerClass: PropTypes.string,
  isHoverable: PropTypes.bool,
};

Tooltip.defaultProps = {
  id: null,
  onAnalytics: () => { },
  buttonClass: '',
  tooltipContainerClass: '',
  buttonContent: null,
  isHoverable: true,
};

export default Tooltip;
