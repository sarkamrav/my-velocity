import { createElement } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';

export const headerTitleTag = {
  h1: 'h1',
  h2: 'h2',
  h3: 'h3',
  h4: 'h4',
  h5: 'h5',
  h6: 'h6',
};

function Header({ tagTitle, classNames, title }) {
  return createElement(tagTitle, {
    className: cx(classNames),
    dangerouslySetInnerHTML: { __html: title },
  });
}

Header.propTypes = {
  tagTitle: PropTypes.oneOf([
    headerTitleTag.h1,
    headerTitleTag.h2,
    headerTitleTag.h3,
    headerTitleTag.h4,
    headerTitleTag.h5,
    headerTitleTag.h6,
  ]),
  classNames: PropTypes.string,
  title: PropTypes.string,
};

Header.defaultProps = {
  tagTitle: headerTitleTag.h6,
  classNames: '',
  title: '',
};

export default Header;
