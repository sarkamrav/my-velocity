import React from 'react';
import PropTypes from 'prop-types';
import { sendToNewRelic, newRelicErrorPrefix } from '../../utils/newRelic';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    // eslint-disable-next-line react/no-unused-state
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    // Update state so the next render will show the fallback UI.
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    const { section } = this.props;
    // You can also log the error to an error reporting service
    sendToNewRelic(`${newRelicErrorPrefix.unhandledError}${section || ''}`, { error, errorInfo });
  }

  render() {
    const { children } = this.props;
    return children;
  }
}

ErrorBoundary.propTypes = {
  children: PropTypes.node,
  section: PropTypes.string,
};

ErrorBoundary.defaultProps = {
  children: null,
  section: '',
};

export default ErrorBoundary;
