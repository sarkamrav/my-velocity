import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import * as Icons from './icons/_IconList';
import styles from './Icon.css';

function Icon(props) {
  const { name, className, size, ...rest } = props;
  const IconComponent = Icons[name];
  return IconComponent ? (
    <IconComponent
      className={cx(styles.icon, className)}
      style={{
        width: size,
        height: size,
      }}
      {...rest}
    />
  ) : null;
}

Icon.propTypes = {
  name: PropTypes.string.isRequired,
  className: PropTypes.string,
  size: PropTypes.number,
};

Icon.defaultProps = {
  className: '',
  size: 20,
};

export default Icon;
