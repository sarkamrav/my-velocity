import React, { useState } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import cx from 'classnames';
import HorizontalScroll from '../HorizontalScroll/HorizontalScroll';
import styles from './Table.css';

function Table({ headers, rows, hasShadow, tableClassName, itemsPerPage }) {
  const [selectedPage, setSelectedPage] = useState(0);
  const showPagination = _.size(rows) > itemsPerPage;
  const maxPage = _.ceil(_.size(rows) / itemsPerPage);

  return _.size(rows) > 0 ? (
    <>
      <HorizontalScroll>
        <table
          className={cx(styles.table, tableClassName, {
            [styles.noShadow]: !hasShadow,
          })}
        >
          {
            _.size(headers) > 0 ? (
              <thead>
                <tr>
                  {
                    _.map(headers, header => (
                      <th
                        scope="col"
                        className={styles.header}
                        key={React.isValidElement(header) ? header.props.children : header}
                      >
                        {header}
                      </th>
                    ))
                  }
                </tr>
              </thead>
            ) : null
          }

          <tbody>
            {
              _(rows)
                .chunk(itemsPerPage)
                .nth(selectedPage)
                .map(row => (
                  <tr key={row.uniqueId}>
                    {
                      _(row)
                        .keys()
                        .map(key => (key !== 'uniqueId' ? <td key={key} className={styles.cell}>{row[key]}</td> : null))
                        .value()
                    }
                  </tr>
                ))
            }
          </tbody>
        </table>
      </HorizontalScroll>
      {
        showPagination ? (
          <div className={styles.pagination}>
            <button
              className={styles.page}
              disabled={selectedPage === 0}
              onClick={selectedPage !== 0 ? () => setSelectedPage(prev => prev - 1) : null}
            >
              Prev
            </button>
            {
              _.map(_.range(maxPage), page => (
                <button
                  key={page}
                  onClick={() => setSelectedPage(page)}
                  className={cx(styles.page, {
                    [styles.selected]: selectedPage === page,
                  })}
                >
                  {page + 1}
                </button>
              ))
            }
            <button
              className={styles.page}
              disabled={selectedPage === maxPage - 1}
              onClick={selectedPage !== maxPage - 1 ? () => setSelectedPage(prev => prev + 1) : null}
            >
              Next
            </button>
          </div>
        ) : null
      }
    </>
  ) : null;
}

Table.propTypes = {
  headers: PropTypes.arrayOf(PropTypes.node),
  tableClassName: PropTypes.string,
  rows: PropTypes.arrayOf(PropTypes.shape({
    uniqueId: PropTypes.string.isRequired,
  })),
  hasShadow: PropTypes.bool,
  itemsPerPage: PropTypes.number,
};

Table.defaultProps = {
  tableClassName: '',
  headers: [],
  rows: [],
  hasShadow: true,
  itemsPerPage: 10,
};

export default Table;
