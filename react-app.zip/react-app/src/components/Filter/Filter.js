import React, { useState, useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import styles from './Filter.css';

import Icon from '../Icon/Icon';

function Filter({ label, options, selected, onChange }) {
  const [isOpen, setIsOpen] = useState(false);
  const [highlightedOption, setHighlightedOption] = useState(selected);
  const dropdownRef = useRef(null);
  const optionsRef = useRef(null);

  const toggleDropdown = () => setIsOpen(!isOpen);

  useEffect(() => {
    // Event handler to close the dropdown if the click is outside of it
    const handleClickOutside = (event) => {
      if (isOpen && !optionsRef.current.contains(event.target) && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const handleKeyDown = (event) => {
    let nextIndex; let
      prevIndex;
    switch (event.key) {
      case 'Enter':
      case ' ':
        toggleDropdown();
        break;
      case 'ArrowDown':
        nextIndex = (options.findIndex(option => option.value === highlightedOption) + 1) % options.length;
        setHighlightedOption(options[nextIndex].value);
        break;
      case 'ArrowUp':
        prevIndex = (options.findIndex(option => option.value === highlightedOption) - 1 + options.length) % options.length;
        setHighlightedOption(options[prevIndex].value);
        break;
      case 'Escape':
        setIsOpen(false);
        break;
      default:
        break;
    }
  };

  const handleOptionClick = (value) => {
    onChange(value);
    setIsOpen(false);
  };

  return (
    <div className={styles.filter}>
      <div className={styles.label}>{label}</div>
      <div
        className={cx(styles.dropdown, { [styles.openDropdown]: isOpen })}
        onClick={toggleDropdown}
        onKeyDown={handleKeyDown}
        role="button"
        tabIndex={0}
        ref={dropdownRef}
      >
        {options.find(option => option.value === selected).label}
        <Icon
          name="chevron"
          size={14}
          className={cx({
            [styles.chevronUp]: isOpen,
            [styles.chevronDown]: !isOpen,
          })}
        />
      </div>
      <div className={cx(styles.options, { [styles.optionsOpen]: isOpen })} ref={optionsRef}>          {options.map(option => (
        <div
          className={cx(styles.option, { [styles.selected]: option.value === selected })}
          key={option.value}
          role="option"
          tabIndex={0}
          aria-selected={highlightedOption === option.value}
          onClick={() => handleOptionClick(option.value)}
          onKeyDown={(event) => {
            if (event.key === 'Enter' || event.key === ' ') {
              handleOptionClick(option.value);
            }
          }}
        >
          {option.label}
        </div>
      ))}
      </div>
    </div>
  );
}

Filter.propTypes = {
  label: PropTypes.string.isRequired,
  options: PropTypes.arrayOf(
    PropTypes.shape({
      value: PropTypes.string.isRequired,
      label: PropTypes.string.isRequired,
    }),
  ).isRequired,
  selected: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
};

export default Filter;
