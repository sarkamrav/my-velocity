import React, { forwardRef } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import Icon from '../Icon/Icon';
import styles from './InformationAlert.css';

export const informationAlertTheme = {
  danger: 'danger',
  success: 'success',
};

function InformationAlert({
  status, icon, title, description, cta, className, analyticsMetadataFromParent, containerRef, tabIndex,
}) {
  return (
    <div
      ref={containerRef}
      className={cx(styles.container, {
        [styles.danger]: status === informationAlertTheme.danger,
        [styles.success]: status === informationAlertTheme.success,
      }, className)}
      analytics-metadata={analyticsMetadataFromParent}
      tabIndex={tabIndex}
    >
      {
        icon ? (
          <div className={styles.iconContainer}>
            <Icon name={icon} className={styles.icon} size={32} />
          </div>
        ) : null
      }
      <div className={styles.content}>
        { title ? <span className={cx('font-size font-size--large', styles.title)}>{title}</span> : null }
        <span className={cx('font-size', styles.description)}>{description}</span>
      </div>
      {
        cta ? <div>{cta}</div> : null
      }
    </div>
  );
}

InformationAlert.propTypes = {
  status: PropTypes.oneOf([
    informationAlertTheme.danger,
    informationAlertTheme.success,
  ]),
  icon: PropTypes.string,
  title: PropTypes.string,
  className: PropTypes.string,
  description: PropTypes.node,
  cta: PropTypes.shape(),
  analyticsMetadataFromParent: PropTypes.shape({}),
  containerRef: PropTypes.shape({}),
  tabIndex: PropTypes.number,
};

InformationAlert.defaultProps = {
  status: null,
  icon: null,
  title: null,
  cta: null,
  description: '',
  className: '',
  analyticsMetadataFromParent: null,
  containerRef: null,
  tabIndex: null,
};

export default forwardRef((props, ref) => <InformationAlert {...props} containerRef={ref} />);
