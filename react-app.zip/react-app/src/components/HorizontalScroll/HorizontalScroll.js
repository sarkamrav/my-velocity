import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import styles from './HorizontalScroll.css';

function HorizontalScroll({ children, className }) {
  return (
    <div className={cx(styles.container, className)}>
      {children}
    </div>
  );
}

HorizontalScroll.propTypes = {
  className: PropTypes.string,
  children: PropTypes.node.isRequired,
};

HorizontalScroll.defaultProps = {
  className: '',
};

export default HorizontalScroll;
