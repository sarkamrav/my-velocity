import React, { useEffect, useState } from 'react';
import cx from 'classnames';
import PropTypes from 'prop-types';
import styles from './Container.css';

const Container = ({
  children,
  fullWidth,
  noHorizontalPadding,
  backgroundColor,
  noVerticalPadding,
  jsObjectKey,
  hasBorderTop,
}) => {
  const [isChildNull, setIsChildNull] = useState(false);

  useEffect(() => {
    if (jsObjectKey) {
      const container = document.getElementById(`container-${jsObjectKey}`);
      if (container?.children.length > 0) {
        setIsChildNull(false);
      } else {
        setIsChildNull(true);
      }
    }
  }, []);

  if (!isChildNull) {
    return (
      <div
        className={cx(
          styles.mainContainer,
          {
            [styles.noHorizontalPadding]: noHorizontalPadding,
          },
          styles[`bg--${backgroundColor}`],
          {
            [styles.noVerticalPadding]: noVerticalPadding,
            [styles.borderTop]: hasBorderTop,
          },
        )}
      >
        <div
          id={`container-${jsObjectKey}`}
          className={cx(styles.container, { [styles.fullWidth]: fullWidth })}
        >
          {children}
        </div>
      </div>
    );
  }
  return null;
};

Container.propTypes = {
  children: PropTypes.node,
  fullWidth: PropTypes.bool,
  noHorizontalPadding: PropTypes.bool,
  backgroundColor: PropTypes.string,
  noVerticalPadding: PropTypes.bool,
  hasBorderTop: PropTypes.bool,
  jsObjectKey: PropTypes.string,
};

Container.defaultProps = {
  children: <></>,
  fullWidth: false,
  noHorizontalPadding: false,
  hasBorderTop: false,
  backgroundColor: null,
  noVerticalPadding: false,
  jsObjectKey: '',
};

export default Container;
