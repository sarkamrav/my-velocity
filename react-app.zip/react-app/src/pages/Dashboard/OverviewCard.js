import React, { useContext } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import moment from 'moment';
import _ from 'lodash';
import { Link } from 'react-router-dom';
import UserContext from '../../contexts/UserContext';
import { DIGITAL_CARD } from '../../utils/statusCredits';
import { formatPoints, isEnableVipTier } from '../../utils/common';
import Icon from '../../components/Icon/Icon';
import WebsiteContext from '../../contexts/WebsiteContext';
import DashboardContext from './DashboardContext';
import ExperienceActivitiesContext from './experienceActivitiesContext';
import A from '../../components/Button/A';
import * as userData from '../../utils/utilities';
import styles from './OverviewCard.css';

function OverviewCard({ scrollToTabs, hidePointsExpiryNotification }) {
  const { user } = useContext(UserContext);
  const websiteData = useContext(WebsiteContext);
  const { getAnalytics } = useContext(DashboardContext);
  const { data: summaryData } = useContext(ExperienceActivitiesContext);
  const ctaContainer = _.get(websiteData, ':items.banner.digitalCard.ctaContainer');
  const vipTierLink = _.get(websiteData, ':items.banner.vipTierAdditionalLink.ctaContainer');
  const isNewVipDesignEnabled = userData.getTierLevel(user) === 'V' && isEnableVipTier();

  function hideReviewDate() {
    const tier = userData.getTierLevel(user);
    const subTier = userData.getSubTierLevel(user);

    return _.includes(['V', 'R'], tier)
      || (tier === 'P' && _.includes(['E', 'G'], subTier))
      || (tier === 'G' && _.includes(['B', 'E', 'G'], subTier));
  }

  return (
    <div className={styles.container}>
      <div className={cx(styles.row, styles.marginBottom)}>
        <div className={styles.left}>
          <span className={cx(styles.title, {
            [styles.vipTierTitle]: isNewVipDesignEnabled,
          })}
          >Points Balance
          </span>
          <Link
            to={websiteData.children.activity.pageUrl}
            className={styles.tileLink}
            analytics-metadata={getAnalytics({
              eventCategory: 'my-activity',
              eventName: 'points-status-interaction',
              eventLocation: 'myvelocity-dashboard',
            }, true)}
            title="Points Balance"
            onClick={scrollToTabs}
          >
            <span className={cx(styles.block, styles.value)}>{formatPoints(userData.getCurrentPointsBalance(user))} {userData.getNearingExpiryDate(user) && !hidePointsExpiryNotification ? <Icon name="clock" /> : null} <Icon name="chevron" size={10} /></span>
          </Link>
        </div>
        <div className={styles.right}>
          <span
            className={cx(styles.subtitle, {
              [styles.vipTierSubTitle]: isNewVipDesignEnabled,
            })}
          >
            This month:
          </span>
          <span className={styles.smallValue}>{summaryData?.included?.summary?.earned} Points earned</span>
          <span className={styles.smallValue}>{summaryData?.included?.summary?.redeemed} Points redeemed</span>
        </div>
      </div>

      <div className={styles.row}>
        <div className={styles.left}>
          <span className={cx(styles.title, {
            [styles.vipTierTitle]: isNewVipDesignEnabled,
          })}
          >Status Credits
          </span>
          <div className={styles.credits}>
            <Link
              to={websiteData.children.status.pageUrl}
              className={styles.tileLink}
              analytics-metadata={getAnalytics({
                eventCategory: 'my-activity',
                eventName: 'points-status-interaction',
                eventLocation: 'myvelocity-dashboard',
              }, true)}
              title="Status Credits Balance"
              onClick={scrollToTabs}
            >
              <span className={styles.value}>{formatPoints(userData.getStatusCreditsBalance(user))} <Icon name="chevron" size={10} /></span>
            </Link>
          </div>
          {
            !hideReviewDate() ? (
              <span className={styles.reviewDate}>
                {userData.getSubTierLevel(user) === 'X' ? 'Resume' : 'Review'} date: {moment(userData.getQualificationPeriodEndDate(user)).format('D MMM YYYY')}
              </span>
            ) : null
          }
          {
            userData.getTierLevel(user) === 'V' && vipTierLink && vipTierLink.ctaLabel && (
            <A
              href={vipTierLink.ctaUrl}
              target={vipTierLink.ctaOpenInNewTab ? '_blank' : '_self'}
              buttonType="white-link"
              title={vipTierLink.ctaTitle}
              ctaAsLink
            >
              {vipTierLink.ctaLabel}
            </A>)
          }
        </div>
        <div className={styles.right}>
          <img
            className={styles.digitalCardIcon}
            src={isNewVipDesignEnabled ? DIGITAL_CARD.BEYOND : DIGITAL_CARD[userData.getTierLevel(user)]}
            alt=""
          />

          {
            ctaContainer && (
              <A
                linkClassName={styles.digitalCardLink}
                buttonType="white-link"
                href={ctaContainer.ctaUrl}
                title={ctaContainer.ctaTitle}
                ctaAsLink
                target={ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
                analytics-metadata={getAnalytics({
                  eventCategory: 'my-activity',
                  eventName: 'points-status-interaction',
                  eventLocation: 'myvelocity-dashboard',
                }, true)}
              >
                <span>{ctaContainer.ctaLabel}</span>
              </A>
            )
          }
        </div>
      </div>
    </div>
  );
}

OverviewCard.propTypes = {
  scrollToTabs: PropTypes.func.isRequired,
  hidePointsExpiryNotification: PropTypes.bool,
};

OverviewCard.defaultProps = {
  hidePointsExpiryNotification: false,
};

export default OverviewCard;
