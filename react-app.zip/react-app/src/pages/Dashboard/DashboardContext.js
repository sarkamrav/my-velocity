import { createContext } from 'react';

export default createContext({
  dashboard: [],
  getAnalytics: () => {},
});
