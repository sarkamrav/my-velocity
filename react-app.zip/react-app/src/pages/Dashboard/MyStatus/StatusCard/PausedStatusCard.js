import React, { useContext } from 'react';
import _ from 'lodash';
import cx from 'classnames';
import moment from 'moment';
import UserContext from '../../../../contexts/UserContext';
import { TIER, TIER_CARD, getTier } from '../../../../utils/statusCredits';
import Circle from '../circle.svg';
import Plane from './plane.svg';
import Paused from './paused.svg';
import status from '../../../../dictionaries/status.json';
import A from '../../../../components/Button/A';
import * as userData from '../../../../utils/utilities';
import statusCardStyles from '../SharedStatusCard.css';
import styles from './StatusCard.css';

export default function PausedStatusCard() {
  const { user } = useContext(UserContext);
  const tierLevel = userData.getTierLevel(user);
  const mainTierInfo = userData.getMainTierInfo(user);

  return (
    <div className={cx(statusCardStyles.card, styles.card, statusCardStyles[_.toLower(TIER[tierLevel])])}>
      <div className={styles.header}>
        <div className={styles.currentTier}>
          <span>Current Status</span>
          <span className={cx(styles.emphasis, `${_.toLower(TIER[tierLevel])}__tier--color`)}>{_.toUpper(getTier(mainTierInfo))}</span>
        </div>
        <A buttonType="black-link" ctaAsLink href="/flying-status/flying-with-status/silver-membership">View Benefits</A>
      </div>
      <div className={styles.content}>
        <div className={styles.progressContainer}>
          <Circle className={cx(styles.progress, 'unknown__tier--fill')} />

          <Plane className={cx(styles.plane, 'unknown__tier--fill')} style={{ transform: 'translateX(-50%) rotate(10deg)' }} />

          <div className={styles.progressContent}>
            <div className={styles.pausedCardContainer}>
              <img src={TIER_CARD[tierLevel]} alt={getTier(mainTierInfo)} className={styles.statusCardImage} />
              <div className={styles.overlay} />
              <Paused className={styles.paused} />
            </div>
            <span className={styles.statusCredits}>Status Paused</span>
            <span className={styles.statusCreditsToUpgrade}>{status.pausedMessage}</span>
          </div>
        </div>
      </div>

      <div className={styles.informationContainer}>
        <span>{status.pausedStatusMessage}</span>
        <span className={styles.expiry}>{moment(userData.getQualificationPeriodEndDate(user)).format('DD MMM YYYY')}</span>
      </div>

      <div className={styles.learnMoreContainer}>
        <A href={status.howStatusReviewWorksLink} buttonType="black-link" ctaAsLink>{status.howStatusReviewWorksLabel}</A>
      </div>
    </div>
  );
}
