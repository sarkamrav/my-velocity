import React, { useContext } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import moment from 'moment';
import cx from 'classnames';
import status from '../../../../dictionaries/status.json';
import { getTier, TIER, TIER_CARD } from '../../../../utils/statusCredits';
import UserContext from '../../../../contexts/UserContext';
import Loading from '../../../../components/Loading/Loading';
import Modal from '../../../../components/Modal/Modal';
import Table from '../../../../components/Table/Table';
import * as userData from '../../../../utils/utilities';
import styles from './UpgradeTable.css';

function UpgradeTable({
  onDismiss, upgradeInfo, loading,
}) {
  const { user } = useContext(UserContext);

  const firstUpgrade = _.first(upgradeInfo);
  const upgradeTierInfo = userData.getUpgradeTierInfo(user);
  const upgradeTierInfoLevel = userData.getUpgradeTierInfoLevel(user);

  return (
    <Modal onDismiss={onDismiss} aria-label="Upgrade table">
      <div className={styles.header}>
        <span className={styles.upgradeTo}>UPGRADE TO</span>
        <span className={cx(styles.tier, [`${TIER[upgradeTierInfoLevel].toLowerCase()}__tier--color`])}>{_.toUpper(getTier(upgradeTierInfo))} <img src={TIER_CARD[upgradeTierInfoLevel]} alt={getTier(upgradeTierInfo)} className={styles.tierCard} /></span>
      </div>

      {
        loading ? <Loading /> : (
          <div className={styles.container}>
            <div className={styles.information}>
              <span className={styles.subtitle}>YOUR NEXT UPGRADE OPPORTUNITY</span>
              <span className="font-size font-size--large">Earn {firstUpgrade?.creditToUpgrade} Status Credits in the 12 months prior to {moment(firstUpgrade?.activityDate).format('DD MMM YYYY')} to upgrade to {getTier(upgradeTierInfo)}^.</span>
            </div>

            <div className={styles.content}>
              <span className={styles.contentTitle}>{status.upgradeTable.futureTitle}</span>
              <p className="font-size font-size--large">{status.upgradeTable.futureText}</p>

              <Table
                headers={status.upgradeTable.headers}
                rows={_.map(upgradeInfo, (upgrade, id) => ({
                  uniqueId: id,
                  [status.upgradeTable.headers[0]]: moment(upgrade.activityDate).format('DD MMM YYYY'),
                  [status.upgradeTable.headers[1]]: upgrade.creditBalance,
                  [status.upgradeTable.headers[2]]: upgrade.creditToUpgrade,
                }))}
              />

              <div className={styles.footer}>
                {
                  _.map(status.upgradeTable.footers, footer => (
                    <span key={footer}>{footer}</span>
                  ))
                }
              </div>
            </div>
          </div>
        )
      }
    </Modal>
  );
}

UpgradeTable.propTypes = {
  onDismiss: PropTypes.func.isRequired,
  upgradeInfo: PropTypes.shape().isRequired,
  loading: PropTypes.bool.isRequired,
};

export default UpgradeTable;
