import React, { useContext } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import cx from 'classnames';
import moment from 'moment';
import UserContext from '../../../../contexts/UserContext';
import Icon from '../../../../components/Icon/Icon';
import { TIER, TIER_CARD, getTier } from '../../../../utils/statusCredits';
import Circle from '../circle.svg';
import SolidProgress from './solid-progress.svg';
import Plane from './plane.svg';
import Tick from './tick.svg';
import RichTextContent from '../../../../components/RichTextContent/RichTextContent';
import CountdownTimer from './CountdownTimer';
import status from '../../../../dictionaries/status.json';
import Tooltip from '../../../../components/Tooltip/Tooltip';
import A from '../../../../components/Button/A';
import analytics from '../../../../utils/analytics';
import DashboardContext from '../../DashboardContext';
import WebsiteContext from '../../../../contexts/WebsiteContext';
import * as userData from '../../../../utils/utilities';
import statusCardStyles from '../SharedStatusCard.css';
import styles from './StatusCard.css';

function MaintainStatusCard({
  panel,
}) {
  const { user } = useContext(UserContext);
  const { getAnalytics } = useContext(DashboardContext);
  const websiteData = useContext(WebsiteContext);

  const progressRadius = 50;
  const monthRadius = 48;
  const tierLevel = userData.getTierLevel(user);
  const mainTierInfo = userData.getMainTierInfo(user);
  const qualificationPeriodStatusCreditsBalance = userData.getQualificationPeriodStatusCreditsBalance(user);
  const downgradeTierCreditsRequired = userData.getDowngradeTierCreditsRequired(user);
  const downgradeTierSectorsRequired = userData.getDowngradeTierSectorsRequired(user);
  const qualificationPeriodEligibleSectorsBalance = userData.getQualificationPeriodEligibleSectorsBalance(user);

  const percentageThrough = _.min([qualificationPeriodStatusCreditsBalance / downgradeTierCreditsRequired, 1]);
  const rotateDeg = _.clamp(360 * percentageThrough, 10, 350);
  const totalProgressPathLength = progressRadius * 2 * Math.PI;
  const travelProgressDistance = _.clamp(totalProgressPathLength * percentageThrough, 10, 305);

  // `reviewPeriodMonths` should be calculated dynamically using the qualification start and end date and rounded off to the nearest value
  const startDate = userData.getQualificationPeriodStartDate(user);
  const endDate = userData.getQualificationPeriodEndDate(user);
  const reviewPeriodMonths = Math.round(moment(endDate).diff(startDate, 'days') / 30);
  const reviewDate = moment(endDate);
  const lastReviewDate = startDate;
  const daysInPeriod = moment(reviewDate).diff(lastReviewDate, 'day');
  const daysPassed = moment().diff(lastReviewDate, 'day');
  const daysPercentage = Math.min((daysPassed / daysInPeriod), 1);

  const totalMonthPathLength = monthRadius * 2 * Math.PI;
  const travelMonthDistance = totalMonthPathLength * daysPercentage;
  const hideCountdown = _.get(websiteData, 'children.status.:items.maintainStatusCard.hideCountdown', false);

  const today = moment().startOf('day');
  const maintained = panel.state === 'Maintained';

  const withinPeriod = _.includes(['Trial Gold', 'Pilot Gold', 'Explore Gold', 'Discover Gold'], getTier(mainTierInfo)) ? 1 : 3;
  const showCountdown = panel.state === 'Countdown' && today > moment(reviewDate).subtract(withinPeriod, 'months').subtract(1, 'days').startOf('day') && today < reviewDate;
  const creditsMaintained = qualificationPeriodStatusCreditsBalance >= downgradeTierCreditsRequired;

  function getLabelForNewExtensionTiers(tierInfo = {}) {
    return (tierInfo.tierLevel === 'S' && tierInfo.tierType === 'H' && 'Extension - Silver')
      || (tierInfo.tierLevel === 'G' && tierInfo.tierType === 'H' && 'Extension - Gold')
      || (tierInfo.tierLevel === 'P' && tierInfo.tierType === 'H' && 'Extension - Platinum');
  }

  const labelForNewExtensionTier = getLabelForNewExtensionTiers(mainTierInfo);

  return (
    <div className={cx(statusCardStyles.card, styles.card, statusCardStyles[_.toLower(TIER[tierLevel])])}>
      <div className={styles.header}>
        <div className={styles.currentTier}>
          <span>Current Status</span>
          <span className={cx(styles.emphasis, `${_.toLower(TIER[tierLevel])}__tier--color`)}>
            { _.toUpper(labelForNewExtensionTier || getTier(mainTierInfo))}
          </span>
        </div>
        <A buttonType="black-link" ctaAsLink href={status[`benefitsLink${_.replace(getTier(mainTierInfo), ' ', '')}`]}>View Benefits</A>
      </div>
      <div className={styles.content}>
        <div className={styles.progressContainer}>
          <svg viewBox="-5 -5 120 120" className={styles.monthProgress}>
            <circle cx="55" cy="55" r="48" fill="transparent" strokeWidth="4" stroke="#ece0ff" strokeLinecap="butt" style={{ strokeDasharray: `${totalProgressPathLength}px`, strokeDashoffset: `${totalMonthPathLength - travelMonthDistance + 11.5}px` }} />
            <circle cx="55" cy="55" r="48" fill="transparent" strokeWidth="6" strokeDashoffset="0" stroke="#fff" style={{ strokeDasharray: `1, ${((totalMonthPathLength / reviewPeriodMonths) - 1)}px` }} />
          </svg>

          <Circle className={styles.progress} />

          <SolidProgress
            className={cx(
              styles.solidProgress,
              `${creditsMaintained ? 'unknown' : _.toLower(TIER[tierLevel])}__tier--stroke`,
              `${creditsMaintained ? 'unknown' : _.toLower(TIER[tierLevel])}__tier--fill`,
            )}
            style={{
              strokeDasharray: `${totalProgressPathLength}px`,
              strokeDashoffset: `${_.clamp((totalProgressPathLength - travelProgressDistance) + 10, 10, 350)}px`,
            }}
          />

          <Plane className={cx(styles.plane, `${creditsMaintained ? 'unknown' : _.toLower(TIER[tierLevel])}__tier--fill`)} style={{ transform: `translateX(-50%) rotate(${rotateDeg}deg)` }} />

          <div className={styles.progressContent}>
            <div className={styles.pausedCardContainer}>
              <img src={TIER_CARD[tierLevel]} alt={getTier(mainTierInfo)} className={styles.statusCardImage} />
              {
                creditsMaintained ? (
                  <>
                    <div className={styles.overlay} />
                    <Tick className={styles.paused} />
                  </>
                ) : null
              }
            </div>
            <span className={styles.statusCredits}>{_.min([qualificationPeriodStatusCreditsBalance, downgradeTierCreditsRequired])} of {downgradeTierCreditsRequired}</span>
            <span className={styles.statusCreditsToUpgrade}>{!creditsMaintained ? status.creditsToMaintainLabel : status.maintainedStatusCredits}</span>
            <Tooltip
              onAnalytics={params => analytics.send(getAnalytics({
                eventCategory: 'status-activity',
                eventName: 'tooltip-interaction',
                eventLocation: 'status-activity-dashboard',
                statusPanelType: panel.panelType,
                statusTileCategory: panel.category,
                statusTileState: panel.state,
                statusTierInfo: panel.tierInfo,
                ...params,
              }))}
            >
              {
                _.map(status.toolTipsMaintain, (tooltip, i) => (
                  <RichTextContent key={i} content={tooltip} className={styles.tooltip} />
                ))
              }
            </Tooltip>
          </div>
        </div>
        <span className={styles.sectors}>
          {
            qualificationPeriodEligibleSectorsBalance >= downgradeTierSectorsRequired ? (
              <Icon name="tickCircleSolid" size={18} className={styles.success} />
            ) : null
          }
          {_.min([qualificationPeriodEligibleSectorsBalance, downgradeTierSectorsRequired])} of {downgradeTierSectorsRequired}
        </span>
        <span>{!maintained ? status.eligibleSectorsToMaintainLabel : status.maintainedEligibleSectors}</span>
      </div>
      <div className={styles.informationContainer}>
        {
          showCountdown && hideCountdown && (
            <>
              <span>{status.yourReviewDateLabel}</span>
              <span className={styles.expiry}>{reviewDate.format('DD MMM YYYY')}</span>
            </>
          )
        }

        {
          showCountdown && !hideCountdown && (
            <>
              <span>{status.riskLosingStatusLabel}</span>
              <CountdownTimer date={reviewDate} />
            </>
          )
        }

        {
          !showCountdown && (
            <>
              <span>{!maintained ? status.yourReviewDateLabel : status.maintainedReviewDateTitle}</span>
              {maintained ? <span className={styles.expiry}>You will maintain {TIER[tierLevel]} Status</span> : null}
              {maintained ? <span>{status.yourReviewDateLabel} {reviewDate.format('DD MMM YYYY')}</span> : <span className={styles.expiry}>{reviewDate.format('DD MMM YYYY')}</span>}
            </>
          )
        }
      </div>
      <div className={styles.learnMoreContainer}>
        <A buttonType="black-link" ctaAsLink href={status.howStatusReviewWorksLink}>{status.howStatusReviewWorksLabel}</A>
      </div>
    </div>
  );
}

MaintainStatusCard.propTypes = {
  panel: PropTypes.shape().isRequired,
};

export default MaintainStatusCard;
