import React from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';
import _ from 'lodash';
import styles from './CountdownTimer.css';

function CountdownTimer({
  date,
}) {
  const diffTime = moment(date).endOf('day').unix() - moment().unix();
  const diffReviewDate = moment.duration(diffTime * 1000, 'milliseconds');

  return (
    <div className={styles.countdown}>
      <div className={styles.column}>
        <div className={styles.date}>
          {
            _.map(_.padStart(moment.duration(diffReviewDate).months().toString(), 2, '0'), (digit, i) => (
              <span key={i} className={styles.digit}>{digit}</span>
            ))
          }
        </div>
        <span className={styles.label}>MONTHS</span>
      </div>
      <div className={styles.separator} />
      <div className={styles.column}>
        <div className={styles.date}>
          {
            _.map(_.padStart(moment.duration(diffReviewDate).days().toString(), 2, '0'), (digit, i) => (
              <span key={i} className={styles.digit}>{digit}</span>
            ))
          }
        </div>
        <span className={styles.label}>DAYS</span>
      </div>
      <div className={styles.separator} />
      <div className={styles.column}>
        <div className={styles.date}>
          {
            _.map(_.padStart(moment.duration(diffReviewDate).hours().toString(), 2, '0'), (digit, i) => (
              <span key={i} className={styles.digit}>{digit}</span>
            ))
          }
        </div>
        <span className={styles.label}>HOURS</span>
      </div>
    </div>
  );
}

CountdownTimer.propTypes = {
  date: PropTypes.string.isRequired,
};

export default CountdownTimer;
