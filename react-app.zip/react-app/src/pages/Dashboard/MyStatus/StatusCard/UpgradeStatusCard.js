import React, { useContext, useState } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import cx from 'classnames';
import moment from 'moment';
import UserContext from '../../../../contexts/UserContext';
import Icon from '../../../../components/Icon/Icon';
import { TIER, TIER_CARD, getTier } from '../../../../utils/statusCredits';
import Circle from '../circle.svg';
import Plane from './plane.svg';
import RichTextContent from '../../../../components/RichTextContent/RichTextContent';
import status from '../../../../dictionaries/status.json';
import Tooltip from '../../../../components/Tooltip/Tooltip';
import Tick from './tick.svg';
import { useApi } from '../../../../utils/api';
import Loading from '../../../../components/Loading/Loading';
import UpgradeTable from './UpgradeTable';
import A from '../../../../components/Button/A';
import analytics from '../../../../utils/analytics';
import DashboardContext from '../../DashboardContext';
import * as userData from '../../../../utils/utilities';
import statusCardStyles from '../SharedStatusCard.css';
import styles from './StatusCard.css';

function UpgradeStatusCard({
  panel,
}) {
  const { user } = useContext(UserContext);
  const { getAnalytics } = useContext(DashboardContext);

  const [showUpgrade, setShowUpgrade] = useState(false);
  const statusCreditsBalance = userData.getStatusCreditsBalance(user);
  const upgradeTierCreditsRequired = userData.getUpgradeTierCreditsRequired(user);
  const upgradeTierInfoLevel = userData.getUpgradeTierInfoLevel(user);
  const upgradeTierSectorsRequired = userData.getUpgradeTierSectorsRequired(user);
  const upgradeTierInfo = userData.getUpgradeTierInfo(user);
  const eligibleSectorsBalance = userData.getEligibleSectorsBalance(user);

  const maintained = eligibleSectorsBalance >= upgradeTierSectorsRequired && statusCreditsBalance >= upgradeTierCreditsRequired;

  const { data, loading } = useApi('/loyalty/v2/activities/tier-upgrade', {
    endpoint: 'vffV2Api',
  });

  const tierUpgradeData = _.get(data, 'data');
  const progressRadius = 50;

  const percentageThrough = statusCreditsBalance / upgradeTierCreditsRequired;
  const rotateDeg = _.clamp(360 * percentageThrough, 10, 350);
  const totalProgressPathLength = progressRadius * 2 * Math.PI;
  const travelProgressDistance = _.clamp(totalProgressPathLength * percentageThrough, 10, 300);

  function renderFirstUpgrade() {
    if (loading) return <Loading containerClassName={styles.loadingContainer} className={styles.loading} />;

    const firstUpgrade = _.first(tierUpgradeData);
    const secondUpgrade = _.nth(tierUpgradeData, 1) || { creditBalance: 0 };
    if (!firstUpgrade) return null;

    return (
      <>
        <span>{status.nextStatusCreditsExpireLabel}</span>
        <span className={styles.expiry}>{moment(firstUpgrade.activityDate).format('DD MMM YYYY')} ({firstUpgrade.creditBalance - secondUpgrade.creditBalance} Status Credits)</span>
      </>
    );
  }

  const creditsMaintained = statusCreditsBalance >= upgradeTierCreditsRequired;

  return (
    <div className={cx(statusCardStyles.card, styles.card, statusCardStyles[_.toLower(TIER[upgradeTierInfoLevel])])}>
      <div className={styles.header}>
        <div className={styles.currentTier}>
          <span>Next Status</span>
          <span className={cx(styles.emphasis, `${_.toLower(TIER[upgradeTierInfoLevel])}__tier--color`)}>{_.toUpper(getTier(upgradeTierInfo))}</span>
        </div>
        <A buttonType="black-link" ctaAsLink href={status[`benefitsLink${_.replace(getTier(upgradeTierInfo), ' ', '')}`]}>View Benefits</A>
      </div>

      <div className={styles.content}>
        <div className={styles.progressContainer}>
          <Circle
            className={cx(styles.progress, `${creditsMaintained ? 'unknown' : _.toLower(TIER[upgradeTierInfoLevel])}__tier--fill`)}
          />

          <svg
            viewBox="-5 -5 120 120"
            className={cx(styles.travelledProgress, `${creditsMaintained ? 'unknown' : _.toLower(TIER[upgradeTierInfoLevel])}__tier--stroke`)}
          >
            <defs>
              <mask id="path-mask">
                <circle cx="55" cy="55" r="50" fill="transparent" strokeWidth="3" stroke="#fff" strokeDashoffset="0" style={{ strokeDasharray: `${totalProgressPathLength}px`, strokeDashoffset: `${totalProgressPathLength - travelProgressDistance}px` }} />
              </mask>
            </defs>
            <path mask="url(#path-mask)" d="M5,55a50,50 0 1,0 100,0a50,50 0 1,0 -100,0" fill="transparent" strokeWidth="1" strokeLinecap="round" strokeDasharray="0, 4.3" />
          </svg>

          <Plane
            className={cx(styles.plane, `${creditsMaintained ? 'unknown' : _.toLower(TIER[upgradeTierInfoLevel])}__tier--fill`)}
            style={{ transform: `translateX(-50%) rotate(${rotateDeg}deg)` }}
          />

          <div className={styles.progressContent}>
            <div className={styles.pausedCardContainer}>
              <img src={TIER_CARD[upgradeTierInfoLevel]} alt={getTier(upgradeTierInfo)} className={styles.statusCardImage} />
              {
                creditsMaintained ? (
                  <>
                    <div className={styles.overlay} />
                    <Tick className={styles.paused} />
                  </>
                ) : null
              }
            </div>
            <span className={styles.statusCredits}>{statusCreditsBalance} of {upgradeTierCreditsRequired}</span>
            <span className={styles.statusCreditsToUpgrade}>{status.creditsToUpgradeLabel}</span>
            <Tooltip
              onAnalytics={params => analytics.send(getAnalytics({
                eventCategory: 'status-activity',
                eventName: 'tooltip-interaction',
                eventLocation: 'status-activity-dashboard',
                statusPanelType: panel.panelType,
                statusTileCategory: panel.category,
                statusTileState: panel.state,
                statusTierInfo: panel.tierInfo,
                ...params,
              }))}
            >
              {
                _.map(status.toolTipsUpgrade, (tooltip, i) => (
                  <RichTextContent key={i} content={tooltip} className={styles.tooltip} />
                ))
              }
            </Tooltip>
          </div>
        </div>

        <span className={styles.sectors}>
          {
            eligibleSectorsBalance >= upgradeTierSectorsRequired ? (
              <Icon name="tickCircleSolid" size={18} className={styles.success} />
            ) : null
          }
          {eligibleSectorsBalance} of {upgradeTierSectorsRequired}
        </span>
        <span>{status.eligibleSectorsToUpgradeLabel}</span>
      </div>

      <div className={styles.informationContainer}>
        {
          maintained ? (
            <>
              <span>{status.maintainedReviewDateTitle}</span>
              <span className={styles.expiry}>You will upgrade to {TIER[upgradeTierInfoLevel]} Status</span>
            </>
          ) : (
            <>
              {renderFirstUpgrade()}
              <span>{status.expirationsOccurLabel}</span>
            </>
          )
        }
      </div>
      <div className={styles.learnMoreContainer}>
        {
          statusCreditsBalance > 0 && statusCreditsBalance < upgradeTierCreditsRequired ? <A buttonType="black-link" ctaAsLink className={styles.learnMore} onClick={() => setShowUpgrade(true)}>{status.yourStatusExpirationsLabel}</A> : null
        }
        {
          showUpgrade ? <UpgradeTable onDismiss={() => setShowUpgrade(false)} upgradeInfo={tierUpgradeData} loading={loading} /> : null
        }
      </div>
    </div>
  );
}

UpgradeStatusCard.propTypes = {
  panel: PropTypes.shape().isRequired,
};

export default UpgradeStatusCard;
