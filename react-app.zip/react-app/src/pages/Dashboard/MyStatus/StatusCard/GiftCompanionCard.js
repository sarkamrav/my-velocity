import React, { useContext } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import cx from 'classnames';
import moment from 'moment';
import UserContext from '../../../../contexts/UserContext';
import { TIER, getNextGift } from '../../../../utils/statusCredits';
import Circle from '../circle.svg';
import Plane from './plane.svg';
import SolidProgress from './solid-progress.svg';
import status from '../../../../dictionaries/status.json';
import RichTextContent from '../../../../components/RichTextContent/RichTextContent';
import Tooltip from '../../../../components/Tooltip/Tooltip';
import A from '../../../../components/Button/A';
import analytics from '../../../../utils/analytics';
import DashboardContext from '../../DashboardContext';
import * as userData from '../../../../utils/utilities';
import statusCardStyles from '../SharedStatusCard.css';
import styles from './StatusCard.css';

function GiftCompanionCard({
  panel,
}) {
  const { user } = useContext(UserContext);
  const { getAnalytics } = useContext(DashboardContext);
  const qualificationPeriodStatusCreditsBalance = userData.getQualificationPeriodStatusCreditsBalance(user);
  const tierLevel = userData.getTierLevel(user);
  const qualificationPeriodEndDate = userData.getQualificationPeriodEndDate(user);

  const nextGift = getNextGift(qualificationPeriodStatusCreditsBalance);

  const progressRadius = 50;
  const monthRadius = 48;

  const percentageThrough = _.min([qualificationPeriodStatusCreditsBalance, nextGift.requiredStatusCredits]) / nextGift.requiredStatusCredits;
  const rotateDeg = _.clamp(360 * percentageThrough, 10, 350);

  const totalProgressPathLength = progressRadius * 2 * Math.PI;
  const travelProgressDistance = _.clamp(totalProgressPathLength * percentageThrough, 10, 305);

  const reviewDate = moment(qualificationPeriodEndDate);
  const reviewDateText = reviewDate.format('DD MMM YYYY');
  const lastReviewDate = userData.getQualificationPeriodStartDate(user);
  const daysInPeriod = moment(reviewDate).diff(lastReviewDate, 'day');
  const daysPassed = moment().diff(lastReviewDate, 'day');
  const daysPercentage = Math.min((daysPassed / daysInPeriod), 1);

  const totalMonthPathLength = monthRadius * 2 * Math.PI;
  const travelMonthDistance = totalMonthPathLength * daysPercentage;

  return (
    <div className={cx(statusCardStyles.card, styles.card, statusCardStyles[_.toLower(TIER[tierLevel])])}>
      <div className={styles.header}>
        <div className={styles.currentTier}>
          <span>Next Goal</span>
          <span className={cx(styles.emphasis, `${_.toLower(TIER[tierLevel])}__tier--color`)}>GIFT STATUS</span>
        </div>
      </div>
      <div className={styles.content}>
        <div className={styles.progressContainer}>
          <svg viewBox="-5 -5 120 120" className={styles.monthProgress}>
            <circle cx="55" cy="55" r="48" fill="transparent" strokeWidth="4" stroke="#ece0ff" strokeLinecap="butt" style={{ strokeDasharray: `${totalProgressPathLength}px`, strokeDashoffset: `${totalMonthPathLength - travelMonthDistance + 11.5}px` }} />
            <circle cx="55" cy="55" r="48" fill="transparent" strokeWidth="6" strokeDashoffset="0" stroke="#fff" style={{ strokeDasharray: `1, ${((totalMonthPathLength / 12) - 1)}px` }} />
          </svg>

          <Circle className={cx(styles.progress, `${_.toLower(TIER[tierLevel])}__tier--fill`)} />

          <SolidProgress
            className={cx(styles.solidProgress, `${_.toLower(TIER[tierLevel])}__tier--stroke`, `${_.toLower(TIER[tierLevel])}__tier--fill`)}
            style={{
              strokeDasharray: `${totalProgressPathLength}px`,
              strokeDashoffset: `${_.clamp((totalProgressPathLength - travelProgressDistance) + 10, 10, 350)}px`,
            }}
          />

          <Plane className={cx(styles.plane, `${_.toLower(TIER[tierLevel])}__tier--fill`)} style={{ transform: `translateX(-50%) rotate(${rotateDeg}deg)` }} />

          <div className={styles.progressContent}>
            <img src={nextGift.image} alt={`Gift ${nextGift.tier}`} className={styles.statusCardImage} />
            <span className={styles.statusCredits}>{_.min([qualificationPeriodStatusCreditsBalance, nextGift.requiredStatusCredits])} of {nextGift.requiredStatusCredits}</span>
            <span className={styles.statusCreditsToUpgrade}>Status Credits to gift {nextGift.tier}</span>
            <Tooltip
              onAnalytics={params => analytics.send(getAnalytics({
                eventCategory: 'status-activity',
                eventName: 'tooltip-interaction',
                eventLocation: 'status-activity-dashboard',
                statusPanelType: panel.panelType,
                statusTileCategory: panel.category,
                statusTileState: panel.state,
                statusTierInfo: panel.tierInfo,
                ...params,
              }))}
            >
              {
                _.map(!nextGift.priorGift ? status.toolTipsCompanionGold : status.toolTipsCompanionPlatinum, (tooltip, i) => (
                  <RichTextContent key={i} content={tooltip} className={styles.tooltip} />
                ))
              }
            </Tooltip>
          </div>
        </div>
        {
          nextGift.priorGift ? (
            <A href={status.companionGiftCtaLink} linkClassName={styles.giftLink} buttonType="black-link" ctaAsLink>
              <img src={nextGift.achieved ? nextGift.image : nextGift.priorGift.image} alt={`Gift ${nextGift.achieved ? nextGift.tier : nextGift.priorGift.tier}`} className={styles.giftImage} />
              <span className={styles.giftDescription}>You may be able to gift {nextGift.achieved ? nextGift.tier : nextGift.priorGift.tier}</span>
            </A>
          ) : null
        }
      </div>
      <div className={styles.informationContainer}>
        {
          nextGift.achieved ? (
            <>
              <span>{status.yourReviewDateLabel}</span>
              <span className={styles.expiry}>{reviewDateText}</span>
            </>
          ) : (
            <>
              <span>Earn {nextGift.requiredStatusCredits} Status Credits by</span>
              <span className={styles.expiry}>{reviewDateText}</span>
              <span>to gift {nextGift.tier} Status</span>
            </>
          )
        }
      </div>
      <div className={styles.learnMoreContainer}>
        <A href={status.learnMoreAboutGiftingStatusLink} buttonType="black-link" ctaAsLink>
          {status.learnMoreAboutGiftingStatusLabel}
        </A>
      </div>
    </div>
  );
}

GiftCompanionCard.propTypes = {
  panel: PropTypes.shape().isRequired,
};

export default GiftCompanionCard;
