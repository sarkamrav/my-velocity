import React, { useEffect } from 'react';
import PropTypes from 'prop-types';

function CoreRichTextContent({ jsObjectKey }) {
  useEffect(() => {
    if (jsObjectKey) {
      window.bootstrapComponent('aem-rich-text', jsObjectKey);
    }
  }, [jsObjectKey]);

  return (
    jsObjectKey && <div aem-rich-text={jsObjectKey} />
  );
}

CoreRichTextContent.propTypes = {
  jsObjectKey: PropTypes.string,
};

CoreRichTextContent.defaultProps = {
  jsObjectKey: '',
};

export default CoreRichTextContent;
