import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { CORE_COMPONENT_NAME } from '../../../../utils/common';

function CoreAccordionComparison({ jsObjectKey }) {
  useEffect(() => {
    if (jsObjectKey) {
      window.bootstrapComponent(CORE_COMPONENT_NAME.accordionComparison, jsObjectKey);
    }
  }, [jsObjectKey]);

  return (
    jsObjectKey && <div aem-accordion_comparison={jsObjectKey} />
  );
}

CoreAccordionComparison.propTypes = {
  jsObjectKey: PropTypes.string,
};

CoreAccordionComparison.defaultProps = {
  jsObjectKey: '',
};

export default CoreAccordionComparison;
