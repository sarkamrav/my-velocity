import React, { useContext, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';

import status from '../../../../dictionaries/status.json';
import { TIER } from '../../../../utils/statusCredits';
import EducationCard from '../EducationCard/EducationCard';
import ReviewStatusCard from '../ReviewStatusCard/ReviewStatusCard';
import BenefitStatusCard from '../BenefitStatusCard/BenefitStatusCard';
import UpgradeStatusCard from '../StatusCard/UpgradeStatusCard';
import PausedStatusCard from '../StatusCard/PausedStatusCard';
import GiftCompanionCard from '../StatusCard/GiftCompanionCard';
import MaintainStatusCard from '../StatusCard/MaintainStatusCard';
import UserContext from '../../../../contexts/UserContext';

import WebsiteContext from '../../../../contexts/WebsiteContext';
import { getTarget } from '../../../../utils/target';
import DoNotDownGradeCard from './DoNotDownGradeCard/DoNotDownGradeCard';
import * as userData from '../../../../utils/utilities';

import styles from './TargetedReviewForDoNotDownGrade.css';

function TargetedReviewForDoNotDownGrade({ panel, analyticsMetadata }) {
  const { user } = useContext(UserContext);
  const websiteData = useContext(WebsiteContext);
  const [targetActivity, setTargetActivity] = useState(null);
  const [isTargetActivityLoading, setIsTargetActivityLoading] = useState(true);

  const statusTipsBenefitsTile = _.get(websiteData, 'children.status.:items.statusTipsBenefitsTile', {});
  const upgradeTierInfoLevel = userData.getUpgradeTierInfoLevel(user);
  const tierLevel = userData.getTierLevel(user);

  function renderTile(tilePanel) {
    if (tilePanel.category === 'General') {
      switch (tilePanel.state) {
        case 'Error':
          break;
        case 'Education':
          return <EducationCard />;
        case 'Review':
          return <ReviewStatusCard />;
        case 'Welcome':
          break;
        case 'Benefit':
          return <BenefitStatusCard />;
        default:
          break;
      }
    } else if (tilePanel.category === 'Upgrade') {
      return <UpgradeStatusCard panel={tilePanel} />;
    } else if (tilePanel.category === 'Maintain' && tilePanel.state === 'Paused') {
      return <PausedStatusCard />;
    } else if (tilePanel.category === 'Companion') {
      return <GiftCompanionCard panel={tilePanel} />;
    }

    return <MaintainStatusCard panel={tilePanel} />;
  }

  function getTitle(tilePanel) {
    if (tilePanel.category === 'General') {
      switch (tilePanel.state) {
        case 'Education':
          return status.educationStatusHeading;
        case 'Review':
          return status.reviewStatusTitle;
        case 'Benefit':
          return status.benefitsHeading;
        default:
          return '';
      }
    } else if (tilePanel.category === 'Maintain') {
      switch (tilePanel.state) {
        case 'Paused':
          return status.pausedStatusTitle;
        case 'Maintained':
          return `You will maintain ${TIER[tierLevel]} Status`;
        default:
          return `Maintain ${TIER[tierLevel]} Status`;
      }
    } else if (tilePanel.category === 'Status') {
      switch (tilePanel.state) {
        default:
          return `Upgrade to ${TIER[upgradeTierInfoLevel]} Status`;
      }
    } else if (tilePanel.category === 'Upgrade') {
      // Upgrade title
      return `Upgrade to ${TIER[upgradeTierInfoLevel]} Status`;
    } else if (tilePanel.category === 'Companion') {
      return status.companionTitle;
    }

    return '';
  }

  async function loadMbox() {
    const targetedActivity = await getTarget(statusTipsBenefitsTile.mboxLocation);

    if (targetedActivity) {
      setTargetActivity(targetedActivity);
    }
    setIsTargetActivityLoading(false);
  }

  useEffect(() => {
    if (statusTipsBenefitsTile.mboxLocation
      && panel.category === 'General'
      && panel.state === 'Review') {
      loadMbox();
    } else {
      setIsTargetActivityLoading(false);
    }
  }, []);

  return (
    <div className={styles.container} analytics-metadata={analyticsMetadata}>
      {
        isTargetActivityLoading && null
      }

      {
        !isTargetActivityLoading && !targetActivity && (
          <>
            <span className={styles.label}>{getTitle(panel)}</span>
            { renderTile(panel) }
          </>
        )
      }

      {
        !isTargetActivityLoading && targetActivity && (
          <>
            <span className={styles.label}>{statusTipsBenefitsTile.title}</span>
            <DoNotDownGradeCard {...targetActivity} />
          </>
        )
      }
    </div>
  );
}

TargetedReviewForDoNotDownGrade.propTypes = {
  panel: PropTypes.shape({
    category: PropTypes.string,
    state: PropTypes.string,
  }),
  analyticsMetadata: PropTypes.string,
};

TargetedReviewForDoNotDownGrade.defaultProps = {
  panel: null,
  analyticsMetadata: null,
};

export default TargetedReviewForDoNotDownGrade;
