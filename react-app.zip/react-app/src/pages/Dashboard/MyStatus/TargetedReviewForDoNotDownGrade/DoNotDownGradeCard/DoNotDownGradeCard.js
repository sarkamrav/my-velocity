import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import _ from 'lodash';

import RichTextContent from '../../../../../components/RichTextContent/RichTextContent';
import A from '../../../../../components/Button/A';

import statusCardStyles from '../../SharedStatusCard.css';
import styles from './DoNotDownGradeCard.css';

function DoNotDownGradeCard({
  title,
  description,
  imageAlt,
  ctaContainer,
  renditions,
}) {
  const image = _.get(renditions, 'imagesSet.720', null);
  return (
    <div className={cx(statusCardStyles.card, styles.container)}>
      {
        image && (
          <div className={styles.imageContainer}>
            <img src={image} alt={imageAlt} />
          </div>
        )
      }

      {
        title && <h5 className={styles.title}>{title}</h5>
      }

      {
        description && <RichTextContent content={description} />
      }

      {
        !_.isEmpty(ctaContainer) && (
          <A buttonType="primary-transparent" className={styles.cta} href={ctaContainer.ctaUrl}>{ctaContainer.ctaLabel}</A>
        )
      }
    </div>
  );
}

DoNotDownGradeCard.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
  imageAlt: PropTypes.string,
  ctaContainer: PropTypes.shape({
    ctaUrl: PropTypes.string,
    ctaLabel: PropTypes.string,
  }),
  renditions: PropTypes.shape({}),
};

DoNotDownGradeCard.defaultProps = {
  title: null,
  description: null,
  imageAlt: null,
  ctaContainer: null,
  renditions: null,
};

export default DoNotDownGradeCard;
