import React, { useEffect } from 'react';
import PropTypes from 'prop-types';

function CoreStripBanner(props) {
  const { jsObjectKey } = props;
  useEffect(() => {
    window.vffCoreWebsite = {
      ...window.vffCoreWebsite,
      [jsObjectKey]: {
        ...props,
      },
    };

    if (jsObjectKey) {
      window.bootstrapComponent('aem-strip-banner', jsObjectKey, true);
    }
  }, [jsObjectKey]);

  return (
    jsObjectKey && <div aem-strip-banner={jsObjectKey} />
  );
}

CoreStripBanner.propTypes = {
  jsObjectKey: PropTypes.string,
};

CoreStripBanner.defaultProps = {
  jsObjectKey: '',
};

export default CoreStripBanner;
