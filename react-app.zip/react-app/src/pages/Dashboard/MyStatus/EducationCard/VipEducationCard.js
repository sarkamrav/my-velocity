import React, { useContext } from 'react';
import cx from 'classnames';
import _ from 'lodash';
import A from '../../../../components/Button/A';
import RichTextContent from '../../../../components/RichTextContent/RichTextContent';
import Plane from '../plane.svg';
import UserContext from '../../../../contexts/UserContext';
import { TIER } from '../../../../utils/statusCredits';
import status from '../../../../dictionaries/status.json';
import * as userData from '../../../../utils/utilities';
import statusCardStyles from '../SharedStatusCard.css';
import styles from './EducationCard.css';

export default function VipEducationCard() {
  const { user } = useContext(UserContext);

  return (
    <div className={cx(statusCardStyles.card, styles.card, statusCardStyles.vip, styles.vip)}>
      <div className={cx(styles.imageContainer, `${_.toLower(TIER[userData.getTierLevel(user)])}__tier--bg-rgba`)}>
        <Plane className={cx(styles.image, `${_.toLower(TIER[userData.getTierLevel(user)])}__tier--fill`)} />
      </div>

      <h5 className={styles.title}>{status.vipEducationTitle}</h5>

      <div className={styles.content}>
        <ul className={styles.list}>
          {
            _.map(status.educationContentVip, item => (
              <li className={styles.listItem} key={item}>
                <RichTextContent content={item} className={styles.listItemContent} />
              </li>
            ))
          }
        </ul>

        <A buttonType="primary-transparent" className={styles.cta} href="mailto:theclubexecutiveservices@virginaustralia.com">{status.educationLearnMoreLabelVip}</A>
      </div>
    </div>
  );
}
