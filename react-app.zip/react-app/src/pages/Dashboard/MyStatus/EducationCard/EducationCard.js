import React, { useContext } from 'react';
import cx from 'classnames';
import _ from 'lodash';
import { TIER } from '../../../../utils/statusCredits';
import A from '../../../../components/Button/A';
import Icon from '../../../../components/Icon/Icon';
import UserContext from '../../../../contexts/UserContext';
import Plane from '../plane.svg';
import status from '../../../../dictionaries/status.json';
import * as userData from '../../../../utils/utilities';
import statusCardStyles from '../SharedStatusCard.css';
import styles from './EducationCard.css';

export default function EducationCard() {
  const { user } = useContext(UserContext);
  const tierLevel = userData.getTierLevel(user);

  return (
    <div className={cx(statusCardStyles.card, styles.card, statusCardStyles[_.toLower(TIER[tierLevel])])}>
      <div className={cx(styles.imageContainer, `${_.toLower(TIER[tierLevel])}__tier--bg-rgba`)}>
        <Plane className={cx(styles.image, `${_.toLower(TIER[tierLevel])}__tier--fill`)} />
      </div>

      <h5 className={styles.title}>{status.educationTitle}</h5>

      <div className={styles.content}>
        <ul className={styles.list}>
          {
            _.map(status.educationContent, item => (
              <li className={styles.listItem} key={item}>
                <Icon name="tickCircleSolid" size={18} className={styles.icon} />
                <span className={styles.listItemContent}>{item}</span>
              </li>
            ))
          }
        </ul>
        <A buttonType="primary-transparent" className={styles.cta} href={status.educationLearnMoreLink}>{status.educationLearnMoreLabel}</A>
      </div>

    </div>
  );
}
