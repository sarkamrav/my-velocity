import React, { useContext } from 'react';
import cx from 'classnames';
import _ from 'lodash';
import { TIER, getTier } from '../../../../utils/statusCredits';
import A from '../../../../components/Button/A';
import Icon from '../../../../components/Icon/Icon';
import Plane from '../plane.svg';
import status from '../../../../dictionaries/status.json';
import UserContext from '../../../../contexts/UserContext';
import * as userData from '../../../../utils/utilities';
import statusCardStyles from '../SharedStatusCard.css';
import styles from './BenefitStatusCard.css';

export default function BenefitStatusCard() {
  const { user } = useContext(UserContext);
  const tierLevel = userData.getTierLevel(user);
  const subTierLevel = userData.getSubTierLevel(user);

  function getList() {
    switch (tierLevel) {
      case 'S':
        return status.benefitsContentSilver;
      case 'G':
        if (subTierLevel === 'Q') { // Pilot Gold
          return status.benefitsContentPilotGold;
        }
        if (subTierLevel === 'O') { // Explore Gold
          return status.benefitsContentExploreGold;
        }
        if (subTierLevel === 'D') { // Discover Gold
          return status.benefitsContentDiscoverGold;
        }
        return status.benefitsContentGold;
      case 'P':
        return subTierLevel === 'H'
          ? status.benefitsContentExtensionPlatinum
          : status.benefitsContentPlatinum;
      case 'R':
      default:
        return status.educationContent;
    }
  }

  function getLink() {
    switch (tierLevel) {
      case 'S':
        return status.benefitsLinkSilver;
      case 'G':
        if (subTierLevel === 'Q') { // Pilot Gold
          return status.benefitsLinkPilotGold;
        }
        if (subTierLevel === 'O') { // Explore Gold
          return status.benefitsLinkExploreGold;
        }
        if (subTierLevel === 'D') { // Discover Gold
          return status.benefitsLinkDiscoverGold;
        }
        return status.benefitsLinkGold;
      case 'P':
        return status.benefitsLinkPlatinum;
      case 'V':
        return null;
      case 'R':
      default:
        return status.educationLearnMoreLink;
    }
  }

  return (
    <div className={cx(statusCardStyles.card, styles.card, statusCardStyles[_.toLower(TIER[tierLevel])])}>
      <div className={cx(styles.imageContainer, `${_.toLower(TIER[tierLevel])}__tier--bg-rgba`)}>
        <Plane className={cx(styles.image, `${_.toLower(TIER[tierLevel])}__tier--fill`)} />
      </div>

      <h5 className={styles.title}>
        {
          tierLevel === 'P' && subTierLevel === 'H'
            ? 'My Extension - Platinum Benefits'
            : `My ${getTier(userData.getMainTierInfo(user))} Benefits`
        }
      </h5>

      <span className={styles.description}>{status[`benefitsDetail${TIER[tierLevel]}`]}</span>

      <div className={styles.content}>
        <ul className={styles.list}>
          {
            _.map(getList(), item => (
              <li className={styles.listItem} key={item}>
                <Icon name="tickCircleSolid" size={18} className={styles.icon} />
                <span className={styles.listItemContent}>{item}</span>
              </li>
            ))
          }
        </ul>
        <A buttonType="primary-transparent" className={styles.cta} href={getLink()}>{status.educationLearnMoreLabel}</A>
      </div>

    </div>
  );
}
