import React, { useContext } from 'react';
import cx from 'classnames';
import _ from 'lodash';
import Icon from '../../../../components/Icon/Icon';
import status from '../../../../dictionaries/status.json';
import RichTextContent from '../../../../components/RichTextContent/RichTextContent';
import { TIER_CARD, TIER } from '../../../../utils/statusCredits';
import UserContext from '../../../../contexts/UserContext';
import * as userData from '../../../../utils/utilities';
import statusCardStyles from '../SharedStatusCard.css';
import styles from './BenefitStatusCard.css';

export default function VipBenefitStatusCard() {
  const { user } = useContext(UserContext);

  return (
    <div className={cx(statusCardStyles.card, styles.card, statusCardStyles.vip, styles.vip)}>
      <div className={cx(styles.imageContainer, `${_.toLower(TIER[userData.getTierLevel(user)])}__tier--bg-rgba`)}>
        <img src={TIER_CARD.V} alt="VIP" className={styles.image} />
      </div>

      <h5 className={styles.title}>{status.vipBenefitsTitle}</h5>
      <span className={styles.description} />

      <div className={styles.content}>
        <ul className={styles.list}>
          {
            _.map(status.benefitsContentVip, item => (
              <li className={styles.listItem} key={item}>
                <Icon name="tickCircleSolid" size={18} className={styles.icon} />
                <RichTextContent content={item} className={styles.listItemContent} />
              </li>
            ))
          }
        </ul>
      </div>
    </div>
  );
}
