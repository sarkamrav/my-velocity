import React, { useContext, useEffect } from 'react';
import _ from 'lodash';
import cx from 'classnames';
import { Helmet } from 'react-helmet';
import DashboardContext from '../DashboardContext';
import UserContext from '../../../contexts/UserContext';
import status from '../../../dictionaries/status.json';
import VipEducationCard from './EducationCard/VipEducationCard';
import VipBenefitStatusCard from './BenefitStatusCard/VipBenefitStatusCard';
import StatusTips from '../../../fragments/StatusTips/StatusTips';
import WebsiteContext from '../../../contexts/WebsiteContext';
import TargetedBannerForDoNotDownGrade from './TargetedBannerForDoNotDownGrade/TargetedBannerForDoNotDownGrade';
import TargetedReviewForDoNotDownGrade from './TargetedReviewForDoNotDownGrade/TargetedReviewForDoNotDownGrade';
import * as userData from '../../../utils/utilities';
import CoreImageTiles from './CoreImageTiles/CoreImageTiles';
import CoreStripBanner from './CoreStripBanner/CoreStripBanner';
import CoreSingleFeature from './CoreSingleFeature/CoreSingleFeature';
import CoreAccordionComparison from './CoreAccordionComparison/CoreAccordionComparison';
import CoreRichTextContent from './CoreRichTextContent/CoreRichTextContent';
import { CORE_COMPONENT_NAME, isEnableVipTier } from '../../../utils/common';
import { applyOffers } from '../../../utils/target';

import styles from './MyStatus.css';

export default function MyStatus() {
  const { user } = useContext(UserContext);
  const websiteData = useContext(WebsiteContext);
  const { dashboard, getAnalytics } = useContext(DashboardContext);

  const section = _.find(dashboard, { sectionReference: 'yourStatus' });

  const targetedStatusTipsNotification = _.get(websiteData, 'children.status.:items.statusTipsNotification', null);
  const vipStatusComponents = _.get(websiteData, 'children.status.:items.vipMemberStatusSection.myVelocityFragmentItems', []);
  const hasVipStatusComponents = !_.isEmpty(vipStatusComponents);
  const isNewVipDesignEnabled = userData.getTierLevel(user) === 'V' && hasVipStatusComponents && isEnableVipTier();

  useEffect(() => {
    if (section) {
      applyOffers();
    }
  }, [section]);

  if (!section) return null;

  return (
    <div
      className={cx(styles.statusPageContainer, {
        [styles.vip]: isNewVipDesignEnabled,
      })}
    >
      <Helmet>
        <title>{websiteData.children.status.browserTitle}</title>
      </Helmet>

      {
        !!targetedStatusTipsNotification && (
          <TargetedBannerForDoNotDownGrade {...targetedStatusTipsNotification} />
        )
      }

      {
        isNewVipDesignEnabled && _.map(vipStatusComponents, (vipMemberStatusComponent) => {
          const componentData = window.vffCoreWebsite[vipMemberStatusComponent.jsObjectKey];

          return (
            <div className={styles.vipComponent} key={vipMemberStatusComponent.jsObjectKey}>
              {
                componentData
                && componentData.componentKey === CORE_COMPONENT_NAME.richTextContent
                && (
                  <div className={styles.vipRichText}>
                    <CoreRichTextContent jsObjectKey={vipMemberStatusComponent.jsObjectKey} />
                  </div>
                )
              }

              {
                componentData
                && componentData.componentKey === CORE_COMPONENT_NAME.imageTiles
                && <CoreImageTiles jsObjectKey={vipMemberStatusComponent.jsObjectKey} />
              }

              {
                componentData
                && componentData.componentKey === CORE_COMPONENT_NAME.stripBanner
                && <CoreStripBanner jsObjectKey={vipMemberStatusComponent.jsObjectKey} />
              }

              {
                componentData
                && componentData.componentKey === CORE_COMPONENT_NAME.singleFeaturedContent
                && <CoreSingleFeature jsObjectKey={vipMemberStatusComponent.jsObjectKey} />
              }

              {
                componentData
                && componentData.componentKey === CORE_COMPONENT_NAME.accordionComparison
                && <CoreAccordionComparison jsObjectKey={vipMemberStatusComponent.jsObjectKey} />
              }
            </div>
          );
        })
      }

      {
        !isNewVipDesignEnabled && (
          <div className={styles.content}>
            <div className={styles.cards}>
              {
                userData.getTierLevel(user) === 'V' ? (
                  <>
                    <div className={styles.container}>
                      <span className={styles.label}>{status.vipTileHeadingOne}</span>
                      <VipBenefitStatusCard />
                    </div>
                    <div className={styles.container}>
                      <span className={styles.label}>{status.vipTileHeadingTwo}</span>
                      <VipEducationCard />
                    </div>
                  </>
                ) : _.map(section.panels, (panel, index) => {
                  const analyticsMetadata = getAnalytics({
                    eventCategory: 'status-activity',
                    eventName: 'status-tile-interaction',
                    eventLocation: 'status-activity-dashboard',
                    displayPanelType: `${panel.category} - ${panel.state} - ${panel.tierInfo}`,
                    statusPanelType: panel.panelType,
                    statusTileCategory: panel.category,
                    statusTileState: panel.state,
                    statusTierInfo: panel.tierInfo,
                  }, true);

                  return (
                    <TargetedReviewForDoNotDownGrade key={index} panel={panel} analyticsMetadata={analyticsMetadata} />
                  );
                })
              }
              <div className={cx(styles.container, styles.statusContainer)}>
                <span className={styles.label}>{_.get(websiteData, 'children.status.:items.statusTips.title', 'More information about Status')}</span>
                <StatusTips defaultStatusTips={_.get(websiteData, 'children.status.:items.statusTips.tileCards', [])} />
              </div>
            </div>
          </div>
        )
      }
    </div>
  );
}
