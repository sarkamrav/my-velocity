import React, { useEffect } from 'react';
import PropTypes from 'prop-types';

function CoreSingleFeature({ jsObjectKey }) {
  useEffect(() => {
    if (jsObjectKey) {
      window.bootstrapComponent('aem-single-featured-content', jsObjectKey);
    }
  }, [jsObjectKey]);

  return (
    jsObjectKey && <div aem-single-featured-content={jsObjectKey} />
  );
}

CoreSingleFeature.propTypes = {
  jsObjectKey: PropTypes.string,
};

CoreSingleFeature.defaultProps = {
  jsObjectKey: '',
};

export default CoreSingleFeature;
