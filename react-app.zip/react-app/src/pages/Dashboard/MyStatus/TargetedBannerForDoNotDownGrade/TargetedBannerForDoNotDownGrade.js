import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';

import { getTarget } from '../../../../utils/target';
import RichTextContent from '../../../../components/RichTextContent/RichTextContent';

function TargetedBannerForDoNotDownGrade({
  mboxLocation,
}) {
  const [targetActivity, setTargetActivity] = useState(null);

  async function loadMbox() {
    const targetedActivity = await getTarget(mboxLocation);

    if (targetedActivity) {
      setTargetActivity(targetedActivity);
    }
  }

  useEffect(() => {
    if (mboxLocation) {
      loadMbox();
    }
  }, []);

  return !!targetActivity && (
    <div className="vffutils__padding-top vffutils__padding-bottom vffutils__info-alert">
      <div
        className="vffutils__container-width vffutils__container-width--standalone-component"
        analytics-metadata={_.get(targetActivity, 'analyticsMetadata.analytics-metadata', null)}
      >
        <RichTextContent content={targetActivity.content} />
      </div>
    </div>
  );
}

TargetedBannerForDoNotDownGrade.propTypes = {
  mboxLocation: PropTypes.string,
};

TargetedBannerForDoNotDownGrade.defaultProps = {
  mboxLocation: null,
};

export default TargetedBannerForDoNotDownGrade;
