import React, { useEffect } from 'react';
import PropTypes from 'prop-types';

function CoreImageTiles(props) {
  const { jsObjectKey } = props;

  useEffect(() => {
    window.vffCoreWebsite = {
      ...window.vffCoreWebsite,
      [jsObjectKey]: {
        ...props,
      },
    };

    if (jsObjectKey) {
      window.bootstrapComponent('aem-image-tiles', jsObjectKey);
    }
  }, [jsObjectKey]);

  return (
    jsObjectKey && <div aem-image-tiles={jsObjectKey} />
  );
}

CoreImageTiles.propTypes = {
  jsObjectKey: PropTypes.string,
};

CoreImageTiles.defaultProps = {
  jsObjectKey: '',
};

export default CoreImageTiles;
