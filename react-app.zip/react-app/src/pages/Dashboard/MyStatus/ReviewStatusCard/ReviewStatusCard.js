import React from 'react';
import cx from 'classnames';
import planeUnknown from '../../../../images/plane-unknown.png';
import Circle from '../circle.svg';
import status from '../../../../dictionaries/status.json';
import A from '../../../../components/Button/A';
import statusCardStyles from '../SharedStatusCard.css';
import styles from './ReviewStatusCard.css';

export default function ReviewStatusCard() {
  return (
    <div className={cx(statusCardStyles.card, styles.card)}>
      <div className={styles.header}>
        <div className={styles.currentTier}>
          <span>Current Status</span>
          <span className={cx(styles.emphasis, 'unknown__tier--color')}>UNDER REVIEW</span>
        </div>
        <A buttonType="black-link" ctaAsLink href={status.statusLevelsLink}>{status.statusLevelsLabel}</A>
      </div>
      <div className={styles.content}>
        <div className={styles.progressContainer}>
          <Circle className={styles.progress} style={{ fill: 'transparent' }} />

          <div className={styles.progressContent}>
            <img src={planeUnknown} alt="Under review" className={styles.underReviewImage} />
            <span className={styles.statusCredits}>{status.underReviewTitle}</span>
            <span className={styles.statusCreditsToUpgrade}>{status.underReviewMessage}</span>
          </div>
        </div>
      </div>

      <div className={styles.learnMoreContainer}>
        <A buttonType="black-link" ctaAsLink href={status.howStatusReviewWorksLink}>{status.howStatusReviewWorksLabel}</A>
      </div>
    </div>
  );
}
