import React, { useContext } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import moment from 'moment';
import cx from 'classnames';
import { useApi } from '../../../utils/api';
import Toucan from './toucan.svg';
import Loading from '../../../components/Loading/Loading';
import WebsiteContext from '../../../contexts/WebsiteContext';
import A from '../../../components/Button/A';
import Icon from '../../../components/Icon/Icon';
import Separator from './separator.svg';
import UserContext from '../../../contexts/UserContext';
import DashboardContext from '../DashboardContext';
import syncText from '../../../utils/common';
import * as userData from '../../../utils/utilities';
import styles from './UpcomingFlightCard.css';

function UpcomingFlightCard({ analyticsMetadataFromParent }) {
  const { user } = useContext(UserContext);
  const spaContainer = useContext(WebsiteContext);
  const { getAnalytics } = useContext(DashboardContext);

  const { data: upcomingBookingData, loading, error } = useApi('/trip/v1/reservations/me', {
    endpoint: 'vaCloudApi',
  });

  if (loading) return <Loading />;

  const flightContent = _.get(spaContainer[':items'], 'banner.flight', {});

  if (error) {
    return (
      <div className={styles.container}>
        <div className={styles.header}>
          <div className={styles.titleContainer}>
            <span className={styles.title}>Upcoming Flight</span>
          </div>
        </div>

        <div className={styles.emptyState}>
          <div className={styles.errorState}>
            <Icon name="exclamationCircleSolid" className={styles.errorIcon} size={24} />
            <div className={styles.column}>
              <div className={styles.description}>Sorry we’re having issues with our system. Please refresh the page or try again later</div>
            </div>
          </div>
        </div>

        <div className={styles.footer}>
          <button
            onClick={() => window.location.reload()}
            className={cx(styles.button, styles.emphasis, styles.fullWidth)}
          >
            Refresh the page
          </button>
        </div>
      </div>
    );
  }

  const upcomingFlights = _(upcomingBookingData?.reservations)
    .map(reservation => ({
      ...reservation,
      itinerary: _.map(reservation.itinerary, itinerary => ({
        ...itinerary,
        recordLocator: reservation.recordLocator,
      })),
    }))
    .flatMap('itinerary')
    .reject(itinerary => moment().isAfter(itinerary.departure.date))
    .sortBy(itinerary => itinerary.departure.date)
    .value();
  const nextFlight = _.first(upcomingFlights);

  if (!nextFlight) {
    const analyticsMetadata = getAnalytics({
      ...analyticsMetadataFromParent,
      eventCategory: 'flight-details',
      eventName: 'upcoming-flight-interaction',
      eventLocation: 'my-velocity-header',
      targeted: 'N',
    }, true);

    const isNewTripLinkOpenInNewTab = _.get(flightContent, 'linkNewTrip.ctaOpenInNewTab', false);
    const isBookFlightLinkOpenInNewTab = _.get(flightContent, 'bookFlight.ctaOpenInNewTab', false);

    return (
      <div className={styles.container}>
        <div className={styles.header}>
          <div className={styles.titleContainer}>
            <span className={styles.title}>Upcoming Flight</span>
          </div>
        </div>

        <div className={styles.emptyState}>
          <div className={styles.column}>
            <span className={styles.description}>You&apos;ve currently got no upcoming flights.</span>
            <span className={styles.subtitle}>Let&apos;s change that!</span>
          </div>

          <div className={cx(styles.column, styles.illustration)}>
            <Toucan />
          </div>
        </div>

        <div
          className={styles.footer}
          analytics-metadata={analyticsMetadata}
        >
          {/* eslint-disable-next-line react/jsx-no-target-blank */}
          <a
            className={styles.button}
            href={_.get(flightContent, 'linkNewTrip.ctaUrl')}
            target={isNewTripLinkOpenInNewTab ? '_blank' : '_self'}
            title={_.get(flightContent, 'linkNewTrip.ctaTitle')}
            rel={isNewTripLinkOpenInNewTab ? 'noopener noreferrer' : null}
          >
            {_.get(flightContent, 'linkNewTrip.ctaLabel')}
          </a>
          {/* eslint-disable-next-line react/jsx-no-target-blank */}
          <a
            className={cx(styles.button, styles.emphasis)}
            href={_.get(flightContent, 'bookFlight.ctaUrl')}
            target={isBookFlightLinkOpenInNewTab ? '_blank' : '_self'}
            title={_.get(flightContent, 'bookFlight.ctaTitle')}
            rel={isBookFlightLinkOpenInNewTab ? 'noopener noreferrer' : null}
          >
            {_.get(flightContent, 'bookFlight.ctaLabel')}
          </a>
        </div>
      </div>
    );
  }

  const analyticsMetadata = getAnalytics({
    ...analyticsMetadataFromParent,
    eventCategory: 'flight-details',
    eventName: 'upcoming-flight-interaction',
    eventLocation: 'my-velocity-header',
    targeted: 'N',
    bookingRef: nextFlight.recordLocator,
    origin: nextFlight.departure.port.code,
    destination: nextFlight.arrival.port.code,
  }, true);

  const isManageLinkOpenInNewTab = _.get(flightContent, 'manageLink.ctaOpenInNewTab', false);

  return (
    <div className={styles.container}>
      <div
        className={styles.header}
        analytics-metadata={analyticsMetadata}
      >
        <div className={styles.titleContainer}>
          <span>Upcoming Flight</span>
        </div>
        <A
          href={_.get(flightContent, 'viewAll.ctaUrl')}
          target={_.get(flightContent, 'viewAll.ctaOpenInNewTab', false) ? '_blank' : '_self'}
          title={_.get(flightContent, 'viewAll.ctaTitle')}
          ctaAsLink
        >
          {_.get(flightContent, 'viewAll.ctaLabel')}
        </A>
      </div>

      <div className={styles.reservation}>
        <div className={styles.location}>
          <span className={styles.time}>{moment.parseZone(nextFlight.departure.date).format('hh:mma')}</span>
          <span className={styles.code}>{nextFlight.departure.port.code}</span>
          <span className={styles.state}>{nextFlight.departure.port.name}</span>
          <span className={styles.date}>{moment(nextFlight.departure.date).format('DD MMMM YYYY')}</span>
        </div>
        <Separator className={styles.separator} />
        <div className={styles.location}>
          <span className={styles.time}>{moment.parseZone(nextFlight.arrival.date).format('hh:mma')}</span>
          <span className={styles.code}>{nextFlight.arrival.port.code}</span>
          <span className={styles.state}>{nextFlight.arrival.port.name}</span>
          <span className={styles.date}>{moment(nextFlight.arrival.date).format('DD MMMM YYYY')}</span>
        </div>
      </div>

      <div
        className={styles.footer}
        analytics-metadata={analyticsMetadata}
      >
        {/* eslint-disable-next-line react/jsx-no-target-blank */}
        <a
          className={cx(styles.button, styles.fullWidth, styles.emphasis)}
          href={syncText(decodeURI(_.get(flightContent, 'manageLink.ctaUrl', '/')), {
            pnr: nextFlight.recordLocator,
            lastName: userData.getLastName(user),
          }, '<', '>')}
          target={isManageLinkOpenInNewTab ? '_blank' : '_self'}
          title={_.get(flightContent, 'manageLink.ctaTitle')}
          rel={isManageLinkOpenInNewTab ? 'noopener noreferrer' : null}
        >
          {_.get(flightContent, 'manageLink.ctaLabel')}
        </a>
      </div>
    </div>
  );
}

UpcomingFlightCard.propTypes = {
  analyticsMetadataFromParent: PropTypes.shape(),
};

UpcomingFlightCard.defaultProps = {
  analyticsMetadataFromParent: {},
};

export default UpcomingFlightCard;
