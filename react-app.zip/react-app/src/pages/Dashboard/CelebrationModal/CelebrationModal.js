import React from 'react';
import PropTypes from 'prop-types';
import isEmpty from 'lodash/isEmpty';
import RichTextContent from '../../../components/RichTextContent/RichTextContent';
import CelebrationModalSvg from './CelebrationModal.svg';
import Button from '../../../components/Button/Button';
import A from '../../../components/Button/A';
import syncText, { isCtaAvailable } from '../../../utils/common';

import styles from './CelebrationModal.css';

function CelebrationModal({ mainTierInfo, celebrationModalInfo, firstname, lastname }) {
  const { celebrationItems, ctaContainer, velocityLogo, virginLogo } = celebrationModalInfo;

  const currentUserTierInfo = celebrationItems.filter(obj => obj.tierLevel === mainTierInfo.tierLevel)[0];

  return (
    <div className={styles.celebrationModalWrapper}>
      {
        (!isEmpty(velocityLogo) || !isEmpty(virginLogo)) && (
          <header className={styles.header}>
            {
              velocityLogo && (
                <img src={velocityLogo.imageRef} alt={velocityLogo.alt} />
              )
            }

            {
              virginLogo && (
                <img src={virginLogo.imageRef} alt={virginLogo.alt} />
              )
            }
          </header>
        )
      }
      <div className={styles.main}>
        <div className={styles.imageContainer}>
          <CelebrationModalSvg className={styles.clbImage} />

          {
            currentUserTierInfo?.iconUrl && (
              <div className={styles.cardImage}>
                <img src={currentUserTierInfo?.iconUrl} alt="" />
              </div>
            )
          }
        </div>
        <div className={styles.contentContainer}>
          <RichTextContent
            className={styles.title}
            content={syncText(currentUserTierInfo?.title, {
              firstName: firstname,
              lastName: lastname,
            })}
          />

          {
            currentUserTierInfo?.description && (
              <RichTextContent
                className={styles.description}
                content={currentUserTierInfo?.description}
              />
            )
          }

          {
            isCtaAvailable(currentUserTierInfo?.ctaContainer) && (
              <Button
                className={styles.ctaButton}
                href={currentUserTierInfo?.ctaContainer.ctaUrl}
                title={currentUserTierInfo?.ctaContainer.ctaTitle}
                target={currentUserTierInfo?.ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
                buttonType={currentUserTierInfo?.ctaContainer.ctaStyle}
              >
                {currentUserTierInfo?.ctaContainer.ctaLabel}
              </Button>
            )
          }

          {
            isCtaAvailable(ctaContainer) && (
              <A
                className={styles.linkButton}
                href={ctaContainer.ctaUrl}
                target={ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
                title={ctaContainer.ctaLabel}
              >
                {ctaContainer.ctaLabel}
              </A>
            )
          }
        </div>
      </div>
    </div>
  );
}

export default CelebrationModal;

CelebrationModal.propTypes = {
  firstname: PropTypes.string,
  lastname: PropTypes.string,
  mainTierInfo: PropTypes.oneOfType([PropTypes.object]).isRequired,
  celebrationModalInfo: PropTypes.oneOfType([PropTypes.object]).isRequired,
};

CelebrationModal.defaultProps = {
  firstname: '',
  lastname: '',
};
