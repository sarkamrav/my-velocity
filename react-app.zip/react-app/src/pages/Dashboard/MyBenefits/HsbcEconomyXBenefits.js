import React, { useCallback } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import cx from 'classnames';
import moment from 'moment';

import EconomyXIcon from './economy-x.svg';
import analytics from '../../../utils/analytics';
import ExpandableCard from './ExpandableCard/ExpandableCard';

import styles from './MyBenefits.css';

function HsbcEconomyXBenefits({
  certificates,
}) {
  const STATUSES = {
    A: 'Available',
    R: 'Redeemed',
    E: 'Expired',
  };

  const availableCertificates = _.filter(certificates, { status: 'A' });
  const numberOfAvailableCertificates = _.size(availableCertificates);
  const totalOfCertificates = _.size(certificates);
  const count = `${numberOfAvailableCertificates} of ${totalOfCertificates}`;

  const analyticsMetadata = {
    eventCategory: 'member-benefits',
    eventName: 'benefits-cta',
    eventLocation: 'member-benefits',
    panelType: 'benefits',
    tileCategory: 'hsbc-economyx',
    tileState: count,
    targeted: 'N',
  };

  const onExpandButtonClick = useCallback(() => analytics.send(analyticsMetadata), [certificates]);

  return _.size(certificates) === 0 ? null : (
    <ExpandableCard
      analyticsMetadataFromParent={analyticsMetadata}
      icon={<EconomyXIcon />}
      title="HSBC Velocity Flight Certificate"
      description="See below for details of your HSBC Velocity Flight Certificate thanks to your HSBC Velocity Black Credit Card."
      counter={{
        availabilityText: `${numberOfAvailableCertificates} of ${totalOfCertificates}`,
        description: 'HSBC Velocity Flight Certificates available',
      }}
      onExpandButtonClick={onExpandButtonClick}
      expandableContent={
        <>
          <div className={styles.section}>
            <div className={cx(styles.title, styles.emphasis)}>HSBC Velocity Black Credit Card</div>
            <span className={cx(styles.emphasis, styles.sectionTitle)}>Passes</span>
            <div className={styles.row}>
              {
                _.map(certificates, certificate => (
                  <div key={certificate.certificateNumber} className={styles.certificate}>
                    <div className={styles.certificateRow}>
                      <span>Certificate code:</span>
                      <span>{certificate.certificateNumber}</span>
                    </div>
                    <div className={styles.certificateRow}>
                      <span>Expiry date:</span>
                      <span>{moment(certificate.expiryDate).format('DD/MM/YYYY')}</span>
                    </div>
                    <div className={styles.certificateRow}>
                      <span>Status:</span>
                      <span className={cx(styles.status, styles[certificate.status])}>{STATUSES[certificate.status]}</span>
                    </div>
                  </div>
                ))
              }
            </div>
          </div>

          <div className={styles.section}>
            <span className={cx(styles.emphasis, styles.sectionTitle)}>How to redeem your Certificate</span>
            <div className={styles.stepContent}>Call our Membership Contact Centre on <a href="tel:1300010479">1300 010 479</a> and ask to redeem your HSBC Velocity Flight Certificate.</div>
          </div>

          <div className={styles.section}>
            <span className={cx(styles.emphasis, styles.sectionTitle)}>Important things to know</span>
            <ul className={styles.list}>
              <li>Flight Certificate must be redeemed on selected return routes only:
                <ul>
                  <li>Sydney - Denpasar (Bali)</li>
                  <li>Melbourne - Denpasar (Bali)</li>
                  <li>Brisbane - Denpasar (Bali)</li>
                </ul>
              </li>
              <li>The member is required to pay for relevant taxes, fees and <a href="https://www.velocityfrequentflyer.com/content/Redeem/Airlines/PointsTables/" target="_blank" rel="noopener noreferrer">carrier charges</a> when making the booking</li>
              <li>Once the Flight Certificate is redeemed, if you make any changes to your flight booking a change fee will be charged</li>
              <li>Flight Certificate is only valid for Economy class seats and seats are subject to availability. Please read the <a href="https://www.virginaustralia.com/au/en/terms-conditions/HSBC-flight-certificate/" target="_blank" rel="noopener noreferrer">HSBC Velocity Flight Certificate Fare Rules</a> for details</li>
            </ul>
            <div className={styles.disclaimer}>* Subject to availability</div>
          </div>
        </>
      }
    />
  );
}

HsbcEconomyXBenefits.propTypes = {
  certificates: PropTypes.arrayOf(PropTypes.shape()),
};

HsbcEconomyXBenefits.defaultProps = {
  certificates: [],
};

export default HsbcEconomyXBenefits;
