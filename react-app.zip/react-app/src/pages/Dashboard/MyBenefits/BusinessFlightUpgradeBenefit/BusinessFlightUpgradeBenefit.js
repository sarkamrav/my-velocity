import React from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';

import get from 'lodash/get';
import { useApi } from '../../../../utils/api';
import { flightUpgradeInfo } from '../common';
import FlightUpgradeIcon from '../flight-upgrade.svg';
import ExpandableCard from '../ExpandableCard/ExpandableCard';
import CreditTable from '../components/flightUpgrade/CreditTable/CreditTable';
import { flightUpgradeContentDescription, flightUpgradeDescription } from '../../../../dictionaries/constants';
import BusinessFlyerRedemptionTable
from '../components/flightUpgrade/BusinessFlyerRedemptionTable/BusinessFlyerRedemptionTable';

const additionalDescription = '<p>Velocity Frequent Flyer members who have been allocated a Business Class upgrade by a Virgin Australia Business Flyer member are eligible to use the Business Class upgrade on full fare Economy Flex fares for Virgin Australia marketed and operated domestic or International Short Haul Flight Sectors (excluding Christmas Island and Cocos Island). Velocity Frequent Flyer members can also use their Business Class upgrades for guests travelling with them on the same flight and who are booked on a Flex fare. Velocity Frequent Flyer members may request an upgrade any time after the flight is booked and up to two hours prior to the scheduled departure time by contacting the <a href="https://experience.velocityfrequentflyer.com/member-support" target="_blank" rel="noopener noreferrer">Membership Contact Centre</a>. For operational reasons, not all Business Class seats are made available for upgrades. This means there may still be empty seats on departure. Upgrades are subject to the <a href="https://experience.velocityfrequentflyer.com/member-support/terms-conditions#clause-8" target="_blank" rel="noopener noreferrer">Upgrade Cancellation and Amendment Policy</a>.</p>';

function BusinessFlightUpgradeBenefit({ awardCreditDetails }) {
  const awardCreditDetailsData = get(awardCreditDetails, 'awardCredits', []);
  const startDate = moment().subtract(1, 'year').format('YYYY-MM-DD');
  const endDate = moment().format('YYYY-MM-DD');
  const redeemedAwardCreditsUri = `/loyalty/v2/experience/benefits/me/redeemedAwardCredits?startDate=${startDate}&endDate=${endDate}&benefitCode=BBFBCU`;

  const { data } = useApi(redeemedAwardCreditsUri, {
    endpoint: 'vffV2Api',
  });

  const redeemedFlightUpgradesAwardCredits = get(data, 'data', []);

  const businessFlightUpgrade = flightUpgradeInfo(
    awardCreditDetailsData,
    redeemedFlightUpgradesAwardCredits,
    ['BBFBCU'],
  );

  return (businessFlightUpgrade.hasFlightUpgradesAwardCredits || businessFlightUpgrade.hasRedeemedFlightUpgrades) && (
    <ExpandableCard
      icon={<FlightUpgradeIcon />}
      title="Virgin Australia Business Flyer Flight Upgrade"
      description={flightUpgradeDescription}
      analyticsMetadataFromParent={{
        eventCategory: 'member-benefits',
        eventName: 'benefits-cta',
        eventLocation: 'member-benefits',
        panelType: 'benefits',
        tileCategory: 'flight-upgrade',
        tileState: businessFlightUpgrade.hasRemainingCredits ? 'unused' : 'used',
        targeted: 'N',
      }}
      counter={{
        description: `${businessFlightUpgrade.remainingCredits} Flight upgrades available`,
      }}
      expandableContent={
        <>
          <CreditTable title={flightUpgradeContentDescription} description={additionalDescription} upgradeInfo={businessFlightUpgrade} />
          <BusinessFlyerRedemptionTable upgradeInfo={businessFlightUpgrade} />
        </>
      }
    />
  );
}

BusinessFlightUpgradeBenefit.propTypes = {
  awardCreditDetails: PropTypes.shape({}),
};

BusinessFlightUpgradeBenefit.defaultProps = {
  awardCreditDetails: null,
};

export default BusinessFlightUpgradeBenefit;
