import React, { useCallback } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import cx from 'classnames';
import moment from 'moment';

import ExpandableCard from './ExpandableCard/ExpandableCard';
import analytics from '../../../utils/analytics';
import EconomyXIcon from './economy-x.svg';

import styles from './MyBenefits.css';

function WestpacEconomyXBenefits({
  certificates,
}) {
  const STATUSES = {
    A: 'Available',
    R: 'Redeemed',
    E: 'Expired',
  };

  const availableCertificates = _.filter(certificates, { status: 'A' });
  const numberOfAvailableCertificates = _.size(availableCertificates);
  const totalOfCertificates = _.size(certificates);
  const count = `${numberOfAvailableCertificates} of ${totalOfCertificates}`;

  const analyticsMetadata = {
    eventCategory: 'member-benefits',
    eventName: 'benefits-cta',
    eventLocation: 'member-benefits',
    panelType: 'benefits',
    tileCategory: 'westpac-economyx',
    tileState: count,
    targeted: 'N',
  };

  const onExpandButtonClick = useCallback(() => analytics.send(analyticsMetadata), [certificates]);

  return _.size(certificates) === 0 ? null : (
    <ExpandableCard
      analyticsMetadataFromParent={analyticsMetadata}
      icon={<EconomyXIcon />}
      title="Economy X Upgrade"
      description="See below for details of your Economy X upgrade vouchers thanks to your Westpac Altitude Velocity Mastercard."
      counter={{
        availabilityText: `${numberOfAvailableCertificates} of ${totalOfCertificates}`,
        description: 'Economy X domestic upgrades*',
      }}
      onExpandButtonClick={onExpandButtonClick}
      expandableContent={
        <>
          <div className={styles.section}>
            <div className={cx(styles.title, styles.emphasis)}>Westpac Altitude Velocity Mastercard</div>
            <span className={cx(styles.emphasis, styles.sectionTitle)}>Passes</span>
            <div className={styles.row}>
              {
                _.map(certificates, certificate => (
                  <div key={certificate.certificateNumber} className={styles.certificate}>
                    <div className={styles.certificateRow}>
                      <span>Voucher code:</span>
                      <span>{certificate.certificateNumber}</span>
                    </div>
                    <div className={styles.certificateRow}>
                      <span>Expiry date:</span>
                      <span>{moment(certificate.expiryDate).format('DD/MM/YYYY')}</span>
                    </div>
                    <div className={styles.certificateRow}>
                      <span>Status:</span>
                      <span className={cx(styles.status, styles[certificate.status])}>{STATUSES[certificate.status]}</span>
                    </div>
                  </div>
                ))
              }
            </div>
          </div>

          <div className={styles.section}>
            <span className={cx(styles.emphasis, styles.sectionTitle)}>How to redeem your vouchers</span>
            <div className={styles.step}>
              <span className={styles.emphasis}>Step 1</span>
              <div className={styles.stepContent}>
                You&apos;ll need to book an Economy Class seat on a <a href="https://www.virginaustralia.com/au/en/bookings/flights/make-a-booking/" target="_blank" rel="noopener noreferrer">Virgin Australia flight</a>.
              </div>
            </div>
            <div className={styles.step}>
              <span className={styles.emphasis}>Step 2</span>
              <div className={styles.stepContent}>
                Once you&apos;ve booked your domestic flight with Virgin Australia please contact our Guest Contact Centre to redeem Economy X seat upgrade voucher (<a href="tel:1300 038 373">1300 038 373</a>).
              </div>
            </div>
          </div>

          <div className={styles.section}>
            <span className={cx(styles.emphasis, styles.sectionTitle)}>Important things to know</span>
            <ul className={styles.list}>
              <li>Upgrade vouchers must be redeemed on a sector of a domestic Virgin Australia flight.</li>
              <li>Once Economy X voucher is redeemed, if you make any changes to your flight booking your voucher upgrade may be forfeited.</li>
              <li>Primary card holder must be travelling on the same itinerary as the person redeeming upgrade voucher.</li>
              <li>Economy X is subject to availability and is not always available. Please read the <a href="https://experience.velocityfrequentflyer.com/partners-offers/credit-cards-banking-insurance/westpac" target="_blank" rel="noopener noreferrer">Westpac Economy X Seat Upgrade Voucher Terms and Conditions</a> for details.</li>
              <li>Eligible members will receive 2 complimentary Economy X seat upgrade vouchers per year.</li>
            </ul>
            <div className={styles.disclaimer}>* Subject to availability</div>
          </div>
        </>
      }
    />
  );
}

WestpacEconomyXBenefits.propTypes = {
  certificates: PropTypes.arrayOf(PropTypes.shape()),
};

WestpacEconomyXBenefits.defaultProps = {
  certificates: [],
};

export default WestpacEconomyXBenefits;
