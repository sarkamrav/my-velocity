import React, { useCallback } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import moment from 'moment';
import cx from 'classnames';

import ExpandableCard from './ExpandableCard/ExpandableCard';
import analytics from '../../../utils/analytics';
import LoungePassIcon from './lounge-pass.svg';

import styles from './MyBenefits.css';

function HsbcLoungePassBenefits({ loungeDetails }) {
  const passes = _.filter(_.get(loungeDetails, 'voucherPasses'), ({ numberAvailable, voucherType }) => voucherType === 'HSBC' && +numberAvailable > 0);
  const numberOfAvailableVouchers = _.sumBy(passes, pass => +pass.numberAvailable);
  const numberOfUsedVouchers = _.sumBy(passes, pass => +pass.numberUsed);
  const totalNumberOfVouchers = numberOfAvailableVouchers + numberOfUsedVouchers;
  // This is necessary in the event that numberAvailable is greater than 1. Note that we duplicate the voucher in that situation.
  const aggregatedVouchers = _.flatMap(passes, voucher => _.map(_.range(+voucher.numberAvailable), () => voucher));

  const count = `${numberOfAvailableVouchers} of ${totalNumberOfVouchers}`;
  const analyticsMetadata = {
    eventCategory: 'member-benefits',
    eventName: 'benefits-cta',
    eventLocation: 'member-benefits',
    panelType: 'benefits',
    tileCategory: 'hsbc-lounge-passes',
    tileState: count,
    targeted: 'N',
  };

  const onExpandButtonClick = useCallback(() => analytics.send(analyticsMetadata), [loungeDetails]);

  return _.size(passes) === 0 ? null : (
    <ExpandableCard
      analyticsMetadataFromParent={analyticsMetadata}
      icon={<LoungePassIcon />}
      title="Complimentary Domestic Lounge Pass"
      description="See below for details of your Virgin Australia Domestic Lounge Passes thanks to your HSBC Velocity Black Credit Card."
      counter={{
        availabilityText: `${numberOfAvailableVouchers} of ${totalNumberOfVouchers}`,
        description: 'Virgin Australia Lounge Passes available',
      }}
      onExpandButtonClick={onExpandButtonClick}
      expandableContent={
        <>
          <div className={styles.section}>
            <div className={cx(styles.title, styles.emphasis)}>HSBC Velocity Black Credit Card</div>
            <span className={cx(styles.emphasis, styles.sectionTitle)}>Passes</span>
            <div className={styles.row}>
              {
                _.map(aggregatedVouchers, (voucher, index) => (
                  <div key={`${voucher.voucherID}${index}`} className={styles.certificate}>
                    <div>Voucher {index + 1}</div>
                    <div className={styles.certificateRow}>
                      <span>Expiry date:</span>
                      <span>{moment(voucher.endDate).format('DD/MM/YYYY')}</span>
                    </div>
                  </div>
                ))
              }
            </div>
          </div>

          <div className={styles.section}>
            <span className={cx(styles.emphasis, styles.sectionTitle)}>How to redeem your vouchers</span>
            <div className={styles.stepContent}>Simply present this digital pass along with your Velocity Frequent Flyer ID to staff at any <a href="https://www.virginaustralia.com/au/en/experience/at-the-airport/lounge/#locations" target="_blank" rel="noopener noreferrer">Virgin Australia operated Domestic Lounge</a> for entry access.</div>
          </div>

          <div className={styles.section}>
            <span className={cx(styles.emphasis, styles.sectionTitle)}>Important things to know</span>
            <ul className={styles.list}>
              <li>You must be travelling on a Virgin Australia flight on the same day as redeeming pass.</li>
              <li>Lounge Pass is valid at Virgin Australia operated Domestic Lounges only.</li>
              <li>Lounge pass entry is subject to availability as detailed in the <a href="https://www.virginaustralia.com/au/en/information/domestic-and-short-haul-international/lounge-terms-and-conditions/" target="_blank" rel="noopener noreferrer">Virgin Australia Lounge Terms and Conditions</a>.</li>
            </ul>
            <div className={styles.disclaimer}>* T&amp;Cs apply</div>
          </div>
        </>
      }
    />
  );
}

HsbcLoungePassBenefits.propTypes = {
  loungeDetails: PropTypes.shape(),
};

HsbcLoungePassBenefits.defaultProps = {
  loungeDetails: {},
};

export default HsbcLoungePassBenefits;
