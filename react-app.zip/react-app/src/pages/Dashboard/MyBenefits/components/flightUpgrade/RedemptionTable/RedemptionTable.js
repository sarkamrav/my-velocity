import React from 'react';
import moment from 'moment';
import map from 'lodash/map';
import PropTypes from 'prop-types';

import Table from '../../../../../../components/Table/Table';

import styles from './RedemptionTable.css';

const redeemedCreditsTable = [
  <span className={styles.tableColumn}>Booking date</span>,
  <span className={styles.tableColumn}>Travel date</span>,
  'PNR',
  <span className={styles.tableColumn}>Sector</span>,
];

function RedemptionTable({ upgradeInfo }) {
  return upgradeInfo?.hasRedeemedFlightUpgrades && (
    <>
      <h2>Upgrade redemption history</h2>
      <Table
        tableClassName={styles.table}
        hasShadow={false}
        itemsPerPage={500}
        headers={redeemedCreditsTable}
        rows={map(upgradeInfo?.redeemedFlightUpgradesAwardCredits, item => ({
          uniqueId: item.id,
          bookingDate: moment(item?.activityDate).format('DD-MM-YYYY'),
          travelDate: moment(item?.flight?.travelDate).format('DD-MM-YYYY'),
          pnr: item?.flight?.bookingReferenceNumber,
          sector: `${item?.flight?.origCode} to ${item?.flight?.destCode}`,
        }))}
      />
    </>
  );
}

RedemptionTable.propTypes = {
  upgradeInfo: PropTypes.shape({
    hasRedeemedFlightUpgrades: PropTypes.bool,
    redeemedFlightUpgradesAwardCredits: PropTypes.arrayOf(PropTypes.shape({})),
  }),
};

RedemptionTable.defaultProps = {
  upgradeInfo: null,
};

export default RedemptionTable;
