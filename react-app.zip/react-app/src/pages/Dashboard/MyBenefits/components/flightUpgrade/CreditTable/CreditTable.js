import React from 'react';
import moment from 'moment';
import PropTypes from 'prop-types';

import RichTextContent from '../../../../../../components/RichTextContent/RichTextContent';
import Table from '../../../../../../components/Table/Table';

import styles from './CreditTable.css';

const creditsTable = [
  'Available',
  <span className={styles.tableColumn}>Expiry</span>,
];

function CreditTable({ title, description, upgradeInfo }) {
  return upgradeInfo?.hasFlightUpgradesAwardCredits && (
    <>
      { title && <RichTextContent className={styles.titleText} content={title} />}
      <Table
        tableClassName={styles.table}
        hasShadow={false}
        itemsPerPage={500}
        headers={creditsTable}
        rows={(upgradeInfo?.filterAvailableAwardCredits).map(item => ({
          uniqueId: item?.expiresAt,
          available: item?.amount,
          expiry: moment(item?.expiresAt).format('DD-MM-YYYY'),
        }))}
      />
      { description && <RichTextContent className={styles.description} content={description} /> }
    </>
  );
}

CreditTable.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
  upgradeInfo: PropTypes.shape({
    hasFlightUpgradesAwardCredits: PropTypes.bool,
    filterAvailableAwardCredits: PropTypes.arrayOf(PropTypes.shape({})),
  }),
};

CreditTable.defaultProps = {
  title: '',
  description: '',
  upgradeInfo: null,
};

export default CreditTable;
