import React from 'react';
import moment from 'moment';
import map from 'lodash/map';
import PropTypes from 'prop-types';

import Table from '../../../../../../components/Table/Table';

import styles from './BusinessFlyerRedemptionTable.css';

const redeemedCreditsTable = [
  'Used',
  <span className={styles.tableColumn}>Activity date</span>,
];

function BusinessFlyerRedemptionTable({ upgradeInfo }) {
  return upgradeInfo?.hasRedeemedFlightUpgrades && (
    <>
      <h2>Upgrade redemption history</h2>
      <Table
        tableClassName={styles.table}
        hasShadow={false}
        itemsPerPage={500}
        headers={redeemedCreditsTable}
        rows={map(upgradeInfo?.redeemedFlightUpgradesAwardCredits, item => ({
          uniqueId: item?.id,
          used: item?.amount,
          activityDate: moment(item?.activityDate).format('DD-MM-YYYY'),
        }))}
      />
    </>
  );
}

BusinessFlyerRedemptionTable.propTypes = {
  upgradeInfo: PropTypes.shape({
    hasRedeemedFlightUpgrades: PropTypes.bool,
    redeemedFlightUpgradesAwardCredits: PropTypes.arrayOf(PropTypes.shape({})),
  }),
};

BusinessFlyerRedemptionTable.defaultProps = {
  upgradeInfo: null,
};

export default BusinessFlyerRedemptionTable;
