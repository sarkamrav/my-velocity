import React, { useContext } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import moment from 'moment';

import BenefitTile from './BenefitTile/BenefitTile';
import WebsiteContext from '../../../contexts/WebsiteContext';

function GoldAwardCredits({ mainTierInfo, awardCreditDetails }) {
  const websiteData = useContext(WebsiteContext);
  const goldFlightUpgradesJsObjectKey = _.get(websiteData, 'children.benefits.:items.goldFlightUpgrades.tileCards.0.jsObjectKey', '');
  const goldFlightUpgrades = window.vffCoreWebsite[goldFlightUpgradesJsObjectKey];

  const awardCreditDetailsData = _.get(awardCreditDetails, 'awardCredits', []);
  const goldCompanionBenefitJsObjectKey = _.get(websiteData, 'children.benefits.:items.goldCompanionBenefit.tileCards.0.jsObjectKey', '');
  const goldCompanionBenefit = window.vffCoreWebsite[goldCompanionBenefitJsObjectKey];

  // `isAwardCreditValid` checks for the expiry date validity within the available array and returns true if satisfied
  const isAwardCreditValid = (available = []) => _.filter(available, availableData => moment(availableData.expiresAt).isSameOrAfter(moment()));

  const hasCovidFlightUpgradeForGoldTier = _.some(
    awardCreditDetailsData,
    award => isAwardCreditValid(award?.available) && ['BCEBG', 'BCUEFP'].includes(award.code),
  );

  const hasCompanionBenefit = _.some(
    awardCreditDetailsData,
    award => isAwardCreditValid(award?.available) && ['BCMGLD'].includes(award.code),
  );

  return (
    <>
      {
        hasCovidFlightUpgradeForGoldTier
        && !_.isEmpty(goldFlightUpgrades)
        && (
          <BenefitTile
            image={_.get(goldFlightUpgrades, 'renditions.imageDefault', '')}
            {...goldFlightUpgrades}
          />
        )
      }

      {
        hasCompanionBenefit
        && !_.isEmpty(goldCompanionBenefit)
        && mainTierInfo?.tierType === 'M'
        && (
          <BenefitTile
            image={_.get(goldCompanionBenefit, 'renditions.imageDefault', '')}
            {...goldCompanionBenefit}
          />
        )
      }
    </>
  );
}

GoldAwardCredits.propTypes = {
  mainTierInfo: PropTypes.shape({
    tierType: PropTypes.string,
  }),
  awardCreditDetails: PropTypes.shape({}),
};

GoldAwardCredits.defaultProps = {
  mainTierInfo: {},
  awardCreditDetails: {},
};

export default GoldAwardCredits;
