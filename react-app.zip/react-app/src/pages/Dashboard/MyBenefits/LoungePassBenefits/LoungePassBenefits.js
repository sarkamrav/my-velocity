import React, { useContext } from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';
import _ from 'lodash';

import Table from '../../../../components/Table/Table';
import UserContext from '../../../../contexts/UserContext';
import ExpandableCard from '../ExpandableCard/ExpandableCard';
import benefits from '../../../../dictionaries/benefits.json';
import LoungePassPurchased from '../lounge-pass-purchased.svg';
import LoungePassIcon from '../lounge-pass.svg';
import * as userData from '../../../../utils/utilities';

import styles from './LoungePassBenefits.css';

function LoungePassBenefits({ loungeDetails }) {
  const tileStates = {
    buy: 'buy',
    available: 'available',
    usedBuy: 'used-buy',
    usedCantBuy: 'used-cant-buy',
  };

  const voucherType = {
    AMEX: 'Amex lounge voucher',
    FARE: 'Fare Class',
    FOC_VOUCH: 'FOC Voucher',
    MEMBER: 'Lounge Passport Holder',
    PRE_PAID: 'Single Entry Pass',
    TIERED_G: 'Gold tiered Velocity member',
    TIER_CHANGE: 'Silver tiered voucher',
    HSBC: 'HSBC Lounge Voucher',
    VIRGIN_MONEY: 'Virgin Money lounge voucher',
    CASUAL: 'Purchased via GMS',
    LIFETIME: 'Lifetime',
    INFANT: 'Infant',
    CHILD: 'Child',
    GUEST: 'Guest',
    TIERED_V: 'VIP tiered Velocity member',
    TIERED_P: 'Platinum tiered Velocity member',
    CASUAL_PASS: 'Purchased',
    WESTPAC_VOUCH: 'Westpac Lounge Voucher',
    NZ_GOLD: 'Gold tiered Airpoints member',
    NZ_GOLD_ELITE: 'Gold Elite tiered Airpoints member',
    NZ_KORU: 'Koru Club member',
    NZ_SILVER: 'Silver tiered Airpoints member',
    VFFCAMP: 'Velocity Campaign Lounge Pass',
    VABF: 'Virgin Australia Business Flyer Lounge Pass',
  };

  const { user } = useContext(UserContext);
  const now = moment();

  const passesAvailable = _.get(loungeDetails, 'voucherPasses', [])
    .filter(pass => !_.includes(['WESTPAC_VOUCH', 'HSBC'], pass.voucherType)) // Ignore Westpac/HSBC Voucher Types
    .filter(pass => moment(pass.endDate).isSameOrAfter(now));

  const numberPassesAvailable = passesAvailable.reduce(
    (total, pass) => total + parseInt(pass.numberAvailable, 10),
    0,
  );

  const numPassesTotal = passesAvailable.reduce(
    (total, pass) => total + parseInt(pass.numberAvailable, 10) + parseInt(pass.numberUsed, 10),
    0,
  );

  const tierLevel = userData.getTierLevel(user);
  const arePassesAvailable = numberPassesAvailable > 0;
  const hasPassesDataFromApi = !_.isEmpty(loungeDetails.voucherPasses);
  const isRedOrSilverTier = _.includes(['R', 'S'], tierLevel);
  const isRedTier = tierLevel === 'R';

  function getPassTile(tileState, content) {
    const passTableHeader = [
      <span className={styles.passColumn}>Lounge Pass</span>,
      <span className={styles.passColumn}>Type</span>,
      <span className={styles.passColumn}>Expiry Date</span>,
      'Number Available',
    ];
    const hasExpandableContent = tileState === tileStates.available && passesAvailable.length > 0;

    return (
      <ExpandableCard
        analyticsMetadataFromParent={{
          eventCategory: 'member-benefits',
          eventName: 'benefits-cta',
          eventLocation: 'member-benefits',
          panelType: 'benefits',
          tileCategory: 'lounge-passes',
          tileState,
          targeted: 'N',
        }}
        icon={arePassesAvailable ? <LoungePassPurchased /> : <LoungePassIcon />}
        title={content.heading}
        description={content.details}
        counter={arePassesAvailable ? {
          availabilityText: `${numberPassesAvailable} of ${numPassesTotal}`,
          description: 'Lounge passes available',
        } : null}
        expandableContent={hasExpandableContent ? (
          <Table
            hasShadow={false}
            itemsPerPage={500}
            headers={passTableHeader}
            tableClassName={styles.passesTable}
            rows={_.map(passesAvailable, (pass, index) => ({
              uniqueId: `${pass.voucherID}${index}`,
              voucherDisplayLevel: 'Single Entry',
              voucherType: voucherType[pass.voucherType],
              endDate: moment(pass.endDate).format('DD-MM-YYYY'),
              numberAvailable: pass.numberAvailable,
            }))}
          />
        ) : null}
        ctaContainer={!hasExpandableContent ? {
          ctaLabel: content.ctaLabel,
          ctaUrl: content.ctaLink,
        } : null}
        footerContentMobilePadding
      />
    );
  }

  return (
    <>
      {
        !loungeDetails && null
      }

      {
        loungeDetails
        && !hasPassesDataFromApi
        && !isRedTier
        && null
      }

      {
        loungeDetails
        && hasPassesDataFromApi
        && arePassesAvailable
        && getPassTile(tileStates.available, benefits.loungePassesAvailable)
      }

      {
        loungeDetails
        && hasPassesDataFromApi
        && !arePassesAvailable
        && isRedOrSilverTier
        && getPassTile(tileStates.usedBuy, benefits.loungePassesUsedPromote)
      }

      {
        loungeDetails
        && hasPassesDataFromApi
        && !arePassesAvailable
        && !isRedOrSilverTier
        && getPassTile(tileStates.usedCantBuy, benefits.loungePassesUsedNoPromote)
      }
    </>
  );
}

LoungePassBenefits.propTypes = {
  loungeDetails: PropTypes.shape(),
};

LoungePassBenefits.defaultProps = {
  loungeDetails: {},
};

export default LoungePassBenefits;
