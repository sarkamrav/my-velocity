import React from 'react';
import renderer from 'react-test-renderer';

import ExpandableCard, { expandableCardContentId } from './ExpandableCard';
import { render, screen, fireEvent } from '../../../../unitTest/test-utils';

describe('ExpandableCard', () => {
  const componentMockData = {
    className: 'testClassName',
    icon: <img src="#" alt="" id="test-icon" />,
    title: 'test title',
    description: 'test description',
    disclaimer: 'test disclaimer',
    counter: {
      availabilityText: '3 of 9',
      description: 'HSBC Velocity Flight Certificates available',
    },
    readMoreLabel: 'more',
    readLessLabel: 'less',
    expandableContentId: 'test-expandable-content-id',
    expandableContent: <div id="expandable-content">expandableContent</div>,
    analyticsMetadataFromParent: {
      test: 'test',
    },
    footerContentMobilePadding: false,
    ctaContainer: {
      ctaUrl: '#',
      ctaLabel: 'test cta label',
    },
    onExpandButtonClick: jest.fn(),
  };

  it('should render correctly', () => {
    const tree = renderer.create(
      <ExpandableCard {...componentMockData} />,
    ).toJSON();

    expect(tree).toMatchSnapshot();
  });

  describe('Icon', () => {
    const elementId = '#test-icon';

    it('should render Icon if it is provided', () => {
      const { container } = render(<ExpandableCard {...componentMockData} />);

      const element = container.querySelector(elementId);
      expect(element).not.toBeNull();
    });

    it('should NOT render Icon if it is not provided', () => {
      const { container } = render(<ExpandableCard {...{ ...componentMockData, icon: null }} />);

      const element = container.querySelector(elementId);
      expect(element).toBeNull();
    });
  });

  describe('Title', () => {
    const elementClassName = '.mv__src-pages-Dashboard-MyBenefits-ExpandableCard-ExpandableCard_title';

    it('should render title if it is provided', () => {
      const { container } = render(<ExpandableCard {...componentMockData} />);

      const element = container.querySelector(elementClassName);
      expect(element.textContent).toBe(componentMockData.title);
    });

    it('should NOT render title if it is not provided', () => {
      const { container } = render(<ExpandableCard {...{ ...componentMockData, title: '' }} />);

      const element = container.querySelector(elementClassName);
      expect(element).toBeNull();
    });
  });

  describe('Description', () => {
    const elementClassName = '.mv__src-pages-Dashboard-MyBenefits-ExpandableCard-ExpandableCard_content'
      + ' .mv__src-pages-Dashboard-MyBenefits-ExpandableCard-ExpandableCard_description';

    it('should render title if it is provided', () => {
      const { container } = render(<ExpandableCard {...componentMockData} />);
      const element = container.querySelector(elementClassName);
      expect(element.textContent).toBe(componentMockData.description);
    });

    it('should NOT render description if it is not provided', () => {
      const { container } = render(<ExpandableCard {...{ ...componentMockData, description: '' }} />);
      const element = container.querySelector(elementClassName);
      expect(element).toBeNull();
    });
  });

  describe('Disclaimer', () => {
    const elementClassName = '.mv__src-pages-Dashboard-MyBenefits-ExpandableCard-ExpandableCard_emphasis';

    it('should render disclaimer if it is provided', () => {
      const { container } = render(<ExpandableCard {...componentMockData} />);
      const element = container.querySelector(elementClassName);
      expect(element.textContent).toBe(componentMockData.disclaimer);
    });

    it('should NOT render disclaimer if it is not provided', () => {
      const { container } = render(<ExpandableCard {...{ ...componentMockData, title: '', description: '', disclaimer: '' }} />);
      const element = container.querySelector(elementClassName);
      expect(element).toBeNull();
    });
  });

  describe('Counter', () => {
    const elementClassName = '.mv__src-pages-Dashboard-MyBenefits-ExpandableCard-ExpandableCard_counter';

    it('should render counter if it is provided', () => {
      const { container } = render(<ExpandableCard {...componentMockData} />);
      const element = container.querySelector(elementClassName);
      expect(element).not.toBeNull();
    });

    it('should NOT render counter if it is not provided', () => {
      const { container } = render(<ExpandableCard {...{ ...componentMockData, counter: null }} />);
      const element = container.querySelector(elementClassName);
      expect(element).toBeNull();
    });

    it('should render proper counter text', () => {
      const { container } = render(<ExpandableCard {...{ ...componentMockData }} />);
      const element = container.querySelector('.mv__src-pages-Dashboard-MyBenefits-ExpandableCard-ExpandableCard_badge');
      expect(element.textContent).toBe('3 of 9');
    });

    it('should render proper counter description', () => {
      const { container } = render(<ExpandableCard {...{ ...componentMockData }} />);
      const element = container.querySelector('.mv__src-pages-Dashboard-MyBenefits-ExpandableCard-ExpandableCard_counter .mv__src-pages-Dashboard-MyBenefits-ExpandableCard-ExpandableCard_description');
      expect(element.textContent).toBe(componentMockData.counter.description);
    });
  });

  describe('Action column', () => {
    const elementClassName = '.mv__src-components-MoreButton-MoreButton_container';

    describe('with expandableContent', () => {
      it('should render read more button', () => {
        const { container } = render(<ExpandableCard {...componentMockData} />);
        const element = container.querySelector(elementClassName);
        expect(element).not.toBeNull();
      });

      it('should expand expandableContent on read more button clicked', () => {
        const { container } = render(<ExpandableCard {...componentMockData} />);
        const button = screen.getByRole('button', { expanded: false });
        fireEvent.click(button);
        const expandedContent = container.querySelector('.mv__src-pages-Dashboard-MyBenefits-ExpandableCard-ExpandableCard_viewMore');
        expect(expandedContent).not.toBeNull();
      });

      it('should call callback function if it is provided', () => {
        render(<ExpandableCard {...componentMockData} />);
        const button = screen.getByRole('button', { expanded: false });
        fireEvent.click(button);
        expect(componentMockData.onExpandButtonClick).toHaveBeenCalledTimes(1);
      });
    });

    describe('without expandableContent', () => {
      it('should NOT render read more button', () => {
        const { container } = render(<ExpandableCard {...{ ...componentMockData, expandableContent: null }} />);
        const element = container.querySelector(elementClassName);
        expect(element).toBeNull();
      });

      it('should NOT render action column button if no ctaContainer', () => {
        const { container } = render(<ExpandableCard {...{ ...componentMockData, expandableContent: null, ctaContainer: null }} />);
        const element = container.querySelector('.mv__src-pages-Dashboard-MyBenefits-ExpandableCard-ExpandableCard_actions');
        expect(element).toBeNull();
      });

      it('should render CTA if ctaContainer is provided', () => {
        const { container } = render(<ExpandableCard {...{ ...componentMockData, expandableContent: null }} />);
        const element = container.querySelector('.mv__src-components-Button-Button_buttonType--red-link');
        expect(element.textContent.trim()).toBe(componentMockData.ctaContainer.ctaLabel);
      });
    });
  });

  describe('expandableContentId', () => {
    it('should auto generate expandableContentId', () => {
      const { container } = render(<ExpandableCard {...{ ...componentMockData, expandableContentId: null }} />);
      const button = screen.getByRole('button', { expanded: false });
      const footer = container.querySelector('.mv__src-pages-Dashboard-MyBenefits-ExpandableCard-ExpandableCard_footer');
      expect(button.getAttribute('aria-controls')).toEqual(expect.stringContaining(expandableCardContentId));
      expect(footer.id).toEqual(expect.stringContaining(expandableCardContentId));
    });
  });
});
