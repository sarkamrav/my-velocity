import React, { useState, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import isEmpty from 'lodash/isEmpty';
import noop from 'lodash/noop';
import uniqueId from 'lodash/uniqueId';

import RichTextContent from '../../../../components/RichTextContent/RichTextContent';
import MoreButton from '../../../../components/MoreButton/MoreButton';
import A from '../../../../components/Button/A';

import styles from './ExpandableCard.css';

export const expandableCardContentId = 'expandable-card_';

function ExpandableCard({
  className,
  icon,
  expandableContent,
  expandableContentId,
  title,
  description,
  disclaimer,
  counter,
  ctaContainer,
  analyticsMetadataFromParent,
  onExpandButtonClick,
  footerContentMobilePadding,
  readMoreLabel,
  readLessLabel,
}) {
  const [showMoreDetails, setShowMoreDetails] = useState(false);
  const [contentId] = useState(expandableContentId || (() => uniqueId(expandableCardContentId)));
  const handleToggleDetails = useCallback(() => setShowMoreDetails(prev => !prev), [setShowMoreDetails]);

  function getActionColumn(content) {
    return (
      <div className={styles.actions}>
        {content}
      </div>
    );
  }

  useEffect(() => {
    if (showMoreDetails && onExpandButtonClick) {
      onExpandButtonClick();
    }
  }, [showMoreDetails]);

  return (
    <div
      className={cx(styles.container, className)}
      analytics-metadata={JSON.stringify(analyticsMetadataFromParent)}
    >
      <div className={styles.card}>
        {
          icon && (
            <div className={styles.imageContainer}>
              {icon}
            </div>
          )
        }

        {
          (title || description || disclaimer) && (
            <div className={styles.content}>
              {title && <span className={styles.title}>{title}</span>}
              {description && <RichTextContent className={styles.description} content={description} />}
              {disclaimer && <span className={styles.emphasis}>{disclaimer}</span>}
            </div>
          )
        }

        {
          !isEmpty(counter) && (
            <div className={styles.counter}>
              { counter.availabilityText && <div className={styles.badge}>{counter.availabilityText}</div> }
              <span className={styles.description}>{counter.description}</span>
            </div>
          )
        }

        {
          expandableContent && getActionColumn(
            <MoreButton
              isShowingMore={showMoreDetails}
              readMoreLabel={readMoreLabel}
              readLessLabel={readLessLabel}
              displayMode="dark"
              contentId={contentId}
              onClick={handleToggleDetails}
            />,
          )
        }

        {
          !expandableContent && !isEmpty(ctaContainer)
            && getActionColumn(
              <A
                buttonType="red-link"
                href={ctaContainer.ctaUrl}
                className={styles.cta}
                target="_blank"
                ctaAsLink
              >
                {ctaContainer.ctaLabel}
              </A>,
            )
        }
      </div>

      {
        expandableContent && (
          <div
            id={contentId}
            className={cx(styles.footer, {
              [styles.viewMore]: showMoreDetails,
            })}
          >
            <div
              className={cx(styles.footerContent, {
                [styles.mobilePadding]: footerContentMobilePadding,
              })}
            >
              {expandableContent}
            </div>
          </div>
        )
      }
    </div>
  );
}

ExpandableCard.propTypes = {
  icon: PropTypes.node,
  expandableContent: PropTypes.node,
  title: PropTypes.string,
  description: PropTypes.string,
  disclaimer: PropTypes.string,
  counter: PropTypes.shape({
    availabilityText: PropTypes.string,
    description: PropTypes.string,
  }),
  ctaContainer: PropTypes.shape({
    ctaUrl: PropTypes.string,
    ctaLabel: PropTypes.string,
  }),
  analyticsMetadataFromParent: PropTypes.shape({}),
  className: PropTypes.string,
  onExpandButtonClick: PropTypes.func,
  expandableContentId: PropTypes.string,
  footerContentMobilePadding: PropTypes.bool,
  readMoreLabel: PropTypes.string,
  readLessLabel: PropTypes.string,
};

ExpandableCard.defaultProps = {
  icon: null,
  expandableContent: null,
  title: '',
  description: '',
  disclaimer: '',
  counter: {},
  ctaContainer: {},
  analyticsMetadataFromParent: {},
  className: '',
  expandableContentId: '',
  onExpandButtonClick: noop,
  footerContentMobilePadding: false,
  readMoreLabel: 'Read more',
  readLessLabel: 'Read less',
};

export default ExpandableCard;
