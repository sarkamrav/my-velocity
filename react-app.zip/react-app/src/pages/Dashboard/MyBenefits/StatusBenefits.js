import React, { useContext } from 'react';
import benefits from '../../../dictionaries/benefits.json';
import A from '../../../components/Button/A';
import RedIcon from './red-status.svg';
import SilverIcon from './silver-status.svg';
import GoldIcon from './gold-status.svg';
import UserContext from '../../../contexts/UserContext';
import { getTier } from '../../../utils/statusCredits';
import * as userData from '../../../utils/utilities';
import styles from './MyBenefits.css';

export default function StatusBenefits() {
  const { user } = useContext(UserContext);

  let tileCategory = 'content';
  let content;
  let Image;

  switch (getTier(userData.getMainTierInfo(user))) {
    case 'Red':
      content = benefits.benefitsOfStatusRed;
      Image = RedIcon;
      tileCategory = 'start-earning-status';
      break;
    case 'Silver':
      content = userData.getSubTierLevel(user) === 'H'
        ? benefits.benefitsOfStatusExtensionSilver
        : benefits.benefitsOfStatusSilver;
      Image = SilverIcon;
      break;
    case 'Explore Gold':
    case 'Pilot Gold':
    case 'Trial Gold':
    case 'Discover Gold':
      content = benefits.benefitsOfStatusDiscoverGold;
      Image = GoldIcon;
      break;
    default:
      return null;
  }

  return (
    <div
      className={styles.wrapper}
      analytics-metadata={JSON.stringify({
        eventCategory: 'member-benefits',
        eventName: 'benefits-cta',
        eventLocation: 'member-benefits',
        panelType: 'benefits',
        tileCategory,
        targeted: 'N',
      })}
    >
      <div className={styles.card}>
        <div className={styles.imageContainer}>
          <Image className={styles.image} />
        </div>
        <div className={styles.content}>
          <span className={styles.title}>{content.heading}</span>
          <span className={styles.description}>{content.details}</span>
        </div>
        <div className={styles.actions}>
          <A buttonType="red-link" href={content.ctaLink} className={styles.cta} ctaAsLink>{content.ctaLabel}</A>
        </div>
      </div>
    </div>
  );
}
