import React, { useState, useRef, useContext, useCallback } from 'react';
import PropTypes from 'prop-types';
import get from 'lodash/get';
import find from 'lodash/find';
import isEmpty from 'lodash/isEmpty';
import cx from 'classnames';

import Radio from '../../../../components/Form/Radio/Radio';
import Checkbox from '../../../../components/Form/Checkbox/Checkbox';
import Input from '../../../../components/Form/Input/Input';
import Button from '../../../../components/Button/Button';
import FormFieldSet, { formFieldGroupTheme } from '../../../../components/Form/FormFieldSet/FormFieldSet';
import Modal from '../../../../components/Modal/Modal';
import InformationAlert, { informationAlertTheme } from '../../../../components/InformationAlert/InformationAlert';
import RichTextContent from '../../../../components/RichTextContent/RichTextContent';
import * as validators from '../../../../components/Form/validators';
import { validateFormField } from '../../../../components/Form/utils';
import { scrollToRef } from '../../../../utils/common';
import { getApiActionName, getApiError, newRelicSection, sendToNewRelic } from '../../../../utils/newRelic';
import UserContext from '../../../../contexts/UserContext';
import * as userData from '../../../../utils/utilities';

import styles from './BenefitOptInForm.css';

function BenefitOptInForm({ eligibleBenefit }) {
  const successAlertRef = useRef();
  const errorAlertRef = useRef();

  const formFieldNames = {
    selectedPartnerName: 'selectedPartnerName',
    areYouExistingMember: 'areYouExistingMember',
    membershipId: 'membershipId',
    partnerTnc: 'partnerTnc',
    velocityTnc: 'velocityTnc',
  };

  const areYouExistingMemberYesValue = 'yes';

  const initialFormValues = {
    [formFieldNames.selectedPartnerName]: '',
    [formFieldNames.areYouExistingMember]: '',
    [formFieldNames.membershipId]: '',
    [formFieldNames.partnerTnc]: false,
    [formFieldNames.velocityTnc]: false,
  };

  const fieldValidators = {
    [formFieldNames.selectedPartnerName]: [validators.required()],
    [formFieldNames.areYouExistingMember]: [validators.required()],
    [formFieldNames.membershipId]: [validators.required()],
    [formFieldNames.partnerTnc]: [validators.required()],
    [formFieldNames.velocityTnc]: [validators.required()],
  };

  const [values, setValues] = useState(initialFormValues);
  const [errors, setErrors] = useState({});
  const [touchedFields, setTouchedFields] = useState({});
  const [apiLoading, setApiLoading] = useState(false);
  const [apiError, setApiError] = useState('');
  const [apiResponse, setApiResponse] = useState({});
  const [isModalVisible, setIsModalVisible] = useState(false);
  const partnerBenefitList = get(eligibleBenefit, 'partnerBenefitList', []);
  const { user } = useContext(UserContext);

  function setTouchField(fieldName) {
    setTouchedFields(prevState => ({
      ...prevState,
      [fieldName]: true,
    }));
  }

  function setFieldValue(fieldName, fieldValue) {
    setValues(prevState => ({
      ...prevState,
      [fieldName]: fieldValue,
    }));
  }

  function setFieldError(fieldName, errorMessage) {
    setErrors(prevState => ({
      ...prevState,
      [fieldName]: errorMessage,
    }));
  }

  function updateFieldErrorMessage(fieldName, fieldValue) {
    const errorMessage = validateFormField(fieldValue, fieldValidators[fieldName]);

    if (errorMessage) {
      setFieldError(fieldName, errorMessage);
    } else {
      setFieldError(fieldName, '');
    }
  }

  const handleFieldChange = useCallback((e) => {
    const fieldName = get(e, 'target.name', '');
    const fieldType = get(e, 'target.type', '');
    const fieldValue = fieldType === 'checkbox'
      ? get(e, 'target.checked', '')
      : get(e, 'target.value', '');

    setFieldValue(fieldName, fieldValue);

    if (touchedFields[fieldName]) {
      updateFieldErrorMessage(fieldName, fieldValue);
    }
  }, [touchedFields, setValues, setErrors]);

  function getFieldValue(e, stateValue) {
    switch (get(e, 'target.type', '')) {
      case 'checkbox':
        return get(e, 'target.checked', '');
      case 'radio':
        return stateValue;
      default:
        return get(e, 'target.value', '');
    }
  }

  const handleBlur = useCallback((e) => {
    const fieldName = get(e, 'target.name', '');
    const fieldValue = getFieldValue(e, values[fieldName]);

    updateFieldErrorMessage(fieldName, fieldValue);

    if (!touchedFields[fieldName]) {
      setTouchField(fieldName);
    }
  }, [touchedFields, setTouchedFields, setErrors, values]);

  async function submitForm(formValues) {
    const compPartnerMembershipsApiUri = '/loyalty/v2/benefits/comp-partner-memberships';

    try {
      const benefitProgramID = get(find(partnerBenefitList, { name: formValues.selectedPartnerName }), 'programId', '');
      const isExistingProgramMember = formValues.areYouExistingMember === areYouExistingMemberYesValue;

      const payload = {
        data: {
          membershipId: userData.getLoyaltyMembershipID(user),
          tierLevelCode: eligibleBenefit.tierLevelCode,
          benefit: {
            programId: benefitProgramID,
            type: eligibleBenefit.benefitType,
            existingProgram: {
              member: isExistingProgramMember,
              ...(isExistingProgramMember ? { memberId: formValues.membershipId } : {}),
            },
          },
        },
      };
      setApiLoading(true);
      const response = await window.vffCoreWebsite.coreApi.vffV2Api.post(compPartnerMembershipsApiUri, payload);

      setApiResponse(response.data);
      setApiLoading(false);
      scrollToRef(successAlertRef, 20);
    } catch (e) {
      setApiLoading(false);
      setApiError('Sorry we\'re having issues with our system. Please try again.');

      if (errorAlertRef.current) {
        errorAlertRef.current.focus();
      }

      sendToNewRelic(
        getApiActionName(window.vffCoreWebsite.coreApi.vffV2Api.defaults.baseURL, compPartnerMembershipsApiUri),
        getApiError(newRelicSection.benefitOptInForm, e),
      );
    }
  }

  const handleSubmit = useCallback((e) => {
    e.preventDefault();

    const partnerErrorMessage = validateFormField(values[formFieldNames.selectedPartnerName], fieldValidators[formFieldNames.selectedPartnerName]);
    const existingMemberErrorMessage = validateFormField(values[formFieldNames.areYouExistingMember], fieldValidators[formFieldNames.areYouExistingMember]);
    const membershipIdErrorMessage = values[formFieldNames.areYouExistingMember] === areYouExistingMemberYesValue
      ? validateFormField(values[formFieldNames.membershipId], fieldValidators[formFieldNames.membershipId])
      : '';
    const partnerTncErrorMessage = validateFormField(values[formFieldNames.partnerTnc], fieldValidators[formFieldNames.partnerTnc]);
    const velocityTncErrorMessage = validateFormField(values[formFieldNames.velocityTnc], fieldValidators[formFieldNames.velocityTnc]);

    if (partnerErrorMessage || existingMemberErrorMessage || membershipIdErrorMessage || partnerTncErrorMessage || velocityTncErrorMessage) {
      setErrors(prevState => ({
        ...prevState,
        [formFieldNames.selectedPartnerName]: partnerErrorMessage,
        [formFieldNames.areYouExistingMember]: existingMemberErrorMessage,
        [formFieldNames.membershipId]: membershipIdErrorMessage,
        [formFieldNames.partnerTnc]: partnerTncErrorMessage,
        [formFieldNames.velocityTnc]: velocityTncErrorMessage,
      }));

      setTouchedFields(prevState => ({
        ...prevState,
        [formFieldNames.selectedPartnerName]: true,
        [formFieldNames.areYouExistingMember]: true,
        [formFieldNames.membershipId]: true,
        [formFieldNames.partnerTnc]: true,
        [formFieldNames.velocityTnc]: true,
      }));
    } else {
      submitForm(values);
    }
  }, [eligibleBenefit, setErrors, setTouchedFields, values]);

  function showModal(e) {
    e.preventDefault();
    setIsModalVisible(true);
  }

  const closeModal = useCallback(() => setIsModalVisible(false), [setIsModalVisible]);

  function getSecondStepForm(partnerInfo) {
    const areYouExistingMemberField = [
      { label: partnerInfo.noLabel, value: 'no' },
      { label: partnerInfo.yesLabel, value: areYouExistingMemberYesValue },
    ];

    return (
      <>
        {
          partnerInfo.title && (
            <RichTextContent className={styles.title} content={partnerInfo.title} />
          )
        }

        {
          partnerInfo.description && (
            <div className={styles.description}>
              <RichTextContent className={styles.descriptionRichText} content={partnerInfo.description} />
              <button className={styles.modalButton} onClick={showModal}>
                <RichTextContent content={partnerInfo.modalButtonText} />
              </button>
            </div>
          )
        }

        {
          partnerInfo.questionText && <RichTextContent className={styles.question} content={partnerInfo.questionText} />
        }

        <FormFieldSet
          label={partnerInfo.questionText}
          theme={formFieldGroupTheme.radioImageButton}
          className={styles.fieldSet}
          error={errors[formFieldNames.areYouExistingMember]}
          isLabelVisuallyHidden
        >
          {
            areYouExistingMemberField.map((field) => (
              <Radio
                key={field.label}
                name={formFieldNames.areYouExistingMember}
                label={field.label}
                value={field.value}
                checked={values.areYouExistingMember === field.value}
                onChange={handleFieldChange}
                onBlur={handleBlur}
              />
            ))
          }
        </FormFieldSet>

        {
          values.areYouExistingMember === areYouExistingMemberYesValue && (
            <>
              <div className={styles.notification}>
                <RichTextContent className={styles.notificationDescription} content={partnerInfo.helpText} />
              </div>

              <Input
                className={styles.membershipId}
                label={partnerInfo.textFieldLabel}
                name={formFieldNames.membershipId}
                onChange={handleFieldChange}
                onBlur={handleBlur}
                value={values[formFieldNames.membershipId]}
                error={errors[formFieldNames.membershipId]}
              />
            </>
          )
        }

        <Checkbox
          containerClassName={styles.checkbox}
          labelClassName={styles.checkboxLabel}
          name={formFieldNames.partnerTnc}
          size="large"
          label={partnerInfo.termsAndConditions}
          error={errors[formFieldNames.partnerTnc]}
          onChange={handleFieldChange}
          onBlur={handleBlur}
          checked={!!values[formFieldNames.partnerTnc]}
        />

        <Checkbox
          containerClassName={styles.checkbox}
          labelClassName={styles.checkboxLabel}
          name={formFieldNames.velocityTnc}
          size="large"
          label={eligibleBenefit.termsAndConditions}
          error={errors[formFieldNames.velocityTnc]}
          onChange={handleFieldChange}
          onBlur={handleBlur}
          checked={!!values[formFieldNames.velocityTnc]}
        />

        <Button
          onClick={handleSubmit}
          buttonType="secondary"
          loading={apiLoading}
        >
          Submit
        </Button>
      </>
    );
  }

  const selectedPartner = partnerBenefitList.find(partner => partner.name === values.selectedPartnerName);

  return (
    <>
      {
        <InformationAlert
          ref={successAlertRef}
          status={informationAlertTheme.success}
          className={cx(styles.successAlert, {
            [styles.hidden]: isEmpty(apiResponse),
          })}
          icon="tickCircleSolid"
          tabIndex={!isEmpty(apiResponse) ? -1 : null}
          description={
            <RichTextContent
              content={`You've successfully opted-in to the <b>${get(apiResponse, 'opted[0].partner.programTier', '')}</b> of the <b>${get(apiResponse, 'opted[0].partner.name', '')}</b> program.`}
            />
          }
        />
      }

      {
        isEmpty(apiResponse) && (
          <form className={styles.container}>
            {
              eligibleBenefit.longDescription && <RichTextContent className={styles.formDescription} content={eligibleBenefit.longDescription} />
            }

            <FormFieldSet
              label="Please select membership into your preferred program"
              className={styles.fieldSet}
              theme={formFieldGroupTheme.radioImageButton}
              error={errors[formFieldNames.selectedPartnerName]}
            >
              {
                partnerBenefitList.map((partner) => (
                  <Radio
                    key={partner.name}
                    className={styles.partnerRadioButton}
                    name={formFieldNames.selectedPartnerName}
                    id={partner.name}
                    label={partner.name}
                    value={partner.name}
                    checked={values.selectedPartnerName === partner.name}
                    onChange={handleFieldChange}
                    onBlur={handleBlur}
                    imageUrl={partner.logoUrl}
                  />
                ))
              }
            </FormFieldSet>

            {
              selectedPartner && getSecondStepForm(selectedPartner)
            }

            <InformationAlert
              ref={errorAlertRef}
              tabIndex={apiError ? -1 : null}
              className={cx(styles.errorAlert, {
                [styles.hidden]: !apiError,
              })}
              status={informationAlertTheme.danger}
              icon="exclamationCircleSolid"
              description={apiError}
            />
          </form>
        )
      }

      {
        isModalVisible && (
          <Modal onDismiss={closeModal} aria-label="benefits">
            <div className={styles.benefitsModal}>
              {
                selectedPartner.logoUrl && <img className={styles.modalLogo} alt="" src={selectedPartner.logoUrl} />
              }

              {
                selectedPartner?.modalDescription && <RichTextContent content={selectedPartner?.modalDescription} />
              }
            </div>
          </Modal>
        )
      }
    </>
  );
}

BenefitOptInForm.propTypes = {
  eligibleBenefit: PropTypes.shape({
    benefitType: PropTypes.string,
    termsAndConditions: PropTypes.string,
    longDescription: PropTypes.string,
    membershipId: PropTypes.string,
    tierLevelCode: PropTypes.string,
  }),
};

BenefitOptInForm.defaultProps = {
  eligibleBenefit: {
    benefitType: '',
    termsAndConditions: '',
    longDescription: '',
    membershipId: '',
    tierLevelCode: '',
  },
};

export default BenefitOptInForm;
