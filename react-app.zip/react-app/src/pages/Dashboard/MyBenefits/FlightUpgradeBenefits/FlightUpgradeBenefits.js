import React, { useContext } from 'react';
import PropTypes from 'prop-types';
import isEmpty from 'lodash/isEmpty';
import get from 'lodash/get';
import filter from 'lodash/filter';
import some from 'lodash/some';
import moment from 'moment';

import FlightUpgradeIcon from '../flight-upgrade.svg';
import BenefitTile from '../BenefitTile/BenefitTile';
import WebsiteContext from '../../../../contexts/WebsiteContext';
import { useApi } from '../../../../utils/api';
import ExpandableCard from '../ExpandableCard/ExpandableCard';
import { flightUpgradeInfo } from '../common';
import CreditTable from '../components/flightUpgrade/CreditTable/CreditTable';
import RedemptionTable from '../components/flightUpgrade/RedemptionTable/RedemptionTable';
import {
  flightUpgradeContentDescription,
  flightUpgradeDescription,
  flightUpgradeDescriptionUsed,
} from '../../../../dictionaries/constants';

function FlightUpgradeBenefits({ mainTierInfo, awardCreditDetails }) {
  const websiteData = useContext(WebsiteContext);
  const platinumFlightUpgradesJsObjectKey = get(websiteData, 'children.benefits.:items.platinumFlightUpgrades.tileCards.0.jsObjectKey', '');
  const platinumFlightUpgrades = window.vffCoreWebsite[platinumFlightUpgradesJsObjectKey];
  const awardCreditDetailsData = get(awardCreditDetails, 'awardCredits', []);
  const now = moment();

  const startDate = moment().subtract(1, 'year').format('YYYY-MM-DD');
  const endDate = moment().format('YYYY-MM-DD');
  const redeemedAwardCreditsUri = `/loyalty/v2/experience/benefits/me/redeemedAwardCredits?startDate=${startDate}&endDate=${endDate}&benefitCode=BCUV&benefitCode=BCPU`;

  const { data } = useApi(redeemedAwardCreditsUri, {
    endpoint: 'vffV2Api',
  });

  const redeemedFlightUpgradesAwardCredits = get(data, 'data', []);

  const standardFlightUpgrade = flightUpgradeInfo(
    awardCreditDetailsData,
    redeemedFlightUpgradesAwardCredits,
    ['BCPU'],
  );

  const vipBrandedFlightUpgrade = flightUpgradeInfo(
    awardCreditDetailsData,
    redeemedFlightUpgradesAwardCredits,
    ['BCUV', 'BCUPV', 'BCUNV'],
  );

  const hasCovidFlightUpgradeForPlatinumTier = some(
    awardCreditDetailsData,
    award => filter(award?.available, availableData => moment(availableData.expiresAt).isSameOrAfter(now)) && ['BCEBG', 'BCUEFP'].includes(award.code),
  );

  function getCardUi(upgradeInfo, title, description) {
    return (upgradeInfo.hasFlightUpgradesAwardCredits || upgradeInfo.hasRedeemedFlightUpgrades) && (
      <ExpandableCard
        icon={<FlightUpgradeIcon />}
        title="Complimentary Flight Upgrades"
        description={upgradeInfo.hasRemainingCredits ? flightUpgradeDescription : flightUpgradeDescriptionUsed}
        analyticsMetadataFromParent={{
          eventCategory: 'member-benefits',
          eventName: 'benefits-cta',
          eventLocation: 'member-benefits',
          panelType: 'benefits',
          tileCategory: 'flight-upgrade',
          tileState: upgradeInfo.hasRemainingCredits ? 'unused' : 'used',
          targeted: 'N',
        }}
        counter={{
          description: `${upgradeInfo.remainingCredits} Flight upgrades available`,
        }}
        expandableContent={
          <>
            <CreditTable title={title} description={description} upgradeInfo={upgradeInfo} />
            <RedemptionTable upgradeInfo={upgradeInfo} />
          </>
        }
      />
    );
  }

  const isPlatinumMember = mainTierInfo?.tierLevel === 'P';

  return (
    <>
      {
        isPlatinumMember
        && hasCovidFlightUpgradeForPlatinumTier
        && !isEmpty(platinumFlightUpgrades)
        && (
          <BenefitTile
            {...platinumFlightUpgrades}
            image={get(platinumFlightUpgrades, 'renditions.imageDefault', '')}
          />
        )
      }

      {
        getCardUi(
          standardFlightUpgrade,
          isPlatinumMember
            ? flightUpgradeContentDescription
            : 'To request a complimentary fare upgrade from a Freedom fare (fare classes Y, B, H, K) please contact our Membership Contact Centre on 13 18 75 in Australia, 0800 230 875 in New Zealand or +61 2 8667 5924 internationally.',
          isPlatinumMember
            ? '1. In each Benefit Period, Platinum members who have paid the full fare for an Economy Flex fare are entitled to a complimentary upgrade to Business class on up to 4 Virgin Australia marketed and operated domestic or International short-haul Flight Sectors (Upgrade). Members can also use their complimentary upgrades for guests travelling with them on the same flight, when booked in a Flex fare. Request an upgrade any time after you have booked your flight, up to two hours prior to scheduled departure time by contacting the <a href="https://experience.velocityfrequentflyer.com/member-support" target="_blank" rel="noopener noreferrer">Membership Contact Centre</a>. Requests can be made at any Virgin Australia Lounge or if departing from Hobart at Priority Check-in. Request any same-day upgrade on Virgin Australia operated Domestic flights up to 30 minutes prior to scheduled flight departure time. Upgrades are subject to Business Class Reward Seat availability and to the <a href="https://experience.velocityfrequentflyer.com/member-support/terms-conditions" target="_blank" rel="noopener noreferrer">Upgrade Cancellation and Amendment Policy.</a>.'
            : '1. Members are entitled to limited complimentary fare upgrades per membership year from a Freedom fare (fare classes Y, B, H, K) to a Business Class seat on Domestic, Trans Tasman or International Short Haul flights marketed and operated by Virgin Australia. Members can also use their complimentary upgrades for guests travelling with them on the same flight. Request an upgrade any time after you have booked your flight, up to two hours prior to scheduled departure time by contacting the <a href="https://experience.velocityfrequentflyer.com/member-support" target="_blank" rel="noopener noreferrer">Membership Contact Centre.</a>. Requests can be made at any Virgin Australia Lounge or if departing from Hobart at Priority Check-in. Request any same-day upgrade on Virgin Australia operated Domestic flights up to 30 minutes prior to scheduled flight departure time. Upgrades are subject to Business Class Reward Seat availability and to the <a href="https://experience.velocityfrequentflyer.com/member-support/terms-conditions" target="_blank" rel="noopener noreferrer">Upgrade Cancellation and Amendment Policy.</a>',
        )
      }

      {
        getCardUi(
          vipBrandedFlightUpgrade,
          '<p>To request a Complimentary Fare Upgrade from a Flex or Choice fare, please contact your dedicated Virgin Australia Beyond team during opening hours on 1800 041 404 in Australia or +61 7 3295 5621 internationally.</p>',
          '1. Virgin Australia Beyond members are entitled to limited Complimentary Fare Upgrades per membership year from a Flex or Choice fare to a Business Class fare on Virgin Australia marketed and operated domestic and international short haul flights (excluding Christmas Island and Cocos Island). Beyond Members can also use their Complimentary Fare Upgrades for guests travelling with them on the same flight. Upgrades can be redeemed by calling the Virgin Australia Beyond team, either at the time of booking or to upgrade an existing booking. Upgrade requests may be made anytime up to 60 minutes prior to the departure of the nominated flight. Upgrades are subject to the availability of seats assigned for upgrades by Virgin Australia. Some flights may have no upgrades available.',
        )
      }
    </>
  );
}

FlightUpgradeBenefits.propTypes = {
  mainTierInfo: PropTypes.shape({
    tierLevel: PropTypes.string,
  }),
  awardCreditDetails: PropTypes.shape({}),
};

FlightUpgradeBenefits.defaultProps = {
  mainTierInfo: {},
  awardCreditDetails: {},
};

export default FlightUpgradeBenefits;
