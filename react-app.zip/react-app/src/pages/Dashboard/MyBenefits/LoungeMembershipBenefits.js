import React, { useContext } from 'react';
import PropTypes from 'prop-types';
import get from 'lodash/get';
import includes from 'lodash/includes';
import moment from 'moment';

import benefits from '../../../dictionaries/benefits.json';
import A from '../../../components/Button/A';
import LoungeMembershipIcon from './lounge-membership.svg';
import UserContext from '../../../contexts/UserContext';
import RichTextContent from '../../../components/RichTextContent/RichTextContent';
import * as userData from '../../../utils/utilities';

import styles from './MyBenefits.css';

function processDataForDisplay(data, dateString) {
  return dateString ? ({
    ...data,
    details: `${data.details} <b>Valid until ${dateString}</b>`,
  }) : data;
}

function LoungeMembershipBenefits({ loungeDetails }) {
  const { user } = useContext(UserContext);

  if (!loungeDetails) {
    return null;
  }

  const purchaseStates = ['Cancelled', 'Refunded', 'Pending', 'Removed'];
  const purchasedStates = ['OK', 'Transferred'];
  const status = get(loungeDetails, 'loungeMemberships[0].status');
  const loungeMembershipEndDate = get(loungeDetails, 'loungeMemberships[0].endDate');
  const endDate = loungeMembershipEndDate ? moment(loungeMembershipEndDate).format('DD MMMM YYYY') : '';

  let tileState = 'purchase';
  let content = benefits.membershipPurchase;
  switch (userData.getTierLevel(user)) {
    case 'R':
      if (includes(purchaseStates, status)) {
        content = benefits.membershipPurchase;
        tileState = 'purchase';
      } else if (includes(purchasedStates, status)) {
        content = processDataForDisplay(benefits.membershipPurchased, endDate);
        tileState = 'purchased';
      }
      break;
    case 'S':
      if (includes(purchaseStates, status)) {
        content = benefits.membershipPurchaseDiscounted;
        tileState = 'purchase-discounted';
      } else if (includes(purchasedStates, status)) {
        content = processDataForDisplay(benefits.membershipPurchased, endDate);
        tileState = 'purchased';
      }
      break;
    case 'G':
    case 'P':
    case 'V':
      if (get(loungeDetails, 'entitledLoungeAccess.membershipNumber')) {
        content = benefits.membershipComplimentary;
        tileState = 'complimentary';
      }
      break;
    default:
      // Hide tile
      return null;
  }

  return (
    <div
      className={styles.wrapper}
      analytics-metadata={JSON.stringify({
        eventCategory: 'member-benefits',
        eventName: 'benefits-cta',
        eventLocation: 'member-benefits',
        panelType: 'benefits',
        tileCategory: 'lounge-membership',
        tileState,
        targeted: 'N',
      })}
    >
      <div className={styles.card}>
        <div className={styles.imageContainer}>
          <LoungeMembershipIcon className={styles.image} />
        </div>
        <div className={styles.content}>
          <span className={styles.title}>{content.heading}</span>
          <RichTextContent className={styles.description} content={content.details} />
        </div>
        <div className={styles.actions}>
          <A buttonType="red-link" href={content.ctaLink} className={styles.cta} target="_blank" ctaAsLink>{content.ctaLabel}</A>
        </div>
      </div>
    </div>
  );
}

LoungeMembershipBenefits.propTypes = {
  loungeDetails: PropTypes.shape(),
};

LoungeMembershipBenefits.defaultProps = {
  loungeDetails: {},
};

export default LoungeMembershipBenefits;
