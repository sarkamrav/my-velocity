import moment from 'moment';
import filter from 'lodash/filter';
import reduce from 'lodash/reduce';
import isEmpty from 'lodash/isEmpty';

export function flightUpgradeInfo(awardCredits, redeemedAwardCredits, awardCreditTypes) {
  const now = moment();

  // Filters the award credits data based on the code
  const flightUpgradesAwardCredits = filter(
    awardCredits,
    award => awardCreditTypes.includes(award.code),
  );

  // Filters the award credits data based on the expiresAt date validity in the available set data of the award credits
  const filterAvailableAwardCredits = reduce(
    flightUpgradesAwardCredits,
    (result, flightUpgradesAwardCreditsData) => [
      ...result,
      ...(filter(flightUpgradesAwardCreditsData?.available, availableData => moment(availableData.expiresAt).isSameOrAfter(now))),
    ],
    [],
  );

  // redeemedAwardCredits do the filtering
  const redeemedFlightUpgradesAwardCredits = filter(
    redeemedAwardCredits,
    award => awardCreditTypes.includes(award.code),
  );

  // Sums up the totalAvailable redemptions and displays the same
  const remainingCredits = reduce(
    flightUpgradesAwardCredits,
    (total, award) => total + award.totalAvailable,
    0,
  );

  const hasRemainingCredits = remainingCredits > 0;
  const hasRedeemedFlightUpgrades = !isEmpty(redeemedFlightUpgradesAwardCredits);
  const hasFlightUpgradesAwardCredits = !isEmpty(filterAvailableAwardCredits);

  return ({
    filterAvailableAwardCredits,
    redeemedFlightUpgradesAwardCredits,
    remainingCredits,
    hasRemainingCredits,
    hasRedeemedFlightUpgrades,
    hasFlightUpgradesAwardCredits,
  });
}
