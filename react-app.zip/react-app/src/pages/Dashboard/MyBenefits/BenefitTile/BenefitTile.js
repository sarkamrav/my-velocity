import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import A from '../../../../components/Button/A';
import RichTextContent from '../../../../components/RichTextContent/RichTextContent';

import styles from './BenefitTile.css';

function BenefitTile({ title, description, image, ctaContainer }) {
  return (
    <div
      className={styles.wrapper}
    >
      <div className={styles.card}>
        {
          !!image && (
            <div className={styles.imageContainer}>
              <img className={styles.image} src={image} alt="" />
            </div>
          )
        }
        <div className={styles.content}>
          <span className={styles.title}>{title}</span>
          <RichTextContent className={styles.description} content={description} />
        </div>

        {
          !_.isEmpty(ctaContainer) && ctaContainer.ctaLabel && (
            <div className={styles.actions}>
              <A
                title={ctaContainer.ctaTitle}
                buttonType={ctaContainer.ctaStyle}
                href={ctaContainer.ctaUrl}
                ctaAsLink={ctaContainer.ctaAsLink}
                className={styles.cta}
                target={ctaContainer.ctaOpenInNewTab ? '_blank' : ''}
              >
                {ctaContainer.ctaLabel}
              </A>
            </div>
          )
        }

      </div>
    </div>
  );
}

BenefitTile.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
  image: PropTypes.string,
  ctaContainer: PropTypes.shape({
    ctaTitle: PropTypes.string,
    ctaLabel: PropTypes.string,
    ctaUrl: PropTypes.string,
    ctaStyle: PropTypes.string,
    ctaAsLink: PropTypes.bool,
    ctaOpenInNewTab: PropTypes.bool,
  }),
};

BenefitTile.defaultProps = {
  title: '',
  description: '',
  image: '',
  ctaContainer: {},
};

export default BenefitTile;
