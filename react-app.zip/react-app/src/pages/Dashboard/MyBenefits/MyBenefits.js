import React, { useContext, useEffect } from 'react';
import _ from 'lodash';
import { useApi } from '../../../utils/api';
import UserContext from '../../../contexts/UserContext';
import LoungeMembershipBenefits from './LoungeMembershipBenefits';
import LoungePassBenefits from './LoungePassBenefits/LoungePassBenefits';
import StatusBenefits from './StatusBenefits';
import { getTier } from '../../../utils/statusCredits';
import FlightUpgradeBenefits from './FlightUpgradeBenefits/FlightUpgradeBenefits';
import ComplimentaryBenefits from './ComplimentaryBenefits/ComplimentaryBenefits';
import CardEconomyXBenefits from './CardEconomyXBenefits';
import CardLoungePassBenefits from './CardLoungePassBenefits';
import GoldAwardCredits from './GoldAwardCredits';
import * as userData from '../../../utils/utilities';
import BusinessFlightUpgradeBenefit from './BusinessFlightUpgradeBenefit/BusinessFlightUpgradeBenefit';
import { applyOffers } from '../../../utils/target';

import styles from './MyBenefits.css';

export default function MyBenefits() {
  const { user } = useContext(UserContext);

  const { data } = useApi('/loyalty/v2/experience/benefits/me', {
    endpoint: 'vffV2Api',
  });

  const {
    awardCreditDetails,
    certificateDetails,
    compPartnerBenefitDetails: complimentaryPartnerBenefitDetails,
    loungeDetails,
  } = _.get(data, 'data', {});

  const mainTierInfo = userData.getMainTierInfo(user);
  const periodicTierInfo = userData.getPeriodicTierInfo(user);
  const periodicTierLevel = userData.getPeriodicTierLevel(user);

  useEffect(() => {
    applyOffers();
  }, []);

  function renderBenefits() {
    switch (getTier(mainTierInfo)) {
      case 'Red':
        return (
          <>
            <LoungeMembershipBenefits loungeDetails={loungeDetails} />
            <LoungePassBenefits loungeDetails={loungeDetails} />
            <StatusBenefits />
          </>
        );
      case 'Silver':
        return (
          <>
            <LoungeMembershipBenefits loungeDetails={loungeDetails} />
            <LoungePassBenefits loungeDetails={loungeDetails} />
            <StatusBenefits />
          </>
        );
      case 'Discover Gold':
      case 'Explore Gold':
      case 'Pilot Gold':
      case 'Trial Gold':
        return (
          <>
            <LoungeMembershipBenefits loungeDetails={loungeDetails} />
            <LoungePassBenefits loungeDetails={loungeDetails} />
            <StatusBenefits />
          </>
        );
      case 'Gold':
        return (
          <>
            <LoungeMembershipBenefits loungeDetails={loungeDetails} />
            <LoungePassBenefits loungeDetails={loungeDetails} />
            <ComplimentaryBenefits mainTierInfo={mainTierInfo} complimentaryPartnerBenefitDetails={complimentaryPartnerBenefitDetails} />
          </>
        );
      case 'Platinum':
        return (
          <>
            <LoungeMembershipBenefits loungeDetails={loungeDetails} />
            <FlightUpgradeBenefits mainTierInfo={mainTierInfo} awardCreditDetails={awardCreditDetails} />
            <LoungePassBenefits loungeDetails={loungeDetails} />
            <ComplimentaryBenefits mainTierInfo={mainTierInfo} complimentaryPartnerBenefitDetails={complimentaryPartnerBenefitDetails} />
          </>
        );
      case 'VIP':
        return (
          <>
            <LoungeMembershipBenefits loungeDetails={loungeDetails} />
            <FlightUpgradeBenefits mainTierInfo={mainTierInfo} awardCreditDetails={awardCreditDetails} />
            <LoungePassBenefits loungeDetails={loungeDetails} />
            <ComplimentaryBenefits mainTierInfo={mainTierInfo} complimentaryPartnerBenefitDetails={complimentaryPartnerBenefitDetails} />
          </>
        );
      default:
        return null;
    }
  }

  return (
    <div className={styles.container}>
      <div className={styles.contentContainer}>
        <h3 className={styles.heading}>My Benefits</h3>

        {
          renderBenefits()
        }

        {
          periodicTierLevel === 'G' && <GoldAwardCredits mainTierInfo={periodicTierInfo} awardCreditDetails={awardCreditDetails} />
        }

        <BusinessFlightUpgradeBenefit awardCreditDetails={awardCreditDetails} />
        <CardEconomyXBenefits certificateDetails={certificateDetails} />
        <CardLoungePassBenefits loungeDetails={loungeDetails} />
      </div>
    </div>
  );
}
