import React from 'react';
import PropTypes from 'prop-types';
import WestpacLoungePassBenefits from './WestpacLoungePassBenefits';
import HsbcLoungePassBenefits from './HsbcLoungePassBenefits';

function CardLoungePassBenefits({ loungeDetails }) {
  return (
    <>
      <WestpacLoungePassBenefits loungeDetails={loungeDetails} />
      <HsbcLoungePassBenefits loungeDetails={loungeDetails} />
    </>
  );
}

CardLoungePassBenefits.propTypes = {
  loungeDetails: PropTypes.shape(),
};

CardLoungePassBenefits.defaultProps = {
  loungeDetails: null,
};

export default CardLoungePassBenefits;
