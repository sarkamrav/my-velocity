import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import WestpacEconomyXBenefits from './WestpacEconomyXBenefits';
import HsbcEconomyXBenefits from './HsbcEconomyXBenefits';

export default function CardEconomyXBenefits({ certificateDetails }) {
  return (
    <>
      <WestpacEconomyXBenefits certificates={_.filter(_.get(certificateDetails, 'certificates'), { partner: 'WESTPAC', type: 'ECONMX' })} />
      <HsbcEconomyXBenefits certificates={_.filter(_.get(certificateDetails, 'certificates'), { partner: 'HSBC', type: 'FLIGHT' })} />
    </>
  );
}

CardEconomyXBenefits.propTypes = {
  certificateDetails: PropTypes.shape({}),
};

CardEconomyXBenefits.defaultProps = {
  certificateDetails: {},
};
