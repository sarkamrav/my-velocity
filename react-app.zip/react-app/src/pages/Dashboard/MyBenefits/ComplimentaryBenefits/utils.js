import moment from 'moment';
import find from 'lodash/find';
import map from 'lodash/map';
import get from 'lodash/get';
import reduce from 'lodash/reduce';
import findIndex from 'lodash/findIndex';
import syncText from '../../../../utils/common';

export function getAuthorDataForBenefit(benefit, authorData) {
  if (!benefit || !authorData) {
    return null;
  }

  const hasFoundAuthorDataForAllPrograms = reduce(benefit.partners, (accumulator, program) => {
    const programIndex = findIndex(authorData.partnerBenefitList, {
      benefitPartnerName: program.name,
      benefitProgramTier: program.programTier,
    });

    return programIndex !== -1 && accumulator;
  }, true);

  return hasFoundAuthorDataForAllPrograms ? ({
    ...benefit,
    ...authorData,
    partnerBenefitList: map(benefit.partners, program => {
      const programAuthorData = find(authorData.partnerBenefitList, {
        benefitPartnerName: program.name,
        benefitProgramTier: program.programTier,
      });

      return programAuthorData ? { ...program, ...programAuthorData } : program;
    }),
  }) : null;
}

export function getAcceptedCardDescription(text, benefit) {
  return syncText(text, {
    dateOptedIn: moment(benefit.optInDate).format('DD MMMM YYYY'),
    benefitProgramTier: get(benefit, 'partner.programTier'),
    benefitPartnerName: get(benefit, 'partner.name'),
  });
}

export function getEligibleCardDescription(text, benefit) {
  return syncText(text, {
    benefitPartnerNameA: get(benefit, 'partners[0].name'),
    benefitPartnerNameB: get(benefit, 'partners[1].name'),
  });
}
