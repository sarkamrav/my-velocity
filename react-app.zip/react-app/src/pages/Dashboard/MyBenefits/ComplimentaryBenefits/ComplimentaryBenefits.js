import React from 'react';
import find from 'lodash/find';
import get from 'lodash/get';
import PropTypes from 'prop-types';

import CarHireBenefits from './CarHireBenefits';
import HotelMembershipBenefits from './HotelMembershipBenefits';

export const complimentaryBenefitType = {
  car: 'C',
  hotel: 'H',
};

function ComplimentaryBenefits({ mainTierInfo, complimentaryPartnerBenefitDetails }) {
  function getBenefit(partnerBenefits, benefitType) {
    return find(partnerBenefits, {
      benefitType,
    });
  }

  function getAcceptedBenefit(acceptedPartnerBenefits, benefitType) {
    return find(
      acceptedPartnerBenefits,
      benefit => get(benefit, 'benefitType') === benefitType,
    );
  }

  const { eligible, opted } = complimentaryPartnerBenefitDetails;
  const carEligibleBenefit = getBenefit(eligible, complimentaryBenefitType.car);
  const acceptedCarBenefit = getAcceptedBenefit(opted, complimentaryBenefitType.car);
  const hotelEligibleBenefit = getBenefit(eligible, complimentaryBenefitType.hotel);
  const acceptedHotelBenefit = getAcceptedBenefit(opted, complimentaryBenefitType.hotel);

  return (
    <>
      <CarHireBenefits
        acceptedBenefit={acceptedCarBenefit}
        eligibleBenefit={carEligibleBenefit}
        mainTierInfo={mainTierInfo}
      />
      <HotelMembershipBenefits
        acceptedBenefit={acceptedHotelBenefit}
        eligibleBenefit={hotelEligibleBenefit}
        mainTierInfo={mainTierInfo}
      />
    </>
  );
}

ComplimentaryBenefits.propTypes = {
  mainTierInfo: PropTypes.shape({}),
  complimentaryPartnerBenefitDetails: PropTypes.shape({
    eligible: PropTypes.arrayOf(PropTypes.shape({})),
    opted: PropTypes.arrayOf(PropTypes.shape({})),
  }),
};

ComplimentaryBenefits.defaultProps = {
  mainTierInfo: null,
  complimentaryPartnerBenefitDetails: {
    eligible: [],
    opted: [],
  },
};

export default ComplimentaryBenefits;
