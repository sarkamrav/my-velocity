import React, { useContext } from 'react';
import PropTypes from 'prop-types';
import isEmpty from 'lodash/isEmpty';
import get from 'lodash/get';

import ExpandableCard from '../ExpandableCard/ExpandableCard';
import HotelMembershipIcon from './hotel-membership.svg';
import BenefitOptInForm from '../BenefitOptInForm/BenefitOptInForm';
import { getAuthorDataForBenefit, getAcceptedCardDescription, getEligibleCardDescription } from './utils';
import WebsiteContext from '../../../../contexts/WebsiteContext';

function HotelMembershipBenefits({ acceptedBenefit, eligibleBenefit, mainTierInfo }) {
  const websiteData = useContext(WebsiteContext);
  const hasAcceptedBenefit = !isEmpty(acceptedBenefit);
  const hotelMembershipAuthorDataPath = {
    G: 'children.benefits.:items.hotelMembershipGold',
    V: 'children.benefits.:items.hotelMembershipVIP',
    P: 'children.benefits.:items.hotelMembershipPlatinum',
  };
  const memberCurrentTierCode = get(mainTierInfo, 'tierLevel');
  const hotelMembershipAuthorData = get(websiteData, hotelMembershipAuthorDataPath[memberCurrentTierCode], null);
  const benefitWithAuthorData = getAuthorDataForBenefit(eligibleBenefit, hotelMembershipAuthorData);

  return hotelMembershipAuthorData && (hasAcceptedBenefit || benefitWithAuthorData) && (
    <ExpandableCard
      icon={hotelMembershipAuthorData.logoUrl ? <img src={hotelMembershipAuthorData.logoUrl} alt="" /> : <HotelMembershipIcon />}
      title={hotelMembershipAuthorData.title}
      description={hasAcceptedBenefit
        ? getAcceptedCardDescription(hotelMembershipAuthorData.existingMemberDescription, acceptedBenefit)
        : getEligibleCardDescription(hotelMembershipAuthorData.description, eligibleBenefit)}
      analyticsMetadataFromParent={{
        eventCategory: 'member-benefits',
        eventName: 'benefits-cta',
        eventLocation: 'member-benefits',
        panelType: 'benefits',
        tileCategory: 'hotel-membership',
        tileState: hasAcceptedBenefit ? 'used' : 'unused',
        targeted: 'N',
      }}
      readMoreLabel={hotelMembershipAuthorData.readMoreLabel}
      readLessLabel={hotelMembershipAuthorData.readLessLabel}
      expandableContent={hasAcceptedBenefit ? null : <BenefitOptInForm eligibleBenefit={benefitWithAuthorData} />}
    />
  );
}

HotelMembershipBenefits.propTypes = {
  acceptedBenefit: PropTypes.shape({}),
  eligibleBenefit: PropTypes.shape({}),
  mainTierInfo: PropTypes.shape({}),
};

HotelMembershipBenefits.defaultProps = {
  acceptedBenefit: null,
  eligibleBenefit: null,
  mainTierInfo: null,
};

export default HotelMembershipBenefits;
