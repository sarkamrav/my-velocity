import React, { useContext } from 'react';
import PropTypes from 'prop-types';
import isEmpty from 'lodash/isEmpty';
import get from 'lodash/get';

import WebsiteContext from '../../../../contexts/WebsiteContext';
import BenefitOptInForm from '../BenefitOptInForm/BenefitOptInForm';
import ExpandableCard from '../ExpandableCard/ExpandableCard';
import CarHireIcon from './car-hire.svg';
import { getAcceptedCardDescription, getAuthorDataForBenefit, getEligibleCardDescription } from './utils';

function CarHireBenefits({ acceptedBenefit, eligibleBenefit, mainTierInfo }) {
  const websiteData = useContext(WebsiteContext);
  const hasAcceptedBenefit = !isEmpty(acceptedBenefit);
  const carHireAuthorDataPath = {
    G: 'children.benefits.:items.carHireMembershipGold',
    V: 'children.benefits.:items.carHireMembershipVIP',
    P: 'children.benefits.:items.carHireMembershipPlatinum',
  };
  const memberCurrentTierCode = get(mainTierInfo, 'tierLevel');
  const carHireAuthorData = get(websiteData, carHireAuthorDataPath[memberCurrentTierCode], null);
  const benefitWithAuthorData = getAuthorDataForBenefit(eligibleBenefit, carHireAuthorData);

  return carHireAuthorData && (hasAcceptedBenefit || benefitWithAuthorData) && (
    <ExpandableCard
      icon={carHireAuthorData.logoUrl ? <img src={carHireAuthorData.logoUrl} alt="" /> : <CarHireIcon />}
      title={carHireAuthorData.title}
      description={hasAcceptedBenefit
        ? getAcceptedCardDescription(carHireAuthorData.existingMemberDescription, acceptedBenefit)
        : getEligibleCardDescription(carHireAuthorData.description, eligibleBenefit)}
      analyticsMetadataFromParent={{
        eventCategory: 'member-benefits',
        eventName: 'benefits-cta',
        eventLocation: 'member-benefits',
        panelType: 'benefits',
        tileCategory: 'car-passes',
        tileState: hasAcceptedBenefit ? 'used' : 'unused',
        targeted: 'N',
      }}
      readMoreLabel={carHireAuthorData.readMoreLabel}
      readLessLabel={carHireAuthorData.readLessLabel}
      expandableContent={hasAcceptedBenefit ? null : <BenefitOptInForm eligibleBenefit={benefitWithAuthorData} />}
    />
  );
}

CarHireBenefits.propTypes = {
  acceptedBenefit: PropTypes.shape({}),
  eligibleBenefit: PropTypes.shape({}),
  mainTierInfo: PropTypes.shape({}),
};

CarHireBenefits.defaultProps = {
  acceptedBenefit: null,
  eligibleBenefit: null,
  mainTierInfo: null,
};

export default CarHireBenefits;
