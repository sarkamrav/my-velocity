import React, { useState, useRef, useContext, useEffect } from "react";
import { Link, Switch, Route, Redirect, useLocation } from "react-router-dom";
import cx from "classnames";
import _ from "lodash";
import moment from "moment";
import isEmpty from "lodash/isEmpty";
import get from "lodash/get";
import { DateTime } from "luxon";
import MyActivity from "./MyActivity/MyActivity";
import MyStatus from "./MyStatus/MyStatus";
import UserContext from "../../contexts/UserContext";
import DashboardContext from "./DashboardContext";
import ExperienceActivitiesContext from "./experienceActivitiesContext";
import {
  formatMembershipNumber,
  getQueryParameter,
  isEnableVipTier,
  scrollToRef,
  analyticsEventName,
  serverTimeZone,
} from "../../utils/common";
import OverviewCard from "./OverviewCard";
import UpcomingFlightCard from "./UpcomingFlightCard/UpcomingFlightCard";
import WebsiteContext from "../../contexts/WebsiteContext";
import InformationAlert, {
  informationAlertTheme,
} from "../../components/InformationAlert/InformationAlert";
import TargetedCard from "../../fragments/TargetedCard/TargetedCard";
import RichTextContent from "../../components/RichTextContent/RichTextContent";
import Icon from "../../components/Icon/Icon";
import MyOffers from "./MyOffers/MyOffers";
import status from "../../dictionaries/status.json";
import A from "../../components/Button/A";
import Badge from "../../components/Badge/Badge";
import MyBenefits from "./MyBenefits/MyBenefits";
import HorizontalScroll from "../../components/HorizontalScroll/HorizontalScroll";
import {
  getApiActionName,
  getApiError,
  sendToNewRelic,
} from "../../utils/newRelic";
import { useApi } from "../../utils/api";
import * as userData from "../../utils/utilities";
import Modal, { modalTheme } from "../../components/Modal/Modal";
import TwoColumnTile from "../../components/Modal/components/TwoColumnTile/TwoColumnTile";
import CelebrationModal from "./CelebrationModal/CelebrationModal";
import styles from "./Dashboard.css";
import { setCookie, getCookie } from "../../utils/cookies";

export default function Dashboard() {
  const tabsRef = useRef();
  const carouselRef = useRef();

  const [carouselScroll, setCarouselScroll] = useState({});
  const [apiOffers, setApiOffers] = useState([]);

  const websiteData = useContext(WebsiteContext);
  const { user } = useContext(UserContext);
  const loyaltyMembershipID = userData.getLoyaltyMembershipID(user);
  const dashboardData = userData.getDashboardData(user);
  const joinYear = moment(userData.getJoinDate(user)).format("YYYY");
  const mainTierInfo = userData.getMainTierInfo(user);
  const firstname = userData?.getFirstName(user);
  const lastname = userData?.getLastName(user);

  const celebrationModalInfo = get(websiteData, ":items.celebrationModal");

  const location = useLocation();

  const startDate = moment().subtract(3, "year").format("YYYY-MM-DD");
  const endDate = moment().format("YYYY-MM-DD");
  const summaryStartDate = moment().startOf("month").format("YYYY-MM-DD");
  const summaryEndDate = moment().endOf("month").format("YYYY-MM-DD");
  const autoShowWelcomeModal =
    getQueryParameter("welcome-modal", location.search) === "show";

  const [isWelcomeModalVisible, setIsWelcomeModalVisible] =
    useState(autoShowWelcomeModal);
  const [isCelebrationModalVisible, setIsCelebrationModalVisible] =
    useState(true);

  const { tierLevel, previousTierInfo, validityStartDate } = mainTierInfo;

  const memberUpgradeTierDate = DateTime.fromISO(
    validityStartDate,
    serverTimeZone
  ).startOf("day");

  const celebrationModalExpiryDate = memberUpgradeTierDate
    .plus({ days: 60 })
    .endOf("day");

  const currentDate = DateTime.fromObject({}, serverTimeZone);

  const isCelebrationModalExpired = currentDate > celebrationModalExpiryDate;

  const mainTierInfoObj = {
    R: 1,
    S: 2,
    G: 3,
    P: 4,
  };

  const isCookieExist = getCookie("isCelebrationModelClosed");

  const isTierDownGraded =
    mainTierInfoObj[tierLevel] < mainTierInfoObj[previousTierInfo?.tierLevel];

  const isEligibleForCelebration =
    !!mainTierInfoObj[tierLevel] &&
    !!mainTierInfoObj[previousTierInfo?.tierLevel];

  const { clickCta } = analyticsEventName;

  useEffect(() => {
    async function loadTotalAvailableOffer() {
      try {
        let contentOffers = [];
        const response = await window.vffCoreWebsite.coreApi.vffV2Api.get(
          "/loyalty/v2/promotions/registrations",
          {
            params: {
              excludeBAUOffers: true,
            },
          }
        );
        const responseData = _.get(response, "data.data", []);
        const aemOffers = _.filter(responseData, (responseOffer) =>
          _.includes(["REGISTRABLE"], responseOffer.registrationStatus)
        );
        if (_.size(aemOffers) > 0) {
          const contentResponse =
            await window.vffCoreWebsite.coreApi.aemApi.get(
              `/api/v1/activated-offers/_jcr_content.promoCode${
                _.size(aemOffers) > 0
                  ? `-${_(aemOffers).map("promotionCode").join("_")}`
                  : ""
              }.webmodel.json`
            );
          contentOffers = _.get(contentResponse, "data.activatedoffers", []);
        }

        setApiOffers(
          _(responseData)
            .filter((responseOffer) =>
              _.some(contentOffers, { promoCode: responseOffer.promotionCode })
            )
            .map((responseOffer) => ({
              ...responseOffer,
              ..._.find(contentOffers, {
                promoCode: responseOffer.promotionCode,
              }),
            }))
            .value()
        );
      } catch (e) {
        sendToNewRelic(getApiActionName(), getApiError("dashboard", e));
      }
    }

    loadTotalAvailableOffer();
  }, []);

  const {
    data: activitiesData,
    loading,
    error,
  } = useApi("/loyalty/v2/experience/activities/me", {
    endpoint: "vffV2Api",
    options: {
      params: {
        startDate,
        endDate,
        pageOffset: 0,
        pageLimit: 10,
        include: "summary",
        summaryStartDate,
        summaryEndDate,
      },
    },
  });

  const availableApiOffers = _.filter(
    apiOffers,
    (offer) => offer.registrationStatus === "REGISTRABLE"
  );
  const availableOffers = _.get(
    websiteData,
    "children.offers.:items.offers.offers.length",
    0
  );
  const totalAvailableOffers = _.size(availableApiOffers) + availableOffers;

  const bannerTileCards = _.get(
    websiteData,
    ":items.banner.tiles.tileCards",
    []
  );
  const hidePointsExpiryNotification = _.get(
    websiteData,
    ":items.banner.hidePointsExpiryNotification",
    false
  );

  const bannerBackgroundImage = _.last(
    _.values(_.get(websiteData, ":items.banner.renditions", {}).imagesSet)
  );
  const vipBannerBackgroundImage = _.last(
    _.values(
      _.get(websiteData, ":items.banner.renditionsForVipTier", {}).imagesSet
    )
  );
  const isVipTierLevel = userData.getTierLevel(user) === "V";
  const shouldShowVipBackground = isVipTierLevel && vipBannerBackgroundImage;
  const bannerStyle = shouldShowVipBackground
    ? { backgroundImage: `url(${vipBannerBackgroundImage})` }
    : { backgroundImage: `url(${bannerBackgroundImage})` };

  useEffect(() => {
    setCarouselScroll({
      scrollLeft: carouselRef.current.scrollLeft,
      scrollWidth: carouselRef.current.scrollWidth,
      clientWidth: carouselRef.current.clientWidth,
    });
  }, []);

  function handleScrollCarousel(e) {
    setCarouselScroll({
      scrollLeft: e.target.scrollLeft,
      scrollWidth: e.target.scrollWidth,
      clientWidth: e.target.clientWidth,
    });
  }

  function getAnalytics(analytics = {}, stringify = false) {
    const statusSection = _.find(dashboardData, {
      sectionReference: "yourStatus",
    });

    const combinedAnalytics = {
      memberStatusState: statusSection
        ? `${_.get(statusSection, "panels[0].category")} - ${_.get(
            statusSection,
            "panels[0].state"
          )}, ${_.get(statusSection, "panels[1].category")} - ${_.get(
            statusSection,
            "panels[1].state"
          )}`
        : undefined,
      ...analytics,
    };

    if (stringify) {
      return JSON.stringify(combinedAnalytics);
    }

    return combinedAnalytics;
  }

  const vipCaption =
    shouldShowVipBackground &&
    _.get(websiteData, ":items.banner.vipTierImageCaption");
  const caption =
    vipCaption || _.get(websiteData, ":items.banner.imageCaption");
  const isNewVipDesignEnabled = isEnableVipTier();
  const welcomeModalData = _.get(websiteData, ":items.welcomeModal");

  const closeCelebrationModel = () => {
    if (!isCookieExist) {
      const cbPopupopClosingTime = DateTime.fromObject(
        {},
        serverTimeZone
      ).endOf("day");
      const cookieExpiryTime = celebrationModalExpiryDate.diff(
        cbPopupopClosingTime,
        ["minutes"]
      );
      setCookie(
        "isCelebrationModelClosed",
        true,
        cookieExpiryTime?.values?.minutes
      );
    }
    setIsCelebrationModalVisible(false);
  };

  return (
    <DashboardContext.Provider
      value={{
        dashboard: dashboardData,
        getAnalytics,
      }}
    >
      <ExperienceActivitiesContext.Provider
        value={{
          data: activitiesData,
          loading,
          error,
        }}
      >
        <div className={styles.wrapper}>
          {!isEmpty(celebrationModalInfo) &&
            isCelebrationModalVisible &&
            isEligibleForCelebration &&
            !isCelebrationModalExpired &&
            !isTierDownGraded &&
            !isCookieExist && (
              <Modal
                onDismiss={closeCelebrationModel}
                theme={modalTheme.fullPageView}
                withCloseButton
                aria-label="Welcome to Celebration Modal"
              >
                <CelebrationModal
                  firstname={firstname}
                  lastname={lastname}
                  mainTierInfo={mainTierInfo}
                  celebrationModalInfo={celebrationModalInfo}
                />
              </Modal>
            )}
          <div className={styles.banner} style={bannerStyle}>
            <section className={cx(styles.container, styles.welcomeSection)}>
              <span className={styles.welcome}>
                Hello{" "}
                {_.map(
                  _.split(_.toLower(userData.getFirstName(user)), " "),
                  (word) => _.upperFirst(word)
                ).join(" ")}
              </span>
              <span className={styles.memberNo}>
                {formatMembershipNumber(loyaltyMembershipID)}
                <span className={styles.pipeDivider}>|</span>
                Member since {joinYear}
              </span>
              <div
                className={styles.overview}
                ref={carouselRef}
                onScroll={handleScrollCarousel}
              >
                <div
                  className={cx(styles.card, {
                    [styles.vipCardBackground]:
                      isVipTierLevel && isNewVipDesignEnabled,
                    [styles.darkBackground]:
                      userData.getSubTierLevel(user) === "P" ||
                      (isVipTierLevel && !isNewVipDesignEnabled),
                  })}
                >
                  <OverviewCard
                    scrollToTabs={() => scrollToRef(tabsRef)}
                    hidePointsExpiryNotification={hidePointsExpiryNotification}
                  />
                </div>
                <div className={cx(styles.card, styles.inverted)}>
                  <UpcomingFlightCard
                    analyticsMetadataFromParent={_.get(
                      websiteData,
                      ":items.banner.analyticsMetadataMap"
                    )}
                  />
                </div>
                {_.map(bannerTileCards, (tileCard) => (
                  <div
                    key={tileCard.jsObjectKey}
                    className={cx(styles.card, styles.inverted)}
                  >
                    <TargetedCard
                      tileTitle={_.get(
                        websiteData,
                        ":items.banner.tiles.title"
                      )}
                      defaultTargetActivity={
                        window.vffCoreWebsite[tileCard.jsObjectKey]
                      }
                      mboxDefinition={tileCard.mboxDefinition}
                      analyticsData={{
                        eventLocation: "myVelocityHeaderContentTile",
                      }}
                    />
                  </div>
                ))}
              </div>

              <div className={styles.bottomControl}>
                <div className={styles.captionContainer}>
                  {caption ? (
                    <>
                      <Icon name="camera" size={24} className={styles.icon} />
                      <RichTextContent
                        content={caption}
                        className={styles.caption}
                      />
                    </>
                  ) : null}
                </div>

                <div
                  className={cx(styles.chevronControl, {
                    [styles.visible]:
                      carouselScroll.scrollWidth > carouselScroll.clientWidth,
                  })}
                >
                  <button
                    className={styles.chevronButton}
                    disabled={carouselScroll.scrollLeft === 0}
                    onClick={() =>
                      carouselRef.current.scrollTo({
                        left: carouselScroll.scrollLeft - 358,
                        behavior: "smooth",
                      })
                    }
                  >
                    <Icon
                      name="chevron"
                      size={14}
                      className={cx(styles.chevron, styles.inverted)}
                    />
                  </button>
                  <button
                    className={styles.chevronButton}
                    disabled={
                      carouselScroll.scrollLeft + carouselScroll.clientWidth ===
                      carouselScroll.scrollWidth
                    }
                    onClick={() =>
                      carouselRef.current.scrollTo({
                        left: carouselScroll.scrollLeft + 358,
                        behavior: "smooth",
                      })
                    }
                  >
                    <Icon name="chevron" size={14} className={styles.chevron} />
                  </button>
                </div>
              </div>

              <HorizontalScroll className={styles.horizontalScroll}>
                <div className={styles.tabs} ref={tabsRef}>
                  <Link
                    className={cx(styles.tab, {
                      [styles.selected]: _.startsWith(
                        location.pathname,
                        websiteData.children.activity.pageUrl
                      ),
                    })}
                    to={websiteData.children.activity.pageUrl}
                    title={websiteData.children.activity.title}
                    analytics-metadata={getAnalytics(
                      {
                        eventCategory: "tabs",
                        eventName: "tab-selection",
                        eventLocation: "my-velocity",
                        moduleSelected: websiteData.children.activity.pageName,
                        moduleSelectedText: websiteData.children.activity.title,
                      },
                      true
                    )}
                  >
                    {websiteData.children.activity.title}
                  </Link>
                  <Link
                    className={cx(styles.tab, {
                      [styles.selected]: _.startsWith(
                        location.pathname,
                        websiteData.children.status.pageUrl
                      ),
                    })}
                    to={websiteData.children.status.pageUrl}
                    title={websiteData.children.status.title}
                    analytics-metadata={getAnalytics(
                      {
                        eventCategory: "tabs",
                        eventName: "tab-selection",
                        eventLocation: "my-velocity",
                        moduleSelected: websiteData.children.status.pageName,
                        moduleSelectedText: websiteData.children.status.title,
                      },
                      true
                    )}
                  >
                    {websiteData.children.status.title}
                  </Link>
                  <Link
                    className={cx(styles.tab, {
                      [styles.selected]: _.startsWith(
                        location.pathname,
                        websiteData.children.benefits.pageUrl
                      ),
                    })}
                    to={websiteData.children.benefits.pageUrl}
                    title={websiteData.children.benefits.title}
                    analytics-metadata={getAnalytics(
                      {
                        eventCategory: "tabs",
                        eventName: "tab-selection",
                        eventLocation: "my-velocity",
                        moduleSelected: websiteData.children.benefits.pageName,
                        moduleSelectedText: websiteData.children.benefits.title,
                      },
                      true
                    )}
                  >
                    {websiteData.children.benefits.title}
                  </Link>
                  <Link
                    className={cx(styles.tab, {
                      [styles.selected]: _.startsWith(
                        location.pathname,
                        websiteData.children.offers.pageUrl
                      ),
                      [styles.hasOffer]: totalAvailableOffers,
                    })}
                    to={websiteData.children.offers.pageUrl}
                    title={websiteData.children.offers.title}
                    analytics-metadata={getAnalytics(
                      {
                        eventCategory: "tabs",
                        eventName: "tab-selection",
                        eventLocation: "my-velocity",
                        moduleSelected: websiteData.children.offers.pageName,
                        moduleSelectedText: websiteData.children.offers.title,
                      },
                      true
                    )}
                  >
                    {websiteData.children.offers.title}
                    {!!totalAvailableOffers && (
                      <Badge
                        className={styles.offerBadge}
                        number={totalAvailableOffers}
                      />
                    )}
                  </Link>
                </div>
              </HorizontalScroll>
            </section>

            {isWelcomeModalVisible && !isEmpty(welcomeModalData) && (
              <Modal
                onDismiss={() => setIsWelcomeModalVisible(false)}
                theme={modalTheme.v2}
                withCloseButton={false}
                aria-label="Welcome to my velocity"
              >
                <TwoColumnTile
                  title={welcomeModalData.title}
                  description={welcomeModalData.description}
                  imageUrl={welcomeModalData.imageRef}
                  imageAlt={welcomeModalData.imageAlt}
                  modalLinks={welcomeModalData.modalLinkTiles}
                  closeModalLabel={welcomeModalData.closeModalLabel}
                  onModalClose={() => setIsWelcomeModalVisible(false)}
                  analyticsMetadataFromParent={getAnalytics(
                    {
                      eventCategory: "modals",
                      eventName: clickCta,
                      eventElementName: "welcomeModal",
                    },
                    true
                  )}
                />
              </Modal>
            )}
          </div>

          <section className={cx(styles.container, styles.content)}>
            {userData.getNearingExpiryDate(user) &&
            !hidePointsExpiryNotification ? (
              <InformationAlert
                status={informationAlertTheme.danger}
                icon="clock"
                title={`Your Points are due to expire in ${moment(
                  userData.getCurrentPointsBalanceExpiryDate(user)
                )
                  .endOf("day")
                  .diff(moment(), "days")} days`}
                description={status.expiryContent}
                cta={
                  <A href={status.expiryLinkDestination} buttonType="secondary">
                    {status.expiryLink}
                  </A>
                }
                analyticsMetadataFromParent={getAnalytics(
                  {
                    eventCategory: "cta-links",
                    eventLocation: "expiryNotification",
                    eventName: "cta-interaction",
                  },
                  true
                )}
              />
            ) : null}
            <Switch>
              <Route
                exact
                path={websiteData.children.activity.pageUrl}
                component={MyActivity}
              />
              <Route
                exact
                path={websiteData.children.status.pageUrl}
                component={MyStatus}
              />
              <Route
                exact
                path={websiteData.children.benefits.pageUrl}
                component={MyBenefits}
              />
              <Route
                exact
                path={websiteData.children.offers.pageUrl}
                component={MyOffers}
              />
              <Redirect to={websiteData.children.activity.pageUrl} />
            </Switch>
          </section>
        </div>
      </ExperienceActivitiesContext.Provider>
    </DashboardContext.Provider>
  );
}
