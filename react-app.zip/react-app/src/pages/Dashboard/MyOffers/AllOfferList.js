import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';

/* eslint-disable react/destructuring-assignment */
function AllOfferList(props) {
  const { offers } = props;

  useEffect(() => {
    window.vffCoreWebsite = {
      ...window.vffCoreWebsite,
      'aolist_my-velocity': {
        ...props,
        offers: _.compact(_.map(offers, card => (card ? { ...window.vffCoreWebsite[card.jsObjectKey], ...card } : null))),
      },
    };

    window.bootstrapComponent('aem-all-offer-list', 'aolist_my-velocity');
  }, []);

  return (
    <div aem-all-offer-list="aolist_my-velocity" />
  );
}

AllOfferList.propTypes = {
  offers: PropTypes.arrayOf(PropTypes.shape()),
};

AllOfferList.defaultProps = {
  offers: [],
};

export default AllOfferList;
