import React, { useContext } from 'react';
import _ from 'lodash';
import { Helmet } from 'react-helmet';
import AllOfferList from './AllOfferList';
import WebsiteContext from '../../../contexts/WebsiteContext';
import styles from './MyOffers.css';

export default function MyOffers() {
  const websiteData = useContext(WebsiteContext);

  return (
    <div className={styles.container}>
      <Helmet>
        <title>{websiteData.children.offers.browserTitle}</title>
      </Helmet>

      <div className={styles.content}>
        <AllOfferList {..._.get(websiteData, 'children.offers.:items.offers', {})} />
      </div>
    </div>
  );
}
