import { createContext } from 'react';

export default createContext({
  data: {},
  loading: true,
  error: '',
});
