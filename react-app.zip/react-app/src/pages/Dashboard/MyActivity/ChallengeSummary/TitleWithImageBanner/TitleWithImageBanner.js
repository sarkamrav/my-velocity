import React from 'react';
import cx from 'classnames';
import PropTypes from 'prop-types';
import RichTextContent from '../../../../../components/RichTextContent/RichTextContent';
import styles from './TitleWithImageBanner.css';

const TitleWithImageBanner = ({ title, description, iconUrl, bgColor }) => (
  <div className={cx(styles.container, styles[`bg-${bgColor}`])}>
    <div className={styles.textInfoContainer}>
      {title && <h4 className={styles.title}>{title}</h4>}
      {description && (
        <RichTextContent content={description} className={styles.description} />
      )}
    </div>
    <div className={styles.imageContainer}>
      {iconUrl && (
        <img src={iconUrl} alt={title} />
      )}
    </div>
  </div>
);

TitleWithImageBanner.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
  iconUrl: PropTypes.string,
  bgColor: PropTypes.string,
};

TitleWithImageBanner.defaultProps = {
  title: '',
  description: '',
  iconUrl: '',
  bgColor: '',
};

export default TitleWithImageBanner;
