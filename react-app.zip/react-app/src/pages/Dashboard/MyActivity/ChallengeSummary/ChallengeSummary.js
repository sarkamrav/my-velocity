import React, { useContext } from 'react';
import PropTypes from 'prop-types';
import { cardStatusInfo } from '../../../../utils/common';
import PointsProCalculationContext from '../../../../contexts/PointsProCalculationContext';
import TitleWithImageBanner from './TitleWithImageBanner/TitleWithImageBanner';

const ChallengeSummary = ({
  completedChallenge,
  pendingChallenge,
  missedChallenge,
}) => {
  const { mainProgressStatus, totalEarnedPoints } = useContext(
    PointsProCalculationContext,
  );

  const getContent = () => {
    switch (mainProgressStatus) {
      case cardStatusInfo.completed:
        return (
          <TitleWithImageBanner {...completedChallenge} bgColor="purple" />
        );

      case cardStatusInfo.missed:
        // eslint-disable-next-line no-case-declarations
        const props = (missedChallenge || []).find(
          (obj) => totalEarnedPoints >= Number(obj.minPoint)
            && totalEarnedPoints <= Number(obj.maxPoint),
        );

        return <TitleWithImageBanner {...props} bgColor="purple" />;

      case cardStatusInfo.pending:
        return (
          <TitleWithImageBanner {...pendingChallenge} title={pendingChallenge.subTitle} bgColor="pale-purple" />
        );

      default:
        return null;
    }
  };

  return getContent();
};

ChallengeSummary.propTypes = {
  missedChallenge: PropTypes.arrayOf(PropTypes.shape({})),
  completedChallenge: PropTypes.shape({}),
  pendingChallenge: PropTypes.shape({}),
};

ChallengeSummary.defaultProps = {
  missedChallenge: [],
  completedChallenge: {},
  pendingChallenge: {},
};

export default ChallengeSummary;
