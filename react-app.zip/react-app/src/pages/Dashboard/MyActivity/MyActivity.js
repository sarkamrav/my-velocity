import React, { useContext, useEffect } from 'react';
import _ from 'lodash';
import cx from 'classnames';
import { Helmet } from 'react-helmet';
import isEmpty from 'lodash/isEmpty';

import ActivityFeed from './ActivityFeed/ActivityFeed';
import Icon from '../../../components/Icon/Icon';
import WebsiteContext from '../../../contexts/WebsiteContext';
import TargetedActivityCard from '../../../fragments/TargetedActivityCard/TargetedActivityCard';
import A from '../../../components/Button/A';
import DashboardContext from '../DashboardContext';
import AmexMgmCard from './AmexMgmCard/AmexMgmCard';
import { applyOffers } from '../../../utils/target';
import usePointsPro from '../../../hooks/usePointsPro/usePointsPro';
import UserContext from '../../../contexts/UserContext';
import * as userData from '../../../utils/utilities';
import { getStatus } from '../../PointsPro/PointsProUtils';
import PointsProCalculations from '../../PointsPro/PointsProCalculations';
import PointsProEntry from './PointsProEntry/PointsProEntry';
import { CHALLENGE_STATUSES } from '../../../utils/common';
import { getPointsProEntry } from './utils';

import styles from './MyActivity.css';
import PDFPage from './PDF/PDFPage';

export default function MyActivity() {
  const websiteData = useContext(WebsiteContext);
  const { getAnalytics } = useContext(DashboardContext);
  const { user } = useContext(UserContext);
  const loyaltyMembershipID = userData.getLoyaltyMembershipID(user);

  const quickLinks = _.get(websiteData, 'children.activity.:items.quickLinks', {});
  const tileCardsRight = _.get(websiteData, 'children.activity.:items.tileCardsRight.tileCards', []);
  const amexTileCard = _.get(websiteData, 'children.activity.:items.amexCard.tileCards[0]');
  const pointsProEntryData = getPointsProEntry(websiteData);

  const {
    promoCode,
    childPromoCodes,
    monthlyPointsRequired,
  } = pointsProEntryData;

  const { loaded, promotionsResponse, activitiesResponse: activities, pendingActivitiesResponse } = usePointsPro(loyaltyMembershipID, promoCode);
  const { data: promotions } = promotionsResponse || {};
  const { data: pendingActivities } = pendingActivitiesResponse || {};

  const allPromoCodes = [promoCode, ...(childPromoCodes || [])];
  const pointsProPromotions = (promotions || []).filter((item) => allPromoCodes.includes(item.promotionCode));
  const mainPromotion = pointsProPromotions.find((item) => item.promotionCode === promoCode);
  const childPromotions = pointsProPromotions.filter((item) => item.promotionCode !== promoCode);

  const status = !isEmpty(promotions)
    ? getStatus({ promotions, promoCode, childPromoCodes })
    : {};

  const shouldShowPointsProEntry = status === CHALLENGE_STATUSES.ACCEPTED
    || status === CHALLENGE_STATUSES.ACTIVITY_STARTED
    || status === CHALLENGE_STATUSES.ACTIVITY_ENDED;

  useEffect(() => {
    applyOffers();
  }, []);

  return (
    <div className={styles.container}>
      <Helmet>
        <title>{websiteData.children.activity.browserTitle}</title>
      </Helmet>

      <div className={styles.content}>
        <div className={styles.feedContainer}>
          {
            loaded && shouldShowPointsProEntry && (
            <PointsProCalculations
              activities={activities}
              mainPromotion={mainPromotion}
              childPromotions={childPromotions}
              pendingActivities={pendingActivities}
              monthlyTargetPoints={monthlyPointsRequired}
            >
              <PointsProEntry startDate={mainPromotion?.activityStartDate} {...pointsProEntryData} />
            </PointsProCalculations>
            )
          }
          <span className={styles.title}>My Activity</span>
          <span className={styles.description}>This feed shows your most recent Velocity activity</span>
          <ActivityFeed />
          <PDFPage />
          <div
            className={styles.ctaContainer}
            analytics-metadata={getAnalytics({
              eventCategory: 'my-activity',
              eventName: 'cta-interaction',
              eventLocation: 'my-activity-dashboard',
              hyperlinkElementName: 'view-all-activity',
            }, true)}
          >
            <A href="/my-velocity/my-activity/summary" buttonType="primary-transparent">See all activity</A>
          </div>
        </div>
        <div className={styles.targetContainer}>
          {
            _.size(quickLinks.quickLinks) > 0 ? (
              <div className={styles.card}>
                <span className={styles.title}>{quickLinks.title}</span>
                <ul
                  className={styles.quickLinks}
                  analytics-metadata={getAnalytics({
                    ...quickLinks.analyticsMetadataMap || {},
                    eventName: 'quick-links-interaction',
                    eventLocation: 'my-activity-dashboard',
                  }, true)}
                >
                  {
                    _.map(quickLinks.quickLinks, (link, i) => (
                      <li key={i}>
                        {/* eslint-disable-next-line react/jsx-no-target-blank */}
                        <a
                          href={link.href}
                          className={styles.link}
                          title={link.title}
                          target={link.openInNewTab ? '_blank' : '_self'}
                          rel={link.openInNewTab ? 'noopener noreferrer' : null}
                        >
                          {link.iconUrl ? <img src={link.iconUrl} alt={link.label} className={styles.icon} /> : null }
                          <span className={styles.text}>
                            {link.label}
                          </span>
                          <Icon name="chevron" size={12} className={styles.chevron} />
                        </a>
                      </li>
                    ))
                  }
                </ul>
              </div>
            ) : null
          }

          <div
            className={cx(styles.targetedCards, {
              [styles.singleChild]: _.size(tileCardsRight) === 1,
            })}
          >
            {
              amexTileCard && <AmexMgmCard {...window.vffCoreWebsite[amexTileCard.jsObjectKey]} />
            }

            {
              _.map(tileCardsRight, tileCard => (
                <TargetedActivityCard
                  key={tileCard.jsObjectKey}
                  defaultTargetActivity={window.vffCoreWebsite[tileCard.jsObjectKey]}
                  mboxDefinition={tileCard.mboxDefinition}
                  analyticsData={{
                    eventLocation: 'myVelocityMyActivityContentTile',
                  }}
                />
              ))
            }
          </div>
        </div>
      </div>
    </div>
  );
}
