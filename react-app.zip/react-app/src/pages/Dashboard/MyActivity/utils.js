import get from 'lodash/get';

export const getPointsProEntry = (websiteData) => get(websiteData, 'children.activity.:items.myVelocityChallengeProgress')
  || {};

export const getProgressSummary = (websiteData) => Object.values(get(websiteData, 'children.activity.:items')).find(item => item.componentKey === 'aem-challenge-summary')
  || {};
