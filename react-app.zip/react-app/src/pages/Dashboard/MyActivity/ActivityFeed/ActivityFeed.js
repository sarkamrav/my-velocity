import React, { useContext } from 'react';
import moment from 'moment';
import _ from 'lodash';
import { Link } from 'react-router-dom';
import { formatAdditionSubtraction } from '../../../../utils/common';
import NotificationEarned from './notification-bell-earned.svg';
import NotificationRedeemed from './notification-bell-redeemed.svg';
import NotificationBase from './notification-bell-base.svg';
import Loading from '../../../../components/Loading/Loading';
import FeedItem from '../../../../fragments/FeedItem/FeedItem';
import UserContext from '../../../../contexts/UserContext';
import InformationAlert, { informationAlertTheme } from '../../../../components/InformationAlert/InformationAlert';
import A from '../../../../components/Button/A';
import NothingHere from './nothing-here.svg';
import WebsiteContext from '../../../../contexts/WebsiteContext';
import ExperienceActivitiesContext from '../../experienceActivitiesContext';
import * as userData from '../../../../utils/utilities';
import styles from './ActivityFeed.css';

export default function ActivityFeed() {
  const websiteData = useContext(WebsiteContext);
  const { user } = useContext(UserContext);

  const { data: activitiesData, loading, error } = useContext(ExperienceActivitiesContext);

  const customActivityTypes = _.get(window.vffCoreWebsite, 'spaContainer.children.activity.:items.activityTypes');
  const customActivityTiles = _.get(customActivityTypes, 'tileCards');

  // TODO: Clean this up
  let injectedFlightActivityType = false;
  const customFlightActivity = _.find(customActivityTiles, { activityType: 'FLIGHT' });

  let injectedHotelStayActivityType = false;
  const customHotelStayActivity = _.find(customActivityTiles, { activityType: 'HOTEL_STAY' });

  let injectedCarRentalActivityType = false;
  const customCarRentalActivity = _.find(customActivityTiles, { activityType: 'CAR_RENTAL' });

  let injectedGenericProductActivityType = false;
  const customGenericProductActivity = _.find(customActivityTiles, { activityType: 'GENERIC_PRODUCT' });

  let injectedManualAdjustmentActivityType = false;
  const customManualAdjustmentActivity = _.find(customActivityTiles, { activityType: 'MANUAL_ADJUSTMENT' });

  let injectedTransferActivityType = false;
  const customTransferActivity = _.find(customActivityTiles, { activityType: 'TRANSFER' });

  let injectedAwardsOperationActivityType = false;
  const customAwardsOperationActivity = _.find(customActivityTiles, { activityType: 'AWARDS_OPERATION' });

  let injectedTierUpdateActivityType = false;
  const customTierUpdateActivity = _.find(customActivityTiles, { activityType: 'TIER_UPDATE' });

  let injectedPoolingActivityType = false;
  const customPoolingActivity = _.find(customActivityTiles, { activityType: 'POOLING' });

  let injectedPromotionRewardActivityType = false;
  const customPromotionRewardActivity = _.find(customActivityTiles, { activityType: 'PROMOTION_REWARD' });

  function generateFeedData(prev, curr, previousBalance, newBalance, pointsIncreased, activity, activityType) {
    return [
      ...prev,
      {
        isFeedItem: true,
        id: _.uniqueId(),
        previousBalance,
        newBalance,
        pointsIncreased,
        defaultTargetActivity: activity,
        mboxDefinition: activityType.mboxDefinition,
        analyticsData: window.vffCoreWebsite[customActivityTypes.analyticsMetadata['analytics-metadata']],
      },
      {
        ...curr,
        previousBalance,
        newBalance,
        pointsIncreased,
      },
    ];
  }

  const feedData = _.reduce(activitiesData?.data?.history, (prev, curr) => {
    const pointsIncreased = curr.points.awardPoints;
    const previousBalance = (_.last(prev) ? _.last(prev).previousBalance : userData.getCurrentPointsBalance(user)) - pointsIncreased;

    const newBalance = previousBalance + pointsIncreased;

    if (curr.activityType === 'FLIGHT' && !injectedFlightActivityType && customFlightActivity) {
      injectedFlightActivityType = true;
      const activity = window.vffCoreWebsite[customFlightActivity.jsObjectKey] || {};
      return generateFeedData(prev, curr, previousBalance, newBalance, pointsIncreased, activity, customFlightActivity);
    }

    if (curr.activityType === 'HOTEL_STAY' && !injectedHotelStayActivityType && customHotelStayActivity) {
      injectedHotelStayActivityType = true;
      const activity = window.vffCoreWebsite[customHotelStayActivity.jsObjectKey] || {};
      return generateFeedData(prev, curr, previousBalance, newBalance, pointsIncreased, activity, customHotelStayActivity);
    }

    if (curr.activityType === 'CAR_RENTAL' && !injectedCarRentalActivityType && customCarRentalActivity) {
      injectedCarRentalActivityType = true;
      const activity = window.vffCoreWebsite[customCarRentalActivity.jsObjectKey] || {};
      return generateFeedData(prev, curr, previousBalance, newBalance, pointsIncreased, activity, customCarRentalActivity);
    }

    if (curr.activityType === 'GENERIC_PRODUCT' && !injectedGenericProductActivityType && customGenericProductActivity) {
      injectedGenericProductActivityType = true;
      const activity = window.vffCoreWebsite[customGenericProductActivity.jsObjectKey] || {};
      return generateFeedData(prev, curr, previousBalance, newBalance, pointsIncreased, activity, customGenericProductActivity);
    }

    if (curr.activityType === 'MANUAL_ADJUSTMENT' && !injectedManualAdjustmentActivityType && customManualAdjustmentActivity) {
      injectedManualAdjustmentActivityType = true;
      const activity = window.vffCoreWebsite[customManualAdjustmentActivity.jsObjectKey] || {};
      return generateFeedData(prev, curr, previousBalance, newBalance, pointsIncreased, activity, customManualAdjustmentActivity);
    }

    if (curr.activityType === 'TRANSFER' && !injectedTransferActivityType && customTransferActivity) {
      injectedTransferActivityType = true;
      const activity = window.vffCoreWebsite[customTransferActivity.jsObjectKey] || {};
      return generateFeedData(prev, curr, previousBalance, newBalance, pointsIncreased, activity, customTransferActivity);
    }

    if (curr.activityType === 'AWARDS_OPERATION' && !injectedAwardsOperationActivityType && customAwardsOperationActivity) {
      injectedAwardsOperationActivityType = true;
      const activity = window.vffCoreWebsite[customAwardsOperationActivity.jsObjectKey] || {};
      return generateFeedData(prev, curr, previousBalance, newBalance, pointsIncreased, activity, customAwardsOperationActivity);
    }

    if (curr.activityType === 'TIER_UPDATE' && !injectedTierUpdateActivityType && customTierUpdateActivity) {
      injectedTierUpdateActivityType = true;
      const activity = window.vffCoreWebsite[customTierUpdateActivity.jsObjectKey] || {};
      return generateFeedData(prev, curr, previousBalance, newBalance, pointsIncreased, activity, customTierUpdateActivity);
    }

    if (curr.activityType === 'POOLING' && !injectedPoolingActivityType && customPoolingActivity) {
      injectedPoolingActivityType = true;
      const activity = window.vffCoreWebsite[customPoolingActivity.jsObjectKey] || {};
      return generateFeedData(prev, curr, previousBalance, newBalance, pointsIncreased, activity, customPoolingActivity);
    }

    if (curr.activityType === 'PROMOTION_REWARD' && !injectedPromotionRewardActivityType && customPromotionRewardActivity) {
      injectedPromotionRewardActivityType = true;
      const activity = window.vffCoreWebsite[customPromotionRewardActivity.jsObjectKey] || {};
      return generateFeedData(prev, curr, previousBalance, newBalance, pointsIncreased, activity, customPromotionRewardActivity);
    }

    return [
      ...prev,
      {
        ...curr,
        previousBalance,
        newBalance,
        pointsIncreased,
      },
    ];
  }, []);

  function renderIcon(activity) {
    // case 'F': // Flight
    // case 'P': // Partner
    // case 'R': // Redemption
    // case 'A': // Adjustment
    if (activity.points.awardPointsBaseSubTotal > 0 || activity.points.awardPointsBonusSubTotal > 0 || activity.points.statusCredits > 0 || activity.points.eligibleSectors > 0 || activity.points.awardPoints > 0) {
      return <NotificationEarned className={styles.icon} />;
    }
    if (activity.points.awardPointsBaseSubTotal < 0 || activity.points.awardPointsBonusSubTotal < 0 || activity.points.statusCredits < 0 || activity.points.eligibleSectors < 0 || activity.points.awardPoints < 0) {
      return <NotificationRedeemed className={styles.icon} />;
    }
    return <NotificationBase className={styles.icon} />;
  }

  return (
    <ul className={styles.feed}>
      {
        loading ? <Loading /> : null
      }
      {
        error ? (
          <InformationAlert
            status={informationAlertTheme.danger}
            icon="exclamationCircleSolid"
            description="Sorry we're having issues with our system. Please refresh the page or try again later."
            cta={<A buttonType="secondary" onClick={() => window.location.reload()}>Refresh page</A>}
          />
        ) : null
      }
      {
        !error && !loading && _.size(feedData) === 0 ? (
          <div className={styles.emptyContainer}>
            <NothingHere className={styles.emptyIcon} />
            <h4 className="heading heading--4 font-weight font-weight--bold">You currently have no transactions</h4>
            <p className="font-size font-size--large">Get started by viewing and activating one of our <Link to={websiteData.children.offers.pageUrl}>Offers</Link></p>
          </div>
        ) : null
      }
      {
        !error && !loading && _.size(feedData) > 0 ? _.map(feedData, activity => {
          const hours = moment().diff(moment(activity.activityDate), 'hours');

          return (
            <li key={`${activity.id}${activity.activityType}`} className={styles.feedItem}>
              <div className={styles.iconContainer}>
                {renderIcon(activity)}
              </div>
              {
                activity.isFeedItem ? (
                  <FeedItem {...activity} />
                ) : (
                  <>
                    <div className={styles.content}>
                      <span className={styles.title}>{activity.partner?.commonName}</span>
                      <span className={styles.description}>{moment(activity.activityDate).format('DD MMM YY')} - {activity.description}</span>
                      <span className={styles.duration}>
                        {hours < 24 ? 'Today' : moment(activity.activityDate).fromNow()}
                      </span>
                    </div>
                    <div className={styles.outcome}>
                      {activity.points.awardPoints ? <span className={styles.morePoints}>{formatAdditionSubtraction(activity.points.awardPoints)} Points</span> : null}

                      {activity.points.statusCredits ? <span className={styles.moreStatusCredits}>{formatAdditionSubtraction(activity.points.statusCredits)} Status Credits</span> : null}

                      {activity.points.eligibleSectors ? <span className={styles.moreStatusCredits}>{formatAdditionSubtraction(activity.points.eligibleSectors)} Eligible Sectors</span> : null}
                    </div>
                  </>
                )
              }
            </li>
          );
        }) : null
      }
    </ul>
  );
}
