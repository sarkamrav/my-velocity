import React, { useContext, useEffect } from 'react';
import PropTypes from 'prop-types';

import { DateTime } from 'luxon';
import ProgressCard, {
  progressCardDisplayMode,
} from '../../../PointsPro/Tabs/Challenges/components/ProgressCard/ProgressCard';
import PointsProCalculationContext from '../../../../contexts/PointsProCalculationContext';
import {
  analyticsEventAction,
  analyticsEventCategory,
  analyticsEventName,
  cardStatusInfo,
  isCtaAvailable,
  serverTimeZone,
} from '../../../../utils/common';
import A from '../../../../components/Button/A';

import styles from './PointsProEntry.css';
import WebsiteContext from '../../../../contexts/WebsiteContext';
import { getProgressSummary } from '../utils';
import ChallengeSummary from '../ChallengeSummary/ChallengeSummary';
import { getServerDateTime } from '../../../PointsPro/PointsProUtils';
import analytics from '../../../../utils/analytics';

const PointsProEntry = ({
  startDate,
  title,
  ctaContainer,
  mainChallenge,
  maxPointsRequired,
}) => {
  const {
    totalEarnedPoints,
    totalPendingPoints,
    mainProgressStatus,
    mainPromotion,
  } = useContext(PointsProCalculationContext);
  const websiteData = useContext(WebsiteContext);
  const icons = mainProgressStatus === cardStatusInfo.active
    || mainProgressStatus === cardStatusInfo.completed
    ? mainChallenge.iconsActive
    : mainChallenge.icons;
  const currentDate = DateTime.fromObject({}, serverTimeZone);
  const mainPromotionActivityEndDate = getServerDateTime(
    mainPromotion.activityEndDate,
  );

  const isActivityEnded = currentDate >= mainPromotionActivityEndDate;

  useEffect(() => {
    if (!isActivityEnded) {
      analytics.send({
        eventAction: analyticsEventAction.impression,
        eventName: analyticsEventName.trackerImpression,
        eventCategory: analyticsEventCategory.tracker,
        eventElementName: title ?? '',
        eventElementText: totalEarnedPoints ?? '',
      });
    }
  }, []);

  const progressSummaryProps = getProgressSummary(websiteData);
  return (
    <div className={styles.container}>
      {title && <span className={styles.title}>{title}</span>}
      {isActivityEnded ? (
        <div className={styles.challengeSummaryMarginTopBottom}>
          <ChallengeSummary {...progressSummaryProps} />
        </div>
      ) : (
        <ProgressCard
          startDate={startDate}
          status={mainProgressStatus}
          currentPoints={totalEarnedPoints}
          totalPoints={maxPointsRequired}
          pendingPoints={totalPendingPoints}
          eStoreTooltipContent={mainChallenge?.pendingPointsTooltipMessage}
          displayMode={progressCardDisplayMode.entry}
          entryFooter={{
            ctaContainer: mainChallenge?.terms,
            icons,
          }}
        />
      )}
      {
        isCtaAvailable(ctaContainer) && (
          <A
            className={styles.callToAction}
            buttonType="purple-link"
            href={ctaContainer.ctaUrl}
            title={ctaContainer.ctaTitle}
            ctaAsLink={false}
            target={ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
            analytics-metadata={JSON.stringify({
              eventName: 'cta-interaction',
              eventCategory: 'cta-links',
            })}
          >
            {ctaContainer.ctaLabel}
          </A>
        )
      }
    </div>
  );
};

PointsProEntry.propTypes = {
  startDate: PropTypes.string,
  title: PropTypes.string,
  maxPointsRequired: PropTypes.number,
  ctaContainer: PropTypes.shape({
    ctaUrl: PropTypes.string,
    ctaTitle: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaLabel: PropTypes.string,
  }),
  mainChallenge: PropTypes.shape({
    pendingPointsTooltipMessage: PropTypes.string,
    icons: PropTypes.arrayOf(PropTypes.string),
    iconsActive: PropTypes.arrayOf(PropTypes.string),
    terms: PropTypes.shape({
      ctaUrl: PropTypes.string,
      ctaTitle: PropTypes.string,
      ctaOpenInNewTab: PropTypes.bool,
      ctaLabel: PropTypes.string,
    }),
  }),
};

PointsProEntry.defaultProps = {
  startDate: null,
  title: null,
  maxPointsRequired: 0,
  ctaContainer: null,
  mainChallenge: null,
};

export default PointsProEntry;
