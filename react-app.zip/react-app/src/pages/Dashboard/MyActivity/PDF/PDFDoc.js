import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  PDFViewer,
  Image,
  Font,
} from "@react-pdf/renderer";
import React, { useEffect, useState } from "react";
import axios from "axios";
import { qrImage } from "./utils";
import GtAmerica1 from "./GT-America-Extended-Light.ttf";
// import gTAmerica from './GT-America-Extended-Light.ttf';
import test1 from "./test1.ttf";

Font.register({ family: "deepak", format: "truetype", src: test1 });

Font.register({
  family: "Ubuntu",
  format: "truetype",
  fonts: [
    {
      src: "https://fonts.gstatic.com/s/questrial/v13/QdVUSTchPBm7nuUeVf7EuStkm20oJA.ttf",
    },
    {
      src: "https://fonts.gstatic.com/s/questrial/v13/QdVUSTchPBm7nuUeVf7EuStkm20oJA.ttf",
      fontWeight: "bold",
    },
    {
      src: "https://fonts.gstatic.com/s/questrial/v13/QdVUSTchPBm7nuUeVf7EuStkm20oJA.ttf",
      fontWeight: "normal",
      fontStyle: "italic",
    },
  ],
});

// Font.register({
//   family: 'Ubuntu',
//   fonts: [
//     {
//       src: GtAmerica,
//     },
// {
//   src: 'https://fonts.gstatic.com/s/questrial/v13/QdVUSTchPBm7nuUeVf7EuStkm20oJA.ttf',
//   fontWeight: 'bold',
// },
// {
//   src: 'https://fonts.gstatic.com/s/questrial/v13/QdVUSTchPBm7nuUeVf7EuStkm20oJA.ttf',
//   fontWeight: 'normal',
//   fontStyle: 'italic',
// },
//   ],
// });

// Font.register({
//   family: "Open-Sans",
//   fonts: [
//     {
//       src: "https://cdn.jsdelivr.net/npm/open-sans-all@0.1.3/fonts/open-sans-regular.ttf",
//     },
//     {
//       src: "https://cdn.jsdelivr.net/npm/open-sans-all@0.1.3/fonts/open-sans-600.ttf",
//       fontWeight: 600,
//     },
//   ],
// });

// Create styles
const styles = StyleSheet.create({
  page: {
    backgroundColor: "white",
    // color: 'red',
  },
  viewer: {
    width: window.innerWidth, // the pdf viewer will take up all of the width and height
    height: window.innerHeight,
  },

  header: {},
  instructionSection: {},
  cardContainer: {},
  cardLogosContainer: {},
  cardMemberContainer: {},
  cardExpiryContainer: {},
  image: {
    width: 80,
    height: 80,
  },
  view: {
    // fontFamily: 'GtAmerica',
  },
  text: {
    // lineHeight: '18px',
    // fontFamily: 'deepak',
  },
});

// Font.register({
//   family: 'GTAmerica',
//   src: 'https://fonts.gstatic.com/s/oswald/v13/Y_TKV6o8WovbUd3m_X9aAA.ttf',
//   fontStyle: 'normal',
// });

// Create Document Component
function BasicDocument({ qrValue }) {
  const [url, setUrl] = useState();

  const getImage = async (value) => {
    console.log("xxx", value);
    const data = await qrImage(value);
    setUrl(data);
  };
  useEffect(() => {
    getImage(qrValue);
  }, [qrValue]);
  console.log(url);

  console.log(Font.getRegisteredFonts());
  return (
    <Document>
      {/* render a single page */}
      <Page size="A4" style={styles.page}>
        <View
          style={{ margin: "10%", flexDirection: "column", rowGap: "16px" }}
        >
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              // marginBottom: '16px',
            }}
          >
            <View
              style={{
                flexDirection: "row",
                justifyContent: "flex-start",
              }}
            >
              {url && <Image style={{ width: 80, height: 24 }} src={url} />}
              {url && <Image style={{ width: 80, height: 24 }} src={url} />}
            </View>
            <View
              style={{
                flexDirection: "column",
                alignItems: "flex-end",
                justifyContent: "flex-end",
              }}
            >
              <Text style={{ fontSize: 9 }}>Mr Diego de Souza Goncalves</Text>
              <Text style={{ fontSize: 14, fontWeight: 500 }}>
                Membership: 1111 222 333
              </Text>
            </View>
          </View>
          <View
            style={{
              backgroundColor: "lightgrey",
              height: 1,
              // width: window.innerWidth,
              // marginHorizontal: "20%",
            }}
          />
          <View style={{ flexDirection: "column", rowGap: "6px" }}>
            <Text style={{ fontSize: 14, fontWeight: 500, marginTop: 24 }}>
              Hi Diego!
            </Text>
            <Text style={{ fontSize: 9 }}>
              Here’s your printable Velocity Frequent Flyer card. Print it at
              home and bring it with you next time you travel.
            </Text>
          </View>
          <View style={{ flexDirection: "column", rowGap: 8 }}>
            <Text style={{ fontSize: 11, fontWeight: 600 }}>Instructions:</Text>
            <Text style={{ fontSize: 9 }}>
              1. Load your printer with A4 paper (or cardboard for a more
              durable card)
            </Text>
            <Text style={{ fontSize: 9 }}>
              2. In print settings: Set paper size to A4 and scale to 100%
            </Text>
            <Text style={{ fontSize: 9 }}>3. Print your card</Text>
            <Text style={{ fontSize: 9 }}>4. Cut along the dashed lines</Text>
          </View>

          <View
            style={{
              border: 2,
              borderStyle: "dashed",
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "flex-start",
              // marginHorizontal: '20%',
              width: 242,
              height: 152,
              padding: 8,
              margin: "40 auto",
            }}
          >
            <View
              style={{
                flexDirection: "column",
                rowGap: 16,
                flexBasis: "50%",
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  marginTop: 8,
                }}
              >
                {url && <Image style={{ width: 54, height: 16 }} src={url} />}
                {url && <Image style={{ width: 54, height: 16 }} src={url} />}
              </View>
              <View>
                <Text style={{ fontSize: 10 }}>
                  Mr Diego de Souza Goncalves
                </Text>
                <Text style={{ fontSize: 14 }}>1111 222 333</Text>
              </View>
              <View style={{ flexDirection: "column", rowGap: 4 }}>
                <View style={{ flexDirection: "row", alignItems: "flex-end" }}>
                  <Text style={{ fontSize: 8 }}>Card exp </Text>
                  <Text style={{ fontSize: 8, fontWeight: 500 }}>
                    13 Mar 2024
                  </Text>
                </View>
                <View style={{ flexDirection: "row", alignItems: "flex-end" }}>
                  <Text style={{ fontSize: 8 }}>Review date </Text>
                  <Text style={{ fontSize: 8, fontWeight: 500 }}>
                    28 Feb 2024
                  </Text>
                </View>
                <View style={{ flexDirection: "row", alignItems: "flex-end" }}>
                  <Text style={{ fontSize: 8 }}>Lounge expiry </Text>
                  <Text style={{ fontSize: 8, fontWeight: 500 }}>
                    23 May 2024
                  </Text>
                </View>
              </View>
            </View>
            <View
              style={{
                flexDirection: "column",
                height: "100%",
              }}
            >
              {url && <Image style={styles.image} src={url} />}
              {url && (
                <Image
                  style={{
                    width: 63,
                    height: 30,
                    margin: "auto 0 auto 8",
                  }}
                  src={url}
                />
              )}
            </View>
          </View>

          <View style={{ flexDirection: "column", rowGap: 2 }}>
            <Text style={{ fontSize: 10, fontWeight: 500, marginBottom: 6 }}>
              Important information
            </Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
              <Text style={{ fontSize: 7 }}>Card expiry:</Text>
              <Text style={{ fontSize: 7 }}>
                This is the last date you can use your card for your status
                benefits (e.g. Lounge Access or Premium check in and boarding).
              </Text>
            </View>
            <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
              <Text style={{ fontSize: 7, fontWeight: 500 }}>Review date:</Text>
              <Text style={{ fontSize: 7 }}>
                This is the last date by which you need to earn enough status
                credits to maintain your status tier.
              </Text>
            </View>
            <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
              <Text style={{ fontSize: 7, fontWeight: 500 }}>
                Lounge expiry:
              </Text>
              <Text style={{ fontSize: 7 }}>
                This is the date your Virgin Australia Lounge membership
                expires. Visit virginaustralia.com/public/system/
                thelounge/index.wm to renew your membership for another year.
              </Text>
            </View>
          </View>
          <View
            style={{
              backgroundColor: "lightgrey",
              height: 1,
            }}
          />
          <View
            style={{ flexDirection: "row", justifyContent: "space-between" }}
          >
            <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
              <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
                <Text style={{ fontSize: 7 }}>F:</Text>
                <Text style={{ fontSize: 7 }}>Facebook</Text>
              </View>
              <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
                <Text style={{ fontSize: 7 }}>F:</Text>
                <Text style={{ fontSize: 7 }}>Facebook</Text>
              </View>
              <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
                <Text style={{ fontSize: 7 }}>F:</Text>
                <Text style={{ fontSize: 7 }}>Facebook</Text>
              </View>
              <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
                <Text style={{ fontSize: 7 }}>F:</Text>
                <Text style={{ fontSize: 7 }}>Facebook</Text>
              </View>
              <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
                <Text style={{ fontSize: 7 }}>Card expiry:</Text>
                <Text style={{ fontSize: 7 }}>This is the .</Text>
              </View>
            </View>
            <View>
              <Text style={{ fontSize: 7 }}>Card expiry:</Text>
              <Text style={{ fontSize: 7 }}>This is the .</Text>
            </View>
          </View>
        </View>
      </Page>
    </Document>
  );
}
export default BasicDocument;
