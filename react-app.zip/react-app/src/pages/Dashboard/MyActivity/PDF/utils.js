import QRCode from 'qrcode';

export const qrImage = async (value) => {
  if (value) {
    try {
      const url = await QRCode.toDataURL(value, {
        errorCorrectionLevel: 'H',
        version: 4,
      });
      console.log(url);
      return url;
    } catch (error) {
      console.error(error);
    }
  }
  return null;
};
