import React, { useState } from 'react';
import { Font, PDFDownloadLink, PDFViewer, usePDF } from '@react-pdf/renderer';
import BasicDocument from './PDFDoc';

const PDFPage = () => {
  const [qrValue, setQrValue] = useState('deepak');
  const [showPdf, setShowPdf] = useState(false);
  const [instance] = usePDF({ document: BasicDocument });

  return (
    <div>
      <input
        value={qrValue}
        onChange={(e) => {
          setQrValue(e.target.value);
        }}
      />
      <button
        onClick={() => {
          setShowPdf(!showPdf);
        }}
      >
        Open PDF
      </button>
      {/* {showPdf && instance.loading && <div>Loading ...</div>}
      {showPdf && instance.error && (
        <div>Something went wrong: {instance.error}</div>
      )} */}
      {/* {showPdf && instance.url && (
        <a href={instance.url} download="test.pdf">
          Download
        </a>
      )} */}
      {/* {showPdf && (
        <PDFDownloadLink
          document={<BasicDocument qrValue={qrValue} />}
          fileName="somename.pdf"
        >
          {({ blob, url, loading, error }) =>
            loading ? "Loading document..." : "Download now!"
          }
        </PDFDownloadLink>
      )} */}
      {showPdf && (
        <PDFViewer
          style={{ width: window.innerWidth, height: window.innerHeight }}
        >
          <BasicDocument qrValue={qrValue} />
        </PDFViewer>
      )}
    </div>
  );
};

export default PDFPage;
