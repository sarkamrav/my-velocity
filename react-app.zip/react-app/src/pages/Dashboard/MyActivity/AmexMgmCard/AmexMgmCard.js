import React, { useState, useRef, useEffect, useContext, useCallback } from 'react';
import { useLocation, useHistory } from 'react-router-dom';
import PropTypes from 'prop-types';
import _ from 'lodash';
import qs from 'qs';

import { useApi } from '../../../../utils/api';
import A from '../../../../components/Button/A';
import RichTextContent from '../../../../components/RichTextContent/RichTextContent';
import AmexMgmModal from './AmexMgmModal';
import { commonAnalyticsMetadata } from './constants';
import DashboardContext from '../../DashboardContext';
import analytics from '../../../../utils/analytics';
import syncText, { getQueryParameter } from '../../../../utils/common';

import styles from './AmexMgmCard.css';

function AmexMgmCard({
  renditions, title, description, ctaContainer,
}) {
  const modalQueryParameterName = 'amex-mgm';
  const imageRef = useRef();
  const location = useLocation();
  const history = useHistory();
  const autoShowModal = getQueryParameter(modalQueryParameterName, location.search) === 'show';
  const [showModal, setShowModal] = useState(autoShowModal);
  const { getAnalytics } = useContext(DashboardContext);

  function getAmexOffer(data) {
    return _.get(data, 'data.amex.external_rafaas_responses[0]');
  }

  function handleResponseAnalytics(data) {
    const amexOffer = getAmexOffer(data);

    if (amexOffer) {
      analytics.send({
        ...commonAnalyticsMetadata,
        eventName: 'amex-mgm-shown',
      });
    }
  }

  const handleShowModal = useCallback((e) => {
    e.preventDefault();

    setShowModal(true);
  }, [setShowModal]);

  const { data, loading, error } = useApi('/loyalty/v2/members/referrals', {
    endpoint: 'vffV2Api',
  }, handleResponseAnalytics);
  const amex = getAmexOffer(data);
  const isAmexMgmCardVisible = !(loading || !!error || !amex || !amex.short_url);

  useEffect(() => {
    if (isAmexMgmCardVisible) {
      window.vffCoreWebsite.coreRenderImage(imageRef.current, renditions);
    }
  }, [isAmexMgmCardVisible]);

  useEffect(() => {
    if (isAmexMgmCardVisible && autoShowModal) {
      const parameterObject = qs.parse(location.search, { ignoreQueryPrefix: true });
      const parameterWithNoAmexParameter = _.omit(parameterObject, modalQueryParameterName);
      const newQueryString = qs.stringify(parameterWithNoAmexParameter, { addQueryPrefix: true });

      history.replace({
        search: newQueryString,
      });
    }
  }, [isAmexMgmCardVisible]);

  return isAmexMgmCardVisible && (
    <div className={styles.container}>
      <div className={styles.referralOffer}>
        Referral offer
      </div>
      <div className={styles.imageContainer}>
        <img className={styles.image} alt={title} ref={imageRef} />
      </div>
      <div className={styles.content}>
        <span className={styles.title}>{title}</span>
        <RichTextContent
          className={styles.description}
          content={syncText(description, {
            mgmerPoints: _.get(amex, 'mgmer_offer_content.bonus_amount', ''),
            mgmeePoints: _.get(amex, 'mgmee_offer_content.bonus_amount', ''),
          })}
        />
      </div>
      <div className={styles.footer}>
        {
          !_.isEmpty(ctaContainer) ? (
            <A
              className={styles.link}
              onClick={handleShowModal}
              title={ctaContainer.ctaTitle}
              buttonType={ctaContainer.ctaStyle}
              analytics-metadata={getAnalytics({
                ...commonAnalyticsMetadata,
                eventName: 'amex-mgm-step1',
              }, true)}
            >
              {ctaContainer.ctaLabel}
            </A>
          ) : null
        }
      </div>

      {
        showModal ? <AmexMgmModal amex={amex} onDismiss={() => setShowModal(false)} /> : null
      }
    </div>
  );
}

AmexMgmCard.propTypes = {
  title: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
  ctaContainer: PropTypes.shape(),
  renditions: PropTypes.shape(),
};

AmexMgmCard.defaultProps = {
  ctaContainer: null,
  renditions: null,
};

export default AmexMgmCard;
