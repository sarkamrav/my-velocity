import React, { useRef, useState, useContext, useCallback } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import Modal from '../../../../components/Modal/Modal';
import RichTextContent from '../../../../components/RichTextContent/RichTextContent';
import Checkbox from '../../../../components/Form/Checkbox/Checkbox';
import Button from '../../../../components/Button/Button';
import DashboardContext from '../../DashboardContext';
import analytics from '../../../../utils/analytics';
import { commonAnalyticsMetadata } from './constants';
import styles from './AmexMgmModal.css';

function AmexMgmModal({ amex, onDismiss }) {
  const inputRef = useRef();
  const [consent, setConsent] = useState(false);
  const [showReferral, setShowReferral] = useState(false);
  const [copied, setCopied] = useState(false);
  const { getAnalytics } = useContext(DashboardContext);

  const handleCopyReferral = useCallback(() => {
    inputRef.current.select();
    document.execCommand('copy');
    setCopied(true);
    analytics.send({
      ...commonAnalyticsMetadata,
      eventName: 'amex-mgm-step3',
      hyperlinkElementName: 'Copy',
    });
  }, [inputRef]);

  const handleGetReferral = useCallback(() => {
    setShowReferral(true);
    analytics.send({
      ...commonAnalyticsMetadata,
      eventName: 'amex-mgm-step2',
      hyperlinkElementName: 'Get referral link',
    });
  }, [setShowReferral]);

  return (
    <Modal onDismiss={onDismiss} aria-label="American Express Referral">
      <div className={styles.container} analytics-metadata={getAnalytics(commonAnalyticsMetadata, true)}>
        <div className={styles.header}>
          <div className={styles.title}>
            <h3 className="heading heading--3 color color--white">{amex.header_content.mgm_header}</h3>
          </div>
          <div className={styles.imageContainer}>
            <img src={amex.header_content.card_art_url} alt={amex.header_content.card_art_hover_text} />
          </div>
        </div>

        <div className={styles.body}>
          <div className={styles.columns}>
            <div className={styles.column}>
              <h3 className={styles.columnTitle}>{amex.mgmer_offer_content.offer_copy}</h3>
              <span className="heading heading--1 color color--purple">{amex.mgmer_offer_content.bonus_amount}</span>
              <RichTextContent className={styles.columnDescription} content={amex.mgmer_offer_content.addnl_offer_copy} />
            </div>
            <div className={styles.column}>
              <h3 className={styles.columnTitle}>{amex.mgmee_offer_content.offer_copy}</h3>
              <span className="heading heading--1 color color--purple">{amex.mgmee_offer_content.bonus_amount}</span>
              <RichTextContent className={styles.columnDescription} content={amex.mgmee_offer_content.addnl_offer_copy} />
            </div>
          </div>

          <div className={styles.spamText}>
            <p>Don’t spam: Please share your referral link responsibly. </p>
            <ul>
              <li>Only refer close friends and family who might be interested in this offer.</li>
              <li>There are limits on the number of friends you can refer and the Points you can receive.</li>
            </ul>
          </div>

          {
            !showReferral && (
              <Checkbox
                id="amexConsent"
                name="amexConsent"
                containerClassName={styles.checkbox}
                label={amex.terms_and_conditions.consent_checkbox_txt}
                size="large"
                checked={consent}
                onChange={e => setConsent(e.target.checked)}
              />
            )
          }
        </div>

        <div
          className={cx(styles.footer, {
            [styles.hidden]: !showReferral,
          })}
        >
          {
            showReferral ? (
              <div className={styles.referralContainer}>
                <span className={styles.referralText}>Copy and share your personalised link</span>

                <div className={styles.inputContainer}>
                  <input className={styles.input} value={`${amex.short_url}?xl=cpvl`} readOnly ref={inputRef} />
                  <Button className={styles.copyButton} buttonType="primary" onClick={handleCopyReferral}>{copied ? 'Copied' : 'Copy'}</Button>
                </div>
              </div>
            ) : null
          }
        </div>
        <div
          className={cx(styles.footer, {
            [styles.hidden]: showReferral,
          })}
        >
          <Button onClick={onDismiss} buttonType="black-link">Cancel</Button>
          <Button onClick={handleGetReferral} disabled={!consent}>Get referral link</Button>
        </div>
      </div>
    </Modal>
  );
}

AmexMgmModal.propTypes = {
  amex: PropTypes.shape().isRequired,
  onDismiss: PropTypes.func.isRequired,
};

export default AmexMgmModal;
