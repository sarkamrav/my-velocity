export const commonAnalyticsMetadata = {
  eventCategory: 'amex-mgm',
  eventLocation: 'my-velocity',
};
