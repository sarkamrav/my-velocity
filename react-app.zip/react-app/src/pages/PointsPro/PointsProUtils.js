import isEmpty from 'lodash/isEmpty';
import { DateTime } from 'luxon';
import get from 'lodash/get';
import {
  ACTIVATION_STATUSES,
  CHALLENGE_STATUSES,
  serverTimeZone,
  cardStatusInfo,
} from '../../utils/common';
import {
  POINTS_PRO_TABS_CHILDREN,
  bonusActivitySubType,
  bonusActivityType, bonusDescriptions, eStoreDateFormat,
  excludedPartnerCodes,
  excludedTransactionTypes, pendingDays,
} from './PointsProConstants';

export const getDashboardBannerData = (websiteData) => get(websiteData, ':items.challenge_banner', {});
export const getChallengeErrorData = (websiteData) => get(websiteData, ':items.challenge_error', {});

/**
 * filter out promotions based on promo codes and remove duplicated if any
 */
const getEligibleList = (
  promotionList = [],
  promoCodes = [],
  conditionStr = '',
) => promotionList.reduce((acc, val) => {
  const duplicate = acc.find(
    ({ promotionCode }) => promotionCode === val?.promotionCode,
  );
  const isActive = val?.registrationStatus === conditionStr;
  const isChallengePromotion = promoCodes.includes(val.promotionCode);

  if (!duplicate && isActive && isChallengePromotion) {
    acc.push(val);
  }

  return acc;
}, []);

/**
 * Eligibility check (for all 4 promo codes)
 */
const checkForPromoCodes = (eligiblePromotionList, promoCodes) => promoCodes?.every((el) => eligiblePromotionList.includes(el));

/**
 * Date from server timezone
 */
export const getServerDateTime = (targetDate) => DateTime.fromISO(targetDate, serverTimeZone);

/**
 * status check based on condition
 */
export const getStatus = ({
  promotions: promotionList = [],
  promoCode = '',
  childPromoCodes = [],
}) => {
  if (!isEmpty(promotionList) && !isEmpty(childPromoCodes) && promoCode) {
    const promoCodes = [...childPromoCodes, promoCode];
    const currentDate = DateTime.fromObject({}, serverTimeZone);

    // Challenge Not Accepted
    const registrablePromotions = getEligibleList(
      promotionList,
      promoCodes,
      ACTIVATION_STATUSES.ACTIVE,
    );
    const hasAllRegistrablePromoCodes = checkForPromoCodes(
      registrablePromotions.map((el) => el.promotionCode),
      promoCodes,
    );

    if (!isEmpty(registrablePromotions) && hasAllRegistrablePromoCodes) {
      const mainPromotion = registrablePromotions.find((el) => el.promotionCode === promoCode)
        || {};
      const registrationEndDate = getServerDateTime(mainPromotion?.registrationEndDate).endOf('day');

      if (hasAllRegistrablePromoCodes && currentDate <= registrationEndDate) {
        return CHALLENGE_STATUSES.NOT_ACCEPTED;
      }

      if (hasAllRegistrablePromoCodes && currentDate > registrationEndDate) {
        return CHALLENGE_STATUSES.REGISTRATION_ENDED;
      }
    }

    // Challenge Accepted
    const registeredPromotions = getEligibleList(
      promotionList,
      promoCodes,
      ACTIVATION_STATUSES.REGISTERED,
    );
    const hasAllRegisteredPromoCodes = checkForPromoCodes(
      registeredPromotions.map((el) => el.promotionCode),
      promoCodes,
    );

    if (!isEmpty(registeredPromotions) && hasAllRegisteredPromoCodes) {
      const mainPromotion = registeredPromotions.find((el) => el.promotionCode === promoCode)
        || {};
      const registrationEndDate = getServerDateTime(mainPromotion?.registrationEndDate).endOf('day');
      const activityEndDate = getServerDateTime(mainPromotion?.activityEndDate).endOf('day');
      const activityStartDate = getServerDateTime(mainPromotion?.activityStartDate).startOf('day');

      if (hasAllRegisteredPromoCodes && currentDate <= registrationEndDate) {
        return CHALLENGE_STATUSES.ACCEPTED;
      }

      if (hasAllRegisteredPromoCodes && currentDate > activityEndDate) {
        return CHALLENGE_STATUSES.ACTIVITY_ENDED;
      }

      if (hasAllRegisteredPromoCodes && currentDate > activityStartDate) {
        return CHALLENGE_STATUSES.ACTIVITY_STARTED;
      }
    }
  }

  return CHALLENGE_STATUSES.INELIGIBLE;
};

/**
 * Filter Activities API data for eligible rows
 */

export const filterActivities = (activities) => activities.filter(({ activityType, activitySubType, partner }) => (
  !(excludedPartnerCodes.includes(partner.code)
    || excludedTransactionTypes.some(
      (excludedTransaction) => (
        excludedTransaction.activityType === activityType
      && excludedTransaction.activitySubTypes.includes(activitySubType)
      ),
    )
  )
));

export const isPointsProBonusTransaction = ({
  activityType,
  activitySubType,
  description,
}) => activityType === bonusActivityType
  && activitySubType === bonusActivitySubType
  && Object.values(bonusDescriptions).some((value) => (description || '').startsWith(value));

export const getProgressStatus = ({
  activityStartDate,
  activityEndDate,
  targetPoints,
  earnedPoints,
}) => {
  const parsedActivityStartDate = getServerDateTime(activityStartDate).startOf('day');
  const parsedActivityEndDate = getServerDateTime(activityEndDate).endOf('day');
  const currentDate = DateTime.fromObject({}, serverTimeZone);
  const calculationEndDate = parsedActivityEndDate.plus({ days: pendingDays });

  if (earnedPoints >= targetPoints) {
    return cardStatusInfo.completed;
  }

  if (currentDate < parsedActivityStartDate) {
    return cardStatusInfo.inactive;
  }

  if (parsedActivityStartDate <= currentDate && currentDate < parsedActivityEndDate) {
    return cardStatusInfo.active;
  }

  if (parsedActivityEndDate <= currentDate && currentDate < calculationEndDate) {
    return cardStatusInfo.pending;
  }

  if (calculationEndDate <= currentDate) {
    return cardStatusInfo.missed;
  }

  return cardStatusInfo.inactive;
};

export const getMonthlyPoints = ({
  activityStartDate,
  activityEndDate,
  activities,
}) => {
  const parsedActivityStartDate = getServerDateTime(activityStartDate).startOf('day');
  const parsedActivityEndDate = getServerDateTime(activityEndDate).endOf('day');

  const eligibleActivities = (activities || []).filter((item) => {
    const activityDate = getServerDateTime(item?.activityDate);
    const postedDate = getServerDateTime(item?.points?.postedDate);

    return parsedActivityStartDate <= activityDate
      && activityDate <= parsedActivityEndDate
      && parsedActivityStartDate <= postedDate
      && postedDate <= parsedActivityEndDate.plus({ days: pendingDays });
  });

  return eligibleActivities.reduce((result, currentItem) => result + parseInt(currentItem?.points.awardPoints, 10), 0);
};

export const getMonthlyPendingPoints = ({
  activityStartDate,
  activityEndDate,
  pendingActivities,
}) => {
  const parsedActivityStartDate = getServerDateTime(activityStartDate).startOf('day');
  const parsedActivityEndDate = getServerDateTime(activityEndDate).endOf('day');

  const eligiblePendingActivities = (pendingActivities || []).filter(({ date }) => {
    const parsedDate = DateTime.fromFormat(date, eStoreDateFormat, serverTimeZone);

    return parsedActivityStartDate <= parsedDate && parsedDate <= parsedActivityEndDate;
  });

  return eligiblePendingActivities.reduce(
    (result, currentItem) => result + parseInt(currentItem?.commission, 10),
    0,
  );
};

// function to render authored children
export const getRenderableChildren = (Components, tab) => {
  let childrenPath;
  switch (tab) {
    case POINTS_PRO_TABS_CHILDREN.ACTIVITY.key:
      childrenPath = POINTS_PRO_TABS_CHILDREN.ACTIVITY.path;
      break;
    case POINTS_PRO_TABS_CHILDREN.CHALLENGES.key:
      childrenPath = POINTS_PRO_TABS_CHILDREN.CHALLENGES.path;
      break;
    case POINTS_PRO_TABS_CHILDREN.FAQS.key:
      childrenPath = POINTS_PRO_TABS_CHILDREN.FAQS.path;
      break;
    default:
      childrenPath = '';
      break;
  }

  if (childrenPath) {
    let children = get(window, childrenPath);
    if (Object.entries(Components).length > 0) {
      children = Object.entries(children)
        .filter((child) => Object.keys(Components).includes(child[1].componentKey))
        .map(([key, item]) => ({
          Component: Components[item.componentKey],
          childProps: item,
          fullWidth: item?.fullWidth,
          jsObjectKey: key,
          componentType: item.componentKey,
          backgroundColor: item?.backgroundColor,
        }));
      return children;
    }
    return [];
  }

  return [];
};

export const getChallengeProgressData = (websiteData) => get(websiteData, 'children.challenges.:items.challengeProgress') || {};
