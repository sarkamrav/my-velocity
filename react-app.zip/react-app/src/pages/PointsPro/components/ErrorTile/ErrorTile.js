import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';

import A from '../../../../components/Button/A';
import { isCtaAvailable } from '../../../../utils/common';
import RichTextContent from '../../../../components/RichTextContent/RichTextContent';

import styles from './ErrorTile.css';

export const infoTileDisplayMode = {
  error: 'error',
  info: 'info',
};

const ErrorTile = ({ title, description, ctaContainer, displayMode, className }) => (
  <div
    className={cx(styles.container, {
      [styles.error]: displayMode === infoTileDisplayMode.error,
    }, className)}
  >
    <div className={styles.contentContainer}>
      {
        title && (
          <div className={styles.title}>{title}</div>
        )
      }

      {
        description && (
          <RichTextContent className={styles.description} content={description} />
        )
      }

      {
        isCtaAvailable(ctaContainer) && (
          <A
            className={styles.callToAction}
            buttonType={ctaContainer.ctaStyle}
            href={ctaContainer.ctaUrl}
            title={ctaContainer.ctaTitle}
            ctaAsLink={ctaContainer.ctaAsLink}
            target={ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
          >
            {ctaContainer.ctaLabel}
          </A>
        )
      }
    </div>
  </div>
);

ErrorTile.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
  className: PropTypes.string,
  ctaContainer: PropTypes.shape({
    ctaTitle: PropTypes.string,
    ctaLabel: PropTypes.string,
    ctaUrl: PropTypes.string,
    ctaStyle: PropTypes.string,
    ctaAsLink: PropTypes.bool,
    ctaOpenInNewTab: PropTypes.bool,
  }),
  displayMode: PropTypes.oneOf([infoTileDisplayMode.error, infoTileDisplayMode.info]),
};

ErrorTile.defaultProps = {
  title: null,
  description: null,
  className: null,
  ctaContainer: null,
  displayMode: infoTileDisplayMode.info,
};

export default ErrorTile;
