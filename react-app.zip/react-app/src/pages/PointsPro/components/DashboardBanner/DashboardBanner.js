import React, { useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import get from 'lodash/get';
import cx from 'classnames';

import Header, { headerTitleTag } from '../../../../components/Header/Header';
import RichTextContent from '../../../../components/RichTextContent/RichTextContent';

import styles from './DashboardBanner.css';

const DashboardBanner = ({
  title,
  description,
  titleTag,
  renditions,
  renditionImageKey,
  children,
  contentComponent,
}) => {
  const defaultImage = get(renditions, 'imageDefault');
  const backgroundContainerRef = useRef();

  useEffect(() => {
    window.vffCoreWebsite.coreRenderImage(backgroundContainerRef.current, renditions);
  }, [renditions]);

  return (
    <div className={styles.pointsProBanner}>
      <div
        ref={backgroundContainerRef}
        rendition-image={renditionImageKey}
        className={styles.backgroundContainer}
        style={
          defaultImage
            ? {
              backgroundImage: `url(${defaultImage})`,
            }
            : null
        }
      >
        <section className={cx(styles.container, styles.welcomeSection)}>
          <div className={styles.card}>
            <Header
              tagTitle={titleTag}
              classNames={styles.title}
              title={title}
            />
            <RichTextContent
              className={styles.description}
              content={description}
            />
            {contentComponent}
          </div>
          {children}
        </section>
      </div>
    </div>
  );
};

DashboardBanner.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
  children: PropTypes.node,
  contentComponent: PropTypes.node,
  titleTag: PropTypes.string,
  renditions: PropTypes.shape({}),
  renditionImageKey: PropTypes.string,
};

DashboardBanner.defaultProps = {
  title: null,
  description: null,
  titleTag: headerTitleTag.h6,
  renditionImageKey: null,
  renditions: null,
  children: null,
  contentComponent: null,
};

export default DashboardBanner;
