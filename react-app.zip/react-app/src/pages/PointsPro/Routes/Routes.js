import React, { useContext } from 'react';
import { Redirect, Route, Switch } from 'react-router-dom/cjs/react-router-dom';

import websiteContext from '../../../contexts/WebsiteContext';

import Challenges from '../Tabs/Challenges/Challenges';
import Activity from '../Tabs/Activity/Activity';
import FAQs from '../Tabs/FAQs/FAQs';

export default function Routes() {
  const websiteData = useContext(websiteContext);

  return (
    <Switch>
      <Route path={websiteData?.children?.challenges?.pageUrl} component={Challenges} />
      <Route path={websiteData?.children?.activity?.pageUrl} component={Activity} />
      <Route path={websiteData?.children?.faqs?.pageUrl} component={FAQs} />
      <Redirect to={websiteData?.children?.challenges?.pageUrl} />
    </Switch>
  );
}
