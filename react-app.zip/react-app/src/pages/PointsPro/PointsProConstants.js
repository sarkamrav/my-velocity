export const excludedPartnerCodes = ['SNOOZE', 'FREEDOMKNW', 'MEDIBANK', 'MEDIBNKPET'];

export const eStoreDateFormat = 'yyyy-MM-dd HH:mm:ss';

export const activitySortTypes = [
  { value: 'newest', label: 'Newest' },
  { value: 'oldest', label: 'Oldest' },
  { value: 'mostPoints', label: 'Most Points' },
  { value: 'fewestPoints', label: 'Fewest Points' },
  { value: 'pending', label: 'Pending' },
];

export const bonusDescriptions = {
  overall: 'Points Pro Overall Bonus Points',
  month1: 'Points Pro Bonus 1',
  month2: 'Points Pro Bonus 2',
  month3: 'Points Pro Bonus 3',
};

export const bonusActivityType = 'PROMOTION_REWARD';
export const bonusActivitySubType = 'ACCRUAL';
export const pendingDays = 42; // 6 weeks

const activityType = {
  purchase: 'PURCHASE',
  refund: 'REFUND',
  exchange: 'EXCHANGE',
  transfer: 'TRANSFER',
  pooling: 'POOLING',
  expiry: 'EXPIRY',
  reactivate_awards: 'REACTIVATE_AWARDS',
};

const activitySubType = {
  purchase: 'PURCHASE',
  refund: 'REFUND',
  exchange: 'EXCHANGE',
  transfer: 'TRANSFER',
  transfer_from: 'TRANSFER_FROM',
  transfer_to: 'TRANSFER_TO',
  pool_transfer_from: 'POOL_TRANSFER_FROM',
  pool_transfer_to: 'POOL_TRANSFER_TO',
  expiry: 'EXPIRY',
};

export const excludedTransactionTypes = [
  {
    activityType: activityType.purchase,
    activitySubTypes: [activitySubType.purchase],
  },
  {
    activityType: activityType.refund,
    activitySubTypes: [activitySubType.refund],
  },
  {
    activityType: activityType.exchange,
    activitySubTypes: [activitySubType.exchange],
  },
  {
    activityType: activityType.transfer,
    activitySubTypes: [activitySubType.transfer, activitySubType.transfer_from, activitySubType.transfer_to],
  },
  {
    activityType: activityType.pooling,
    activitySubTypes: [activitySubType.pool_transfer_from, activitySubType.pool_transfer_to],
  },
  {
    activityType: activityType.expiry,
    activitySubTypes: [activitySubType.expiry],
  },
];

export const POINTS_PRO_TABS_CHILDREN = {
  ACTIVITY: {
    key: 'ACTIVITY',
    path: "vffCoreWebsite.spaContainer.children.activity[':items']",
  },
  CHALLENGES: {
    key: 'CHALLENGES',
    path: "vffCoreWebsite.spaContainer.children.challenges[':items']",
  },
  FAQS: {
    key: 'FAQS',
    path: "vffCoreWebsite.spaContainer.children.faqs[':items']",
  },
};
