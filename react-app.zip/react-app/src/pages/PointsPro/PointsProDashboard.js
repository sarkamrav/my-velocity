import React, { useContext, useRef } from 'react';
import cx from 'classnames';
import get from 'lodash/get';
import isEmpty from 'lodash/isEmpty';
import { DateTime } from 'luxon';
import WebsiteContext from '../../contexts/WebsiteContext';
import PointsProDashboardContext from '../../contexts/PointsProDashboardContext';
import HorizontalScroll from '../../components/HorizontalScroll/HorizontalScroll';
import Tab from './Tabs/Tab';
import Routes from './Routes/Routes';
import CountdownTimer from '../../components/CountDownTimer/CountDownTimer';
import usePointsPro from '../../hooks/usePointsPro/usePointsPro';
import { getChallengeErrorData, getChallengeProgressData, getDashboardBannerData, getStatus } from './PointsProUtils';
import Loading from '../../components/Loading/Loading';
import syncText, { CHALLENGE_STATUSES, serverTimeZone } from '../../utils/common';
import UserContext from '../../contexts/UserContext';
import * as userData from '../../utils/utilities';
import PointsProCalculations from './PointsProCalculations';
import DashboardBanner from './components/DashboardBanner/DashboardBanner';
import ErrorTile, { infoTileDisplayMode } from './components/ErrorTile/ErrorTile';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import Container from '../../components/Container/Container';

import styles from './PointsProDashboard.css';

export default function PointsProDashboard() {
  const bottomTermsAndConditions = '<p><span class="font-size font-size--extra-small"><b>*Velocity Points Pro Offer Terms and Conditions</b></span></p>'
    + '<p><span class="font-size font-size--extra-small">This ‘Velocity Points Pro’ challenge offer (<b>Velocity</b> <b>Points Pro Offer</b>) is targeted to selected Velocity members only and is not transferable. Selected members must activate the Velocity Points Pro Offer between 12:00am AEDT 20 November 2023 and 11:59pm AEDT 30 November 2023 (<b>Activation Period</b>). Selected members who activated the Velocity Points Pro Offer during the Activation Period will receive: (i) 5,500 bonus Velocity Points when they earn 25,000 Velocity Points or more with Eligible Partners between 12:00am AEDT 1 December 2023 and 11:59pm AEDT 29 February 2024 (<b>Overall Challenge Period</b>); (ii) 100 bonus Velocity Points when they earn 5,000 Velocity Points or more with Eligible Partners between 12:00am AEDT 1 December 2023 and 11:59pm AEDT 31 December 2023 (<b>Challenge Period 1</b>); (iii) 400 bonus Velocity Points when they earn 7,500 Velocity Points or more with Eligible Partners between 12:00am AEDT 1 January 2024 and 11:59pm AEDT 31 January 2024 (<b>Challenge Period 2</b>); and (iv) 1,000 bonus Velocity Points when they earn 12,500 Velocity Points or more between 12:00am AEDT 1 February 2024 and 11:59pm AEDT 29 February 2024 (<b>Challenge Period 3</b>). The Overall Challenge Period and Challenge Periods 1, 2 and 3 are each a “<b>Challenge Period</b>” and are together the “<b>Challenge Periods</b>”.</span></p>'
    + '<p><span class="font-size font-size--extra-small">When calculating the selected member’s earn total for a Challenge Period, all Velocity Points earned for Eligible Partner activities within the relevant Challenge Period and credited to the member’s account within 6 weeks of the end of the Challenge Period will contribute to the member’s earn total. For the avoidance of doubt, Points are earned on the date of the activity and not the transaction date (e.g., for flights this is the date on which the flight is flown and not on the date on which the flight is booked). For more information, please follow the link to see our FAQs. Family Pooling, Family Points transfers and the bonus Velocity Points allocated to the member for this Velocity Points Pro Offer will not contribute to the member’s earn total. “<b>Eligible Partners</b>” are all Velocity Frequent Flyer partners listed on the <a href="https://www.velocityfrequentflyer.com/partners-offers/all-partners" tabindex="0">Explore Velocity Partners</a> page, except Medibank, Medibank Pet Insurance, Freedom Kitchens and Snooze. Earn transactions, the terms on which members can earn Points and the periods for crediting Points differ between Eligible Partners and may vary depending on the member’s status level. Please check Points earn rates and applicable terms and conditions before making an eligible Points earn transaction with an Eligible Partner.</span></p>'
    + '<p><span class="font-size font-size--extra-small">Where a selected member has achieved the required earn total for a Challenge Period, the bonus Velocity Points for that Challenge Period will be credited to the member’s account within 90 days after the Overall Challenge Period date. A member may be eligible to receive bonus Points for one or more of the Challenge Periods. To earn Velocity Points, you must be a Velocity member. Velocity membership and Points earn is subject to the <a href="https://www.velocityfrequentflyer.com/member-support/terms-conditions" tabindex="0">Velocity Membership Terms and Conditions</a>, as amended from time to time.</span></p>'
    + '<p><span class="font-size font-size--extra-small">&nbsp;</span></p>';
  const tabsRef = useRef();
  const websiteData = useContext(WebsiteContext);
  const { user } = useContext(UserContext);
  const loyaltyMembershipID = userData.getLoyaltyMembershipID(user);
  const tabs = get(websiteData, 'children', {});

  const challengeBanner = getDashboardBannerData(websiteData);
  const {
    promoCode,
    childPromoCodes,
    challengeAccepted,
    challengeNotAccepted,
    renditions,
    renditionImageKey,
  } = challengeBanner;

  const { loading, loaded, error, promotionsResponse, activitiesResponse: activities, pendingActivitiesResponse } = usePointsPro(loyaltyMembershipID, promoCode);
  const { data: promotions } = promotionsResponse || {};
  const { data: pendingActivities } = pendingActivitiesResponse || {};

  const status = !isEmpty(promotions)
    ? getStatus({ promotions, promoCode, childPromoCodes })
    : {};

  const allPromoCodes = [promoCode, ...childPromoCodes];
  const pointsProPromotions = (promotions || []).filter((item) => allPromoCodes.includes(item.promotionCode));
  const mainPromotion = pointsProPromotions.find((item) => item.promotionCode === promoCode);
  const childPromotions = pointsProPromotions.filter((item) => item.promotionCode !== promoCode);

  const getAnalytics = (analytics = {}, stringify = false) => (stringify ? JSON.stringify(analytics) : analytics);

  const isChallengeAccepted = status === CHALLENGE_STATUSES.ACCEPTED;
  const shouldShowDashboard = isChallengeAccepted
    || status === CHALLENGE_STATUSES.ACTIVITY_STARTED
    || status === CHALLENGE_STATUSES.ACTIVITY_ENDED;

  const { title, titleTag, description } = isChallengeAccepted ? challengeAccepted : challengeNotAccepted;

  const challengeErrorData = getChallengeErrorData(websiteData);
  const challengeStatusData = challengeErrorData && challengeErrorData[status];
  const hasChallengeStatusData = !isEmpty(challengeStatusData);

  const challengeProgressData = getChallengeProgressData(websiteData);
  const monthlyTargetPoints = [
    ...get(
      challengeProgressData,
      'monthlyChallenge.monthlyChallengeDetails',
      [],
    ).map((item) => item?.pointsRequired),
  ].sort((a, b) => a - b);

  return (
    <PointsProDashboardContext.Provider
      value={{
        getAnalytics,
        mainPromotion,
        childPromotions,
        activities,
        pendingActivities,
      }}
    >
      <div className={styles.wrapper}>
        {loading && <Loading className={styles.pointsProLoading} />}

        {
          ((!loading && error && !loaded)
            || (!loading && !error && loaded && !shouldShowDashboard)) && (
            <>
              <DashboardBanner
                {...challengeNotAccepted}
                renditions={renditions}
                renditionImageKey={renditionImageKey}
              />

              {
                (hasChallengeStatusData || !isEmpty(challengeErrorData?.apiErrorMessage)) && (
                  <ErrorTile
                    className={cx({
                      [styles.challengeError]: !hasChallengeStatusData,
                    })}
                    displayMode={hasChallengeStatusData ? infoTileDisplayMode.info : infoTileDisplayMode.error}
                    {...(hasChallengeStatusData ? challengeStatusData : challengeErrorData?.apiErrorMessage)}
                  />
                )
              }
            </>
          )
        }

        {
          !loading && !error && loaded && shouldShowDashboard && (
            <>
              <DashboardBanner
                title={title}
                titleTag={titleTag}
                description={isChallengeAccepted ? syncText(description, {
                  activityStartDate: `${DateTime.fromISO(mainPromotion?.activityStartDate, serverTimeZone).toFormat('MMMM dd')}`,
                }) : description}
                renditions={renditions}
                renditionImageKey={renditionImageKey}
                contentComponent={status === CHALLENGE_STATUSES.ACCEPTED && (
                  <CountdownTimer targetDate={mainPromotion?.activityStartDate} />
                )}
              >
                <HorizontalScroll className={styles.horizontalScroll}>
                  <div className={styles.tabs} ref={tabsRef}>
                    {tabs
                      && Object.keys(tabs)?.map((tab) => (
                        <Tab key={tabs[tab].pageUrl} {...tabs[tab]} bannerTitle={title} />
                      ))}
                  </div>
                </HorizontalScroll>
              </DashboardBanner>

              <section className={cx(styles.container, styles.content)}>
                <PointsProCalculations
                  activities={activities}
                  mainPromotion={mainPromotion}
                  childPromotions={childPromotions}
                  pendingActivities={pendingActivities}
                  monthlyTargetPoints={monthlyTargetPoints}
                >
                  <Routes />
                </PointsProCalculations>
              </section>
            </>
          )
        }

        <Container hasBorderTop>
          <RichTextContent
            isExpandable
            truncateTextHeight={150}
            content={bottomTermsAndConditions}
          />
        </Container>
      </div>
    </PointsProDashboardContext.Provider>
  );
}
