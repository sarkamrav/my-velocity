import React from 'react';
import PropTypes from 'prop-types';
import PointsProCalculationContext from '../../contexts/PointsProCalculationContext';
import {
  filterActivities,
  getMonthlyPendingPoints,
  getMonthlyPoints,
  getProgressStatus,
  getServerDateTime,
  isPointsProBonusTransaction,
} from './PointsProUtils';

const PointsProCalculations = ({
  children,
  activities,
  mainPromotion,
  pendingActivities,
  childPromotions,
  monthlyTargetPoints,
}) => {
  const totalTargetPoints = (monthlyTargetPoints || []).reduce(
    (total, targetPoint) => total + targetPoint,
    0,
  );

  // filter activities based on partner code, transaction types and activity subtypes
  const eligibleActivities = filterActivities(activities?.data?.history || []);

  // removing all the bonus activities
  const eligibleActivitiesExcludedBonuses = (eligibleActivities || []).filter(
    (item) => !isPointsProBonusTransaction(item),
  );

  // removing all the activities except bonus activities
  const eligibleBonusActivities = (eligibleActivities || []).filter((item) => isPointsProBonusTransaction(item));

  const monthlyProgress = [...childPromotions]
    .sort(
      (a, b) => getServerDateTime(a.activityStartDate)
        - getServerDateTime(b.activityStartDate),
    )
    .map((promotion, index) => {
      const monthlyTotal = getMonthlyPoints({
        activityStartDate: promotion.activityStartDate,
        activityEndDate: promotion.activityEndDate,
        activities: eligibleActivitiesExcludedBonuses,
      });

      const progressStatus = getProgressStatus({
        activityStartDate: promotion.activityStartDate,
        activityEndDate: promotion.activityEndDate,
        targetPoints: monthlyTargetPoints[index],
        earnedPoints: monthlyTotal,
      });

      const pendingPoints = getMonthlyPendingPoints({
        activityStartDate: promotion.activityStartDate,
        activityEndDate: promotion.activityEndDate,
        pendingActivities,
      });

      return { monthlyTotal, progressStatus, pendingPoints };
    });

  const totalEarnedPoints = (monthlyProgress || []).reduce(
    (total, promotion) => total + promotion.monthlyTotal,
    0,
  );

  const totalPendingPoints = (monthlyProgress || []).reduce(
    (total, promotion) => total + promotion.pendingPoints,
    0,
  );

  const totalBonusPoints = eligibleBonusActivities.reduce((result, item) => item?.points?.awardPoints, 0);

  const mainProgressStatus = getProgressStatus({
    activityStartDate: mainPromotion?.activityStartDate,
    activityEndDate: mainPromotion?.activityEndDate,
    targetPoints: totalTargetPoints,
    earnedPoints: totalEarnedPoints,
  });

  return (
    <PointsProCalculationContext.Provider
      value={{
        eligibleActivities,
        totalEarnedPoints,
        totalBonusPoints,
        totalPendingPoints,
        monthlyProgress,
        mainProgressStatus,
        mainPromotion,
      }}
    >
      {children}
    </PointsProCalculationContext.Provider>
  );
};

PointsProCalculations.propTypes = {
  children: PropTypes.node,
  activities: PropTypes.shape({
    data: PropTypes.shape({
      history: PropTypes.arrayOf(PropTypes.shape({})),
    }),
  }),
  mainPromotion: PropTypes.shape({
    activityStartDate: PropTypes.string,
    activityEndDate: PropTypes.string,
  }),
  pendingActivities: PropTypes.arrayOf(PropTypes.shape({})),
  childPromotions: PropTypes.arrayOf(PropTypes.shape({})),
  monthlyTargetPoints: PropTypes.arrayOf(PropTypes.number),
};

PointsProCalculations.defaultProps = {
  children: null,
  activities: null,
  mainPromotion: null,
  pendingActivities: null,
  childPromotions: null,
  monthlyTargetPoints: null,
};

export default PointsProCalculations;
