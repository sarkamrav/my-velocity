import CoreFAQSection from './components/CoreFAQSection/CoreFAQSection';
import CoreAccordion from './components/CoreAccordion/CoreAccordion';

export const Components = {
  'aem-faq-content-section': CoreFAQSection,
  'aem-accordion': CoreAccordion,
};
