import React, { useEffect } from 'react';
import PropTypes from 'prop-types';

const CoreFAQSection = (props) => {
  const { jsObjectKey } = props;
  useEffect(() => {
    if (jsObjectKey) {
      if (window?.vffCoreWebsite) {
        window.vffCoreWebsite = {
          ...window.vffCoreWebsite,
          [jsObjectKey]: {
            ...props,
          },
        };
      }

      if (window?.bootstrapComponent) {
        window?.bootstrapComponent('aem-faq-content-section', jsObjectKey, true);
      }
    }
  }, [jsObjectKey]);
  if (jsObjectKey) {
    return <div aem-faq-content-section={jsObjectKey} />;
  }
  return null;
};

CoreFAQSection.propTypes = {
  jsObjectKey: PropTypes.string,
};

CoreFAQSection.defaultProps = {
  jsObjectKey: '',
};

export default CoreFAQSection;
