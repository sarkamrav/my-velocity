import React, { useEffect } from 'react';
import PropTypes from 'prop-types';

const CoreAccordion = (props) => {
  const { jsObjectKey } = props;
  useEffect(() => {
    try {
      if (jsObjectKey) {
        if (window?.vffCoreWebsite) {
          window.vffCoreWebsite = {
            ...window.vffCoreWebsite,
            [jsObjectKey]: {
              ...props,
            },
          };
        }

        if (window?.bootstrapComponent) {
          window?.bootstrapComponent('aem-accordion', jsObjectKey, true);
        }
      }
    } catch (error) {}
  }, [jsObjectKey]);
  if (jsObjectKey) {
    return <div aem-accordion={jsObjectKey} />;
  }
  return null;
};

CoreAccordion.propTypes = {
  jsObjectKey: PropTypes.string,
};

CoreAccordion.defaultProps = {
  jsObjectKey: '',
};

export default CoreAccordion;
