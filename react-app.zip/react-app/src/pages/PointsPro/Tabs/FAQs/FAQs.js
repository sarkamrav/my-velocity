import React from 'react';
import { Components } from './ComponentMap';
import { getRenderableChildren } from '../../PointsProUtils';
import { POINTS_PRO_TABS_CHILDREN } from '../../PointsProConstants';
import Container from '../../../../components/Container/Container';

export default function FAQs() {
  return (
    <div>
      {getRenderableChildren(Components, POINTS_PRO_TABS_CHILDREN.FAQS.key).map(
        ({
          Component,
          fullWidth,
          childProps,
          jsObjectKey,
          backgroundColor,
        }) => (
          <Container
            fullWidth={fullWidth}
            key={jsObjectKey}
            backgroundColor={backgroundColor}
            jsObjectKey={jsObjectKey}
          >
            <Component {...childProps} jsObjectKey={jsObjectKey} />
          </Container>
        ),
      )}
    </div>
  );
}
