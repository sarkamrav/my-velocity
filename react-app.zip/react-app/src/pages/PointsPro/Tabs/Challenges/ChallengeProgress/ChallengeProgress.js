import React, { useContext, useEffect } from 'react';
import PropTypes from 'prop-types';

import ProgressCard from '../components/ProgressCard/ProgressCard';
import MonthlyProgressCard from '../components/MonthlyProgressCard/MonthlyProgressCard';
import { cardStatusInfo } from '../../../../../utils/common';
import RichTextContent from '../../../../../components/RichTextContent/RichTextContent';

import styles from './ChallengeProgress.css';
import PointsProDashboardContext from '../../../../../contexts/PointsProDashboardContext';
import PointsProCalculationContext from '../../../../../contexts/PointsProCalculationContext';
import analytics from '../../../../../utils/analytics';

const ChallengeProgress = ({ mainChallenge, monthlyChallenge }) => {
  const { mainPromotion, childPromotions } = useContext(
    PointsProDashboardContext,
  );
  const {
    totalEarnedPoints,
    totalPendingPoints,
    monthlyProgress,
    mainProgressStatus,
  } = useContext(PointsProCalculationContext);
  const mainProgress = {
    startDate: mainPromotion?.activityStartDate,
    status: mainProgressStatus,
    pendingPoints: totalPendingPoints,
    currentPoints: totalEarnedPoints,
  };

  const monthlyProgressIntermediate = monthlyProgress.map((progress, index) => ({
    startDate: childPromotions[index]?.activityStartDate,
    endDate: childPromotions[index]?.activityEndDate,
    status: progress.progressStatus,
    pendingPoints: progress.pendingPoints,
    currentPoints: progress.monthlyTotal,
  }));
  const progressCardInfo = {
    ...mainProgress,
    totalPoints: mainChallenge?.mainChallengeDetail?.pointsRequired,
    eStoreTooltipContent:
      mainChallenge?.mainChallengeDetail?.pendingPointsTooltipMessage,
    bottomLegend: {
      heading: mainChallenge?.mainChallengeDetail?.title,
      description: mainChallenge?.mainChallengeDetail?.description,
      icon: mainChallenge?.mainChallengeDetail?.imageRef,
    },
  };

  const monthlyProgressData = monthlyProgressIntermediate.map((month, index) => {
    const monthlyChallengeDetails = monthlyChallenge?.monthlyChallengeDetails[index];

    return {
      ...month,
      targetPoints: monthlyChallengeDetails?.pointsRequired,
      pendingPointsMessage: monthlyChallengeDetails?.pendingPointsMessage,
      bottomLegend: {
        heading: monthlyChallengeDetails?.title,
        description: monthlyChallengeDetails?.description,
        icon: monthlyChallengeDetails?.imageRef,
      },
      eStoreTooltipContent:
        monthlyChallengeDetails?.pendingPointsTooltipMessage,
    };
  });

  useEffect(() => {
    if (
      mainProgress
      && monthlyProgressIntermediate
      && progressCardInfo
      && monthlyProgressData
    ) {
      analytics.send({
        eventAction: 'impression',
        eventName: 'tracker-impression',
        eventCategory: 'tracker',
        eventElementName: mainChallenge?.title || '',
        eventElementText: totalEarnedPoints,
      });
    }
  }, []);

  return (
    <div className={styles.container}>
      {mainChallenge?.title && (
        <div className={styles.progressTitle}>{mainChallenge?.title}</div>
      )}

      <ProgressCard {...progressCardInfo} />

      <div className={styles.monthlyProgressSection}>
        {mainProgress.status === cardStatusInfo.active
          && (monthlyChallenge?.title || monthlyChallenge?.description) && (
            <div className={styles.monthlyProgressSectionDescription}>
              {monthlyChallenge?.title && <h4>{monthlyChallenge?.title}</h4>}

              {monthlyChallenge?.description && (
                <RichTextContent content={monthlyChallenge?.description} />
              )}
            </div>
        )}

        {monthlyProgressData && monthlyProgressData.length > 0 && (
          <div className={styles.monthlyProgressCardsContainer}>
            {monthlyProgressData.map((data) => (
              <MonthlyProgressCard key={data?.targetPoints} {...data} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

ChallengeProgress.propTypes = {
  mainChallenge: PropTypes.shape({
    title: PropTypes.string,
    mainChallengeDetail: PropTypes.shape({
      imageRef: PropTypes.string,
      title: PropTypes.string,
      description: PropTypes.string,
      pendingPointsTooltipMessage: PropTypes.string,
      pointsRequired: PropTypes.number,
    }),
  }),
  monthlyChallenge: PropTypes.shape({
    title: PropTypes.string,
    description: PropTypes.string,
    monthlyChallengeDetails: PropTypes.arrayOf(
      PropTypes.shape({
        imageRef: PropTypes.string,
        title: PropTypes.string,
        description: PropTypes.string,
        pendingPointsTooltipMessage: PropTypes.string,
        pendingPointsMessage: PropTypes.string,
        pointsRequired: PropTypes.number,
      }),
    ),
  }),
};

ChallengeProgress.defaultProps = {
  mainChallenge: null,
  monthlyChallenge: null,
};

export default ChallengeProgress;
