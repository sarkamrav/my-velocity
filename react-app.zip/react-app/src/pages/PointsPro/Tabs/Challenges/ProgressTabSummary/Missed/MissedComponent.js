import React from 'react';
import PropTypes from 'prop-types';
import CompletedComponent from '../Completed/CompletedComponent';

const getObjectForRange = (currentPoints, data) =>
  // eslint-disable-next-line implicit-arrow-linebreak
  (data || []).find(
    (obj) => currentPoints >= Number(obj.minPoint)
      && currentPoints <= Number(obj.maxPoint),
  );

const MissedComponent = ({ rangeDetails, currentPoints, bonusPoints }) => (
  <CompletedComponent
    {...getObjectForRange(currentPoints, rangeDetails)}
    earnedPoints={currentPoints}
    bonusPoints={bonusPoints}
  />
);
MissedComponent.propTypes = {
  rangeDetails: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
  currentPoints: PropTypes.number.isRequired,
  bonusPoints: PropTypes.number.isRequired,
};

export default MissedComponent;
