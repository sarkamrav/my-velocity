import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import RichTextContent from '../../../../../../components/RichTextContent/RichTextContent';
import A from '../../../../../../components/Button/A';
import { formatPoints } from '../../../../../../utils/common';

import styles from './CompletedComponent.css';
import analytics from '../../../../../../utils/analytics';

const CompletedComponent = ({
  title,
  subTitle,
  description,
  iconUrl,
  ctaContainer,
  earnedPoints,
  bonusPoints,
}) => {
  useEffect(() => {
    analytics.send({
      eventAction: 'impression',
      eventName: 'challenge-ended-impression',
      eventCategory: 'challenge-ended',
      eventElementName: subTitle,
      eventElementText: formatPoints(earnedPoints + bonusPoints),
    });
  }, [earnedPoints, bonusPoints, formatPoints]);

  return (
    <div className={styles.completedContainer}>
      {title && (
        <div className={styles.mainHeading}>
          <h2>{title}</h2>
        </div>
      )}
      <div className={styles.content}>
        <div className={styles.text}>
          <h4 className={styles.title}>{subTitle}</h4>
          <RichTextContent content={description} className={styles.description} />
        </div>
        <div className={styles.pointsContainer}>
          <div className={styles.points}>
            <div className={styles.totalPoints}>
              <h5>Points Collected</h5>
              <p>{formatPoints(earnedPoints + bonusPoints)}</p>
            </div>
            <div className={styles.bonusAndEarnedPoints}>
              <div className={styles.earnedPoints}>
                <h6>Points earned</h6>
                <h4>{formatPoints(earnedPoints)}</h4>
              </div>
              <h4>+</h4>
              <div className={styles.bonusPoints}>
                <h6>Bonus Points</h6>
                <h4>{formatPoints(bonusPoints)}</h4>
              </div>
            </div>
          </div>
          <div className={styles.image}>
            <img src={iconUrl} alt="completed summary" />
          </div>
        </div>
        {ctaContainer && (
          <div className={styles.cta}>
            <A
              target={ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
              href={ctaContainer.ctaUrl}
            >
              {ctaContainer.ctaLabel}
            </A>
          </div>
        )}
      </div>
    </div>
  );
};

CompletedComponent.propTypes = {
  title: PropTypes.string,
  subTitle: PropTypes.string,
  description: PropTypes.string,
  iconUrl: PropTypes.string,
  ctaContainer: PropTypes.shape({
    ctaTitle: PropTypes.string,
    ctaUrl: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaType: PropTypes.string,
    ctaAsLink: PropTypes.bool,
    ctaStyle: PropTypes.string,
    ctaLabel: PropTypes.string,
  }),
  earnedPoints: PropTypes.number,
  bonusPoints: PropTypes.number,
};

CompletedComponent.defaultProps = {
  title: '',
  subTitle: '',
  description: '',
  iconUrl: '',
  ctaContainer: {
    ctaTitle: 'Terms and Conditions apply*',
    ctaUrl:
      '/content/vff/velocity/en_au/home/member-support/terms-conditions.html',
    ctaOpenInNewTab: true,
    ctaType: 'primary',
    ctaAsLink: false,
    ctaStyle: 'primary',
    ctaLabel: 'Terms and Conditions apply*',
  },
  earnedPoints: 0,
  bonusPoints: 0,
};
export default CompletedComponent;
