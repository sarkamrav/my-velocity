import React from 'react';
import PropTypes from 'prop-types';
import RichTextContent from '../../../../../../components/RichTextContent/RichTextContent';
import styles from './PendingComponent.css';
import A from '../../../../../../components/Button/A';

const PendingComponent = ({ subTitle, description, ctaContainer, iconUrl }) => (
  <div className={styles.pendingContainer}>
    <div className={styles.content}>
      <h3 className={styles.title}>{subTitle}</h3>
      <RichTextContent content={description} className={styles.description} />
      {ctaContainer && (
        <div className={styles.cta}>
          <A
            target={ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
            href={ctaContainer.ctaUrl}
          >
            {ctaContainer.ctaLabel}
          </A>
        </div>
      )}
    </div>
    {iconUrl && (
      <div className={styles.image}>
        <img src={iconUrl} alt="pending summary" />
      </div>
    )}
  </div>
);

PendingComponent.propTypes = {
  subTitle: PropTypes.string,
  description: PropTypes.string,
  ctaContainer: PropTypes.shape({
    ctaTitle: PropTypes.string,
    ctaUrl: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaType: PropTypes.string,
    ctaAsLink: PropTypes.bool,
    ctaStyle: PropTypes.string,
    ctaLabel: PropTypes.string,
  }),
  iconUrl: PropTypes.string,
};

PendingComponent.defaultProps = {
  subTitle: '',
  description: '',
  ctaContainer: {
    ctaTitle: 'Terms and Conditions apply*',
    ctaUrl:
      '/content/vff/velocity/en_au/home/member-support/terms-conditions.html',
    ctaOpenInNewTab: false,
    ctaType: 'primary',
    ctaAsLink: false,
    ctaStyle: 'primary',
    ctaLabel: 'Terms and Conditions apply*',
  },
  iconUrl: '',
};

export default PendingComponent;
