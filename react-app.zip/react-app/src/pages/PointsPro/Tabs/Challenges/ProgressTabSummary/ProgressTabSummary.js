import React, { useContext } from 'react';
import PropTypes from 'prop-types';
import { DateTime } from 'luxon';
import CompletedComponent from './Completed/CompletedComponent';
import MissedComponent from './Missed/MissedComponent';
import PendingComponent from './Pending/PendingComponent';
import { cardStatusInfo, serverTimeZone } from '../../../../../utils/common';
import PointsProCalculationContext from '../../../../../contexts/PointsProCalculationContext';
import PointsProDashboardContext from '../../../../../contexts/PointsProDashboardContext';
import { getServerDateTime } from '../../../PointsProUtils';
import styles from './ProgressTabSummary.css';

const ProgressTabSummary = ({
  completedChallenge,
  pendingChallenge,
  missedChallenge,
}) => {
  const { mainPromotion } = useContext(PointsProDashboardContext);
  const currentDate = DateTime.fromObject({}, serverTimeZone);
  const mainPromotionActivityEndDate = getServerDateTime(
    mainPromotion.activityEndDate,
  );

  const {
    totalEarnedPoints,
    totalBonusPoints,
    mainProgressStatus,
  } = useContext(PointsProCalculationContext);

  const getContent = () => {
    switch (mainProgressStatus) {
      case cardStatusInfo.completed:
        return (
          <CompletedComponent
            {...completedChallenge}
            earnedPoints={totalEarnedPoints}
            bonusPoints={totalBonusPoints}
          />
        );

      case cardStatusInfo.missed:
        return (
          <MissedComponent
            rangeDetails={[...missedChallenge]}
            currentPoints={totalEarnedPoints}
            bonusPoints={totalBonusPoints}
          />
        );

      case cardStatusInfo.pending:
        return <PendingComponent {...pendingChallenge} />;

      default:
        return null;
    }
  };

  if (currentDate >= mainPromotionActivityEndDate && getContent()) {
    return <div className={styles.container}>{getContent()}</div>;
  }
  return null;
};

ProgressTabSummary.propTypes = {
  missedChallenge: PropTypes.arrayOf(PropTypes.shape({})),
  completedChallenge: PropTypes.shape({}),
  pendingChallenge: PropTypes.shape({}),
};

ProgressTabSummary.defaultProps = {
  missedChallenge: [],
  completedChallenge: {},
  pendingChallenge: {},
};

export default ProgressTabSummary;
