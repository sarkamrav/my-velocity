import React from 'react';
import { getRenderableChildren } from '../../PointsProUtils';
import { Components } from './ComponentMap';
import Container from '../../../../components/Container/Container';
import { POINTS_PRO_TABS_CHILDREN } from '../../PointsProConstants';
import styles from './Challenges.css';

const ComponentsWithNoPadding = ['aem-content-tiles', 'aem-folist'];

function Challenges() {
  return (
    <div className={styles.challengeContainer}>
      {getRenderableChildren(
        Components,
        POINTS_PRO_TABS_CHILDREN.CHALLENGES.key,
      ).map(
        ({ Component, fullWidth, childProps, jsObjectKey, componentType, backgroundColor }) => (
          <Container
            fullWidth={fullWidth}
            key={jsObjectKey}
            noHorizontalPadding={ComponentsWithNoPadding.includes(
              componentType,
            )}
            backgroundColor={backgroundColor}
            jsObjectKey={jsObjectKey}
          >
            <Component {...childProps} jsObjectKey={jsObjectKey} />
          </Container>
        ),
      )}
    </div>
  );
}

export default Challenges;
