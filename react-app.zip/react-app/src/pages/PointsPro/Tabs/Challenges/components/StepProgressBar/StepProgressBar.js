import React from 'react';
import { DateTime } from 'luxon';
import PropTypes from 'prop-types';
import { isMobile } from 'react-device-detect';
import ProgressBar, { heightTheme } from '../../../../../../components/ProgressBar/ProgressBar';
import Circle from '../Circle/Circle';
import Months from '../Month/Months';
import Flag from '../../../../../../components/Icon/icons/flag.svg';
import { dateDifference } from '../../../../../../utils/common';
import styles from './StepProgressBar.css';

export default function StepProgressBar({ startDate, currentDate, isChallangeStart, cardStatus }) {
  const dateFormatter = (date, formate) => new DateTime(date).toFormat(formate);

  const secondMonthStartDate = startDate.plus({ month: 1 }).startOf('month');

  const thirdMonthStartDate = startDate.plus({ month: 2 }).startOf('month').startOf('day');

  const lastDateMonthStartDate = startDate.plus({ month: 3 }).startOf('month').startOf('day');

  const endDate = startDate.plus({ months: 3 });

  const totalDuration = dateDifference(startDate, endDate);

  const secondBreakPoint = dateDifference(startDate, secondMonthStartDate);

  const thirdBreakPoint = dateDifference(secondMonthStartDate, thirdMonthStartDate);

  const totalDurationNow = dateDifference(startDate, currentDate);

  const detectDevice = (date) => (isMobile ? dateFormatter(date, 'MMM') : dateFormatter(date, 'MMMM'));

  const finalBreakPoint = () => {
    if (endDate > lastDateMonthStartDate) {
      const fourthBreakPoint = dateDifference(thirdMonthStartDate, lastDateMonthStartDate);
      const lastBreakPoint = dateDifference(lastDateMonthStartDate, endDate);

      return {
        finalBreakPoints: [{
          breakPoint: (fourthBreakPoint / totalDuration) * 100,
          month: detectDevice(lastDateMonthStartDate),
          filledPercentage: dateDifference(lastDateMonthStartDate, currentDate) >= 0 ? '100%' : null,
        },
        {
          breakPoint: (lastBreakPoint / totalDuration) * 100,
          month: <Flag />,
          filledPercentage: dateDifference(endDate, currentDate) >= 0 ? '100%' : null,
        },
        ] };
    }
    return {
      breakPoint: (dateDifference(thirdMonthStartDate, endDate) / totalDuration) * 100,
      month: <Flag />,
      filledPercentage: dateDifference(endDate, currentDate) >= 0 ? '100%' : null,
    };
  };

  const bullet = [
    {
      breakPoint: 0,
      month: detectDevice(startDate),
      filledPercentage: totalDurationNow >= 0 ? '100%' : null,
    },
    {
      breakPoint: (secondBreakPoint / totalDuration) * 100,
      month: detectDevice(secondMonthStartDate),
      filledPercentage: dateDifference(secondMonthStartDate, currentDate) >= 0 ? '100%' : null,
    },
    {
      breakPoint: (thirdBreakPoint / totalDuration) * 100,
      month: detectDevice(thirdMonthStartDate),
      filledPercentage: dateDifference(thirdMonthStartDate, currentDate) >= 0 ? '100%' : null,
    },
  ];

  const percentage = (totalDurationNow / totalDuration) * 100;

  const finalData = finalBreakPoint();

  if (finalData?.finalBreakPoints) {
    finalData?.finalBreakPoints.forEach(data => {
      bullet.push(data);
    });
  } else {
    bullet.push(finalData);
  }

  const calDistance = (index) => {
    let totalWidth = 0;
    for (let i = 1; i <= index; i += 1) {
      totalWidth += bullet[i]?.breakPoint;
    }
    return totalWidth;
  };

  return (
    <div className={styles.progressContainer}>
      <div className={styles.progressWrapper}>
        { isChallangeStart && (
          <div className={styles.filledLine}>
            <ProgressBar color="purple" theme={heightTheme.narrow} cardStatus={cardStatus} done={Math.max(percentage, 5)} />
          </div>
        )}

        <div className={styles.stepbar}>
          <div className={styles.circleWrapper}>
            { bullet.map(data => <Circle key={data.month} filledPercentage={data.filledPercentage} width={`${data.breakPoint}%`} />)}
          </div>
        </div>

        <div className={styles.monthWrapper}>
          { bullet.map((data, index) => <Months key={data.month} month={data.month} width={calDistance(index)} />)}
        </div>
      </div>
    </div>
  );
}

StepProgressBar.propTypes = {
  startDate: PropTypes.oneOfType([PropTypes.object]).isRequired,
  cardStatus: PropTypes.string.isRequired,
  currentDate: PropTypes.oneOfType([PropTypes.object]).isRequired,
  isChallangeStart: PropTypes.bool.isRequired,
};
