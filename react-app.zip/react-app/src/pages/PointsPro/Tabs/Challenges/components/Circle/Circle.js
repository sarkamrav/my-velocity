import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import styles from './Circle.css';

function Circle({ width, filledPercentage }) {
  return (
    <div
      className={cx(styles.circle, {
        [styles.circleFilled]: filledPercentage,
      })}
      style={{ width }}
    />
  );
}

Circle.propTypes = {
  filledPercentage: PropTypes.string,
  width: PropTypes.string.isRequired,
};

Circle.defaultProps = {
  filledPercentage: null,
};

export default Circle;
