import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';

function CoreOfferList(props) {
  const { offers, jsObjectKey } = props;

  useEffect(() => {
    window.vffCoreWebsite = {
      ...window.vffCoreWebsite,
      [jsObjectKey]: {
        ...props,
        offers: _.compact(
          _.map(offers, (card) => (card
            ? { ...window.vffCoreWebsite[card.jsObjectKey], ...card }
            : null)),
        ),
      },
    };

    window.bootstrapComponent('aem-folist', jsObjectKey);
  }, []);

  return <div aem-folist={jsObjectKey} />;
}

CoreOfferList.propTypes = {
  offers: PropTypes.arrayOf(PropTypes.shape()),
  jsObjectKey: PropTypes.string,
};

CoreOfferList.defaultProps = {
  offers: [],
  jsObjectKey: '',
};

export default CoreOfferList;
