import React from 'react';
import { DateTime } from 'luxon';
import isEmpty from 'lodash/isEmpty';
import map from 'lodash/map';
import PropTypes from 'prop-types';
import cx from 'classnames';

import ProgressBar from '../../../../../../components/ProgressBar/ProgressBar';
import StepProgressBar from '../StepProgressBar/StepProgressBar';
import { isCtaAvailable, serverTimeZone } from '../../../../../../utils/common';
import ProgressCardContainer from '../../../../../../components/ProgressCardContainer/ProgressCardContainer';
import ProgressStatusBadge from '../ProgressStatusBadge/ProgressStatusBadge';
import BottomLegend from '../BottomLegend/BottomLegend';
import Tooltip from '../../../../../../components/Tooltip/Tooltip';
import RichTextContent from '../../../../../../components/RichTextContent/RichTextContent';
import A from '../../../../../../components/Button/A';

import styles from './ProgressCard.css';

export const progressCardDisplayMode = {
  entry: 'entry',
  default: 'default',
};

export default function ProgressCard({
  startDate,
  status,
  currentPoints,
  totalPoints,
  pendingPoints,
  bottomLegend,
  eStoreTooltipContent,
  displayMode,
  entryFooter,
}) {
  const parsedStartDate = DateTime.fromISO(startDate, serverTimeZone).startOf('day');

  const currentDate = DateTime.fromObject({}, serverTimeZone);

  const endDate = parsedStartDate.plus({ months: 2 });

  const getPercentage = () => parseInt(currentPoints * 100, 10) / parseInt(totalPoints, 10);

  const isChallengeStart = currentDate > parsedStartDate;

  return (
    <ProgressCardContainer className={styles.challengeCardContainer} cardStatus={status}>
      <div className={styles.challengeCard}>
        <div className={styles.challengeDuration}>
          <div>
            <span>
              {`${parsedStartDate.toFormat('MMMM')} '${parsedStartDate.toFormat(
                'yy',
              )} - ${endDate.toFormat('MMMM')} '${endDate.toFormat('yy')}`}
            </span>
          </div>
          <ProgressStatusBadge cardStatus={status} endDate={endDate.endOf('month')} startDate={parsedStartDate} />
        </div>
      </div>
      <div className={styles.overallPointsProgress}>
        <div className={styles.pointsEarned}>
          <span className={styles.currentPoint}>{currentPoints}</span> / <span className={styles.totalPoint}>{totalPoints}</span> <span>Points</span>
        </div>

        <ProgressBar
          className={styles.progressBar}
          cardStatus={status}
          done={getPercentage()}
        />
        {pendingPoints > 0 && (
          <Tooltip
            buttonContent={
              <div className={styles.eStorePoints}>
                + {pendingPoints} pending e-Store Points
              </div>
            }
            buttonClass={cx(styles.eStorePointsWrapper, {
              [styles.disabled]: pendingPoints <= 0,
            })}
          >
            <RichTextContent content={eStoreTooltipContent} />
          </Tooltip>
        )}
      </div>

      {
        displayMode === progressCardDisplayMode.entry && !isEmpty(entryFooter) && (
          <div
            className={cx(styles.entryFooter, {
              [styles.spacing]: pendingPoints > 0,
            })}
          >
            {
              !isEmpty(entryFooter?.icons) && (
                <div className={styles.entryIcons}>
                  {
                    map(entryFooter?.icons, (url) => (
                      <div key={url} className={styles.entryIconContainer}>
                        <img className={styles.entryIcon} src={url} alt="" />
                      </div>
                    ))
                  }
                </div>
              )
            }

            {
              isCtaAvailable(entryFooter?.ctaContainer) && (
                <A
                  className={styles.termsAndConditionCta}
                  buttonType="purple-link"
                  href={entryFooter?.ctaContainer.ctaUrl}
                  title={entryFooter?.ctaContainer.ctaTitle}
                  ctaAsLink={false}
                  target={entryFooter?.ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
                >
                  {entryFooter?.ctaContainer.ctaLabel}
                </A>
              )
            }
          </div>
        )
      }

      {
        displayMode === progressCardDisplayMode.default && (
          <>
            <StepProgressBar
              startDate={parsedStartDate}
              currentDate={currentDate}
              isChallangeStart={isChallengeStart}
              cardStatus={status}
            />

            {
              !isEmpty(bottomLegend) && (
                <BottomLegend className={styles.bottomLegend} {...bottomLegend} />
              )
            }
          </>
        )
      }
    </ProgressCardContainer>
  );
}

ProgressCard.propTypes = {
  startDate: PropTypes.string,
  status: PropTypes.string.isRequired,
  currentPoints: PropTypes.number.isRequired,
  totalPoints: PropTypes.number.isRequired,
  pendingPoints: PropTypes.number,
  bottomLegend: PropTypes.shape({
    heading: PropTypes.string,
    description: PropTypes.string,
    icon: PropTypes.string,
    bonusPoints: PropTypes.number,
  }),
  eStoreTooltipContent: PropTypes.string,
  displayMode: PropTypes.oneOf([progressCardDisplayMode.default, progressCardDisplayMode.entry]),
  entryFooter: PropTypes.shape({
    ctaContainer: PropTypes.shape({
      ctaUrl: PropTypes.string,
      ctaTitle: PropTypes.string,
      ctaOpenInNewTab: PropTypes.bool,
      ctaLabel: PropTypes.string,
    }),
    icons: PropTypes.arrayOf(PropTypes.string),
  }),
};

ProgressCard.defaultProps = {
  startDate: null,
  pendingPoints: 0,
  eStoreTooltipContent: '',
  bottomLegend: null,
  displayMode: progressCardDisplayMode.default,
  entryFooter: null,
};
