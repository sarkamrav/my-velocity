import React from 'react';
import PropTypes from 'prop-types';
import { DateTime } from 'luxon';
import cx from 'classnames';
import BottomLegend, {
  bottomLegendBadgeSize,
} from '../BottomLegend/BottomLegend';
import ProgressBar, {
  heightTheme,
} from '../../../../../../components/ProgressBar/ProgressBar';
import ProgressCardContainer from '../../../../../../components/ProgressCardContainer/ProgressCardContainer';
import Tooltip from '../../../../../../components/Tooltip/Tooltip';
import RichTextContent from '../../../../../../components/RichTextContent/RichTextContent';
import ProgressStatusBadge from '../ProgressStatusBadge/ProgressStatusBadge';
import { cardStatusInfo, serverTimeZone } from '../../../../../../utils/common';
import Icon from '../../../../../../components/Icon/Icon';

import styles from './MonthlyProgressCard.css';

const MonthlyProgressCard = ({
  status,
  targetPoints,
  currentPoints,
  startDate,
  endDate,
  pendingPoints,
  bottomLegend,
  eStoreTooltipContent,
  pendingPointsMessage,
}) => {
  const parsedStartDate = DateTime.fromISO(startDate, serverTimeZone).startOf('day');
  const parsedEndDate = DateTime.fromISO(endDate, serverTimeZone).endOf('day');

  return (
    <div className={styles.outerContainer}>
      <ProgressCardContainer className={styles.cardContainer} cardStatus={status}>
        <div className={styles.challengeDateAndStatusRow}>
          <div className={styles.dateContainer}>
            {`${parsedStartDate.toFormat('MMMM')} '${parsedStartDate.toFormat('yy')}`}
          </div>
          <div>
            <ProgressStatusBadge
              cardStatus={status}
              startDate={parsedStartDate}
              endDate={parsedEndDate}
            />
          </div>
        </div>
        <div className={styles.challengePointsRow}>
          <div className={styles.pointsCounter}>
            <p className={styles.currentPoints}>{currentPoints}</p>
            <p className={styles.targetPoints}>
              &nbsp;/&nbsp;{targetPoints}&nbsp;Points
            </p>
          </div>

          <ProgressBar
            cardStatus={status}
            theme={heightTheme.narrow}
            done={(currentPoints / targetPoints) * 100}
          />

          <div className={styles.eStoreLegendContainer}>
            <Tooltip
              buttonContent={<p>+ {pendingPoints} pending e-Store Points</p>}
              buttonClass={cx(styles.buttonClass, {
                [styles.disabled]: !pendingPoints,
              })}
              tooltipContainerClass={styles.tooltipContainerClass}
            >
              <RichTextContent content={eStoreTooltipContent} />
            </Tooltip>
          </div>
        </div>
        <BottomLegend {...bottomLegend} badgeSize={bottomLegendBadgeSize.small} />
      </ProgressCardContainer>

      {
        status === cardStatusInfo.pending && pendingPointsMessage && (
          <div className={styles.pendingInfo}>
            <Icon className={styles.pendingIcon} name="infoFilled" />
            <RichTextContent className={styles.pendingText} content={pendingPointsMessage} />
          </div>
        )
      }
    </div>
  );
};

MonthlyProgressCard.propTypes = {
  status: PropTypes.oneOf([
    cardStatusInfo.active,
    cardStatusInfo.inactive,
    cardStatusInfo.completed,
    cardStatusInfo.missed,
    cardStatusInfo.pending,
  ]).isRequired,
  targetPoints: PropTypes.number.isRequired,
  currentPoints: PropTypes.number,
  startDate: PropTypes.string,
  endDate: PropTypes.string,
  pendingPoints: PropTypes.number,
  bottomLegend: PropTypes.shape({
    heading: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
    icon: PropTypes.string,
    bonusPoints: PropTypes.number,
  }).isRequired,
  eStoreTooltipContent: PropTypes.string,
  pendingPointsMessage: PropTypes.string,
};

MonthlyProgressCard.defaultProps = {
  currentPoints: 0,
  startDate: '',
  endDate: '',
  pendingPoints: null,
  eStoreTooltipContent: '',
  pendingPointsMessage: '',
};

export default MonthlyProgressCard;
