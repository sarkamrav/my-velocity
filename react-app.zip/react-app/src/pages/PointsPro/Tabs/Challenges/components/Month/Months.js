import React from 'react';
import PropTypes from 'prop-types';
import styles from './Month.css';

function Months({ month, width }) {
  return (
    <div className={styles.month} style={{ left: `${width}%` }}>
      <span className={styles.monthLabel}>{month}</span>
    </div>
  );
}

Months.propTypes = {
  month: PropTypes.oneOfType([PropTypes.string, PropTypes.object]).isRequired,
  width: PropTypes.number.isRequired,
};

export default Months;
