import React, { useEffect } from 'react';
import PropTypes from 'prop-types';

const CoreContentTiles = (props) => {
  const { jsObjectKey } = props;
  useEffect(() => {
    if (jsObjectKey) {
      if (window?.vffCoreWebsite) {
        window.vffCoreWebsite = {
          ...window.vffCoreWebsite,
          [jsObjectKey]: {
            ...props,
          },
        };
      }

      if (window?.bootstrapComponent) {
        window?.bootstrapComponent('aem-content-tiles', jsObjectKey, true);
      }
    }
  }, [jsObjectKey]);
  if (jsObjectKey) {
    return <div aem-content-tiles={jsObjectKey} />;
  }
  return null;
};

CoreContentTiles.propTypes = {
  jsObjectKey: PropTypes.string,
};

CoreContentTiles.defaultProps = {
  jsObjectKey: '',
};

export default CoreContentTiles;
