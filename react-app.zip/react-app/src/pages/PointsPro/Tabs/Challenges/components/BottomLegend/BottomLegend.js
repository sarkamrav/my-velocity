import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import RichTextContent from '../../../../../../components/RichTextContent/RichTextContent';

import styles from './BottomLegend.css';

export const bottomLegendBadgeSize = {
  large: 'large',
  small: 'small',
};

const BottomLegend = ({
  className,
  heading,
  description,
  badgeSize,
  icon,
}) => (
  <div className={cx(styles.bottomLegendContainer, className)}>
    {
      icon && (
        <img
          className={cx(styles.badge, {
            [styles.small]: badgeSize === bottomLegendBadgeSize.small,
          })}
          src={icon}
          alt=""
        />
      )
    }

    {
      (heading || description) && (
        <div className={styles.info}>
          {
            heading && (
              <div className={styles.heading}>{heading}</div>
            )
          }

          {
            description && (
              <RichTextContent className={styles.description} content={description} />
            )
          }
        </div>
      )
    }
  </div>
);

BottomLegend.propTypes = {
  badgeSize: PropTypes.oneOf([
    bottomLegendBadgeSize.large,
    bottomLegendBadgeSize.small,
  ]),
  heading: PropTypes.string,
  description: PropTypes.string,
  icon: PropTypes.string,
  className: PropTypes.string,
};

BottomLegend.defaultProps = {
  badgeSize: bottomLegendBadgeSize.large,
  heading: '',
  description: '',
  icon: '',
  className: '',
};

export default BottomLegend;
