import React, { useEffect } from 'react';
import PropTypes from 'prop-types';

import ProgressCardLabelContainer from '../../../../../../components/ProgressCardLabelContainer/ProgressCardLabelContainer';
import Icon from '../../../../../../components/Icon/Icon';

import styles from './ProgressStatusBadge.css';

function ProgressStatusBadge({ cardStatus, startDate, endDate }) {
  const cardStatusIcon = {
    inactive: 'inactiveCalander',
    completed: 'greenTick',
    pending: 'pendingDots',
    active: 'watch',
    missed: 'hyphen',
  };

  const getStatusLabel = () => {
    if (['completed', 'pending', 'missed'].includes(cardStatus)) {
      return <span className={styles.statusLabel}>{cardStatus}</span>;
    }
    if (cardStatus === 'active') {
      return <span className={styles.statusLabel}>Ends {endDate.toFormat('dd')} {endDate.toFormat('MMM')}</span>;
    }
    return <span className={styles.statusLabel}>Starts {startDate.toFormat('dd')} {startDate.toFormat('MMM')}</span>;
  };

  useEffect(() => {
    getStatusLabel();
  }, [cardStatus]);

  return (
    <ProgressCardLabelContainer className={styles.challengeSubInfo} cardStatus={cardStatus}>
      <Icon className={styles.icon} name={cardStatusIcon[cardStatus]} />
      {getStatusLabel()}
    </ProgressCardLabelContainer>
  );
}

export default ProgressStatusBadge;

ProgressStatusBadge.propTypes = {
  startDate: PropTypes.oneOfType([PropTypes.object]).isRequired,
  endDate: PropTypes.oneOfType([PropTypes.object]).isRequired,
  cardStatus: PropTypes.string.isRequired,
};

