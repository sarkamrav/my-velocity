import RichTextContent from '../../../../components/RichTextContent/RichTextContent';
import ChallengeProgress from './ChallengeProgress/ChallengeProgress';
import ProgressTabSummary from './ProgressTabSummary/ProgressTabSummary';
import CoreImageTiles from '../../../Dashboard/MyStatus/CoreImageTiles/CoreImageTiles';
import CoreStripBanner from '../../../Dashboard/MyStatus/CoreStripBanner/CoreStripBanner';
import CoreContentTiles from './components/CoreContentTiles/CoreContentTiles';
import CoreOfferList from './components/CoreOfferList/CoreOfferList';

export const Components = {
  'aem-challenge-summary': ProgressTabSummary,
  'aem-rich-text': RichTextContent,
  'aem-challenge_progress': ChallengeProgress,
  'aem-image-tiles': CoreImageTiles,
  'aem-strip-banner': CoreStripBanner,
  'aem-content-tiles': CoreContentTiles,
  'aem-folist': CoreOfferList,
};
