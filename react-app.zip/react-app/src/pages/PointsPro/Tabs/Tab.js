import React, { useContext } from 'react';
import { Link, useLocation } from 'react-router-dom/cjs/react-router-dom';
import startsWith from 'lodash/startsWith';
import PropTypes from 'prop-types';
import cx from 'classnames';

import PointsProDashboardContext from '../../../contexts/PointsProDashboardContext';

import styles from './Tab.css';

export default function Tab({ title, pageUrl, bannerTitle }) {
  const location = useLocation();
  const { getAnalytics } = useContext(PointsProDashboardContext);

  return (
    <Link
      to={pageUrl}
      title={title}
      className={cx(styles.tab, {
        [styles.selected]: startsWith(location.pathname, pageUrl),
      })}
      analytics-metadata={getAnalytics(
        {
          eventAction: 'click',
          eventName: 'tab-interaction',
          eventCategory: 'tab',
          eventElementName: bannerTitle ? bannerTitle.replace(/(<([^>]+)>|\r|\n)/ig, '') : '',
          eventElementText: title,
        },
        true,
      )}
    >
      {title}
    </Link>
  );
}

Tab.propTypes = {
  title: PropTypes.string,
  pageUrl: PropTypes.string,
  bannerTitle: PropTypes.string,
};

Tab.defaultProps = {
  title: '',
  pageUrl: '/points-pro/',
  bannerTitle: '',
};
