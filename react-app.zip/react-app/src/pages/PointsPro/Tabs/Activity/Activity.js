import React, { useState, useContext, useEffect, useMemo } from 'react';
import { DateTime } from 'luxon';
import isEmpty from 'lodash/isEmpty';
import { isMobile } from 'react-device-detect';

import get from 'lodash/get';
import PointsProDashboardContext from '../../../../contexts/PointsProDashboardContext';
import ActivitySort from './Components/ActivitySort';
import Button from '../../../../components/Button/Button';
import Transaction from './Components/Transaction';
import { serverTimeZone } from '../../../../utils/common';
import { filterActivities, getServerDateTime, isPointsProBonusTransaction } from '../../PointsProUtils';
import { activitySortTypes, eStoreDateFormat, pendingDays } from '../../PointsProConstants';
import InfoBannerTile from './componenets/InfoBannerTile/InfoBannerTile';
import WebsiteContext from '../../../../contexts/WebsiteContext';
import NothingHere from '../../../Dashboard/MyActivity/ActivityFeed/nothing-here.svg';

import styles from './Activity.css';
import Container from '../../../../components/Container/Container';

const getRelativeDateDescription = (date) => {
  const targetDate = date.startOf('day');
  const today = DateTime.local().startOf('day');

  const diffInDays = Math.floor(today.diff(targetDate, 'days').days);

  if (diffInDays === 0) {
    return 'Today';
  } if (diffInDays === 1) {
    return 'Yesterday';
  } if (diffInDays <= 28 && diffInDays > 1) {
    return `${diffInDays} days ago`;
  }

  return '';
};

export default function Activity() {
  const initialItemsToShow = 10;
  const [itemsToShow, setItemsToShow] = useState(initialItemsToShow);
  const [sortType, setSortType] = useState('newest');
  const [sortedHistory, setSortedHistory] = useState([]);

  const websiteData = useContext(WebsiteContext);
  const infoBannerContent = get(websiteData, 'children.activity.:items.info_banner', {});

  const { activities, pendingActivities, mainPromotion } = useContext(PointsProDashboardContext);

  const activityStartDate = mainPromotion?.activityStartDate;
  const activityEndDate = mainPromotion?.activityEndDate;

  const formattedEStoreTransactions = useMemo(() => (pendingActivities || [])
    .filter(({ date }) => {
      const parsedActivityStartDate = getServerDateTime(activityStartDate).startOf('day');
      const parsedActivityEndDate = getServerDateTime(activityEndDate).endOf('day');
      const parsedDate = DateTime.fromFormat(date, eStoreDateFormat, serverTimeZone);

      return parsedActivityStartDate <= parsedDate && parsedDate <= parsedActivityEndDate;
    })
    .map(({ id, name, date, commission }) => ({
      id,
      name,
      description: `${name} e-Store Points`,
      date: DateTime.fromFormat(date, eStoreDateFormat, serverTimeZone),
      points: commission,
      isPending: true,
      isBonus: false,
    })), [pendingActivities]);

  const formattedTransactions = useMemo(() => filterActivities(activities?.data?.history || [])
    .filter((activity) => {
      const isPointsProBonusActivity = isPointsProBonusTransaction({
        activityType: activity.activityType,
        activitySubType: activity.activitySubType,
        description: activity.description,
      });

      const parsedActivityStartDate = getServerDateTime(activityStartDate).startOf('day');
      const parsedActivityEndDate = getServerDateTime(activityEndDate).endOf('day');
      const activityDate = getServerDateTime(activity?.activityDate);
      const postedDate = getServerDateTime(activity?.points?.postedDate);

      if (isPointsProBonusActivity) {
        return true;
      }

      return parsedActivityStartDate <= activityDate
          && activityDate <= parsedActivityEndDate
          && parsedActivityStartDate <= postedDate
          && postedDate <= parsedActivityEndDate.plus({ days: pendingDays });
    })
    .map(({ id, partner, description, activityDate, activityType, activitySubType, points }) => (
      {
        id,
        name: partner.commonName,
        description,
        date: DateTime.fromISO(activityDate, serverTimeZone),
        points: points.awardPoints,
        isPending: false,
        isBonus: isPointsProBonusTransaction({ activityType, activitySubType, description }),
      })), [activities?.data?.history]);

  const allTransactions = useMemo(() => formattedTransactions.concat(formattedEStoreTransactions),
    [formattedTransactions, formattedEStoreTransactions]);

  useEffect(() => {
    switch (sortType) {
      case 'newest':
      default:
        setSortedHistory([...allTransactions].sort((a, b) => b.date - a.date));
        break;
      case 'oldest':
        setSortedHistory([...allTransactions].sort((a, b) => a.date - b.date));
        break;
      case 'mostPoints':
        setSortedHistory([...allTransactions].sort((a, b) => b.points - a.points));
        break;
      case 'fewestPoints':
        setSortedHistory([...allTransactions].sort((a, b) => a.points - b.points));
        break;
      case 'pending':
        setSortedHistory([...allTransactions].sort((a, b) => {
          if (a.isPending && !b.isPending) {
            return -1;
          }
          if (!a.isPending && b.isPending) {
            return 1;
          }
          return b.date - a.date;
        }));
        break;
    }

    setItemsToShow(initialItemsToShow);
  }, [sortType, allTransactions]);

  const visibleTransactions = sortedHistory.slice(0, itemsToShow);

  const handleLoadMore = () => {
    setItemsToShow(prev => prev + 10);
  };

  const generateDateOptions = (start, end) => {
    let currentDate = DateTime.fromISO(start, serverTimeZone);
    const endDate = DateTime.fromISO(end, serverTimeZone);
    const options = [];
    while (currentDate <= endDate) {
      options.push(currentDate.toFormat('MMMM'));
      currentDate = currentDate.plus({ months: 1 });
    }
    return options;
  };

  const dateOptions = generateDateOptions(activityStartDate, activityEndDate);

  return (
    <Container jsObjectKey="activity-tab" noHorizontalPadding={isMobile}>
      {
        !isEmpty(infoBannerContent) && (
          <InfoBannerTile {...infoBannerContent} />
        )
      }
      <div className={styles.activity}>
        <div className={styles.header}>
          <h2>
            Points Pro activity
          </h2>
        </div>

        {allTransactions.length
          ? (
            <div>
              <div className={styles.detailsContainer}>
                <div>
                  {`${Math.min(itemsToShow, sortedHistory.length)} of ${sortedHistory.length} results`}
                </div>

                <div className={styles.sortContainer}>
                  <div>Sort by:</div>
                  <ActivitySort selected={sortType} options={activitySortTypes} onChange={(value) => setSortType(value)} />
                </div>
              </div>
              <div className={styles.tableHeader}>
                <div className={styles.headerContainer}>
                  <div className={styles.dateContainer}>Date</div>
                  <div>Description</div>
                </div>
                <div>Points</div>
              </div>
              <div>
                {visibleTransactions.map((transaction, i) => (
                  <div key={transaction.id}>
                    {(i === 0 || !transaction.date.hasSame(visibleTransactions[i - 1].date, 'day')) && (
                    <div className={styles.mobileHeader}>
                      <div className={styles.mobileDate}>{transaction.date.toFormat('dd LLL yy')}</div>
                      <div>{getRelativeDateDescription(transaction.date)}</div>
                    </div>
                    )}
                    <Transaction transaction={transaction} promotionMonths={dateOptions} />
                  </div>
                ))}
              </div>
            </div>
          )
          : (
            <div className={styles.emptyContainer}>
              <NothingHere className={styles.emptyIcon} />
              <h4>Nothing to see here just yet</h4>
              <p>You currently have no eligible points pro transactions</p>
            </div>
          )}
      </div>
      {itemsToShow < sortedHistory.length && (
      <div className={styles.buttonContainer}>
        <Button
          buttonType="primary"
          onClick={handleLoadMore}
          className={styles.loadMore}
        >
          Load More
        </Button>
      </div>
      )}
    </Container>
  );
}

