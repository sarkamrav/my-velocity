import React from 'react';
import PropTypes from 'prop-types';

import BlueBonus from './100-bonus.svg';
import SilverBonus from './400-bonus.svg';
import PurpleBonus from './1000-bonus.svg';
import GoldBonus from './5500-bonus.svg';
import Tooltip from '../../../../../components/Tooltip/Tooltip';
import { formatAdditionSubtraction } from '../../../../../utils/common';
import Icon from '../../../../../components/Icon/Icon';
import { bonusDescriptions } from '../../../PointsProConstants';

import styles from './Transaction.css';

const isStartWith = (value, match) => value.startsWith(match);

function getBonusMonth(description, promotionMonths) {
  if (isStartWith(description, bonusDescriptions.month1)) return promotionMonths[0];
  if (isStartWith(description, bonusDescriptions.month2)) return promotionMonths[1];
  if (isStartWith(description, bonusDescriptions.month3)) return promotionMonths[2];

  return '';
}

function Transaction({ transaction, promotionMonths }) {
  const { name, description, date, points, isPending, isBonus } = transaction;

  return (
    <div className={styles.activityRow}>
      <div className={styles.dateLabel}>
        {date.toFormat('dd LLL yy')}
      </div>
      {isBonus
        ? (
          <div className={styles.bonusContainer}>

            {isStartWith(description, bonusDescriptions.month1) && <BlueBonus className={styles.badgeWrapper} />}
            {isStartWith(description, bonusDescriptions.month2) && <SilverBonus className={styles.badgeWrapper} />}
            {isStartWith(description, bonusDescriptions.month3) && <PurpleBonus className={styles.badgeWrapper} />}
            {isStartWith(description, bonusDescriptions.overall) && <GoldBonus className={styles.badgeWrapper} />}

            {isStartWith(description, bonusDescriptions.overall) ? (
              <div className={styles.bonusDescriptionContainer}>
                <div className={styles.bold}>{'You\'ve reached your Points Accelerator goal!'}</div>
                <div>And collected a mountain of Points doing it. Great work!</div>
              </div>
            ) : (
              <div className={styles.bonusDescriptionContainer}>
                <div className={styles.bold}>{`You have reached your ${getBonusMonth(description, promotionMonths)} goal!`}</div>
                <div>{'Bonus Points don\'t count towards your Points Pro goals'}</div>
              </div>
            )}

          </div>
        )
        : (
          <div className={styles.descriptionContainer}>
            <div className={styles.textColumnContainer}>
              <div>{name}</div>
              <div>{description}</div>
            </div>
            {isPending && (
            <div>
              <Tooltip
                buttonContent={
                  <div className={styles.pendingTag}>
                    <div className={styles.pendingButton}>
                      Pending
                    </div>
                    <Icon name="infoFilled" />
                  </div>
                }
                buttonClass={styles.noPadding}
              >
                <h3 className={styles.tooltipHeader}>E-Store Points take up to 37 days to land in your account.</h3>
                <p className={styles.noMargin}>That’s why we use the purchase date not when your Points arrive to determine if you’ve met your goals.</p>
              </Tooltip>

            </div>
            )}
          </div>
        )}
      <div className={styles.pointsContainer}>
        <div className={styles.pointsLabel}>{formatAdditionSubtraction(points)}</div>
      </div>
    </div>
  );
}

Transaction.propTypes = {
  transaction: PropTypes.shape().isRequired,
  promotionMonths: PropTypes.arrayOf(PropTypes.string).isRequired,
};

export default Transaction;

