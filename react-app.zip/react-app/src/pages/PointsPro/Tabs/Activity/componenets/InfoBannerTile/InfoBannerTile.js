import React, { useState } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';

import Icon from '../../../../../../components/Icon/Icon';
import RichTextContent from '../../../../../../components/RichTextContent/RichTextContent';
import Collapse from '../../../../../../components/Collapse/Collapse';

import styles from './InfoBannerTile.css';

function InfoBannerTile({ title, description }) {
  const [isOpen, setIsOpen] = useState(false);

  function togglePopup() {
    setIsOpen((prevState) => !prevState);
  }

  return (
    <div className={cx(styles.infoBannerWrapper)}>
      <button
        className={styles.infoBannerTitle}
        aria-expanded={isOpen}
        onClick={togglePopup}
        aria-haspopup="true"
      >
        <span className={styles.title}>
          {title}
        </span>
        <div className={styles.iconWrapper}>
          <Icon
            name="newChevron"
            className={cx(styles.icon, {
              [styles.open]: isOpen,
            })}
          />
        </div>
      </button>

      <Collapse
        isOpen={isOpen}
        role="dialog"
        tabIndex="-1"
        duration={100}
      >
        <RichTextContent className={cx(styles.dialogContainer)} content={description} />
      </Collapse>
    </div>
  );
}

InfoBannerTile.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
};

InfoBannerTile.defaultProps = {
  title: null,
  description: null,
};

export default InfoBannerTile;
