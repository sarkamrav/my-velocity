import get from 'lodash/get';
import { useEffect, useState } from 'react';
import { DateTime } from 'luxon';
import promotionsMock from './mocks/getPromotions.mock.json';
import activitiesMock from './mocks/getActivities.mock.json';
import pendingActivitiesMock from './mocks/getPendingActivities.mock.json';
import eStoreUserMock from './mocks/eStoreUser.mock.json';
import { serverTimeZone } from '../../utils/common';
import { pendingDays } from '../../pages/PointsPro/PointsProConstants';
import analytics from '../../utils/analytics';

const promotionsUrl = '/loyalty/v2/promotions/registrations';
const activitiesUrl = '/loyalty/v2/experience/activities/me';
const eStoreURL = '/loyalty/v1/estore/api/users';

const mocks = {
  [promotionsUrl]: promotionsMock,
  [activitiesUrl]: activitiesMock,
  [eStoreURL]: eStoreUserMock,
  [`${eStoreURL}/purchases`]: pendingActivitiesMock,
};

const usePointsPro = (loyaltyMembershipID, promoCode) => {
  const [loading, setLoading] = useState(true);
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState(false);

  const [promotions, setPromotions] = useState({});
  const [activities, setActivities] = useState({});
  const [pendingActivities, setPendingActivities] = useState({});

  useEffect(async () => {
    if (loyaltyMembershipID && promoCode) {
      const vffV2ApiCall = async (
        url,
        { config = {}, method = 'get', postData },
      ) => {
        const { vffV2Api } = get(window, 'vffCoreWebsite.coreApi', {});
        const useMocks = get(
          window,
          'vffCoreWebsite.websiteData.useMocks',
        ) || false;
        const mock = get(mocks, url);

        if (useMocks && mock) {
          return mock;
        }

        let response = null;
        if (method === 'get') {
          response = await vffV2Api[method](
            url,
            { ...config },
          );
        }

        if (method === 'post') {
          response = await vffV2Api[method](
            url,
            postData,
            { ...config },
          );
        }

        return get(response, 'data');
      };

      try {
        setLoading(true);
        setLoaded(false);
        setError(false);
        const promotionsResponse = promoCode ? await vffV2ApiCall(promotionsUrl, {
          config: {
            params: {
              excludeBAUOffers: true,
            },
          },
        }) || {} : {};

        const { activityStartDate = '', activityEndDate = '' } = promotionsResponse?.data?.find((el) => el.promotionCode === promoCode) || {};

        if (activityStartDate && activityEndDate) {
          const apiEndDate = DateTime.fromISO(activityEndDate, serverTimeZone).plus({ days: pendingDays }).toFormat('yyyy-LL-dd');
          const activitiesResponse = await vffV2ApiCall(activitiesUrl, {
            config: {
              params: {
                startDate: activityStartDate,
                endDate: apiEndDate,
                pageOffset: 0,
                pageLimit: 100000,
                include: 'categories',
              },
            },
          }) || [];

          setActivities(activitiesResponse);
        }

        const pendingActivitiesResponse = await vffV2ApiCall(
          `${eStoreURL}/purchases`,
          {
            method: 'post',
            config: {
              params: {
                status: 1,
              },
            },
          },
        );

        setPendingActivities(pendingActivitiesResponse);

        setPromotions(promotionsResponse);
        setLoading(false);
        setLoaded(true);
      } catch (e) {
        setLoading(false);
        setLoaded(false);
        setError(true);
        analytics.send({
          eventAction: 'impression',
          eventName: 'points-pro-error',
          eventCategory: 'tracker',
          eventElementName: 'API Error',
          eventElementText: 'Failed to retrieve component',
        });
      }
    }
  }, [loyaltyMembershipID, promoCode]);

  return { loading, loaded, error, promotionsResponse: promotions, activitiesResponse: activities, pendingActivitiesResponse: pendingActivities };
};

export default usePointsPro;
