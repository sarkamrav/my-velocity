export const flightUpgradeDescription = 'Enjoy the luxury of Business Class by using a complimentary fare upgrade on your next Virgin Australia Domestic or International Short Haul flight';

export const flightUpgradeDescriptionUsed = 'You\'ve used all your complimentary flight upgrades. You can still upgrade with Points.';

export const flightUpgradeContentDescription = '<p>To request a complimentary fare upgrade from an Economy Flex fare please contact our <a href="https://experience.velocityfrequentflyer.com/member-support" target="_blank" rel="noopener noreferrer">Membership Contact Centre</a>.</p>';
