import _ from 'lodash';
import * as fragments from './fragments';

// Used for rendering of all components
window.renderMyVelocityFragments = () => {
  _.each(fragments, fragment => fragment.bootstrap());
};

// Used for rendering of a single type of component, or a specific instance
window.renderMyVelocityFragment = (elementName, id = null) => {
  const fragment = _.find(fragments, { elementName });

  if (fragment) {
    fragment.bootstrap(id);
  }
};

// Initial run of the renderers for all components
window.renderMyVelocityFragments();
