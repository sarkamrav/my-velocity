import React, { useContext, useState, useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import A from '../../components/Button/A';
import StatusGlobe from './status-globe.svg';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import { getTarget } from '../../utils/target';
import DashboardContext from '../../pages/Dashboard/DashboardContext';
import styles from './FeedItem.css';

function FeedItem({
  type, tier,
  defaultTargetActivity, mboxDefinition, analyticsData,
}) {
  const imageRef = useRef();
  const { getAnalytics } = useContext(DashboardContext);
  const [targetActivity, setTargetActivity] = useState(null);
  const [isTargeted, setIsTargeted] = useState(false);

  async function loadMbox() {
    const targetedActivity = await getTarget(mboxDefinition.mboxLocation);

    if (targetedActivity) {
      setTargetActivity(targetedActivity);
      setIsTargeted(true);
    } else {
      setTargetActivity(defaultTargetActivity);
    }
  }

  useEffect(() => {
    if (mboxDefinition.mboxLocation) {
      loadMbox();
    } else {
      setTargetActivity(defaultTargetActivity);
    }
  }, []);

  useEffect(() => {
    window.vffCoreWebsite.coreRenderImage(imageRef.current, targetActivity?.renditions);
  }, [targetActivity]);

  if (!targetActivity) return null;

  const {
    title, description, ctaContainer, terms,
  } = targetActivity;

  const commonAnalyticsData = {
    ...analyticsData,
    contentTitle: `${title}|${description}`,
    targeted: isTargeted,
  };

  return (
    <div
      className={cx(styles.container, {
        [styles.status]: type === 'status',
      }, styles[tier])}
    >
      <div className={styles.imageContainer}>
        <img ref={imageRef} alt={tier} className={styles.image} />
      </div>
      <div className={styles.content}>
        <span className={styles.title}>{title}</span>
        <RichTextContent className={styles.description} content={description} analytics-metadata={getAnalytics(commonAnalyticsData, true)} />
      </div>
      {
        ctaContainer ? (
          <div className={styles.ctaContainer}>
            <A
              buttonType={ctaContainer.ctaStyle}
              href={ctaContainer.ctaUrl}
              title={ctaContainer.ctaTitle}
              ctaAsLink={ctaContainer.ctaAsLink}
              target={ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
              analytics-metadata={getAnalytics({
                ...commonAnalyticsData,
                eventCategory: 'cta-links',
                eventName: 'cta-interaction',
              }, true)}
            >
              {ctaContainer.ctaLabel}
            </A>
            {terms ? <span className={styles.tooltip}>{terms.buttonLabel}</span> : null}
          </div>
        ) : null
      }
      { type === 'status' ? <StatusGlobe className={styles.statusGlobe} /> : null }
    </div>
  );
}

FeedItem.propTypes = {
  type: PropTypes.oneOf(['offer', 'status']),
  tier: PropTypes.oneOf(['Red', 'Silver', 'Gold', 'Platinum', 'VIP']),
  defaultTargetActivity: PropTypes.shape({
    renditions: PropTypes.shape(),
    title: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
    ctaContainer: PropTypes.shape(),
    tooltip: PropTypes.string,
  }).isRequired,
  mboxDefinition: PropTypes.shape(),
  analyticsData: PropTypes.shape(),
};

FeedItem.defaultProps = {
  type: null,
  tier: null,
  mboxDefinition: {},
  analyticsData: {},
};

export default FeedItem;
