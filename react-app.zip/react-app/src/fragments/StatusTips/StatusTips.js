import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import StatusTip from './StatusTip';
import styles from './StatusTips.css';

function StatusTips({
  defaultStatusTips,
}) {
  return (
    <div className={styles.container}>
      {
        _.map(defaultStatusTips, (tip, i) => <StatusTip defaultTip={window.vffCoreWebsite[tip.jsObjectKey]} mboxDefinition={tip.mboxDefinition} key={i} />)
      }
    </div>
  );
}

StatusTips.propTypes = {
  defaultStatusTips: PropTypes.arrayOf(PropTypes.shape()),
};

StatusTips.defaultProps = {
  defaultStatusTips: [],
};

export default StatusTips;
