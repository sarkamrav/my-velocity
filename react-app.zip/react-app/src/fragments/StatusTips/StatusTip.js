import React, { useRef, useState, useEffect, useContext } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { getTarget } from '../../utils/target';
import A from '../../components/Button/A';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import DashboardContext from '../../pages/Dashboard/DashboardContext';
import styles from './StatusTip.css';

function StatusTip({
  defaultTip, mboxDefinition,
}) {
  const { getAnalytics } = useContext(DashboardContext);
  const imageRef = useRef();
  const [statusTip, setStatusTip] = useState(null);

  async function loadMbox() {
    const targetedTip = await getTarget(mboxDefinition.mboxLocation);

    if (targetedTip) {
      setStatusTip({
        ...targetedTip,
        targeted: true,
      });
    } else {
      setStatusTip({
        ...defaultTip,
        targeted: false,
      });
    }
  }

  useEffect(() => {
    if (mboxDefinition?.mboxLocation) {
      loadMbox();
    } else {
      setStatusTip({
        ...defaultTip,
        targeted: false,
      });
    }
  }, []);

  useEffect(() => {
    window.vffCoreWebsite.coreRenderImage(imageRef.current, statusTip?.renditions);
  }, [statusTip]);

  if (!statusTip) return null;

  const { title, description, ctaContainer = {}, targeted, analyticsMetadataMap = {} } = statusTip;

  const analyticsMetadata = getAnalytics({
    ...analyticsMetadataMap,
    eventCategory: 'status-activity',
    eventName: 'status-tips-interaction',
    eventLocation: 'status-activity-dashboard-tips',
    targeted: targeted ? 'Y' : 'N',
  }, true);

  return (
    <div className={styles.card}>
      <div className={styles.imageContainer}>
        <img ref={imageRef} alt={title} className={styles.image} />
      </div>
      <div className={styles.content} analytics-metadata={analyticsMetadata}>
        <span className={styles.title}>{title}</span>
        <RichTextContent className={styles.description} content={description} />
        {
          !_.isEmpty(ctaContainer) ? (
            <A
              className={styles.link}
              buttonType={ctaContainer.ctaStyle}
              href={ctaContainer.ctaUrl}
              title={ctaContainer.ctaTitle}
              ctaAsLink={ctaContainer.ctaAsLink}
              target={ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
            >
              {ctaContainer.ctaLabel}
            </A>
          ) : null
        }
      </div>
    </div>
  );
}

StatusTip.propTypes = {
  defaultTip: PropTypes.shape(),
  mboxDefinition: PropTypes.shape(),
};

StatusTip.defaultProps = {
  defaultTip: {},
  mboxDefinition: {},
};

export default StatusTip;
