import React from 'react';
import ReactDOM from 'react-dom';
import _ from 'lodash';
import StatusTip from './StatusTip';

const ELEMENT_NAME = 'aem-status-tip';

function renderComponent(elements) {
  _.map(elements, (element) => {
    const props = window.vffCoreWebsite[element.getAttribute(ELEMENT_NAME)];
    if (props) {
      ReactDOM.render(<StatusTip defaultTip={props} />, element);
    }
  });
}

export default {
  elementName: ELEMENT_NAME,
  bootstrap: (id = null) => {
    const elements = document.querySelectorAll(`[${ELEMENT_NAME}${id ? `=${id}` : ''}]`);

    if (_.size(elements) > 0) {
      renderComponent(elements);
    }
  },
};
