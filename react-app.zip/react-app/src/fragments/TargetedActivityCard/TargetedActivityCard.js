import React, { useRef, useEffect, useState, useContext } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import A from '../../components/Button/A';
import { getTarget } from '../../utils/target';
import DashboardContext from '../../pages/Dashboard/DashboardContext';
import styles from './TargetedActivityCard.css';

function TargetedActivityCard({
  defaultTargetActivity, mboxDefinition, analyticsData,
}) {
  const imageRef = useRef();
  const { getAnalytics } = useContext(DashboardContext);
  const [targetActivity, setTargetActivity] = useState(null);
  const [isTargeted, setIsTargeted] = useState(false);

  async function loadMbox() {
    const targetedActivity = await getTarget(mboxDefinition.mboxLocation);

    if (targetedActivity) {
      setTargetActivity(targetedActivity);
      setIsTargeted(true);
    } else {
      setTargetActivity(defaultTargetActivity);
    }
  }

  useEffect(() => {
    if (mboxDefinition.mboxLocation) {
      loadMbox();
    } else {
      setTargetActivity(defaultTargetActivity);
    }
  }, [mboxDefinition]);

  useEffect(() => {
    window.vffCoreWebsite.coreRenderImage(imageRef.current, targetActivity?.renditions);
  }, [targetActivity]);

  if (!targetActivity) return null;

  const { title, description, ctaContainer } = targetActivity;

  const commonAnalyticsData = {
    ...analyticsData,
    contentTitle: `${title}|${description}`,
    targeted: isTargeted,
  };

  return (
    <div className={styles.container}>
      <div className={styles.imageContainer}>
        <img className={styles.image} alt={title} ref={imageRef} />
      </div>
      <div className={styles.content}>
        <span className={styles.title}>{title}</span>
        <RichTextContent className={styles.description} content={description} analytics-metadata={getAnalytics(commonAnalyticsData, true)} />
      </div>
      <div className={styles.footer}>
        {
          !_.isEmpty(ctaContainer) ? (
            <A
              className={styles.link}
              buttonType={ctaContainer.ctaStyle}
              href={ctaContainer.ctaUrl}
              title={ctaContainer.ctaTitle}
              target={ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
              analytics-metadata={getAnalytics({
                ...commonAnalyticsData,
                eventCategory: 'cta-links',
                eventName: 'cta-interaction',
              }, true)}
            >
              {ctaContainer.ctaLabel}
            </A>
          ) : null
        }
      </div>
    </div>
  );
}

TargetedActivityCard.propTypes = {
  defaultTargetActivity: PropTypes.shape(),
  mboxDefinition: PropTypes.shape(),
  analyticsData: PropTypes.shape(),
};

TargetedActivityCard.defaultProps = {
  defaultTargetActivity: {},
  mboxDefinition: {},
  analyticsData: {},
};

export default TargetedActivityCard;
