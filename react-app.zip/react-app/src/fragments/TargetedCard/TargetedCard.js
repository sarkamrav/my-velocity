import React, { useContext, useRef, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import A from '../../components/Button/A';
import { getTarget } from '../../utils/target';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import DashboardContext from '../../pages/Dashboard/DashboardContext';
import styles from './TargetedCard.css';

function TargetedCard({
  tileTitle, defaultTargetActivity, mboxDefinition, analyticsData,
}) {
  const imageRef = useRef();
  const { getAnalytics } = useContext(DashboardContext);
  const [targetActivity, setTargetActivity] = useState(null);
  const [isTargeted, setIsTargeted] = useState(false);

  async function loadMbox() {
    const targetedActivity = await getTarget(mboxDefinition.mboxLocation);

    if (targetedActivity) {
      setTargetActivity(targetedActivity);
      setIsTargeted(true);
    } else {
      setTargetActivity(defaultTargetActivity);
    }
  }

  useEffect(() => {
    if (mboxDefinition.mboxLocation) {
      loadMbox();
    } else {
      setTargetActivity(defaultTargetActivity);
    }
  }, []);

  useEffect(() => {
    window.vffCoreWebsite.coreRenderImage(imageRef.current, targetActivity?.renditions);
  }, [targetActivity]);

  if (!targetActivity) return null;

  const { title, description, ctaContainer } = targetActivity;

  const commonAnalyticsData = {
    ...analyticsData,
    contentTitle: `${title}|${description}`,
    targeted: isTargeted,
  };

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <span className={styles.title}>{tileTitle}</span>
      </div>
      <div className={styles.wrapper}>
        <div className={styles.imageContainer}>
          <img ref={imageRef} alt={title} className={styles.image} />
        </div>
        <div className={styles.content}>
          <span className={styles.title}>{title}</span>
          <RichTextContent className={styles.description} content={description} analytics-metadata={getAnalytics(commonAnalyticsData, true)} />
          {
            !_.isEmpty(ctaContainer) ? (
              <A
                className={styles.link}
                buttonType={ctaContainer.ctaStyle}
                href={ctaContainer.ctaUrl}
                title={ctaContainer.ctaTitle}
                ctaAsLink={ctaContainer.ctaAsLink}
                target={ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
                analytics-metadata={getAnalytics({
                  ...commonAnalyticsData,
                  eventCategory: 'cta-links',
                  eventName: 'cta-interaction',
                }, true)}
              >
                {ctaContainer.ctaLabel}
              </A>
            ) : null
          }
        </div>
      </div>
    </div>
  );
}

TargetedCard.propTypes = {
  tileTitle: PropTypes.string,
  defaultTargetActivity: PropTypes.shape(),
  mboxDefinition: PropTypes.shape(),
  analyticsData: PropTypes.shape(),
};

TargetedCard.defaultProps = {
  tileTitle: 'You might like',
  defaultTargetActivity: {},
  mboxDefinition: {},
  analyticsData: {},
};

export default TargetedCard;
