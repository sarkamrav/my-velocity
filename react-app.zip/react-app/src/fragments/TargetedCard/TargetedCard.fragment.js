import React from 'react';
import ReactDOM from 'react-dom';
import _ from 'lodash';
import TargetedCard from './TargetedCard';

const ELEMENT_NAME = 'aem-targeted-card';

function renderComponent(elements) {
  _.map(elements, (element) => {
    const props = window.vffCoreWebsite[element.getAttribute(ELEMENT_NAME)];
    if (props) {
      ReactDOM.render(<TargetedCard {...props} />, element);
    }
  });
}

export default {
  elementName: ELEMENT_NAME,
  bootstrap: (id = null) => {
    const elements = document.querySelectorAll(`[${ELEMENT_NAME}${id ? `=${id}` : ''}]`);

    if (_.size(elements) > 0) {
      renderComponent(elements);
    }
  },
};
