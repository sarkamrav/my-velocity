const presetEnv = require('postcss-preset-env');

module.exports = {
  plugins: [
    presetEnv({
      stage: 0,
      importFrom: [
        './src/styles/mediaqueries.css',
      ],
      features: {
        'custom-properties': {
          preserve: true,
          importFrom: [
            './src/styles/variables.css',
          ],
        },
      },
    }),
  ],
};
