/*
 * For a detailed explanation regarding each configuration property, visit:
 * https://jestjs.io/docs/configuration
 */

module.exports = {
  clearMocks: true,
  collectCoverage: true,
  coverageDirectory: 'coverage',
  coveragePathIgnorePatterns: [
    '/node_modules/',
  ],
  coverageReporters: [
    'json',
    'lcov',
  ],
  testEnvironment: 'jsdom',
  testPathIgnorePatterns: [
    '/node_modules/',
  ],
  transform: {
    '.+\\.(css|scss)$': 'jest-css-modules-processor',
    '^.+\\.(js|jsx)$': 'babel-jest',
    '.+\\.(svg|png|jpg|ttf|woff|woff2)$': 'jest-transform-stub',
  },
  verbose: true,
};
