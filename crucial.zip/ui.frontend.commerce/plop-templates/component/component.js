/**
 * {{pascalCase name}} class
 */

export default class {{pascalCase name}} {
  constructor(el) {
    this.el = el;

  }


  static init(el) {
    return new {{pascalCase name}}(el);
  }
}
