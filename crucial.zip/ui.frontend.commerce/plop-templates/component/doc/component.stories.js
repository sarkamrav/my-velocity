import {{pascalCase name}} from "../{{dashCase name}}.hbs";

export default {
  title: "Components/{{titleCase name}}",
  argTypes: {
  },
};

export { {{pascalCase name}} };

