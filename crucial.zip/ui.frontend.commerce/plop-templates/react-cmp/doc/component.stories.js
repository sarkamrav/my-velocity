import {{ pascalCase  name}} from "../{{ dashCase  name}}.hbs";

export default {
  title: "Components/React Component/{{ titleCase  name}}",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { {{ pascalCase  name}} };
