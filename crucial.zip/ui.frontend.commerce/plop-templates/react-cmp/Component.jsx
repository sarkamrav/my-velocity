import React from "react";

export default function {{ pascalCase  name}}({ name }) {
  return (
    <>
      <h1>Component {{ name}}</h1>
    </>
  );
}
