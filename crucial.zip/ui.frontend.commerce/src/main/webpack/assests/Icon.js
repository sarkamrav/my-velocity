import React from 'react';
import PropTypes from 'prop-types';
import * as Icons from './icon/_IconList';

import './Icon.scss';

const Icon = props => {
  const { name, className, size, ...rest } = props;
  const IconComponent = Icons[name];

  return IconComponent ? <IconComponent className={`icon size--${size} ${className}`} {...rest} /> : null;
};

Icon.propTypes = {
  name: PropTypes.string.isRequired,
  className: PropTypes.string,
  size: PropTypes.oneOf(['default', 'small', 'extra-small', 'smallest']),
};

Icon.defaultProps = {
  className: '',
  size: 'default',
};

export default Icon;
