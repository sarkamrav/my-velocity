const productFilterMock = {
  data: {
    products: {
      aggregations: [
        {
          label: 'Category',
          count: 2,
          attribute_code: 'category_uid',
          options: [
            {
              label: 'RAM',
              value: 'NA==',
              __typename: 'AggregationOption',
            },
            {
              label: 'SSD',
              value: 'Mw==',
              __typename: 'AggregationOption',
            },
          ],
          position: null,
          __typename: 'Aggregation',
        },
        {
          label: 'Price',
          count: 3,
          attribute_code: 'price',
          options: [
            {
              label: '0-100',
              value: '0_100',
              label: '0_100',
              __typename: 'AggregationOption',
            },
            {
              label: '100-200',
              value: '100_200',
              __typename: 'AggregationOption',
            },
            {
              label: '200-0',
              value: '200_0',
              __typename: 'AggregationOption',
            },
          ],
          position: null,
          __typename: 'Aggregation',
        },
        {
          label: 'Series',
          count: 2,
          attribute_code: 'series',
          options: [
            {
              label: 'Classic',
              value: '22',
              __typename: 'AggregationOption',
            },
            {
              label: 'Pro',
              value: '23',
              __typename: 'AggregationOption',
            },
          ],
          position: 0,
          __typename: 'Aggregation',
        },
        {
          label: 'Speed',
          count: 4,
          attribute_code: 'speed',
          options: [
            {
              label: 'DDR5-5200',
              value: '19',
              __typename: 'AggregationOption',
            },
            {
              label: 'DDR5-5600',
              value: '20',
              __typename: 'AggregationOption',
            },
            {
              label: 'DDR5-6000',
              value: '21',
              __typename: 'AggregationOption',
            },
            {
              label: 'DDR4-3200',
              value: '35',
              __typename: 'AggregationOption',
            },
          ],
          position: 0,
          __typename: 'Aggregation',
        },
      ],
      __typename: 'Products',
    },
  },
};

export default productFilterMock;
