const plpdata = {
  data: {
    attributeMetadata: {
      sortable: [
        {
          attribute: 'name',
          label: 'Product Name',
          numeric: false,
        },
        {
          attribute: 'position',
          label: 'Position',
          numeric: true,
        },
        {
          attribute: 'relevance',
          label: 'Relevance',
          numeric: true,
        },
        {
          attribute: 'price',
          label: 'Price',
          numeric: true,
        },
      ],
    },
    productSearch: {
      total_count: 1,
      page_info: {
        current_page: 1,
        page_size: 1,
        total_pages: 1,
      },
      items: [
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '16GB',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR5-6000',
              },
            ],
            description: '',
            id: 'UTFBeVN6RTJSell3UXpNMlZUVkMAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [
              {
                label: '',
                roles: ['image', 'small_image', 'thumbnail', 'swatch_image'],
                url: 'https://content.crucial.com/content/dam/crucial/dram-products/dram-family/ads/digital/dram-reviews-badge/crucial-dram-review-badge-2000x2000.jpg',
              },
            ],
            metaDescription: '',
            metaKeyword: '',
            metaTitle: '',
            name: 'Crucial Pro Overclocking 32GB Kit (2x16GB) DDR5-6000 UDIMM Black',
            shortDescription:
              'Push performance to the next level with the blazing speed and massive bandwidth of Crucial® DDR5 Pro Memory: Overclocking Edition. Mobilize the power of low latency to beat the clock and fuel your next win instead of worrying about performance bottlenecks. Our powerful overclocking DDR5 Pro memory supports next-gen multi-core CPUs and features Intel® XMP 3.0 and AMD EXPO™ support1 on every module.',
            sku: 'CP2K16G60C36U5B',
            externalId: '6',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-pro-overclocking-32gb-kit-2x16gb-ddr5-6000-udimm-black.html',
            urlKey: 'crucial-pro-overclocking-32gb-kit-2x16gb-ddr5-6000-udimm-black',
            price: {
              final: {
                amount: {
                  value: 99.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 164.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
      ],
      facets: [
        {
          attribute: 'categories',
          title: 'Categories',
          type: 'PINNED',
          buckets: [],
        },
        {
          attribute: 'series',
          title: 'Series',
          type: 'POPULAR',
          buckets: [
            {
              title: 'Pro',
              id: 'Pro',
              count: 1,
            },
          ],
        },
        {
          attribute: 'speed',
          title: 'Speed',
          type: 'POPULAR',
          buckets: [
            {
              title: 'DDR5-6000',
              id: 'DDR5-6000',
              count: 1,
            },
          ],
        },
        {
          attribute: 'density',
          title: 'Density',
          type: 'POPULAR',
          buckets: [
            {
              title: '16GB',
              id: '16GB',
              count: 1,
            },
          ],
        },
        {
          attribute: 'price',
          title: 'Price',
          type: 'POPULAR',
          buckets: [
            {
              title: '0.0-100.0',
              to: 100,
              from: 0,
              count: 1,
            },
          ],
        },
      ],
    },
  },
  extensions: {},
};
