const productData = {
  data: {
    attributeMetadata: {
      sortable: [
        {
          attribute: 'name',
          label: 'Product Name',
          numeric: false,
        },
        {
          attribute: 'position',
          label: 'Position',
          numeric: true,
        },
        {
          attribute: 'relevance',
          label: 'Relevance',
          numeric: true,
        },
        {
          attribute: 'price',
          label: 'Price',
          numeric: true,
        },
      ],
    },
    productSearch: {
      total_count: 75,
      page_info: {
        current_page: 1,
        page_size: 75,
        total_pages: 1,
      },
      items: [
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Power Reviews Rating Count',
                name: 'rating_count',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '1.5',
              },
            ],
            description: '',
            id: 'VkVWVFZFaFFVa05VTFRBd01RAFpHVm1ZWFZzZEEAWWprd05qRXhObVl0T0dJM05DMDBNREkwTFdJeVpqa3RaakF5TkRFNU5qTTJZbUkxAGJXRnBibDkzWldKemFYUmxYM04wYjNKbABZbUZ6WlEAVFVGSE1EQTFPVFU0TWprNQ',
            images: [],
            metaDescription: 'Heatsink protector ',
            metaKeyword: 'Heatsink protector',
            metaTitle: 'Heatsink protector',
            name: 'Heatsink protector',
            shortDescription: '',
            sku: 'TESTHPRCT-001',
            externalId: '24',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/heatsink-protector.html',
            urlKey: 'heatsink-protector',
            price: {
              final: {
                amount: {
                  value: 12.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 18.15,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '8GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-3200',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kwNFIwSXRSRVJTTkMwek1qQXdMVkJ5YncAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-8GB-DDR4-3200-Pro',
            shortDescription: '<p>crucial-memory-udimm</p>',
            sku: 'crucial-memory-udimm-Singles-8GB-DDR4-3200-Pro',
            externalId: '36',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-8gb-ddr4-3200-pro.html',
            urlKey: 'crucial-udimm-singles-8gb-ddr4-3200-pro',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 25.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '8GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-3200',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
              {
                label: 'Power Reviews Rating Count',
                name: 'rating_count',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '3.000000',
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kwNFIwSXRSRVJTTkMwek1qQXdMVU5zWVhOemFXTQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [
              {
                label: '',
                roles: ['image', 'small_image', 'thumbnail', 'swatch_image'],
                url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/media/catalog/product/c/r/crucial-pcie-gen4-nvme-ssd_2.png',
              },
            ],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-8GB-DDR4-3200-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-8GB-DDR4-3200-Classic',
            externalId: '35',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-8gb-ddr4-3200-classic.html',
            urlKey: 'crucial-udimm-singles-8gb-ddr4-3200-classic',
            price: {
              final: {
                amount: {
                  value: 75.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 85.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Brand',
                name: 'brand',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Cruical',
              },
              {
                label: 'Power Reviews Rating Count',
                name: 'rating_count',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '3.000000',
              },
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '8GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2666',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kwNFIwSXRSRVJTTkMweU5qWTJMVkJ5YncAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-8GB-DDR4-2666-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-8GB-DDR4-2666-Pro',
            externalId: '34',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-8gb-ddr4-2666-pro.html',
            urlKey: 'crucial-udimm-singles-8gb-ddr4-2666-pro',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Power Reviews Rating Count',
                name: 'rating_count',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '3.000000',
              },
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '8GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2666',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kwNFIwSXRSRVJTTkMweU5qWTJMVU5zWVhOemFXTQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-8GB-DDR4-2666-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-8GB-DDR4-2666-Classic',
            externalId: '33',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-8gb-ddr4-2666-classic.html',
            urlKey: 'crucial-udimm-singles-8gb-ddr4-2666-classic',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '8GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2400',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kwNFIwSXRSRVJTTkMweU5EQXdMVkJ5YncAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-8GB-DDR4-2400-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-8GB-DDR4-2400-Pro',
            externalId: '32',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-8gb-ddr4-2400-pro.html',
            urlKey: 'crucial-udimm-singles-8gb-ddr4-2400-pro',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '8GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2400',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kwNFIwSXRSRVJTTkMweU5EQXdMVU5zWVhOemFXTQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-8GB-DDR4-2400-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-8GB-DDR4-2400-Classic',
            externalId: '31',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-8gb-ddr4-2400-classic.html',
            urlKey: 'crucial-udimm-singles-8gb-ddr4-2400-classic',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '4',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-3200',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kwMExVUkVValF0TXpJd01DMVFjbTgAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-4-DDR4-3200-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-4-DDR4-3200-Pro',
            externalId: '30',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-4-ddr4-3200-pro.html',
            urlKey: 'crucial-udimm-singles-4-ddr4-3200-pro',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '4',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-3200',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kwMExVUkVValF0TXpJd01DMURiR0Z6YzJsagBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-4-DDR4-3200-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-4-DDR4-3200-Classic',
            externalId: '29',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-4-ddr4-3200-classic.html',
            urlKey: 'crucial-udimm-singles-4-ddr4-3200-classic',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '4',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2666',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kwMExVUkVValF0TWpZMk5pMVFjbTgAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-4-DDR4-2666-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-4-DDR4-2666-Pro',
            externalId: '28',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-4-ddr4-2666-pro.html',
            urlKey: 'crucial-udimm-singles-4-ddr4-2666-pro',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '4',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2666',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kwMExVUkVValF0TWpZMk5pMURiR0Z6YzJsagBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-4-DDR4-2666-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-4-DDR4-2666-Classic',
            externalId: '27',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-4-ddr4-2666-classic.html',
            urlKey: 'crucial-udimm-singles-4-ddr4-2666-classic',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '4',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2400',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kwMExVUkVValF0TWpRd01DMVFjbTgAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-4-DDR4-2400-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-4-DDR4-2400-Pro',
            externalId: '26',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-4-ddr4-2400-pro.html',
            urlKey: 'crucial-udimm-singles-4-ddr4-2400-pro',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '4',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2400',
              },
              {
                label: 'Variants Sort Order',
                name: 'variants_sort',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '2',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kwMExVUkVValF0TWpRd01DMURiR0Z6YzJsagBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-4-DDR4-2400-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-4-DDR4-2400-Classic',
            externalId: '25',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-4-ddr4-2400-classic.html',
            urlKey: 'crucial-udimm-singles-4-ddr4-2400-classic',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '32GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-3200',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kwek1rZENMVVJFVWpRdE16SXdNQzFRY204AFpHVm1ZWFZzZEEAWWprd05qRXhObVl0T0dJM05DMDBNREkwTFdJeVpqa3RaakF5TkRFNU5qTTJZbUkxAGJXRnBibDkzWldKemFYUmxYM04wYjNKbABZbUZ6WlEAVFVGSE1EQTFPVFU0TWprNQ',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-32GB-DDR4-3200-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-32GB-DDR4-3200-Pro',
            externalId: '48',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-32gb-ddr4-3200-pro.html',
            urlKey: 'crucial-udimm-singles-32gb-ddr4-3200-pro',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '32GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-3200',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kwek1rZENMVVJFVWpRdE16SXdNQzFEYkdGemMybGoAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-32GB-DDR4-3200-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-32GB-DDR4-3200-Classic',
            externalId: '47',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-32gb-ddr4-3200-classic.html',
            urlKey: 'crucial-udimm-singles-32gb-ddr4-3200-classic',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '32GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2666',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kwek1rZENMVVJFVWpRdE1qWTJOaTFRY204AFpHVm1ZWFZzZEEAWWprd05qRXhObVl0T0dJM05DMDBNREkwTFdJeVpqa3RaakF5TkRFNU5qTTJZbUkxAGJXRnBibDkzWldKemFYUmxYM04wYjNKbABZbUZ6WlEAVFVGSE1EQTFPVFU0TWprNQ',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-32GB-DDR4-2666-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-32GB-DDR4-2666-Pro',
            externalId: '46',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-32gb-ddr4-2666-pro.html',
            urlKey: 'crucial-udimm-singles-32gb-ddr4-2666-pro',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '32GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2666',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kwek1rZENMVVJFVWpRdE1qWTJOaTFEYkdGemMybGoAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-32GB-DDR4-2666-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-32GB-DDR4-2666-Classic',
            externalId: '45',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-32gb-ddr4-2666-classic.html',
            urlKey: 'crucial-udimm-singles-32gb-ddr4-2666-classic',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '32GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2400',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kwek1rZENMVVJFVWpRdE1qUXdNQzFRY204AFpHVm1ZWFZzZEEAWWprd05qRXhObVl0T0dJM05DMDBNREkwTFdJeVpqa3RaakF5TkRFNU5qTTJZbUkxAGJXRnBibDkzWldKemFYUmxYM04wYjNKbABZbUZ6WlEAVFVGSE1EQTFPVFU0TWprNQ',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-32GB-DDR4-2400-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-32GB-DDR4-2400-Pro',
            externalId: '44',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-32gb-ddr4-2400-pro.html',
            urlKey: 'crucial-udimm-singles-32gb-ddr4-2400-pro',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '32GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2400',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kwek1rZENMVVJFVWpRdE1qUXdNQzFEYkdGemMybGoAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-32GB-DDR4-2400-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-32GB-DDR4-2400-Classic',
            externalId: '43',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-32gb-ddr4-2400-classic.html',
            urlKey: 'crucial-udimm-singles-32gb-ddr4-2400-classic',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '16GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-3200',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kweE5rZENMVVJFVWpRdE16SXdNQzFRY204AFpHVm1ZWFZzZEEAWWprd05qRXhObVl0T0dJM05DMDBNREkwTFdJeVpqa3RaakF5TkRFNU5qTTJZbUkxAGJXRnBibDkzWldKemFYUmxYM04wYjNKbABZbUZ6WlEAVFVGSE1EQTFPVFU0TWprNQ',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-16GB-DDR4-3200-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-16GB-DDR4-3200-Pro',
            externalId: '42',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-16gb-ddr4-3200-pro.html',
            urlKey: 'crucial-udimm-singles-16gb-ddr4-3200-pro',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '16GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-3200',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kweE5rZENMVVJFVWpRdE16SXdNQzFEYkdGemMybGoAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-16GB-DDR4-3200-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-16GB-DDR4-3200-Classic',
            externalId: '41',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-16gb-ddr4-3200-classic.html',
            urlKey: 'crucial-udimm-singles-16gb-ddr4-3200-classic',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '16GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2666',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kweE5rZENMVVJFVWpRdE1qWTJOaTFRY204AFpHVm1ZWFZzZEEAWWprd05qRXhObVl0T0dJM05DMDBNREkwTFdJeVpqa3RaakF5TkRFNU5qTTJZbUkxAGJXRnBibDkzWldKemFYUmxYM04wYjNKbABZbUZ6WlEAVFVGSE1EQTFPVFU0TWprNQ',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-16GB-DDR4-2666-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-16GB-DDR4-2666-Pro',
            externalId: '40',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-16gb-ddr4-2666-pro.html',
            urlKey: 'crucial-udimm-singles-16gb-ddr4-2666-pro',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '16GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2666',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kweE5rZENMVVJFVWpRdE1qWTJOaTFEYkdGemMybGoAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-16GB-DDR4-2666-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-16GB-DDR4-2666-Classic',
            externalId: '39',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-16gb-ddr4-2666-classic.html',
            urlKey: 'crucial-udimm-singles-16gb-ddr4-2666-classic',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '16GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2400',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kweE5rZENMVVJFVWpRdE1qUXdNQzFRY204AFpHVm1ZWFZzZEEAWWprd05qRXhObVl0T0dJM05DMDBNREkwTFdJeVpqa3RaakF5TkRFNU5qTTJZbUkxAGJXRnBibDkzWldKemFYUmxYM04wYjNKbABZbUZ6WlEAVFVGSE1EQTFPVFU0TWprNQ',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-16GB-DDR4-2400-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-16GB-DDR4-2400-Pro',
            externalId: '38',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-16gb-ddr4-2400-pro.html',
            urlKey: 'crucial-udimm-singles-16gb-ddr4-2400-pro',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '16GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Singles',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2400',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFUybHVaMnhsY3kweE5rZENMVVJFVWpRdE1qUXdNQzFEYkdGemMybGoAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Singles-16GB-DDR4-2400-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Singles-16GB-DDR4-2400-Classic',
            externalId: '37',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-singles-16gb-ddr4-2400-classic.html',
            urlKey: 'crucial-udimm-singles-16gb-ddr4-2400-classic',
            price: {
              final: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 15.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '8GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-3200',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTA0UjBJdFJFUlNOQzB6TWpBd0xWQnlieTB5AFpHVm1ZWFZzZEEAWWprd05qRXhObVl0T0dJM05DMDBNREkwTFdJeVpqa3RaakF5TkRFNU5qTTJZbUkxAGJXRnBibDkzWldKemFYUmxYM04wYjNKbABZbUZ6WlEAVFVGSE1EQTFPVFU0TWprNQ',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-8GB-DDR4-3200-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-8GB-DDR4-3200-Pro-2',
            externalId: '89',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-8gb-ddr4-3200-pro-ppss.html',
            urlKey: 'crucial-udimm-kits-8gb-ddr4-3200-pro-ppss',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '8GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-3200',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTA0UjBJdFJFUlNOQzB6TWpBd0xVTnNZWE56YVdNdE1nAFpHVm1ZWFZzZEEAWWprd05qRXhObVl0T0dJM05DMDBNREkwTFdJeVpqa3RaakF5TkRFNU5qTTJZbUkxAGJXRnBibDkzWldKemFYUmxYM04wYjNKbABZbUZ6WlEAVFVGSE1EQTFPVFU0TWprNQ',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-8GB-DDR4-3200-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-8GB-DDR4-3200-Classic-2',
            externalId: '87',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-8gb-ddr4-3200-classic-iis.html',
            urlKey: 'crucial-udimm-kits-8gb-ddr4-3200-classic-iis',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '8GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2666',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTA0UjBJdFJFUlNOQzB5TmpZMkxWQnlieTB5AFpHVm1ZWFZzZEEAWWprd05qRXhObVl0T0dJM05DMDBNREkwTFdJeVpqa3RaakF5TkRFNU5qTTJZbUkxAGJXRnBibDkzWldKemFYUmxYM04wYjNKbABZbUZ6WlEAVFVGSE1EQTFPVFU0TWprNQ',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-8GB-DDR4-2666-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-8GB-DDR4-2666-Pro-2',
            externalId: '97',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-8gb-ddr4-2666-pro-tus.html',
            urlKey: 'crucial-udimm-kits-8gb-ddr4-2666-pro-tus',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '8GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2666',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTA0UjBJdFJFUlNOQzB5TmpZMkxVTnNZWE56YVdNdE1nAFpHVm1ZWFZzZEEAWWprd05qRXhObVl0T0dJM05DMDBNREkwTFdJeVpqa3RaakF5TkRFNU5qTTJZbUkxAGJXRnBibDkzWldKemFYUmxYM04wYjNKbABZbUZ6WlEAVFVGSE1EQTFPVFU0TWprNQ',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-8GB-DDR4-2666-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-8GB-DDR4-2666-Classic-2',
            externalId: '95',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-8gb-ddr4-2666-classic-rr.html',
            urlKey: 'crucial-udimm-kits-8gb-ddr4-2666-classic-rr',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '8GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2400',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTA0UjBJdFJFUlNOQzB5TkRBd0xWQnlieTB5AFpHVm1ZWFZzZEEAWWprd05qRXhObVl0T0dJM05DMDBNREkwTFdJeVpqa3RaakF5TkRFNU5qTTJZbUkxAGJXRnBibDkzWldKemFYUmxYM04wYjNKbABZbUZ6WlEAVFVGSE1EQTFPVFU0TWprNQ',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-8GB-DDR4-2400-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-8GB-DDR4-2400-Pro-2',
            externalId: '93',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-8gb-ddr4-2400-pro-si.html',
            urlKey: 'crucial-udimm-kits-8gb-ddr4-2400-pro-si',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '8GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2400',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTA0UjBJdFJFUlNOQzB5TkRBd0xVTnNZWE56YVdNdE1nAFpHVm1ZWFZzZEEAWWprd05qRXhObVl0T0dJM05DMDBNREkwTFdJeVpqa3RaakF5TkRFNU5qTTJZbUkxAGJXRnBibDkzWldKemFYUmxYM04wYjNKbABZbUZ6WlEAVFVGSE1EQTFPVFU0TWprNQ',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-8GB-DDR4-2400-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-8GB-DDR4-2400-Classic-2',
            externalId: '91',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-8gb-ddr4-2400-classic-yty.html',
            urlKey: 'crucial-udimm-kits-8gb-ddr4-2400-classic-yty',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: false,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '4',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-3200',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTAwTFVSRVVqUXRNekl3TUMxUWNtOHRNZwBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-4-DDR4-3200-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-4-DDR4-3200-Pro-2',
            externalId: '117',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-4-ddr4-3200-pro-sdsd.html',
            urlKey: 'crucial-udimm-kits-4-ddr4-3200-pro-sdsd',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: false,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '4',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-3200',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTAwTFVSRVVqUXRNekl3TUMxRGJHRnpjMmxqTFRJAFpHVm1ZWFZzZEEAWWprd05qRXhObVl0T0dJM05DMDBNREkwTFdJeVpqa3RaakF5TkRFNU5qTTJZbUkxAGJXRnBibDkzWldKemFYUmxYM04wYjNKbABZbUZ6WlEAVFVGSE1EQTFPVFU0TWprNQ',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-4-DDR4-3200-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-4-DDR4-3200-Classic-2',
            externalId: '116',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-4-ddr4-3200-classic-sssd.html',
            urlKey: 'crucial-udimm-kits-4-ddr4-3200-classic-sssd',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: false,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '4',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2666',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTAwTFVSRVVqUXRNalkyTmkxUWNtOHRNZwBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-4-DDR4-2666-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-4-DDR4-2666-Pro-2',
            externalId: '121',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-4-ddr4-2666-pro-qwe.html',
            urlKey: 'crucial-udimm-kits-4-ddr4-2666-pro-qwe',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: false,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '4',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2666',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTAwTFVSRVVqUXRNalkyTmkxRGJHRnpjMmxqTFRJAFpHVm1ZWFZzZEEAWWprd05qRXhObVl0T0dJM05DMDBNREkwTFdJeVpqa3RaakF5TkRFNU5qTTJZbUkxAGJXRnBibDkzWldKemFYUmxYM04wYjNKbABZbUZ6WlEAVFVGSE1EQTFPVFU0TWprNQ',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-4-DDR4-2666-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-4-DDR4-2666-Classic-2',
            externalId: '120',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-4-ddr4-2666-classic-sps.html',
            urlKey: 'crucial-udimm-kits-4-ddr4-2666-classic-sps',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: false,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '4',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2400',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTAwTFVSRVVqUXRNalF3TUMxUWNtOHRNZwBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-4-DDR4-2400-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-4-DDR4-2400-Pro-2',
            externalId: '119',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-4-ddr4-2400-proww.html',
            urlKey: 'crucial-udimm-kits-4-ddr4-2400-proww',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: false,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '4',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2400',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTAwTFVSRVVqUXRNalF3TUMxRGJHRnpjMmxqTFRJAFpHVm1ZWFZzZEEAWWprd05qRXhObVl0T0dJM05DMDBNREkwTFdJeVpqa3RaakF5TkRFNU5qTTJZbUkxAGJXRnBibDkzWldKemFYUmxYM04wYjNKbABZbUZ6WlEAVFVGSE1EQTFPVFU0TWprNQ',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-4-DDR4-2400-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-4-DDR4-2400-Classic-2',
            externalId: '118',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-4-ddr4-2400-classicsd.html',
            urlKey: 'crucial-udimm-kits-4-ddr4-2400-classicsd',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '32GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-3200',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTB6TWtkQ0xVUkVValF0TXpJd01DMVFjbTh0TWcAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-32GB-DDR4-3200-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-32GB-DDR4-3200-Pro-2',
            externalId: '111',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-32gb-ddr4-3200-pro-vv.html',
            urlKey: 'crucial-udimm-kits-32gb-ddr4-3200-pro-vv',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '32GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-3200',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTB6TWtkQ0xVUkVValF0TXpJd01DMURiR0Z6YzJsakxUSQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-32GB-DDR4-3200-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-32GB-DDR4-3200-Classic-2',
            externalId: '110',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-32gb-ddr4-3200-classic-vvx.html',
            urlKey: 'crucial-udimm-kits-32gb-ddr4-3200-classic-vvx',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: false,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '32GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2666',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTB6TWtkQ0xVUkVValF0TWpZMk5pMVFjbTh0TWcAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-32GB-DDR4-2666-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-32GB-DDR4-2666-Pro-2',
            externalId: '115',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-32gb-ddr4-2666-pro-pss.html',
            urlKey: 'crucial-udimm-kits-32gb-ddr4-2666-pro-pss',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: false,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '32GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2666',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTB6TWtkQ0xVUkVValF0TWpZMk5pMURiR0Z6YzJsakxUSQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-32GB-DDR4-2666-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-32GB-DDR4-2666-Classic-2',
            externalId: '114',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-32gb-ddr4-2666-classics.html',
            urlKey: 'crucial-udimm-kits-32gb-ddr4-2666-classics',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '32GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2400',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTB6TWtkQ0xVUkVValF0TWpRd01DMVFjbTh0TWcAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-32GB-DDR4-2400-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-32GB-DDR4-2400-Pro-2',
            externalId: '113',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-32gb-ddr4-2400-pro-12.html',
            urlKey: 'crucial-udimm-kits-32gb-ddr4-2400-pro-12',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '32GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2400',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTB6TWtkQ0xVUkVValF0TWpRd01DMURiR0Z6YzJsakxUSQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-32GB-DDR4-2400-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-32GB-DDR4-2400-Classic-2',
            externalId: '112',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-32gb-ddr4-2400-classic-aa.html',
            urlKey: 'crucial-udimm-kits-32gb-ddr4-2400-classic-aa',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '16GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-3200',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTB4TmtkQ0xVUkVValF0TXpJd01DMVFjbTh0TWcAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-16GB-DDR4-3200-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-16GB-DDR4-3200-Pro-2',
            externalId: '101',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-16gb-ddr4-3200-pro-yy.html',
            urlKey: 'crucial-udimm-kits-16gb-ddr4-3200-pro-yy',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '16GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-3200',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTB4TmtkQ0xVUkVValF0TXpJd01DMURiR0Z6YzJsakxUSQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-16GB-DDR4-3200-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-16GB-DDR4-3200-Classic-2',
            externalId: '99',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-16gb-ddr4-3200-classic-tt.html',
            urlKey: 'crucial-udimm-kits-16gb-ddr4-3200-classic-tt',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '16GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2666',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTB4TmtkQ0xVUkVValF0TWpZMk5pMVFjbTh0TWcAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-16GB-DDR4-2666-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-16GB-DDR4-2666-Pro-2',
            externalId: '109',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-16gb-ddr4-2666-pro-mm.html',
            urlKey: 'crucial-udimm-kits-16gb-ddr4-2666-pro-mm',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '16GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2666',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTB4TmtkQ0xVUkVValF0TWpZMk5pMURiR0Z6YzJsakxUSQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-16GB-DDR4-2666-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-16GB-DDR4-2666-Classic-2',
            externalId: '107',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-16gb-ddr4-2666-classic-p.html',
            urlKey: 'crucial-udimm-kits-16gb-ddr4-2666-classic-p',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '16GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2400',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTB4TmtkQ0xVUkVValF0TWpRd01DMVFjbTh0TWcAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-16GB-DDR4-2400-Pro',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-16GB-DDR4-2400-Pro-2',
            externalId: '105',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-16gb-ddr4-2400-pro-ks.html',
            urlKey: 'crucial-udimm-kits-16gb-ddr4-2400-pro-ks',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '16GB',
              },
              {
                label: 'Package Type',
                name: 'package_type',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Kits',
              },
              {
                label: 'Parent SKU',
                name: 'parent_sku',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'crucial-memory-udimm',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-2400',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwdFMybDBjeTB4TmtkQ0xVUkVValF0TWpRd01DMURiR0Z6YzJsakxUSQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM-Kits-16GB-DDR4-2400-Classic',
            shortDescription: '',
            sku: 'crucial-memory-udimm-Kits-16GB-DDR4-2400-Classic-2',
            externalId: '103',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm-kits-16gb-ddr4-2400-classic-oe.html',
            urlKey: 'crucial-udimm-kits-16gb-ddr4-2400-classic-oe',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Capacity',
                name: 'capacity',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '500GB',
              },
              {
                label: 'Thermal',
                name: 'thermal',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Heatsink',
              },
              {
                label: 'Weight',
                name: 'weight',
                roles: ['visible_in_pdp'],
                value: 1,
              },
            ],
            description: '',
            id: 'WTNKMVkybGhiQzF0WlcxdmNua3RkV1JwYlcwAFpHVm1ZWFZzZEEAWWprd05qRXhObVl0T0dJM05DMDBNREkwTFdJeVpqa3RaakF5TkRFNU5qTTJZbUkxAGJXRnBibDkzWldKemFYUmxYM04wYjNKbABZbUZ6WlEAVFVGSE1EQTFPVFU0TWprNQ',
            images: [],
            metaDescription: 'Crucial UDIMM ',
            metaKeyword: 'Crucial UDIMM',
            metaTitle: 'Crucial UDIMM',
            name: 'Crucial UDIMM',
            shortDescription: '',
            sku: 'crucial-memory-udimm',
            externalId: '49',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-udimm.html',
            urlKey: 'crucial-udimm',
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Capacity',
                name: 'capacity',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '500GB',
              },
              {
                label: 'Thermal',
                name: 'thermal',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Heatsink',
              },
              {
                label: 'Variants Sort Order',
                name: 'variants_sort',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '0',
              },
            ],
            description: '',
            id: 'TVRFMVJqaEJNa05CTlVOQk56TXdOQQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: 'Crucial T705 PCIe 5.0 NVMe M.2 SSD with limited edition white heatsink ',
            metaKeyword: 'Crucial T705 PCIe 5.0 NVMe M.2 SSD with limited edition white heatsink',
            metaTitle: 'Crucial T705 PCIe 5.0 NVMe M.2 SSD with limited edition white heatsink',
            name: 'Crucial T705 PCIe 5.0 NVMe M.2 SSD with limited edition white heatsink',
            shortDescription:
              '<p>Hold on tight — the Crucial® T705 Gen5 NVMe® SSD is taking Gen5 performance to the next level. Fuel your gaming, create at the speed of ideas, and power through AI applications with ease with this fully optimized Gen5 masterpiece that works with your motherboard heatsink.</p>',
            sku: '115F8A2CA5CA7304',
            externalId: '2',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-t705-pcie-5-0-nvme-m-2-ssd-with-limited-edition-white-heatsink.html',
            urlKey: 'crucial-t705-pcie-5-0-nvme-m-2-ssd-with-limited-edition-white-heatsink',
            price: {
              final: {
                amount: {
                  value: 479.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 479.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Capacity',
                name: 'capacity',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '500GB',
              },
              {
                label: 'Thermal',
                name: 'thermal',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Heatsink',
              },
            ],
            description: '',
            id: 'UTFReU1EQXdWRGN3TlZOVFJEVkIAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [],
            metaDescription: 'Crucial T705 PCIe 5.0 NVMe M.2 SSD with limited edition white heatsink ',
            metaKeyword: 'Crucial T705 PCIe 5.0 NVMe M.2 SSD with limited edition white heatsink',
            metaTitle: 'Crucial T705 PCIe 5.0 NVMe M.2 SSD with limited edition white heatsink',
            name: 'Crucial T705 PCIe 5.0 NVMe M.2 SSD with limited edition white heatsink',
            shortDescription:
              '<p>Hold on tight — the Crucial® T705 Gen5 NVMe® SSD is taking Gen5 performance to the next level. Fuel your gaming, create at the speed of ideas, and power through AI applications with ease with this fully optimized Gen5 masterpiece that works with your motherboard heatsink.</p>',
            sku: 'CT2000T705SSD5A',
            externalId: '2',
            url: 'http://integration-5ojmyuq-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-t705-pcie-5-0-nvme-m-2-ssd-with-limited-edition-white-heatsink.html',
            urlKey: 'crucial-t705-pcie-5-0-nvme-m-2-ssd-with-limited-edition-white-heatsink',
            price: {
              final: {
                amount: {
                  value: 479.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 479.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Variants Sort Order',
                name: 'variants_sort',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '0',
              },
            ],
            description: '',
            id: 'T0RoQlF6RTRPVUpCTlVOQk56TXdOQQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: 'Crucial T705 1TB PCIe Gen5 NVMe M.2 SSD with heatsink ',
            metaKeyword: 'Crucial T705 1TB PCIe Gen5 NVMe M.2 SSD with heatsink',
            metaTitle: 'Crucial T705 1TB PCIe Gen5 NVMe M.2 SSD with heatsink',
            name: 'Crucial T705 1TB PCIe Gen5 NVMe M.2 SSD with heatsink',
            shortDescription:
              '<p>Hold on tight — the Crucial® T705 Gen5 NVMe® SSD is taking Gen5 performance to the next level. Fuel your gaming, create at the speed of ideas, and power through AI applications with ease with this fully optimized Gen5 masterpiece that works with your motherboard heatsink.</p>',
            sku: '88AC189BA5CA7304',
            externalId: '1',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-t705-1tb-pcie-gen5-nvme-m-2-ssd-with-heatsink.html',
            urlKey: 'crucial-t705-1tb-pcie-gen5-nvme-m-2-ssd-with-heatsink',
            price: {
              final: {
                amount: {
                  value: 175,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 259.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: null,
            inStock: true,
            attributes: [],
            description: '',
            id: 'T0VaQ01VUXdPRFpCTlVOQk56TXdOQQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: 'Crucial T705 1TB PCIe Gen5 NVMe M.2 SSD with heatsink ',
            metaKeyword: 'Crucial T705 1TB PCIe Gen5 NVMe M.2 SSD with heatsink',
            metaTitle: 'Crucial T705 1TB PCIe Gen5 NVMe M.2 SSD with heatsink',
            name: 'Crucial T705 1TB PCIe Gen5 NVMe M.2 SSD with heatsink',
            shortDescription:
              '<p>Hold on tight — the Crucial® T705 Gen5 NVMe® SSD is taking Gen5 performance to the next level. Fuel your gaming, create at the speed of ideas, and power through AI applications with ease with this fully optimized Gen5 masterpiece that works with your motherboard heatsink.</p>',
            sku: '8FB1D086A5CA7304',
            externalId: '1',
            url: 'http://integration-5ojmyuq-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-t705-1tb-pcie-gen5-nvme-m-2-ssd-with-heatsink.html',
            urlKey: 'crucial-t705-1tb-pcie-gen5-nvme-m-2-ssd-with-heatsink',
            price: null,
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: false,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '16GB',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR5-6000',
              },
              {
                label: 'Variants Sort Order',
                name: 'variants_sort',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '0',
              },
            ],
            description: '',
            id: 'UTFBeVN6RTJSell3UXpNMlZUVkMAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [
              {
                label: '',
                roles: ['image', 'small_image', 'thumbnail', 'swatch_image'],
                url: 'https://content.crucial.com/content/dam/crucial/dram-products/dram-family/ads/digital/dram-reviews-badge/crucial-dram-review-badge-2000x2000.jpg',
              },
            ],
            metaDescription: '',
            metaKeyword: '',
            metaTitle: '',
            name: 'Crucial Pro Overclocking 32GB Kit (2x16GB) DDR5-6000 UDIMM Black',
            shortDescription:
              'Push performance to the next level with the blazing speed and massive bandwidth of Crucial® DDR5 Pro Memory: Overclocking Edition. Mobilize the power of low latency to beat the clock and fuel your next win instead of worrying about performance bottlenecks. Our powerful overclocking DDR5 Pro memory supports next-gen multi-core CPUs and features Intel® XMP 3.0 and AMD EXPO™ support1 on every module.',
            sku: 'CP2K16G60C36U5B',
            externalId: '6',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-pro-overclocking-32gb-kit-2x16gb-ddr5-6000-udimm-black.html',
            urlKey: 'crucial-pro-overclocking-32gb-kit-2x16gb-ddr5-6000-udimm-black',
            price: {
              final: {
                amount: {
                  value: 99.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 164.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '16GB',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Classic',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR5-6000',
              },
            ],
            description: '',
            id: 'UTFBeE5rYzJNRU16TmxVMVFnAFpHVm1ZWFZzZEEAWWprd05qRXhObVl0T0dJM05DMDBNREkwTFdJeVpqa3RaakF5TkRFNU5qTTJZbUkxAGJXRnBibDkzWldKemFYUmxYM04wYjNKbABZbUZ6WlEAVFVGSE1EQTFPVFU0TWprNQ',
            images: [
              {
                label: '',
                roles: ['image', 'small_image', 'thumbnail'],
                url: 'https://content.crucial.com/content/dam/crucial/dram-products/laptop/images/product/crucial-ddr4-sodimm-kit-2.psd.transform/medium-png/image.png',
              },
            ],
            metaDescription: '',
            metaKeyword: '',
            metaTitle: '',
            name: 'Crucial Pro Overclocking 16GB DDR5-6000 UDIMM Black',
            shortDescription:
              'Push performance to the next level with the blazing speed and massive bandwidth of Crucial® DDR5 Pro Memory: Overclocking Edition. Mobilize the power of low latency to beat the clock and fuel your next win instead of worrying about performance bottlenecks. Our powerful overclocking DDR5 Pro memory supports next-gen multi-core CPUs and features Intel® XMP 3.0 and AMD EXPO™ support1 on every module.',
            sku: 'CP16G60C36U5B',
            externalId: '5',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-pro-overclocking-16gb-ddr5-6000-udimm-black.html',
            urlKey: 'crucial-pro-overclocking-16gb-ddr5-6000-udimm-black',
            price: {
              final: {
                amount: {
                  value: 0,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 79.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '48GB',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR5-5600',
              },
            ],
            description: '',
            id: 'UTFBeVN6UTRSelUyUXpRMlZUVQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: '',
            metaKeyword: '',
            metaTitle: '',
            name: 'Crucial Pro 96GB Kit (2x48GB) DDR5-5600 UDIMM',
            shortDescription:
              'Crucial® DDR5 Pro Memory has the blazing speed and massive bandwidth needed to support next-gen multi-core CPUs without the fuss of overclocking, latency tuning, die chasing, and LEDs.',
            sku: 'CP2K48G56C46U5',
            externalId: '8',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-pro-96gb-kit-2x48gb-ddr5-5600-udimm.html',
            urlKey: 'crucial-pro-96gb-kit-2x48gb-ddr5-5600-udimm',
            price: {
              final: {
                amount: {
                  value: 264.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 264.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '32GB',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR5-5600',
              },
            ],
            description: '',
            id: 'UTFBeVN6TXlSelUyUXpRMlZUVQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: '',
            metaKeyword: '',
            metaTitle: '',
            name: 'Crucial Pro 64GB Kit (2x32GB) DDR5-5600 UDIMM',
            shortDescription:
              'Crucial® DDR5 Pro Memory has the blazing speed and massive bandwidth needed to support next-gen multi-core CPUs without the fuss of overclocking, latency tuning, die chasing, and LEDs.',
            sku: 'CP2K32G56C46U5',
            externalId: '9',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-pro-64gb-kit-2x32gb-ddr5-5600-udimm.html',
            urlKey: 'crucial-pro-64gb-kit-2x32gb-ddr5-5600-udimm',
            price: {
              final: {
                amount: {
                  value: 178.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 272.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: false,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '32GB',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-3200',
              },
            ],
            description: '',
            id: 'UTFBeVN6TXlSelJFUmxKQk16SkIAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [],
            metaDescription: '',
            metaKeyword: '',
            metaTitle: '',
            name: 'Crucial Pro 64GB Kit (2x32GB) DDR4-3200 UDIMM',
            shortDescription:
              'Load programs faster and increase responsiveness without the fuss of overclocking, latency tuning, die chasing, and LEDs. Run data-intensive applications with ease and increase your desktop’s multitasking capabilities with Intel® XMP 2.0 support for performance recovery and a low-profile aluminum heat spreader for heat dissipation.',
            sku: 'CP2K32G4DFRA32A',
            externalId: '13',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-pro-64gb-kit-2x32gb-ddr4-3200-udimm.html',
            urlKey: 'crucial-pro-64gb-kit-2x32gb-ddr4-3200-udimm',
            price: {
              final: {
                amount: {
                  value: 161.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 161.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '24GB',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR5-6000',
              },
            ],
            description: '',
            id: 'UTFBeVN6STBSell3UXpRNFZUVQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: '',
            metaKeyword: '',
            metaTitle: '',
            name: 'Crucial Pro 48GB Kit (2x24GB) DDR5-6000 UDIMM',
            shortDescription:
              'Crucial® DDR5 Pro Memory has the blazing speed and massive bandwidth needed to support next-gen multi-core CPUs without the fuss of overclocking, latency tuning, die chasing, and LEDs.',
            sku: 'CP2K24G60C48U5',
            externalId: '7',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-pro-48gb-kit-2x24gb-ddr5-6000-udimm.html',
            urlKey: 'crucial-pro-48gb-kit-2x24gb-ddr5-6000-udimm',
            price: {
              final: {
                amount: {
                  value: 153.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 210.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '24GB',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR5-5600',
              },
            ],
            description: '',
            id: 'UTFBeVN6STBSelUyUXpRMlZUVQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: '',
            metaKeyword: '',
            metaTitle: '',
            name: 'Crucial Pro 48GB Kit (2x24GB) DDR5-5600 UDIMM',
            shortDescription:
              'Crucial® DDR5 Pro Memory has the blazing speed and massive bandwidth needed to support next-gen multi-core CPUs without the fuss of overclocking, latency tuning, die chasing, and LEDs.',
            sku: 'CP2K24G56C46U5',
            externalId: '10',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-pro-48gb-kit-2x24gb-ddr5-5600-udimm.html',
            urlKey: 'crucial-pro-48gb-kit-2x24gb-ddr5-5600-udimm',
            price: {
              final: {
                amount: {
                  value: 152.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 208.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '48GB',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR5-5600',
              },
            ],
            description: '',
            id: 'UTFBME9FYzFOa00wTmxVMQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: '',
            metaKeyword: '',
            metaTitle: '',
            name: 'Crucial Pro 48GB DDR5-5600 UDIMM',
            shortDescription:
              'Crucial® DDR5 Pro Memory has the blazing speed and massive bandwidth needed to support next-gen multi-core CPUs without the fuss of overclocking, latency tuning, die chasing, and LEDs.',
            sku: 'CP48G56C46U5',
            externalId: '21',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-pro-48gb-ddr5-5600-udimm.html',
            urlKey: 'crucial-pro-48gb-ddr5-5600-udimm',
            price: {
              final: {
                amount: {
                  value: 149,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 149,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '16GB',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR5-6000',
              },
            ],
            description: '',
            id: 'UTFBeVN6RTJSell3UXpRNFZUVQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: '',
            metaKeyword: '',
            metaTitle: '',
            name: 'Crucial Pro 32GB Kit (2x16GB) DDR5-6000 UDIMM',
            shortDescription:
              'Crucial® DDR5 Pro Memory has the blazing speed and massive bandwidth needed to support next-gen multi-core CPUs without the fuss of overclocking, latency tuning, die chasing, and LEDs.',
            sku: 'CP2K16G60C48U5',
            externalId: '15',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-pro-32gb-kit-2x16gb-ddr5-6000-udimm.html',
            urlKey: 'crucial-pro-32gb-kit-2x16gb-ddr5-6000-udimm',
            price: {
              final: {
                amount: {
                  value: 88.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 149.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '16GB',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR5-5600',
              },
            ],
            description: '',
            id: 'UTFBeVN6RTJSelUyUXpRMlZUVQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: '',
            metaKeyword: '',
            metaTitle: '',
            name: 'Crucial Pro 32GB Kit (2x16GB) DDR5-5600 UDIMM',
            shortDescription:
              'Crucial® DDR5 Pro Memory has the blazing speed and massive bandwidth needed to support next-gen multi-core CPUs without the fuss of overclocking, latency tuning, die chasing, and LEDs.',
            sku: 'CP2K16G56C46U5',
            externalId: '11',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-pro-32gb-kit-2x16gb-ddr5-5600-udimm.html',
            urlKey: 'crucial-pro-32gb-kit-2x16gb-ddr5-5600-udimm',
            price: {
              final: {
                amount: {
                  value: 114.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 149.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '16GB',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-3200',
              },
            ],
            description: '',
            id: 'UTFBeVN6RTJSelJFUmxKQk16SkIAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [],
            metaDescription: '',
            metaKeyword: '',
            metaTitle: '',
            name: 'Crucial Pro 32GB Kit (2x16GB) DDR4-3200 UDIMM',
            shortDescription:
              'Load programs faster and increase responsiveness without the fuss of overclocking, latency tuning, die chasing, and LEDs. Run data-intensive applications with ease and increase your desktop’s multitasking capabilities with Intel® XMP 2.0 support for performance recovery and a low-profile aluminum heat spreader for heat dissipation.',
            sku: 'CP2K16G4DFRA32A',
            externalId: '12',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-pro-32gb-kit-2x16gb-ddr4-3200-udimm.html',
            urlKey: 'crucial-pro-32gb-kit-2x16gb-ddr4-3200-udimm',
            price: {
              final: {
                amount: {
                  value: 57.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 92.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: false,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '32GB',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR5-5600',
              },
            ],
            description: '',
            id: 'UTFBek1rYzFOa00wTmxVMQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: '',
            metaKeyword: '',
            metaTitle: '',
            name: 'Crucial Pro 32GB DDR5-5600 UDIMM',
            shortDescription:
              'Crucial® DDR5 Pro Memory has the blazing speed and massive bandwidth needed to support next-gen multi-core CPUs without the fuss of overclocking, latency tuning, die chasing, and LEDs.',
            sku: 'CP32G56C46U5',
            externalId: '20',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-pro-32gb-ddr5-5600-udimm.html',
            urlKey: 'crucial-pro-32gb-ddr5-5600-udimm',
            price: {
              final: {
                amount: {
                  value: 129.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 129.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: false,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '32GB',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-3200',
              },
            ],
            description: '',
            id: 'UTFBek1rYzBSRVpTUVRNeVFRAFpHVm1ZWFZzZEEAWWprd05qRXhObVl0T0dJM05DMDBNREkwTFdJeVpqa3RaakF5TkRFNU5qTTJZbUkxAGJXRnBibDkzWldKemFYUmxYM04wYjNKbABZbUZ6WlEAVFVGSE1EQTFPVFU0TWprNQ',
            images: [],
            metaDescription: '',
            metaKeyword: '',
            metaTitle: '',
            name: 'Crucial Pro 32GB DDR4-3200 UDIMM',
            shortDescription:
              'Load programs faster and increase responsiveness without the fuss of overclocking, latency tuning, die chasing, and LEDs. Run data-intensive applications with ease and increase your desktop’s multitasking capabilities with Intel® XMP 2.0 support for performance recovery and a low-profile aluminum heat spreader for heat dissipation.',
            sku: 'CP32G4DFRA32A',
            externalId: '17',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-pro-32gb-ddr4-3200-udimm.html',
            urlKey: 'crucial-pro-32gb-ddr4-3200-udimm',
            price: {
              final: {
                amount: {
                  value: 84.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 84.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '24GB',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR5-6000',
              },
            ],
            description: '',
            id: 'UTFBeU5FYzJNRU0wT0ZVMQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: '',
            metaKeyword: '',
            metaTitle: '',
            name: 'Crucial Pro 24GB DDR5-6000 UDIMM',
            shortDescription:
              'Crucial® DDR5 Pro Memory has the blazing speed and massive bandwidth needed to support next-gen multi-core CPUs without the fuss of overclocking, latency tuning, die chasing, and LEDs.',
            sku: 'CP24G60C48U5',
            externalId: '22',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-pro-24gb-ddr5-6000-udimm.html',
            urlKey: 'crucial-pro-24gb-ddr5-6000-udimm',
            price: {
              final: {
                amount: {
                  value: 93.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 93.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '24GB',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR5-5600',
              },
            ],
            description: '',
            id: 'UTFBeU5FYzFOa00wTmxVMQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: '',
            metaKeyword: '',
            metaTitle: '',
            name: 'Crucial Pro 24GB DDR5-5600 UDIMM',
            shortDescription:
              'Crucial® DDR5 Pro Memory has the blazing speed and massive bandwidth needed to support next-gen multi-core CPUs without the fuss of overclocking, latency tuning, die chasing, and LEDs.',
            sku: 'CP24G56C46U5',
            externalId: '19',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-pro-24gb-ddr5-5600-udimm.html',
            urlKey: 'crucial-pro-24gb-ddr5-5600-udimm',
            price: {
              final: {
                amount: {
                  value: 83.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 83.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '16GB',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR5-6000',
              },
            ],
            description: '',
            id: 'UTFBeE5rYzJNRU0wT0ZVMQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: '',
            metaKeyword: '',
            metaTitle: '',
            name: 'Crucial Pro 16GB DDR5-6000 UDIMM',
            shortDescription:
              'Crucial® DDR5 Pro Memory has the blazing speed and massive bandwidth needed to support next-gen multi-core CPUs without the fuss of overclocking, latency tuning, die chasing, and LEDs.',
            sku: 'CP16G60C48U5',
            externalId: '14',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-pro-16gb-ddr5-6000-udimm.html',
            urlKey: 'crucial-pro-16gb-ddr5-6000-udimm',
            price: {
              final: {
                amount: {
                  value: 68.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 71.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: false,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '16GB',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR5-5600',
              },
            ],
            description: '',
            id: 'UTFBeE5rYzFOa00wTmxVMQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: '',
            metaKeyword: '',
            metaTitle: '',
            name: 'Crucial Pro 16GB DDR5-5600 UDIMM',
            shortDescription:
              'Crucial® DDR5 Pro Memory has the blazing speed and massive bandwidth needed to support next-gen multi-core CPUs without the fuss of overclocking, latency tuning, die chasing, and LEDs.',
            sku: 'CP16G56C46U5',
            externalId: '18',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-pro-16gb-ddr5-5600-udimm.html',
            urlKey: 'crucial-pro-16gb-ddr5-5600-udimm',
            price: {
              final: {
                amount: {
                  value: 64.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 64.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '16GB',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR4-3200',
              },
            ],
            description: '',
            id: 'UTFBeE5rYzBSRVpTUVRNeVFRAFpHVm1ZWFZzZEEAWWprd05qRXhObVl0T0dJM05DMDBNREkwTFdJeVpqa3RaakF5TkRFNU5qTTJZbUkxAGJXRnBibDkzWldKemFYUmxYM04wYjNKbABZbUZ6WlEAVFVGSE1EQTFPVFU0TWprNQ',
            images: [],
            metaDescription: '',
            metaKeyword: '',
            metaTitle: '',
            name: 'Crucial Pro 16GB DDR4-3200 UDIMM',
            shortDescription:
              'Load programs faster and increase responsiveness without the fuss of overclocking, latency tuning, die chasing, and LEDs. Run data-intensive applications with ease and increase your desktop’s multitasking capabilities with Intel® XMP 2.0 support for performance recovery and a low-profile aluminum heat spreader for heat dissipation.',
            sku: 'CP16G4DFRA32A',
            externalId: '16',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-pro-16gb-ddr4-3200-udimm.html',
            urlKey: 'crucial-pro-16gb-ddr4-3200-udimm',
            price: {
              final: {
                amount: {
                  value: 47.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 47.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '16GB',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR5-5200',
              },
            ],
            description: '',
            id: 'UTFReVN6RTJSelJUUmxKQk16SkIAWkdWbVlYVnNkQQBZamt3TmpFeE5tWXRPR0kzTkMwME1ESTBMV0l5WmprdFpqQXlOREU1TmpNMlltSTEAYldGcGJsOTNaV0p6YVhSbFgzTjBiM0psAFltRnpaUQBUVUZITURBMU9UVTRNams1',
            images: [],
            metaDescription: 'Crucial 32GB Kit (2x16GB) DDR4-3200 SODIMM ',
            metaKeyword: 'Crucial 32GB Kit (2x16GB) DDR4-3200 SODIMM',
            metaTitle: 'Crucial 32GB Kit (2x16GB) DDR4-3200 SODIMM',
            name: 'Crucial 32GB Kit (2x16GB) DDR4-3200 SODIMM',
            shortDescription:
              '<p>Designed to help your system run faster and smoother, Crucial Laptop Memory is one of the easiest and most affordable ways to improve your system’s performance.</p>',
            sku: 'CT2K16G4SFRA32A',
            externalId: '4',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-32gb-kit-2x16gb-ddr4-3200-sodimm.html',
            urlKey: 'crucial-32gb-kit-2x16gb-ddr4-3200-sodimm',
            price: {
              final: {
                amount: {
                  value: 75.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 75.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
        {
          productView: {
            addToCartAllowed: null,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '48GB',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR5-6000',
              },
            ],
            description: '',
            id: 'UTFReE5rYzBVMFpTUVRNeVFRAFpHVm1ZWFZzZEEAWWprd05qRXhObVl0T0dJM05DMDBNREkwTFdJeVpqa3RaakF5TkRFNU5qTTJZbUkxAGJXRnBibDkzWldKemFYUmxYM04wYjNKbABZbUZ6WlEAVFVGSE1EQTFPVFU0TWprNQ',
            images: [],
            metaDescription: 'Crucial 16GB DDR4-3200 SODIMM ',
            metaKeyword: 'Crucial 16GB DDR4-3200 SODIMM',
            metaTitle: 'Crucial 16GB DDR4-3200 SODIMM',
            name: 'Crucial 16GB DDR4-3200 SODIMM',
            shortDescription:
              '<p>Designed to help your system run faster and smoother, Crucial Laptop Memory is one of the easiest and most affordable ways to improve your system’s performance.</p>',
            sku: 'CT16G4SFRA32A',
            externalId: '3',
            url: 'http://integration-5ojmyuq-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-16gb-ddr4-3200-sodimm.html',
            urlKey: 'crucial-16gb-ddr4-3200-sodimm',
            price: null,
          },
        },
        {
          productView: {
            addToCartAllowed: true,
            inStock: true,
            attributes: [
              {
                label: 'Density',
                name: 'density',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: '48GB',
              },
              {
                label: 'Series',
                name: 'series',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'Pro',
              },
              {
                label: 'Speed',
                name: 'speed',
                roles: ['visible_in_pdp', 'visible_in_plp', 'visible_in_search'],
                value: 'DDR5-6000',
              },
            ],
            description: '',
            id: 'TVRaRU16QkJRVEJCTlVOQk56TXdOQQBaR1ZtWVhWc2RBAFlqa3dOakV4Tm1ZdE9HSTNOQzAwTURJMExXSXlaamt0WmpBeU5ERTVOak0yWW1JMQBiV0ZwYmw5M1pXSnphWFJsWDNOMGIzSmwAWW1GelpRAFRVRkhNREExT1RVNE1qazU',
            images: [],
            metaDescription: 'Crucial 16GB DDR4-3200 SODIMM ',
            metaKeyword: 'Crucial 16GB DDR4-3200 SODIMM',
            metaTitle: 'Crucial 16GB DDR4-3200 SODIMM',
            name: 'Crucial 16GB DDR4-3200 SODIMM',
            shortDescription:
              '<p>Designed to help your system run faster and smoother, Crucial Laptop Memory is one of the easiest and most affordable ways to improve your system’s performance.</p>',
            sku: '16D30AA0A5CA7304',
            externalId: '3',
            url: 'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/crucial-16gb-ddr4-3200-sodimm.html',
            urlKey: 'crucial-16gb-ddr4-3200-sodimm',
            price: {
              final: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              regular: {
                amount: {
                  value: 42.99,
                  currency: 'USD',
                },
              },
              roles: ['visible'],
            },
          },
        },
      ],
      facets: [
        {
          attribute: 'categories',
          title: 'Categories',
          type: 'PINNED',
          buckets: [],
        },
        {
          attribute: 'density',
          title: 'Density',
          type: 'POPULAR',
          buckets: [
            {
              title: '16GB',
              id: '16GB',
              count: 22,
            },
            {
              title: '32GB',
              id: '32GB',
              count: 17,
            },
            {
              title: '4',
              id: '4',
              count: 13,
            },
            {
              title: '8GB',
              id: '8GB',
              count: 13,
            },
            {
              title: '24GB',
              id: '24GB',
              count: 4,
            },
            {
              title: '48GB',
              id: '48GB',
              count: 4,
            },
          ],
        },
        {
          attribute: 'series',
          title: 'Series',
          type: 'POPULAR',
          buckets: [
            {
              title: 'Pro',
              id: 'Pro',
              count: 45,
            },
            {
              title: 'Classic',
              id: 'Classic',
              count: 26,
            },
          ],
        },
        {
          attribute: 'speed',
          title: 'Speed',
          type: 'POPULAR',
          buckets: [
            {
              title: 'DDR4-3200',
              id: 'DDR4-3200',
              count: 21,
            },
            {
              title: 'DDR4-2400',
              id: 'DDR4-2400',
              count: 17,
            },
            {
              title: 'DDR4-2666',
              id: 'DDR4-2666',
              count: 17,
            },
            {
              title: 'DDR5-5600',
              id: 'DDR5-5600',
              count: 8,
            },
            {
              title: 'DDR5-6000',
              id: 'DDR5-6000',
              count: 8,
            },
            {
              title: 'DDR5-5200',
              id: 'DDR5-5200',
              count: 1,
            },
          ],
        },
        {
          attribute: 'price',
          title: 'Price',
          type: 'POPULAR',
          buckets: [
            {
              title: '0.0-100.0',
              to: 100,
              from: 0,
              count: 63,
            },
            {
              title: '100.0-200.0',
              to: 200,
              from: 100,
              count: 8,
            },
            {
              title: '200.0-*',
              to: null,
              from: 200,
              count: 3,
            },
          ],
        },
      ],
    },
  },
  errors: [
    {
      message: 'Exception while fetching data (/_entities[53]/price) : Missing price information',
      path: ['productSearch', 'items', 53, 'productView', 'price'],
      extensions: {
        classification: 'DataFetchingException',
      },
    },
    {
      message: 'Exception while fetching data (/_entities[73]/price) : Missing price information',
      path: ['productSearch', 'items', 73, 'productView', 'price'],
      extensions: {
        classification: 'DataFetchingException',
      },
    },
  ],
};
export default productData;
