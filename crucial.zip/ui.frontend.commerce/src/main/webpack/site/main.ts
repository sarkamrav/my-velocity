import A11y from './js/a11y.js';

// Javascript or Typescript
import { Initializer } from '../framework/initializer';
import '../site/js/noncommerce-login.js';
import '../site/js/urlresolver.js';

/***************************************************************** */
/* Uncomment the below lines while doing local development *********/
/**** DONOT CHECKIN UNCOMMENTED CODE ****************/

// import "./core-app.css";
// import "./crucial-app.css";
/***************************************************************** */

import './main.scss';

new Initializer();
new A11y();
