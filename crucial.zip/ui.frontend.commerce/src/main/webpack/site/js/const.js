const CONSTANTS = {
  COMPONENT_TYPE: "react",
};

//  Freezing the enum
Object.freeze(CONSTANTS);

export default CONSTANTS;
