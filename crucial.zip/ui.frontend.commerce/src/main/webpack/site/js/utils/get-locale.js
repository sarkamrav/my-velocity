export const getCurrentLocalFromPage = () => {
    const htmlLang = document.documentElement.getAttribute('lang');
    if (htmlLang) {
        const parts = htmlLang.split('-');
        if (parts.length === 2) {
            return `${parts[0]}_${parts[1].toUpperCase()}`;
        }
    }
    return '';
};
