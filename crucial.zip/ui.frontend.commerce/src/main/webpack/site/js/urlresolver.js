export const getShoppingUrls = () => {
  const htmlTag = document.querySelector('html');
  const loginElement = document.querySelector('[data-name="Login"]');
  const isAuthor = loginElement?.hasAttribute('data-is-author');
  const rootPagePath = loginElement?.getAttribute('data-root-page');

  const getAuthorUrl = (attr, defaultPath, isHtml = false) => {
    const attrValue = htmlTag?.getAttribute(attr);
    if (attrValue === null) {
      return isAuthor ? `${rootPagePath}${defaultPath}.html` : defaultPath;
    } else {
      return isAuthor ? `${rootPagePath}${attrValue}${isHtml ? '.html' : ''}` : attrValue;
    }
  };

  const cartURL = getAuthorUrl('data-cart-url', '/shop/cart', true);
  const guestURL = getAuthorUrl('data-guest-checkout-url', '/shop/guest-checkout', true);
  const billingURL = getAuthorUrl('data-billing-info-url', '/shop/billing-info', true);
  const orderVerifyURL = getAuthorUrl('data-verify-order-url', '/shop/verify-order', true);
  const thankYouURL = getAuthorUrl('data-thank-you-url', '/shop/thank-you', true);
  const invoiceURL = getAuthorUrl('data-invoice-url', '/shop/invoice', true);
  const placeHolderImage =
    htmlTag.getAttribute('data-placeholder-image-url') === null
      ? '/content/dam/crucial/web-ui/crucial_placeholder.png'
      : htmlTag.getAttribute('data-placeholder-image-url');
  const orderHistoryPageURL = getAuthorUrl('data-order-history-url', '/account/order-history', true);
  const orderDetailURL = getAuthorUrl('data-order-detail-url', '/shop/manage-order/order-details', true);
  const orderDetailLegacyURL = getAuthorUrl(
    'data-order-detail-legacy-url',
    '/shop/manage-order/order-details-legacy',
    true
  );
  const orderSearchURL = getAuthorUrl('data-order-search-url', '/shop/manage-order/order-search', true);
  const orderReturnPageURL = getAuthorUrl('data-order-return-url', '/shop/manage-order/return', true);
  const priorOrderHistoryURL = getAuthorUrl(
    'prior-order-history-website',
    'https://gc.digitalriver.com/sstore?Action=DisplayHomePage&SiteID=findmyor',
    true
  );
  return {
    cartURL,
    guestURL,
    billingURL,
    orderVerifyURL,
    thankYouURL,
    invoiceURL,
    placeHolderImage,
    orderHistoryPageURL,
    orderDetailURL,
    orderDetailLegacyURL,
    orderSearchURL,
    orderReturnPageURL,
    priorOrderHistoryURL,
  };
};
