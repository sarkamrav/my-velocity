import { gql } from '@apollo/client';

export const DEFAULT_ADDRESS = gql`
  mutation Core_updateCustomerAddress($id: Int!, $default_shipping: Boolean!, $default_billing: Boolean!) {
    core_updateCustomerAddress(
      input: { default_shipping: $default_shipping, default_billing: $default_billing }
      id: $id
    ) {
      id
    }
  }
`;
