import { gql } from '@apollo/client';

export const QUICK_SET_SHIPPING = gql`
  mutation setShippingAddressesOnCart(
    $cart_id: String!
    $city: String!
    $countryCode: String!
    $postcode: String
    $region: String
    $street: [String]!
    $firstname: String!
    $lastname: String!
    $telephone: String!
  ) {
    core_setShippingAddressesOnCart(
      input: {
        cart_id: $cart_id
        shipping_addresses: {
          address: {
            city: $city
            country_code: $countryCode
            postcode: $postcode
            region: $region
            street: $street
            firstname: $firstname
            lastname: $lastname
            telephone: $telephone
          }
        }
      }
    ) {
      cart {
        digital_river {
          checkout_id
          session_id
        }
        prices {
          grand_total {
            currency
            value
          }
        }
        shipping_addresses {
          city
          company
          firstname
          lastname
          postcode
          street
          telephone
          available_shipping_methods {
            carrier_title
            carrier_code
            method_title
            method_code
            amount {
              value
              currency
            }
          }
        }
      }
    }
    core_setBillingAddressOnCart(input: { billing_address: { same_as_shipping: true }, cart_id: $cart_id }) {
      cart {
        billing_address {
          city
          company
          customer_notes
          firstname
          lastname
          postcode
          street
          telephone
        }
      }
    }
  }
`;

export const GET_SHIPPING_METHOD = gql`
  query Cart($cart_id: String!) {
    core_cart(cart_id: $cart_id) {
      total_quantity
      digital_river {
        session_id
        checkout_id
      }
      prices {
        grand_total {
          currency
          value
        }
      }
      shipping_addresses {
        available_shipping_methods {
          available
          carrier_code
          carrier_title
          error_message
          method_code
          method_title
          amount {
            currency
            value
          }
        }
      }
    }
  }
`;

export const SET_SHIPPING_METHOD = gql`
  mutation setShippingMethodsOnCart($cart_id: String!, $carrierCode: String!, $methodCode: String!) {
    core_setShippingMethodsOnCart(
      input: { cart_id: $cart_id, shipping_methods: { carrier_code: $carrierCode, method_code: $methodCode } }
    ) {
      cart {
        total_quantity
        digital_river {
          checkout_id
          session_id
        }
        prices {
          grand_total {
            currency
            value
          }
        }
        shipping_addresses {
          available_shipping_methods {
            amount {
              currency
              value
            }
            available
            carrier_code
            carrier_title
            error_message
            method_code
            method_title
          }
        }
      }
    }
  }
`;

export const QUICK_SET_PAYMENT_METHOD_TO_CART = gql`
  mutation core_setPaymentMethodOnCart(
    $cart_id: String!
    $source_id: String!
    $additional_data: String
    $code: String!
  ) {
    core_setPaymentMethodOnCart(
      input: {
        cart_id: $cart_id
        payment_method: { code: $code, additional_data: $additional_data, source_id: $source_id }
      }
    ) {
      cart {
        id
        selected_payment_method {
          code
        }
      }
    }
    core_placeOrder(input: { cart_id: $cart_id }) {
      order {
        dr_order_id
        dr_payment_data
        order_id
        order_number
        order_status
      }
    }
  }
`;
