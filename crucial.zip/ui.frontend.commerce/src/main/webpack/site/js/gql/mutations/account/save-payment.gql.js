import { gql } from '@apollo/client';

export const SAVE_PAYMENT = gql`
  mutation savePayment($source_id: ID!) {
    core_setSource(id: $source_id) {
      status
      message
    }
  }
`;

export const GET_SAVED_PAYMENT = gql`
  query {
    core_getSavedCard {
      id
      lastFourDigits
      expirationMonth
      expirationYear
      brand
      is_default
    }
  }
`;

export const SAVED_GET_CUSTOMER = gql`
  query Core_customer {
    core_customer {
      default_billing
      default_shipping
      email
      addresses {
        city
        company
        country_code
        country_id
        default_billing
        default_shipping
        firstname
        id
        lastname
        middlename
        postcode
        region {
          region_code
        }
        street
        telephone
      }
    }
  }
`;

export const DELETE_SAVED_CARD = gql`
  mutation deleteCard($source_id: ID!) {
    core_deleteSavedCard(id: $source_id) {
      status
      message
    }
  }
`;

export const SET_AS_DEFAULT = gql`
  mutation setDefaultCard($source_id: ID!) {
    core_setDefaultSource(id: $source_id) {
      status
      message
    }
  }
`;
