import { gql } from '@apollo/client';

export const UPDATE_VAT_TO_CHECKOUT = gql`
  mutation coreAddVatIdToCheckout($cart_id: String!, $type: String!, $value: String!) {
    core_add_vat_id_to_checkout(input: { cart_id: $cart_id, type: $type, value: $value }) {
      status
      message
      cart {
        prices {
          grand_total {
            value
          }
        }
        digital_river {
          session_id
          checkout_id
        }
      }
    }
  }
`;

export const REMOVE_VAT_FROM_CHECKOUT = gql`
  mutation remove_vat_id_from_checkout($cart_id: String!) {
    core_remove_vat_id_from_checkout(input: { cart_id: $cart_id }) {
      status
      message
      cart {
        prices {
          grand_total {
            value
          }
        }
        digital_river {
          session_id
          checkout_id
        }
      }
    }
  }
`;
