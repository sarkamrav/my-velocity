import { gql } from "@apollo/client";

const CREATE_EMPTY_CART = gql`
  mutation {
    createEmptyCart(input: {})
  }
`;

export default CREATE_EMPTY_CART;
