import {gql} from '@apollo/client';


export const CREATE_ACCOUNT = gql`
mutation CreateCustomerV2(
    $email: String!
    $password: String!
    $firstname: String!
    $lastname: String!
    $company_name: String!
    $customer_type: String!
    $is_subscribed: Boolean
) {
    core_createCustomerV2(
        input: {
            email: $email
            firstname: $firstname
            lastname: $lastname
            password: $password
            company_name: $company_name
            customer_type: $customer_type
            is_subscribed: $is_subscribed
        }
    ) {
        customer {
            email
            firstname
            lastname
        }
    }
}
`;
