import { gql } from '@apollo/client';
export const REMOVE_PRODUCTS_COMPARE_LIST = gql`
  mutation removeProductsToCompare($uid: ID!, $productList: [ID!]!) {
    core_removeProductsFromCompareList(input: { uid: $uid, products: $productList }) {
      uid
      item_count
      attributes {
        code
        label
      }
      items {
        uid
        product {
          sku
          name
          description {
            html
          }
        }
      }
    }
  }
`;
