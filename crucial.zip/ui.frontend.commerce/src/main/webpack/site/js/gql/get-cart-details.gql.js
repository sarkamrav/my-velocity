import { gql } from '@apollo/client';

export const GET_CART_DETAILS = gql`
  query Cart($cart_id: String!) {
    core_cart(cart_id: $cart_id) {
      digital_river {
        session_id
        checkout_id
      }
      total_quantity
      email
      billing_address {
        firstname
        lastname
        street
        city

        country {
          code
        }
        region {
          region_id
          code
        }

        postcode
        telephone
      }
      shipping_addresses {
        firstname
        lastname
        postcode
        telephone
        street
        customer_notes
        company
        city
        country {
          code
        }
        region {
          code
          region_id
        }
        available_shipping_methods {
          carrier_code
          carrier_title
          method_code
          method_title
          amount {
            value
            currency
          }
        }
        selected_shipping_method {
            carrier_title
            amount {
                value
            }
        }
      }
      selected_payment_method {
        code
        title
        purchase_order_number
      }
      prices {
        grand_total {
          currency
          value
        }
        total_tax {
          currency
          value
        }
        dr_tax_info {
          dr_ior_tax {
            currency
            value
          }
          dr_duty_fee {
            currency
            value
          }
          dr_total_fee {
            currency
            value
          }
        }
        subtotal_excluding_tax {
          currency
          value
        }
        subtotal_including_tax {
          currency
          value
        }
        discounts {
          label
          amount {
            currency
            value
          }
        }
        subtotal_with_discount_excluding_tax {
          currency
          value
        }
      }
      items {
        quantity
        availableInStockQty
        uid

        product {
          id
          name
          sku
          price {
            regularPrice {
              amount {
                currency
                value
              }
            }
          }
        }
        ... on core_ConfigurableCartItem {
          id
          quantity
          uid
          configurable_options {
            configurable_product_option_uid
            configurable_product_option_value_uid
            id
            option_label
            value_id
            value_label
          }
        }
        prices {
          price {
            currency
            value
          }
          row_total {
            currency
            value
          }
        }
      }
    }
  }
`;
