import { gql } from '@apollo/client';

export const USER_TOKEN = gql`
    mutation SignIn($email: String!, $password: String!) {
        core_generateCustomerToken(email: $email, password: $password) {
            token
            __typename
        }
    }
`;
