import { gql } from '@apollo/client';

const CUSTOMER_CART_INFO = gql`
  query {
    core_customerCart {
      email
      digital_river {
        checkout_id
        session_id
      }
    }
  }
`;

export default CUSTOMER_CART_INFO;
