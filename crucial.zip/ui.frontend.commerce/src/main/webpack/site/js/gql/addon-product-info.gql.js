import { gql } from '@apollo/client';

const GET_ADDON_PRODUCT_INFO = gql`
  query getProduct($SKU: String!) {
    products(skus: [$SKU]) {
      sku
      images(roles: ["thumbnail"]) {
        url
        label
        roles
      }
    }
  }
`;
export default GET_ADDON_PRODUCT_INFO;
