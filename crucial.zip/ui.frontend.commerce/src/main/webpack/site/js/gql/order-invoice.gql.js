import { gql } from '@apollo/client';

const ORDER_INVOICE = gql`
  query getInvoice($orderNumber: String!) {
    core_customer {
      orders(filter: { number: { eq: $orderNumber } }) {
        items {
          grand_total
          invoices {
            total {
              base_grand_total {
                currency
                value
              }
              discounts {
                label
                amount {
                  currency
                  value
                }
              }
              grand_total {
                currency
                value
              }
              subtotal {
                currency
                value
              }
              total_tax {
                currency
                value
              }
              total_shipping {
                currency
                value
              }
            }
            items {
              id
              product_name
              product_sku
              quantity_invoiced
              product_sale_price {
                currency
                value
              }
              discounts {
                label
                amount {
                  currency
                  value
                }
              }
            }
          }
          order_date
          status
          shipping_address {
            city
            company
            country_code
            fax
            firstname
            lastname
            middlename
            postcode
            prefix
            region
            region_id
            street
            suffix
            telephone
            vat_id
          }
          billing_address {
            city
            company
            country_code
            fax
            firstname
            lastname
            middlename
            postcode
            prefix
            region
            region_id
            street
            suffix
            telephone
            vat_id
          }
        }
      }
    }
  }
`;

export default ORDER_INVOICE;
