import { gql } from '@apollo/client';

const GET_CART = gql`
  query Cart($cart_id: String!) {
    core_cart(cart_id: $cart_id) {
      total_quantity
      digital_river {
        session_id
        checkout_id
      }
      prices {
        grand_total {
          currency
          value
        }
        discount {
          label
          amount {
            currency
            value
          }
        }
      }
      items {
        quantity
        availableInStockQty
        uid
        id
        is_supersize_price
        product {
          uid
          name
          sku
          only_x_left_in_stock
          stock_status
          image {
            label
            url
          }
          price {
            regularPrice {
              amount {
                currency
                value
              }
            }
            minimalPrice {
              amount {
                currency
                value
              }
            }
          }
        }
        ... on core_ConfigurableCartItem {
          id
          quantity
          uid
          configurable_options {
            configurable_product_option_uid
            configurable_product_option_value_uid
            id
            option_label
            value_id
            value_label
          }
        }
        prices {
          price {
            currency
            value
          }
          row_total {
            currency
            value
          }
        }
      }
      shipping_addresses {
        selected_shipping_method {
          carrier_code
          carrier_title
          method_code
          method_title
          amount {
            currency
            value
          }
        }
      }
      applied_coupon {
        code
      }
      applied_coupons {
        code
      }
    }
  }
`;

export default GET_CART;
