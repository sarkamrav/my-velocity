import { gql } from '@apollo/client';

export const UPDATE_QUOTE_FIELD = gql`
  mutation updateQuoteField(
    $cart_id: String!
    $order_type: String
    $po_number: String
    $pack_count_tray: String
    $opt_in: Boolean
    $tos_accepted: Boolean
    $request_email: Boolean
  ) {
    core_updateQuoteField(
      input: {
        cart_id: $cart_id
        order_type: $order_type
        po_number: $po_number
        pack_count_tray: $pack_count_tray
        opt_in: $opt_in
        tos_accepted: $tos_accepted
        request_email: $request_email
      }
    ) {
      message
      success
    }
  }
`;
