import { gql } from '@apollo/client';

const APPLY_PROMO_CODE = gql`
  mutation applyPromoCode($cart_id: String!, $coupon_code: String!) {
    core_applyCouponToCart(
      input: {
        cart_id: $cart_id,
        coupon_code: $coupon_code
      }
    ) {
      cart {
        items {
          product {
            name
            sku
          }
          quantity
        }
        applied_coupons {
          code
        }
        prices {
          grand_total{
            value
            currency
          }
        }
      }
    }
  }
`;

export default APPLY_PROMO_CODE;
