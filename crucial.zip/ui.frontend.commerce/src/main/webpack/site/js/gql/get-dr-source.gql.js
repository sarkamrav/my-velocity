import { gql } from '@apollo/client';

export const GET_DR_SOURCE_DATA = gql`
  query get_digital_river_source($sourceId: String!) {
    core_get_digital_river_source(input: { source_id: $sourceId }) {
      dr_source
    }
  }
`;

export const GET_PAYPAL_SOURCE_DATA = gql`
  query attach_dr_source_to_checkout($sourceId: String!, $checkoutId: String!) {
    core_attach_dr_source_to_checkout(input: { source_id: $sourceId, checkout_id: $checkoutId }) {
      status
      dr_checkout
    }
  }
`;
