import { gql } from "@apollo/client";

const CREATE_ADDRESS = gql`
  mutation CreateCustomerAddress($firstname:String!,$lastname:String!, $street: [String!],$city:String!, $postcode:String!, $telephone:String!,
  $default_shipping:Boolean!,$default_billing:Boolean!, $region:CustomerAddressRegionInput!, $country_id:CountryCodeEnum!, $country_code:CountryCodeEnum!){
    createCustomerAddress(input: {
      telephone: $telephone
      postcode: $postcode
      region: $region
      country_code: $country_code
      country_id: $country_id
      city: $city
      street:$street
      firstname: $firstname
      lastname: $lastname
      default_shipping: $default_shipping
      default_billing: $default_billing
    }) {
      id
      country_code
      telephone
      postcode
      city
      default_shipping
      default_billing
    }
  }

`;

export default CREATE_ADDRESS;
