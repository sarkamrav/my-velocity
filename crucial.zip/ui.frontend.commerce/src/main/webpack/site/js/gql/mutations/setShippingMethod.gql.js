import { gql } from '@apollo/client';

export const SET_SHIPPING_METHOD = gql`
  mutation core_setShippingMethodsOnCart($cartId: String!, $carrierCode: String!, $methodCode: String!) {
    core_setShippingMethodsOnCart(
      input: { cart_id: $cartId, shipping_methods: [{ carrier_code: $carrierCode, method_code: $methodCode }] }
    ) {
      cart {
        digital_river {
          checkout_id
          session_id
        }
        shipping_addresses {
          selected_shipping_method {
            carrier_code
            method_code
            carrier_title
            method_title
          }
        }
        prices {
          grand_total {
            currency
            value
          }
          total_tax {
            currency
            value
          }
          dr_tax_info {
            dr_ior_tax {
              currency
              value
            }
            dr_duty_fee {
              currency
              value
            }
            dr_total_fee {
              currency
              value
            }
          }
          subtotal_excluding_tax {
            currency
            value
          }
          subtotal_including_tax {
            currency
            value
          }
          discounts {
            label
            amount {
              currency
              value
            }
          }
          subtotal_with_discount_excluding_tax {
            currency
            value
          }
        }
      }
    }
  }
`;
