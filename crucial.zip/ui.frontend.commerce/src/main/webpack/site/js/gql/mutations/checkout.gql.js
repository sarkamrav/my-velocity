import { gql } from '@apollo/client';

// Mutation for adding Billing Address
export const SET_BILLING_ADDRESS_FOR_SAME_ADDRESS = gql`
  mutation setBillingAddress(
    $cart_id: String!
    $firstName: String!
    $lastName: String!
    $company: String
    $streetAddress: [String!]!
    $city: String!
    $region: String!
    $region_id: Int
    $postalCode: String!
    $country: String!
    $telephone: String!
    $use_for_shipping: Boolean!
  ) {
    core_setBillingAddressOnCart(
      input: {
        cart_id: $cart_id
        billing_address: {
          address: {
            firstname: $firstName
            lastname: $lastName
            company: $company
            street: $streetAddress
            city: $city
            region: $region
            region_id: $region_id
            postcode: $postalCode
            country_code: $country
            telephone: $telephone
            save_in_address_book: true
          }
          use_for_shipping: $use_for_shipping
        }
      }
    ) {
      cart {
        digital_river {
          checkout_id
          session_id
        }
        shipping_addresses {
          uid
          firstname
          lastname
          company
          street
          city
          region {
            code
            label
          }
          postcode
          telephone
          country {
            code
            label
          }
          available_shipping_methods {
            available
            carrier_code
            carrier_title
            error_message
            method_code
            method_title
            amount {
              currency
              value
            }
          }
          pickup_location_code
        }
        billing_address {
          uid
          firstname
          lastname
          company
          street
          city
          region {
            code
            label
          }
          postcode
          telephone
          country {
            code
            label
          }
        }
      }
    }
  }
`;

// Mutation for adding Shipping Address
export const SET_BILLING_ADDRESS_FOR_DIFFERENT_ADDRESS = gql`
  mutation setShippingAddress(
    $cart_id: String!
    $shippingFirstName: String!
    $shippingLastName: String!
    $shippingCompany: String
    $shippingStreetAddress: [String!]!
    $shippingCity: String!
    $shippingRegion: String!
    $shippingRegion_id: Int
    $shippingPostalCode: String!
    $shippingCountry: String!
    $shippingTelephone: String!
  ) {
    core_setShippingAddressesOnCart(
      input: {
        cart_id: $cart_id
        shipping_addresses: [
          {
            address: {
              firstname: $shippingFirstName
              lastname: $shippingLastName
              company: $shippingCompany
              street: $shippingStreetAddress
              city: $shippingCity
              region: $shippingRegion
              region_id: $shippingRegion_id
              postcode: $shippingPostalCode
              country_code: $shippingCountry
              telephone: $shippingTelephone
              save_in_address_book: true
            }
            pickup_location_code: ""
          }
        ]
      }
    ) {
      cart {
        shipping_addresses {
          firstname
          lastname
          company
          street
          city
          region {
            code
            label
          }
          postcode
          telephone
          country {
            code
            label
          }
          pickup_location_code
        }
      }
    }
  }
`;

// Mutation for assigning Email to guest
export const ASSIGN_EMAIL_GUEST = gql`
  mutation setGuestEmailOnCart($cart_id: String!, $email: String!) {
    core_setGuestEmailOnCart(input: { cart_id: $cart_id, email: $email }) {
      cart {
        email
        id
        digital_river {
          checkout_id
          session_id
        }
      }
    }
  }
`;

// Mutation for cart merge
export const MERGE_GUEST_CART = gql`
  mutation setMergedCart($source_cart_id: String!, $destination_cart_id: String!) {
    core_mergeCarts(source_cart_id: $source_cart_id, destination_cart_id: $destination_cart_id) {
      email
      id
      total_quantity
      digital_river {
        checkout_id
        session_id
      }
      items {
        availableInStockQty
        id
        quantity
        uid
      }
    }
  }
`;
