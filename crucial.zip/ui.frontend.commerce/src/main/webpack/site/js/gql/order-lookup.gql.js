import { gql } from '@apollo/client';

const ORDER_LOOKUP = gql`
  query getOrderLookup($orderNumber: String!, $email: String!) {
    core_orderLookup(input: { number: $orderNumber, email: $email }) {
      shipments {
        comments {
          message
          timestamp
        }
        id
        number
        tracking {
          carrier
          number
          title
          url
        }
        items {
          id
          product_name
          product_sku
          quantity_shipped
        }
      }
      billing_address {
        city
        company
        country_code
        fax
        firstname
        lastname
        middlename
        postcode
        prefix
        region
        region_id
        street
        suffix
        telephone
        vat_id
      }
      shipping_address {
        city
        company
        country_code
        fax
        firstname
        lastname
        middlename
        postcode
        prefix
        region
        region_id
        street
        suffix
        telephone
        vat_id
      }
      carrier
      shipping_method
      comments {
        timestamp
        message
      }
      id
      number
      order_date
      status
      items {
        discounts {
          amount {
            currency
            value
          }
          label
        }
        id
        product_name

        product_sale_price {
          currency
          value
        }
        product_sku

        product_type
        product_url_key
        quantity_canceled
        quantity_invoiced
        quantity_ordered
        quantity_refunded
        quantity_returned
        quantity_shipped
        selected_options {
          label
          value
        }
        status
      }
      payment_methods {
        additional_data {
          name
          value
        }
        name
        type
        additional_dr_data
      }
      invoices {
        id
        number
        total {
          base_grand_total {
            currency
            value
          }
          discounts {
            amount {
              currency
              value
            }
            label
          }
          grand_total {
            currency
            value
          }
          subtotal {
            currency
            value
          }
          taxes {
            amount {
              currency
              value
            }
            rate
            title
          }
          total_shipping {
            currency
            value
          }
          total_tax {
            currency
            value
          }
        }
        items {
          id
          product_name
          product_sku
          product_sale_price {
            currency
            value
          }
          discounts {
            amount {
              currency
              value
            }
            label
          }
          quantity_invoiced
        }
        comments {
          message
          timestamp
        }
      }
      total {
        dr_tax_info {
          dr_ior_tax {
            currency
            value
          }
          dr_duty_fee {
            currency
            value
          }
          dr_total_fee {
            currency
            value
          }
        }
        base_grand_total {
          currency
          value
        }
        discounts {
          amount {
            currency
            value
          }
          label
        }
        grand_total {
          currency
          value
        }
        subtotal {
          currency
          value
        }
        taxes {
          amount {
            currency
            value
          }
          rate
          title
        }
        total_shipping {
          currency
          value
        }
        total_tax {
          currency
          value
        }
      }
    }
  }
`;

export default ORDER_LOOKUP;
