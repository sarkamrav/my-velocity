import { gql } from "@apollo/client";

const REVERIFICATION_EMAIL = gql`
query {
    core_sendReVerificationEmail {
        sent
        message
    }
}
`;

export default REVERIFICATION_EMAIL;
