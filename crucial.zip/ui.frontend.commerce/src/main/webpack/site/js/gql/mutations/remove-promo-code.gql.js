import { gql } from '@apollo/client';

const REMOVE_PROMO_CODE = gql`
mutation removePromoCode($cart_id: String!){
  core_removeCouponFromCart(
    input:
      { cart_id: $cart_id }
    ) {
    cart {
      items {
        product {
          name
          sku
        }
        quantity
      }
      applied_coupons {
        code
      }
      prices {
        grand_total{
          value
          currency
        }
      }
    }
  }
}
`;

export default REMOVE_PROMO_CODE;
