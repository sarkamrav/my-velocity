import { gql } from '@apollo/client';

const ORDER_LEGACY_HISTORY = gql`
  query {
  core_drOrders {
    creation_date
    currency
    id
    status
    total
    payment_id
  }
}
`;
export default ORDER_LEGACY_HISTORY;
