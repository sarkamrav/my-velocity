import { gql } from '@apollo/client';

export const SET_PAYMENT_METHOD_TO_CART = gql`
  mutation core_setPaymentMethodOnCart(
    $cart_id: String!
    $source_id: String!
    $additional_data: String
    $code: String!
  ) {
    core_setPaymentMethodOnCart(
      input: {
        cart_id: $cart_id
        payment_method: { code: $code, additional_data: $additional_data, source_id: $source_id }
      }
    ) {
      cart {
        id
        selected_payment_method {
          code
        }
      }
    }
  }
`;
