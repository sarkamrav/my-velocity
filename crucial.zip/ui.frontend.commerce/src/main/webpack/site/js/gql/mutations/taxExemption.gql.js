import { gql } from '@apollo/client';

export const TAX_EXEMPTION = gql`
  mutation coreImportTaxExemptCertificate(
    $cart_id: String!
    $company_name: String!
    $tax_authority: String!
    $start_date: String!
    $end_date: String!
    $file: String!
  ) {
    core_import_tax_exempt_certificate(
      input: {
        cart_id: $cart_id
        company_name: $company_name
        tax_authority: $tax_authority
        start_date: $start_date
        end_date: $end_date
        file: $file
      }
    ) {
      status
      message
      cart {
        prices {
          grand_total {
            value
          }
        }
        digital_river {
          session_id
          checkout_id
        }
      }
    }
  }
`;
