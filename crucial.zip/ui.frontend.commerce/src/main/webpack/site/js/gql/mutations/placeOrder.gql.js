import { gql } from '@apollo/client';
export const PLACE_ORDER = gql`
  mutation core_placeOrder($cartId: String!) {
    core_placeOrder(input: { cart_id: $cartId }) {
      order {
        order_number
        order_status
        dr_order_id
      }
    }
  }
`;
