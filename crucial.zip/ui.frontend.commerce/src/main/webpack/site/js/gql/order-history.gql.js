import { gql } from '@apollo/client';

const ORDER_HISTORY = gql`
  query {
    core_customer {
      orders(pageSize: 200
      sort: {
        sort_direction : DESC
        sort_field : NUMBER
      }) {
        items {
          id
          order_date
          order_number
          total {
            grand_total {
              value
              currency
            }
          }
          status
        }
      }
    }
  }
`;

export default ORDER_HISTORY;
