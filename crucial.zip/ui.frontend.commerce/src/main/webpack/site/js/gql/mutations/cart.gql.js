import { gql } from '@apollo/client';

export const CREATE_EMPTY_CART = gql`
  mutation CreateEmptyCart {
    core_createEmptyCart
  }
`;

export const CLEAR_CART = gql`
  mutation ClearCart($uid: ID!) {
    core_clearCart(input: { uid: $uid }) {
      cart {
        id
        email
      }
      errors {
        message
      }
    }
  }
`;

export const ADD_PRODUCTS_TO_CART = gql`
  mutation AddProductsToCart(
    $cartId: String!
    $quantity: Float!
    $SKU: String!
    $enteredOption: [core_EnteredOptionInput]
    $supersizePrice: Boolean! = false
  ) {
    core_addProductsToCart(
      cartId: $cartId
      cartItems: [{ quantity: $quantity, sku: $SKU, set_supersize_price: $supersizePrice, entered_options: $enteredOption }]
    ) {
      cart {
        items {
          product {
            name
            sku
          }
          quantity
        }
      }

      user_errors {
        code
        message
      }
    }
  }
`;
