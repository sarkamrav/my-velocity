import { gql } from '@apollo/client';
export const FORGET_PASSWORD = gql`
  mutation Core_requestPasswordResetEmail($email: String!) {
    core_requestPasswordResetEmail(email: $email)
  }
`;
