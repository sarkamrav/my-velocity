import { gql } from '@apollo/client';

const REMOVE_ITEM_FROM_CART = gql`
  mutation removeCartItem($cart_id: String!, $cart_item_uid: ID!) {
    core_removeItemFromCart(input: { cart_id: $cart_id, cart_item_uid: $cart_item_uid }) {
      cart {
        total_quantity
        items {
          uid
          quantity
          product {
            name
            sku
          }
        }
      }
    }
  }
`;

export default REMOVE_ITEM_FROM_CART;
