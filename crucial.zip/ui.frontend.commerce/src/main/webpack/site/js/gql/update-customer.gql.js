import { gql } from "@apollo/client";

const UPDATE_CUSTOMER = gql`
  mutation UpdateCustomerV2 ($firstname:String!,$lastname:String!,$gender:Int!,$is_subscribed:Boolean!,$allow_remote_shopping_assistance:Boolean!,$date_of_birth:String!,
  $dob:String!,$middlename:String!,$prefix:String!,$suffix:String!,$taxvat:String!){
      updateCustomerV2(
          input: {
              firstname: $firstname
              gender: $gender
              is_subscribed: $is_subscribed
              lastname: $lastname
              allow_remote_shopping_assistance: $allow_remote_shopping_assistance
              date_of_birth: $date_of_birth
              dob: $dob
              middlename: $middlename
              prefix: $prefix
              suffix: $suffix
              taxvat: $taxvat
          }
      ) {
          customer {
              created_at
              date_of_birth
              default_billing
              default_shipping
              email
              firstname
              group_id
              id
              is_subscribed
              lastname
              middlename
              prefix
              suffix
              taxvat
          }
      }
  }
`;

export default UPDATE_CUSTOMER;
