import { gql } from "@apollo/client";

const CUSTOMER_INFO = gql`
query{
  customer {
    firstname
    lastname
    suffix
    email
    addresses {
      firstname
      lastname
      street
      city
      region {
        region_code
        region
      }
      postcode
      country_code
      telephone
    }
  }
}
`;

export default CUSTOMER_INFO;
