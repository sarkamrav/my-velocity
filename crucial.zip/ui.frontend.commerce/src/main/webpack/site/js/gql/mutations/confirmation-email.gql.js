import { gql } from '@apollo/client';

const CONFIRM_EMAIL_MUTATION = gql`
  mutation ConfirmEmail($email: String!, $confirmationKey: String!) {
    confirmEmail(input: { email: $email, confirmation_key: $confirmationKey }) {
      customer {
        email
      }
    }
  }
`;
export default CONFIRM_EMAIL_MUTATION;
