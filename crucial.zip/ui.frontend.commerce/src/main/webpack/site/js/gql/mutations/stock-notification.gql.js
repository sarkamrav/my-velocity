import { gql } from '@apollo/client';

export const SET_STOCK_NOTIFICATION = gql`
  mutation stockNotification($productNumber: Int!) {
    core_registerProductStockAlert(input: { productId: $productNumber }) {
      success
      message
    }
  }
`;
