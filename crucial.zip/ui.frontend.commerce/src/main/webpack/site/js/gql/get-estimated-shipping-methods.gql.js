import { gql } from '@apollo/client';

export const GET_ESTIMATED_SHIPPING_METHODS_QUERY = gql`
  query core_getEstimatedShippingMethods($country: String!, $cart_id: String!) {
    core_getEstimatedShippingMethods(country: $country, cart_id: $cart_id) {
      carrier_code
      carrier_title
      currency
      method_code
      price
      shipping_method_label
    }
  }
`;
