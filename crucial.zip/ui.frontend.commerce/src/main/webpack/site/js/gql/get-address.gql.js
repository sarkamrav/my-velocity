import { gql } from '@apollo/client';

export const GET_ADDRESS = gql`
  {
    core_customer {
      addresses {
        firstname
        lastname
        street
        city
        region {
          region
          region_code
          region_id
        }
        postcode
        country_code
        company
        telephone
        id
        default_shipping
        default_billing
        custom_attributes {
          attribute_code
          value
        }
      }
    }
  }
`;
