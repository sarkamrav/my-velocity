import { gql } from "@apollo/client";

const ADD_PRODUCTS_TO_CART = gql`
  mutation AddProductsToCart ($cartId:String!, $cartItems: [CartItemInput!]!){
      addProductsToCart(
          cartId: $cartId
          cartItems: $cartItems
      ) {
        cart {
            items {
                product {
                    name
                    sku
                }
                ... on ConfigurableCartItem {
                    configurable_options {
                        configurable_product_option_uid
                        option_label
                        configurable_product_option_value_uid
                        value_label
                    }
                }
                quantity
            }
            total_quantity
        }
        user_errors {
            code
            message
        }
    }
  }


`;

export default ADD_PRODUCTS_TO_CART;
