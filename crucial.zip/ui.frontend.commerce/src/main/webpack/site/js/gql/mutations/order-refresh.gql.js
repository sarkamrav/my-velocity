import { gql } from '@apollo/client';

export const REFRESH_DR_ORDER = gql`
  mutation refreshOrder($dr_order_number: String!, $order_number: String!) {
    core_refreshOrder(input: { dr_order_number: $dr_order_number, order_number: $order_number }) {
      message
      status
    }
  }
`;
