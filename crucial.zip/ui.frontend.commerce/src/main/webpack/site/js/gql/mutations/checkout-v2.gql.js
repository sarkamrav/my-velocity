import { gql } from '@apollo/client';

// Mutation to set addresses on cart
export const SET_SAME_ADDRESSES_ON_CART = gql`
  mutation Core_setShippingAddressesOnCart(
    $cart_id: String!
    $firstName: String!
    $lastName: String!
    $company: String
    $streetAddress: [String!]!
    $city: String!
    $region: String!
    $region_id: Int
    $postalCode: String!
    $country: String!
    $telephone: String!
    $sameAsShipping: Boolean!
    $saveAddress: Boolean!
  ) {
    core_setShippingAddressesOnCart(
      input: {
        cart_id: $cart_id
        shipping_addresses: [
          {
            address: {
              firstname: $firstName
              lastname: $lastName
              company: $company
              street: $streetAddress
              city: $city
              region: $region
              region_id: $region_id
              postcode: $postalCode
              country_code: $country
              telephone: $telephone
              save_in_address_book: $saveAddress
            }
            pickup_location_code: ""
          }
        ]
      }
    ) {
      cart {
        digital_river {
          checkout_id
          session_id
        }
        shipping_addresses {
          city
          company
          customer_notes
          firstname
          items_weight
          lastname
          pickup_location_code
          postcode
          region {
            code
            label
          }
          country {
            code
            label
          }
          street
          telephone
          uid
          vat_id
          available_shipping_methods {
            amount {
              currency
              value
            }
            available
            carrier_code
            carrier_title
            method_code
            method_title
            price_excl_tax {
              currency
              value
            }
            price_incl_tax {
              currency
              value
            }
          }
        }
      }
    }
    core_setBillingAddressOnCart(input: { billing_address: { same_as_shipping: $sameAsShipping }, cart_id: $cart_id }) {
      cart {
        email
        gift_receipt_included
        id
        is_virtual
        printed_card_included
        total_quantity
        digital_river {
          checkout_id
          session_id
        }
        billing_address {
          city
          company
          customer_notes
          firstname
          lastname
          postcode
          region {
            code
            label
          }
          country {
            code
            label
          }
          street
          telephone
          uid
          vat_id
        }
      }
    }
  }
`;

export const SET_SHIPPING_ADDRESS_ON_CART = gql`
  mutation Core_setShippingAddressesOnCart(
    $cart_id: String!
    $firstName: String!
    $lastName: String!
    $company: String
    $streetAddress: [String!]!
    $city: String!
    $region: String!
    $region_id: Int
    $postalCode: String!
    $country: String!
    $telephone: String!
    $saveAddress: Boolean!
  ) {
    core_setShippingAddressesOnCart(
      input: {
        cart_id: $cart_id
        shipping_addresses: [
          {
            address: {
              firstname: $firstName
              lastname: $lastName
              company: $company
              street: $streetAddress
              city: $city
              region: $region
              region_id: $region_id
              postcode: $postalCode
              country_code: $country
              telephone: $telephone
              save_in_address_book: $saveAddress
            }
            pickup_location_code: ""
          }
        ]
      }
    ) {
      cart {
        digital_river {
          checkout_id
          session_id
        }
        shipping_addresses {
          city
          company
          customer_notes
          firstname
          items_weight
          lastname
          pickup_location_code
          postcode
          region {
            code
            label
          }
          country {
            code
            label
          }
          street
          telephone
          uid
          vat_id
          available_shipping_methods {
            amount {
              currency
              value
            }
            available
            carrier_code
            carrier_title
            method_code
            method_title
            price_excl_tax {
              currency
              value
            }
            price_incl_tax {
              currency
              value
            }
          }
        }
      }
    }
  }
`;

export const SET_BILLING_AS_SHIPPING = gql`
  mutation Core_setBillingAsShippingOnCart($cart_id: String!, $sameAsShipping: Boolean!) {
    core_setBillingAddressOnCart(input: { billing_address: { same_as_shipping: $sameAsShipping }, cart_id: $cart_id }) {
      cart {
        email
        gift_receipt_included
        id
        is_virtual
        printed_card_included
        total_quantity
        digital_river {
          checkout_id
          session_id
        }
        billing_address {
          city
          company
          customer_notes
          firstname
          lastname
          postcode
          region {
            code
            label
          }
          country {
            code
            label
          }
          street
          telephone
          uid
          vat_id
        }
      }
    }
  }
`;

// Mutation to set different addresses
export const SET_DIFFERENT_ADDRESSES_ON_CART = gql`
  mutation Core_setDifferentAddresesOnCart(
    $cart_id: String!
    $firstName: String!
    $lastName: String!
    $company: String
    $streetAddress: [String!]!
    $city: String!
    $region: String!
    $region_id: Int
    $postalCode: String!
    $country: String!
    $telephone: String!
    $shippingFirstName: String!
    $shippingLastName: String!
    $shippingCompany: String
    $shippingStreetAddress: [String!]!
    $shippingCity: String!
    $shippingRegion: String!
    $shippingRegion_id: Int
    $shippingPostalCode: String!
    $shippingCountry: String!
    $shippingTelephone: String!
    $saveAddress: Boolean!
  ) {
    core_setShippingAddressesOnCart(
      input: {
        cart_id: $cart_id
        shipping_addresses: [
          {
            address: {
              firstname: $shippingFirstName
              lastname: $shippingLastName
              company: $shippingCompany
              street: $shippingStreetAddress
              city: $shippingCity
              region: $shippingRegion
              region_id: $shippingRegion_id
              postcode: $shippingPostalCode
              country_code: $shippingCountry
              telephone: $shippingTelephone
              save_in_address_book: $saveAddress
            }
            pickup_location_code: ""
          }
        ]
      }
    ) {
      cart {
        shipping_addresses {
          firstname
          lastname
          company
          street
          city
          region {
            code
            label
          }
          postcode
          telephone
          country {
            code
            label
          }
          pickup_location_code
          available_shipping_methods {
            amount {
              currency
              value
            }
            available
            carrier_code
            carrier_title
            method_code
            method_title
            price_excl_tax {
              currency
              value
            }
            price_incl_tax {
              currency
              value
            }
          }
        }
      }
    }
    core_setBillingAddressOnCart(
      input: {
        cart_id: $cart_id
        billing_address: {
          address: {
            firstname: $firstName
            lastname: $lastName
            company: $company
            street: $streetAddress
            city: $city
            region: $region
            region_id: $region_id
            postcode: $postalCode
            country_code: $country
            telephone: $telephone
          }
        }
      }
    ) {
      cart {
        digital_river {
          checkout_id
          session_id
        }
        billing_address {
          uid
          firstname
          lastname
          company
          street
          city
          region {
            code
            label
          }
          postcode
          telephone
          country {
            code
            label
          }
        }
        shipping_addresses {
          firstname
          lastname
          company
          street
          city
          region {
            code
            label
          }
          postcode
          telephone
          country {
            code
            label
          }
          pickup_location_code
          available_shipping_methods {
            amount {
              currency
              value
            }
            available
            carrier_code
            carrier_title
            method_code
            method_title
            price_excl_tax {
              currency
              value
            }
            price_incl_tax {
              currency
              value
            }
          }
        }
      }
    }
  }
`;

export const SET_BILLING_ADDRESS_ON_CART = gql`
  mutation Core_setBillingAddresOnCart(
    $cart_id: String!
    $firstName: String!
    $lastName: String!
    $company: String
    $streetAddress: [String!]!
    $city: String!
    $region: String!
    $region_id: Int
    $postalCode: String!
    $country: String!
    $telephone: String!
  ) {
    core_setBillingAddressOnCart(
      input: {
        cart_id: $cart_id
        billing_address: {
          address: {
            firstname: $firstName
            lastname: $lastName
            company: $company
            street: $streetAddress
            city: $city
            region: $region
            region_id: $region_id
            postcode: $postalCode
            country_code: $country
            telephone: $telephone
            save_in_address_book: false
          }
        }
      }
    ) {
      cart {
        digital_river {
          checkout_id
          session_id
        }
        billing_address {
          uid
          firstname
          lastname
          company
          street
          city
          region {
            code
            label
          }
          postcode
          telephone
          country {
            code
            label
          }
        }
        shipping_addresses {
          firstname
          lastname
          company
          street
          city
          region {
            code
            label
          }
          postcode
          telephone
          country {
            code
            label
          }
          pickup_location_code
          available_shipping_methods {
            amount {
              currency
              value
            }
            available
            carrier_code
            carrier_title
            method_code
            method_title
            price_excl_tax {
              currency
              value
            }
            price_incl_tax {
              currency
              value
            }
          }
        }
      }
    }
  }
`;

// Mutation for assigning Email to guest
export const ASSIGN_EMAIL_GUEST = gql`
  mutation setGuestEmailOnCart($cart_id: String!, $email: String!) {
    core_setGuestEmailOnCart(input: { cart_id: $cart_id, email: $email }) {
      cart {
        email
        id
        digital_river {
          checkout_id
          session_id
        }
      }
    }
  }
`;

// Mutation for cart merge
// export const MERGE_GUEST_CART = gql`
//   mutation setMergedCart($source_cart_id: String!, $destination_cart_id: String!) {
//     core_mergeCarts(source_cart_id: $source_cart_id, destination_cart_id: $destination_cart_id) {
//       email
//       id
//       total_quantity
//       digital_river {
//         checkout_id
//         session_id
//       }
//       items {
//         availableInStockQty
//         id
//         quantity
//         uid
//       }
//     }
//   }
// `;

export const MERGE_GUEST_CART = gql`
  mutation setMergedCart($source_cart_id: String!, $destination_cart_id: String!) {
    core_mergeCarts(source_cart_id: $source_cart_id, destination_cart_id: $destination_cart_id) {
      digital_river {
        session_id
        checkout_id
      }
      total_quantity
      email
      id
      billing_address {
        firstname
        lastname
        street
        city

        country {
          code
        }
        region {
          region_id
          code
        }

        postcode
        telephone
      }
      shipping_addresses {
        firstname
        lastname
        postcode
        telephone
        street
        customer_notes
        company
        city
        country {
          code
        }
        region {
          code
          region_id
        }
        available_shipping_methods {
          carrier_code
          carrier_title
          method_code
          method_title
          price_excl_tax {
            value
          }
        }
      }
      selected_payment_method {
        code
        title
        purchase_order_number
      }
      prices {
        grand_total {
          currency
          value
        }
        applied_taxes {
          label
          amount {
            currency
            value
          }
        }
        subtotal_excluding_tax {
          currency
          value
        }
        subtotal_including_tax {
          currency
          value
        }
        discounts {
          label
          amount {
            currency
            value
          }
        }
        subtotal_with_discount_excluding_tax {
          currency
          value
        }
      }
      items {
        quantity
        availableInStockQty
        uid
        id
        product {
          id
          name
          sku
          price {
            regularPrice {
              amount {
                currency
                value
              }
            }
          }
        }
        ... on core_ConfigurableCartItem {
          id
          quantity
          uid
          configurable_options {
            configurable_product_option_uid
            configurable_product_option_value_uid
            id
            option_label
            value_id
            value_label
          }
        }
        prices {
          price {
            currency
            value
          }
          row_total {
            currency
            value
          }
        }
      }
    }
  }
`;

export const SET_SHIPPING_METHOD = gql`
  mutation core_setShippingMethodsOnCart($cart_id: String!, $carrierCode: String!, $methodCode: String!) {
    core_setShippingMethodsOnCart(
      input: { cart_id: $cart_id, shipping_methods: [{ carrier_code: $carrierCode, method_code: $methodCode }] }
    ) {
      cart {
        digital_river {
          checkout_id
          session_id
        }
        prices {
          total_tax {
            currency
            value
          }
          dr_tax_info {
            dr_ior_tax {
              currency
              value
            }
            dr_duty_fee {
              currency
              value
            }
            dr_total_fee {
              currency
              value
            }
          }
        }
      }
    }
  }
`;

export const CHECKOUT_V2_GET_CART = gql`
  query Cart($cart_id: String!) {
    core_cart(cart_id: $cart_id) {
      total_quantity
      digital_river {
        session_id
        checkout_id
      }
      prices {
        grand_total {
          currency
          value
        }
        total_tax {
          currency
          value
        }
        dr_tax_info {
          dr_ior_tax {
            currency
            value
          }
          dr_duty_fee {
            currency
            value
          }
          dr_total_fee {
            currency
            value
          }
        }
        discount {
          label
          amount {
            currency
            value
          }
        }
      }
      items {
        quantity
        product {
          uid
          name
          sku
          only_x_left_in_stock
          stock_status
          image {
            label
            url
          }
          price {
            regularPrice {
              amount {
                currency
                value
              }
            }
            minimalPrice {
              amount {
                currency
                value
              }
            }
          }
        }
        ... on core_ConfigurableCartItem {
          id
          quantity
          uid
          configurable_options {
            configurable_product_option_uid
            configurable_product_option_value_uid
            id
            option_label
            value_id
            value_label
          }
        }
        prices {
          price {
            currency
            value
          }
          row_total {
            currency
            value
          }
        }
      }
      shipping_addresses {
        selected_shipping_method {
          carrier_code
          carrier_title
          method_code
          method_title
          amount {
            currency
            value
          }
        }
      }
    }
  }
`;

export const GET_COMBINED_SOURCE_DATA = gql`
  query attach_dr_source_to_checkout($sourceId: String!, $checkoutId: String!) {
    core_attach_dr_source_to_checkout(input: { source_id: $sourceId, checkout_id: $checkoutId }) {
      status
      dr_checkout
    }
  }
`;
