import { gql } from '@apollo/client';

const UPDATE_CART_ITEM = gql`
  mutation updateCartItem($cart_id: String!, $cart_item_uid: ID!, $quantity: Float!) {
    core_updateCartItems(
      input: { cart_id: $cart_id, cart_items: [{ cart_item_uid: $cart_item_uid, quantity: $quantity }] }
    ) {
      cart {
        total_quantity
        items {
          uid
          quantity
          product {
            name
            sku
          }
        }
      }
    }
  }
`;

export default UPDATE_CART_ITEM;
