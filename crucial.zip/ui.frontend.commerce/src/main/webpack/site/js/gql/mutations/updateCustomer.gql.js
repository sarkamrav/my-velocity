import { gql } from '@apollo/client';

export const UPDATE_CUSTOMER = gql`
  mutation Core_updateCustomerV2(
    $firstname: String!
    $lastname: String!
    $password: String
    $newPassword: String
    $is_subscribed: Boolean
    $email: String!
    $customer_type: String!
  ) {
    core_updateCustomerV2(
      input: {
        firstname: $firstname
        lastname: $lastname
        password: $password
        newPassword: $newPassword
        is_subscribed: $is_subscribed
        email: $email
        customer_type: $customer_type
      }
    ) {
      customer {
        firstname
        lastname
        email
        id
        is_subscribed
      }
    }
  }
`;
