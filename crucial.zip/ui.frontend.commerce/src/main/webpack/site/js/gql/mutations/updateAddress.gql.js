import { gql } from '@apollo/client';

export const UPDATE_ADDRESS = gql`
  mutation Core_updateCustomerAddress(
    $id: Int!
    $nickname: String!
    $firstname: String!
    $lastname: String!
    $street: [String]!
    $city: String!
    $region: String!
    $postcode: String!
    $country_code: core_CountryCodeEnum!
    $company: String
    $telephone: String!
    $region_id: Int
    $region_code: String
  ) {
    core_updateCustomerAddress(
      input: {
        firstname: $firstname
        lastname: $lastname
        custom_attributes: { attribute_code: "nick_name", value: $nickname }
        street: $street
        city: $city
        region: { region: $region, region_code: $region_code, region_id: $region_id }
        postcode: $postcode
        country_code: $country_code
        company: $company
        telephone: $telephone
      }
      id: $id
    ) {
      id
    }
  }
`;
