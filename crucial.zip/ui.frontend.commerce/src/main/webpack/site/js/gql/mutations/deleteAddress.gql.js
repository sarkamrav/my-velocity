import { gql } from '@apollo/client';

export const DELETE_ADDRESS = gql`
  mutation core_DeleteCustomerAddress($id: Int!) {
    core_deleteCustomerAddress(id: $id)
  }
`;
