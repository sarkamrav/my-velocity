import { gql } from '@apollo/client';

export const GET_RETURN_REASONS = gql`
  query CoreReturnReasons {
    core_returnReasons {
      id
      name
    }
  }
`;
