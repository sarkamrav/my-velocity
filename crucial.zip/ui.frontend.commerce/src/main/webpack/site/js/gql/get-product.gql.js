import { gql } from '@apollo/client';

const GET_RECOMMENDATIONS_FRAGMENT = `
fragment Recommendations on Query  {
     recommendations(currentSku: $SKU, pageType: Product){
      totalResults
      results {
        storefrontLabel
        productsView {
          inStock
          id
          name
          shortDescription
          sku
          externalId
          url
          attributes(roles: null) {
            label
            name
            roles
            value
          }
          ... on SimpleProductView {
            categories_url_list {
              categories {
                url_key
                url_path
                level
              }
            }
            price {
              final {
                amount {
                  value
                  currency
                }
              }
              regular {
                amount {
                  value
                  currency
                }
              }
              roles
            }
          }
          images(roles: null) {
            label
            roles
            url
          }
        }
      }
    }

  }
`;

export const GET_BASIC_PRODUCT_DETAILS = gql`
  query getProduct($SKU: String!) {
    products(skus: [$SKU]) {
      __typename
      metaKeyword
      name
      description
      shortDescription
      sku
      externalId
      inStock
      attributes(roles: []) {
        name
        label
        value
      }
      images(roles: []) {
        url
      }

      ... on SimpleProductView {
        price {
          final {
            amount {
              value
              currency
            }
          }
          regular {
            amount {
              value
              currency
            }
          }
        }
      }
    }
  }
`;

export const GET_PRODUCT_ADDON = gql`
  query getProduct($SKU: String!, $isPdp: Boolean!) {
    products(skus: [$SKU]) {
      attributes(roles: []) {
        name
        label
        value
      }
      ... on SimpleProductView {
        addon_details {
          ... on core_SimpleProduct {
            options {
              uid

              ... on core_CustomizableRadioOption {
                radio_option: value {
                  option_type_id
                  sku
                  price
                  title
                }
              }
            }
          }
        }

        options_details {
          sku

          ... on core_ConfigurableProduct {
            configurable_options {
              label
              attribute_code
              values {
                value_index
                label
              }
            }
            variants {
              product {
                name
                sku
                supersize_price
                thumbnail {
                  url
                }
                stock_status
                kit_qty
                packaging
                price {
                  regularPrice {
                    amount {
                      value
                      currency
                    }
                  }
                  minimalPrice {
                    amount {
                      value
                      currency
                    }
                  }
                }
              }
              attributes {
                label
                code
                value_index
              }
            }
          }
        }
      }
    }

    core_customAttributeMetadata(attributes: { attribute_code: "packaging", entity_type: "catalog_product" }) {
      items {
        attribute_options {
          label
          value
        }
        attribute_code
      }
    }
    ...Recommendations @include(if: $isPdp)
  }
  ${GET_RECOMMENDATIONS_FRAGMENT}
`;

const GET_PRODUCT = gql`
  query getProduct($SKU: String!) {
    products(skus: [$SKU]) {
      __typename
      metaKeyword
      metaTitle
      name
      description
      shortDescription
      sku
      externalId
      url
      urlKey
      addToCartAllowed
      inStock
      images(roles: []) {
        url
        label
        roles
      }
      attributes(roles: []) {
        name
        label
        value
        roles
      }
      ... on SimpleProductView {
        price {
          final {
            amount {
              value
              currency
            }
          }
          regular {
            amount {
              value
              currency
            }
          }
          roles
        }
        addon_details {
          ... on core_SimpleProduct {
            options {
              title
              required
              sort_order
              option_id
              uid
              ... on core_CustomizableFieldOption {
                product_sku
                field_option: value {
                  sku
                  price
                  price_type
                  max_characters
                }
              }
              ... on core_CustomizableAreaOption {
                product_sku
                area_option: value {
                  sku
                  price
                  price_type
                  max_characters
                }
              }
              ... on core_CustomizableDateOption {
                product_sku
                date_option: value {
                  sku
                  price
                  price_type
                }
              }
              ... on core_CustomizableDropDownOption {
                drop_down_option: value {
                  option_type_id
                  sku
                  price
                  price_type
                  title
                  sort_order
                }
              }
              ... on core_CustomizableRadioOption {
                radio_option: value {
                  option_type_id
                  sku
                  price
                  price_type
                  title
                  sort_order
                }
              }
              ... on core_CustomizableCheckboxOption {
                checkbox_option: value {
                  option_type_id
                  sku
                  price
                  price_type
                  title
                  sort_order
                }
              }
              ... on core_CustomizableMultipleOption {
                multiple_option: value {
                  option_type_id
                  sku
                  price
                  price_type
                  title
                  sort_order
                }
              }
              ... on core_CustomizableFileOption {
                product_sku
                file_option: value {
                  sku
                  price
                  price_type
                  file_extension
                  image_size_x
                  image_size_y
                }
              }
            }
          }
        }

        options_details {
          sku

          ... on core_ConfigurableProduct {
            configurable_options {
              id
              attribute_id
              label
              position
              use_default
              attribute_code
              values {
                value_index
                label
                swatch_data {
                  value
                }
              }
            }
            variants {
              product {
                id
                name
                sku
                supersize_price
                variants_sort
                stock_status
                kit_qty
                packaging
                price {
                  regularPrice {
                    amount {
                      value
                      currency
                    }
                  }
                  minimalPrice {
                    amount {
                      value
                      currency
                    }
                  }
                }
              }
              attributes {
                label
                code
                value_index
              }
            }
          }
        }
      }
    }
  }
`;

export default GET_PRODUCT;
