import { gql } from "@apollo/client";

const CUSTOMER_INFO_STU_EMP = gql`
query {
  core_customer {
    firstname
    lastname
    email
    customer_type
    is_student_group
    is_employee_group
    send_reverification_link
    re_verify_date
    }
    core_customerCart {
        id
    }
}
`;

export default CUSTOMER_INFO_STU_EMP;
