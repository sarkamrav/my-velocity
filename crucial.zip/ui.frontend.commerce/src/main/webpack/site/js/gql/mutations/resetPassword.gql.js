import { gql } from '@apollo/client';
export const RESET_PASSWORD = gql`
  mutation ResetPassword($email: String!, $resetPasswordToken: String!, $newPassword: String!) {
    core_resetPassword(email: $email, resetPasswordToken: $resetPasswordToken, newPassword: $newPassword)
  }
`;
