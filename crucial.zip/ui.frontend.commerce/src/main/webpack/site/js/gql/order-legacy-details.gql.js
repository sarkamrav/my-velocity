import { gql } from '@apollo/client';

const ORDER_LEGACY_DETAIL = gql`
  query {
  core_drOrders {
    creation_date
    currency
    id
    status
    total
    payment_id
    billingAddress {
      city
      company
      country
      country_id
      email
      firstname
      lastname
      postcode
      region
      street
      telephone
    }
    items {
      discount_amount
      formatted_price
      formatted_sale_price
      id
      name
      price
      qty
      sale_price
      sku
      small_image
      tax_amount
      thumbnail
      tracking_information {
        tracking_number
        carrier
        date
        quantity
        tracking_link
      }
    }
    shippingAddress {
      city
      company
      country
      country_id
      email
      firstname
      lastname
      postcode
      region
      street
      telephone
    }
  }
}
`;

export default ORDER_LEGACY_DETAIL;

