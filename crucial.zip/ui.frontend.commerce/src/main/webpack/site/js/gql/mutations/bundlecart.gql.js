import { gql } from '@apollo/client';

export const CREATE_EMPTY_CART = gql`
  mutation CreateEmptyCart {
    core_createEmptyCart
  }
`;

export const ADD_BUNDLE_TO_CART = gql`
  mutation AddProductsToCart(
    $cartId: String!, $cartItems: [core_CartItemInput!]!
  ) {
    core_addProductsToCart(
      cartId: $cartId
      cartItems: $cartItems
    ) {
      cart {
        items {
          product {
            name
            sku
          }
          quantity
        }
      }

      user_errors {
        code
        message
      }
    }
  }
`;