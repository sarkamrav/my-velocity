import { gql } from '@apollo/client';

const CUSTOMER_TYPE = gql`
  query {
    core_customAttributeMetadata(attributes: [{ attribute_code: "customer_type", entity_type: "customer" }]) {
      items {
        attribute_options {
          value
          label
        }
      }
    }
  }
`;

export default CUSTOMER_TYPE;
