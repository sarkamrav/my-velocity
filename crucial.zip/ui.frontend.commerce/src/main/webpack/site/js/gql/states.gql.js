import { gql } from '@apollo/client';

export const STATE_QUERY = gql`
  query Core_country($id: String!) {
    core_country(id: $id) {
      two_letter_abbreviation
      available_regions {
        id
        code
        name
      }
    }
  }
`;
