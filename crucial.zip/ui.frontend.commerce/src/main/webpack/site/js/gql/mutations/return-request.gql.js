import { gql } from '@apollo/client';

export const RETURN_REQUEST = gql`
  mutation requestReturn($input: core_RequestReturnInput!) {
    core_requestReturn(input: $input) {
      return {
        uid
        items {
          uid
          status
          request_quantity
          quantity
          order_item {
            id
            eligible_for_return
            product_sku
            product_type
            quantity_returned
            status
          }
        }
        number
        status
        comments {
          uid
          author_name
          text
          created_at
        }
        customer {
          firstname
          lastname
          email
        }
      }
    }
  }
`;
