import { gql } from '@apollo/client';

export const PLP_PRODUCT_LIST = gql`
  query productSearch(
    $phrase: String!
    $sortObjName: String!
    $filter: [SearchClauseInput!]
    $current_page: Int
    $page_size: Int
    $imageRole: [String]
  ) {
    attributeMetadata {
      sortable {
        attribute
        label
      }
    }
    productSearch(
      phrase: $phrase
      current_page: $current_page
      page_size: $page_size
      sort: [{ attribute: $sortObjName, direction: DESC }]
      filter: $filter
    ) {
      total_count
      items {
        productView {
          inStock
          attributes(roles: []) {
            name
            value
            label
          }
          id
          images(roles: $imageRole) {
            url
          }
          name
          sku
          externalId
          ... on SimpleProductView {
            categories_url_list {
              categories {
                url_key
                url_path
                level
              }
            }
            price {
              final {
                amount {
                  value
                  currency
                }
              }
              regular {
                amount {
                  value
                  currency
                }
              }
            }
          }
        }
      }
      facets {
        attribute
        title
        buckets {
          title
          ... on RangeBucket {
            title
            to
            from
            count
          }
          ... on ScalarBucket {
            title
            id
            count
          }
          ... on StatsBucket {
            title
            min
            max
          }
        }
      }
    }
  }
`;
