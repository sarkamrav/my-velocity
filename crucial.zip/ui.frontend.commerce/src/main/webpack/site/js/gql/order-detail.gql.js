import { gql } from '@apollo/client';

const ORDER_DETAIL = gql`
  query getOrder($orderNumber: String!) {
    core_customer {
      email
      orders(filter: { number: { eq: $orderNumber } }) {
        total_count
        items {
          id
          number
          order_date
          status
          status_code
          invoices {
            items {
              id
            }
          }
          shipments {
            comments {
              message
              timestamp
            }
            id
            number
            tracking {
              carrier
              number
              title
              url
            }
            items {
              id
              product_name
              product_sku
              quantity_shipped
            }
          }
          items {
            id
            product_name
            product_sku
            product_url_key
            product_sale_price {
              value
              currency
            }
            quantity_ordered
            quantity_returned
            quantity_invoiced
            quantity_shipped
            eligible_for_return
          }
          returns {
            items {
              items {
                status
                order_item {
                  id
                  product_name
                  product_sku
                  quantity_returned
                  quantity_shipped
                  quantity_ordered
                }
              }
            }
          }
          carrier
          shipments {
            id
            number
            items {
              product_name
              quantity_shipped
            }
          }
          total {
            base_grand_total {
              value
              currency
            }
            grand_total {
              value
              currency
            }
            total_tax {
              value
            }
            subtotal {
              value
              currency
            }
            taxes {
              amount {
                value
                currency
              }
              title
              rate
            }
            total_shipping {
              value
            }
            shipping_handling {
              amount_including_tax {
                value
              }
              amount_excluding_tax {
                value
              }
              total_amount {
                value
              }
              taxes {
                amount {
                  value
                }
                title
                rate
              }
            }
            discounts {
              amount {
                value
                currency
              }
              label
            }
          }
          shipping_address {
            city
            company
            country_code
            fax
            firstname
            lastname
            middlename
            postcode
            prefix
            region
            region_id
            street
            suffix
            telephone
            vat_id
          }
          billing_address {
            city
            company
            country_code
            fax
            firstname
            lastname
            middlename
            postcode
            prefix
            region
            region_id
            street
            suffix
            telephone
            vat_id
          }
        }
      }
    }
  }
`;

export default ORDER_DETAIL;
