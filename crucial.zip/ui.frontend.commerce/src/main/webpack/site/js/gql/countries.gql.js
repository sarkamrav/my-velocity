import { gql } from '@apollo/client';

export const COUNTRY_QUERY = gql`
  query {
    core_countries {
      id
      two_letter_abbreviation
      full_name_locale
      full_name_english
    }
  }
`;
