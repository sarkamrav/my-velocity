export const hideSignInDiv = () => {
  const htmlTag = document.querySelector('html');
  const langAttribute = htmlTag.getAttribute('lang');

  const invalidLanguages = ['es-mx', 'pt-br', 'en-in', 'ko-kr', 'zh', 'zh-tw', 'zh-cn', 'ja-jp'];
  const invalidLocales = invalidLanguages.includes(langAttribute);
  return invalidLocales;
};
