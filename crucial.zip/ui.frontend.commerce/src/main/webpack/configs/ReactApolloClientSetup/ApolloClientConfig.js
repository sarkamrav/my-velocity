import { InMemoryCache, HttpLink, ApolloClient } from '@apollo/client';
import { setContext } from '@apollo/client/link/context';
import CryptoJS from 'crypto-js';
import { stripIgnoredCharacters } from 'graphql';
import { getCookie } from '../../utils/cookies_operation';

// Define the GraphQL endpoint
let graphqlEndPoint = '';
const dataElement = document.querySelector('[data-graphql-endpoint]');
if (dataElement) {
  graphqlEndPoint = dataElement.getAttribute('data-graphql-endpoint');
}

// Function to get user token from local storage
export function getUserTokenFromLoaclStorate() {
  const tokenData = localStorage.getItem('user_token');
  if (tokenData) {
    const jsonData = JSON.parse(tokenData);
    const timeStored = Number(jsonData.timeStored);
    const ttl = Number(jsonData.ttl);
    if (timeStored + ttl < new Date().getTime()) {
      localStorage.removeItem('user_token');
      document.cookie = 'user_token=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
      document.cookie = 'cart_items=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
      document.cookie = 'user_email=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
      document.cookie = 'student_popup=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
      return '';
    }
    return jsonData.token;
  }
  return '';
}

// Function to get catalog service headers
export function getCatalogServiceHeaders() {
  const localeMap = [
    { key: 'en-us', value: 'en_us' },
    { key: 'en-gb', value: 'en_gb' },
    { key: 'fr-fr', value: 'fr' },
    { key: 'de-de', value: 'de' },
    { key: 'es-es', value: 'es_es' },
    { key: 'it-it', value: 'it' },
    { key: 'es-mx', value: 'es_mx' },
    { key: 'pt-br', value: 'pt_br' },
    { key: 'en', value: 'eu' },
    { key: 'en-in', value: 'en_in' },
    { key: 'ko-kr', value: 'ko' },
    { key: 'zh', value: 'CN_ZH' },
    { key: 'zh-tw', value: 'TW_ZH' },
    { key: 'ja-jp', value: 'ja' },
  ];

  const localeElement = document.querySelector('[lang]');
  const locale = localeElement ? localeElement.getAttribute('lang') : '';

  let store = 'default';
  if (locale) {
    for (let i = 0; i < localeMap.length; i++) {
      if (localeMap[i].key === locale) {
        store = localeMap[i].value;
        break;
      }
    }
  }
  return store;
}

// Function to get the vatID type to be sent to the API
// Being used in the VATID component
// Will be used for non-US customers only
export function getVatId(code) {
  const countryCodes = [
    {
      id: 'AU',
      full_name_english: 'Australia',
      value: 'au',
    },
    {
      id: 'AT',
      full_name_english: 'Austria',
      value: 'at',
    },
    {
      id: 'AE',
      full_name_english: 'United Arab Emirates',
      value: 'ae',
    },
    {
      id: 'BE',
      full_name_english: 'Belgium',
      value: 'be',
    },
    {
      id: 'BG',
      full_name_english: 'Bulgaria',
      value: 'bg',
    },
    {
      id: 'BH',
      full_name_english: 'Bahrain',
      value: 'bh',
    },
    {
      id: 'CA',
      full_name_english: 'Canada',
      value: 'ca',
    },
    {
      id: 'CH',
      full_name_english: 'Switzerland',
      value: 'ch',
    },
    {
      id: 'CL',
      full_name_english: 'Chile',
      value: 'cl',
    },
    {
      id: 'CO',
      full_name_english: 'Colombia',
      value: 'co',
    },
    {
      id: 'CY',
      full_name_english: 'Cyprus',
      value: 'cy',
    },
    {
      id: 'CZ',
      full_name_english: 'Czechia',
      value: 'cz',
    },
    {
      id: 'DE',
      full_name_english: 'Germany',
      value: 'de',
    },
    {
      id: 'DK',
      full_name_english: 'Denmark',
      value: 'dk',
    },
    {
      id: 'EE',
      full_name_english: 'Estonia',
      value: 'ee',
    },
    {
      id: 'ES',
      full_name_english: 'Spain',
      value: 'es',
    },
    {
      id: 'FI',
      full_name_english: 'Finland',
      value: 'fi',
    },
    {
      id: 'FR',
      full_name_english: 'France',
      value: 'fr',
    },
    {
      id: 'GB',
      full_name_english: 'United Kingdom',
      value: 'uk',
    },
    {
      id: 'GR',
      full_name_english: 'Greece',
      value: 'gr',
    },
    {
      id: 'HR',
      full_name_english: 'Croatia',
      value: 'hr',
    },
    {
      id: 'HU',
      full_name_english: 'Hungary',
      value: 'hu',
    },
    {
      id: 'IE',
      full_name_english: 'Ireland',
      value: 'ie',
    },
    {
      id: 'IN',
      full_name_english: 'India',
      value: 'in',
    },
    {
      id: 'IS',
      full_name_english: 'Iceland',
      value: 'is',
    },
    {
      id: 'IT',
      full_name_english: 'Italy',
      value: 'it',
    },
    {
      id: 'JP',
      full_name_english: 'Japan',
      value: 'jp',
    },
    {
      id: 'LT',
      full_name_english: 'Lithuania',
      value: 'lt',
    },
    {
      id: 'LU',
      full_name_english: 'Luxembourg',
      value: 'lu',
    },
    {
      id: 'MT',
      full_name_english: 'Malta',
      value: 'mt',
    },
    {
      id: 'MX',
      full_name_english: 'Mexico',
      value: 'mx',
    },
    {
      id: 'NL',
      full_name_english: 'Netherlands',
      value: 'nl',
    },
    {
      id: 'NZ',
      full_name_english: 'New Zealand',
      value: 'nz',
    },
    {
      id: 'NO',
      full_name_english: 'Norway',
      value: 'no',
    },
    {
      id: 'PH',
      full_name_english: 'Philippines',
      value: 'ph',
    },
    {
      id: 'PL',
      full_name_english: 'Poland',
      value: 'pl',
    },
    {
      id: 'PT',
      full_name_english: 'Portugal',
      value: 'pt',
    },
    {
      id: 'RO',
      full_name_english: 'Romania',
      value: 'ro',
    },
    {
      id: 'SG',
      full_name_english: 'Singapore',
      value: 'sg',
    },
    {
      id: 'ZA',
      full_name_english: 'South Africa',
      value: 'za',
    },
    {
      id: 'SE',
      full_name_english: 'Sweden',
      value: 'se',
    },
    {
      id: 'SI',
      full_name_english: 'Slovenia',
      value: 'si',
    },
    {
      id: 'SK',
      full_name_english: 'Slovakia',
      value: 'sk',
    },
    {
      id: 'TH',
      full_name_english: 'Thailand',
      value: 'th',
    },
    {
      id: 'TW',
      full_name_english: 'Taiwan, Province of China',
      value: 'tw',
    },
    {
      id: 'TR',
      full_name_english: 'Turkey',
      value: 'tr',
    },
  ];

  return countryCodes.find(countryCode => countryCode.id === code).value;
}

// Function to decrypt stored header value
export function readStoredHeader(title) {
  const headerString = getCookie('headerDetails');
  if (headerString) {
    return CryptoJS.AES.decrypt(JSON.parse(headerString)[title], 'crucialAdobeCommerce').toString(CryptoJS.enc.Utf8);
  }
  return '';
}

// Function to create Apollo Client configuration for product
export function apolloClientConfigForProduct() {
  return {
    uri: graphqlEndPoint,
    cache: new InMemoryCache(),
    link: new HttpLink({
      uri: graphqlEndPoint,
      headers: {
        authorization: `Bearer ${getUserTokenFromLoaclStorate()}`,
        Store: getCatalogServiceHeaders(),
        'Magento-Customer-Group': readStoredHeader('customer_group'),
        'Magento-Environment-Id': readStoredHeader('environment_id'),
        'Magento-Store-Code': readStoredHeader('store_code'),
        'Magento-Store-View-Code': readStoredHeader('store_view_code'),
        'Magento-Website-Code': readStoredHeader('website_code'),
      },
      print(ast, originalPrint) {
        return stripIgnoredCharacters(originalPrint(ast));
      },
    }),
  };
}

// Function to create Apollo Client configuration using GET for queries
export function apolloClientConfigUsingGet() {
  const authLink = setContext((_, { headers }) => {
    return {
      headers: {
        ...headers,
        authorization: `Bearer ${getUserTokenFromLoaclStorate()}`,
        Store: getCatalogServiceHeaders(),
        'Magento-Customer-Group': readStoredHeader('customer_group'),
        'Magento-Environment-Id': readStoredHeader('environment_id'),
        'Magento-Store-Code': readStoredHeader('store_code'),
        'Magento-Store-View-Code': readStoredHeader('store_view_code'),
        'Magento-Website-Code': readStoredHeader('website_code'),
      },
    };
  });

  const link = authLink.concat(
    new HttpLink({
      uri: graphqlEndPoint,
      useGETForQueries: true,
      print(ast, originalPrint) {
        return stripIgnoredCharacters(originalPrint(ast));
      },
    })
  );

  return {
    cache: new InMemoryCache(),
    link: link,
  };
}

// Function to create Apollo Client configuration using GET for queries for non product related calls
export function clientConfigUsingGet() {
  const authLink = setContext((_, { headers }) => {
    return {
      headers: {
        ...headers,
        authorization: `Bearer ${getUserTokenFromLoaclStorate()}`,
        Store: getCatalogServiceHeaders(),
      },
    };
  });

  return new ApolloClient({
    link: authLink.concat(
      new HttpLink({
        uri: graphqlEndPoint,
        useGETForQueries: true,
        print(ast, originalPrint) {
          return stripIgnoredCharacters(originalPrint(ast));
        },
      })
    ),
    cache: new InMemoryCache(),
  });
}

export function clientConfig() {
  const authLink = setContext((_, { headers }) => {
    return {
      headers: {
        ...headers,
        authorization: `Bearer ${getUserTokenFromLoaclStorate()}`,
        Store: getCatalogServiceHeaders(),
      },
    };
  });

  return {
    link: authLink.concat(
      new HttpLink({
        uri: graphqlEndPoint,
        print(ast, originalPrint) {
          return stripIgnoredCharacters(originalPrint(ast));
        },
      })
    ),
    cache: new InMemoryCache(),
  };
}

export default clientConfig();
