export const IMG_SOURCE = 'https://venia.magento.com';
export const CURRENCY = { USD: '$' };
export const QTY_LIMIT = 10;
