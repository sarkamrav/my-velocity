const storeConfigEl = document.querySelector('meta[name="store-config"]');
let storeConfig;
let headers = {};

if (storeConfigEl) {
  storeConfig = JSON.parse(storeConfigEl.content);
  headers = storeConfig.headers;
}

const baseUrl = storeConfig.storeRootUrl;
const basePath = baseUrl ? baseUrl.substr(0, baseUrl.indexOf('.')) : '';
const { localeCode, countrycode } = document.documentElement.dataset;
const storeView = storeConfig.storeView || localeCode?.toLowerCase();


export default {
  storeView,
  localeCode,
  countrycode,
  graphqlEndpoint: storeConfig.graphqlEndpoint,
  // Can be GET or POST. When selecting GET, this applies to cache-able GraphQL query requests only. Mutations
  // will always be executed as POST requests.
  graphqlMethod: storeConfig.graphqlMethod,
  headers,

  pagePaths: {
    baseUrl,
    basePath,
  },
};
