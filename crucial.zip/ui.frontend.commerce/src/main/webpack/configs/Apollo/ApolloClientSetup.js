import { ApolloClient, from, HttpLink, InMemoryCache } from '@apollo/client';
// import { getCookie } from './common/cookie';
// import { cookieConst } from './common/constant';
import compressQueryFetch from './compressQueryFetch';
import typePolicies from './typePolicies';

const ApolloClientSetup = config => {
  // const token = getCookie(cookieConst.authToken);
  const token = '';
  const clientHeaders = { ...config.headers };

  if (config.storeView) {
    clientHeaders.Store = config.storeView;
  }

  if (token) {
    clientHeaders.Authorization = `Bearer ${token}`;
  }

  const clientConfig = {
    link: from([
      new HttpLink({
        uri: config.graphqlEndpoint,
        headers: clientHeaders,
        useGETForQueries: config.graphqlMethod === 'GET',
        fetch: compressQueryFetch,
      }),
    ]),
    cache: new InMemoryCache({ typePolicies }),
  };

  const client = new ApolloClient(clientConfig);
  return client;
};

export default ApolloClientSetup;
