/**
 * Custom type policies that allow us to have more granular control
 * over how ApolloClient reads from and writes to the cache.
 *
 * https://www.apollographql.com/docs/react/caching/cache-configuration/#typepolicy-fields
 * https://www.apollographql.com/docs/react/caching/cache-field-behavior/
 */

const typePolicies = {
  // Query/Mutation are "types" just like "Cart".
  Query: {
    fields: {
      customer: {
        keyArgs: () => 'Customer',
      },
      customerWishlistProducts: {
        read: existing => existing || [],
      },
    },
  },
  AppliedGiftCard: {
    keyFields: ['code'],
  },
  Breadcrumb: {
    // Uses provided fields on the object as the `id`.
    keyFields: ['category_id'],
  },
  Cart: {
    keyFields: () => 'Cart',
    fields: {
      applied_gift_cards: {
        // eslint-disable-next-line no-unused-vars
        merge(existing, incoming) {
          return incoming;
        },
      },
      prices: {
        // `merge: true` can be used for an object field.
        merge: true,
      },
    },
  },
  Customer: {
    keyFields: () => 'Customer',
    fields: {
      addresses: {
        merge(existing, incoming) {
          return incoming;
        },
        read(cachedAddresses, { toReference }) {
          if (cachedAddresses) {
            return cachedAddresses.map(address => {
              // Update v2 identifiers to new references. Previous
              // entries had `id: CustomerAddress:1` which caused
              // v3's lookup to fail. If we find a legacy id,
              // point it at the object using a reference.
              if (address.id && address.id.includes('CustomerAddress')) {
                return toReference(address.id);
              }
              return address;
            });
          }
          // If there are no cached addresses that's fine - the schema
          // shows that it is a nullable field.
        },
      },
      orders: {
        keyArgs: ['filter'],
        items: {
          merge: true,
        },
      },
    },
  },
  CustomerAddress: {
    fields: {
      street: {
        // eslint-disable-next-line no-unused-vars
        merge(existing, incoming) {
          return incoming;
        },
      },
    },
  },
  SelectedConfigurableOption: {
    // id alone is not enough to identify a selected option as it can refer
    // to something like "size" where value_id refers to "large".
    keyFields: ['id', 'value_id'],
  },
  CategoryTree: {
    fields: {
      children: {
        merge(existing, incoming) {
          return incoming;
        },
      },
    },
  },
  Wishlist: {
    keyFields: ({ id }) => `CustomerWishlist:${id}`,
    fields: {
      items_v2: {
        keyArgs: false,
        merge: false,
      },
    },
  },
  WishlistItem: {
    keyFields: ({ id }) => `CustomerWishlistItem:${id}`,
  },
  WishlistItems: {
    fields: {
      items: {
        // eslint-disable-next-line default-param-last
        merge: (existing = [], incoming, { variables }) => {
          if (variables) {
            const { currentPage = 1 } = variables;
            // reset cache collection if we're on the first page

            if (currentPage === 1) {
              return incoming;
            }
          }

          return [...existing, ...incoming];
        },
      },
    },
  },
  SimpleWishlistItem: {
    keyFields: ({ id }) => `CustomerSimpleWishlistItem:${id}`,
  },
  VirtualWishlistItem: {
    keyFields: ({ id }) => `CustomerVirtualWishlistItem:${id}`,
  },
  DownloadableWishlistItem: {
    keyFields: ({ id }) => `CustomerDownloadableWishlistItem:${id}`,
  },
  BundleWishlistItem: {
    keyFields: ({ id }) => `CustomerBundleWishlistItem:${id}`,
  },
  GroupedProductWishlistItem: {
    keyFields: ({ id }) => `CustomerGroupedProductWishlistItem:${id}`,
  },
  ConfigurableWishlistItem: {
    keyFields: ({ id }) => `CustomerConfigurableWishlistItem:${id}`,
  },
  GiftCardWishlistItem: {
    keyFields: ({ id }) => `CustomerGiftCardWishlistItem:${id}`,
  },
};

export default typePolicies;
