export default function syncText(input = '', content) {
  // Create a regular expression pattern to match the placeholders [#]
  let placeholderPattern = /\[#\]/g;
  let response = input || '';
  let contentIndex = 0;

  // Replace the placeholders with content data using the replace() method
  response = input.replace(placeholderPattern, function (match) {
    if (contentIndex < content.length) {
      return content[contentIndex++];
    } else {
      // If there's no more dynamic data, keep the placeholder unchanged
      return match;
    }
  });

  return response;
}
