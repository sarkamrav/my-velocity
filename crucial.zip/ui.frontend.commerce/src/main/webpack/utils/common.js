// Links data for the main nav on Account Home pages
/* eslint-disable max-len */ 
export const navLinks = [
  {
    linkText: 'Address book',
  },
  {
    linkText: 'Saved payments',
  },
  {
    linkText: 'Order history',
  },
  {
    linkText: 'Saved scans',
  },
];

// Link data for the 'My Account' dropdown menu
export const linksJSON = [
  {
    linkIcon: 'Settings',
    linkText: 'Account home',
  },
  {
    linkIcon: 'AddressBook',
    linkText: 'Address book',
  },
  {
    linkIcon: 'CreditCard',
    linkText: 'Saved payments',
  },
  {
    linkIcon: 'ShoppingBag',
    linkText: 'Order history',
  },
  {
    linkIcon: 'PlusCircle',
    linkText: 'Product registration',
  },
  {
    linkIcon: 'CheckCircle',
    linkText: 'Registered products',
  },
  {
    linkIcon: 'Laptop',
    linkText: 'Saved scans',
  },
];

// Dummy data for Order list component to be shown on Order History page
export const columnNames = ['Order Number', 'Order Date', 'Creation Date', 'Status', 'Order Amount'];
export const orderData = [
  {
    order_number: 'ABC',
    order_date: 'ABC',
    creation_date: 'ABC',
    status: 'ABC',
    order_amount: 'ABC',
  },
  {
    order_number: 'ABC',
    order_date: 'ABC',
    creation_date: 'ABC',
    status: 'ABC',
    order_amount: 'ABC',
  },
  {
    order_number: 'ABC',
    order_date: 'ABC',
    creation_date: 'ABC',
    status: 'ABC',
    order_amount: 'ABC',
  },
];

// Dummy data to display on the order details page
export const orderInfo = {
  order_number: '137175036800',
  order_date: '4/29/24',
  order_status: 'Order Unsubmitted',
  billing_address: {
    billing_name: 'Matthew Haglund',
    billing_line_1: 'Digital River',
    billing_line_2: '10380 Bren Rd W',
    billing_line_3: 'Minnetonka, MN 55343',
    billing_locale: 'US',
  },
  shipping_address: {
    shipping_name: 'Matthew Haglund',
    shipping_line_1: 'Digital River',
    shipping_line_2: '10380 Bren Rd W',
    shipping_line_3: 'Minnetonka, MN 55343',
    shipping_locale: 'US',
  },
  product_list: [
    {
      quantity: '1',
      products: {
        title: '16GB DDR5-6000 UDIMM 1.1V CL48',
        product_info: [
          {
            name: 'CP16G60C48U5',
          },
          {
            name: 'CP16G60C48U6',
          },
          {
            name: 'CP16G60C48U7',
          },
        ],
      },
    },
    {
      quantity: '1',
      products: {
        title: '16GB DDR5-600 Premium',
        product_info: [
          {
            name: 'CP16G60C48U5',
          },
          {
            name: 'CP16G60C48U6',
          },
          {
            name: 'CP16G60C48U7',
          },
        ],
      },
    },
  ],
};

//Options for Select menus on Saved payments page
export const months = [
  {
    options: [
      { value: '', label: 'Select One' },
      { value: '1', label: 'January' },
      { value: '2', label: 'February' },
      { value: '3', label: 'March' },
      { value: '4', label: 'April' },
      { value: '5', label: 'May' },
      { value: '6', label: 'June' },
      { value: '7', label: 'July' },
      { value: '8', label: 'August' },
      { value: '9', label: 'September' },
      { value: '10', label: 'October' },
      { value: '11', label: 'November' },
      { value: '12', label: 'December' },
    ],
  },
];

const currentYear = new Date().getFullYear();
export const years = [
  {
    options: [{ value: '', label: 'Select One' }],
  },
  ...Array.from({ length: 15 }, (_, i) => ({
    options: [{ value: currentYear + i, label: (currentYear + i).toString() }],
  })),
];

// Options being used on Address Book page
export const countries = [
  {
    options: [
      { value: '', label: 'Select One' },
      { value: 'CA', label: 'Canada' },
      { value: 'US', label: 'United States' },
    ],
  },
];

export const states = [
  { options: [{ value: '', label: '' }] },
  {
    optGroup: 'States',
    options: [
      { value: 'AL', label: 'Alabama' },
      { value: 'AK', label: 'Alaska' },
      { value: 'AZ', label: 'Arizona' },
      { value: 'AR', label: 'Arkansas' },
      { value: 'AA', label: 'Armed Forces America' },
      { value: 'AE', label: 'Armed Forces Europe' },
      { value: 'AP', label: 'Armed Forces Pacific' },
      { value: 'CA', label: 'California' },
      { value: 'CO', label: 'Colorado' },
      { value: 'CT', label: 'Connecticut' },
      { value: 'DE', label: 'Delaware' },
      { value: 'DC', label: 'District Of Columbia' },
      { value: 'FL', label: 'Florida' },
      { value: 'GA', label: 'Georgia' },
      { value: 'HI', label: 'Hawaii' },
      { value: 'ID', label: 'Idaho' },
      { value: 'IL', label: 'Illinois' },
      { value: 'IN', label: 'Indiana' },
      { value: 'IA', label: 'Iowa' },
      { value: 'KS', label: 'Kansas' },
      { value: 'KY', label: 'Kentucky' },
      { value: 'LA', label: 'Louisiana' },
      { value: 'ME', label: 'Maine' },
      { value: 'MD', label: 'Maryland' },
      { value: 'MA', label: 'Massachusetts' },
      { value: 'MI', label: 'Michigan' },
      { value: 'MN', label: 'Minnesota' },
      { value: 'MS', label: 'Mississippi' },
      { value: 'MO', label: 'Missouri' },
      { value: 'MT', label: 'Montana' },
      { value: 'NE', label: 'Nebraska' },
      { value: 'NV', label: 'Nevada' },
      { value: 'NH', label: 'New Hampshire' },
      { value: 'NJ', label: 'New Jersey' },
      { value: 'NM', label: 'New Mexico' },
      { value: 'NY', label: 'New York' },
      { value: 'NC', label: 'North Carolina' },
      { value: 'ND', label: 'North Dakota' },
      { value: 'OH', label: 'Ohio' },
      { value: 'OK', label: 'Oklahoma' },
      { value: 'OR', label: 'Oregon' },
      { value: 'PA', label: 'Pennsylvania' },
      { value: 'RI', label: 'Rhode Island' },
      { value: 'SC', label: 'South Carolina' },
      { value: 'SD', label: 'South Dakota' },
      { value: 'TN', label: 'Tennessee' },
      { value: 'TX', label: 'Texas' },
      { value: 'UT', label: 'Utah' },
      { value: 'VT', label: 'Vermont' },
      { value: 'VA', label: 'Virginia' },
      { value: 'WA', label: 'Washington' },
      { value: 'WV', label: 'West Virginia' },
      { value: 'WI', label: 'Wisconsin' },
      { value: 'WY', label: 'Wyoming' },
    ],
  },
  {
    optGroup: 'Provinces',
    options: [
      { value: 'AB', label: 'Alberta' },
      { value: 'BC', label: 'British Columbia' },
      { value: 'MB', label: 'Manitoba' },
      { value: 'NB', label: 'New Brunswick' },
      { value: 'NL', label: 'Newfoundland and Labrador' },
      { value: 'NT', label: 'Northwest Territories' },
      { value: 'NS', label: 'Nova Scotia' },
      { value: 'NU', label: 'Nunavut' },
      { value: 'ON', label: 'Ontario' },
      { value: 'PE', label: 'Prince Edward Island' },
      { value: 'QC', label: 'Quebec' },
      { value: 'SK', label: 'Saskatchewan' },
      { value: 'YT', label: 'Yukon' },
    ],
  },
];

// For Addressbook component - eventually might be removed
export const addresses = [
  {
    address_heading: 'Address Heading',
    address_firstName: 'Firstname',
    address_lastName: 'Lastname',
    address_companyName: 'Company',
    address_line1: 'Line 1',
    address_line2: 'line 2',
    address_city: 'Minnesota',
    address_state: 'Florida',
    address_country: 'US',
    address_zipCode: '123ABC',
    address_phoneNumber: '1234567890',
  },
  {
    address_heading: 'Address Heading',
    address_firstName: 'Firstname',
    address_lastName: 'Lastname',
    address_companyName: 'Company',
    address_line1: 'Line 1',
    address_line2: 'line 2',
    address_city: 'Minnesota',
    address_state: 'Florida',
    address_country: 'US',
    address_zipCode: '123ABC',
    address_phoneNumber: '1234567890',
  },
];

// Dummy data for Dropdown component
export const dummyJSON = [
  {
    options: [
      {
        label: 'Select',
        value: '',
      },
    ],
  },
  {
    optGroup: 'Fruits',
    options: [
      {
        value: 'A',
        label: 'Apple',
      },
      {
        value: 'B',
        label: 'Banana',
      },
      {
        value: 'C',
        label: 'Chicku',
      },
    ],
  },
  {
    optGroup: 'Cars',
    options: [
      {
        value: 'H',
        label: 'Honda',
      },
      {
        value: 'T',
        label: 'Tata',
        selected: true,
      },
      {
        value: 'F',
        label: 'Ford',
      },
    ],
  },
];

// JSON for addresses dropdown on Billing Info Page
export const billingAddresses = [
  {
    options: [
      {
        value: '',
        label: 'Default',
      },
      {
        value: 'A',
        label: 'First Address',
      },
      {
        value: 'B',
        label: 'Second Address',
      },
    ],
  },
];

// JSON for radio buttons on Billing Info page
export const purchases = [
  {
    label: 'Personal purchase',
    value: 'individual',
  },
  {
    label: 'Business purchase',
    value: 'business',
  },
];

// Steps for step navigator on Checkout Pages
export const steps = [
  {
    title: 'Billing',
  },
  {
    title: 'Verify Order',
  },
  {
    title: 'Order Completed',
  },
];

// Tax exemption authority options
export const taxAuthorities = [
  {
    options: [
      { value: '', label: 'Exemption Certificate Tax Authority*' },
      { value: 'AL', label: 'Alabama' },
      { value: 'AK', label: 'Alaska' },
      { value: 'AZ', label: 'Arizona' },
      { value: 'AR', label: 'Arkansas' },
      { value: 'AA', label: 'Armed Forces America' },
      { value: 'AE', label: 'Armed Forces Europe' },
      { value: 'AP', label: 'Armed Forces Pacific' },
      { value: 'CA', label: 'California' },
      { value: 'CO', label: 'Colorado' },
      { value: 'CT', label: 'Connecticut' },
      { value: 'DE', label: 'Delaware' },
      { value: 'DC', label: 'District Of Columbia' },
      { value: 'FL', label: 'Florida' },
      { value: 'GA', label: 'Georgia' },
      { value: 'HI', label: 'Hawaii' },
      { value: 'ID', label: 'Idaho' },
      { value: 'IL', label: 'Illinois' },
      { value: 'IN', label: 'Indiana' },
      { value: 'IA', label: 'Iowa' },
      { value: 'KS', label: 'Kansas' },
      { value: 'KY', label: 'Kentucky' },
      { value: 'LA', label: 'Louisiana' },
      { value: 'ME', label: 'Maine' },
      { value: 'MD', label: 'Maryland' },
      { value: 'MA', label: 'Massachusetts' },
      { value: 'MI', label: 'Michigan' },
      { value: 'MN', label: 'Minnesota' },
      { value: 'MS', label: 'Mississippi' },
      { value: 'MO', label: 'Missouri' },
      { value: 'MT', label: 'Montana' },
      { value: 'NE', label: 'Nebraska' },
      { value: 'NV', label: 'Nevada' },
      { value: 'NH', label: 'New Hampshire' },
      { value: 'NJ', label: 'New Jersey' },
      { value: 'NM', label: 'New Mexico' },
      { value: 'NY', label: 'New York' },
      { value: 'NC', label: 'North Carolina' },
      { value: 'ND', label: 'North Dakota' },
      { value: 'OH', label: 'Ohio' },
      { value: 'OK', label: 'Oklahoma' },
      { value: 'OR', label: 'Oregon' },
      { value: 'PA', label: 'Pennsylvania' },
      { value: 'RI', label: 'Rhode Island' },
      { value: 'SC', label: 'South Carolina' },
      { value: 'SD', label: 'South Dakota' },
      { value: 'TN', label: 'Tennessee' },
      { value: 'TX', label: 'Texas' },
      { value: 'UT', label: 'Utah' },
      { value: 'VT', label: 'Vermont' },
      { value: 'VA', label: 'Virginia' },
      { value: 'WA', label: 'Washington' },
      { value: 'WV', label: 'West Virginia' },
      { value: 'WI', label: 'Wisconsin' },
      { value: 'WY', label: 'Wyoming' },
    ],
  },
];

// Products JSON for the Order summary component on Billing info page
export const orderedProducts = [
  {
    id: 1,
    qty: 9,
    
    img: 'https://content.crucial.com/content/dam/crucial/dram-products/desktop/images/product/crucial-ddr5-16-32gb-udimm-kit2-image.psd.transform/small-png/image.png',
    title: '2-32GB DDR5-5600 UDIMM 1.1V CL46',
    price: '$2,069.91',
  },
  {
    id: 2,
    qty: 2,
    img: 'https://content.crucial.com/content/dam/crucial/ssd-products/x10-pro/photography/isolated/crucial-x10-pro-portable-ssd-left-angle.psd.transform/small-png/image.png',
    title: 'Crucial X10 Pro 2TB Portable SSD',
    price: '$174.99',
  },
];
// For Price Type Calculation

export const priceType = price => {
  if (price?.final?.amount?.value !== undefined && price?.regular?.amount?.value !== undefined) {
    if (price?.final?.amount?.value) {
      if (price.final.amount.value < price.regular.amount.value) {
        return 'special';
      } else {
        return 'regular';
      }
    }
  }
};

export function findObjectByName(array, name) {
  return array.find(obj => obj.name === name);
}

export function getAttributeValue(array, attributeCode) {
  if (!array || !attributeCode) {
    return undefined;
  }

  const attributes = array;
  for (const attribute of attributes) {
    if (attribute.name === attributeCode) {
      return attribute.value;
    }
  }
  return undefined;
}

// Function to get the attribute object
export function getAttribute(array, attributeCode) {
  if (!array || !attributeCode) {
    return undefined;
  }

  const attributes = array;
  for (const attribute of attributes) {
    if (attribute.name === attributeCode) {
      return attribute;
    }
  }
  return undefined;
}

// Function to create JSON to formulate the specs table for the PDP page
export const createSpecsJSON = attributes => {
  if (!attributes || attributes === undefined) {
    return;
  }
  const general_specs = [];
  const default_specs = [];
  const speed_specs = [];
  const warranty_specs = [];

  if (getAttribute(attributes, 'technology') || getAttribute(attributes, 'ssd_series')) {
    getAttribute(attributes, 'technology')
      ? general_specs.push(getAttribute(attributes, 'technology'))
      : general_specs.push(getAttribute(attributes, 'ssd_series'));
  }

  if (getAttribute(attributes, 'interface') || getAttribute(attributes, 'module_type')) {
    getAttribute(attributes, 'interface')
      ? general_specs.push(getAttribute(attributes, 'interface'))
      : general_specs.push(getAttribute(attributes, 'module_type'));
  }

  if (getAttribute(attributes, 'density') || getAttribute(attributes, 'total_density')) {
    getAttribute(attributes, 'density')
      ? general_specs.push(getAttribute(attributes, 'density'))
      : general_specs.push(getAttribute(attributes, 'total_density'));
  }

  getAttribute(attributes, 'kit_qty') && general_specs.push(getAttribute(attributes, 'kit_qty'));

  if (getAttribute(attributes, 'form_factor') || getAttribute(attributes, 'voltage')) {
    getAttribute(attributes, 'form_factor')
      ? general_specs.push(getAttribute(attributes, 'form_factor'))
      : general_specs.push(getAttribute(attributes, 'voltage'));
  }

  if (getAttribute(attributes, 'dimm_type') || getAttribute(attributes, 'ssd_endurance_tbw')) {
    getAttribute(attributes, 'dimm_type')
      ? general_specs.push(getAttribute(attributes, 'dimm_type'))
      : general_specs.push(getAttribute(attributes, 'ssd_endurance_tbw'));
  }

  getAttribute(attributes, 'die_density') && general_specs.push(getAttribute(attributes, 'die_density'));

  if (getAttribute(attributes, 'sequential_write') || getAttribute(attributes, 'speed')) {
    getAttribute(attributes, 'sequential_write')
      ? speed_specs.push(getAttribute(attributes, 'sequential_write'))
      : speed_specs.push(getAttribute(attributes, 'speed'));
  }

  if (getAttribute(attributes, 'sequential_read') || getAttribute(attributes, 'cas_latency')) {
    getAttribute(attributes, 'sequential_read')
      ? speed_specs.push(getAttribute(attributes, 'sequential_read'))
      : speed_specs.push(getAttribute(attributes, 'cas_latency'));
  }

  getAttribute(attributes, 'extended_timings') && speed_specs.push(getAttribute(attributes, 'extended_timings'));

  getAttribute(attributes, 'default_jedec') && default_specs.push(getAttribute(attributes, 'default_jedec'));

  getAttribute(attributes, 'xmp_3_profile_1') && default_specs.push(getAttribute(attributes, 'xmp_3_profile_1'));

  getAttribute(attributes, 'xmp_3_profile_2') && default_specs.push(getAttribute(attributes, 'xmp_3_profile_2'));

  getAttribute(attributes, 'xmp_2_profile_1') && default_specs.push(getAttribute(attributes, 'xmp_2_profile_1'));

  getAttribute(attributes, 'xmp_2_profile_2') && default_specs.push(getAttribute(attributes, 'xmp_2_profile_2'));

  getAttribute(attributes, 'expo_profile_1') && default_specs.push(getAttribute(attributes, 'expo_profile_1'));

  getAttribute(attributes, 'expo_profile_2') && default_specs.push(getAttribute(attributes, 'expo_profile_2'));

  getAttribute(attributes, 'warranty') && warranty_specs.push(getAttribute(attributes, 'warranty'));

  getAttribute(attributes, 'returns') && warranty_specs.push(getAttribute(attributes, 'returns'));

  return {
    general_specs,
    default_specs,
    speed_specs,
    warranty_specs,
  };
};

// Dummy response for Order detail api being used on Order Return
export const order = {
  data: {
    core_customer: {
      orders: {
        total_count: 1,
        items: [
          {
            id: 'MjE=',
            number: '000000021',
            order_date: '2024-06-06 12:50:48',
            status: 'Complete',
            shipments: [
              {
                comments: [],
                id: 'MDAwMDAwMDA1',
                number: '000000005',
                tracking: [],
                items: [
                  {
                    id: 'NQ==',
                    product_name: 'Crucial DDR5 UDIMM-Kits-48GB-DDR5-6000-Classic',
                    product_sku: 'cp16g60c36u5b',
                    quantity_shipped: 1,
                    __typename: 'core_ShipmentItem',
                  },
                  {
                    id: 'Ng==',
                    product_name: 'Crucial DDR6 UDIMM-Single-48GB-DDR6-6600-Awesome',
                    product_sku: 'cp20g60c3abcd',
                    quantity_shipped: 6,
                    __typename: 'core_ShipmentItem',
                  },
                ],
                __typename: 'core_OrderShipment',
              },
            ],
            items: [
              {
                product_name: 'Crucial DDR5 UDIMM-Kits-48GB-DDR5-6000-Classic',
                product_sku: 'cp16g60c36u5b',
                product_url_key: 'cp16g60c36u5b',
                product_sale_price: {
                  value: 50,
                  currency: 'USD',
                  __typename: 'core_Money',
                },
                quantity_ordered: 1,
                quantity_invoiced: 1,
                quantity_shipped: 1,
                quantity_returned: 0,
                eligible_for_return: true,
                __typename: 'core_OrderItem',
              },
              {
                product_name: 'Crucial DDR6 UDIMM-Single-48GB-DDR6-6600-Awesome',
                product_sku: 'cp20g60c3abcd',
                product_url_key: 'cp20g60c3abcd',
                product_sale_price: {
                  value: 80,
                  currency: 'USD',
                  __typename: 'core_Money',
                },
                quantity_ordered: 6,
                quantity_invoiced: 6,
                quantity_shipped: 6,
                quantity_returned: 0,
                eligible_for_return: true,
                __typename: 'core_OrderItem',
              },
            ],
            carrier: 'Flat Rate',
            total: {
              base_grand_total: {
                value: 110,
                currency: 'USD',
                __typename: 'core_Money',
              },
              grand_total: {
                value: 110,
                currency: 'USD',
                __typename: 'core_Money',
              },
              total_tax: {
                value: 0,
                __typename: 'core_Money',
              },
              subtotal: {
                value: 100,
                currency: 'USD',
                __typename: 'core_Money',
              },
              taxes: [],
              total_shipping: {
                value: 10,
                __typename: 'core_Money',
              },
              shipping_handling: {
                amount_including_tax: {
                  value: 10,
                  __typename: 'core_Money',
                },
                amount_excluding_tax: {
                  value: 10,
                  __typename: 'core_Money',
                },
                total_amount: {
                  value: 10,
                  __typename: 'core_Money',
                },
                taxes: [],
                __typename: 'core_ShippingHandling',
              },
              discounts: [],
              __typename: 'core_OrderTotal',
            },
            shipping_address: {
              city: 'California',
              company: 'Micron Company',
              country_code: 'US',
              fax: null,
              firstname: 'Amy B',
              lastname: 'Lewis',
              middlename: null,
              postcode: '90210',
              prefix: null,
              region: 'California',
              region_id: '12',
              street: ['1723 Hickory Heights Drive', 'street 3'],
              suffix: null,
              telephone: '443-933-6501',
              vat_id: null,
              __typename: 'core_OrderAddress',
            },
            billing_address: {
              city: 'COLOMBES',
              company: 'Micron Company',
              country_code: 'US',
              fax: null,
              firstname: 'Amy B',
              lastname: 'Lewis',
              middlename: null,
              postcode: '90210',
              prefix: null,
              region: 'California',
              region_id: '12',
              street: ['1723 Hickory Heights Drive', 'street 3'],
              suffix: null,
              telephone: '443-933-6501',
              vat_id: null,
              __typename: 'core_OrderAddress',
            },
            __typename: 'core_CustomerOrder',
          },
        ],
        __typename: 'core_CustomerOrders',
      },
      __typename: 'core_Customer',
    },
  },
  extensions: {},
};
/* eslint-enable max-len */

