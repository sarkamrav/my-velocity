import React from 'react'; // Function to find the object with name = givn name
export function findObjectByName(array = [], name) {
  return array.find(obj => obj.name === name);
}

export function formatDateString(inputDateStr) {
  // Convert the input date string to a Date object
  const inputDate = new Date(inputDateStr);

  return inputDate.toLocaleDateString('en-GB');
}

export function daysDifference(inputDateStr, noOfDays) {
  // Convert the input date string to a Date object
  const inputDate = new Date(inputDateStr);

  // Get the current date
  const currentDate = new Date();

  // Calculate the difference in time (milliseconds)
  const timeDifference = currentDate - inputDate;

  // Convert the difference in time to days
  const differenceInDays = timeDifference / (1000 * 60 * 60 * 24);

  // Check if the difference in days is greater than or equal to 45
  return differenceInDays >= noOfDays;
}

export function createAttributeString(input) {
  var loginAttributes = document.querySelector('[data-name="Login"]');

  const hyphenated = input.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
  const attributeString = `data-${hyphenated}`;

  const value = loginAttributes?.getAttribute(attributeString);

  return value;
}

// Function to format date as 'YYYY-MM-DDTHH:MM:SSZ'
export function formatDateToISOString(date) {
  const year = date.getUTCFullYear();
  const month = String(date.getUTCMonth() + 1).padStart(2, '0');
  const day = String(date.getUTCDate()).padStart(2, '0');
  const hours = String(date.getUTCHours()).padStart(2, '0');
  const minutes = String(date.getUTCMinutes()).padStart(2, '0');
  const seconds = String(date.getUTCSeconds()).padStart(2, '0');

  return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}Z`;
}

// getting the window width and checking against 640px for tablet size
export function isTablet() {
  if (typeof window.innerWidth != 'undefined') {
    if (window.innerWidth <= 640) {
      return true;
    }
  }
  return false;
}

// Function to find the position of the element
export function findPosition(elem) {
  var currenttop = 0;
  if (elem.offsetParent) {
    do {
      currenttop += elem.offsetTop;
    } while ((elem = elem.offsetParent));
    return [currenttop];
  }
}

// To convert files to base64 format
// Tax exemption API needs this
export const fileToBase64 = file => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = () => {
      const base64String = reader.result.split(',')[1];
      resolve(base64String);
    };

    reader.onerror = error => {
      reject(error);
    };

    reader.readAsDataURL(file);
  });
};

// To covert date to string
// Being used in Order complete component
export const convertDateString = dateString => {
  const date = new Date(dateString);

  const month = String(date.getMonth() + 1).padStart(2, '0'); // Pad month with leading zero
  const day = String(date.getDate()).padStart(2, '0'); // Pad day with leading zero
  const year = date.getFullYear();

  const formattedDate = `${month}/${day}/${year}`;
  return formattedDate;
};

export const generateMessage = () => (
  <>
    <span className="info-message-head">{createAttributeString('infoMessage1')}</span>&nbsp;
    <span className="info-message-body">
      {createAttributeString('infoMessage2')}&nbsp;[{createAttributeString('infoMessage3')}]&nbsp;
      {createAttributeString('infoMessage4')}
    </span>
    &nbsp;
  </>
);

// Format Price as per locale
export const formatLocalePrice = (price, currencySymbol) => {
  if (typeof price === 'number') {
    price = price.toString();
  }
  const localeElement = document.querySelector('[lang]');
  const locale = localeElement ? localeElement.getAttribute('lang') : '';

  if (currencySymbol === undefined) {
    currencySymbol = '';
  }

  if (!locale || !price) {
    return null;
  }

  {
    /* Display symbol on left side for all locales except these three */
  }
  if (locale !== 'fr-fr' && locale !== 'de-de' && locale !== 'es-es') {
    return `${currencySymbol}${Intl.NumberFormat(locale, {
      minimumFractionDigits: 2,
    }).format(price)}`;
  } else {
    return `${Intl.NumberFormat(locale, {
      minimumFractionDigits: 2,
    }).format(price)}${currencySymbol}`;
  }
};

// Function to check if a string is likely a JSON string
// Being used in the Address Fragment component
export const isJsonString = str => {
  if (typeof str !== 'string') {
    return false;
  }
  return (str.startsWith('{') && str.endsWith('}')) || (str.startsWith('[') && str.endsWith(']'));
};

// Function to convert size strings to bytes for easy comparison
export const convertToBytes = (size) => {
  let units = {
    'GB': 1e9,   // 1 Gigabyte = 1e9 bytes
    'TB': 1e12   // 1 Terabyte = 1e12 bytes
};

// Extract the numeric part and the unit
let value = parseFloat(size);
let unit = size.match(/[A-Z]+/i)[0];

// Convert the size to bytes
return value * (units[unit] || 1); // Default to 1 if the unit is not recognized
};
