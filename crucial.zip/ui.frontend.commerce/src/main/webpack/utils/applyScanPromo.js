import { getCatalogServiceHeaders, getUserTokenFromLoaclStorate, readStoredHeader } from "../configs/ReactApolloClientSetup/ApolloClientConfig";
import { getCookie } from "./cookies_operation";

export const applyScanPromoCode = async () => {
    if (getCookie('scanned') && getCookie('scanned') === 'true') {
        const url = "/bin/micron/applypromocode.json";
        const cart_id = getCookie('cart_id') ? JSON.parse(getCookie('cart_id')) : '';
        const headers = JSON.stringify(getCookie('headerDetails'));
        const encryptedCouponCode = getCookie('couponCode') ? getCookie('couponCode') : '';
        const headerDetails = {
            'authorization': getUserTokenFromLoaclStorate() && `Bearer ${getUserTokenFromLoaclStorate()}`,
            'Store': getCatalogServiceHeaders(),
            'magento-customer-group': readStoredHeader('customer_group'),
            'magento-environment-id': readStoredHeader('environment_id'),
            'magento-store-code': readStoredHeader('store_code'),
            'magento-store-view-code': readStoredHeader('store_view_code'),
            'magento-website-code': readStoredHeader('website_code'),
        };
        const payloadData = {
            couponCode: encryptedCouponCode,
            cartId: cart_id,
            headerDetails: JSON.stringify(headerDetails),
        };

        $.ajax({
            type: 'POST',
            url: url,
            data: payloadData,
            success: function success(data) {
                // need to write function to show NDA popup
                console.log('success');
            },
            error: function error(jqXhr, data) {
                console.log("Error occured");
            }
        });

    }

}