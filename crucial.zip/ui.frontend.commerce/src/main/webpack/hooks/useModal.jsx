import { useState } from 'react';

const useModal = () => {
  const [isShowing, setIsShowing] = useState(false);
  const toggle = () => {
    document.body.style.overflowY = '';
    setIsShowing(prevIsShowing => !prevIsShowing);
  };
  return {
    isShowing,
    toggle,
  };
};

export default useModal;
