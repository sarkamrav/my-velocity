import React, { useRef } from 'react';
import PropTypes from 'prop-types';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

const useCustomSlider = (initialSlide = 0) => {
  const sliderRef = useRef(null);

  const handleDotClick = index => {
    if (index > 0 && index < slides.length - 1 && sliderRef.current) {
      sliderRef.current.slickGoTo(index);
    }
  };

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    initialSlide: initialSlide
  };

  return { sliderRef, settings, handleDotClick };
};

export default useCustomSlider;
