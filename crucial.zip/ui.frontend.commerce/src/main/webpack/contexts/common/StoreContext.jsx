import React, { createContext, useContext, useMemo, useReducer } from 'react';
// import PropTypes from 'prop-types';
import plpreducer from './reducers/plpreducer';
import pdpreducer from './reducers/pdpreducer';
import cartreducer from './reducers/cartreducer';
import checkoutreducer from './reducers/checkoutreducer';

const initialState = {};

const StoreContext = createContext(initialState);

// 2. Combine Reducers
const combineReducers = reducers => {
  return (state, action) => {
    return Object.keys(reducers).reduce((acc, key) => {
      acc[key] = reducers[key](state[key], action);
      return acc;
    }, {});
  };
};

const rootReducer = combineReducers({ plp: plpreducer, pdp: pdpreducer, cart: cartreducer, checkout: checkoutreducer });

export const StoreProvider = ({ children }) => {
  const [state, dispatch] = useReducer(rootReducer, initialState);
  const contextValue = useMemo(() => ({ state, dispatch }), [state, dispatch]);

  return <StoreContext.Provider value={contextValue}>{children}</StoreContext.Provider>;
};

export const useStoreContext = () => useContext(StoreContext);

// StoreProvider.propTypes = {
//   children: PropTypes.node.isRequired,
// };
