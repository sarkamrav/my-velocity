import { ACTION } from '../../constant';

export const addFilterData = payload => {
  return {
    type: ACTION.ADD_FILTER_VALUE,
    payload,
  };
};

export const removeFilterData = payload => {
  return {
    type: ACTION.REMOVE_FILTER_VALUE,
    payload,
  };
};

export const fetchProductData = payload => {
  return {
    type: ACTION.FETCH_PRODUCT_LIST,
    payload,
  };
};

export const updateProductData = payload => {
  return {
    type: ACTION.UPDATE_PRODUCT_LIST,
    payload,
  };
};

export const fetchFilterData = payload => {
  return {
    type: ACTION.FETCH_FILTER_LIST,
    payload,
  };
};

export const updateCompareDataList = payload => {
  return {
    type: ACTION.ADD_COMPARE_DATA_LIST,
    payload,
  };
};

export const removeCompareDataList = payload => {
  return {
    type: ACTION.REMOVE_COMPARE_DATA_LIST,
    payload,
  };
};

export const addItemsToCompareList = payload => {
  console.log('payload', payload);
  return {
    type: ACTION.ADD_COMPARE_LIST_ITEM,
    payload,
  };
};
