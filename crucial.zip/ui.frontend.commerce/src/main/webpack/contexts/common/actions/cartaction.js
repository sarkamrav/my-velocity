import {ACTION} from '../../constant';

export const fetchCartData = payload => {
	return {
		type: ACTION.FETCH_CART_DATA,
		payload,
	};
};

export const fetchAddedItem = payload => {
	return {
		type: ACTION.FETCH_ADDED_DATA,
		payload,
	};
};

export const updateCartGrandTotal = payload => {
	return {
	  type: ACTION.UPDATE_CART_GRAND_TOTAL,
	  payload,
	};
  };
  