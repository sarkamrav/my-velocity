import { ACTION } from '../../constant';

export const fetchAddressData = payload => {
  return {
    type: ACTION.FETCH_ADDRESS_DATA,
    payload,
  };
};

export const fetchShippingMethodData = payload => {
  return {
    type: ACTION.FETCH_SHIPPING_METHOD_DATA,
    payload,
  };
};
