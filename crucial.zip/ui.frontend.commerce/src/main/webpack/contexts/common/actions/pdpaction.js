import { ACTION } from '../../constant';

export const fetchProductDetailsData = payload => {
  return {
    type: ACTION.FETCH_PRODUCT_DATA,
    payload,
  };
};

export const fetchProductAddonData = payload => {
  return {
    type: ACTION.FETCH_PRODUCT_ADDON_DATA,
    payload,
  };
};
