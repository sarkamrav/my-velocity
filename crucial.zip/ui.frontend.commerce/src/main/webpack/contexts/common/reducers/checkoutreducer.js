import {ACTION} from '../../constant';

const initialState = {
    addressData: [],
    shippingMethodData: []
};

// reducers
const reducer = (state = initialState, action) => {
    switch (action.type) {
        case ACTION.FETCH_ADDRESS_DATA:
            return {
                ...state,
                addressData: action.payload,
            };
        case ACTION.FETCH_SHIPPING_METHOD_DATA:
            return {
                ...state,
                shippingMethodData: action.payload,
            };
        default:
            return state;
    }
};

export default reducer;
