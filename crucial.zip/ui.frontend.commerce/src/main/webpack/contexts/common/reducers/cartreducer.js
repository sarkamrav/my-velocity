import { ACTION } from '../../constant';

const initialState = {
  cartData: [],
  addedItemsData: [],
};

// reducers
const reducer = (state = initialState, action) => {
  switch (action.type) {
    case ACTION.FETCH_CART_DATA:
      return {
        ...state,
        cartData: action.payload,
      };
    case ACTION.FETCH_ADDED_DATA:
      return {
        ...state,
        addedItemsData: action.payload,
      };
    case ACTION.UPDATE_CART_GRAND_TOTAL:
      return {
        ...state,
        cartData: {
          ...state.cartData,
          core_cart: {
            ...state.cartData?.core_cart,
            prices: {
              ...state.cartData?.core_cart?.prices,
              updated_grand_total: action.payload,
            },
          },
        },
      };
    default:
      return state;
  }
};

export default reducer;
