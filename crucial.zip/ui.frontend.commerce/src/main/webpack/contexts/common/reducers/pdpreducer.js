import { ACTION } from '../../constant';

/**
 * Method to update Compare Product Sku
 * @param {Object} state
 * @param {String} name
 * @returns Updated State Object
 */

const initialState = {
  productDetailData: [],
};

// reducers
const reducer = (state = initialState, action) => {

  switch (action.type) {
    case ACTION.FETCH_PRODUCT_DATA:
      return {
        ...state,
        productDetailData: action.payload,
      };
    case ACTION.FETCH_PRODUCT_ADDON_DATA:
      return {
        ...state,
        productDetailData: {
          ...state.productDetailData,
          products: [{ ...state.productDetailData.products[0], ...action.payload.products[0] }],
          recommendations: action.payload.recommendations,
          core_customAttributeMetadata:action.payload.core_customAttributeMetadata
        },
      };
    default:
      return state;
  }
};

// eslint-disable-next-line import/prefer-default-export
export default reducer;
