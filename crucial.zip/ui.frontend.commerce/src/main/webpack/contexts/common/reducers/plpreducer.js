import { ACTION } from '../../constant';

/**
 * Method to update Compare Product Sku
 * @param {Object} state
 * @param {String} name
 * @returns Updated State Object
 */

const initialState = {
  filterData: [],
  productListData: [],
  activeFilterList: [],
  wishlist: [],
  filterListData: [],
  updateCompareDataList: [],
  compareListItems: {},
};
const addSelecedFilter = (state, payload) => {
  return {
    ...state,
    activeFilterList: [...state.activeFilterList, payload],
  };
};

const removeSelecedFilter = (state, payload) => {
  return {
    ...state,
    activeFilterList: state.activeFilterList.filter(data => data.label !== payload.label),
  };
};

const filterProductItem = (state, payload) => {
  if (payload === 'Price Low to High') {
    return [
      ...state.productListData?.data?.products?.items.sort(
        (a, b) => a.price_range.maximum_price.final_price.value - b.price_range.maximum_price.final_price.value
      ),
    ];
  } else if (payload === 'Price High to Low') {
    return [
      ...state.productListData?.data?.products?.items.sort(
        (a, b) => b.price_range.maximum_price.final_price.value - a.price_range.maximum_price.final_price.value
      ),
    ];
  } else if (payload === 'Customer Rating') {
    return [...state.productListData?.data?.products?.items.sort((a, b) => b.review_count - a.review_count)];
  }
};

const updateProductDataList = (state, payload) => {
  return {
    ...state,
    productListData: {
      ...state.productListData,
      data: {
        ...state.productListData.data,
        products: {
          ...state.productListData.data.products,
          items: filterProductItem(state, payload),
        },
      },
    },
  };
};

const addCompareDataList = (state, payload) => {
  return {
    ...state,
    updateCompareDataList: [...state.updateCompareDataList, payload],
  };
};

const removeCompareDataList = (state, payload) => {
  return {
    ...state,
    updateCompareDataList: state.updateCompareDataList.filter(data => data?.productView?.id !== payload),
  };
};

// reducers
const reducer = (state = initialState, action) => {
  switch (action.type) {
    case ACTION.ADD_FILTER_VALUE:
      return addSelecedFilter(state, action.payload);
    case ACTION.REMOVE_FILTER_VALUE:
      return removeSelecedFilter(state, action.payload);
    case ACTION.FETCH_PRODUCT_LIST:
      return {
        ...state,
        productListData: action.payload,
      };
    case ACTION.UPDATE_PRODUCT_LIST:
      return updateProductDataList(state, action.payload);
    case ACTION.FETCH_FILTER_LIST:
      return {
        ...state,
        filterListData: action.payload,
      };
    case ACTION.ADD_COMPARE_DATA_LIST:
      return addCompareDataList(state, action.payload);

    case ACTION.REMOVE_COMPARE_DATA_LIST:
      return removeCompareDataList(state, action.payload);

    case ACTION.ADD_COMPARE_LIST_ITEM:
      return {
        ...state,
        compareListItems: action.payload,
      };
    default:
      return state;
  }
};

export default reducer;
