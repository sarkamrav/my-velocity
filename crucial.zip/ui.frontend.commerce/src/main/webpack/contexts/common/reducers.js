import { ACTION } from '../constant';

/**
 * Method to update Compare Product Sku
 * @param {Object} state
 * @param {String} name
 * @returns Updated State Object
 */

const addSelecedFilter = (state, payload) => {
  return {
    ...state,
    activeFilterList: [...state.activeFilterList, payload],
  };
};

const removeSelecedFilter = (state, payload) => {
  return {
    ...state,
    activeFilterList: state.activeFilterList.filter(data => data.label !== payload.label),
  };
};

const filterProductItem = (state, payload) => {
  console.log('ppp', payload);
  if (payload === 'Price Low to High') {
    return [
      ...state.productListData?.data?.products?.items.sort(
        (a, b) => a.price_range.maximum_price.final_price.value - b.price_range.maximum_price.final_price.value
      ),
    ];
  } else if (payload === 'Price High to Low') {
    return [
      ...state.productListData?.data?.products?.items.sort(
        (a, b) => b.price_range.maximum_price.final_price.value - a.price_range.maximum_price.final_price.value
      ),
    ];
  } else if (payload === 'Customer Rating') {
    return [...state.productListData?.data?.products?.items.sort((a, b) => b.review_count - a.review_count)];
  }
};

const updateProductDataList = (state, payload) => {
  return {
    ...state,
    productListData: {
      ...state.productListData,
      data: {
        ...state.productListData.data,
        products: {
          ...state.productListData.data.products,
          items: filterProductItem(state, payload),
        },
      },
    },
  };
};

// reducers
const reducer = (state, action) => {
  switch (action.type) {
    case ACTION.ADD_FILTER_VALUE:
      return addSelecedFilter(state, action.payload);
    case ACTION.REMOVE_FILTER_VALUE:
      return removeSelecedFilter(state, action.payload);
    case ACTION.FETCH_PRODUCT_LIST:
      return {
        ...state,
        productListData: action.payload,
      };
    case ACTION.UPDATE_PRODUCT_LIST:
      return updateProductDataList(state, action.payload);
    default:
      return state;
  }
};

// eslint-disable-next-line import/prefer-default-export
export { reducer };
