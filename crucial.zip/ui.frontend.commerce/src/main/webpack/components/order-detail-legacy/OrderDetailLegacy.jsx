import React, { useState, useEffect } from 'react';
import { useQuery } from '@apollo/client';
import OrderInfoLegacy from './components/OrderInfoLegacy/OrderInfoLegacy';
import Button from '../micro-components/Button/Button';
import Link from '../micro-components/Link/Link';
import Icon from '../../assests/Icon';
import { getShoppingUrls } from '../../site/js/urlresolver';
import Loader from '../micro-components/Loader/Loader';
import ORDER_LEGACY_DETAIL from '../../site/js/gql/order-legacy-details.gql';

export default function OrderDetailLegacy({
  displayHeading,
  displayInvoiceLabel,
  displayBackLabel,
  lookupDetail,
  noInfoFound,
  unauthorized,
  ...restProps
}) {
  const params = new URLSearchParams(window.location.search);
  const orderNumber = params.get('order_number');
  const legacyflag = params.get('legacy');
  const [error, setError] = useState('');
  const [orderDetailLegacyList, setOrderDetailLegacyList] = useState([]);
  const user_token = localStorage.getItem('user_token');

  const {
    error: legacyQueryError,
    loading: legacyQueryLoading,
    data: legacyQueryData,
  } = useQuery(ORDER_LEGACY_DETAIL, {
    onCompleted: (data) => {
      if (data) {
        setOrderDetailLegacyList(data.core_drOrders || []);
      }
    },
  });

  useEffect(() => {
    if (orderNumber && legacyflag && orderDetailLegacyList.length > 0) {
      // Filter the orders based on the orderNumber
      const filteredOrders = orderDetailLegacyList.filter(order => order.id === orderNumber);
      console.log('Filtered orders:', filteredOrders);
      setOrderDetailLegacyList(filteredOrders);
    }
  }, [legacyQueryData, orderNumber, legacyflag, orderDetailLegacyList]);

  useEffect(() => {
    if (user_token && orderDetailLegacyList.length === 0 && !legacyQueryLoading) {
      setError(noInfoFound);
    } else if (!user_token && legacyQueryError && orderNumber) {
      setError(legacyQueryError?.message || unauthorized);
    } else if (legacyQueryLoading) {
      setError('');
    } else {
      setError('');
    }
  }, [user_token, legacyQueryError, legacyQueryLoading, orderDetailLegacyList]);

  const showInvoice = false;

  const redirection = () => {
    if (user_token) {
      window.location.href = getShoppingUrls()?.orderHistoryPageURL;
    } else {
      window.location.href = getShoppingUrls()?.orderSearchURL;
    }
  };

  return (
    <section className="cmp-acommerce_order-detail-section">
      {legacyQueryLoading && <Loader />}
      <div className="custom-container">
        <div className="cmp-acommerce_order-detail__main">
          <p className="headinginfo">{displayHeading}</p>
          {orderDetailLegacyList.length > 0 &&
            orderDetailLegacyList.map((order, index) => (
              <OrderInfoLegacy key={index} {...restProps} orderDetail={order} />
            ))}
          {error && <div className="no_order-error">{error || noInfoFound}</div>}

          <div className="cmp-acommerce_order-detail__actions">
            {showInvoice && (
              <Button
                onClick={() =>
                  (window.location.href = `${getShoppingUrls().invoiceURL}?order_number=${new URLSearchParams(
                    window.location.search
                  ).get('order_number')}`)
                }>
                {displayInvoiceLabel}
              </Button>
            )}
          </div>

          <p className="back-link">
            <Icon name="ArrowLeft" />
            <Link text={displayBackLabel} type="back" onClick={redirection} />
          </p>
        </div>
      </div>
    </section>
  );
}

OrderDetailLegacy.defaultProps = {
  displayHeading: 'Order Details',
  displayInvoiceLabel: 'View Invoice',
  displayBackLabel: 'Look Up Your Order',
};
