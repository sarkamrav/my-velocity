import React from 'react';
import PropTypes from 'prop-types';
import './order-info-legacy.scss';
import AddressLegacy from '../../../address-legacy/AddressLegacy';

//Function to parse and format date
const parseDateString = (dateString) => {
  const [day, month, year] = dateString.split('/').map(Number);
  return new Date(year, month - 1, day);
};

const formatDate = (date) => {
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  return `${day}/${month}/${year}`;
};

const formatDateStringLegacy = (dateString) => {
  try {
    const date = parseDateString(dateString);
    return formatDate(date);
  } catch (error) {
    console.error('Error formatting date:', error);
    return dateString; // Return original string if formatting fails
  }
};

const OrderInfoLegacy = ({
  displayOrderNumber,
  displayOrderDate,
  displayOrderStatus,
  displayBillingAddress,
  displayShippingAddress,
  displayQuantity,
  displayProductName,
  orderDetail,
  trackingLink,
  trackShippent,
  quantityShipped,
  displayReturnHeading,
  displayReturnStatus,
  displayQuantityPendingReturn
}) => {
  let itemsList = '';
  let itemListMain = [];
  let itemListShipping = '';
  let itemListBilling = '';

  if (orderDetail) {
    itemsList = orderDetail;
    itemListMain = itemsList?.items;
    itemListShipping = itemsList?.shippingAddress;
    itemListBilling = itemsList?.billingAddress;
  }

  return (
    <div className="cmp-acommerce_order-info">
      <ul className="cmp-acommerce_order-info__list">
        {itemsList?.id && (
          <li>
            <strong>{displayOrderNumber} </strong>
            {itemsList?.id}
          </li>
        )}
        {itemsList?.creation_date && (
          <li>
            <strong>{displayOrderDate} </strong>
            {formatDateStringLegacy(itemsList?.creation_date)}
          </li>
        )}
        {itemsList?.status && (
          <li>
            <strong>{displayOrderStatus} </strong>
            {itemsList?.status}
          </li>
        )}
        <li>
          {itemsList && (
            <div className="cmp-acommerce_order-info__address-group">
              <AddressLegacy title={displayBillingAddress} address={itemsList?.billingAddress} />
              <AddressLegacy title={displayShippingAddress} address={itemsList?.shippingAddress} />
            </div>
          )}
        </li>
      </ul>
      {itemsList && (
        <div className="cmp-acommerce_order-info__product-table">
          <div className="cmp-acommerce_order-info__product-table__head">
            <div className="product-quantity">
              <strong>{displayQuantity}</strong>
            </div>
            <div className="product-name">
              <strong>{displayProductName}</strong>
            </div>
          </div>
          <div className="cmp-acommerce_order-info__product-table__body">
            {itemListMain?.map((product, index) => (
              <div className="product-row" key={`${product.id}-${index}`}>
                <div className="product-quantity">
                  <div className="product-quantity-label lg-hidden">{displayQuantity}</div>
                  <div className="product-quantity-value">{product.qty}</div>
                </div>
                <div className="product-name">
                  <div className="product-name-label lg-hidden">{displayProductName}</div>
                  <div className="product-name-value">
                    <span className="product-title">{product.name}</span>
                    <ul className="product-list">
                      <li>{product.sku}</li>
                      <li>
                        <span>{trackShippent}: </span>
                        <span className="track-shippment-url" onClick={() => window.open(product.tracking_information.tracking_link, '_blank')}>
                          {trackingLink}
                        </span>
                      </li>
                      <li>
                        <span>{quantityShipped}: </span>
                        <span>{product.qty}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

OrderInfoLegacy.propTypes = {
  displayOrderNumber: PropTypes.string,
  displayOrderDate: PropTypes.string,
  displayOrderStatus: PropTypes.string,
  displayBillingAddress: PropTypes.string,
  displayShippingAddress: PropTypes.string,
  displayQuantity: PropTypes.string,
  displayProductName: PropTypes.string,
  trackingLink: PropTypes.string,
  trackShippent: PropTypes.string,
  quantityShipped: PropTypes.string,
  displayReturnHeading: PropTypes.string,
  displayReturnStatus: PropTypes.string,
  displayQuantityPendingReturn: PropTypes.string
};

OrderInfoLegacy.defaultProps = {
  displayOrderNumber: 'Order Number:',
  displayOrderDate: 'Order Date:',
  displayOrderStatus: 'Order Status:',
  displayBillingAddress: 'Billing Address',
  displayShippingAddress: 'Shipping Address',
  displayQuantity: 'Qty',
  displayProductName: 'Product Name',
  trackingLink: 'Track Shipment',
  trackShippent: 'Tracking Number',
  quantityShipped: 'Quantity Shipped',
  displayReturnHeading: 'Return request',
  displayReturnStatus: 'Status',
  displayQuantityPendingReturn:'Quantity pending return'
};

export default OrderInfoLegacy;
