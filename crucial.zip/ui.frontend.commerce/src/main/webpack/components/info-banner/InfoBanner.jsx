import React from 'react';
import Icon from '../../assests/Icon';
import { createAttributeString } from '../../utils/utils';
function InfoBanner({ message, className, url }) {
  function linkHandler() {
    window.open(url, '_blank');
  }

  return (
    <div className={`banner ${className}`}>
      <p className="banner-info">
        <Icon name="UserCartIcon" />
        <span className="info-message">{message}</span>
        <span className="info-message-foot" onClick={linkHandler}>
          {createAttributeString('infoMessage5')}
        </span>
      </p>
    </div>
  );
}

export default InfoBanner;
