import React from "react";
import { createRoot } from "react-dom/client";
import { StoreProvider } from '../../contexts/common/StoreContext.jsx';
import { ApolloClient, ApolloProvider } from '@apollo/client';
import ApolloClientConfig from '../../configs/ReactApolloClientSetup/ApolloClientConfig.js';
import HeadersForCatalogServices from '../headers-for-catalog-services/HeadersForCatalogServices.jsx';

export default class {
  static init(el) {
    const client = new ApolloClient(ApolloClientConfig);
    let props = JSON.parse(JSON.stringify(el.dataset));
    createRoot(el).render(
        <StoreProvider>
          <ApolloProvider client={client}>
            <HeadersForCatalogServices {...props} />
          </ApolloProvider>
        </StoreProvider>
    );
  }
}