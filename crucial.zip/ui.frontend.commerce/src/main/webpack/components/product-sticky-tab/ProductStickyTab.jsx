import React, { useEffect, useMemo } from 'react';

import { useStoreContext } from '../../contexts/common/StoreContext';

import StickyTab from './components/stickytab/StickyTab';

// Working SKUs
// Crucial DDR5 UDIMM-Kits-48GB-DDR5-6000-Classic
// crucial-t500-pcie-gen4-nvme-m.2-ssd-2TB-Non-Heatsink
// ct500t500ssd8  -- this one has oid

const ProductStickyTab = ({ name, ...props }) => {
  const { state, dispatch } = useStoreContext();
  const productUrl = new URL(window.location.href);
  const urlArray = productUrl.pathname.split('/');
  const sku = urlArray[urlArray.length - 1];
  const subCategory = urlArray[urlArray.length - 2];

  return (
    <>
      <div className="product-detail-wrapper">
        <div
          className="product-specs-resources"
          data-pagepath={props.pagePath}
          data-sku={sku}
          data-subcategory={subCategory}></div>
        {state?.pdp && (
          <>
            <StickyTab name={name} {...props} />
          </>
        )}
      </div>
    </>
  );
};

export default ProductStickyTab;
