import ProductStickyTab from "../product-sticky-tab.hbs";

export default {
  title: "Components/React Component/Product-Sticky-Tab",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { ProductStickyTab };
