import React, { useState, useEffect } from 'react';
import Price from '../price/Price';
import Overview from '../overview/Overview.jsx';
import AddToCartModal from '../../../product-information/components/add-to-cart-modal/AddToCartModal';
import ModalPopup from '../../../modal-popup/ModalPopup.jsx';
import SupersizePromoModal from '../../../product-information/components/supersize-promo-modal/SupersizePromoModal.jsx';
import { useStoreContext } from '../../../../contexts/common/StoreContext';
import { createSpecsJSON, getAttributeValue, priceType } from '../../../../utils/common';
import Accordion from '../Accordion/Accordion.jsx';
import ProductReview from '../product-review/ProductReview.jsx';
import { ADD_PRODUCTS_TO_CART, CREATE_EMPTY_CART } from '../../../../site/js/gql/mutations/cart.gql.js';
import { getCookie, setCookie } from '../../../../utils/cookies_operation.js';
import useModal from '../../../../hooks/useModal.jsx';
import { useMutation } from '@apollo/client';
import { findObjectByName } from '../../../../utils/utils';
import { hideSignInDiv } from '../../../../site/js/noncommerce-login.js';
import { applyScanPromoCode } from '../../../../utils/applyScanPromo.js';

const supportedLocales = [
  { key: 'en-us', value: 'en_us' },
  { key: 'en-gb', value: 'en_gb' },
  { key: 'fr-fr', value: 'fr' },
  { key: 'en', value: 'eu' },
];

const isLocaleSupported = locale => {
  return supportedLocales.some(loc => loc.value === locale);
};

export default function StickyTab() {
  // State hooks
  const [isSticky, setIsSticky] = useState(false);
  const [activeLink, setActiveLink] = useState('');
  const [cart] = useState(1);
  const { state } = useStoreContext();
  const { isShowing: isConfirmationShowing, toggle: toggleConfirmation } = useModal();
  const [productSpecs, setProductSpecs] = useState({
    general_specs: [],
    speed_specs: [],
    default_specs: [],
    warranty_specs: [],
  });
  const [overviewUrl, setOverviewUrl] = useState('');
  const [awardsUrl, setAwardsUrl] = useState('');
  const [categoryUrl, setCategoryUrl] = useState('');
  const [buyingOptionUrl, setBuyingOptionUrl] = useState('');
  const [isLocaleValid, setIsLocaleValid] = useState(false);
  const [hideNonCommerceLocale, setHideNonCommerceLocale] = useState(false);
  const { isShowing: isPromoShowing, toggle: togglePromoConfirmation } = useModal();  
  const [supersizedVariant, setSupersizedVariant] = useState([]);
  //non commerce locale hide
  useEffect(() => {
    setHideNonCommerceLocale(hideSignInDiv);
  }, []);

  // Buying option Url
  useEffect(() => {
    const productBrandName = findObjectByName(attributes, 'technology') || { value: 'technology' };

    if (productBrandName?.value) {
      const urlPathSegments = location.pathname.split('/');
      const catalogIndex = urlPathSegments.indexOf('catalog');
      if (catalogIndex !== -1) {
        const lowercaseBrandName = productBrandName.value.toLowerCase();
        setPdpUrl(`/${urlPathSegments[catalogIndex + 1]}/${lowercaseBrandName}/${sku}`);
        setBuyingOptionUrl(`/buying-options/${urlPathSegments[catalogIndex + 1]}/${lowercaseBrandName}/${sku}`);
      }
    }
  }, [attributes, location.pathname, sku]);

  // Handle link click to smooth scroll to section
  const handleLinkClick = (e, id) => {
    e.preventDefault();
    setActiveLink(id);
    window.scrollTo({
      top: document.querySelector(`#${id}`).offsetTop - document.querySelector('#sticky-section').clientHeight,
      behavior: 'smooth',
    });
  };

  // Handle view cart button click
  const handleViewCart = () => {
    console.log('View Cart is clicked');
  };

  // Extract product details from state
  const productDetailData = state?.pdp?.productDetailData?.products[0];
  const { name, sku, price, attributes = [], images, metaKeyword, url, inStock, description } = productDetailData || {};
  const variants = productDetailData?.options_details?.variants;
  const addToCartElement = document?.querySelector('.addCart');
  const getFinalPrice = () => {
    let finalPrice = 0;
    const supersizePromoCookie =
      (getCookie('supersize_price_set') && JSON.parse(getCookie('supersize_price_set'))) || [];
    const isSupersizePriceAvaliable = supersizePromoCookie.find(item => item.sku === sku && item.isSupersizePriceSet);
    if (isSupersizePriceAvaliable) {
      const supersizedPrice = attributes?.find(item => item.name === 'supersize_price' && item.value);
      finalPrice = supersizedPrice?.value
        ? parseFloat(supersizedPrice.value) < price?.final?.amount?.value
          ? parseFloat(supersizedPrice.value)
          : price?.final?.amount?.value
        : price?.final?.amount?.value;
    } else {
      finalPrice = price?.final?.amount?.value;
    }
    return finalPrice && finalPrice?.toFixed(2);
  };
  const finalPrice = getFinalPrice();
  const regularPrice = price?.regular?.amount?.value;
  // const brand = `${getAttributeValue(attributes, 'brand')}${
  //   getAttributeValue(attributes, 'series') ? ' ' + getAttributeValue(attributes, 'series') : ''
  // }`;
  const [cartData, setCardData] = useState({
    productImage: images[0]?.url,
    productName: name,
    currency: price?.final?.amount?.currency,
    finalPrice: getFinalPrice(),
    regularPrice: price?.regular?.amount?.value?.toFixed(2),
    isSupersizePriceSet: false,
  });
  const brand = getAttributeValue(attributes, 'brand');

  // i18n translation variable
  const element = document.querySelector('[data-name="ProductInformation"]');

  // Define accordion items
  const accordionItems = [
    ...(attributes && getAttributeValue(attributes, 'install_url') !== undefined
      ? [
        {
          id: 'install',
          header: element && element.getAttribute('data-installheading'),
          content:
            '/content/' +
            getAttributeValue(attributes, 'install_url')
              .split('/content/')[1]
              .replace(/(\.html?)?$/, '.component-lite.html'),
        },
      ]
      : []),
    ...(attributes && getAttributeValue(attributes, 'warranty_url') !== undefined
      ? [
        {
          id: 'warranty',
          header: element && element.getAttribute('data-warrantyheading'),
          content:
            '/content/' +
            getAttributeValue(attributes, 'warranty_url')
              .split('/content/')[1]
              .replace(/(\.html?)?$/, '.component-lite.html'),
        },
      ]
      : []),
    {
      id: 'rohs',
      header: element && element.getAttribute('data-rohsheading'),
      content: element && element.getAttribute('data-dramrohspagepath') + '.component-lite.html',
    },
    {
      id: 'reach',
      header: element && element.getAttribute('data-reachheading'),
      content: element && element.getAttribute('data-dramreachpagepath') + '.component-lite.html',
    },
  ];

  // Define tab links conditionally
  const tabLinks = [
    ...(overviewUrl !== '' ? ['overview'] : []),
    ...(productSpecs.general_specs.length > 0 ||
      productSpecs.speed_specs.length > 0 ||
      productSpecs.default_specs.length > 0 ||
      productSpecs.warranty_specs.length > 0
      ? ['specifications']
      : []),
    'product-resources',
    ...(awardsUrl !== '' ? ['awards'] : []),
    ...(isLocaleValid ? ['reviewPanel'] : []),
  ];

  // Supersize promo modal will be shown to user if product is ssd and higher variant has supersized price
  const showSupersizePromoModal = () => {
    const pageUrl = window.location.pathname;
    if (pageUrl && pageUrl.toUpperCase().indexOf('SSD') > -1 && !isPromoShowing) {
      let currentProductVariantSort = variants?.find(
        item => item.product?.sku === addToCartElement.getAttribute('data-sku')
      );
      currentProductVariantSort = currentProductVariantSort?.attributes?.find(item => item.code === 'variants_sort');
      currentProductVariantSort = currentProductVariantSort?.label;
      const supersizedVariants = variants?.filter(element => {
        const supersizeVariantPrice = element?.product?.supersize_price;
        let supersizeProductVariantSort = element?.attributes?.find(item => item.code === 'variants_sort');
        supersizeProductVariantSort = supersizeProductVariantSort?.label;
        return supersizeProductVariantSort > currentProductVariantSort && supersizeVariantPrice !== null;
      });
      if (supersizedVariants && supersizedVariants.length > 0) {
        supersizedVariants.length > 1 &&
          supersizedVariants.sort((a, b) => {
            const first_ele_variant_sort = a?.attributes?.find(item => item.code === 'variants_sort')?.label;
            const second_ele_variant_sort = b?.attributes?.find(item => item.code === 'variants_sort')?.label;
            return first_ele_variant_sort < second_ele_variant_sort ? 1 : -1;
          });
        setSupersizedVariant(supersizedVariants[0]);
        return true;
      }
    }
    return false;
  };
  

  const getPriceType = () => {
    return getFinalPrice() < regularPrice ? "special" : "regular"
  }

  // Set category URL on component mount
  useEffect(() => {
    const urlSegments = new URL(window.location.href).pathname.split('/');
    setCategoryUrl(urlSegments.slice(1, 2).join('/'));
  }, []);

  // Review data for product review component
  const reviewData = {
    name,
    url,
    image_url: images[0]?.url,
    description: metaKeyword,
    category_name: categoryUrl,
    manufacturer_id: sku,
    brand_name: brand,
    price: price?.final?.amount?.value,
  };

  // Add to cart functionality
  const cartKey = 'cart_id';

  // Handle add to cart action
  const handleAddCart = () => {
    if (showSupersizePromoModal()) {
      togglePromoConfirmation();
    } else {
      const addToCartElement = document?.querySelector('.addCart');
      //This is for add to cart analytics
      if (window.digitalData) {
        digitalData.cart = digitalData.cart || {};
        digitalData.cart.addtocart = digitalData.cart.addtocart || [];
        digitalData.cart.oderOffer = '';
        let prodInfoObject = {
          skuToAdd: addToCartElement.getAttribute('data-sku'),
          qtyNumber: Math.floor(addToCartElement.getAttribute('data-qty')),
          prodCategory: window.location.pathname.split('/')[1],
          prodSubCategory: window.location.pathname.split('/')[2],
          prodTitle: name,
          pagePath: window.location.pathname,
          prodPrice: regularPrice,
          offerPrice: finalPrice,
          currency: price?.final?.amount?.currency,
          prodImage: images[0]?.url,
          cartID: JSON.parse(getCookie('cart_id')),
          loggedIn: localStorage.getItem('user_token') ? true : false,
          configToAdd: undefined,
          modOut: undefined,
          productOfferId: undefined,
          rfgpn: undefined,
        };
        digitalData.cart.addtocart.push({ productInfo: prodInfoObject });
        digitalData.cart.cartId = JSON.parse(getCookie('cart_id'));
        if (typeof _satellite !== 'undefined' && _satellite.track) {
          // Fire the Add to Cart Event
          _satellite.track('add_to_cart');
        }
      }

      const supersizePromoCookie =
        (getCookie('supersize_price_set') && JSON.parse(getCookie('supersize_price_set'))) || [];
      const isSupersizePriceAvaliable = supersizePromoCookie.find(
        item => item.sku === addToCartElement.getAttribute('data-sku') && item.isSupersizePriceSet
      );
      addProductToCart({
        variables: {
          cartId: JSON.parse(getCookie('cart_id')),
          SKU: addToCartElement.getAttribute('data-sku'),
          supersizePrice: isSupersizePriceAvaliable ? true : false,
          quantity: Math.floor(addToCartElement.getAttribute('data-qty')),
        },
      });
    }
  };

  const handleAddPromoToCart = supersizeObj => {
    const addToCartElement = document?.querySelector('.addCart');
    //This is for add to cart analytics
    if (window.digitalData) {
      digitalData.cart = digitalData.cart || {};
      digitalData.cart.addtocart = digitalData.cart.addtocart || [];
      digitalData.cart.oderOffer = '';
      let prodInfoObject = {
        skuToAdd: supersizedVariant?.product?.sku,
        qtyNumber: Math.floor(addToCartElement.getAttribute('data-qty')),
        prodCategory: window.location.pathname.split('/')[1],
        prodSubCategory: window.location.pathname.split('/')[2],
        prodTitle: supersizeObj.productName,
        pagePath: window.location.pathname,
        prodPrice: supersizeObj.regularPrice,
        offerPrice: supersizeObj.finalPrice,
        currency: supersizeObj.currency,
        prodImage: supersizeObj.productImage,
        cartID: JSON.parse(getCookie('cart_id')),
        loggedIn: localStorage.getItem('user_token') ? true : false,
        configToAdd: undefined,
        modOut: undefined,
        productOfferId: undefined,
        rfgpn: undefined,
      };
      digitalData.cart.addtocart.push({ productInfo: prodInfoObject });
      digitalData.cart.cartId = JSON.parse(getCookie('cart_id'));
      if (typeof _satellite !== 'undefined' && _satellite.track) {
        // Fire the Add to Cart Event
        _satellite.track('add_to_cart');
      }
    }
    addProductToCart({
      variables: {
        cartId: JSON.parse(getCookie('cart_id')),
        SKU: supersizedVariant?.product?.sku,
        supersizePrice: true,
        quantity: Math.floor(addToCartElement.getAttribute('data-qty')),
      },
    });
  };

  const [addProductToCart, { data: addToCartData, loading: addToCartLoading, error: addToCartError }] = useMutation(
    ADD_PRODUCTS_TO_CART,
    {
      onCompleted(data) {
        if (data.core_addProductsToCart.user_errors.length <= 0) {
          toggleConfirmation();
          let currentSKU = {};
          if (isPromoShowing) {
            togglePromoConfirmation();
            currentSKU = supersizedVariant?.product?.sku;
            let promoObj = {
              sku: currentSKU,
              isSupersizePriceSet: true,
            };
            let supersizePromoCookieData =
              (getCookie('supersize_price_set') && JSON.parse(getCookie('supersize_price_set'))) || [];
            let existingSku = supersizePromoCookieData.find(item => item.sku === currentSKU);
            if (!existingSku) {
              supersizePromoCookieData.push(promoObj);
            }
            setCookie('supersize_price_set', JSON.stringify(supersizePromoCookieData));
          } else {
            currentSKU = document?.querySelector('.addCart').getAttribute('data-sku');
          }

          //Update miniCart quantity.
          const addToCartElement = document?.querySelector('.addCart');
          if (document.querySelector('.cmp-acommerce_cart-qty')) {
            document.querySelector('.cmp-acommerce_cart-qty').innerText =
              Math.floor(document.querySelector('.cmp-acommerce_cart-qty').innerText) +
              Math.floor(addToCartElement.getAttribute('data-qty'));
          }

          // Add product url and sku to the cookie to read on shopping cart and verify order pages
          const skuPath = `/${window.location.pathname.split('/')[1]}/${
            window.location.pathname.split('/')[2]
          }/${currentSKU}`;
          let productUrlObj = {
            sku: currentSKU,
            url: skuPath,
          };
          let productCookieData = (getCookie('cart_product_urls') && JSON.parse(getCookie('cart_product_urls'))) || [];
          let existingProduct = productCookieData.find(item => item.sku === currentSKU);
          if (existingProduct) {
            existingProduct.url = skuPath;
          } else {
            productCookieData.push(productUrlObj);
          }
          setCookie('cart_product_urls', JSON.stringify(productCookieData));
          applyScanPromoCode();
        }
      },
    }
  );

  const [createEmptyCart] = useMutation(CREATE_EMPTY_CART, {
    onCompleted(data) {
      setCookie('cart_id', JSON.stringify(data.core_createEmptyCart), 2880);
    },
  });

  if (addToCartError) {
    console.error(addToCartError);
    document.cookie = 'cart_id=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
    createEmptyCart();
  }

  // Populate specifications and awards URL on component mount
  useEffect(() => {
    const specifications = createSpecsJSON(attributes);
    let awards_url = attributes && getAttributeValue(attributes, 'awards_url');
    setProductSpecs(prev => ({
      ...prev,
      ...specifications,
    }));
    if (awards_url !== undefined) {
      awards_url = '/content/' + awards_url.split('/content/')[1].replace(/(\.html?)?$/, '.component-lite.html');
      setAwardsUrl(awards_url);
    }
    let overviewLink = new URL(description)?.pathname?.replace(/(\.html?)?$/, '.component-lite.html');
    setOverviewUrl(overviewLink);
  }, []);

  let locale = document
    .querySelector('[data-name="ProductInformation"]')
    ?.getAttribute('data-locale')
    ?.toLocaleLowerCase();

  useEffect(() => {
    if (locale) {
      setIsLocaleValid(isLocaleSupported(locale));
    }
  }, [locale]);

  const handleAddToCartModalClose = () => {
    toggleConfirmation();
    // On cart modal close check if super size promo price cookie(supersize_price_set) for the selected sku
    // If supersized promo price is set then redirect to selected sku
    if (cartData.isSupersizePriceSet) {
      const supersizePromoCookie =
        (getCookie('supersize_price_set') && JSON.parse(getCookie('supersize_price_set'))) || [];
      const isSupersizePriceAvaliable = supersizePromoCookie.find(
        item => item.sku === supersizedVariant?.product?.sku && item.isSupersizePriceSet
      );
      if (isSupersizePriceAvaliable) {
        let skuURL = (getCookie('cart_product_urls') && JSON.parse(getCookie('cart_product_urls'))) || [];
        skuURL = skuURL.find(item => item.sku === isSupersizePriceAvaliable.sku);
        if (skuURL?.url) {
          window.location.href = skuURL.url;
        }
      }
    }
  };

  return (
    <>
      <div className={`sticky-container`} id="sticky-section">
        <div className={`sticky-product-tab`}>
          <div className="container-wrapper container">
            <div className="div-wrapper-75">
              <div className="title-prefix">{brand && brand}</div>
              <div className="product-sticky-title ">{name}</div>
              <div className="link-list">
                <ul className="menu simple">
                  <li className="product-number">
                    <span className="part-number base-part-number">{sku}</span>
                  </li>
                </ul>
              </div>
              <div className="product-sticky-links show-for-large">
                {tabLinks.map((link, index) => (
                  <a
                    key={index}
                    // href={`#${link}`}
                    className={activeLink === link ? 'active' : ''}
                    onClick={e => handleLinkClick(e, link)}>
                    {link === 'product-resources'
                      ? element && element.getAttribute('data-prodresourcesheading')
                      : link === 'reviewPanel'
                        ? element && element.getAttribute('data-pdp-review')
                        : link}
                  </a>
                ))}
              </div>
            </div>
            <div className="div-wrapper-25">
              {!hideNonCommerceLocale && <Price priceType={getPriceType()} specialPrice={getFinalPrice()} regularPrice={regularPrice} />}
              <div className="product-actions">
                {!hideNonCommerceLocale && (
                  <>
                    {inStock && (
                      <a
                        className="addCart cmp-acommerce_button button-primary"
                        data-sku={sku}
                        data-qty={cart}
                        onClick={handleAddCart}>
                        {element && element.getAttribute('data-pdp-addtocart')}
                      </a>
                    )}
                    {!inStock && (
                      <a
                        className="addCart cmp-acommerce_button button-primary"
                        data-sku={sku}
                        data-qty={cart}
                        href={buyingOptionUrl}>
                        {element && element.getAttribute('data-pdp-buying-options')}
                      </a>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {overviewUrl !== '' && (
        <section className={`overview`} id="overview">
          <Overview path={overviewUrl} />
        </section>
      )}

      {(productSpecs.general_specs.length > 0 ||
        productSpecs.speed_specs.length > 0 ||
        productSpecs.default_specs.length > 0 ||
        productSpecs.warranty_specs.length > 0) && (
          <section className="specification" id="specifications">
            <div className="section-inner container">
              <h3>{element && element.getAttribute('data-pdp-specification')}</h3>
              <div className="row-wrapper table">
                <div className="col-wrapper-6">
                  {productSpecs?.general_specs.length > 0 && (
                    <table className="spec-table">
                      <thead>
                        <tr>
                          <th colSpan="2">{element && element.getAttribute('data-general-tech-specs')}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {productSpecs?.general_specs.map(spec => (
                          <tr key={spec?.name}>
                            <td>{spec?.label}</td>
                            <td className="spec-value">{spec?.value}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
                <div className="col-wrapper-6">
                  {productSpecs?.default_specs.length > 0 && (
                    <table className="spec-table">
                      <thead>
                        <tr>
                          <th colSpan="2">{element && element.getAttribute('data-default-performance-profiles')}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {productSpecs?.default_specs.map(spec => (
                          <tr key={spec?.name}>
                            <td>{spec?.label}</td>
                            <td className="spec-value">{spec?.value}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}

                  {productSpecs?.speed_specs.length > 0 && (
                    <table className="spec-table">
                      <thead>
                        <tr>
                          <th colSpan="2">{element && element.getAttribute('data-speed-timing')}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {productSpecs?.speed_specs.map(spec => (
                          <tr key={spec?.name}>
                            <td>{spec?.label}</td>
                            <td className="spec-value">{spec?.value}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}

                  {productSpecs?.warranty_specs.length > 0 && (
                    <table className="spec-table">
                      <thead>
                        <tr>
                          <th colSpan="2">{element && element.getAttribute('data-warranty-returns')}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {productSpecs?.warranty_specs.map(spec => (
                          <tr key={spec?.name}>
                            <td>{spec?.label}</td>
                            <td className="spec-value">{spec?.value}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              </div>
            </div>
          </section>
        )}

      <section className="product-resource" id="product-resources">
        <div className="section-inner container">
          <h3>{element && element.getAttribute('data-prodresourcesheading')}</h3>
          <Accordion items={accordionItems} />
        </div>
      </section>

      {awardsUrl !== '' && (
        <section className="awards" id="awards">
          <div className="section-inner container">
            <h3>{element && element.getAttribute('data-pdp-awards')}</h3>
            <Overview path={awardsUrl} />
          </div>
        </section>
      )}

      {isLocaleValid && (
        <section className="review-panel" id="reviewPanel">
          <div className="section-inner container">
            <h3>{element && element.getAttribute('data-pdp-review')}</h3>
            <ProductReview reviewData={reviewData} oid={getAttributeValue(attributes, 'oid') || ''} />
          </div>
        </section>
      )}

      {isConfirmationShowing && (
        <ModalPopup isShowing={isConfirmationShowing} hide={handleAddToCartModalClose}>
          <AddToCartModal
            productImage={cartData.productImage}
            productName={cartData.productName}
            currency={cartData.currency}
            finalPrice={cartData.finalPrice}
            regularPrice={cartData.regularPrice}
            viewCart={handleViewCart}
            continueShopping={handleAddToCartModalClose}
            cartQty={cart}
          />
        </ModalPopup>
      )}

      {isPromoShowing && (
        <ModalPopup className="auth-popup" isShowing={isPromoShowing} hide={togglePromoConfirmation}>
          <SupersizePromoModal
            supersizedVariant={supersizedVariant}
            handleAddCart={handleAddCart}
            handleAddPromoToCart={handleAddPromoToCart}
            cartQty={Math.floor(addToCartElement.getAttribute('data-qty'))}
            selectedSku={addToCartElement.getAttribute('data-sku')}
            variants={variants}
            setCardData={setCardData}></SupersizePromoModal>
        </ModalPopup>
      )}
    </>
  );
}
