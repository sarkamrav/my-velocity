import React from 'react';
import PropTypes from 'prop-types';
import { getCookie } from '../../../../utils/cookies_operation.js';
import { formatLocalePrice } from '../../../../utils/utils.js';
import { getCatalogServiceHeaders } from '../../../../configs/ReactApolloClientSetup/ApolloClientConfig.js';
// priceType can be 'regular' or 'special'
export default function Price({ priceType, specialPrice, regularPrice, className, ...rest }) {
  const currencySymbol = JSON.parse(getCookie('currency'))?.currencySymbol;
  const locale = getCatalogServiceHeaders();

  // i18n translation variable
  const element = document.querySelector('[data-name="ProductInformation"]');
  return (
    <>
      <div className={`product-pricing price-type__${priceType} ${className}`} {...rest}>
        <span className="special-price price">
          {formatLocalePrice(specialPrice, currencySymbol)}{' '}
          {locale !== 'en_us' && <span className="vat_text">{element && element.getAttribute('data-inc-vat')}</span>}
        </span>
        <span className="regular-price price">
          {formatLocalePrice(regularPrice, currencySymbol)}{' '}
          {locale !== 'en_us' && <span className="vat_text">{element && element.getAttribute('data-inc-vat')}</span>}
        </span>
      </div>
    </>
  );
}
Price.propTypes = {
  specialPrice: PropTypes.number,
  regularPrice: PropTypes.number.isRequired,
  priceType: PropTypes.string.isRequired,
  className: PropTypes.string,
};

Price.defaultProps = {
  specialPrice: '',
  className: '',
};
