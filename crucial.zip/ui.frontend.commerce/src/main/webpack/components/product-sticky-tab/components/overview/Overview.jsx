import React, { useState, useEffect } from "react";

export default function Overview({ path }) {
  const [htmlContent, setHtmlContent] = useState('');

  useEffect(() => {
      fetch(path)
        .then(response => {
          if (!response.ok) {
            console.error(`Error fetching HTML: ${response.statusText} (status: ${response.status})`);
            throw new Error(`Error fetching HTML: ${response.statusText} (status: ${response.status})`);
          }
          return response.text();
        })
        .then(data => setHtmlContent(data))
        .catch(error => console.error('Error fetching HTML:', error));
    }, [path]);

  useEffect(() => {
      const imgs = document.querySelectorAll('img[data-interchange]');
      const screenWidth = window.innerWidth;

      imgs.forEach(img => {
          const objArray = parseImageData(img.getAttribute('data-interchange'));
          img.src = getImageUrlBasedOnScreen(objArray, screenWidth);
      });
  }, [htmlContent]);

  function parseImageData(input) {
      return input.trim().slice(1, -1).split('], [')
          .map(entry => {
              const [url, size] = entry.replace(/^\[|\]$/g, '').split(',').map(item => item.trim());
              return { url, size: size.replace(']', '')
          };
      });
  }

  function getImageUrlBasedOnScreen(objArray, screenWidth) {
       let fallbackUrl = objArray[objArray.length - 1].url;
       for (const { url, size } of objArray) {
            if (size === 'small' && screenWidth < 768) {return url;}
            if (size === 'medium' && screenWidth >= 768 && screenWidth < 1024) {return url;}
            if (size === 'large' && screenWidth >= 1024) {return url;}
       }
       return fallbackUrl;
  }

  return (
    <>
      <div dangerouslySetInnerHTML={{ __html: htmlContent }} />
    </>
  );
}
