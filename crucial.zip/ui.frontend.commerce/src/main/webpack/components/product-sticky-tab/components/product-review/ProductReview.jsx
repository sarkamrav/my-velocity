import React, { useEffect } from 'react';

const ProductReview = ({ reviewData, oid }) => {
  useEffect(() => {
    const script = document.createElement('script');
    script.src = '//ui.powerreviews.com/stable/4.0/ui.js';
    script.async = true;
    const root = document.querySelector('.cmp_catalog_product_detail_Page');
    let api_key = '';
    let locale = 'en_US';
    let merchant_group_id = '';
    let merchant_id = '';
    let page_id = '';
    let structured_data_product_id = '';
    let review_wrapper_url = '';
    if (root) {
      api_key = root.getAttribute('data-power-review-key');
      locale = root.getAttribute('data-locale');
      merchant_group_id = root.getAttribute('data-merchant-group-id');
      merchant_id = root.getAttribute('data-merchant-id');
      page_id = oid;
      structured_data_product_id = oid;
      review_wrapper_url = `/write-review?oid=${oid}`;
    }

    script.onload = () => {
      // PowerReviews initialization code
      window.POWERREVIEWS.display.render({
        api_key: api_key,
        locale: locale,
        merchant_group_id: merchant_group_id,
        merchant_id: merchant_id,
        page_id: page_id,
        structured_data_product_id: structured_data_product_id,
        review_wrapper_url: review_wrapper_url,
        on_change: function (config, data) {
          if (config.component === 'ReviewList') {
            if (data.review_count > 0 && data.reviews.length > 0 && data.average_rating) {
              const aggregateRating = {
                '@context': 'http://schema.org/',
                '@type': 'AggregateRating',
                ratingValue: data.average_rating,
                reviewCount: data.review_count,
              };

              const scriptTagObject = JSON.parse(document.getElementById('productschema').innerHTML);
              scriptTagObject['aggregateRating'] = aggregateRating;
              document.getElementById('productschema').innerHTML = JSON.stringify(scriptTagObject);

              const reviews = data.reviews.map(pwrReview => ({
                '@type': 'Review',
                reviewRating: {
                  '@type': 'Rating',
                  ratingValue: pwrReview.metrics.rating,
                },
                author: {
                  '@type': 'Person',
                  name: pwrReview.details.nickname,
                },
              }));

              scriptTagObject['review'] = reviews;
              document.getElementById('productschema').innerHTML = JSON.stringify(scriptTagObject);
            }

            if (data.reviews.length === 0) {
              const scriptTagObject = JSON.parse(document.getElementById('productschema').innerHTML);
              delete scriptTagObject['review'];
              document.getElementById('productschema').innerHTML = JSON.stringify(scriptTagObject);
            }
          }
        },
        product: {
          name: reviewData.name,
          url: reviewData.url,
          image_url: reviewData.image_url,
          description: reviewData.shortDescription,
          category_name: reviewData.category_name,
          manufacturer_id: reviewData.manufacturer_id,
          brand_name: reviewData.brand_name,
          price: reviewData.price,
        },
        REVIEW_DISPLAY_SNAPSHOT_TYPE: 'SIMPLE',
        components: {
          ReviewSnippet: 'pr-reviewsnippet',
          ReviewDisplay: 'pr-reviewdisplay',
          CategorySnippet: 'review-snippet',
        },
      });
    };

    document.body.appendChild(script);

    return () => {
      document.body.removeChild(script);
    };
  }, []);

  return <div id="pr-reviewdisplay"></div>;
};

export default ProductReview;
