import CompatibleProductsPriceCart from "../compatible-products-price-cart.hbs";

export default {
  title: "Components/React Component/Compatible-Products-Price-Cart",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { CompatibleProductsPriceCart };
