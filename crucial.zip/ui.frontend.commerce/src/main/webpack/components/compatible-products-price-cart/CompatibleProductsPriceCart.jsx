import React, { useState, useEffect } from 'react';
import { PLP_PRODUCT_LIST } from '../../site/js/gql/plp-productfetch.gql';
import { ApolloClient, gql, useMutation, useQuery } from '@apollo/client';
import ReactDOM from 'react-dom/client';
import Loader from "../micro-components/Loader/Loader";
import CompatibleProdCart from "./components/compatibleprodscart/CompatibleProdCart";
import BundleProdCart from "./components/compatibleprodscart/BundleProdCart";
import { getCookie, setCookie } from '../../utils/cookies_operation';
import { BUY_NOW_SELECTORS, BUY_BUNDLE_SELECTORS } from './components/constants.js';
import { apolloClientConfigForProduct, readStoredHeader } from '../../configs/ReactApolloClientSetup/ApolloClientConfig.js';
import CryptoJS from 'crypto-js';

export default function CompatibleProductsPriceCart({ name }) {

  const [productListData, setProductListData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  let phrase = '';
  let sortObjName = "name";
  let memoryProds = JSON.parse(prodListJSmemory);
  let ssdProds = JSON.parse(prodListJSssd);
  let externalProds = JSON.parse(prodListJSExternalssd);
  let extractedMemorySkus = memoryProds?.map(product => product.sku).join(',');
  let extractedSsdSkus = ssdProds?.map(product => product.sku).join(',');
  let extractedExternalSsdSkus = externalProds?.map(product => product.sku).join(',');
  let memorySkuArray = extractedMemorySkus?.split(',');
  let ssdSkuArray = extractedSsdSkus?.split(',');
  let externalSsdSkuArray = extractedExternalSsdSkus?.split(',');
  let skuArray = [...externalSsdSkuArray, ...ssdSkuArray, ...memorySkuArray];
  let recommendedProductsData = [];
  BUY_NOW_SELECTORS?.map((itemSelector, index) => {
    let itemTag = document.querySelector(itemSelector[0]);
    if (itemTag) {
      let data = { sku: $(itemSelector[0]).attr('data-prodskuval'), qty: $(itemSelector[0]).attr('data-prodquantityval'), cartSelector: itemSelector[0], priceSelector: itemSelector[1] + $(itemSelector[0]).attr('data-prodskuval') };
      recommendedProductsData.push(data);
    }
  });
  let recommendedBundlesData = [];
  BUY_BUNDLE_SELECTORS?.map((itemSelector, index) => {
    let itemTag = document.querySelector(itemSelector[0]);
    if (itemTag) {
      let data = { memorySku: $(itemSelector[0]).attr('data-prodmemoryskuval'), memoryQty: $(itemSelector[0]).attr('data-prodmemoryquantityval'), ssdSku: $(itemSelector[0]).attr('data-prodssdskuval'), ssdQty: $(itemSelector[0]).attr('data-prodssdquantityval'), cartSelector: itemSelector[0], memoryBuyNowSelector: itemSelector[1], ssdBuyNowSelector: itemSelector[2], priceSelector: itemSelector[3], totalTextSelector: itemSelector[4], bundleUserSectionMemorySelector : itemSelector[5], bundleUserSectionSsdSelector : itemSelector[6]};
      recommendedBundlesData.push(data);
    }
  });

  let filter = [{ attribute: 'sku', in: skuArray }];
  let page_size = skuArray.length;
  let current_page = 1;
  const currencySymbol = getCookie('currency') && JSON.parse(getCookie('currency'))?.currencySymbol;
  const isscanpage = $('#product-compare').attr('data-plptype') == 'scanid' ? true : false;
  let client;

  if(isscanpage){
    const scannergroup = $('#product-compare').attr('data-scangroup');
    const usergroups = $('#product-compare').attr('data-usergroups');
    const coupon_code =  $('#product-compare').attr('data-couponcode') ?  $('#product-compare').attr('data-couponcode') :'';
    const encryptedCouponCode = btoa(coupon_code); 
    setCookie('scanned', true, 120);
    setCookie('scannergroup', scannergroup, 120);
    setCookie('usergroups', usergroups, 120);
    setCookie('couponCode', encryptedCouponCode, 120);
    const isScanned = getCookie('scanned')?getCookie('scanned'):true;
    const encryptedScannergroup = CryptoJS.AES.encrypt(scannergroup, 'crucialAdobeCommerce').toString();
    const headerDetailsCookie = getCookie('headerDetails');
    const headerDetails = JSON.parse(headerDetailsCookie);
    if(isScanned){
          headerDetails.customer_group = encryptedScannergroup;
          setCookie('headerDetails', JSON.stringify(headerDetails), 20);
    } else {
      headerDetails.customer_group = readStoredHeader('customer_group');
      setCookie('headerDetails', JSON.stringify(headerDetails), 20);
    }
    client = new ApolloClient(apolloClientConfigForProduct());
  }


  const {
    error: queryError,
    loading: queryLoading,
    data: queryData,
  } = useQuery(PLP_PRODUCT_LIST, {
    variables: {
      phrase,
      sortObjName,
      filter, 
      current_page, 
      page_size,
      imageRole:['thumbnail']
    },
  });
  useEffect(() => {
    if (queryData) {
      setProductListData(queryData);
    }
    if (queryError) {
      setError(queryError);
    }
    if (recommendedProductsData) {
      if (productListData) {
        recommendedProductsData?.map(data => {
          priceUpdate(data.priceSelector, data.sku, data.qty, productListData);
        });

        recommendedBundlesData?.map(data => {
          var memoryProdData = productListData?.productSearch?.items?.find(product => product?.productView?.sku === data.memorySku);
          var ssdProdData = productListData?.productSearch?.items?.find(product => product?.productView?.sku === data.ssdSku);
          if (ssdProdData?.productView?.inStock && memoryProdData?.productView?.inStock) {
            var memoryFinalPrice = memoryProdData?.productView?.price?.final?.amount?.value * data.memoryQty;
            var ssdFinalPrice = ssdProdData?.productView?.price?.final?.amount?.value * data.ssdQty;

            $(data.totalTextSelector).removeClass('hide');
            document.querySelector(data.priceSelector).innerHTML = currencySymbol + (memoryFinalPrice + ssdFinalPrice).toFixed(2);
          }
        });

      }

      function priceUpdate(eleSelector, sku, prodQty, productListData) {
        var prodData = productListData.productSearch?.items?.find(product => product?.productView?.sku === sku);

        if (prodData) {
          var finalPrice = prodData?.productView?.price?.final?.amount?.value;
          var regularPrice = prodData?.productView?.price?.regular?.amount?.value;
          const priceTag = document.querySelector(eleSelector);
          const prodClassName = "price-active recommended-price-text recommended-price-text-" + sku;
          const taxClassName = "text-small recommended-tax-text recommended-tax-text-" + sku;
          if (priceTag && finalPrice) {
            priceTag.innerHTML = '';
            const priceRootTag = ReactDOM.createRoot(priceTag);
            priceRootTag.render((regularPrice > finalPrice) ?
              <>
                <span class="offer-prev">{finalPrice && currencySymbol}
                  {(regularPrice * prodQty).toFixed(2)}</span>
                <span className={taxClassName}></span>
                <span class="price-active offer-active">{finalPrice && currencySymbol}
                  {(finalPrice * prodQty).toFixed(2)}</span>
                <span class="recommended-tax-text"></span>
              </> : <>
                <span className={prodClassName}>{finalPrice && currencySymbol}{(finalPrice * prodQty).toFixed(2)}</span>
                <span className={taxClassName}></span>
              </>
            );
          }
          return (finalPrice * prodQty).toFixed(2);
        }
        return '0.0';
      }
    }
    productListData.productSearch?.items?.forEach(product => {
      if (product.productView) {
        const { id, inStock, name, price, sku } = product.productView;
        const isRegularPriceMore = price?.regular?.amount?.value > price?.final?.amount?.value;
        const currency = price?.final?.amount?.currency;
        const priceSelector = ".product-card[data-prodsku=" + sku + "] .product-pricing .product-price";
        const priceTag = document.querySelector(priceSelector);
        if (priceTag) {
          const priceRootTag = ReactDOM.createRoot(priceTag);
          priceRootTag.render(
            <div>
              {isRegularPriceMore && <span className="regular_price">
                {price && currencySymbol}
                {price?.regular?.amount?.value.toFixed(2)}
              </span>
              }
              <span className={isRegularPriceMore ? 'final_price_red' : 'final_price'}>
                {price && currencySymbol}
                {price?.final?.amount?.value?.toFixed(2)}
              </span>
            </div>
          );
        }
      }
    });

  }, [queryData, queryError, productListData]);

  const cardListData = productListData?.productSearch?.items;
  let recommendedBundlesProdData = [];
  if (productListData?.productSearch) {
    recommendedBundlesData?.map(data => {
      var memoryProdData = productListData?.productSearch?.items?.find(product => product?.productView?.sku === data.memorySku);
      var ssdProdData = productListData?.productSearch?.items?.find(product => product?.productView?.sku === data.ssdSku);
      if (ssdProdData?.productView?.inStock && memoryProdData?.productView?.inStock) {
        $(data.memoryBuyNowSelector).closest('.user-actions').addClass('hide');
        $(data.ssdBuyNowSelector).closest('.user-actions').addClass('hide');
        $(data.bundleUserSectionMemorySelector).closest('.bundle-user-actions').removeClass('hide');
        $(data.bundleUserSectionSsdSelector).closest('.bundle-user-actions').removeClass('hide');
        recommendedBundlesProdData.push({ memoryProdData: memoryProdData, ssdProdData: ssdProdData, memoryQty: data.memoryQty, ssdQty: data.ssdQty, cartSelector: data.cartSelector });
      }
    });
  }
  
  return (
    <div>
      {queryLoading && <Loader />}
      {cardListData?.map((contents, index) => (
        <div key={index}>
          { contents?.productView && <CompatibleProdCart productdata={contents} />}
        </div>
      ))}
      {
        recommendedProductsData?.map((data, index) => (
          <div key={index}>
            {productListData?.productSearch
              && productListData?.productSearch?.items?.find(product => product?.productView?.sku === data.sku)
              && <CompatibleProdCart productdata={productListData?.productSearch?.items?.find(product => product?.productView?.sku === data.sku)} cartRecSelector={data.cartSelector} prodQty={data.qty} />}
          </div>
        ))
      }
      {recommendedBundlesProdData?.map((data, index) => (
        <div key={index}>
          {productListData?.productSearch &&
            <BundleProdCart memoryProductdata={data.memoryProdData} memoryQty={data.memoryQty} ssdProductdata={data.ssdProdData} ssdQty={data.ssdQty} cartRecSelector={data.cartSelector} />
          }
        </div>
      ))
      }
    </div>
  );
}
