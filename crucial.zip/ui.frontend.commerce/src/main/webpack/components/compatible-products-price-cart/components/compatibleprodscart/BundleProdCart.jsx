// import { FaShoppingCart, FaRegBookmark, FaStar, FaFireAlt } from 'react-icons/fa';
import React, { useState, useEffect } from 'react';
import Button from '../../../micro-components/Button/Button.jsx';
import ReactDOM from 'react-dom/client';

import { useStoreContext } from '../../../../contexts/common/StoreContext.jsx';
import { findObjectByName } from '../../../../utils/utils.js';
import ModalPopup from '../../../modal-popup/ModalPopup.jsx';
import useModal from '../../../../hooks/useModal.jsx';
import { ADD_BUNDLE_TO_CART, CREATE_EMPTY_CART } from '../../../../site/js/gql/mutations/bundlecart.gql.js';
import BundleToCartModal from '../bundle-to-cart-modal/BundleToCartModal.jsx';
import { useMutation, useQuery } from '@apollo/client';
import { getUserTokenFromLoaclStorate } from '../../../../configs/ReactApolloClientSetup/ApolloClientConfig.js'; // Fixed the spelling of 'LocalStorage'
import { getCookie, setCookie, checkCookie } from '../../../../utils/cookies_operation.js';
import GET_CART from '../../../../site/js/gql/get-cart.gql.js';
import LoginForm from '../../../login/component/loginform/LoginForm.jsx';
import CreateAccount from '../../../create-account/CreateAccount.jsx';
import ForgetPassword from '../../../forget-password/ForgetPassword.jsx';
import Loader from '../../../micro-components/Loader/Loader.jsx';


export default function BundleProdCart({
    memoryProductdata, memoryQty, ssdProductdata, ssdQty , cartRecSelector

}) {
    const [showConfirmPopup, setShowConfirmPopup] = useState(false);
    const plpAddtocart = $('#product-compare').attr('buybundletext');
    const { isShowing: isConfirmationShowing, toggle: toggleConfirmation } = useModal();
    const { isShowing: isLoginConfirmation, toggle: loginToggleConfirmation } = useModal();
    const { isShowing: isCAConfirmation, toggle: caToggleConfirmation } = useModal();
    const { isShowing: isForgetPasswordLogin, toggle: forgetToggleConfirmation } = useModal();
    const { state, dispatch } = useStoreContext();
    
    
    const handleUserForm = () => {
        loginToggleConfirmation();
        caToggleConfirmation();
    };

    const forgetPasswordHandler = () => {
        loginToggleConfirmation();
        forgetToggleConfirmation();

    };

    const cancelFormHandler = () => {
        loginToggleConfirmation();
    };

    const createAccountHandler = event => {
        console.log('event', event);
        if (event === 'login') {
            caToggleConfirmation();
            loginToggleConfirmation();
        }

        if (event === 'shopping') {
            //needs to verify
            caToggleConfirmation();
            loginToggleConfirmation();
        }
    };
    
    useEffect(() => {
        let previousScript = document.getElementById('cswidgetjs');
        if (previousScript) {
            previousScript.remove();
        }
        const script = document.createElement('script');
        script.src = 'https://cscoreproweustor.blob.core.windows.net/widget/scripts/cswidget.loader.js';
        script.async = true;
        document.body.appendChild(script);
        return () => {
            document.body.removeChild(script);
        };
    }, []);
    
    const { id : memoryId, inStock : memoryInStock , name : memoryName, price : memoryPrice, attributes : memoryAttributes, sku : memorySku, images : memoryImages, externalId : memoryExternalId} = memoryProductdata?.productView;
    const { id : ssdId, inStock : ssdInStock , name : ssdName, price : ssdPrice, attributes : ssdAttributes, sku : ssdSku, images : ssdImages, externalId : ssdExternalId} = ssdProductdata?.productView;
    
  
    const btnText = plpAddtocart;
   
    const cartbtn = document.querySelector(cartRecSelector);
    
    if (cartbtn) {
        useEffect(() => {
            const cartbtnRoot = ReactDOM.createRoot(cartbtn);    
                cartbtnRoot.render(
                    <Button
                        type="primary"
                        onClick={handleAddCart}
                    >
                        {btnText}
                    </Button>
                );
        }, [btnText, handleAddCart]);
    }

    const { regular: { amount: { value: memoryRegularPrice } = {} } = {}, final: { amount: { value: memoryFinalPrice } = {} } = {} } =
        memoryPrice || {};
    const { regular: { amount: { value: ssdRegularPrice } = {} } = {}, final: { amount: { value: ssdFinalPrice } = {} } = {} } =
        ssdPrice || {};
    const cartKey = 'cart_id';
    const accessToken = getUserTokenFromLoaclStorate() || '';
    const [createEmptyCart] = useMutation(CREATE_EMPTY_CART, {
        context: {
            headers: {
                authorization: accessToken ? `Bearer ${accessToken}` : '',
            },
        },
        onCompleted(data) {
            const cartData = JSON.stringify(data.core_createEmptyCart);
            setCookie(cartKey, cartData, 2880);
            
            addProductToCart({
                variables: {
                    cartId: JSON.parse(getCookie(cartKey)),
                    cartItems : [{sku : memorySku, quantity : Math.floor(memoryQty)},{sku : ssdSku, quantity : Math.floor(ssdQty)}]
                },
            });
        },
    });

    const handleAddCart = () => {
        if (!checkCookie(cartKey)) {
            createEmptyCart();
        } else {
            //Analytics code for add to cart event on plp
            if (window.digitalData) {
                digitalData.cart = digitalData.cart || {};
                digitalData.cart.addtocart = digitalData.cart.addtocart || [];
                digitalData.cart.oderOffer = '';
                let memoryProdInfoObject = {
                    skuToAdd: memorySku,
                    qtyNumber: Math.floor(memoryQty),
                    prodTitle: memoryName,
                    pagePath: window.location.pathname,
                    prodPrice: memoryRegularPrice,
                    offerPrice: memoryFinalPrice,
                    currency: memoryPrice?.final?.amount?.currency,
                    prodImage: memoryImages[0]?.url,
                    cartID: JSON.parse(getCookie(cartKey)),
                    loggedIn: localStorage.getItem('user_token') ? true : false,
                    configToAdd: undefined,
                    modOut: undefined,
                    productOfferId: undefined,
                    rfgpn: undefined,
                };
                let ssdProdInfoObject = {
                    skuToAdd: ssdSku,
                    qtyNumber: Math.floor(ssdQty),
                    prodTitle: ssdName,
                    pagePath: window.location.pathname,
                    prodPrice: ssdRegularPrice,
                    offerPrice: ssdFinalPrice,
                    currency: ssdPrice?.final?.amount?.currency,
                    prodImage: ssdImages[0]?.url,
                    cartID: JSON.parse(getCookie(cartKey)),
                    loggedIn: localStorage.getItem('user_token') ? true : false,
                    configToAdd: undefined,
                    modOut: undefined,
                    productOfferId: undefined,
                    rfgpn: undefined,
                };
                digitalData.cart.addtocart.push({ productInfo: memoryProdInfoObject });
                digitalData.cart.addtocart.push({ productInfo: ssdProdInfoObject });
                digitalData.cart.cartId = JSON.parse(getCookie(cartKey));
                if (typeof _satellite !== 'undefined' && _satellite.track) {
                    // Fire the Add to Cart Event
                    _satellite.track('add_to_cart');
                }
            }

            addProductToCart({
                variables: {
                    cartId: JSON.parse(getCookie(cartKey)),
                    cartItems : [{sku : memorySku, quantity : Math.floor(memoryQty)},{sku : ssdSku, quantity : Math.floor(ssdQty)}],
                },
            });
        }
    };
    
    const [addProductToCart, { data: addToCartData, loading: cartDataLoading }] = useMutation(ADD_BUNDLE_TO_CART, {
        context: {
            headers: {
                authorization: accessToken ? `Bearer ${accessToken}` : '',
            },
        },
        onCompleted() {
            toggleConfirmation();
            //Update miniCart quantity.
            document.querySelector(".cmp-acommerce_cart-qty").innerText = Math.floor(document.querySelector(".cmp-acommerce_cart-qty").innerText) + Math.floor(recommendedProdsObj[0].qty);
            let productCookieData = (getCookie('cart_product_urls') && JSON.parse(getCookie('cart_product_urls'))) || [];
            
            setCookie('cart_product_urls', JSON.stringify(productCookieData));
        },
    });

    const { data: viewCartData } = useQuery(GET_CART, {
        skip: !addToCartData,
        context: {
            headers: {
                authorization: accessToken ? `Bearer ${accessToken}` : '',
            },
        },
        variables: { cart_id: getCookie(cartKey) && JSON.parse(getCookie(cartKey)) },
    });
    if (viewCartData) {
        setCookie('cart_items', JSON.stringify(viewCartData), 2880);
    }

    const handleViewCart = () => {
        console.log('View Cart is clicked');
        setShowConfirmPopup(false);
    };

    
    return (
        <>
            <div className="productCardWrapper">
           { cartDataLoading && <Loader/>}
                {isConfirmationShowing && (
                    <ModalPopup isShowing={isConfirmationShowing} hide={toggleConfirmation}>
                        <BundleToCartModal
                            memoryProductImage={memoryImages[0]?.url}
                            memoryProductName={memoryName}
                            memoryPrice={memoryPrice}
                            memoryFinalPrice={memoryPrice?.final?.amount?.value}
                            memoryRegularPrice={memoryPrice?.regular?.amount?.value}
                            currency={memoryPrice?.final?.amount?.currency}
                            viewCart={handleViewCart}
                            continueShopping={toggleConfirmation}
                            memoryCartQty={memoryQty}
                            ssdProductImage={ssdImages[0]?.url}
                            ssdProductName={ssdName}
                            ssdPrice={ssdPrice}
                            ssdFinalPrice={ssdPrice?.final?.amount?.value}
                            ssdRegularPrice={ssdPrice?.regular?.amount?.value}
                            ssdCartQty={ssdQty}
                        />
                    </ModalPopup>
                )}
                {isLoginConfirmation && (
                    <ModalPopup isShowing={isLoginConfirmation} hide={loginToggleConfirmation} className="auth-popup">
                        <LoginForm changeFormHandler={handleUserForm} forgetPasswordHandler={forgetPasswordHandler} {...props} />
                    </ModalPopup>
                )}
                {isCAConfirmation && (
                    <ModalPopup className="auth-popup" isShowing={isCAConfirmation} hide={caToggleConfirmation}>
                        <CreateAccount
                            cancelFormHandler={cancelFormHandler}
                            createAccountHandler={createAccountHandler}

                        />
                    </ModalPopup>
                )}
                {isForgetPasswordLogin && (
                    <ModalPopup isShowing={isForgetPasswordLogin} hide={forgetToggleConfirmation} className="auth-popup">
                        <ForgetPassword
                            cancelFormHandler={cancelFormHandler}
                            forgetPasswordHandler={forgetPasswordHandler}

                        />
                    </ModalPopup>
                )}
            </div>
        </>
    );
}

