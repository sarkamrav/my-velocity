import React, { useEffect } from 'react';
import Button from '../../../micro-components/Button/Button.jsx';
import Icon from '../../../../assests/Icon.js';
import PropTypes from 'prop-types';
import { getShoppingUrls } from '../../../../site/js/urlresolver.js';
import { getCookie } from '../../../../utils/cookies_operation.js';

const BundleToCartModal = ({
  memoryProductImage,
  memoryProductName,
  memoryCartQty,
  memoryFinalPrice,
  memoryRegularPrice,
  ssdProductImage,
  ssdProductName,
  ssdCartQty,
  ssdFinalPrice,
  ssdRegularPrice,
  continueShopping,
  configProduct,
}) => {
  const isMemoryRegularPriceMore = memoryRegularPrice > memoryFinalPrice;
  const isSsdRegularPriceMore = ssdRegularPrice > ssdFinalPrice;
  const fallbackUrl = getShoppingUrls().placeHolderImage;
  const viewCart = () => {
    window.location.href = getShoppingUrls().cartURL;
  };
  const configProductsArray = Array.isArray(configProduct) ? configProduct : [];

  const currencySymbol = JSON.parse(getCookie('currency'))?.currencySymbol;

  //analytics code for mini cart.
  useEffect(() => {
    if (window.digitalData) {
      digitalData.link = digitalData.link || {};
      const addToCartFooterEl = document.querySelector('.cart-content-container__footer');
      const buttons = addToCartFooterEl?.querySelectorAll('button');
      buttons?.forEach(button => {
        button.addEventListener('click', function () {
          digitalData.link.linkCategory = 'button';
          digitalData.link.linkName = button.textContent;
          digitalData.link.linkUrl = 'n/a';
        });
      });
    }
  }, []);
  return (
    <>
      <div className="cmp-acommerce-mini-cart-wrapper">
        <div className="cart-title-container">
          <Icon name="CheckCircle" className="cart-title-container__checkmark" />
          <span className="cart-title-container__title">Added to cart</span>
        </div>
        <div>
          <div className="cart-content-container">
            <div className="cart-content-container__product-img">
              <img
                loading="lazy"
                className="product-image"
                alt={memoryProductName}
                src={memoryProductImage ? memoryProductImage : fallbackUrl}
              />
            </div>

            <div className="cart-content-container__description">
              <div className="cart-content-container__description--title">{memoryProductName}</div>
              <div className="cart-content-container__description--qty">
                <div>
                  <span>QTY: {memoryCartQty}</span>
                </div>
                <div className="cart-content-container__final-price">
                  <span className={isMemoryRegularPriceMore ? 'final_price_red' : 'final_price'}>
                    {currencySymbol}
                    {(memoryFinalPrice * memoryCartQty).toFixed(2)}
                  </span>
                  {isMemoryRegularPriceMore && (
                    <span className="regular_price">
                      {currencySymbol}
                      {(memoryRegularPrice * memoryCartQty).toFixed(2)}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
          <div className="cart-content-container">
            <div className="cart-content-container__product-img">
              <img
                loading="lazy"
                className="product-image"
                alt={ssdProductName}
                src={ssdProductImage ? ssdProductImage : fallbackUrl}
              />
            </div>

            <div className="cart-content-container__description">
              <div className="cart-content-container__description--title">{ssdProductName}</div>
              <div className="cart-content-container__description--qty">
                <div>
                  <span>QTY: {ssdCartQty}</span>
                </div>
                <div className="cart-content-container__final-price">
                  <span className={isSsdRegularPriceMore ? 'final_price_red' : 'final_price'}>
                    {currencySymbol}
                    {(ssdFinalPrice * ssdCartQty).toFixed(2)}
                  </span>
                  {isSsdRegularPriceMore && (
                    <span className="regular_price">
                      {currencySymbol}
                      {(ssdRegularPrice * ssdCartQty).toFixed(2)}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
          <div className="cart-content-container__footer">
            <Button type="secondary" onClick={continueShopping}>
              Continue shopping
            </Button>
            <Button type="primary" onClick={viewCart}>
              View Cart
            </Button>
          </div>
        </div>
      </div>
    </>
  );
};

export default BundleToCartModal;
