// import { FaShoppingCart, FaRegBookmark, FaStar, FaFireAlt } from 'react-icons/fa';
import React, { useState, useEffect } from 'react';
import Button from '../../../micro-components/Button/Button.jsx';
import ReactDOM from 'react-dom/client';

import { useStoreContext } from '../../../../contexts/common/StoreContext.jsx';
import { findObjectByName } from '../../../../utils/utils.js';
import ModalPopup from '../../../modal-popup/ModalPopup.jsx';
import useModal from '../../../../hooks/useModal.jsx';
import { ADD_PRODUCTS_TO_CART, CREATE_EMPTY_CART } from '../../../../site/js/gql/mutations/cart.gql.js';
import AddToCartModal from '../../../product-information/components/add-to-cart-modal/AddToCartModal.jsx';
import { useMutation, useQuery } from '@apollo/client';
import { getUserTokenFromLoaclStorate } from '../../../../configs/ReactApolloClientSetup/ApolloClientConfig.js'; // Fixed the spelling of 'LocalStorage'
import { getCookie, setCookie, checkCookie } from '../../../../utils/cookies_operation.js';
import GET_CART from '../../../../site/js/gql/get-cart.gql.js';
import LoginForm from '../../../login/component/loginform/LoginForm.jsx';
import CreateAccount from '../../../create-account/CreateAccount.jsx';
import ForgetPassword from '../../../forget-password/ForgetPassword.jsx';
import { SET_STOCK_NOTIFICATION } from '../../../../site/js/gql/mutations/stock-notification.gql.js';
import Loader from '../../../micro-components/Loader/Loader.jsx';
import { applyScanPromoCode } from '../../../../utils/applyScanPromo.js';

export default function CompatibleProdCart({
    productdata, cartRecSelector, prodQty

}) 
{
    const [showConfirmPopup, setShowConfirmPopup] = useState(false);
    const [buyingOptionUrl, setBuyingOptionUrl] = useState('');
    const [pdpUrl, setPdpUrl] = useState('');
    const loggedInNotifyMessage =  $('#product-compare').attr('data-logged-in-notify-message');
    const guestNotifyMessage =  $('#product-compare').attr('data-guest-notify-message');
    const [notifyMessage, setNotifyMessage] = useState(guestNotifyMessage);
    const [nofityMessegeShown, setNofityMessegeShown] = useState(true);
    const plpAddtocart = cartRecSelector ? $('#product-compare').attr('recommendedaddtocarttext') :$('#product-compare').attr('addtocarttext');
    const plpBuyingoptions = $('#product-compare').attr('data-buyingoptionslabel');
    const plpNotify = $('#product-compare').attr('data-notifytext');
    const { isShowing: isConfirmationShowing, toggle: toggleConfirmation } = useModal();
    const { isShowing: isLoginConfirmation, toggle: loginToggleConfirmation } = useModal();
    const { isShowing: isCAConfirmation, toggle: caToggleConfirmation } = useModal();
    const { isShowing: isForgetPasswordLogin, toggle: forgetToggleConfirmation } = useModal();
    const[cartQty,setCartQty]=useState(Number('1'));
    const { state, dispatch } = useStoreContext();

    const handleUserForm = () => {
        loginToggleConfirmation();
        caToggleConfirmation();
    };

    const forgetPasswordHandler = () => {
        loginToggleConfirmation();
        forgetToggleConfirmation();

    };

    const cancelFormHandler = () => {
        loginToggleConfirmation();
    };

    const createAccountHandler = event => {
        if (event === 'login') {
            caToggleConfirmation();
            loginToggleConfirmation();
        }

        if (event === 'shopping') {
            //needs to verify
            caToggleConfirmation();
            loginToggleConfirmation();
        }
    };
    const [stockNotification, { loading: notificationloading, error, data: stockdata }] =
        useMutation(SET_STOCK_NOTIFICATION);

    useEffect(() => {
        let previousScript = document.getElementById('cswidgetjs');
        if (previousScript) {
            previousScript.remove();
        }
        const script = document.createElement('script');
        script.src = 'https://cscoreproweustor.blob.core.windows.net/widget/scripts/cswidget.loader.js';
        script.async = true;
        document.body.appendChild(script);
        return () => {
            document.body.removeChild(script);
        };
    }, []);

    const { id, inStock, name, price, attributes, sku, images, externalId } = productdata?.productView;
    const btnText = inStock ? plpAddtocart : plpBuyingoptions;

    useEffect(() => {
        const prodUrl = $(".product-card[data-prodsku=" + sku + "] a").attr('href'); 
        setPdpUrl(pdpUrl => prodUrl);
        const categoryName = prodUrl?.split('/')[1];
        const subCategory = prodUrl?.split('/')[2];
        if (categoryName && subCategory) {
            const loginElement = document.querySelector('[data-name="Login"]');
            const isAuthor = loginElement?.hasAttribute('data-is-author');
            const rootPagePath = loginElement.getAttribute('data-root-page');
            isAuthor ? setBuyingOptionUrl(`${rootPagePath}/buying-options.html/${categoryName}/${subCategory}/${sku}`) : setBuyingOptionUrl(`/buying-options/${categoryName}/${subCategory}/${sku}`);
            
        }
    }, [attributes, buyingOptionUrl, sku]);

    const cartSelector = cartRecSelector ? cartRecSelector : ".product-card[data-prodsku=" + sku + "] .buy-container  .product-actions .actions";
    const cartbtn = document.querySelector(cartSelector);
    
    if (cartbtn) {
        const buttonElements = cartbtn.querySelectorAll('.button');
        buttonElements.forEach(button => {
            button.parentNode.removeChild(button);
        });
        useEffect(() => {
            const cartbtnRoot = ReactDOM.createRoot(cartbtn);
            if (inStock) {
                $(".product-card[data-prodsku=" + sku + "] .buy-container  .product-actions .product-quantity").removeClass("hide");
                cartbtnRoot.render(
                    <Button
                        type="primary"
                        onClick={btnHandler}
                    >
                        {btnText}
                    </Button>
                );
            }
            if (!inStock) {
                cartbtnRoot.render(
                    <div><a
                        className="cmp-acommerce_button button-primary"
                        data-sku={sku}
                        href={buyingOptionUrl}>
                        {plpBuyingoptions}
                    </a>
                        <p className="guest-notify-title-link-wrapper">
                            {nofityMessegeShown && (
                                <span className="guest-notify-title-link" onClick={notifyHandler}>
                                    {plpNotify}{' '}
                                </span>
                            )}
                            <span>{notifyMessage}</span>
                        </p>
                    </div>
                );
            }
        }, [btnText, notifyMessage, btnHandler,buyingOptionUrl]);
    }

    const { regular: { amount: { value: regularPrice } = {} } = {}, final: { amount: { value: finalPrice } = {} } = {} } =
        price || {};
    const cartKey = 'cart_id';
    const accessToken = getUserTokenFromLoaclStorate() || '';
    const [createEmptyCart] = useMutation(CREATE_EMPTY_CART, {
        context: {
            headers: {
                authorization: accessToken ? `Bearer ${accessToken}` : '',
            },
        },
        onCompleted(data) {
            const cartData = JSON.stringify(data.core_createEmptyCart);
            setCookie(cartKey, cartData, 2880);
            addProductToCart({
                variables: {
                    cartId: JSON.parse(getCookie(cartKey)),
                    SKU: sku,
                    quantity: 1,
                },
            });
        },
    });

    const handleAddCart = () => {
        setCartQty(prodQty ? prodQty : Number($('#quantity_' + sku).val()));
        if (!checkCookie(cartKey)) {
            createEmptyCart();
        } else {
            //Analytics code for add to cart event on plp
            if (window.digitalData) {
                digitalData.cart = digitalData.cart || {};
                digitalData.cart.addtocart = digitalData.cart.addtocart || [];
                digitalData.cart.oderOffer = '';
                let prodInfoObject = {
                    skuToAdd: sku,
                    qtyNumber:Number(prodQty ? prodQty : $('#quantity_' + sku).val()),
                    prodCategory: pdpUrl.split('/')[1],
                    prodSubCategory: pdpUrl.split('/')[2],
                    prodTitle: name,
                    pagePath: window.location.pathname,
                    prodPrice: regularPrice,
                    offerPrice: finalPrice,
                    currency: price?.final?.amount?.currency,
                    prodImage: images[0]?.url,
                    cartID: JSON.parse(getCookie(cartKey)),
                    loggedIn: localStorage.getItem('user_token') ? true : false,
                    configToAdd: undefined,
                    modOut: undefined,
                    productOfferId: undefined,
                    rfgpn: undefined,
                };
                digitalData.cart.addtocart.push({ productInfo: prodInfoObject });
                digitalData.cart.cartId = JSON.parse(getCookie(cartKey));
                if (typeof _satellite !== 'undefined' && _satellite.track) {
                    // Fire the Add to Cart Event
                    _satellite.track('add_to_cart');
                }
            }
           
            addProductToCart({
                variables: {
                    cartId: JSON.parse(getCookie(cartKey)),
                    SKU: sku,
                    quantity: Number(prodQty ? prodQty : $('#quantity_' + sku).val()),
                },
            });
        }
    };

    const [addProductToCart, { data: addToCartData, loading: cartDataLoading }] = useMutation(ADD_PRODUCTS_TO_CART, {
        context: {
            headers: {
                authorization: accessToken ? `Bearer ${accessToken}` : '',
            },
        },
        onCompleted() {
            toggleConfirmation();
            //Update miniCart quantity.
            document.querySelector(".cmp-acommerce_cart-qty").innerText = Math.floor(document.querySelector(".cmp-acommerce_cart-qty").innerText) + Number(prodQty ? prodQty : $('#quantity_' + sku).val());
            let productCookieData = (getCookie('cart_product_urls') && JSON.parse(getCookie('cart_product_urls'))) || [];
            setCookie('cart_product_urls', JSON.stringify(productCookieData));
            applyScanPromoCode();
        },
    });

    const { data: viewCartData } = useQuery(GET_CART, {
        skip: !addToCartData,
        context: {
            headers: {
                authorization: accessToken ? `Bearer ${accessToken}` : '',
            },
        },
        variables: { cart_id: getCookie(cartKey) && JSON.parse(getCookie(cartKey)) },
    });
    if (viewCartData) {
        setCookie('cart_items', JSON.stringify(viewCartData), 2880);
    }

    const btnHandler = () => {
        if (btnText === plpAddtocart) {
            console.log('Sku', typeof sku, sku);
            handleAddCart();

            // toggleConfirmation();
        } else {
            window.location.href = buyingOptionUrl;
        }
    };

    const handleViewCart = () => {
        console.log('View Cart is clicked');
        setShowConfirmPopup(false);
    };

    const notifyHandler = async () => {
        let user_token = localStorage.getItem('user_token');
        if (user_token) {
            const resdata = await stockNotification({
                variables: {
                    productNumber: externalId && Number(externalId),
                },
            });

            const isResponseSuccess = resdata?.data?.core_registerProductStockAlert;
            if (isResponseSuccess?.success) {
                setNotifyMessage(loggedInNotifyMessage);
                setNofityMessegeShown(false);
            }
        } else {
            loginToggleConfirmation();
        }
    };
    
    return (
        <>
            {cartDataLoading && <Loader />}
            <div className="productCardWrapper">
                {isConfirmationShowing && (
                    <ModalPopup isShowing={isConfirmationShowing} hide={toggleConfirmation}>
                        <AddToCartModal
                            productImage={images[0]?.url}
                            productName={name}
                            price={price}
                            finalPrice={price?.final?.amount?.value}
                            regularPrice={price?.regular?.amount?.value}
                            currency={price?.final?.amount?.currency}
                            viewCart={handleViewCart}
                            continueShopping={toggleConfirmation}
                            cartQty={cartQty}
                        />
                    </ModalPopup>
                )}
                {isLoginConfirmation && (
                    <ModalPopup isShowing={isLoginConfirmation} hide={loginToggleConfirmation} className="auth-popup">
                        <LoginForm changeFormHandler={handleUserForm} forgetPasswordHandler={forgetPasswordHandler} />
                    </ModalPopup>
                )}
                {isCAConfirmation && (
                    <ModalPopup className="auth-popup" isShowing={isCAConfirmation} hide={caToggleConfirmation}>
                        <CreateAccount
                            cancelFormHandler={cancelFormHandler}
                            createAccountHandler={createAccountHandler}

                        />
                    </ModalPopup>
                )}
                {isForgetPasswordLogin && (
                    <ModalPopup isShowing={isForgetPasswordLogin} hide={forgetToggleConfirmation} className="auth-popup">
                        <ForgetPassword
                            cancelFormHandler={cancelFormHandler}
                            forgetPasswordHandler={forgetPasswordHandler}

                        />
                    </ModalPopup>
                )}
            </div>
        </>
        
    );
}

