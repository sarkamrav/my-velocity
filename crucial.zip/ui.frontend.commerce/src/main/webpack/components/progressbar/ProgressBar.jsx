import React from 'react';
import PropTypes from 'prop-types';
import './progressbar.scss';

function ProgressBar({currentCount,totalCount}) {

const progressBarStyle = {
  width: `${(currentCount/ totalCount) * 100}%`,
};

return (
  <div className="progress-bar">
    <div className="progress" style={progressBarStyle}></div>
</div>
);
}

ProgressBar.propTypes = {
  currentCount: PropTypes.number,
  totalCount: PropTypes.number,
};

ProgressBar.defaultProps = {
  currentCount: 0,
  totalCount: 0
};
export default ProgressBar;
