import React, { useState } from 'react';
import { Formik, Form } from 'formik';
import InputField from '../inputfield/InputField';
import * as Yup from 'yup';
import ForgetSuccess from '../../components/forget-password/component/forgetsuccess/ForgetSuccess';
import Button from '../micro-components/Button/Button';
import { useMutation } from '@apollo/client';
import { FORGET_PASSWORD } from '../../site/js/gql/mutations/forgetPassword.gql';
import Loader from '../micro-components/Loader/Loader';
import { createAttributeString } from '../../utils/utils';

const ForgetPassword = ({ cancelFormHandler, ...props }) => {
  const [submitted, setSubmitted] = useState(false);

  const [getToken, { loading, error }] = useMutation(FORGET_PASSWORD);

  // Form validation schema
  const validationSchema = Yup.object().shape({
    email: Yup.string().email('Please enter a valid email address').required('Please enter a valid email address'),
    verifyemail: Yup.string()
      .oneOf([Yup.ref('email'), null], 'Please enter a valid email address')
      .required('This field is required.'),
  });

  // Form submit handler
  const handleSubmit = async values => {
    try {
      const { email } = values;
      const { data } = await getToken({
        variables: {
          email,
        },
      });

      if (data) {
        setSubmitted(true);
      }
    } catch (error) {
      console.error('Error creating account:', error);
    }
  };

  return (
    <>
      {loading && <Loader />}
      {!submitted && (
        <Formik
          initialValues={{
            email: '',
            verifyemail: '',
          }}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}>
          {({ isSubmitting }) => (
            <div className="forgetpassword">
              <p className="forgetpassword__title">{createAttributeString('forgetPasswordTitle')}</p>
              <p className="forgetpassword__description"> {createAttributeString('forgetPasswordDescription')}</p>
              {error && <div className="submiterror">{error?.message}</div>}
              <Form className="forgetpassword__formcontainer">
                <div className="forgetpassword__formcontainer--form">
                  <InputField
                    name="email"
                    type="email"
                    label={createAttributeString('forgetPasswordEmailAddressLabel')}
                    isMandatory
                  />
                  <InputField
                    name="verifyemail"
                    type="email"
                    label={createAttributeString('forgetPasswordVerifyEmailAddressLabel')}
                    isMandatory
                  />
                </div>
                <div className="forgetpassword__formcontainer--cta">
                  <Button size="small" disabled={isSubmitting}>
                    {createAttributeString('forgotPasswordCta')}
                  </Button>
                </div>
              </Form>
            </div>
          )}
        </Formik>
      )}
      {submitted && <ForgetSuccess cancelFormHandler={cancelFormHandler} {...props} />}
    </>
  );
};
export default ForgetPassword;
