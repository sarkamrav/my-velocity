import React from "react";
import { createRoot } from "react-dom/client";
import ForgetPassword from "./ForgetPassword.jsx";

export default class {
  static init(el) {
    const props = JSON.parse(JSON.stringify(el.dataset));
    createRoot(el).render(<ForgetPassword {...props} />);
  }
}
