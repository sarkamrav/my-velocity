import React from 'react';
import { createAttributeString } from '../../../../utils/utils';

function ForgetSuccess() {
  return (
    <div className="forgetsuccess">
      <div className="forgetsuccess__title">{createAttributeString('fpSuccessTitle')}</div>
      <div className="forgetsuccess__subtitle">{createAttributeString('fpSuccessSubtitle')}</div>
      <p className="forgetsuccess__description">{createAttributeString('fpSuccessDescriptionTitle')}</p>
    </div>
  );
}

export default ForgetSuccess;
