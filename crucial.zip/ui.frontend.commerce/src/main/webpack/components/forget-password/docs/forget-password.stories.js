import ForgetPassword from "../forget-password.hbs";

export default {
  title: "Components/React Component/Forget-Password",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { ForgetPassword };
