import React from 'react';
import Icon from '../../assests/Icon';
import { gql, useQuery } from '@apollo/client';
import Link from '../micro-components/Link/Link';
import { linksJSON } from '../../utils/common';
import { getCookie, setCookie } from '../../utils/cookies_operation.js';
import Loader from '../micro-components/Loader/Loader.jsx';

export default function UserDetails({ ...props }) {
  const FIRST_NAME = gql`
    query {
      core_customer {
        email
        firstname
      }
      core_customerCart {
        email
        id
        total_quantity
      }
    }
  `;
  const { error, loading, data } = useQuery(FIRST_NAME);

  const {
    userGreeting,
    accountHomeUrl,
    addressBookUrl,
    savedPaymentsUrl,
    orderHistoryUrl,
    productRegistrationNewUrl,
    registeredProductNewUrl,
    savedScansNewUrl,
    accountHomeLabel,
    addressBookLabel,
    savePaymentLabel,
    orderHistoryLabel,
    productRegistrationLabel,
    registeredProductsLabel,
    savedScansLabel,
    signOutLabel,
  } = props;

  if (loading) {
    return <Loader />;
  }

  if (data) {
    setCookie('cart_id', JSON.stringify(data.core_customerCart.id), 2800);
  }

  const removeUserToken = e => {
    e.stopPropagation();
    document.cookie = 'cart_id=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
    localStorage.removeItem('user_token');
    document.cookie = 'user_token=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
    document.cookie = 'cart_items=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
    document.cookie = 'user_email=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
    document.cookie = 'student_popup=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
    let requestedPath = window.location.href;
    window.location.reload(requestedPath);
  };

  return (
    <div className="cmp-acommerce_user-details__menu">
      <ul className="cmp-acommerce_user-details__menu-list">
        {error && <span className="submiterror">{error.message}</span>}
        <li className="cmp-acommerce_user-details__menu-item">
          {userGreeting}, {data?.core_customer.firstname}
        </li>
        <li key="Account home" className="cmp-acommerce_user-details__menu-item">
          <Icon name="Settings" size="smallest" />
          <Link text={accountHomeLabel} link="#" href={accountHomeUrl} type="primary" />
        </li>
        <li key="Address book" className="cmp-acommerce_user-details__menu-item">
          <Icon name="AddressBook" size="smallest" />
          <Link text={addressBookLabel} link="#" href={addressBookUrl} type="primary" />
        </li>
        <li key="Saved payments" className="cmp-acommerce_user-details__menu-item">
          <Icon name="CreditCard" size="smallest" />
          <Link text={savePaymentLabel} link="#" href={savedPaymentsUrl} type="primary" />
        </li>
        <li key="Order history" className="cmp-acommerce_user-details__menu-item">
          <Icon name="ShoppingBag" size="smallest" />
          <Link text={orderHistoryLabel} link="#" href={orderHistoryUrl} type="primary" />
        </li>
        <li key="Product registration" className="cmp-acommerce_user-details__menu-item">
          <Icon name="PlusCircle" size="smallest" />
          <Link text={productRegistrationLabel} link="#" href={productRegistrationNewUrl} type="primary" />
        </li>
        <li key="Registered products" className="cmp-acommerce_user-details__menu-item">
          <Icon name="CheckCircle" size="smallest" />
          <Link text={registeredProductsLabel} link="#" href={registeredProductNewUrl} type="primary" />
        </li>
        <li key="Saved scans" className="cmp-acommerce_user-details__menu-item">
          <Icon name="Laptop" size="smallest" />
          <Link text={savedScansLabel} link="#" href={savedScansNewUrl} type="primary" />
        </li>
        <li className="cmp-acommerce_user-details__menu-item" onClick={removeUserToken}>
          <Icon name="User" size="smallest" />
          <Link text={signOutLabel} link="#" type="primary" />
        </li>
      </ul>
    </div>
  );
}

UserDetails.defaultProps = {
  accountHomeUrl: '#',
  addressBookUrl: '#',
  savedPaymentsUrl: '#',
  orderHistoryUrl: '#',
  productRegistrationNewUrl: '#',
  registeredProductNewUrl: '#',
  savedScansNewUrl: '#',
};
