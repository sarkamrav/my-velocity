import UserDetails from "../user-details.hbs";

export default {
  title: "Components/React Component/userDetails",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { UserDetails };
