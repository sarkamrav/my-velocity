import React, { useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import Icon from '../../assests/Icon';

export default function ModalPopup({ isShowing, hide, closeTitle, className, children }) {
  const modalRef = useRef();

  const closeModal = event => {
    // Check if the click was outside of the modal-close-btn-wrapper
    if (document.querySelector('.modal-close-btn-wrapper').contains(event.target)) {
      hide();
    }
  };

  useEffect(() => {
    const modalOverlay = modalRef.current;
    modalOverlay.addEventListener('click', closeModal);

    return () => {
      modalOverlay.removeEventListener('click', closeModal);
    };
  }, []);

  useEffect(() => {
    if (isShowing) {
      document.body.style.overflowY = 'hidden';
    }
  }, [isShowing]);

  return (
    <>
      {isShowing && (
        <div className="cmp-acommerce-modal-overlay" onClick={closeModal}>
          <div className={`cmp-acommerce-modal-overlay__modal-popup-wrapper ${className}`}>
            {hide && (
              <div className="modal-close-btn-wrapper" ref={modalRef} onClick={hide}>
                {closeTitle && <span className="done-text">{closeTitle}</span>}
                <button
                  className="cmp-acommerce-modal-overlay__modal-close-button"
                  aria-label="Close modal"
                  type="button">
                  <Icon name="ModalCross" className="modal-close-btn" />
                </button>
              </div>
            )}
            {children}
          </div>
        </div>
      )}
    </>
  );
}

ModalPopup.propTypes = {
  isShowing: PropTypes.bool,
  hide: PropTypes.func,
  isClose: PropTypes.bool,
  closeTitle: PropTypes.string,
};

ModalPopup.defaultProps = {
  isShowing: false,
  isClose: true,
  closeTitle: 'Close',
  // eslint-disable-next-line @typescript-eslint/no-empty-function
  hide: () => {},
};
