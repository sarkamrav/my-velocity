import React, { useEffect, useState } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import Link from '../micro-components/Link/Link';
import GET_CART from '../../site/js/gql/get-cart.gql';
import { CREATE_EMPTY_CART } from '../../site/js/gql/mutations/cart.gql';
import { getCookie, setCookie } from '../../utils/cookies_operation';
import { getShoppingUrls } from '../../site/js/urlresolver';
import { hideSignInDiv } from '../../site/js/noncommerce-login.js';

const Minicart = () => {
  const [minicart, setMinicart] = useState(0);
  const [triggerCartQuery, setTriggerCartQuery] = useState(false);
  const [hideNonCommerceLocale, setHideNonCommerceLocale] = useState(false);

  const [createEmptyCart] = useMutation(CREATE_EMPTY_CART, {
    onCompleted(data) {
      setCookie('cart_id', JSON.stringify(data.core_createEmptyCart), 2880);
    },
  });

  const { data: cartQueryData } = useQuery(GET_CART, {
    skip: !triggerCartQuery,
    variables: {
      cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
    },
  });
  //non commerce locale hide
  useEffect(() => {
    setHideNonCommerceLocale(hideSignInDiv);
  }, []);

  useEffect(() => {
    if (!getCookie('cart_id')) {
      console.log('card id getting created from Minicart');
      console.log('reading user token from mini cart', localStorage.getItem('user_token'));
      createEmptyCart();
    } else {
      setTriggerCartQuery(true);
    }
  }, [createEmptyCart]);

  useEffect(() => {
    if (cartQueryData) {
      setMinicart(JSON.parse(cartQueryData.core_cart.total_quantity));
      cartQueryData?.core_cart?.items &&
        cartQueryData.core_cart.items.length > 0 &&
        cartQueryData.core_cart.items.forEach(item => {
          if (item?.is_supersize_price) {
            const currentSKU = item?.product?.sku;
            let promoObj = {
              sku: currentSKU,
              isSupersizePriceSet: true,
            };
            let supersizePromoCookieData =
              (getCookie('supersize_price_set') && JSON.parse(getCookie('supersize_price_set'))) || [];
            let existingSku = supersizePromoCookieData.find(item => item.sku === currentSKU);
            if (!existingSku) {
              supersizePromoCookieData.push(promoObj);
            }
            setCookie('supersize_price_set', JSON.stringify(supersizePromoCookieData));
          }
        });
    }
  }, [cartQueryData]);

  return (
    <span className="cmp-acommerce_minicart-wrapper">
      {!hideNonCommerceLocale && (
        <div className="cmp-acommerce-minicart-visible">
          <Link
            type="icon-link"
            text="Cart"
            icon="Cart"
            isMobileTextShown={false}
            className="minicart-link"
            href={getShoppingUrls().cartURL}>
            <span className="cmp-acommerce_cart-qty">{minicart}</span>
          </Link>
        </div>
      )}
    </span>
  );
};

export default Minicart;
