import Minicart from "../minicart.hbs";

export default {
  title: "Components/React Component/Minicart",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { Minicart };
