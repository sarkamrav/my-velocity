import React from "react";
import {createRoot} from "react-dom/client";
import Minicart from "./Minicart.jsx";
import ApolloClientConfig from "../../configs/ReactApolloClientSetup/ApolloClientConfig";
import {ApolloClient, ApolloProvider} from "@apollo/client";
import {StoreProvider} from "../../contexts/common/StoreContext";

export default class {
	static init(el) {
		const client = new ApolloClient(ApolloClientConfig);
		const props = JSON.parse(JSON.stringify(el.dataset));
		createRoot(el).render(
			<StoreProvider>
				<ApolloProvider client={client}>
					<Minicart {...props} />
				</ApolloProvider>
			</StoreProvider>
		);
	}
}
