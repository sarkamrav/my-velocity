import React, { useEffect, useState } from 'react';
import Icon from '../../assests/Icon';
import PropTypes from 'prop-types';

const CustomCheckbox = ({ title, checked, id, handleChange }) => {
  const [isChecked, setIsChecked] = useState(false);

  useEffect(() => {
    if (checked) {
      setIsChecked(checked);
    } else {
      setIsChecked(false);
    }
  }, [checked]);

  const handleCheckboxChange = () => {
    setIsChecked(!isChecked);
    handleChange && handleChange(title);
  };

  return (
    <div className="customCheckbox" id={id}>
      <div
        className="customCheckbox__container"
        style={{ position: 'relative' }}
        onClick={handleCheckboxChange}
        title={title}>
        <div className="customCheckbox__checkbox">
          {isChecked ? <Icon name="Checkbox" /> : <Icon name="CheckboxEmpty" />}
        </div>
        <label className={`customCheckbox__label ${isChecked ? 'label-checked' : 'empty'}`} htmlFor={id}>
          {title}
        </label>
      </div>
    </div>
  );
};

CustomCheckbox.propTypes = {
  title: PropTypes.string,
  name: PropTypes.string,
  id: PropTypes.string,
  value: PropTypes.any,
  onChange: PropTypes.func,
};

CustomCheckbox.defaultProps = {
  title: 'category',
  name: 'category',
  id: 1,
  value: 'abc',
};

export default CustomCheckbox;
