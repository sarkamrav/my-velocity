import React, { useState, useEffect, useMemo } from 'react';
import { useQuery, ApolloClient } from '@apollo/client';
import GET_PRODUCT from '../../site/js/gql/get-product.gql';
import { getCookie } from "../../utils/cookies_operation.js"
import { apolloClientConfigUsingGet } from '../../configs/ReactApolloClientSetup/ApolloClientConfig.js';

export default function DynamicPricing(props) {
  const { sku } = props;
  const [productInfo, setProductInfo] = useState(null);
  const [price, setPrice] = useState('');

  const isRegularPriceMore = price?.regular?.amount?.value > price?.final?.amount?.value;

  const gqlClientFotGet = useMemo(() => new ApolloClient(apolloClientConfigUsingGet()), []);
  const { error, loading, data } = useQuery(GET_PRODUCT, {
    client: gqlClientFotGet,
    variables: { SKU: sku, isPdp: true },
  });
  console.log('props', props);

  const currencySymbol =
    getCookie('currency') && JSON.parse(getCookie('currency')).currencySymbol;

  useEffect(() => {
    if (data) {
      setProductInfo(data);
      console.log('data', data);
      console.log('props?.displayPriceHeading.', props?.displayPriceHeading);
      const price = data?.products[0]?.price;
      setPrice(price);
    }
  }, [data]);

  return (
    <>
      {props?.component === 'dynamic-pricing' && (
        <div class="dynamic-price" data-partnumber="CT500T500SSD8">
          <div className="productPrice">
            <span className={isRegularPriceMore ? 'final_price_red' : 'final_price'}>
              {price && currencySymbol}
              {price?.final?.amount?.value?.toFixed(2)}
            </span>
            {isRegularPriceMore && (
              <span className="regular_price">
                {price && currencySymbol}
                {price?.regular?.amount?.value?.toFixed(2)}
              </span>
            )}           
          </div>
        </div>
      )}
    </>
  );
}
