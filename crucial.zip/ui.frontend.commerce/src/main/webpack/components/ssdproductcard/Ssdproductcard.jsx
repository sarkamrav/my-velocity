import React, { useState, useEffect } from 'react';
import DOMPurify from 'dompurify';
import { useMutation, useQuery } from '@apollo/client';
import GET_PRODUCT from '../../site/js/gql/get-product.gql.js';
import { getCookie, setCookie, checkCookie } from '../../utils/cookies_operation.js';
import Loader from '../micro-components/Loader/Loader.jsx';
import Button from '../micro-components/Button/Button.jsx';
import useModal from '../../hooks/useModal.jsx';
import ModalPopup from '../modal-popup/ModalPopup.jsx';
import AddToCartModal from '../product-information/components/add-to-cart-modal/AddToCartModal.jsx';
import ForgetPassword from '../forget-password/ForgetPassword.jsx';
import CreateAccount from '../create-account/CreateAccount.jsx';
import LoginForm from '../login/component/loginform/LoginForm.jsx';
import GET_CART from '../../site/js/gql/get-cart.gql.js';
import { getUserTokenFromLoaclStorate } from '../../configs/ReactApolloClientSetup/ApolloClientConfig.js'; // Fixed the spelling of 'LocalStorage'
import { ADD_PRODUCTS_TO_CART, CREATE_EMPTY_CART } from '../../site/js/gql/mutations/cart.gql.js';
import { SET_STOCK_NOTIFICATION } from '../../site/js/gql/mutations/stock-notification.gql.js';



export default function Ssdproductcard(props) {

    const { sku, productTitle, prodDetails, imageUrl, productSubcategory } = props;
    const sanitizedProdDetails = DOMPurify.sanitize(prodDetails);
    const [productInfo, setProductInfo] = useState(null);
    const [price, setPrice] = useState('');
    const [externalId, setExternalId] = useState('');

    const isRegularPriceMore = price?.regular?.amount?.value > price?.final?.amount?.value;


    const currencySymbol = getCookie('currency') && JSON.parse(getCookie('currency'))?.currencySymbol;

    const [showConfirmPopup, setShowConfirmPopup] = useState(false);
    const loggedInNotifyMessage = $('#product-compare').attr('data-logged-in-notify-message');
    const guestNotifyMessage = $('#product-compare').attr('data-guest-notify-message');
    const [notifyMessage, setNotifyMessage] = useState(guestNotifyMessage);
    const [nofityMessegeShown, setNofityMessegeShown] = useState(true);
    const plpAddtocart = $('#product-compare').attr('addToCartText');
    const plpNotify = $('#product-compare').attr('data-notifytext');
    const { isShowing: isConfirmationShowing, toggle: toggleConfirmation } = useModal();
    const { isShowing: isLoginConfirmation, toggle: loginToggleConfirmation } = useModal();
    const { isShowing: isCAConfirmation, toggle: caToggleConfirmation } = useModal();
    const { isShowing: isForgetPasswordLogin, toggle: forgetToggleConfirmation } = useModal();
    const [instock, setInstock] = useState(null);

    const handleUserForm = () => {
        loginToggleConfirmation();
        caToggleConfirmation();
    };

    const forgetPasswordHandler = () => {
        loginToggleConfirmation();
        forgetToggleConfirmation();

    };

    const cancelFormHandler = () => {
        loginToggleConfirmation();
    };

    const createAccountHandler = event => {
        if (event === 'login') {
            caToggleConfirmation();
            loginToggleConfirmation();
        }

        if (event === 'shopping') {
            //needs to verify
            caToggleConfirmation();
            loginToggleConfirmation();
        }
    };
    const [stockNotification, { loading: notificationloading, resperror, data: stockdata }] =
        useMutation(SET_STOCK_NOTIFICATION);

    const { error, loading: productdataloading, data } = useQuery(GET_PRODUCT, {
        variables: { SKU: sku, isPdp: true },
    });

    useEffect(() => {
        if (data) {
            setProductInfo(data);
            const price = data?.products[0]?.price;
            setPrice(price);
            setInstock(data?.products[0]?.inStock);
            setExternalId(data?.products[0]?.externalId);
        }
    }, [data, productInfo, instock]);

    const handleViewCart = () => {
        setShowConfirmPopup(false);
    };

    const notifyHandler = async () => {
        let user_token = localStorage.getItem('user_token');
        if (user_token) {
            const resdata = await stockNotification({
                variables: {
                    productNumber: externalId && Number(externalId),
                },
            });

            const isResponseSuccess = resdata?.data?.core_registerProductStockAlert;
            if (isResponseSuccess?.success) {
                setNotifyMessage(loggedInNotifyMessage);
                setNofityMessegeShown(false);
            }
        } else {
            loginToggleConfirmation();
        }
    };

    const btnHandler = () => {
        handleAddCart();
    };

    const handleAddCart = () => {
        // const addToCartElement = document.querySelector('.addCart');
        if (!checkCookie(cartKey)) {
            createEmptyCart();
        } else {
            //Analytics code for add to cart event on plp
            if (window.digitalData) {
                digitalData.cart = digitalData.cart || {};
                digitalData.cart.addtocart = digitalData.cart.addtocart || [];
                digitalData.cart.oderOffer = '';
                let prodInfoObject = {
                    skuToAdd: sku,
                    qtyNumber: 1,
                    prodCategory: 'ssd',
                    prodSubCategory: { productSubcategory },
                    prodTitle: { productTitle },
                    pagePath: window.location.pathname,
                    prodPrice: price?.regular?.amount?.value.toFixed(2),
                    offerPrice: price?.final?.amount?.value.toFixed(2),
                    currency: price?.final?.amount?.currency,
                    prodImage: { imageUrl },
                    cartID: JSON.parse(getCookie(cartKey)),
                    loggedIn: localStorage.getItem('user_token') ? true : false,
                    configToAdd: undefined,
                    modOut: undefined,
                    productOfferId: undefined,
                    rfgpn: undefined,
                };
                digitalData.cart.addtocart.push({ productInfo: prodInfoObject });
                digitalData.cart.cartId = JSON.parse(getCookie(cartKey));
                if (typeof _satellite !== 'undefined' && _satellite.track) {
                    // Fire the Add to Cart Event
                    _satellite.track('add_to_cart');
                }
            }

            addProductToCart({
                variables: {
                    cartId: JSON.parse(getCookie(cartKey)),
                    SKU: sku,
                    quantity: 1,
                },
            });
        }
    };

    const [addProductToCart, { data: addToCartData, loading: cartDataLoading }] = useMutation(ADD_PRODUCTS_TO_CART, {
        context: {
            headers: {
                authorization: accessToken ? `Bearer ${accessToken}` : '',
            },
        },
        onCompleted() {
            toggleConfirmation();
            let productCookieData = (getCookie('cart_product_urls') && JSON.parse(getCookie('cart_product_urls'))) || [];
            setCookie('cart_product_urls', JSON.stringify(productCookieData));
        },
    });

    const { data: viewCartData } = useQuery(GET_CART, {
        skip: !addToCartData,
        context: {
            headers: {
                authorization: accessToken ? `Bearer ${accessToken}` : '',
            },
        },
        variables: { cart_id: getCookie(cartKey) && JSON.parse(getCookie(cartKey)) },
    });
    if (viewCartData) {
        setCookie('cart_items', JSON.stringify(viewCartData), 2880);
    }

    const cartKey = 'cart_id';
    const accessToken = getUserTokenFromLoaclStorate() || '';
    const [createEmptyCart] = useMutation(CREATE_EMPTY_CART, {
        context: {
            headers: {
                authorization: accessToken ? `Bearer ${accessToken}` : '',
            },
        },
        onCompleted(data) {
            const cartData = JSON.stringify(data.core_createEmptyCart);
            setCookie(cartKey, cartData, 2880);
            addProductToCart({
                variables: {
                    cartId: JSON.parse(getCookie(cartKey)),
                    SKU: sku,
                    quantity: 1,
                },
            });
        },
    });



    return (
        <>
            {(productdataloading || cartDataLoading) && <Loader />}
            <div class="product-title" dangerouslySetInnerHTML={{ __html: sanitizedProdDetails }} />
            <div class="product-pricing" >
                <div className="product-price" data-externalId = {externalId}>
                    {isRegularPriceMore && (
                        <span className="regular_price">
                            {price && currencySymbol}
                            {price?.regular?.amount?.value.toFixed(2)}
                        </span>
                    )}
                    <span className={isRegularPriceMore ? 'final_price_red' : 'final_price'}>
                        {price && currencySymbol}
                        {price?.final?.amount?.value.toFixed(2)}
                    </span>
                </div>
            </div>
            <div class="product-actions compatible-products-price-cart">
                {instock && (
                    <Button
                        type="primary"
                        onClick={btnHandler}>
                        {plpAddtocart}
                    </Button>)}
                {!instock && (
                    <p className="guest-notify-title-link-wrapper">
                        {nofityMessegeShown && (
                            <span className="guest-notify-title-link" onClick={notifyHandler}>
                                {plpNotify}{' '}
                            </span>
                        )}
                        <span>{notifyMessage}</span>
                    </p>
                )}
            </div>
            <div>
                {isConfirmationShowing && (
                    <ModalPopup isShowing={isConfirmationShowing} hide={toggleConfirmation}>
                        <AddToCartModal
                            productImage={imageUrl}
                            productName={productTitle}
                            price={price}
                            finalPrice={price?.final?.amount?.value.toFixed(2)}
                            regularPrice={price?.regular?.amount?.value.toFixed(2)}
                            currency={price?.final?.amount?.currency}
                            viewCart={handleViewCart}
                            continueShopping={toggleConfirmation}
                        />
                    </ModalPopup>
                )}
                {isLoginConfirmation && (
                    <ModalPopup isShowing={isLoginConfirmation} hide={loginToggleConfirmation} className="auth-popup">
                        <LoginForm changeFormHandler={handleUserForm} forgetPasswordHandler={forgetPasswordHandler} {...props} />
                    </ModalPopup>
                )}
                {isCAConfirmation && (
                    <ModalPopup className="auth-popup" isShowing={isCAConfirmation} hide={caToggleConfirmation}>
                        <CreateAccount
                            cancelFormHandler={cancelFormHandler}
                            createAccountHandler={createAccountHandler}
                            {...props}
                        />
                    </ModalPopup>
                )}
                {isForgetPasswordLogin && (
                    <ModalPopup isShowing={isForgetPasswordLogin} hide={forgetToggleConfirmation} className="auth-popup">
                        <ForgetPassword
                            cancelFormHandler={cancelFormHandler}
                            forgetPasswordHandler={forgetPasswordHandler}
                            {...props}
                        />
                    </ModalPopup>
                )}
            </div>
        </>
    );
}
