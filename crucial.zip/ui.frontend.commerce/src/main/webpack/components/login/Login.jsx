import React, { useState, useEffect, useRef } from 'react';
import UserDetails from '../user-details/UserDetails';
import LoginForm from './component/loginform/LoginForm';
import CreateAccount from '../create-account/CreateAccount';
import { getUserTokenFromLoaclStorate } from '../../configs/ReactApolloClientSetup/ApolloClientConfig.js';
import ForgetPassword from '../forget-password/ForgetPassword';
import useModal from '../../hooks/useModal.jsx';
import ModalPopup from '../modal-popup/ModalPopup.jsx';
import HeadersForCatalogServices from '../headers-for-catalog-services/HeadersForCatalogServices.jsx';
import CUSTOMER_INFO_STU_EMP from '../../site/js/gql/get-customer-info.gql.js';
import REVERIFICATION_EMAIL from '../../site/js/gql/reverification-email.gql.js';
import { useLazyQuery } from '@apollo/client';
import { getCookie, setCookie } from '../../utils/cookies_operation.js';
import { hideSignInDiv } from '../../site/js/noncommerce-login.js';
import CONFIRM_EMAIL_MUTATION from '../../site/js/gql/mutations/confirmation-email.gql.js';
import { useMutation } from '@apollo/client';

export default function Login({
  loginCta,
  accountDetailsCta,
  employeeMembershipInfoPartOne,
  studentMembershipInfoPartOne,
  stuEmpMembershipInfoPartTwo,
  empStuSuccessTitle,
  empStuThankyouTitle,
  stuEmpMembershipEmail,
  studentMembershipDayOneReminder,
  studentMembershipDayTwoReminder,
  studentMembershipDayThreeReminder,
  ...restProps
}) {
  const [showUserDetails, showUserDetailsFlag] = useState(false);
  const [isStudentGroup, setIsStudentGroup] = useState(false);
  const [isEmployeeGroup, setIsEmployeeGroup] = useState(false);
  const [sendReverificationLink, setSendReverificationLink] = useState(false);
  const [reVerifyDate, setReVerifyDate] = useState('');
  const [isModalToggled, setIsModalToggled] = useState(false);
  const [hideNonCommerceLocale, setHideNonCommerceLocale] = useState(false);
  const [userEmail, setUserEmail] = useState('');
  const [confirmationKey, setConfirmationKey] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const { isShowing: isLoginConfirmation, toggle: loginToggleConfirmation } = useModal();
  const { isShowing: isCAConfirmation, toggle: caToggleConfirmation } = useModal();
  const { isShowing: isForgetPasswordLogin, toggle: forgetToggleConfirmation } = useModal();
  const [isUserVerifiedFlag, setUserVerifiedFlag] = useState(false);

  //student group and employee group confirmation
  const { isShowing: isStudentConfirmation, toggle: studentToggleConfirmation } = useModal();
  const [getCustomerInfo, { error: custerror, data: customerdata }] = useLazyQuery(CUSTOMER_INFO_STU_EMP);
  const [sendReverificationEmail, { data: reverificationemail }] = useLazyQuery(REVERIFICATION_EMAIL);

  const [confirmEmail] = useMutation(CONFIRM_EMAIL_MUTATION, {
    onCompleted: data => {
      setSuccessMessage(`Email ${data.confirmEmail.customer.email} confirmed successfully!`);
      setErrorMessage(''); // Clear any previous error message
    },
    onError: error => {
      setErrorMessage(`Error: ${error.message}`);
      setSuccessMessage(''); // Clear any previous success message
    },
  });

  console.log('errorMessage', errorMessage);
  const btnRef = useRef(null);

  const handleUserForm = () => {
    loginToggleConfirmation();
    caToggleConfirmation();
  };

  const cancelFormHandler = () => {
    loginToggleConfirmation();
  };

  const handleShowForms = () => {
    loginToggleConfirmation();
    handleUserFlag();
  };

  /* to show forget password screen */
  const forgetPasswordHandler = () => {
    loginToggleConfirmation();
    forgetToggleConfirmation();
  };

  const handleUserFlag = () => {
    showUserDetailsFlag(!showUserDetails);
  };

  //non commerce locale hide
  useEffect(() => {
    setHideNonCommerceLocale(hideSignInDiv);
  }, []);

  //To manage active session of user.
  useEffect(() => {
    const handleActivity = () => {
      let user_token = localStorage.getItem('user_token');
      if (user_token) {
        let tokenObject = JSON.parse(user_token);
        if (new Date().getTime() - Number(tokenObject.timeStored) <= 1080000) {
          tokenObject.timeStored = new Date().getTime().toString();
          localStorage.setItem('user_token', JSON.stringify(tokenObject));
          document.cookie =
            'user_token' +
            '=' +
            JSON.stringify(tokenObject) +
            ';  expires=' +
            new Date(Date.now() + 1080000).toUTCString() +
            '; path=/';
        } else {
          document.cookie = 'cart_id=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
          localStorage.removeItem('user_token');
          document.cookie = 'user_token=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
          document.cookie = 'cart_items=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
          document.cookie = 'user_email=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
          document.cookie = 'student_popup=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
        }
      }
    };
    // List of events to track user activity
    const events = ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll'];

    events.forEach(event => {
      window.addEventListener(event, handleActivity);
    });
  }, []);

  useEffect(() => {
    if (getCookie('login_popup_required')) {
      loginToggleConfirmation();
    }
  }, []);

  //This is for login analytics data
  useEffect(() => {
    let profile = [];
    if (window.digitalData) {
      digitalData.user = digitalData.user || [];
      digitalData.user[0] = { profile: profile };
      profile.push({
        profileInfo: {},
        attributes: {
          loggedIn: localStorage.getItem('user_token') ? true : false,
        },
      });
    }
  }, []);

  // useEffect(() => {
  //   const params = new URLSearchParams(window.location.search);
  //   const isUserVerified = params.get('isuserverified');

  //   if (isUserVerified === 'true') {
  //     setUserVerifiedFlag(true);
  //     loginToggleConfirmation();
  //   }
  // }, []);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const confirmationKey = params.get('confirmation_key');
    const email = params.get('email');

    if (confirmationKey) {
      setConfirmationKey(confirmationKey);
    }
    if (email) {
      setUserEmail(decodeURIComponent(encodeURIComponent(email).replace(/%20/g, '+')));
    }
  }, []);

  useEffect(() => {
    if (confirmationKey && userEmail) {
      setUserVerifiedFlag(true);
      loginToggleConfirmation();
      confirmEmail({ variables: { email: userEmail, confirmationKey: confirmationKey } });
    }
  }, [userEmail, confirmationKey]);

  const createAccountHandler = event => {
    console.log('event', event);
    if (event === 'login') {
      caToggleConfirmation();
      loginToggleConfirmation();
    }

    if (event === 'shopping') {
      caToggleConfirmation();
      window.location.href = '/';
    }
  };

  //student group and employee group confirmation
  useEffect(() => {
    if (localStorage.getItem('user_token') && getCookie('student_popup') === undefined) {
      getCustomerInfo({
        context: {
          headers: {
            Authorization: `Bearer ${JSON.parse(localStorage.getItem('user_token')).token}`,
          },
        },
      });
    }
  }, []);

  useEffect(() => {
    if (customerdata && !isModalToggled) {
      const coreCustomer = customerdata.core_customer;
      setIsStudentGroup(coreCustomer.is_student_group);
      setIsEmployeeGroup(coreCustomer.is_employee_group);
      setSendReverificationLink(coreCustomer.send_reverification_link);
      setReVerifyDate(coreCustomer.re_verify_date);

      // Show modal if either flag is true, otherwise reload the page
      if (
        (coreCustomer.is_student_group && (coreCustomer.send_reverification_link || coreCustomer.re_verify_date)) ||
        (coreCustomer.is_employee_group && coreCustomer.send_reverification_link)
      ) {
        studentToggleConfirmation();
      } else {
        setIsModalToggled(true);
      }
      setIsModalToggled(true); // Set modal toggled to true to prevent re-triggering
    }
  }, [customerdata]);

  useEffect(() => {
    if (reverificationemail) {
      console.log('Reverification Email Data:', reverificationemail.core_sendReVerificationEmail.message);
    }
  });

  const formatDate = date => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const calculateDaysLeft = reVerifyDate => {
    if (reVerifyDate) {
      const currentDate1 = new Date();
      const currentDateFormatted = formatDate(currentDate1);
      const currentDate = new Date(currentDateFormatted); // Ensure currentDate is a Date object
      const reVerify = new Date(reVerifyDate);
      const timeDiff = reVerify.getTime() - currentDate.getTime();
      const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
      return daysDiff;
    }
  };

  if (reVerifyDate) {
    var daysLeft = calculateDaysLeft(reVerifyDate);
  }

  useEffect(() => {
    if (customerdata) {
      setTimeout(() => {
        setCookie('student_popup', true);
      }, 7000);
    }
  }, [customerdata]);

  return (
    <>
      <HeadersForCatalogServices name="currency" />
      {!hideNonCommerceLocale && (
        <>
          {getUserTokenFromLoaclStorate('user_token') == '' ? (
            <button className="loginButton" onClick={loginToggleConfirmation}>
              <svg class="icon-svg icon-user">
                <use href="/etc.clientlibs/core/clientlibs/resources/icons-sprite.svg#icon-user"></use>
              </svg>
              <span className="loginButtonText">{loginCta}</span>
            </button>
          ) : (
            <button className="loginButton" onClick={handleShowForms}>
              <svg className="icon-svg icon-user">
                <use href="/etc.clientlibs/core/clientlibs/resources/icons-sprite.svg#icon-user"></use>
              </svg>
              <span className="createButtonText">{accountDetailsCta}</span>
            </button>
          )}
        </>
      )}
      {localStorage.getItem('user_token') && showUserDetails && (
        <div ref={btnRef}>
          <UserDetails {...restProps} />
        </div>
      )}
      {!localStorage.getItem('user_token') && isLoginConfirmation && (
        <ModalPopup
          isShowing={isLoginConfirmation}
          showUserDetails={showUserDetails}
          hide={loginToggleConfirmation}
          className="auth-popup">
          <LoginForm
            changeFormHandler={handleUserForm}
            isUserVerifiedFlag={isUserVerifiedFlag}
            handleUserFlag={handleUserFlag}
            forgetPasswordHandler={forgetPasswordHandler}
            {...restProps}
          />
        </ModalPopup>
      )}

      {isCAConfirmation && (
        <ModalPopup className="auth-popup" isShowing={isCAConfirmation} hide={caToggleConfirmation}>
          <CreateAccount
            cancelFormHandler={cancelFormHandler}
            createAccountHandler={createAccountHandler}
            {...restProps}
          />
        </ModalPopup>
      )}
      {isForgetPasswordLogin && (
        <ModalPopup isShowing={isForgetPasswordLogin} hide={forgetToggleConfirmation} className="auth-popup">
          <ForgetPassword
            cancelFormHandler={cancelFormHandler}
            forgetPasswordHandler={forgetPasswordHandler}
            {...restProps}
          />
        </ModalPopup>
      )}

      {((getCookie('student_popup') == undefined &&
        isStudentConfirmation &&
        isEmployeeGroup &&
        sendReverificationLink) ||
        (getCookie('student_popup') == undefined &&
          isStudentConfirmation &&
          isStudentGroup &&
          (daysLeft < 3 || daysLeft == undefined))) && (
        <ModalPopup
          className="auth-popup student-popup"
          isShowing={isStudentConfirmation}
          hide={studentToggleConfirmation}>
          <div className="successinfo">
            <p className="successinfo__title">{empStuSuccessTitle}</p>
            {isEmployeeGroup && sendReverificationLink && (
              <p className="group-info">
                {employeeMembershipInfoPartOne}&nbsp;
                <span className="loginform__reverifyemail" onClick={sendReverificationEmail}>
                  {stuEmpMembershipEmail}
                </span>
                &nbsp;{stuEmpMembershipInfoPartTwo}
              </p>
            )}
            {isStudentGroup && (sendReverificationLink || reVerifyDate) && (
              <>
                {daysLeft === 2 && <p className="group-info">{studentMembershipDayOneReminder}</p>}
                {daysLeft === 1 && <p className="group-info">{studentMembershipDayTwoReminder}</p>}
                {daysLeft === 0 && <p className="group-info">{studentMembershipDayThreeReminder}</p>}
                {(daysLeft < 0 || daysLeft == undefined) && sendReverificationLink && (
                  <p className="group-info">
                    {studentMembershipInfoPartOne}&nbsp;
                    <span className="loginform__reverifyemail" onClick={sendReverificationEmail}>
                      {stuEmpMembershipEmail}
                    </span>
                    &nbsp;{stuEmpMembershipInfoPartTwo}
                  </p>
                )}
              </>
            )}
          </div>
        </ModalPopup>
      )}
      {reverificationemail && (
        <ModalPopup
          className="auth-popup student-popup"
          isShowing={isStudentConfirmation}
          hide={studentToggleConfirmation}>
          <div className="successinfo">
            <p className="successinfo__title">{empStuThankyouTitle}</p>
            <p>{reverificationemail.core_sendReVerificationEmail.message}</p>
          </div>
        </ModalPopup>
      )}
    </>
  );
}
