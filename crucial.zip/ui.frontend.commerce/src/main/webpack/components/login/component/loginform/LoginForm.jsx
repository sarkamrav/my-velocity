import React, { useEffect, useState } from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import { gql, useMutation, useQuery } from '@apollo/client';

import InputField from '../../../inputfield/InputField';
import { USER_TOKEN } from '../../../../site/js/gql/mutations/UserToken';
import UserDetails from '../../../user-details/UserDetails';
import TextInput from '../../../input/TextInput';
import * as Yup from 'yup';
import Button from '../../../micro-components/Button/Button';
import { checkCookie, getCookie, setCookie } from '../../../../utils/cookies_operation';
import { CREATE_EMPTY_CART } from '../../../../site/js/gql/mutations/cart.gql';
import { getUserTokenFromLoaclStorate } from '../../../../configs/ReactApolloClientSetup/ApolloClientConfig';
import Loader from '../../../micro-components/Loader/Loader';
import { getShoppingUrls } from '../../../../site/js/urlresolver';
import { createAttributeString } from '../../../../utils/utils';
import InfoBanner from '../../../info-banner/InfoBanner';
import Link from '../../../micro-components/Link/Link';
import { generateMessage } from '../../../../utils/utils';
import AlertBanner from '../../../alert-banner/AlertBanner';

const LoginForm = ({
  changeFormHandler,
  isUserVerifiedFlag,
  handleUserFlag,
  showUserDetails,
  forgetPasswordHandler,
  ...props
}) => {
  useEffect(() => {
    if (document.querySelector('.header.header-mega .sticky')) {
      document.querySelector('.header.header-mega .sticky').style.zIndex = '999';
    }
    return () => {
      if (document.querySelector('.header.header-mega .sticky')) {
        document.querySelector('.header.header-mega .sticky').style.zIndex = '';
      }
    };
  }, []);
  const [name, setName] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [tokenDataProcessed, setTokenDataProcessed] = useState(false);

  // Form validation schema
  const [getToken, { error, loading, data: tokenData }] = useMutation(USER_TOKEN);

  const [createEmptyCart, { data: EmptyCart }] = useMutation(CREATE_EMPTY_CART);

  const validationSchema = Yup.object().shape({
    email: Yup.string().email('Enter a valid email address.').required('Please enter a valid email address'),
    password: Yup.string()
      .required('Please enter a password')
      .min(8, 'Password must be between 8 - 32 characters.')
      .max(32, 'Password must be between 8 - 32 characters.'),
  });
  const handleSubmit = async (values, { setSubmitting }) => {
    try {
      // handleUserFlag(false);
      const { email, password } = values;
      setUserEmail(email);
      getToken({
        variables: {
          email,
          password,
        },
      });
    } catch (error) {
      console.error('Error creating account:', error);
    }
  };
  if (tokenData && !tokenDataProcessed) {
    var tokenString = JSON.stringify(tokenData.core_generateCustomerToken);
    var tokenJson = JSON.parse(tokenString);
    setCookie('user_email', userEmail);
    tokenJson.timeStored = new Date().getTime().toString();
    tokenJson.ttl = '1080000';
    localStorage.setItem('user_token', JSON.stringify(tokenJson));
    document.cookie =
      'user_token' +
      '=' +
      JSON.stringify(tokenJson) +
      ';  expires=' +
      new Date(Date.now() + 1080000).toUTCString() +
      '; path=/';
    createEmptyCart({
      context: {
        headers: {
          Authorization: `Bearer ${tokenData?.core_generateCustomerToken?.token}`,
        },
      },
    });
    setTokenDataProcessed(true);
  }

  if (EmptyCart) {
    setCookie('cart_id', JSON.stringify(EmptyCart.core_createEmptyCart), 2880);
    if (getCookie('requested_page')) {
      let requestedPath = getCookie('requested_page');
      document.cookie = 'requested_page=; Path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
      document.cookie = 'login_popup_required=; Path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
      window.location.pathname = requestedPath;
    } else if (window.location.pathname.includes('shop/manage-order/order-search')) {
      window.location.href = getShoppingUrls()?.orderHistoryPageURL;
    } else {
      window.location.reload(window.location.href);
    }
  }

  function orderStatusHandler() {
    window.location.href = getShoppingUrls()?.orderSearchURL;
  }
  return (
    <>
      {loading && <Loader />}
      <Formik
        initialValues={{
          email: '',
          password: '',
        }}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}>
        {({ errors, isSubmitting }) => (
          <>
            {
              <div className="crucialformlogincontainer__login">
                <p className="crucialformlogincontainer__title">{createAttributeString('loginFormTitle')}</p>
                {/* <div className="divider"></div> */}
                {isUserVerifiedFlag && <AlertBanner type="success" message="success" />}

                <div className="crucialformlogincontainer__description">
                  {createAttributeString('loginFormDescription')}
                </div>
                {error && <span className="submiterror">{error.message}</span>}

                <div className="crucialformlogincontainer__form">
                  <Form className="loginform">
                    <p className="loginform__title">{createAttributeString('loginReturningCustomers')}</p>
                    <div className="loginform__container">
                      <InputField
                        name="email"
                        label={createAttributeString('emailAddressLabel')}
                        type="email"
                        isMandatory
                      />
                      <InputField
                        name="password"
                        label={createAttributeString('passwordLabel')}
                        type="password"
                        isMandatory
                      />
                    </div>
                    <Button className="login-submit" type="primary" size="large" isOutlined={false}>
                      {createAttributeString('loginAccountCta')}
                    </Button>
                    <span className="loginform__forgetpassword" onClick={forgetPasswordHandler}>
                      {createAttributeString('forgetPasswordLabel')}
                    </span>
                  </Form>
                  <div className="newcustomer">
                    <p className="newcustomer__title">{createAttributeString('loginNewCustomers')}</p>
                    <div
                      className="newcustomer__description"
                      dangerouslySetInnerHTML={{ __html: createAttributeString('loginNewCustomersDescription') }}
                    />
                    <Button
                      className="create-button"
                      type="primary"
                      size="large"
                      onClick={changeFormHandler}
                      isOutlined={false}>
                      {createAttributeString('createAccountCta')}
                    </Button>
                  </div>
                </div>
                <Link
                  className="link_info_wrapper"
                  onClick={orderStatusHandler}
                  type="special"
                  text={createAttributeString('lookupTitleInfo')}
                />
                <InfoBanner
                  message={generateMessage()}
                  url={getShoppingUrls()?.priorOrderHistoryURL}
                  className="info-banner-wrapper"
                />
              </div>
            }
          </>
        )}
      </Formik>
    </>
  );
};

export default LoginForm;
