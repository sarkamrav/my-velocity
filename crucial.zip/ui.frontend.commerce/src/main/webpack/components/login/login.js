import React from 'react';
import { createRoot } from 'react-dom/client';
import Login from './Login.jsx';
import { ApolloClient, ApolloProvider } from '@apollo/client';
import ApolloClientConfig from '../../configs/ReactApolloClientSetup/ApolloClientConfig.js';
export default class {
  static init(el) {
    const client = new ApolloClient(ApolloClientConfig);
    let props = JSON.parse(JSON.stringify(el.dataset));

    createRoot(el).render(
      <ApolloProvider client={client}>
        <Login {...props} />
      </ApolloProvider>
    );
  }
}
