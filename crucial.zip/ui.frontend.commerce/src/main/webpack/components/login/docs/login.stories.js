import Login from "../login.hbs";

export default {
  title: "Components/React Component/Login",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { Login };
