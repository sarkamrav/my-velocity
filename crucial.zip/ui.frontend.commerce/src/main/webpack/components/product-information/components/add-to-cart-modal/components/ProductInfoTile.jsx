import React from 'react';

const ProductInfoTile = (productImage, productName, cartQty, isRegularPriceMore, regularPrice, finalPrice) => {
  return (
    <div className="cart-content-container">
      {/* <div className="cart-content-container__product-img">
        <img className="product-image" alt={productName} src={productImage ? productImage : fallbackUrl} />
      </div> */}

      <div className="cart-content-container__description">
        <div className="cart-content-container__description--title">{productName}</div>
        <div className="cart-content-container__description--qty">
          <div>
            <span>Qty: {cartQty || 1}</span>
          </div>
          {/* <Price priceType="special" regularPrice={regularPrice} finalPrice={finalPrice} /> */}
        </div>
      </div>
    </div>
  );
};
export default ProductInfoTile;
