import React from 'react';
import PropTypes from 'prop-types';

export default function SelectRetailers({ sku, dataElement, ...props }) {
  // const dataElemet = document.querySelector('[data-name="ProductDetailPage"]');
  // if (dataElemet) {
  // }
  const { plpAlsoavailableat, plpSelectretailers } = props;

  return (
    <>
      {dataElement && (
        <div className="button-wrap wtb-button select-retailer">
          <span style={{ display: 'inline-block', marginRight: '6px', marginTop: '2px' }}>
            {dataElement.getAttribute('data-alsoavailableat')}
          </span>
          <a
            className="cswidget secondary"
            data-asset-id={dataElement.getAttribute('data-wtbAssetId')}
            type="button"
            pixel-id="wtb"
            data-product-sku={sku}>
            {dataElement.getAttribute('data-selectretailer')}
          </a>
        </div>
      )}
    </>
  );
}

SelectRetailers.propTypes = {
  sku: PropTypes.string,
};

SelectRetailers.defaultProps = {
  sku: '',
};
