import React, { useState, useEffect } from 'react';
import Price from '../price/Price.jsx';
import Klarna from '../klarna/Klarna.jsx';
import SelectRetailers from '../select-retailers/SelectRetailers.jsx';
import Icon from '../../../../assests/Icon.js';
import Feature from '../feature/Feature.jsx';
import ProductMediaGallery from '../product-media-gallery/ProductMediaGallery.jsx';
import AddToCartModal from '../add-to-cart-modal/AddToCartModal';
import ModalPopup from '../../../modal-popup/ModalPopup.jsx';
import { useStoreContext } from '../../../../contexts/common/StoreContext.jsx';
import { getAttributeValue, priceType } from '../../../../utils/common';
import ConfigurableProduct from './ConfigurableProduct';
import { useMutation } from '@apollo/client';
import { ADD_PRODUCTS_TO_CART, CREATE_EMPTY_CART } from '../../../../site/js/gql/mutations/cart.gql.js';
import useModal from '../../../../hooks/useModal.jsx';
import { getCookie, setCookie } from '../../../../utils/cookies_operation.js';
import StarRating from '../../../star-rating/StartRating';
import { fetchAddedItem } from '../../../../contexts/common/actions/cartaction';
import { Formik } from 'formik';
import Checkbox from '../../../micro-components/Checkbox/Checkbox.jsx';
import Radio from '../../../micro-components/Radio/Radio.jsx';
import Loader from '../../../micro-components/Loader/Loader';
import LoginForm from '../../../login/component/loginform/LoginForm.jsx';
import CreateAccount from '../../../create-account/CreateAccount.jsx';
import SupersizePromoModal from '../supersize-promo-modal/SupersizePromoModal.jsx';
import ForgetPassword from '../../../forget-password/ForgetPassword.jsx';
import { SET_STOCK_NOTIFICATION } from '../../../../site/js/gql/mutations/stock-notification.gql.js';
import ProductCard from '../../../product-list-page/components/productcard/ProductCard';
import { hideSignInDiv } from '../../../../site/js/noncommerce-login.js';
import { applyScanPromoCode } from '../../../../utils/applyScanPromo.js';

const ProductDetails = props => {
  const { stylesMap, guestNotifyMessage, loggedInNotifyMessage, plpNotifyTitle, pdpBuynow, pdpBestSellerMaxCount } =
    props;

  // Import necessary hooks and functions from React and other libraries
  const { state, dispatch } = useStoreContext();
  const [cart, setCart] = useState(1);
  const [categoryUrl, setCategoryUrl] = useState('');
  const [addondetail, setAddondetail] = useState([]);
  const [configProduct, setConfigProduct] = useState([]);
  const [supersizedVariant, setSupersizedVariant] = useState([]);
  const [formData, setFormData] = useState({
    addoncheckbox: false,
    radiocheckbox: '',
  });
  const [notifyMessage, setNotifyMessage] = useState(guestNotifyMessage);
  const [nofityMessegeShown, setNofityMessegeShown] = useState(true);
  const [hideNonCommerceLocale, setHideNonCommerceLocale] = useState(false);

  // Use custom modal hook
  const { isShowing: isConfirmationShowing, toggle: toggleConfirmation } = useModal();
  const { isShowing: isPromoShowing, toggle: togglePromoConfirmation } = useModal();
  const { isShowing: isLoginConfirmation, toggle: loginToggleConfirmation } = useModal();
  const { isShowing: isCAConfirmation, toggle: caToggleConfirmation } = useModal();
  const { isShowing: isForgetPasswordLogin, toggle: forgetToggleConfirmation } = useModal();

  //non commerce locale hide
  useEffect(() => {
    setHideNonCommerceLocale(hideSignInDiv);
  }, []);

  // Extract product details from state
  const productDetailData = state?.pdp?.productDetailData?.products[0] || {};
  const recommendations = state?.pdp?.productDetailData?.recommendations?.results || {};
  const {
    name,
    sku,
    price,
    shortDescription,
    images,
    attributes = [],
    addon_details,
    inStock,
    externalId,
  } = productDetailData;
  const variants = productDetailData?.options_details?.variants;
  const addToCartElement = document?.querySelector('.addCart');
  const handleUserForm = () => {
    loginToggleConfirmation();
    caToggleConfirmation();
  };

  /* to show forget password screen */
  const forgetPasswordHandler = () => {
    loginToggleConfirmation();
    forgetToggleConfirmation();
    // setSignupForm(false);
    // setForgetPasswordForm(true);
  };

  const cancelFormHandler = () => {
    loginToggleConfirmation();
  };

  const createAccountHandler = event => {
    if (event === 'login') {
      caToggleConfirmation();
      loginToggleConfirmation();
    }

    if (event === 'shopping') {
      //needs to verify
      caToggleConfirmation();
      loginToggleConfirmation();
    }
  };

  const [stockNotification, { loading: notificationloading, error, data: stockdata }] =
    useMutation(SET_STOCK_NOTIFICATION);

  const notifyHandler = async () => {
    let user_token = localStorage.getItem('user_token');
    if (user_token) {
      const resdata = await stockNotification({
        variables: {
          productNumber: externalId && Number(externalId),
        },
      });

      const isResponseSuccess = resdata?.data?.core_registerProductStockAlert;
      if (isResponseSuccess?.success) {
        setNotifyMessage(loggedInNotifyMessage);
        setNofityMessegeShown(false);
      }
    } else {
      loginToggleConfirmation();
    }
  };

  // Define mutation for adding products to cart
  const [addProductToCart, { data: addToCartData, loading: addToCartLoading, error: addToCartError }] = useMutation(
    ADD_PRODUCTS_TO_CART,
    {
      onCompleted(data) {
        if (data.core_addProductsToCart.user_errors.length <= 0) {
          toggleConfirmation();
          let currentSKU = {};
          if (isPromoShowing) {
            togglePromoConfirmation();
            currentSKU = supersizedVariant?.product?.sku;
            let promoObj = {
              sku: currentSKU,
              isSupersizePriceSet: true,
            };
            let supersizePromoCookieData =
              (getCookie('supersize_price_set') && JSON.parse(getCookie('supersize_price_set'))) || [];
            let existingSku = supersizePromoCookieData.find(item => item.sku === currentSKU);
            if (!existingSku) {
              supersizePromoCookieData.push(promoObj);
            }
            setCookie('supersize_price_set', JSON.stringify(supersizePromoCookieData));
          } else {
            currentSKU = document?.querySelector('.addCart').getAttribute('data-sku');
          }

          //Update miniCart quantity.
          const addToCartElement = document?.querySelector('.addCart');
          if (document.querySelector('.cmp-acommerce_cart-qty')) {
            document.querySelector('.cmp-acommerce_cart-qty').innerText =
              Math.floor(document.querySelector('.cmp-acommerce_cart-qty').innerText) +
              Math.floor(addToCartElement.getAttribute('data-qty'));
          }

          // Add product url and sku to the cookie to read on shopping cart and verify order pages
          const skuPath = `/${window.location.pathname.split('/')[1]}/${
            window.location.pathname.split('/')[2]
          }/${currentSKU}`;
          let productUrlObj = {
            sku: currentSKU,
            url: skuPath,
          };
          let productCookieData = (getCookie('cart_product_urls') && JSON.parse(getCookie('cart_product_urls'))) || [];
          let existingProduct = productCookieData.find(item => item.sku === currentSKU);
          if (existingProduct) {
            existingProduct.url = skuPath;
          } else {
            productCookieData.push(productUrlObj);
          }
          setCookie('cart_product_urls', JSON.stringify(productCookieData));
          applyScanPromoCode();
        }
      },
    }
  );

  const [createEmptyCart] = useMutation(CREATE_EMPTY_CART, {
    onCompleted(data) {
      setCookie('cart_id', JSON.stringify(data.core_createEmptyCart), 2880);
    },
  });

  if (addToCartError) {
    console.error(addToCartError);
    document.cookie = 'cart_id=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
    createEmptyCart();
  }

  // Load external script on component mount
  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://cscoreproweustor.blob.core.windows.net/widget/scripts/cswidget.loader.js';
    script.async = true;
    document.body.appendChild(script);
    return () => {
      document.body.removeChild(script);
    };
  }, []);

  const getFinalPrice = () => {
    let finalPrice = 0;
    const supersizePromoCookie =
      (getCookie('supersize_price_set') && JSON.parse(getCookie('supersize_price_set'))) || [];
    const isSupersizePriceAvaliable = supersizePromoCookie.find(item => item.sku === sku && item.isSupersizePriceSet);
    if (isSupersizePriceAvaliable) {
      const supersizedPrice = attributes?.find(item => item.name === 'supersize_price' && item.value);
      finalPrice = supersizedPrice?.value
        ? parseFloat(supersizedPrice.value) < price?.final?.amount?.value
          ? parseFloat(supersizedPrice.value)
          : price?.final?.amount?.value
        : price?.final?.amount?.value;
    } else {
      finalPrice = price?.final?.amount?.value;
    }
    return finalPrice && finalPrice?.toFixed(2);
  };

  // const { name, sku, price, shortDescription, images, attributes, addon_details } = productDetailData;
  // const inStock = false;
  // Format product prices
  const finalPrice = `${getFinalPrice()}`;
  const regularPrice = `${price?.regular?.amount?.value?.toFixed(2)}`;
  // const brand = `${getAttributeValue(attributes, 'brand')}${
  //   getAttributeValue(attributes, 'series') ? ' ' + getAttributeValue(attributes, 'series') : ''
  // }`;

  const [cartData, setCardData] = useState({
    productImage: images[0]?.url,
    productName: name,
    currency: price?.final?.amount?.currency,
    finalPrice: getFinalPrice(),
    regularPrice: price?.regular?.amount?.value?.toFixed(2),
    isSupersizePriceSet: false,
  });

  const brand = getAttributeValue(attributes, 'brand');
  // Function to get addon info
  const getInfo = val => {
    const addonInfo = addon_details?.options[0]?.radio_option.find(data => {
      return data?.option_type_id == val;
    });
    return {
      price: addonInfo?.price,
      title: addonInfo?.title,
      addonSku: addonInfo?.sku,
    };
  };

  // Set document title based on product name and SKU
  useEffect(() => {
    if (name && sku) {
      document.title = `${name} | ${sku} | Crucial.com`;
    }
  }, [name, sku]);

  // Dispatch action to fetch added item when addToCartData changes
  useEffect(() => {
    if (addToCartData) {
      dispatch(fetchAddedItem(addToCartData));
    }
  }, [addToCartData, dispatch]);

  // Set category URL based on current window location
  useEffect(() => {
    const urlSegments = new URL(window.location.href).pathname.split('/');
    setCategoryUrl(urlSegments.slice(1, 2).join('/'));
  }, []);

  // Set addon details when addon_details changes
  useEffect(() => {
    if (addon_details?.options?.length > 0) {
      const addondetailval = addon_details?.options[0]?.radio_option?.map((data, index) => {
        return {
          index: index + 1,
          title: `Get ${data?.title} only for $${data?.price}`,
          option_type_id: `${data?.option_type_id}`,
        };
      });
      setAddondetail(addondetailval);
    }
  }, [addon_details]);

  //This is for pdp page load analytics data
  useEffect(() => {
    const addToCartElement = document?.querySelector('.addCart');
    if (window.digitalData) {
      digitalData.product = digitalData.product || [];
      let productInfoObject = {
        productID: addToCartElement.getAttribute('data-sku'),
        productName: name,
        productCategory: window.location.pathname.split('/')[1],
        productType: window.location.pathname.split('/')[2],
        brand: getAttributeValue(attributes, 'brand'),
        density: getAttributeValue(attributes, 'density'),
        moduletype: getAttributeValue(attributes, 'module_type'),
        speed: getAttributeValue(attributes, 'speed'),
        interface: getAttributeValue(attributes, 'interface'),
      };
      digitalData.product.push({ productInfo: productInfoObject });
      if (typeof _satellite !== 'undefined' && _satellite.track) {
        // Fire page load event
        _satellite.track('page_view_event');
      }
    }
  }, []);

  useEffect(() => {
    if (productDetailData) {
      setCardData(prevData => {
        return {
          ...prevData,
          ...{ finalPrice: getFinalPrice() },
        };
      });
    }
  }, [productDetailData]);

  // Increase cart quantity
  const increaseCart = () => setCart(cart + 1);

  // Decrease cart quantity
  const decreaseCart = () => cart > 0 && setCart(cart - 1);

  // Supersize promo modal will be shown to user if product is ssd and higher variant has supersized price
  const showSupersizePromoModal = () => {
    const pageUrl = window.location.pathname;
    if (pageUrl && pageUrl.toUpperCase().indexOf('SSD') > -1 && !isPromoShowing) {
      let currentProductVariantSort = variants?.find(
        item => item.product?.sku === addToCartElement.getAttribute('data-sku')
      );
      currentProductVariantSort = currentProductVariantSort?.attributes?.find(item => item.code === 'variants_sort');
      currentProductVariantSort = currentProductVariantSort?.label;
      const supersizedVariants = variants?.filter(element => {
        const supersizeVariantPrice = element?.product?.supersize_price;
        let supersizeProductVariantSort = element?.attributes?.find(item => item.code === 'variants_sort');
        supersizeProductVariantSort = supersizeProductVariantSort?.label;
        return supersizeProductVariantSort > currentProductVariantSort && supersizeVariantPrice !== null;
      });
      if (supersizedVariants && supersizedVariants.length > 0) {
        supersizedVariants.length > 1 &&
          supersizedVariants.sort((a, b) => {
            const first_ele_variant_sort = a?.attributes?.find(item => item.code === 'variants_sort')?.label;
            const second_ele_variant_sort = b?.attributes?.find(item => item.code === 'variants_sort')?.label;
            return first_ele_variant_sort < second_ele_variant_sort ? 1 : -1;
          });
        setSupersizedVariant(supersizedVariants[0]);
        return true;
      }
    }
    return false;
  };

  // Handle view cart action
  const handleViewCart = () => setShowConfirmPopup(false);
  // Handle add to cart action
  const handleAddCart = () => {
    if (showSupersizePromoModal()) {
      togglePromoConfirmation();
    } else {
      const addToCartElement = document?.querySelector('.addCart');
      //This is for add to cart analytics
      if (window.digitalData) {
        digitalData.cart = digitalData.cart || {};
        digitalData.cart.addtocart = digitalData.cart.addtocart || [];
        digitalData.cart.oderOffer = '';
        let prodInfoObject = {
          skuToAdd: addToCartElement.getAttribute('data-sku'),
          qtyNumber: Math.floor(addToCartElement.getAttribute('data-qty')),
          prodCategory: window.location.pathname.split('/')[1],
          prodSubCategory: window.location.pathname.split('/')[2],
          prodTitle: name,
          pagePath: window.location.pathname,
          prodPrice: regularPrice,
          offerPrice: finalPrice,
          currency: price?.final?.amount?.currency,
          prodImage: images[0]?.url,
          cartID: JSON.parse(getCookie('cart_id')),
          loggedIn: localStorage.getItem('user_token') ? true : false,
          configToAdd: undefined,
          modOut: undefined,
          productOfferId: undefined,
          rfgpn: undefined,
        };
        digitalData.cart.addtocart.push({ productInfo: prodInfoObject });
        digitalData.cart.cartId = JSON.parse(getCookie('cart_id'));
        if (typeof _satellite !== 'undefined' && _satellite.track) {
          // Fire the Add to Cart Event
          _satellite.track('add_to_cart');
        }
      }

      const supersizePromoCookie =
        (getCookie('supersize_price_set') && JSON.parse(getCookie('supersize_price_set'))) || [];
      const isSupersizePriceAvaliable = supersizePromoCookie.find(
        item => item.sku === addToCartElement.getAttribute('data-sku') && item.isSupersizePriceSet
      );
      addProductToCart({
        variables: {
          cartId: JSON.parse(getCookie('cart_id')),
          SKU: addToCartElement.getAttribute('data-sku'),
          supersizePrice: isSupersizePriceAvaliable ? true : false,
          quantity: Math.floor(addToCartElement.getAttribute('data-qty')),
          ...(configProduct.length > 0 && {
            enteredOption: [{ uid: configProduct[0].uid, value: configProduct[0].value }],
          }),
        },
      });
    }
  };

  const handleAddPromoToCart = supersizeObj => {
    const addToCartElement = document?.querySelector('.addCart');
    //This is for add to cart analytics
    if (window.digitalData) {
      digitalData.cart = digitalData.cart || {};
      digitalData.cart.addtocart = digitalData.cart.addtocart || [];
      digitalData.cart.oderOffer = '';
      let prodInfoObject = {
        skuToAdd: supersizedVariant?.product?.sku,
        qtyNumber: Math.floor(addToCartElement.getAttribute('data-qty')),
        prodCategory: window.location.pathname.split('/')[1],
        prodSubCategory: window.location.pathname.split('/')[2],
        prodTitle: supersizeObj.productName,
        pagePath: window.location.pathname,
        prodPrice: supersizeObj.regularPrice,
        offerPrice: supersizeObj.finalPrice,
        currency: supersizeObj.currency,
        prodImage: supersizeObj.productImage,
        cartID: JSON.parse(getCookie('cart_id')),
        loggedIn: localStorage.getItem('user_token') ? true : false,
        configToAdd: undefined,
        modOut: undefined,
        productOfferId: undefined,
        rfgpn: undefined,
      };
      digitalData.cart.addtocart.push({ productInfo: prodInfoObject });
      digitalData.cart.cartId = JSON.parse(getCookie('cart_id'));
      if (typeof _satellite !== 'undefined' && _satellite.track) {
        // Fire the Add to Cart Event
        _satellite.track('add_to_cart');
      }
    }
    addProductToCart({
      variables: {
        cartId: JSON.parse(getCookie('cart_id')),
        SKU: supersizedVariant?.product?.sku,
        supersizePrice: true,
        quantity: Math.floor(addToCartElement.getAttribute('data-qty')),
        ...(configProduct.length > 0 && {
          enteredOption: [{ uid: configProduct[0].uid, value: configProduct[0].value }],
        }),
      },
    });
  };

  // i18n translation variable
  const element = document.querySelector('[data-name="ProductInformation"]');

  // Function to add a new segment to the buying option URL
  function getBuyingOptionUrl(newSegment) {
    const { origin, pathname } = window.location;
    return `${origin}/${newSegment}${pathname}`;
  }

  const setBestSellers = () => {
    return (
      recommendations &&
      recommendations.length > 0 &&
      recommendations.map(contents => (
        <>
          <h3>{contents.storefrontLabel}</h3>
          <div className="recommended-item">
            {contents.productsView.slice(0, pdpBestSellerMaxCount)?.map(product => (
              <ProductCard key={product.id} productdata={product} plpAddtocart={pdpBuynow} isInPdp />
            ))}
          </div>
        </>
      ))
    );
  };

  const handleAddToCartModalClose = () => {
    toggleConfirmation();
    // On cart modal close check if super size promo price cookie(supersize_price_set) for the selected sku
    // If supersized promo price is set then redirect to selected sku
    if (cartData.isSupersizePriceSet) {
      const supersizePromoCookie =
        (getCookie('supersize_price_set') && JSON.parse(getCookie('supersize_price_set'))) || [];
      const isSupersizePriceAvaliable = supersizePromoCookie.find(
        item => item.sku === supersizedVariant?.product?.sku && item.isSupersizePriceSet
      );
      if (isSupersizePriceAvaliable) {
        let skuURL = (getCookie('cart_product_urls') && JSON.parse(getCookie('cart_product_urls'))) || [];
        skuURL = skuURL.find(item => item.sku === isSupersizePriceAvaliable.sku);
        if (skuURL?.url) {
          window.location.href = skuURL.url;
        }
      }
    }
  };

  return (
    <>
      {(notificationloading || addToCartLoading) && <Loader />}
      <section className="product-details-block">
        <div className="container">
          {addToCartData && addToCartData?.core_addProductsToCart?.user_errors?.length > 0 && (
            <div className="cmp-acommerce_mage-error">
              {addToCartData.core_addProductsToCart.user_errors[0].message}
            </div>
          )}
          <div className="row-wrapper">
            <div className="col-wrapper-6 product-media-wrapper only-desktop">
              <ProductMediaGallery
                images={images}
                productName={name}
                stylesMap={stylesMap}
                productattributes={attributes}
              />
            </div>
            <div className="col-wrapper-6 product-info-wrapper">
              <div className="title-prefix brand">{brand !== 'undefined' ? brand : ''}</div>
              <h1 className="product-title">{name}</h1>
              <div className="attributes-wrapper">
                <div className="product attribute sku">
                  <div className="attribute-value">{sku}</div>
                </div>
                <div className="product attribute rating">
                  <div className="attribute-value">
                    <StarRating
                      value={
                        getAttributeValue(attributes, 'rating_count')
                          ? getAttributeValue(attributes, 'rating_count')
                          : 0
                      }
                      className="ratings-star"
                    />
                  </div>
                </div>
              </div>
              <div className="product attribute product-description">
                <div dangerouslySetInnerHTML={{ __html: shortDescription }} />
              </div>
              <div className="product-media-wrapper only-mobile">
                <ProductMediaGallery
                  images={images}
                  productName={name}
                  stylesMap={stylesMap}
                  productattributes={attributes}
                />
              </div>
              <div className="only-desktop price-wrapper">
                {priceType(price) === 'special' && (
                  <div className="deal-description-wrapper">
                    <span className="deal">{element && element.getAttribute('data-pdp-deals')}</span>
                  </div>
                )}
                {!hideNonCommerceLocale && <Price priceType={priceType(price)} specialPrice={finalPrice} regularPrice={regularPrice} />}
                <div className="osm-container">
                  <Klarna price={getFinalPrice()} />
                </div>
              </div>
              {name && <ConfigurableProduct />}
              <div className="only-tablet price-wrapper">
                <div className="deal-description-wrapper">
                  <span className="deal">{element && element.getAttribute('data-pdp-deals')}</span>
                </div>
                {!hideNonCommerceLocale && <Price priceType={priceType(price)} specialPrice={finalPrice} regularPrice={regularPrice} />}
                <div className="osm-container">
                  <Klarna price={getFinalPrice()} />
                </div>
              </div>
              {/*For Add On Products*/}
              {addon_details?.options?.length > 0 && (
                <Formik initialValues={formData}>
                  {({ values, errors, touched, isSubmitting }) => {
                    useEffect(() => {
                      const newConfigProduct = [];

                      if (values?.addoncheckbox) {
                        newConfigProduct.push({
                          uid: addon_details?.options[0]?.uid,
                          value: addon_details?.options[0]?.radio_option[0]?.option_type_id.toString(),
                          title: addon_details?.options[0]?.radio_option[0]?.title,
                          price: addon_details?.options[0]?.radio_option[0]?.price,
                          addonSku: addon_details?.options[0]?.radio_option[0]?.sku,
                        });
                      } else if (values?.radiocheckbox) {
                        newConfigProduct.push({
                          uid: addon_details?.options[0]?.uid,
                          value: values?.radiocheckbox,
                          ...getInfo(values?.radiocheckbox),
                        });
                      }

                      setConfigProduct(newConfigProduct);
                    }, [values, setConfigProduct]);

                    return (
                      <div className="addonproduct">
                        {addondetail?.length === 1 ? (
                          <Checkbox name="addoncheckbox" label={addondetail[0]?.title} />
                        ) : (
                          <Radio options={addondetail} name="radiocheckbox" />
                        )}
                      </div>
                    );
                  }}
                </Formik>
              )}
              {/* Product action  */}
              <div className="product-action">
                <form action="">
                  {!hideNonCommerceLocale && (
                    <div className="product-button-group">
                      {inStock && (
                        <div className="product-quantity">
                          <div className="input-group">
                            <div className="input-group-button">
                              <button
                                type="button"
                                className="qty-minus"
                                data-quantity="minus"
                                data-field="quantity"
                                onClick={decreaseCart}
                                disabled={cart === 1}>
                                <Icon name="Minus" size="qty-btn" />
                              </button>
                            </div>
                            <input
                              className="qty-input"
                              type="number"
                              name="quantity"
                              id="quantity"
                              value={cart}
                              min="1"
                              max="9"
                              onChange={event => {
                                const value = parseInt(event.target.value);
                                setCart(value > 9 ? 9 : value < 1 ? 1 : value);
                              }}
                            />
                            <div className="input-group-button">
                              <button
                                type="button"
                                className="qty-plus"
                                data-quantity="plus"
                                data-field="quantity"
                                onClick={increaseCart}
                                disabled={cart === 9}>
                                <Icon name="Plus" size="qty-btn" />
                              </button>
                            </div>
                          </div>
                        </div>
                      )}
                      <div className="wtb-wrapper">
                        <div className="button-wrap">
                          {inStock && (
                            <a
                              className="addCart cmp-acommerce_button button-primary"
                              data-sku={sku}
                              data-qty={cart}
                              onClick={handleAddCart}>
                              {element && element.getAttribute('data-pdp-addtocart')}
                            </a>
                          )}
                          {!inStock && (
                            <a
                              className="addCart cmp-acommerce_button button-primary"
                              data-sku={sku}
                              data-qty={cart}
                              href={getBuyingOptionUrl('buying-options')}>
                              {element && element.getAttribute('data-pdp-buying-options')}
                            </a>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                  {inStock && <SelectRetailers sku={sku} dataElement={element} />}
                  {!inStock && (
                    <p className="guest-notify-title-link-wrapper">
                      {nofityMessegeShown && !hideNonCommerceLocale && (
                        <span className="guest-notify-title-link" onClick={notifyHandler}>
                          {plpNotifyTitle}{' '}
                        </span>
                      )}
                      <span>{notifyMessage}</span>
                    </p>
                  )}
                </form>
              </div>
            </div>
          </div>
          <Feature />
          {recommendations && recommendations.length > 0 ? (
            <div className="recommendations">
              <div className="recommendations-wrapper">{setBestSellers()}</div>
            </div>
          ) : (
            ''
          )}
        </div>
      </section>
      {isConfirmationShowing && (
        <ModalPopup isShowing={isConfirmationShowing} hide={handleAddToCartModalClose}>
          <AddToCartModal
            productImage={cartData.productImage}
            productName={cartData.productName}
            currency={cartData.currency}
            finalPrice={cartData.finalPrice}
            configProduct={configProduct}
            regularPrice={cartData.regularPrice}
            viewCart={handleViewCart}
            continueShopping={handleAddToCartModalClose}
            cartQty={cart}
          />
        </ModalPopup>
      )}

      {isLoginConfirmation && (
        <ModalPopup isShowing={isLoginConfirmation} hide={loginToggleConfirmation} className="auth-popup">
          <LoginForm changeFormHandler={handleUserForm} forgetPasswordHandler={forgetPasswordHandler} {...props} />
        </ModalPopup>
      )}
      {isCAConfirmation && (
        <ModalPopup className="auth-popup" isShowing={isCAConfirmation} hide={caToggleConfirmation}>
          <CreateAccount cancelFormHandler={cancelFormHandler} createAccountHandler={createAccountHandler} {...props} />
        </ModalPopup>
      )}
      {isForgetPasswordLogin && (
        <ModalPopup isShowing={isForgetPasswordLogin} hide={forgetToggleConfirmation} className="auth-popup">
          <ForgetPassword
            cancelFormHandler={cancelFormHandler}
            forgetPasswordHandler={forgetPasswordHandler}
            {...props}
          />
        </ModalPopup>
      )}

      {isPromoShowing && (
        <ModalPopup className="auth-popup" isShowing={isPromoShowing} hide={togglePromoConfirmation}>
          <SupersizePromoModal
            supersizedVariant={supersizedVariant}
            handleAddCart={handleAddCart}
            handleAddPromoToCart={handleAddPromoToCart}
            cartQty={Math.floor(addToCartElement.getAttribute('data-qty'))}
            selectedSku={addToCartElement.getAttribute('data-sku')}
            variants={variants}
            setCardData={setCardData}></SupersizePromoModal>
        </ModalPopup>
      )}
    </>
  );
};

export default ProductDetails;
