import React, { useState, useEffect, useRef } from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.scss';
import 'slick-carousel/slick/slick-theme.scss';
// import { useStoreContext } from '../../../../contexts/common/StoreContext';
import { findObjectByName } from '../../../../utils/utils';
import RibbonPanel from '../../../ribbonpanel/RibbonPanel';
import { getShoppingUrls } from '../../../../site/js/urlresolver';

function ProductMediaGallery({ images, productName, stylesMap, productattributes }) {
  //   const { state } = useStoreContext();

  // State hooks
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [mainCarousel, setMainCarousel] = useState(null);
  const [thumbnailCarousel, setThumbnailCarousel] = useState(null);
  const [brandcolor, setBrandColor] = useState('');

  // Refs
  const mainCarouselRef = useRef(null);
  const thumbnailCarouselRef = useRef(null);

  // Parse styles map
  const brandstyles = stylesMap && JSON.parse(stylesMap);

  // Set carousel refs on mount
  useEffect(() => {
    setMainCarousel(mainCarouselRef.current);
    setThumbnailCarousel(thumbnailCarouselRef.current);
  }, []);

  // Handle slide change
  const handleSlideChange = current => {
    setCurrentSlideIndex(current);
  };

  // Set brand color based on product attributes
  useEffect(() => {
    const isEol = findObjectByName(productattributes, 'is_eol');
    const isNewProduct = findObjectByName(productattributes, 'is_new_product');
    const isPreOrder = findObjectByName(productattributes, 'pre_order');

    // Filter and find valid objects
    const validObjects = [isEol, isNewProduct, isPreOrder].filter(obj => obj !== undefined);
    const data = validObjects?.find(obj => obj?.value === 'yes');

    if (data) {
      setBrandColor(data);
    }
  }, [productattributes]);

  // Navigate to next slide
  const goToNextSlide = () => {
    mainCarousel.slickNext();
  };

  // Navigate to previous slide
  const goToPreviousSlide = () => {
    mainCarousel.slickPrev();
  };

  // Main carousel settings
  const mainCarouselSettings = {
    dots: false,
    infinite: false,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
  };

  // Thumbnail carousel settings
  const thumbnailCarouselSettings = {
    dots: false,
    arrows: false,
    draggable: true,
    infinite: false,
    slidesToShow: 5,
    swipeToSlide: true,
    focusOnSelect: true,
    responsive: [
      {
        breakpoint: 640,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
        },
      },
    ],
  };

  // Product detail data from store context
  //   const productDetailData = state?.pdp?.productDetailData?.products[0] || {};
  //   const { attributes } = productDetailData;

  return (
    <>
      <div className="product-media-gallery">
        <div className="cmp-acommerce-product-label">
          {Object.entries(brandstyles || {}).map(
            ([title, link]) =>
              title === brandcolor?.name && (
                <RibbonPanel key={title} style={{ background: link }}>
                  {brandcolor?.label}
                </RibbonPanel>
              )
          )}
        </div>
        {images?.length > 0 ? (
          <Slider
            {...mainCarouselSettings}
            asNavFor={thumbnailCarousel}
            ref={mainCarouselRef}
            afterChange={handleSlideChange}>
            {images &&
              images?.map((image, index) => (
                <div key={index} className="product-image-slide">
                  <img loading="lazy" src={image.url} alt={productName} />
                </div>
              ))}
          </Slider>
        ) : (
          <img
            loading="lazy"
            className="product-image-placeholder"
            src={getShoppingUrls().placeHolderImage}
            alt={productName}
          />
        )}
      </div>
      {images?.length > 0 && (
        <>
          <div className="product_carousel--thumbnails">
            <Slider {...thumbnailCarouselSettings} asNavFor={mainCarousel} ref={thumbnailCarouselRef}>
              {images &&
                images.map((image, index) => (
                  <div key={index} className="thumbnail-item">
                    <img loading="lazy" src={image.url} alt={productName} />
                  </div>
                ))}
            </Slider>
          </div>
          <div className="product_carousel--arrows">
            <button className="arrow prev" onClick={goToPreviousSlide}>
              <i className="fas fa-chevron-left"></i>←
            </button>
            <span className="slides-number">
              {currentSlideIndex + 1}/{images && images?.length}
            </span>
            <button className="arrow next" onClick={goToNextSlide}>
              <i className="fas fa-chevron-right"></i>→
            </button>
          </div>
        </>
      )}
    </>
  );
}

export default ProductMediaGallery;
