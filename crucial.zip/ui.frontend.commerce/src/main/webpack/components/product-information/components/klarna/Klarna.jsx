import React from 'react';

export default function Klarna({price}) {
  const dataElemet = document.querySelector('[data-name="ProductInformation"]');
  if (dataElemet) {
  }
  return (
    <>
      {' '}
      {dataElemet && (
        <klarna-placement
          data-loqateurl={dataElemet.getAttribute('data-loqateUrl')}
          data-exclude={dataElemet.getAttribute('data-excludeCountries')}
          data-key={dataElemet.getAttribute('data-klarnaKey')}
          data-locale={dataElemet.getAttribute('data-klarnaLocale')}
          data-purchase-amount={price*100}></klarna-placement>
      )}
    </>
  );
}
