import React from 'react';
import { useQuery } from '@apollo/client';
import GET_ADDON_PRODUCT_INFO from '../../../../../site/js/gql/addon-product-info.gql.js';
import Loader from '../../../../micro-components/Loader/Loader.jsx';
const ProuctAddonImg = ({ sku }) => {
  const { loading, data } = useQuery(GET_ADDON_PRODUCT_INFO, {
    variables: { SKU: sku },
  });

  if (loading) {
    return <Loader />;
  }

  const { products } = data;

  const product = products[0];
  return (
    <>
      {data &&
        product.images.map(image => (
          <>
            <img loading="lazy" className="product-image" src={image?.url} alt="alt" />
          </>
        ))}
    </>
  );
};

export default ProuctAddonImg;
