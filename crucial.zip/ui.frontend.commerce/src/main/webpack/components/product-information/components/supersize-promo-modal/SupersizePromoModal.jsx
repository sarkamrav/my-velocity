import React, { useEffect } from 'react';
import Button from '../../../micro-components/Button/Button';
import PropTypes from 'prop-types';
import { getCookie } from '../../../../utils/cookies_operation.js';

const SupersizePromoModal = ({
  cartQty,
  handleAddCart,
  handleAddPromoToCart,
  supersizedVariant,
  selectedSku,
  variants,
  setCardData,
}) => {
  const product = supersizedVariant?.product;
  const regularPrice = product?.price?.regularPrice?.amount?.value;
  const supersizedPrice = product?.supersize_price;
  const displayRegularPrice = regularPrice && (regularPrice * cartQty).toFixed(2);
  const displaySupersizedPrice = supersizedPrice && (supersizedPrice * cartQty).toFixed(2);
  const capacity = supersizedVariant?.attributes?.find(item => item.code === 'capacity')?.label;
  const selectedProduct = variants?.find(item => item.product.sku === selectedSku);
  const selectedProductCapacity = selectedProduct?.attributes?.find(item => item.code === 'capacity')?.label;
  const selectedProductFinalPrice = selectedProduct?.product?.price?.minimalPrice?.amount?.value;
  const selectedProductRegularPrice = selectedProduct?.product?.price?.regularPrice?.amount?.value;
  const dealPrice = selectedProductFinalPrice ? selectedProductFinalPrice : selectedProductRegularPrice;
  const amountDifference = (supersizedPrice - dealPrice)?.toFixed(0);
  const currencySymbol = JSON.parse(getCookie('currency'))?.currencySymbol;
  const imagrUrl = product?.thumbnail?.url;
  const element = document.querySelector('[data-name="ProductInformation"]');
  const handleAddPromo = () => {
    const supersizeObj = {
      productName: product?.name,
      currency: product?.price?.regularPrice?.amount?.currency,
      finalPrice: product?.supersize_price,
      regularPrice: regularPrice,
      productImage: imagrUrl,
      isSupersizePriceSet: true,
    };
    setCardData(prevData => {
      return {
        ...prevData,
        ...supersizeObj,
      };
    });
    handleAddPromoToCart(supersizeObj);
  };

  const capacityDifferenceRatio = () => {
    let selectedVariantCapacity,
      supersizedVariantCapacity = 0;
    if (capacity.indexOf('TB') > 0) {
      supersizedVariantCapacity = capacity.split('TB')[0] * 1000;
    } else {
      supersizedVariantCapacity = capacity.split('GB')[0];
    }
    if (selectedProductCapacity.indexOf('TB') > 0) {
      selectedVariantCapacity = selectedProductCapacity.split('TB')[0] * 1000;
    } else {
      selectedVariantCapacity = selectedProductCapacity.split('GB')[0];
    }
    return (supersizedVariantCapacity / selectedVariantCapacity)?.toFixed(0);
  };

  return (
    <div className="cmp-acommerce-mini-cart-wrapper">
      <div className="promo-header">
        <span className="promo-title-container__title">{element.getAttribute('data-upgrade-product-title')}</span>
      </div>

      <div className="promo-container">
        <div className="promo-cont-head1">
          <span>
            {element.getAttribute('data-get-string')} {capacityDifferenceRatio()}
            {element.getAttribute('data-X-storage-for-string')} {currencySymbol}
            {amountDifference} {element.getAttribute('data-more-exclamation')}
          </span>
        </div>
        <div className="promo-cont-head2">
          <span>
            {element.getAttribute('data-upgrade-by-adding')} {product.name} {element.getAttribute('data-to-your-cart')}{' '}
            {currencySymbol}
            {amountDifference} {element.getAttribute('data-more-end')}
          </span>
        </div>
        <div className="products">
          <div className="row">
            <div className="column small-6 left">
              <img loading="lazy" className="product-image" alt={product.name} src={imagrUrl} />
            </div>
            <div className="column small-6 right">
              <div className="product-title">{product.name}</div>
              <div className="product-quantity">
                <span>Qty: </span>
                <span className="val">{cartQty}</span>
              </div>
              <div className="product-price">
                <div className="original-price">
                  {currencySymbol}
                  {displayRegularPrice}
                </div>
                <div className="offer-price">
                  {currencySymbol}
                  {displaySupersizedPrice}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="promo-footer">
        <div className="promo-foot-header">
          <span className="promo-title-container__title">
            {element.getAttribute('data-option-to-upgrade')} {currencySymbol}
            {amountDifference} {element.getAttribute('data-string-more-question')}
          </span>
        </div>
        <div className="btn-prim">
          <Button type="primary" onClick={handleAddPromo}>
            {element.getAttribute('data-supersize-promo-proceed')}
          </Button>
        </div>
        <div className="btn-sec" onClick={handleAddCart}>
          <Button type="secondary">{element.getAttribute('data-supersize-promo-decline')}</Button>
        </div>
      </div>
    </div>
  );
};

SupersizePromoModal.propTypes = {
  cartQty: PropTypes.string,
  supersizedVariant: PropTypes.object,
  selectedSku: PropTypes.string,
  variants: PropTypes.object,
};

SupersizePromoModal.defaultProps = {
  cartQty: 1,
  supersizedVariant: {},
  selectedSku: '',
  variants: {},
};

export default SupersizePromoModal;
