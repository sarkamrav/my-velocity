import React, { useEffect, useState, useMemo } from 'react';
import { useQuery, ApolloClient } from '@apollo/client';
import { useStoreContext } from '../../../../contexts/common/StoreContext';
import { getAttributeValue } from '../../../../utils/common';
import { getCookie } from '../../../../utils/cookies_operation.js';
import { GET_PRODUCT_ADDON } from '../../../../site/js/gql/get-product.gql';
import { fetchProductAddonData } from '../../../../contexts/common/actions/pdpaction';
import { apolloClientConfigUsingGet } from '../../../../configs/ReactApolloClientSetup/ApolloClientConfig';
import Miniloader from '../../../micro-components/Miniloader/Miniloader.jsx';
import { formatLocalePrice, convertToBytes } from '../../../../utils/utils.js';

const ConfigurableProduct = () => {
  const { state, dispatch } = useStoreContext();
  const [activeTab, setActiveTab] = useState(getAttributeValue(attributes, 'packaging'));
  const [categoryUrl, setCategoryUrl] = useState('');
  const handleLinkClick = id => setActiveTab(id);
  const productDetailData = state?.pdp?.productDetailData?.products[0] || {};
  const { attributes, sku } = productDetailData;
  const configurableOptionsFromApi = state.pdp?.productDetailData?.products[0]?.options_details?.configurable_options;
  // const productPageUrl = new URL('https://dev.crucial.com/memory/technology/ct500t500ssd8');
  const productPageUrl = new URL(window.location.href);
  const variants = productDetailData?.options_details?.variants;
  const [prices, setPrices] = useState({});
  const currencySymbol = JSON.parse(getCookie('currency'))?.currencySymbol;
  const pageUrl = new URL(window.location.href);
  const urlAttrArray = pageUrl.pathname.split('/');
  const urlSkuParam = urlAttrArray[urlAttrArray.length - 1];
  const gqlClientFotGet = useMemo(() => new ApolloClient(apolloClientConfigUsingGet()), []);
  const { loading, data } = useQuery(GET_PRODUCT_ADDON, {
    client: gqlClientFotGet,
    variables: { SKU: urlSkuParam, isPdp: true },
    errorPolicy: 'all',
  });

  useEffect(() => {
    if (data) {
      dispatch(fetchProductAddonData(data));
    }
  }, [data, dispatch]);

  ///getting the different packaging attributes
  const metaDataOptions = state?.pdp?.productDetailData?.core_customAttributeMetadata?.items?.[0]?.attribute_options;

  let packagingObj = {};
  metaDataOptions?.map(attribute => {
    packagingObj[attribute.value] = attribute.label;
  });

  const tabList = [];
  //get the tabs to be shown as per the packaging available for the products
  variants?.map(variant => {
    if (packagingObj[variant?.product?.packaging] && !tabList.includes(packagingObj[variant?.product?.packaging])) {
      tabList.push(packagingObj[variant?.product?.packaging]);
    }
  });

  let speed;
  let series;
  let density;
  let capacity;
  let thermal;

  //we set the order so it shows properly in ui as we want it and not randomly decided by api
  configurableOptionsFromApi?.map(option => {
    if (option?.attribute_code === 'speed') {
      speed = option;
    } else if (option?.attribute_code === 'series') {
      series = option;
    } else if (option?.attribute_code === 'density') {
      density = option;
    } else if (option?.attribute_code === 'capacity') {
      capacity = option;
    } else if (option?.attribute_code === 'thermal') {
      thermal = option;
    }
  });

  let configurableOptions = [];

  if (density) {
    configurableOptions.push(density);
  }

  if (speed) {
    configurableOptions.push(speed);
  }

  if (series) {
    configurableOptions.push(series);
  }

  if (capacity) {
    let arr = { ...capacity };
    let sortedValues = arr?.values?.slice()?.sort((a, b) => convertToBytes(a.label) - convertToBytes(b.label));
    configurableOptions.push({ ...arr, values: sortedValues });
  }

  if (thermal) {
    configurableOptions.push(thermal);
  }

  useEffect(() => {
    if (productPageUrl) {
      const urlSegments = productPageUrl.pathname.split('/');
      const catUrl = urlSegments[urlSegments.length - 3];
      setCategoryUrl(catUrl);
    }
  }, [productPageUrl]);

  useEffect(() => {
    if (
      getAttributeValue(attributes, 'packaging') !== undefined &&
      getAttributeValue(attributes, 'packaging') !== null
    ) {
      setActiveTab(getAttributeValue(attributes, 'packaging'));
    }
  }, [productDetailData]);

  const getUrl = (indices, packaging) => {
    const filteredVariants = variants.filter(
      variant =>
        indices.every(index => variant.attributes.some(attribute => attribute.value_index === index)) &&
        (!packaging || (variant?.product?.packaging && packagingObj[variant.product.packaging] === packaging))
    );

    const sortedVariants = filteredVariants.sort((a, b) => {
      const b_variant_sort = b?.attributes?.find(item => item.code === 'variants_sort')?.label;
      const a_variant_sort = a?.attributes?.find(item => item.code === 'variants_sort')?.label;
      return b_variant_sort - a_variant_sort;
    });
    if (sortedVariants.length > 0) {
      const urlSegments = new URL(productPageUrl).pathname.split('/');
      return `/${urlSegments[1]}/${urlSegments[2]}/${sortedVariants[0].product.sku}`;
    } else {
      return 'not-available';
    }
  };

  // Function to filter variants with both value_index of capaity options and
  // selected thermal variant
  function filterVariants(variants, variantIndices) {
    return variants.filter(variant => {
      let valueIndices = variant.attributes.filter(item => item.code !== 'variants_sort');
      valueIndices = valueIndices.map(attr => attr.value_index);
      return valueIndices.length === variantIndices.length && valueIndices.every(val => variantIndices.includes(val));
    });
  }

  // Function to return the price object
  const getPrice = varints => {
    const sortedVariants = varints?.sort((a, b) => {
      const b_variant_cost = b?.attribute?.find(item => item.code === 'variants_sort')?.label;
      const a_variant_cost = a?.attribute?.find(item => item.code === 'variants_sort')?.label;
      return b_variant_cost - a_variant_cost;
    });

    const supersizePromoCookie =
      (getCookie('supersize_price_set') && JSON.parse(getCookie('supersize_price_set'))) || [];
    const isSuperSizePriceAvailable = supersizePromoCookie.find(
      item => item.sku === sortedVariants[0]?.product?.sku && item.isSupersizePriceSet
    );
    const supersizePrice = variants?.find(item => item.product?.sku === sortedVariants[0]?.product?.sku)?.product
      ?.supersize_price;
    return {
      minimalPrice:
        isSuperSizePriceAvailable &&
        supersizePrice &&
        supersizePrice < sortedVariants[0]?.product?.price?.minimalPrice?.amount?.value
          ? supersizePrice
          : sortedVariants[0]?.product?.price?.minimalPrice?.amount?.value,
      regularPrice: sortedVariants[0]?.product?.price?.regularPrice?.amount?.value,
      stockStatus: sortedVariants[0]?.product?.stock_status,
    };
  };

  // Function to create a prices options to display with the product variants
  const getOptionsPrices = () => {
    const prices = {};
    const categories = [];

    document.querySelectorAll('.product-variant.selected').forEach(variant => {
      if (variant.getAttribute('data-code') !== 'capacity') {
        categories.push(Number(variant.getAttribute('data-index')));
      }
    });

    configurableOptions?.forEach(configurableOption => {
      if (configurableOption.attribute_code === 'capacity') {
        prices[`${configurableOption.attribute_code}`] = [];
        configurableOption?.values.forEach(value => {
          prices[`${configurableOption.attribute_code}`].push({
            label: value.label,
            index: value.value_index,
            prices: getPrice(filterVariants(variants, [value.value_index, ...categories])),
          });
        });
      }
    });
    setPrices(prices);
  };
  useEffect(() => {
    if (configurableOptionsFromApi) {
      getOptionsPrices();
    }
  }, [configurableOptionsFromApi]);

  const getPrimaryUrl = (current_index, packaging) => getUrl([current_index], packaging);

  const getSecondaryUrl = (current_index, primary_index, packaging) =>
    getUrl([current_index, primary_index], packaging);

  const getTernaryUrl = (current_index, primary_index, secondary_index, packaging) =>
    getUrl([current_index, primary_index, secondary_index], packaging);

  const handleSku = event => {
    event.preventDefault();
    const clickedElement = event.target;
    const dataIndex = parseInt(clickedElement.getAttribute('data-index'));
    const dataPackaging = clickedElement.getAttribute('data-packaging');
    const attributeLevel = clickedElement.getAttribute('data-attribute-level');
    const dataAvailable = clickedElement.getAttribute('data-available');

    let url;
    if (attributeLevel === '0' || dataAvailable === 'not-available') {
      url = getPrimaryUrl(dataIndex, dataPackaging);
    } else if (attributeLevel === '1') {
      const primarySelected = parseInt(
        document.querySelector('[data-attribute-level="0"] a.selected').getAttribute('data-index')
      );
      url = getSecondaryUrl(dataIndex, primarySelected, dataPackaging);
    } else if (attributeLevel === '2') {
      const primarySelected = parseInt(
        document.querySelector('[data-attribute-level="0"] a.selected').getAttribute('data-index')
      );
      const secondarySelected = parseInt(
        document.querySelector('[data-attribute-level="1"] a.selected').getAttribute('data-index')
      );
      url = getTernaryUrl(dataIndex, primarySelected, secondarySelected, dataPackaging);
    }

    if (url) {
      window.location.href = url;
    }
  };

  const checkAvailability = (currentIndex, primaryIndex, tertiaryIndex) => {
    return variants.some(
      variant =>
        variant.attributes.some(attribute => attribute.value_index === currentIndex) &&
        variant.attributes.some(attribute => attribute.value_index === primaryIndex) &&
        (!tertiaryIndex || variant.attributes.some(attribute => attribute.value_index === tertiaryIndex))
    );
  };

  // Function to get kit quantity
  const checkKitQuantity = sku => {
    // Find the product with the given SKU
    const product = variants.find(variant => variant.product.sku === sku);

    // If product is not found, return false
    if (!product) {
      console.error('Product Not found');
      return false;
    }

    // Check if kit_qty is null
    if (product.product.kit_qty === null) {
      console.error('Kit quantity is null');
      return false;
    }
    return product.product.kit_qty !== 1;
  };

  // Function for data rendering
  function tabData(value_index, packaging) {
    let foundVariant = variants.filter(variant => {
      return variant.attributes.some(attr => attr.value_index === value_index);
    });
    foundVariant = foundVariant.find(item => item.product.packaging === packaging);
    return foundVariant?.product?.packaging ? true : false;
  }

  useEffect(() => {
    const updateAvailability = () => {
      let notMemory = false;
      let configsDivs = document.querySelectorAll('.tabs-panel.is-active .configs');
      if (configsDivs.length === 0) {
        configsDivs = document.querySelectorAll('.tabs-panel.not-memory .configs');
        notMemory = true;
      }
      configsDivs.forEach(configsDiv => {
        const configUl = configsDiv.querySelector('ul');
        if (!configUl) {
          return;
        }

        const speedListItems = configUl.querySelectorAll('li');
        speedListItems.forEach(li => {
          const currentAnchor = li.querySelector('a');
          const currentIndex = parseInt(currentAnchor.getAttribute('data-index'), 10);
          if (notMemory) {
            let secondaryIndex;

            if (configsDiv.getAttribute('data-attribute-level') === '0') {
              secondaryIndex = parseInt(
                document.querySelector('.configs[data-attribute-level="1"] a.selected')?.getAttribute('data-index'),
                10
              );
              const isAvailable = checkAvailability(currentIndex, secondaryIndex);
              currentAnchor.setAttribute('data-available', isAvailable ? 'available' : 'not-available');
            } else if (configsDiv.getAttribute('data-attribute-level') === '1') {
              secondaryIndex = parseInt(
                document.querySelector('.configs[data-attribute-level="0"] a.selected')?.getAttribute('data-index'),
                10
              );
              const isAvailable = checkAvailability(currentIndex, secondaryIndex);
              currentAnchor.setAttribute('data-available', isAvailable ? 'available' : 'not-available');
            }
          } else {
            const primaryIndex = parseInt(
              document.querySelector('.configs[data-attribute-level="0"] a.selected')?.getAttribute('data-index'),
              10
            );
            let secondaryIndex, tertiaryIndex;

            if (configsDiv.getAttribute('data-attribute-level') === '1') {
              tertiaryIndex = parseInt(
                document.querySelector('.configs[data-attribute-level="2"] a.selected')?.getAttribute('data-index'),
                10
              );
              secondaryIndex = tertiaryIndex;
              const isAvailable = checkAvailability(currentIndex, primaryIndex, secondaryIndex);
              currentAnchor.setAttribute('data-available', isAvailable ? 'available' : 'not-available');
            } else if (configsDiv.getAttribute('data-attribute-level') === '2') {
              secondaryIndex = parseInt(
                document.querySelector('.configs[data-attribute-level="1"] a.selected')?.getAttribute('data-index'),
                10
              );
              tertiaryIndex = secondaryIndex;
              const isAvailable = checkAvailability(currentIndex, primaryIndex, secondaryIndex);
              currentAnchor.setAttribute('data-available', isAvailable ? 'available' : 'not-available');
            }
          }
        });
      });
    };
    if (variants) {
      const timerId = setTimeout(updateAvailability, 1000);

      return () => clearTimeout(timerId);
    }
  }, [variants, activeTab]);

  // i18n translation variable
  const element = document.querySelector('[data-name="ProductInformation"]');

  return (
    <>
      {loading && <Miniloader />}
      {!loading && (
        <div className="product-configuration">
          {categoryUrl === 'memory' ? (
            <>
              {tabList.length > 1 ? (
                <ul className="tabs" data-tabs="nrwhi3-tabs" id="config-tabs" role="tablist">
                  {tabList.map(tab => (
                    <li key={tab} className={`tabs-title ${activeTab === tab ? 'is-active' : ''}`} role="presentation">
                      <a
                        href={`#${tab}`}
                        aria-selected={activeTab === tab}
                        role="tab"
                        aria-controls={tab}
                        id={`${tab}-label`}
                        tabIndex={activeTab === tab ? '0' : '-1'}
                        onClick={() => handleLinkClick(tab)}>
                        {tab === 'Singles' ? 'Singles' : 'Kits'}
                      </a>
                    </li>
                  ))}
                </ul>
              ) : (
                ''
              )}
              <div className="tabs-content" data-tabs-content="config-tabs">
                <div
                  className={`tabs-panel ${activeTab === 'Singles' ? 'is-active' : ''}`}
                  id="Singles"
                  role="tabpanel"
                  aria-labelledby="Singles-label"
                  aria-hidden="true">
                  {configurableOptions &&
                    configurableOptions.map((option, option_index) => {
                      return (
                        <>
                          {option.attribute_code !== 'packaging' && (
                            <>
                              <div className="configs" key={option_index} data-attribute-level={option_index}>
                                <p className="config-label" data-attribute-code={option.attribute_code}>
                                  {option.label}:{' '}
                                  <strong className="selected-config">
                                    {attributes && getAttributeValue(attributes, option.attribute_code)}
                                  </strong>
                                </p>
                                <ul className={option.label}>
                                  {option.values.map(
                                    (value, index) =>
                                      tabData(value.value_index, element.getAttribute('data-singlevalue')) && (
                                        <li key={index}>
                                          <a
                                            data-attribute={option.label}
                                            data-code={option.attribute_code}
                                            data-index={value.value_index}
                                            data-packaging={activeTab}
                                            data-attribute-level={option_index}
                                            className={`product-variant ${
                                              attributes &&
                                              value.label === getAttributeValue(attributes, option.attribute_code) &&
                                              (getAttributeValue(attributes, 'packaging') === 'Singles'
                                                ? 'selected'
                                                : '')
                                            }`}
                                            onClick={handleSku}>
                                            {value.label}
                                          </a>
                                        </li>
                                      )
                                  )}
                                </ul>
                              </div>
                            </>
                          )}
                        </>
                      );
                    })}
                </div>
                <div
                  className={`tabs-panel ${activeTab === 'Kits' ? 'is-active' : ''}`}
                  id="Kits"
                  role="tabpanel"
                  aria-labelledby="kits-label"
                  aria-hidden="true">
                  {configurableOptions &&
                    configurableOptions.map((option, option_index) => {
                      return (
                        <>
                          {option.attribute_code !== 'packaging' && (
                            <>
                              <div className="configs" key={option_index} data-attribute-level={option_index}>
                                <p className="config-label" data-attribute-code={option.attribute_code}>
                                  {option.label}:{' '}
                                  <strong className="selected-config">
                                    {attributes && getAttributeValue(attributes, option.attribute_code)}
                                  </strong>
                                </p>
                                <ul className={option.label}>
                                  {option.values.map(
                                    (value, index) =>
                                      tabData(value.value_index, element.getAttribute('data-kitvalue')) && (
                                        <li key={index}>
                                          <a
                                            data-attribute={option.label}
                                            data-code={option.attribute_code}
                                            data-index={value.value_index}
                                            data-packaging={activeTab}
                                            data-attribute-level={option_index}
                                            className={`product-variant ${
                                              attributes &&
                                              value.label === getAttributeValue(attributes, option.attribute_code) &&
                                              (getAttributeValue(attributes, 'packaging') === 'Kits' ? 'selected' : '')
                                            }`}
                                            onClick={handleSku}>
                                            {value.label}
                                          </a>
                                        </li>
                                      )
                                  )}
                                </ul>
                              </div>
                            </>
                          )}
                        </>
                      );
                    })}
                </div>
              </div>
            </>
          ) : (
            <>
              <div className="tabs-content">
                <div className={`tabs-panel not-memory`}>
                  {configurableOptions &&
                    configurableOptions.map((option, option_index) => {
                      return (
                        <>
                          {option.attribute_code !== 'packaging' && (
                            <>
                              <div className="configs" key={option_index} data-attribute-level={option_index}>
                                <p className="config-label" data-attribute-code={option.attribute_code}>
                                  {option.label}:{' '}
                                  <strong className="selected-config">
                                    {attributes && getAttributeValue(attributes, option.attribute_code)}
                                  </strong>
                                </p>
                                <ul className={option.label}>
                                  {option.values.map((value, index) => (
                                    <>
                                      <li key={index}>
                                        <a
                                          data-attribute={value.label}
                                          data-code={option.attribute_code}
                                          data-index={value.value_index}
                                          data-packaging={activeTab}
                                          data-attribute-level={option_index}
                                          className={`product-variant ${
                                            attributes &&
                                            value.label === getAttributeValue(attributes, option.attribute_code)
                                              ? 'selected'
                                              : ''
                                          }`}
                                          onClick={handleSku}>
                                          {value.label}
                                          {Object.keys(prices).length &&
                                          option.attribute_code === 'capacity' &&
                                          prices[`${option.attribute_code}`].find(item => item.label === value.label)
                                            ?.prices?.minimalPrice ? (
                                            <>
                                              <span className="separator">{'|'}</span>
                                              {formatLocalePrice(
                                                prices[`${option.attribute_code}`].find(
                                                  item => item.label === value.label
                                                ).prices.minimalPrice,
                                                currencySymbol
                                              )}
                                              {prices[`${option.attribute_code}`].find(
                                                item => item.label === value.label
                                              ).prices.regularPrice >
                                                prices[`${option.attribute_code}`].find(
                                                  item => item.label === value.label
                                                ).prices.minimalPrice && (
                                                <span className="label deal">
                                                  {element && element.getAttribute('data-pdp-deals')}
                                                </span>
                                              )}
                                            </>
                                          ) : (
                                            ''
                                          )}
                                        </a>
                                      </li>
                                    </>
                                  ))}
                                </ul>
                              </div>
                            </>
                          )}
                        </>
                      );
                    })}
                </div>
              </div>
            </>
          )}
        </div>
      )}
    </>
  );
};

export default ConfigurableProduct;
