import React, { useEffect } from 'react';
import Button from '../../../micro-components/Button/Button';
import Icon from '../../../../assests/Icon';
import PropTypes from 'prop-types';
import { getShoppingUrls } from '../../../../site/js/urlresolver';
import { getCookie } from '../../../../utils/cookies_operation.js';
import ProuctAddonImg from './components/ProuctAddonImg.jsx';
import { formatLocalePrice } from '../../../../utils/utils.js';
const AddToCartModal = ({
  productImage,
  productName,
  continueShopping,
  cartQty,
  regularPrice,
  finalPrice,
  configProduct,
  addToCartContinueShopping,
  addToCartViewCart,
  addToCartQty,
}) => {
  const isRegularPriceMore = regularPrice > finalPrice;
  const fallbackUrl = getShoppingUrls().placeHolderImage;
  const viewCart = () => {
    window.location.href = getShoppingUrls().cartURL;
  };
  const configProductsArray = configProduct && Array.isArray(configProduct) ? configProduct : [];
  console.log('configProductsArray', configProductsArray);
  const currencySymbol = getCookie('currency') && JSON.parse(getCookie('currency'))?.currencySymbol;
  const rootAttrElement = document.querySelector('[data-add-to-cart-continue-shopping]');

  //analytics code for mini cart.
  useEffect(() => {
    if (window.digitalData) {
      digitalData.link = digitalData.link || {};
      const addToCartFooterEl = document.querySelector('.cart-content-container__footer');
      const buttons = addToCartFooterEl?.querySelectorAll('button');
      buttons?.forEach(button => {
        button.addEventListener('click', function () {
          digitalData.link.linkCategory = 'button';
          digitalData.link.linkName = button.textContent;
          digitalData.link.linkUrl = 'n/a';
          if (typeof _satellite !== 'undefined' && _satellite.track) {
            _satellite.track('link_tracking');
          }
        });
      });
    }
  }, []);
  return (
    <>
      <div className="cmp-acommerce-mini-cart-wrapper">
        <div className="cart-title-container">
          <Icon name="CheckCircle" className="cart-title-container__checkmark" />
          <span className="cart-title-container__title">Added to cart</span>
        </div>
        <div>
          <div className="cart-content-container">
            <div className="cart-content-container__product-img">
              <img
                loading="lazy"
                className="product-image"
                alt={productName}
                src={productImage ? productImage : fallbackUrl}
              />
            </div>

            <div className="cart-content-container__description">
              <div className="cart-content-container__description--title">{productName}</div>
              <div className="cart-content-container__description--qty">
                <div>
                  <span>
                    {rootAttrElement?.getAttribute('data-add-to-cart-qty')}: {cartQty}
                  </span>
                </div>
                <div className="cart-content-container__final-price">
                  <span className={isRegularPriceMore ? 'final_price_red' : 'final_price'}>
                    {formatLocalePrice(finalPrice * cartQty, currencySymbol)}
                  </span>
                  {isRegularPriceMore && (
                    <span className="regular_price">{formatLocalePrice(regularPrice * cartQty, currencySymbol)}</span>
                  )}
                </div>
              </div>
            </div>
          </div>
          <div>
            {configProductsArray?.map(product => (
              <>
                <div className="cart-content-container">
                  <div className="cart-content-container__product-img">
                    <ProuctAddonImg sku={product?.addonSku} />
                  </div>

                  <div className="cart-content-container__description">
                    <div className="cart-content-container__description--title">{product?.title}</div>
                    <div className="cart-content-container__description--qty">
                      <div>
                        <span>
                          {rootAttrElement?.getAttribute('data-add-to-cart-qty')}: {1}
                        </span>
                      </div>
                      <div className="cart-content-container__final-price">
                        <span className={'final_price'}>{formatLocalePrice(product?.price, currencySymbol)}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            ))}
          </div>
          <div className="cart-content-container__footer">
            <Button type="secondary" onClick={continueShopping}>
              {rootAttrElement?.getAttribute('data-add-to-cart-continue-shopping')}
            </Button>
            <Button type="primary" onClick={viewCart}>
              {rootAttrElement?.getAttribute('data-add-to-cart-view-cart')}
            </Button>
          </div>
        </div>
      </div>
    </>
  );
};

AddToCartModal.propTypes = {
  productImage: PropTypes.string.isRequired,
  productName: PropTypes.string.isRequired,
  cartQty: PropTypes.number,
  finalPrice: PropTypes.number,
  regularPrice: PropTypes.number.isRequired,
};

AddToCartModal.defaultProps = {
  cartQty: 1,
};

export default AddToCartModal;
