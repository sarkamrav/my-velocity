import React from 'react';
import Icon from '../../../../assests/Icon.js';

export default function Feature() {
	// i18n translation variable
	const element = document.querySelector('[data-name="ProductInformation"]');
	return (
		<>
			<div className="col-wrapper-12 features">
				<ul className="feature">
					<li>
						<Icon name="NewRelease" size="feature"/>
						{element && element.getAttribute('data-pdp-newrelease')}
					</li>
					<li>
						<Icon name="Shipping" size="feature"/>
						{element && element.getAttribute('data-pdp-shipping')}
					</li>
					<li>
						<Icon name="Loading" size="feature"/>
						{element && element.getAttribute('data-pdp-return')}
					</li>
					<li>
						<Icon name="Support" size="feature"/>
						{element && element.getAttribute('data-pdp-support')}
					</li>
				</ul>
			</div>
		</>
	);
}
