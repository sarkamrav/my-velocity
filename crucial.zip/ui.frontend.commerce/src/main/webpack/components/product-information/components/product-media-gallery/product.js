/* eslint-disable max-len */
export const images = [
  "https://content.crucial.com/content/dam/crucial/ssd-products/mx500/images/product/crucial-mx500-2-5inch-product-front-image.psd.transform/medium-png/image.png",
  "https://content.crucial.com/content/dam/crucial/ssd-products/mx500/images/lifestyle/crucial-MX500-lifestyle-motherboard-1-image.psd.transform/medium-png/img.png",
  "https://content.crucial.com/content/dam/crucial/ssd-products/mx500/images/lifestyle/crucial-MX500-lifestyle-laptop-install-2-image.psd.transform/medium-png/img.png",
  "https://content.crucial.com/content/dam/crucial/ssd-products/mx500/images/product/crucial-mx500-2-5inch-product-dynamic-1-image-toms-anand.psd.transform/medium/image.png",
  "https://content.crucial.com/content/dam/crucial/ssd-products/mx500/images/lifestyle/crucial-MX500-lifestyle-motherboard-1-image.psd.transform/medium-png/img.png",
  "https://content.crucial.com/content/dam/crucial/ssd-products/mx500/images/lifestyle/crucial-MX500-lifestyle-laptop-install-2-image.psd.transform/medium-png/img.png",
];
