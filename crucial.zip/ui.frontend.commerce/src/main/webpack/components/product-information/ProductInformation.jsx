import React, { useEffect, useMemo } from 'react';
import { useQuery, ApolloClient } from '@apollo/client';
import { useStoreContext } from '../../contexts/common/StoreContext';
import ProductStickyTab from '../product-sticky-tab/ProductStickyTab';
import { fetchProductDetailsData } from '../../contexts/common/actions/pdpaction';
import ProductDetails from './components/product-details/ProductDetails';
import { GET_BASIC_PRODUCT_DETAILS } from '../../site/js/gql/get-product.gql';
import Loader from '../micro-components/Loader/Loader';
import { apolloClientConfigUsingGet } from '../../configs/ReactApolloClientSetup/ApolloClientConfig';

// Working SKUs
// Crucial DDR5 UDIMM-Kits-48GB-DDR5-6000-Classic
// crucial-t500-pcie-gen4-nvme-m.2-ssd-2TB-Non-Heatsink
// ct500t500ssd8  -- this one has oid

const ProductInformation = ({ name, ...props }) => {
  const { state, dispatch } = useStoreContext();
  const productUrl = new URL(window.location.href);
  const urlArray = productUrl.pathname.split('/');
  const sku = urlArray[urlArray.length - 1];
  const gqlClientFotGet = useMemo(() => new ApolloClient(apolloClientConfigUsingGet()), []);
  const { error, loading, data } = useQuery(GET_BASIC_PRODUCT_DETAILS, {
    client: gqlClientFotGet, // Override the client here for get call
    variables: { SKU: sku, isPdp: true },
  });

  useEffect(() => {
    if (data) {
      dispatch(fetchProductDetailsData(data));
    }
  }, [data, dispatch]);

  if (error) {
    console.error(error);
  }

  return (
    <>
      {loading && <Loader />}
      <div className="product-detail-wrapper">
        {state?.pdp && (
          <>
            <ProductDetails {...props} />
          </>
        )}
      </div>
      {state?.pdp && (
        <div data-name="ProductStickyTab" class="cmp_catalog_product_detail_Page">
          <ProductStickyTab {...props} />
        </div>
      )}
    </>
  );
};

export default ProductInformation;
