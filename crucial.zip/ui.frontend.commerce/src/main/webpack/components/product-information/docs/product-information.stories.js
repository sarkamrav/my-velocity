import ProductInformation from "../product-information.hbs";

export default {
  title: "Components/React Component/Product-Information",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { ProductInformation };
