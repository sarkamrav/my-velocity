import React from 'react';
import PropTypes from 'prop-types';
import { ErrorMessage, useField } from 'formik';
import Icon from '../../../assests/Icon';

const Radio = ({ options, isMandatory, label, className, ...props }) => {
  const [field, meta, helpers] = useField(props);
  const hasError = meta.touched && meta.error;

  return (
    <div className={`cmp-acommerce_radio ${className ? className : ''} ${hasError ? 'error' : ''}`}>
      {label && (
        <label htmlFor={field.name}>
          {label}
          {isMandatory && <Icon name="Asterisk" className="mandatory_asterisk" />}
        </label>
      )}
      {options?.map(item => (
        <div className="cmp-acommerce_radio-group" key={item.value}>
          <input
            type="radio"
            id={item.value || item.title}
            value={item.value || item.title}
            name={field.name}
            checked={field.value === (item.value || item.option_type_id)}
            onChange={() => helpers.setValue(item.value || item.option_type_id)} // Set the field value on change
            className="cmp-acommerce_radio-input"
          />
          <label htmlFor={item.value || item.title} className="cmp-acommerce_radio-label">
            {item.label || item.title}
          </label>
        </div>
      ))}
      <ErrorMessage component="div" name={field.name} className="form-input-error" />
    </div>
  );
};

export default Radio;

Radio.propTypes = {
  options: PropTypes.arrayOf(
    PropTypes.shape({
      value: PropTypes.string.isRequired,
      label: PropTypes.string.isRequired,
    })
  ).isRequired,
  name: PropTypes.string.isRequired,
  isMandatory: PropTypes.bool,
  className: PropTypes.string,
};

Radio.defaultProps = {
  isMandatory: false,
};
