import React from 'react';
import PropTypes from 'prop-types';
import { ErrorMessage, useField } from 'formik';
import Icon from '../../../assests/Icon';

const Checkbox = ({ label, className, ...props }) => {
  const [field, meta] = useField(props);
  const hasError = meta.touched && meta.error;

  return (
    <div className={`cmp-acommerce_checkbox ${hasError ? 'error' : ''} ${className}`}>
      <div className="cmp-acommerce_checkbox-group">
        <div className="cmp-acommerce_checkbox-input-group">
          <input
            type="checkbox"
            {...field}
            {...props}
            id={field.name}
            className="cmp-acommerce_checkbox-input"
            checked={field.value ? 'checked' : ''}
          />
          <Icon name="Checkbox" />
        </div>
        <label htmlFor={field.name} className={`cmp-acommerce_checkbox-label ${field.value ? 'bold' : ''}`}>
          {label}
        </label>
      </div>
      <ErrorMessage component="div" name={field.name} className="form-input-error" />
    </div>
  );
};

Checkbox.propTypes = {
  label: PropTypes.string.isRequired,
  className: PropTypes.string,
};

Checkbox.defaultProps = {
  className: '',
};

export default Checkbox;
