import React from 'react';
import PropTypes from 'prop-types';
import Icon from '../../../assests/Icon';

const Link = ({
  href,
  type,
  text,
  isMobileTextShown,
  className,
  target,
  disabled,
  icon,
  media,
  onClick,
  children,
  ...rest
}) => {
  const handleClick = event => {
    if (onClick && !disabled) {
      onClick(event);
    }
  };
  const renderContent = () => {
    switch (type) {
      case 'default':
      case 'headline-link':
        return text;
      case 'cta-link':
        return (
          <>
            <span>{text}</span> <Icon name="ArrowRight" size="link-cta" className="_static" />
            <Icon name="ArrowRightActive" size="link-cta" className="_hover" />
          </>
        );
      case 'heading-cta-link':
        return (
          <>
            <span>{text}</span> <Icon name="ArrowRight" size="headline-link-cta" className="_static" />
            <Icon name="ArrowRightActive" size="headline-link-cta" className="_hover" />
          </>
        );
      case 'icon-link':
        return (
          <>
            {icon && <Icon name={icon} size="headline-link-cta" />}
            <span className={isMobileTextShown ? '' : 'hidetext'}>{text}</span>
            {children}
          </>
        );
      case 'special':
        return (
          <>
            <Icon name={icon} size="headline-link-cta" /> <span>{text}</span>{' '}
            <Icon name="ArrowRight" size="link-cta" className="_static" />
            <Icon name="ArrowRightActive" size="link-cta" className="_hover" />
          </>
        );
      case 'social':
        return <Icon name={media} size="social" />;
      default:
        return text;
    }
  };

  return (
    <a
      className={`cmp-acommerce_link cmp-acommerce_type--${type} ${disabled ? 'disabled' : ''} ${className}`}
      href={href}
      target={target}
      onClick={handleClick}
      {...rest}>
      {renderContent()}
    </a>
  );
};

Link.propTypes = {
  href: PropTypes.string,
  type: PropTypes.oneOf(['default', 'cta-link', 'headline-link', 'heading-cta-link', 'icon-link', 'social', 'special']),
  text: PropTypes.string,
  className: PropTypes.string,
  target: PropTypes.oneOf(['_self', '_blank', '_parent', '_top']),
  disabled: PropTypes.bool,
  icon: PropTypes.string,
  media: PropTypes.string,
  isMobileTextShown: PropTypes.bool,
  onClick: PropTypes.func,
};

Link.defaultProps = {
  type: 'default',
  text: 'Link',
  href: '#',
  className: '',
  target: '_self',
  disabled: false,
  icon: '',
  media: '',
  isMobileTextShown: true,
};

export default Link;
