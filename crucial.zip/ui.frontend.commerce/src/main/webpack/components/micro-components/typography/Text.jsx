import React from 'react';
import PropTypes from 'prop-types';
export default function Text({ className, children }) {
  return (
    <>
      <p className={`cmp-acommerce_typo cmp-acommerce_text ${className}`}>{children}</p>
    </>
  );
}

Text.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
};

Text.defaultProps = {
  className: '',
};
