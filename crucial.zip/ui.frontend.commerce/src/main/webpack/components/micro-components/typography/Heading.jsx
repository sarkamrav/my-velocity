import React from 'react';
import PropTypes from 'prop-types';
export default function Heading({ type, children,className, ...rest }) {
  const Tag = type;
  return (
    <>
      <Tag className={`cmp-acommerce_typo cmp-acommerce_${type} ${className}`} {...rest}>
        {children}
      </Tag>
    </>
  );
}

Heading.propTypes = {
  type: PropTypes.oneOf(['h1', 'h2', 'h3', 'h4', 'h5', 'h6']).isRequired,
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
};

Heading.defaultProps = {
  className: ''
};

