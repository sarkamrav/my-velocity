import React, { useEffect, useState } from 'react';
import Icon from '../../../assests/Icon';
import PropTypes from 'prop-types';
import { ErrorMessage, useField, useFormikContext } from 'formik';

const useOptionalFormikContext = () => {
  try {
    return useFormikContext();
  } catch (error) {
    return null;
  }
};

const useOptionalField = (props, formikContext) => {
  if (formikContext) {
    return useField(props);
  } else {
    const [fieldValue, setFieldValue] = useState('');
    const [fieldTouched, setFieldTouched] = useState(false);
    const [fieldError, setFieldError] = useState('');

    const setValue = value => setFieldValue(value);
    const setTouched = touched => setFieldTouched(touched);
    const setError = error => setFieldError(error);

    return [
      { value: fieldValue, name: props.name },
      { touched: fieldTouched, error: fieldError },
      { setValue, setTouched, setError },
    ];
  }
};

const Dropdown = ({ options, label, isMandatory, sortByTitle, isDisabled, className, ...props }) => {
  const formikContext = useOptionalFormikContext();
  const [field, meta, { setValue }] = useOptionalField(props, formikContext);

  const hasError = meta.touched && meta.error;

  useEffect(() => {
    if (props.selectedValue) {
      setValue(props.selectedValue);
    }
  }, []);

  return (
    <div className={`cmp-acommerce_dropdown ${className}`}>
      {label && (
        <label className="cmp-acommerce_dropdown-label">
          {label}
          {isMandatory && <span className="mandatory_asterisk">*</span>}
        </label>
      )}
      <div className="cmp-acommerce_dropdown-group">
        {sortByTitle && <option className="sortby">{sortByTitle} </option>}
        <select
          className={`cmp-acommerce_dropdown-select ${field.value !== '' ? 'selected' : ''} ${
            sortByTitle ? 'padLeft' : ''
          }`}
          {...field}
          {...props}
          onChange={e => {
            setValue(e.target.value);
            props.onChange && typeof props.onChange === 'function' && props.onChange(e);
          }}
          disabled={isDisabled}>
          {options.map((optionGroup, index) =>
            optionGroup.hasOwnProperty('optGroup') ? (
              <optgroup label={optionGroup.optGroup} key={optionGroup.optGroup}>
                {optionGroup.options.map(option => (
                  <option key={option.label + index} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </optgroup>
            ) : (
              optionGroup.options.map(option => (
                <>
                  <option key={option.label + index} value={option.value}>
                    {' '}
                    {option.label}
                  </option>
                </>
              ))
            )
          )}
        </select>
      </div>
      {hasError && !isDisabled && formikContext && (
        <ErrorMessage component="div" name={field.name} className="cmp-acommerce_dropdown-error form-input-error" />
      )}
    </div>
  );
};

Dropdown.propTypes = {
  label: PropTypes.string,
  isMandatory: PropTypes.bool,
  isDisabled: PropTypes.bool,
  className: PropTypes.string,
  options: PropTypes.arrayOf(
    PropTypes.shape({
      optGroup: PropTypes.string,
      options: PropTypes.arrayOf(
        PropTypes.shape({
          value: PropTypes.string.isRequired,
          label: PropTypes.string.isRequired,
        })
      ),
    })
  ),
};

Dropdown.defaultProps = {
  isMandatory: false,
  isDisabled: false,
  className: '',
};

export default Dropdown;
