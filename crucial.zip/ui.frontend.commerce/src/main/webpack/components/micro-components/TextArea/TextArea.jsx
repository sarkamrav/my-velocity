import React from 'react';
import PropTypes from 'prop-types';

import { ErrorMessage, useField } from 'formik';
import Icon from '../../../assests/Icon';

const TextArea = ({ label, isMandatory, className, ...props }) => {
  const [field, meta] = useField(props);

  const hasError = meta.touched && meta.error;

  return (
    <div className={`cmp-acommerce_text-area ${className}`}>
      <label htmlFor={field.name}>
        {label}
        {isMandatory && <span className="mandatory_asterisk">*</span>}
      </label>
      <textarea {...field} {...props} className={`${hasError ? 'is-invalid' : 'valid'}`} />
      <ErrorMessage component="div" name={field.name} className="text-error" />
    </div>
  );
};

TextArea.propTypes = {
  label: PropTypes.string.isRequired,
};

TextArea.defaultProps = {
  label: 'Text Area',
};

export default TextArea;
