import React from 'react';
import PropTypes from 'prop-types';
import Icon from '../../../assests/Icon';

const Button = ({ type, onClick, children, className, disabled, icon, ...rest }) => {
  // const buttonClassName = `cmp-acommerce_button button-${disabled ? 'disabled' : type} ${className}`;

  const handleClick = event => {
    if (onClick && !disabled) {
      onClick(event);
    }
  };

  return (
    <button
      className={`cmp-acommerce_button button-${disabled ? 'disabled' : type} ${className}`}
      onClick={handleClick}
      disabled={disabled}
      aria-label={type === 'social' ? `Social Button: ${icon}` : ''}
      {...rest}>
      {type === 'social' ? <Icon name={icon} size="small" /> : children}
    </button>
  );
};

Button.propTypes = {
  type: PropTypes.oneOf(['primary', 'secondary', 'social', 'media-text']),
  onClick: PropTypes.func,
  children: PropTypes.node,
  disabled: PropTypes.bool,
  className: PropTypes.string,
  icon: PropTypes.string,
};

Button.defaultProps = {
  type: 'primary',
  disabled: false,
  className: '',
  icon: '',
};

export default Button;
