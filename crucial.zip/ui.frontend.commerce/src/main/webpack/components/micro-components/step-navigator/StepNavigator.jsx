import React from 'react';
import PropTypes from 'prop-types';

const StepNavigator = ({ type, steps, activeStep, className, ...rest }) => {
  return (
    <div className="cmp-acommerce_step-navigator">
      <ul className={`cmp-acommerce_steps step-navigator_${type}`}>
        {steps.map((step, index) => (
          <li
            key={index}
            className={`cmp-acommerce_step ${activeStep === index ? '_active' : ''} ${
              activeStep > index ? '_completed' : ''
            } ${className}`}
            {...rest}>
            {step.title}
          </li>
        ))}
      </ul>
    </div>
  );
};

StepNavigator.propTypes = {
  type: PropTypes.string,
  steps: PropTypes.arrayOf(
    PropTypes.shape({
      title: PropTypes.string.isRequired,
    })
  ).isRequired,
  activeStep: PropTypes.number.isRequired,
  className: PropTypes.string,
};

StepNavigator.defaultProps = {
  type: 'primary',
  className: '',
};

export default StepNavigator;
