import React, { useEffect, useState  } from "react";
import Button from "../../micro-components/Button/Button";
import useModal from "../../../hooks/useModal";
import ModalPopup from "../../modal-popup/ModalPopup";
import AddToCartModal from "../../product-information/components/add-to-cart-modal/AddToCartModal";
import { useMutation } from "@apollo/client";
import { ADD_PRODUCTS_TO_CART, CREATE_EMPTY_CART } from "../../../site/js/gql/mutations/cart.gql";
import { getCookie } from "../../../utils/cookies_operation";
import Loader from "../../micro-components/Loader/Loader";
 
export default function CustomButton({ ...props }) {
  const { cartCta, doNotshow, imgUrl, priceFinal, priceRegular, sku, title, inSearchbar } = props;
  const { isShowing: isConfirmationShowing, toggle: toggleConfirmation } = useModal();
  const cartQty = 1;
  const configProduct = [];

  function parseCurrencyString(currencyString) {
      // Remove everything except digits, commas, dots, and the minus sign
      let cleanedString = currencyString.replace(/[^\d,.-]/g, '');

      // Handle the case where both commas and dots are present
      if (cleanedString.includes(',') && cleanedString.includes('.')) {
          // Assume the dot is the decimal separator and remove commas
          cleanedString = cleanedString.replace(/,/g, '');
      } else if (cleanedString.includes(',')) {
          // If only commas are present, replace them with dots
          cleanedString = cleanedString.replace(',', '.');
      }

      // Convert the cleaned string to a float number
      let number = parseFloat(cleanedString);

      // Return the parsed number or NaN if parsing failed
      return isNaN(number) ? null : number;
  }

  let regPrice = parseCurrencyString(priceRegular);
  let finalPrice = parseCurrencyString(priceFinal);
  const handleViewCart = () => {
    setShowConfirmPopup(false);
  }
  const [showConfirmPopup, setShowConfirmPopup] = useState(false);
  const btnHandler = () => {
    addProductToCart({
      variables: {
        cartId: JSON.parse(getCookie('cart_id')),
        SKU: sku,
        quantity: parseFloat(cartQty),
      },
    });
  }

  useEffect(() => {
    let previousScript = document.getElementById('cswidgetjs');
    if (previousScript) {
      previousScript.remove();
    }
    const script = document.createElement('script');
    script.src = 'https://cscoreproweustor.blob.core.windows.net/widget/scripts/cswidget.loader.js';
    script.async = true;
    document.body.appendChild(script);
    return () => {
      document.body.removeChild(script);
    };
  }, []);

    // Define mutation for adding products to cart
    const [addProductToCart, { error: addToCartError, loading: cartDataLoading }] = useMutation(ADD_PRODUCTS_TO_CART, {
      onCompleted(data) {
        if (data.core_addProductsToCart.user_errors.length <= 0) {
          toggleConfirmation();
        }
      },
    });

    const [createEmptyCart] = useMutation(CREATE_EMPTY_CART, {
          onCompleted(data) {
            setCookie('cart_id', JSON.stringify(data.core_createEmptyCart), 2880);
          },
    });

    if (addToCartError) {
      console.error(addToCartError);
      document.cookie = 'cart_id=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
      createEmptyCart();
    }

    const searchOrPage = (inSearchbar) => {
      if(inSearchbar === 'true'){
        return (<div onClick={btnHandler}>
            <svg className="icon-svg icon-add-shopping-cart">
            <use href="/etc.clientlibs/core/clientlibs/resources/icons-sprite.svg#icon-add-shopping-cart"></use>
          </svg>
          </div>)
      } else {
        return (<Button type="primary" onClick={btnHandler}>{cartCta}</Button>)
      }
    }

  return (
    <>
        {cartDataLoading && <Loader />}
        {doNotshow === 'true' ? '' : searchOrPage(inSearchbar)}
        {isConfirmationShowing && (
        <ModalPopup isShowing={isConfirmationShowing} hide={toggleConfirmation}>
          <AddToCartModal
            productImage={imgUrl}
            productName={title}
            finalPrice={finalPrice}
            configProduct={configProduct}
            regularPrice={regPrice}
            viewCart={handleViewCart}
            continueShopping={toggleConfirmation}
          />
        </ModalPopup>
      )}
    </>
  );
}
 
 