import CustomAddToCart from "../custom-add-to-cart.hbs";

export default {
  title: "Components/React Component/Custom Add to Cart",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { CustomAddToCart };
