import React, { useEffect, useState  } from "react";
import ReactDOM from "react-dom";
import CustomButton from "./components/CustomButton";
 
export default function CustomAddToCart({ ...restProps }) {
  const [elements, setElements] = useState([]);
  const processedElements = new Set();
  useEffect(() => {
    const updateAttributes = () => {
      const targetElements = document.querySelectorAll('[data-component="custom-add-to-cart"]');
      const elementsArray = Array.from(targetElements);
      setElements(elementsArray);
      // Filter out elements that have already been processed
      const newElements = elementsArray.filter(element => !processedElements.has(element));
      newElements.forEach(element => processedElements.add(element));

      setElements(prevElements => [...prevElements, ...newElements]);
    };

    // Initial attribute update
    updateAttributes();

    // Set up a MutationObserver to update attributes on DOM changes
    const observer = new MutationObserver((mutationsList) => {
      for (const mutation of mutationsList) {
        if (mutation.type === 'childList') {
          updateAttributes();
        }
      }
    });

    const aemContainer = document.querySelector('body');
    if (aemContainer) {
      observer.observe(aemContainer, { childList: true, subtree: true });
    }

    // Cleanup observer on component unmount
    return () => {
      observer.disconnect();
    };
  }, []);
  return (
    <>
      {/* {elements.map((element, index) => {
        const props = JSON.parse(JSON.stringify(element.dataset));
         return ReactDOM.createPortal(<CustomButton key={index} {...props}  />, element);
        
      })} */}
      <CustomButton {...restProps} />
    </>
  );
}


