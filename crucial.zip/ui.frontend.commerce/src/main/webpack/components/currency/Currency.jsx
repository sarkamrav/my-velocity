import React, { useState } from 'react';
import { gql, useLazyQuery } from '@apollo/client';
import { getCookie, setCookie } from "../../utils/cookies_operation.js"

export default function Currency({ name }) {
  const CURRENCY_GQL = gql`
    query {
      core_currency {
        base_currency_code
        base_currency_symbol
        default_display_currency_code
        default_display_currency_symbol
        available_currency_codes
        exchange_rates {
          currency_to
          rate
        }
      }
    }
  `;
  const [currencyQueryFired, setCurrencyQueryFired] = useState(false);
//   const { error, loading, data } = useQuery(CURRENCY_GQL);
  const [getCurrency, { error, data }] = useLazyQuery(CURRENCY_GQL);

  if(!isCurrencyAvailable() && !currencyQueryFired) {
      getCurrency();
      setCurrencyQueryFired(true);
  }

  function isCurrencyAvailable() {
     let currencyDetails = getCookie('currency');
     return currencyDetails && (JSON.parse(currencyDetails)?.lang==document.querySelector('[lang]')?.getAttribute('lang'));
  }

  if (data) {
    let currencyObj = {
      currencyCode: data.core_currency.default_display_currency_code,
      currencySymbol: data.core_currency.default_display_currency_symbol,
      lang: document.querySelector('[lang]')?.getAttribute('lang')
    };
//     localStorage.setItem('currency', JSON.stringify(currencyObj));
    //localStorage.getItem('currency'
    setCookie('currency', JSON.stringify(currencyObj), 720);
  }

  if (error) {
    console.log('error while fetching currency details', error.message);
  }
}
