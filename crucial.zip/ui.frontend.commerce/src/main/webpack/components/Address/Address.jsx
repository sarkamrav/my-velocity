import React from 'react';
import { PropTypes } from 'prop-types';

const Address = ({ title, address, email, poNumber }) => {
  return (
    <div className="address-container">
      <p className="address-name">
        <strong>{title}</strong>
      </p>
      <ul className="address-details">
        <li className="address-details-name">
          {address?.firstname} {address?.lastname}
        </li>
        <li>{address?.company}</li>
        {address?.street?.map((addline, index) => (
          <li key={addline + index}>{addline}</li>
        ))}
        <li>
          {address?.city},{' '}
          {address?.region?.code || address?.region?.code === '' || address?.region?.code === null
            ? address?.region?.code
            : address?.region}{' '}
          {address?.postcode}
        </li>
        <li>{address?.country?.code || address?.country_code}</li>
        <li>{address?.telephone}</li>
        {email && <li>{email}</li>}
        {poNumber && <li>{poNumber}</li>}
      </ul>
    </div>
  );
};

Address.propTypes = {
  title: PropTypes.string,
  address: PropTypes.object.isRequired,
  email: PropTypes.string,
  poNumber: PropTypes.string,
};

export default Address;
