import ShoppingCartPage from "../shopping-cart-page.hbs";

export default {
  title: "Components/React Component/Shopping-Cart-Page",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { ShoppingCartPage };
