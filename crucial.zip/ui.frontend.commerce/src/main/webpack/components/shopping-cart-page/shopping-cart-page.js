import React from 'react';
import { createRoot } from 'react-dom/client';
import { StoreProvider } from '../../contexts/common/StoreContext.jsx';
import { ApolloClient, ApolloProvider } from '@apollo/client';
import ApolloClientConfig from '../../configs/ReactApolloClientSetup/ApolloClientConfig.js';
import ShoppingCartPage from './ShoppingCartPage.jsx';

export default class {
  static init(el) {
    const client = new ApolloClient(ApolloClientConfig);
    const props = JSON.parse(JSON.stringify(el.dataset));
    createRoot(el).render(
      <StoreProvider>
        <ApolloProvider client={client}>
          <ShoppingCartPage {...props} />
        </ApolloProvider>
      </StoreProvider>
    );
  }
}
