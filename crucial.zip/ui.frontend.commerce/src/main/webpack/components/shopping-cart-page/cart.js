/* eslint-disable max-len */
export const cartData = {
  data: {
    products: [
      {
        id: '1124912164339',
        qty: '1',
        sku: 'CP2K16G60C36U5B',
        name: 'Crucial Pro Overclocking 32GB Kit (2x16GB) DDR5-6000 UDIMM Black',
        description: 'Save on Crucial SSDs! (Limit 3 discounts per order)',
        img_url: 'https://content.crucial.com/content/dam/crucial/ssd-products/mx500/images/product/crucial-mx500-2-5inch-product-front-image.psd.transform/medium-png/image.png',
        price: {
            regular_price: '$164.99',
            special_price: '$104.99'
        },
        stock: '291',
        url: '/product-detail-page.html'
      },
      {
        id: '1124912164339',
        qty: '1',
        sku: 'CP2K16G60C36U5B',
        name: '2-16GB DDR5-6000 UDIMM 1.35V CL36',
        description: 'Save on Crucial SSDs! (Limit 3 discounts per order)',
        img_url: 'https://content.crucial.com/content/dam/crucial/dram-products/ddr5-pro/overclocking/images/product/crucial-ddr5-pro-overclocking-udimm-kit-front.psd.transform/small-png/image.png',
        price: {
            regular_price: '$164.99',
            special_price: '$104.99'
        },
        stock: '291',
        url: '/product-detail-page.html'
      },
      {
        id: '1124912164339',
        qty: '1',
        sku: 'CP2K16G60C36U5B',
        name: 'Crucial Pro Overclocking 32GB Kit (2x16GB) DDR5-6000 UDIMM Black',
        description: 'Save on Crucial SSDs! (Limit 3 discounts per order)',
        img_url: 'https://content.crucial.com/content/dam/crucial/ssd-products/mx500/images/product/crucial-mx500-2-5inch-product-front-image.psd.transform/medium-png/image.png',
        price: {
            regular_price: '$164.99',
            special_price: '$104.99'
        },
        stock: '291',
        url: '/product-detail-page.html'
      },
    ],
  },
};
