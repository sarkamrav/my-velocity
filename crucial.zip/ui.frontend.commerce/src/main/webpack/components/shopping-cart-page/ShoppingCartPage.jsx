import React, { useCallback, useEffect, useState } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import PromoCode from './components/promo-code/PromoCode';
import EstimateShipping from './components/shipping-information/EstimateShipping';
import SubTotal from './components/subtotal/SubTotal';
import PaymentAction from './components/payment-action/PaymentAction';
import Link from '../micro-components/Link/Link';
import Heading from '../micro-components/typography/Heading';
import GET_CART from '../../site/js/gql/get-cart.gql.js';
import { getCookie } from '../../utils/cookies_operation.js';
import { fetchCartData } from '../../contexts/common/actions/cartaction.js';
import { useStoreContext } from '../../contexts/common/StoreContext.jsx';
import Icon from '../../assests/Icon';
import UPDATE_CART_ITEM from '../../site/js/gql/mutations/update-cart-item.gql';
import Loader from '../micro-components/Loader/Loader';
import REMOVE_ITEM_FROM_CART from '../../site/js/gql/mutations/remove-item-from-cart.gql.js';
import GtmDataLayer from '../gtm-data-layer/GtmDataLayer.jsx';
import { formatLocalePrice } from '../../utils/utils';
import { getCatalogServiceHeaders } from '../../configs/ReactApolloClientSetup/ApolloClientConfig.js';
const ShoppingCartPage = props => {
  // Access store context
  const { state, dispatch } = useStoreContext();

  // State for showing Loader
  const [showLoader, setShowLoader] = useState(false);

  // State for showing update error
  const [showUpdateError, setShowUpdateError] = useState(false);
  const [cartUpdated, setCartUpdated] = useState(false);

  // State for special price
  const [specialPrice, setSpecialPrice] = useState([]);
  const [itemErrors, setItemErrors] = useState({});

  // Query to get cart data
  const { data: cartData, loading: getCartLoading } = useQuery(GET_CART, {
    variables: {
      cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
    },
  });

  // Mutation to update cart item

  const [updateCartItem, { loading: updateCartLoading }] = useMutation(UPDATE_CART_ITEM, {
    onError: (error, { variables }) => {
      setItemErrors(prev => ({ ...prev, [variables.cart_item_uid]: error.message }));
    },
  });

  // Mutation to remove cart item
  const [removeCartItem, { loading: removeCartLoading }] = useMutation(REMOVE_ITEM_FROM_CART);

  // Reference to shopping element
  const shoppingElement = document.querySelector('.cmp-acommerce_shopping-cart-page');

  // Retrieve cart items from store
  const cartItems = state.cart?.cartData?.core_cart?.items || [];

  // State for items
  const [items, setItems] = useState(cartItems);

  const [showQtyChangeMsg, setShowQtyChangeMsg] = useState(false);

  const locale = getCatalogServiceHeaders();

  useEffect(() => {
    document.cookie = 'new_shipping_values=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
  }, []);

  // Update items when cart data changes
  useEffect(() => {
    if (cartItems) {
      setItems(cartItems);
      const result = cartItems.map(item => ({
        uid: item.uid,
        amount: item.product.price.regularPrice.amount.value,
        quantity: item.quantity,
      }));
      setSpecialPrice(result);
    }
  }, [state.cart?.cartData]);

  // Dispatch cart data when it's fetched
  useEffect(() => {
    if (cartData) {
      dispatch(fetchCartData(cartData));
    }
  }, [cartData, dispatch]);

  // Handle quantity change for a cart item
  const handleQuantityChange = (uid, newQuantity) => {
    let Qty = newQuantity && Number(newQuantity) > 1000 ? 1000 : newQuantity;
    Qty = Qty && Number(Qty) < 0 ? 0 : Qty;
    setItems(prevItems =>
      prevItems.map(item => (item.uid === uid ? { ...item, quantity: Qty, showQTYChangeMsg: true } : item))
    );
  };

  // Handle update of cart item quantity
  const handleUpdate = (uid, quantity, event) => {
    event.preventDefault();
    setItemErrors(prev => ({ ...prev, [uid]: null }));
    updateCartItem({
      variables: {
        cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
        cart_item_uid: uid,
        quantity: parseFloat(quantity),
      },
      refetchQueries: [
        {
          query: GET_CART,
          variables: {
            cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
          },
        },
      ],
    }).then(() => setCartUpdated(true));
  };

  // Handle removal of cart item
  const handleRemove = (uid, event) => {
    event.preventDefault();
    const previousItems = [...items];
    setItems(prevItems => prevItems.filter(item => item.uid !== uid));
    removeCartItem({
      variables: {
        cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
        cart_item_uid: uid,
      },
      refetchQueries: [
        {
          query: GET_CART,
          variables: {
            cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
          },
        },
      ],
      onError: () => {
        setItems(previousItems); // Revert to the original state
      },
    }).then(() => setCartUpdated(true));
  };

  // Handle decrease in quantity
  const handleQtyDecrease = useCallback(
    (uid, event) => {
      event.preventDefault();
      setItems(prevItems =>
        prevItems.map(item =>
          item.uid === uid
            ? { ...item, quantity: Math.max(0, Number(item.quantity) - 1), showQTYChangeMsg: true }
            : item
        )
      );
    },
    [items]
  );

  // Handle increase in quantity
  const handleQtyIncrease = useCallback(
    (uid, event) => {
      event.preventDefault();
      setItems(prevItems =>
        prevItems.map(item =>
          item.uid === uid
            ? { ...item, quantity: Math.min(1000, Number(item.quantity) + 1), showQTYChangeMsg: true }
            : item
        )
      );
    },
    [items]
  );

  // Handle click for increasing quantity
  const handleQtyIncreaseClick = uid => event => {
    handleQtyIncrease(uid, event);
  };

  // Handle click for decreasing quantity
  const handleQtyDecreaseClick = uid => event => {
    handleQtyDecrease(uid, event);
  };

  // Handle click for updating quantity
  const handleUpdateClick = (uid, quantity) => event => {
    handleUpdate(uid, quantity, event);
  };

  // Handle click for removing item
  const handleRemoveClick = uid => event => {
    handleRemove(uid, event);
  };

  // Show loader
  useEffect(() => {
    if (getCartLoading || updateCartLoading || removeCartLoading) {
      setShowLoader(true);
    } else {
      setShowLoader(false);
    }
  }, [getCartLoading, updateCartLoading, removeCartLoading]);

  // Retrieve currency symbol
  const currencySymbol = getCookie('currency') && JSON.parse(getCookie('currency')).currencySymbol;

  const productUrls = getCookie('cart_product_urls') && JSON.parse(getCookie('cart_product_urls'));
  // useEffect(()=>{

  // },[cart.quantity]);
  function getPrice(price, qant = 1) {
    return price * qant.toFixed(2);
    // setTotalPrice()
  }

  return (
    <>
      {showLoader && <Loader />}
      <div className="cmp-acommerce_container">
        <div className="cmp-acommerce_main">
          <h1 className="cmp-acommerce_title">{shoppingElement.getAttribute('data-shopping-cart-title')}</h1>
          {cartData && cartData.core_cart.total_quantity !== 0 ? (
            <>
              <div className="cmp-acommerce_cart-notice-wrapper">
                <div className="cmp-acommerce_cart-reference">
                  <p>
                    <strong>{shoppingElement.getAttribute('data-cart-reference-number')}:</strong>{' '}
                    {cartData.core_cart.digital_river.checkout_id}
                  </p>
                </div>
                <div className="cmp-acommerce_notice">
                  <p>{shoppingElement.getAttribute('data-free-express-shipping')}</p>
                  <p>{shoppingElement.getAttribute('data-quantity-limit')}</p>
                </div>
              </div>
              <div className="cmp-acommerce_cart-item-table">
                <form>
                  <div className="cmp-acommerce_table">
                    <div className="cmp-acommerce_thead">
                      <div className="cmp-acommerce_tr">
                        <div className="cmp-acommerce_th col-qty" scope="col">
                          {shoppingElement.getAttribute('data-cart-qty')}
                        </div>
                        <div className="cmp-acommerce_th col-product-name" scope="col">
                          {shoppingElement.getAttribute('data-cart-product-name')}
                        </div>
                        <div className="cmp-acommerce_th col-product-price" scope="col">
                          {shoppingElement.getAttribute('data-cart-price')}{' '}
                          {locale !== 'en_us' && <span>{props.incVat}</span>}
                        </div>
                      </div>
                    </div>
                    <div className="cmp-acommerce_tbody">
                      {items &&
                        items.map((cart, index) => (
                          <div key={index} className="cmp-acommerce_tr">
                            <div className="cmp-acommerce_td col-qty">
                              <div className="cmp-acommerce_cart-qty-wrapper">
                                <span className="cmp-acommerce_cart-qty">
                                  <label htmlFor={`cart_qty_${cart.product.sku}`} className="cmp-acommerce_hidden">
                                    {shoppingElement.getAttribute('data-cart-qty')}
                                  </label>
                                  <input
                                    className="cmp-acommerce_cart-qty"
                                    data-cart-uid={cart.uid}
                                    type="number"
                                    name="cart_qty"
                                    id={`cart_qty_${cart.product.sku}`}
                                    value={cart.quantity}
                                    onChange={e => handleQuantityChange(cart.uid, e.target.value)}
                                  />
                                  <button
                                    className="cmp-acommerce_qty-update cmp-acommerce_button-up"
                                    type="button"
                                    onClick={handleQtyIncreaseClick(cart.uid)}>
                                    +
                                  </button>
                                  <button
                                    className="cmp-acommerce_qty-update cmp-acommerce_button-down"
                                    type="button"
                                    disabled={cart.quantity === 1}
                                    onClick={handleQtyDecreaseClick(cart.uid)}>
                                    -
                                  </button>
                                </span>
                                <span className="cmp-acommerce_cart-qty-update">
                                  <button
                                    className="cmp-acommerce_cart-action"
                                    onClick={handleUpdateClick(cart.uid, cart.quantity)}>
                                    {shoppingElement.getAttribute('data-update')}
                                  </button>
                                  {itemErrors[cart.uid] && (
                                    <div className="update-item-error-message">{itemErrors[cart.uid]}</div>
                                  )}
                                </span>
                                <span className="cmp-acommerce_cart-qty-remove">
                                  <Icon name="Delete" size="icon-pdp" />
                                  <button className="cmp-acommerce_cart-action" onClick={handleRemoveClick(cart.uid)}>
                                    {shoppingElement.getAttribute('data-remove')}
                                  </button>
                                </span>
                                {cart.showQTYChangeMsg && (
                                  <span className="cmp-acommerce_update-text">
                                    {shoppingElement.getAttribute('data-qty-change-text')}
                                  </span>
                                )}
                              </div>
                              {showUpdateError && (
                                <span className="dr_qtyError">
                                  {shoppingElement.getAttribute('data-please-update')}
                                </span>
                              )}
                            </div>
                            <div className="cmp-acommerce_td col-product-name">
                              <div className="cmp-acommerce_productName">
                                <div className="prod_thumbnail">
                                  <a
                                    href={productUrls?.find(product => product.sku === cart.product.sku)?.url || ''}
                                    target="_blank"
                                    rel="noopener noreferrer">
                                    <img
                                      loading="lazy"
                                      className="cmp-acommerce_productThumbnail"
                                      src={cart.product.image.url}
                                      alt={cart.product.image.label}
                                    />
                                  </a>
                                </div>
                                <div className="prod_info">
                                  <a
                                    href={productUrls?.find(product => product.sku === cart.product.sku)?.url || ''}
                                    target="_blank"
                                    rel="noopener noreferrer">
                                    <span className="cmp-acommerce_lineItemProductName">{cart.product.name}</span>
                                  </a>
                                  <div className="stock-status">
                                    {shoppingElement.getAttribute('data-in-stock')} - {cart.availableInStockQty}
                                  </div>
                                  <div>
                                    {shoppingElement.getAttribute('data-sku')} {cart.product.sku}
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="cmp-acommerce_td col-product-price">
                              <div
                                className={`product-pricing ${
                                  (
                                    specialPrice.find(ele => ele?.uid === cart?.uid)?.amount *
                                    specialPrice.find(ele => ele?.uid === cart?.uid)?.quantity
                                  ).toFixed(2) > cart?.prices?.row_total?.value
                                    ? 'special'
                                    : 'regular'
                                }`}>
                                <span className="regular-price price">
                                  {specialPrice?.map((price, index) => {
                                    return (
                                      <React.Fragment key={index}>
                                        {price?.uid === cart?.uid &&
                                          formatLocalePrice(price?.amount * price?.quantity, currencySymbol)}
                                      </React.Fragment>
                                    );
                                  })}
                                </span>
                                <span className="special-price price">
                                  {formatLocalePrice(cart?.prices?.row_total?.value, currencySymbol)}{' '}
                                </span>
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                </form>
              </div>
              <PromoCode />
              <EstimateShipping cartUpdated={cartUpdated} setCartUpdated={setCartUpdated} />
              <SubTotal />
              <PaymentAction referenceId={cartData?.core_cart?.digital_river?.checkout_id} {...props} />
              <GtmDataLayer cartData={cartData} />
              <p className="cmp-accomerce_cartPricingDisclaimer">
                <strong>
                  <Link text={shoppingElement.getAttribute('data-important-update')} type="secondary" target="_blank" />
                </strong>{' '}
                {shoppingElement.getAttribute('data-prices-offers')}
              </p>
            </>
          ) : (
            <div className="cmp-acommerce_empty-cart">
              {!getCartLoading ? (
                <>
                  <Heading type="h3" className="cmp-acommerce_empty-cart-title">
                    {shoppingElement.getAttribute('data-empty-cart-message')}
                  </Heading>
                  <GtmDataLayer basicGtmData="true" />
                </>
              ) : (
                ''
              )}
              <Link type="default" href="/" text={shoppingElement.getAttribute('data-continue-shopping')} />
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default ShoppingCartPage;
