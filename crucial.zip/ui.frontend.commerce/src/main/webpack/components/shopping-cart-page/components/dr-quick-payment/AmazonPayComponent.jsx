import React, { useEffect } from 'react';
import { getShoppingUrls } from '../../../../site/js/urlresolver';

function AmazonPayComponent({ element, sessionId }) {
  useEffect(() => {
    const digitalriver = new DigitalRiver(element.getAttribute('data-dr-public-key'));

    // Amazon Payment Service
    const options = {
      style: {
        color: 'Gold', // one of ['Gold', 'LightGray', 'DarkGray']
      },
      classes: {
        empty: 'cmp-acommerce_amazon-pay-element',
        base: 'cmp-acommerce_amazon-pay-element',
        invalid: 'cmp-acommerce_amazon-pay-element',
        complete: 'cmp-acommerce_amazon-pay-element',
      },
      sourceData: {
        type: 'amazonPay',
        sessionId,
        country: 'US', //to be updated
        amazonPay: {
          returnUrl: `${window.location.origin}${getShoppingUrls().orderVerifyURL}`,
          resultReturnUrl: `${window.location.origin}${getShoppingUrls().orderVerifyURL}`,
          cancelUrl: window.location.href,
          placement: 'Checkout',
        },
      },
    };
    const amazonpay = digitalriver.createElement('amazonpay', options);
    amazonpay.mount('amazonpay');
  }, [element, sessionId]);

  return null;
}

export default AmazonPayComponent;
