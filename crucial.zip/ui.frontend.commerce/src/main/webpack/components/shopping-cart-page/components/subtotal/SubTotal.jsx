import React from 'react';
import PropTypes from 'prop-types';
import { useStoreContext } from '../../../../contexts/common/StoreContext';
import { getCookie } from '../../../../utils/cookies_operation.js';
import { formatLocalePrice } from '../../../../utils/utils.js';

const SubTotal = () => {
  // Reference to shopping element
  const shoppingElement = document.querySelector('.cmp-acommerce_shopping-cart-page');
  const { state } = useStoreContext();
  const grandTotal = state.cart?.cartData?.core_cart?.prices?.grand_total || {};
  const updatedGrandTotalInt = state.cart?.cartData?.core_cart?.prices?.updated_grand_total;
  const updatedGrandTotal = updatedGrandTotalInt ? parseFloat(updatedGrandTotalInt).toFixed(2) : 0;

  const discount = state.cart?.cartData?.core_cart?.prices?.discount || {};
  const currencySymbol = getCookie('currency') && JSON.parse(getCookie('currency')).currencySymbol;

  return (
    <>
      {discount.amount !== undefined && (
        <div className="cmp-accommerce_discount-wrapper">
          <div className="discount-container">
            <div className="discount_title">{shoppingElement.getAttribute('data-discount')}</div>
            <div className="discount_offer">
              {shoppingElement.getAttribute('data-order-offer')}{' '}
              {discount?.label?.map((label, index) => (index !== discount?.label?.length - 1 ? `${label} | ` : label))}
            </div>
          </div>
          <div className="discount-value-container">
            <div className="discount_value">
              {'-'}
              {formatLocalePrice(discount?.amount?.value, currencySymbol)}
            </div>
          </div>
        </div>
      )}

      <div className="cmp-accommerce_subtotal-wrapper">
        <div className="subtotal_title">{shoppingElement.getAttribute('data-sub-total')}</div>
        <div className="subtotal_value">
          {formatLocalePrice(updatedGrandTotal || grandTotal?.value, currencySymbol)}
        </div>
      </div>
    </>
  );
};

SubTotal.propTypes = {
  grandTotal: PropTypes.shape({
    currency: PropTypes.string,
    value: PropTypes.number,
  }),
};

export default SubTotal;
