import React, { useEffect, useState } from 'react';
import { useStoreContext } from '../../../../contexts/common/StoreContext.jsx';
import { setCookie } from '../../../../utils/cookies_operation';
import { getShoppingUrls } from '../../../../site/js/urlresolver';
import { getCurrentLocalFromPage } from '../../../../site/js/utils/get-locale';

function Paypal() {
  const { state } = useStoreContext();
  const cartData = state?.cart?.cartData?.core_cart || {};
  const { digital_river } = cartData || {};
  const element = document.querySelector('[data-name="ShoppingCartPage"]');
  const [loadPaypalScript, setLoadPaypalScript] = useState(false);
  const [loadDrScript, setLoadDrScript] = useState(false);

  useEffect(() => {
    const scriptDr = document.createElement('script');
    scriptDr.src = 'https://js.digitalriver.com/v1/DigitalRiver.js';
    scriptDr.type = 'text/javascript';
    scriptDr.async = true;
    scriptDr.onload = () => {
      setLoadDrScript(true);
    };
    document.body.appendChild(scriptDr);

    const scriptPaypal = document.createElement('script');
    scriptPaypal.src = 'https://www.paypalobjects.com/api/checkout.js';
    scriptPaypal.type = 'text/javascript';
    scriptPaypal.async = true;
    scriptPaypal.onload = () => {
      setLoadPaypalScript(true);
    };
    document.body.appendChild(scriptPaypal);
  }, []);

  useEffect(() => {
    if (loadPaypalScript && loadDrScript && digital_river?.session_id) {
      const digitalriver = new DigitalRiver(element.getAttribute('data-dr-public-key'));
      const paypalSourceData = {
        type: 'payPal',
        requestShipping: true,
        sessionId: digital_river?.session_id,
        payPal: {
          returnUrl: `${window.location.origin}${getShoppingUrls().orderVerifyURL}`,
          cancelUrl: window.location.href,
        },
      };

      const payPalElement = document.getElementById('paypal-button');
      if (payPalElement.hasChildNodes()) {
        payPalElement.innerHTML = '';
      }

      paypal.Button.render(
        {
          env: element.getAttribute('data-dr-env'),
          locale: getCurrentLocalFromPage(),
          style: {
            label: 'checkout',
            size: 'responsive',
            color: 'gold',
            shape: 'rect',
            layout: 'horizontal',
            tagline: 'false',
          },
          payment: () => {
            return digitalriver.createSource(paypalSourceData).then(result => {
              if (result.error) {
                console.error('result.error', result);
              } else {
                return result.source.payPal.token;
              }
            });
          },
          onAuthorize: data => {
            setCookie('checkout_id', JSON.stringify(digital_river?.checkout_id));
            window.location = data.returnUrl;
          },
          onCancel: data => {
            console.log('inside onCancel', data);
          },
        },
        '#paypal-button'
      );
    }
  }, [loadPaypalScript, loadDrScript, digital_river]);

  return <div id="paypal-button" style={{ position: 'relative' }}></div>;
}

export default Paypal;
