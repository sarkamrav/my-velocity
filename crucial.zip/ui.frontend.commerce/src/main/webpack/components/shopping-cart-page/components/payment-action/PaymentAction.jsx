import React, { useState } from 'react';
import Button from '../../../micro-components/Button/Button';
import Link from '../../../micro-components/Link/Link';
import { getUserTokenFromLoaclStorate } from '../../../../configs/ReactApolloClientSetup/ApolloClientConfig';
import { getShoppingUrls } from '../../../../site/js/urlresolver.js';
import QuickPayments from '../dr-quick-payment/QuickPayments';

export default function PaymentAction({ referenceId, ...props }) {
  // Reference to shopping element
  const shoppingElement = document.querySelector('.cmp-acommerce_shopping-cart-page');
  const [consentCheck, setConsentCheck] = useState(true);
  const handleCheckout = () => {
    if (getUserTokenFromLoaclStorate()) {
      window.location = getShoppingUrls().billingURL;
      //window.location = "/shop/billing-info";
    } else {
      window.location = getShoppingUrls().guestURL;
      //window.location = "/shop/guest-checkout";
    }
  };

  return (
    <div className="cmp-accomerce_payment-action-wrapper">
      <div className="link-to-home">
        <Button type="secondary" className="go-to-home" onClick={() => (window.location = '/')}>
          {shoppingElement.getAttribute('data-continue-shopping')}
        </Button>
      </div>
      <div className="cart_payment">
        <div className="consent-checkbox">
          <div className="cmp-accomerce_checkbox-field">
            <input
              type="checkbox"
              name="cmp-accomerce_consent"
              id="cmp-accomerce_consent"
              defaultChecked={consentCheck}
            />
            <label htmlFor="cmp-accomerce_consent" className="cmp-accomerce_checkbox checkbox-primary">
              <div>
                {shoppingElement.getAttribute('data-by-clicking')}{' '}
                <Link
                  type="secondary"
                  text={shoppingElement.getAttribute('data-privacy-policy')}
                  className="cmp-accomerce_privacyPolicy"
                  link="/store/defaults/en_US/DisplayDRPrivacyPolicyPage/eCommerceProvider.DR+globalTech+Inc."
                  target="_blank"
                />
                {shoppingElement.getAttribute('data-and')}{' '}
                <Link
                  type="secondary"
                  text={shoppingElement.getAttribute('data-terms')}
                  className="cmp-accomerce_termsAndConditions"
                  link="/store/defaults/en_US/DisplayDRTermsAndConditionsPage/eCommerceProvider.DR+globalTech+Inc."
                  target="_blank"
                />{' '}
                {shoppingElement.getAttribute('data-of')}{' '}
                <Link
                  type="secondary"
                  text={shoppingElement.getAttribute('data-dr-global')}
                  className="cmp-accomerce_aboutDigitalRiver"
                  link="/store/defaults/en_US/DisplayDRAboutDigitalRiverPage/eCommerceProvider.DR+globalTech+Inc."
                  target="_blank"
                />
              </div>
            </label>
          </div>
        </div>
        {referenceId ? <QuickPayments {...props} /> : <p className="reference-error">Not a valid reference Number</p>}

        <Button
          type="primary"
          className="go-to-checkout"
          disabled={!referenceId ? true : false}
          onClick={handleCheckout}>
          {shoppingElement.getAttribute('data-checkout')}
        </Button>
      </div>
    </div>
  );
}
