import React from 'react';
import AmazonPay from './AmazonPay';
import GooglePay from './GooglePay';
import Paypal from './Paypal';
import ApplePay from './ApplePay';

function QuickPayments(props) {
  return (
    <>
      <div className="cmp-acommerce_quick-payments cmp-acommerce_quick-payments_googlepay">
        <ApplePay />
      </div>
      <div className="cmp-acommerce_quick-payments cmp-acommerce_quick-payments_googlepay">
        <GooglePay />
      </div>
      <div className="cmp-acommerce_quick-payments cmp-acommerce_quick-payments_amazon">
        <AmazonPay {...props} />
      </div>
      <div className="cmp-acommerce_quick-payments cmp-acommerce_quick-payments_amazon">
        <Paypal />
      </div>
      <div className="cmp-acommerce_separator">OR</div>
    </>
  );
}

export default QuickPayments;
