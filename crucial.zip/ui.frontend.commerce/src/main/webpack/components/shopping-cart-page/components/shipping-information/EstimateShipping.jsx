import React, { useState, useEffect, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { useLazyQuery, useQuery } from '@apollo/client';
import Dropdown from '../../../micro-components/Dropdown/Dropdown';
import useModal from '../../../../hooks/useModal.jsx';
import { updateCartGrandTotal } from '../../../../contexts/common/actions/cartaction.js';
import { useStoreContext } from '../../../../contexts/common/StoreContext.jsx';
import { getCookie, setCookie } from '../../../../utils/cookies_operation.js';
import { COUNTRY_QUERY } from '../../../../site/js/gql/countries.gql';
import { GET_ESTIMATED_SHIPPING_METHODS_QUERY } from '../../../../site/js/gql/get-estimated-shipping-methods.gql';
import {
  getCatalogServiceHeaders,
  clientConfigUsingGet,
} from '../../../../configs/ReactApolloClientSetup/ApolloClientConfig';
import Accordion from './Accordion/Accordion';
import ModalPopup from '../../../../components/modal-popup/ModalPopup.jsx';
import { formatLocalePrice, isTablet } from '../../../../utils/utils';
import Icon from '../../../../assests/Icon';
import Loader from '../../../../components/micro-components/Loader/Loader';

export default function EstimateShipping({ cartUpdated, setCartUpdated }) {
  // Reference to shopping element
  const shoppingElement = document.querySelector('.cmp-acommerce_shopping-cart-page');
  const currencySymbol = getCookie('currency') && JSON.parse(getCookie('currency')).currencySymbol;
  const locale = getCatalogServiceHeaders();
  const { state, dispatch } = useStoreContext();

  const grandTotal = state.cart?.cartData?.core_cart?.prices?.grand_total || {};
  const [loader, setLoader] = useState(false);
  const [shippingRate, setShippingRate] = useState('0.00');
  const [shippingMethod, setShippingMethod] = useState('');
  const [showTooltip, setShowTooltip] = useState(false);

  const [shippingMethodOptions, setShippingMethodOptions] = useState([]);
  const [accordionItems, setAccordionItems] = useState([]);

  const { toggle: toggleModal } = useModal();
  // To get countries on page load
  const gqlClientFotGet = useMemo(() => clientConfigUsingGet(), []);
  const {
    loading: countryQueryLoading,

    data: countryQueryData,
  } = useQuery(COUNTRY_QUERY, { client: gqlClientFotGet });
  const [
    getEstimatedShippingMethods,
    { loading: methodsQueryLoading, error: methodsQueryError, data: methodsQueryData, refetch: refetchMethods },
  ] = useLazyQuery(GET_ESTIMATED_SHIPPING_METHODS_QUERY);

  const [selectedCountry, setSelectedCountry] = useState(
    locale?.includes('_') ? locale?.split('_')[1]?.toUpperCase() : locale?.toUpperCase()
  );
  const element = document.querySelector('[data-name="ShoppingCartPage"]');

  useEffect(() => {
    let i = 1;
    let items = [];
    do {
      items.push({
        id: i,
        header: (
          <div dangerouslySetInnerHTML={{ __html: element.getAttribute('data-shipping-info-tooltip-clause' + i) }} />
        ),
        content: (
          <div
            dangerouslySetInnerHTML={{ __html: element.getAttribute('data-shipping-info-tooltip-clause-details' + i) }}
          />
        ),
      });
      i++;
    } while (
      element?.getAttribute('data-shipping-info-tooltip-clause' + i) &&
      element?.getAttribute('data-shipping-info-tooltip-clause-details' + i)
    );

    setAccordionItems(items);
  }, []);

  // To trigger states query when a country is selected
  useEffect(() => {
    if (selectedCountry) {
      setLoader(true);
      getEstimatedShippingMethods({
        variables: {
          country: selectedCountry,
          cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
        },
      })
        .then(data => {
          setCartUpdated(false);
          if (data?.data?.core_getEstimatedShippingMethods && data.data.core_getEstimatedShippingMethods.length > 0) {
            setShippingMethodOptions(data.data.core_getEstimatedShippingMethods);
            setShippingMethod(data.data.core_getEstimatedShippingMethods[0].method_code);
            setShippingRate(data.data.core_getEstimatedShippingMethods[0].price);
            updateSubTotal(data.data.core_getEstimatedShippingMethods[0].price);
            
          } else {
            setShippingMethodOptions([]);
            setShippingRate('0.00');
            setShippingMethod('');
            if (grandTotal.value) {
              updateSubTotal(0);
            }
          }
          setLoader(false);
        })
        .catch(error => console.log(`Server responed with an error - ${error.message}`));
    } else {
      setShippingMethodOptions([]);
      setShippingRate('0.00');
      setShippingMethod('');
      if (grandTotal.value) {
        updateSubTotal(0);
      }
    }
  }, [selectedCountry,state.cart?.cartData?.core_cart?.prices?.grand_total]);

  useEffect(() => {
    if (cartUpdated) {
      setLoader(true);
      refetchMethods({
        variables: {
          country: selectedCountry,
          cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
        },
      })
        .then(data => {
          setCartUpdated(false);
          if (data?.data?.core_getEstimatedShippingMethods && data.data.core_getEstimatedShippingMethods.length > 0) {
            setShippingMethodOptions(data.data.core_getEstimatedShippingMethods);
            setShippingMethod(data.data.core_getEstimatedShippingMethods[0].method_code);
            setShippingRate(data.data.core_getEstimatedShippingMethods[0].price);
            updateSubTotal(data.data.core_getEstimatedShippingMethods[0].price);
          } else {
            setShippingMethodOptions([]);
            setShippingRate('0.00');
            setShippingMethod('');
            if (grandTotal.value) {
              updateSubTotal(0);
            }
          }
          setLoader(false);
        })
        .catch(error => console.log(`Server responed with an error - ${error.message}`));
    }
  }, [cartUpdated,state.cart?.cartData?.core_cart?.prices?.grand_total]);

  const handleSetShippingCountry = e => {
    setSelectedCountry(e.target.value);
  };
  // To populate dropdowns with an initial state
  const initialOptions = [
    {
      options: [
        {
          value: '',
          label: 'Select One',
        },
      ],
    },
  ];
  // Initial values for countries to be later populated by the API
  const [countries, setCountries] = useState(initialOptions);
  // To populate countries on receiving from API
  useEffect(() => {
    if (countryQueryData) {
      let countriesArrayOptions = initialOptions;
      countryQueryData.core_countries.map(item => {
        countriesArrayOptions.map(countriesOptions => {
          countriesOptions.options.push({
            value: item.id,
            label: item.full_name_english,
          });
        });
      });
      setCountries(countriesArrayOptions);
    }
  }, [countryQueryData]);

  const countryLabel = () => {
    return (
      <>
        <span>{element.getAttribute('data-shipping-info-country-label')} </span>

        {locale === 'en_us' || locale === 'en_gb' ? (
          <>
            <span className="cmp-acommerce_shipping-label-subtext">
              {element.getAttribute('data-shipping-info-country-tooltip-text')}
            </span>
            <span className="cmp-acommerce_shipping-tooltip-icon" onClick={() => setShowTooltip(true)}>
              <Icon name="InfoIcon" size="small" />
            </span>
            {showTooltip && !isTablet() && getTooltipInfoText()}
          </>
        ) : (
          ''
        )}
      </>
    );
  };

  const getTooltipInfoText = () => {
    return (
      <div className="cmp-acommerce_shipping-tooltip right">
        <span class="arrow left-arrow"></span>
        <h6>{element.getAttribute('data-shipping-info-tooltip-heading')}</h6>
        <span
          onClick={() => {
            setShowTooltip(false);
          }}
          className="close">
          {/* <Button type="social" icon="Cross" /> */}
          <Icon name="Cross" size="small" />
        </span>
        {accordionItems.length > 1 ? (
          <Accordion items={accordionItems} />
        ) : (
          <>
            <h3 className="tooltip-item-header">{accordionItems?.[0]?.header}</h3>
            <div
              className="tooltip-content"
              // {...(!showText1 && { hidden: true })}
            >
              {accordionItems?.[0]?.content}
            </div>
          </>
        )}
        {element.getAttribute('data-shipping-info-tooltip-postscript') ? (
          <>
            <div className="seperator"></div>
            <div
              className="footer"
              dangerouslySetInnerHTML={{ __html: element.getAttribute('data-shipping-info-tooltip-postscript') }}></div>
          </>
        ) : (
          ''
        )}
      </div>
    );
  };

  const updateSubTotal = price => {
    // as the numbers can be string with different decimal places we want end result with 2 decimals
    const newGrandTotal = parseFloat(Number(grandTotal.value) + Number(price)).toFixed(2);
    setCookie(
      'new_shipping_values',
      JSON.stringify({ newGrandTotal, estimatedShipPrice: price, selectedCountry }),
      2880
    );
    //TODO: when does this have to be removed
    dispatch(updateCartGrandTotal(newGrandTotal));
  };

  return (
    <>
      <div className="cmp-acommerce_shipping-wrapper">
        <div className="cmp-acommerce_shipping-title">
          <p>{element.getAttribute('data-shipping-info-heading')}</p>
        </div>

        <div className="cmp-acommerce_shipping-calculator-wrapper">
          <form className="cmp-acommerce_shipping-input">
            <div className="field shipping-country">
              <label htmlFor="shipping_country" className="cmp-acommerce_hidden">
                {shoppingElement.getAttribute('data-shipping-country')}
              </label>
              <Dropdown
                className="input-field-wrapper"
                options={countries}
                name="country_code"
                label={countryLabel()}
                selectedValue={selectedCountry}
                onChange={e => handleSetShippingCountry(e)}
              />
            </div>
            <div className="field shipping-methods">
              {shippingMethodOptions.length > 0
                ? shippingMethodOptions.map((shipping, index) => {
                    return (
                      <div
                        onClick={() => {
                          setShippingRate(
                            shipping?.price?.includes(',')
                              ? Number(shipping?.price?.replaceAll(',', '.')).toFixed(2)
                              : shipping.price
                          );
                          setShippingMethod(shipping.method_code);
                          updateSubTotal(
                            shipping?.price?.includes(',')
                              ? Number(shipping?.price?.replaceAll(',', '.')).toFixed(2)
                              : shipping.price
                          );
                        }}
                        key={`shipping_method_${shipping.method_code}_${index}`}
                        className="shipping-method">
                        <input
                          type="radio"
                          name="shipping_method"
                          id={`shipping_method_${shipping.method_code}`}
                          value={shipping.shipping_method_label}
                          checked={shippingMethod === shipping.method_code}
                        />
                        <label htmlFor={`shipping_method_${shipping.method_code}`}>
                          {shipping.shipping_method_label}
                        </label>
                      </div>
                    );
                  })
                : shoppingElement.getAttribute('data-no-shipping')}
            </div>
          </form>
          <div className="cmp-acommerce_shipping-rate">
            <span className="cmp-acommerce_shipping-rate-value">{formatLocalePrice(shippingRate, currencySymbol)}</span>
          </div>
        </div>
      </div>
      {showTooltip && isTablet() && (
        <div className="cmp-acommerce_shipping-tooltip-modal">
          <ModalPopup closeTitle="" isShowing={showTooltip} hide={() => toggleModal()} className="auth-popup">
            {getTooltipInfoText()}
          </ModalPopup>
        </div>
      )}
      {(methodsQueryLoading || countryQueryLoading || loader) && createPortal(<Loader />, document.body)}
    </>
  );
}
