import React, { useEffect, useState, Suspense, lazy } from 'react';
import { Helmet } from 'react-helmet';
import { useStoreContext } from '../../../../contexts/common/StoreContext.jsx';
import Button from '../../../micro-components/Button/Button.jsx';
import Loader from '../../../micro-components/Loader/Loader.jsx';

const AmazonPayComponent = lazy(() => import('./AmazonPayComponent'));

function AmazonPay(props) {
  const { state } = useStoreContext();
  const cartData = state?.cart?.cartData?.core_cart || [];
  const { digital_river } = cartData || {};
  const [loadDrScript, setLoadDrScript] = useState(false);
  const [scriptError, setScriptError] = useState(null);
  const [retryCount, setRetryCount] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const element = document.querySelector('[data-name="ShoppingCartPage"]');
  const { retryCta, scriptErrorTitle, scriptErrorNotLoadedTitle } = props;
  const loadScript = (retry = false) => {
    setIsLoading(true); // Start the loader
    setScriptError(false);

    if (!element) {
      console.error('Element with data-name "ShoppingCartPage" not found');
      setIsLoading(false);
      return;
    }

    const scriptDr = document.createElement('script');
    scriptDr.src = 'https://js.digitalriver.com/v1/DigitalRiver.js';
    scriptDr.type = 'text/javascript';
    scriptDr.async = true;

    const loadStartTime = performance.now();
    console.log(`AmazonPay Script load started at: ${loadStartTime}`);

    scriptDr.onload = () => {
      const loadEndTime = performance.now();
      console.log(`AmazonPay Script loaded at: ${loadEndTime}`);
      console.log(`AmazonPay Time taken to load the script: ${loadEndTime - loadStartTime} ms`);

      const executionStartTime = performance.now();
      console.log(`AmazonPay Script execution started at: ${executionStartTime}`);

      if (window.DigitalRiver) {
        console.log('DigitalRiver script executed successfully');
        setLoadDrScript(true);
        setScriptError(null); // Clear any previous errors
      } else {
        setTimeout(() => {
          if (!window.DigitalRiver) {
            console.error('DigitalRiver script loaded but did not execute correctly');
            setScriptError('DigitalRiver script loaded but did not execute correctly');
            setScriptError(scriptErrorNotLoadedTitle);
          }
        }, 5000);
      }

      const executionEndTime = performance.now();
      console.log(`AmazonPay Script execution ended at: ${executionEndTime}`);
      console.log(`AmazonPay Time taken to execute the script: ${executionEndTime - executionStartTime} ms`);
      // Stop the loader after script execution
    };

    scriptDr.onerror = error => {
      console.error('An error occurred while loading the DigitalRiver script', error);
      setScriptError(scriptErrorTitle);
      setIsLoading(false); // Stop the loader on error
    };

    document.body.appendChild(scriptDr);
    if (retry === true) {
      setIsLoading(false);
      setRetryCount(retryCount + 1);
    } else {
      setIsLoading(false);
    }

    return () => {
      document.body.removeChild(scriptDr);
    };
  };

  const handleRetry = () => {
    if (retryCount < 1) {
      setRetryCount(retryCount + 1);
      loadScript(true);
    } else {
      console.log('Max retry attempts reached');
      setScriptError(null); // Remove the error after 2 failed attempts
    }
  };

  useEffect(() => {
    loadScript(); // Initial load of the script
  }, [element]);

  return (
    <>
      <Helmet>
        <link rel="preload" href="https://js.digitalriver.com/v1/DigitalRiver.js" as="script" />
      </Helmet>
      <div id="amazonpay"></div>
      {isLoading && <Loader />} {/* Show loader when isLoading is true */}
      {scriptError && (
        <div className="script-amazonpay-error">
          {scriptError}
          {retryCount < 1 && (
            <Button type="secondary" className="retry-error-cta" onClick={handleRetry}>
              {retryCta}
            </Button>
          )}
        </div>
      )}
      {loadDrScript && digital_river?.session_id && (
        <Suspense fallback={<div>Loading...</div>}>
          <AmazonPayComponent element={element} sessionId={digital_river.session_id} />
        </Suspense>
      )}
    </>
  );
}

export default AmazonPay;
