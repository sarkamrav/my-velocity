import React, { useEffect, useState } from 'react';
import { useLazyQuery, useMutation } from '@apollo/client';
import { getCookie } from '../../../../utils/cookies_operation.js';
import APPLY_PROMO_CODE from '../../../../site/js/gql/mutations/apply-promo-code.gql';
import REMOVE_PROMO_CODE from '../../../../site/js/gql/mutations/remove-promo-code.gql';
import Button from '../../../micro-components/Button/Button';
import { useStoreContext } from '../../../../contexts/common/StoreContext';
import Loader from '../../../micro-components/Loader/Loader';
import GET_CART from '../../../../site/js/gql/get-cart.gql';

export default function PromoCode() {
  // Reference to shopping element
  const shoppingElement = document.querySelector('.cmp-acommerce_shopping-cart-page');
  // State variables for managing promo code functionality
  const [showPromoCode, setShowPromoCode] = useState(false);
  const [showStatus, setShowStatus] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [formData, setFormData] = useState('');
  const { state } = useStoreContext();

  // State for showing Loader
  const [showLoader, setShowLoader] = useState(false);

  // Effect to update formData when promo code changes in the cart
  useEffect(() => {
    if (state?.cart?.cartData?.core_cart?.applied_coupon?.code) {
      setFormData({ promo_code: state?.cart?.cartData?.core_cart?.applied_coupon?.code });
    }
  }, [state?.cart?.cartData?.core_cart?.applied_coupon?.code]);

  // mutations for applying and removing promo codes
  const [applyPromoCode, { loading: applyPromoCodeLoading }] = useMutation(APPLY_PROMO_CODE);
  const [removePromoCode, { loading: removePromoCodeLoading }] = useMutation(REMOVE_PROMO_CODE);

  // Query to get cart data
  const { loading: getCartLoading } = useLazyQuery(GET_CART);

  // Handler for input change in the promo code input field
  const handleChange = e => {
    setFormData({ promo_code: e.target.value });
  };

  // Show loader
  useEffect(() => {
    if (applyPromoCodeLoading || removePromoCodeLoading || getCartLoading) {
      setShowLoader(true);
    } else {
      setShowLoader(false);
    }
  }, [applyPromoCodeLoading, removePromoCodeLoading, getCartLoading]);

  // Handler for applying promo code
  const handleApplyPromoCode = event => {
    event.preventDefault();
    applyPromoCode({
      variables: {
        cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
        coupon_code: formData.promo_code,
      },
      refetchQueries: [
        {
          query: GET_CART,
          variables: {
            cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
          },
        },
      ],
    })
      .then(response => {
        if (response.data) {
          setShowStatus('success');
          setErrorMessage('Promo code applied');
          setTimeout(() => {
            setErrorMessage('');
            setShowStatus('');
          }, 3000);
        }
      })
      .catch(err => {
        if (err) {
          setShowStatus('error');
          setErrorMessage(err.message);
          setTimeout(() => {
            setErrorMessage('');
            setShowStatus('');
          }, 3000);
        }
      });
  };

  // Handler for removing promo code
  const handleRemovePromoCode = event => {
    event.preventDefault();
    removePromoCode({
      variables: {
        cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
      },
      refetchQueries: [
        {
          query: GET_CART,
          variables: {
            cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
          },
        },
      ],
    })
      .then(response => {
        if (response.data) {
          setShowStatus('success');
          setErrorMessage('Promo code removed');
          setTimeout(() => {
            setErrorMessage('');
            setShowStatus('');
            setFormData({ promo_code: '' });
          }, 3000);
        }
      })
      .catch(err => {
        if (err) {
          setShowStatus('error');
          setErrorMessage(err.message);
          setTimeout(() => {
            setErrorMessage('');
            setShowStatus('');
          }, 3000);
        }
      });
  };

  // Render the promo code component
  return (
    <>
      {showLoader && <Loader />}
      <div className="cmp-acommerce_promocode-wrapper">
        <div className="cmp-acommerce_promocode-title">
          <p>
            {shoppingElement.getAttribute('data-enter')}{' '}
            <span
              className="cmp-acommerce_promocode-link"
              onClick={() => {
                setShowPromoCode(!showPromoCode);
              }}>
              {shoppingElement.getAttribute('data-promo-code')}
            </span>
          </p>
        </div>
        {showPromoCode && (
          <div className="cmp-acommerce_promocode-form">
            <form onSubmit={handleApplyPromoCode}>
              <p>
                <span className="promocodeNote">{shoppingElement.getAttribute('data-please-note')}</span>{' '}
                {shoppingElement.getAttribute('data-coupons')}
              </p>
              <div className="form-input">
                <label htmlFor="promo_code" className="cmp-acommerce_hidden">
                  {shoppingElement.getAttribute('data-promo-code-caps')}
                </label>
                <input
                  type="text"
                  name="promo_code"
                  id="cmp-acommerce_promo_code"
                  size="10"
                  value={formData.promo_code}
                  onChange={handleChange}
                  disabled={state?.cart?.cartData?.core_cart?.applied_coupon?.code}
                  required
                />
                <Button
                  type="primary"
                  className="btn-promo-code _apply"
                  onClick={handleApplyPromoCode}
                  disabled={state?.cart?.cartData?.core_cart?.applied_coupon?.code}>
                  {shoppingElement.getAttribute('data-apply')}
                </Button>
                <Button
                  type="primary"
                  className="btn-promo-code _remove"
                  onClick={handleRemovePromoCode}
                  disabled={!state?.cart?.cartData?.core_cart?.applied_coupon?.code}>
                  {shoppingElement.getAttribute('data-remove')}
                </Button>
                <div className="cmp-acommerce_promo_code_error_message">
                  {showStatus === 'success' && (
                    <span className="cmp-acommerce_alert promo_success">{errorMessage}</span>
                  )}
                  {showStatus === 'error' && <span className="cmp-acommerce_alert promo_error">{errorMessage}</span>}
                </div>
              </div>
            </form>
          </div>
        )}
      </div>
    </>
  );
}
