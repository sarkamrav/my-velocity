export const country_option = [
  { value: 'united_state', label: 'United State' },
  { value: 'india', label: 'India' },
];
export const shipping_method_option = [
  {
    shipping_label: 'Express Shipping (2-4 business days)',
    shipping_method: 'express_shipping',
    shipping_rate: '$0.00',
  },
  {
    shipping_label: 'One Day Shipping (within 24 hours)',
    shipping_method: 'oneday_shipping',
    shipping_rate: '$50.00',
  },
  {
    shipping_label: 'Premium Shipping (within 4 hours)',
    shipping_method: 'premium_shipping',
    shipping_rate: '$150.00',
  },
];
