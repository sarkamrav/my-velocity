import React, { useEffect, useState } from 'react';
import { useStoreContext } from '../../../../contexts/common/StoreContext';
import { getCookie, setCookie } from '../../../../utils/cookies_operation';
import { useMutation } from '@apollo/client';
import {
  QUICK_SET_PAYMENT_METHOD_TO_CART,
  QUICK_SET_SHIPPING,
  SET_SHIPPING_METHOD,
} from '../../../../site/js/gql/mutations/cart-quick-action.gql';
import Loader from '../../../micro-components/Loader/Loader';
import { ASSIGN_EMAIL_GUEST } from '../../../../site/js/gql/mutations/checkout.gql';
import { getShoppingUrls } from '../../../../site/js/urlresolver';
import {getUserTokenFromLoaclStorate} from "../../../../configs/ReactApolloClientSetup/ApolloClientConfig";

function GooglePay() {
  const { state } = useStoreContext();
  const cartData = state?.cart?.cartData?.core_cart || {};
  const { items, prices, digital_river } = cartData;
  const [cartItem, setCartItem] = useState([]);
  const [country, setCountry] = useState('');
  const [grandTotal, setGrandTotal] = useState(0);
  const [currency, setCurrency] = useState('');
  const [dropinSeesionId, setDropinSessionId] = useState('');
  const [isEnabledGpay, setIsEnableGpay] = useState(false);

  useEffect(() => {
    const htmlLang = document.documentElement.getAttribute('lang');
    if (htmlLang) {
      const parts = htmlLang.split('-');
      if (parts.length === 2) {
         setCountry(`${parts[1].toUpperCase()}`);
      }
    }
  }, []);

  useEffect(() => {
    if (digital_river?.session_id !== '' && digital_river?.session_id !== undefined) {
      setGrandTotal(prices?.grand_total?.value);
      setCurrency(prices?.grand_total?.currency);
      setDropinSessionId(digital_river?.session_id);
      const itemsArray = items.map(item => ({
        amount: item.prices.row_total.value,
        label: item.product.name,
      }));
      setCartItem(itemsArray);
    }
  }, [cartData]);

  useEffect(() => {
    if (grandTotal && currency && digital_river?.session_id) {
      setIsEnableGpay(true);
    }
  }, [grandTotal, currency, dropinSeesionId]);

  // Mutation
  const [setShipping, { loading: setShippingLoading }] = useMutation(QUICK_SET_SHIPPING);
  const [setShippingMethod] = useMutation(SET_SHIPPING_METHOD);
  const [setPayementMethod, { loading: paymentLoading }] = useMutation(QUICK_SET_PAYMENT_METHOD_TO_CART);
  const [assignGuestEmail, { loading: assignEmailLoading }] = useMutation(ASSIGN_EMAIL_GUEST);

  // Query selector
  const element = document.querySelector('[data-name="ShoppingCartPage"]');
  // Function for shipping method
  function extractShippingMethods(response, id) {
    return response.map(method => ({
      id: method.method_code,
      label: method.carrier_title,
      detail: method.carrier_code,
      amount: method.amount.value,
      selected: method.method_code === id ? true : false,
    }));
  }

  useEffect(() => {
    if (isEnabledGpay) {
      const script = document.createElement('script');
      script.src = 'https://js.digitalriverws.com/v1/DigitalRiver.js';
      script.type = 'text/javascript';
      script.async = true;
      script.onload = () => {
        const digitalRiver = new DigitalRiver(element.getAttribute('data-dr-public-key'));
        const paymentRequestData = digitalRiver.paymentRequest({
          country: country,
          currency: currency,
          total: {
            label: element.getAttribute('data-order-total'),
            amount: grandTotal,
          },
          displayItems: cartItem,
          requestShipping: true,
          shippingOptions: [],
          success: true,
          style: {
            buttonType: 'long',
            buttonColor: 'dark',
            buttonRadius: 50,
          },
          sessionId: dropinSeesionId,
        });

        const googlepay = digitalRiver.createElement('googlepay', paymentRequestData);

        if (googlepay.canMakePayment()) {
          googlepay.mount('googlepay-element');
          document.getElementById('googlepay-element').style.display = 'block';
        }

        googlepay.on('source', async function (event) {
          const source = event.source;
          if (source) {
            if (!getUserTokenFromLoaclStorate()) {
              await assignGuestEmail({
                variables: {
                  cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
                  email: source.owner.email,
                },
              });
            }
            let street;
            if (source.owner.address) {
              street = [
                source.owner.address.line1 || element.getAttribute('data-address-line1'),
                source.owner.address.line2 || element.getAttribute('data-address-line2')
              ];
            } else {
              street = [element.getAttribute('data-address-line1'), element.getAttribute('data-address-line2')];
            }
            await setShipping({
              variables: {
                cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
                city: source.owner.address.city,
                countryCode: source.owner.address.country,
                postcode: source.owner.address.postalCode,
                region: source.owner.address.state,
                street: street,
                firstname: source.owner.firstName,
                lastname: source.owner.lastName,
                telephone: source.owner.phoneNumber,
              },
            });
            await setPayementMethod({
              variables: {
                cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
                source_id: source.id,
                additional_data: JSON.stringify(source),
                code: 'dr_drop_in_payment',
              },
            }).then(response => {
              event.complete('success');
              setCookie('crucialPaymentSource', JSON.stringify(source));
              window.location.href = `${getShoppingUrls().thankYouURL}?order_number=${
                response?.data?.core_placeOrder?.order?.order_number
              }`;
            });
          }
        });

        googlepay.on('shippingaddresschange', function (event) {
          if (event.shippingAddress) {
            const shippingAddress = event.shippingAddress;
            let street, firstname, lastname, telephone;
            if (shippingAddress && shippingAddress.address) {
              street = [
                shippingAddress.address.line1 || element.getAttribute('data-address-line1'),
                shippingAddress.address.line2 || element.getAttribute('data-address-line2')
              ];
            } else {
              street = [element.getAttribute('data-address-line1'), element.getAttribute('data-address-line2')];
            }

            if (shippingAddress && shippingAddress.firstName) {
              firstname = shippingAddress.firstName;
            } else {
              firstname = element.getAttribute('data-given-name');
            }

            if (shippingAddress && shippingAddress.lastName) {
              lastname = shippingAddress.lastName;
            } else {
              lastname = element.getAttribute('data-family-name');
            }

            if (shippingAddress && shippingAddress.phone) {
              telephone = shippingAddress.phone;
            } else {
              telephone = '9988776655';
            }
            setShipping({
              variables: {
                cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
                city: shippingAddress.address.city,
                countryCode: shippingAddress.address.country,
                postcode: shippingAddress.address.postalCode,
                region: shippingAddress.address.state,
                street: street,
                firstname: firstname,
                lastname: lastname,
                telephone: telephone,
              },
            }).then(res => {
              if (
                res.data.core_setShippingAddressesOnCart.cart.shipping_addresses[0].available_shipping_methods.length
              ) {
                const extractedShipping = extractShippingMethods(
                  res.data.core_setShippingAddressesOnCart.cart.shipping_addresses[0].available_shipping_methods
                );
                setShippingMethod({
                  variables: {
                    cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
                    carrierCode: extractedShipping[0].detail,
                    methodCode: extractedShipping[0].id,
                  },
                }).then(response => {
                  const updatedShippingOption = {
                    status: 'success',
                    total: {
                      label: element.getAttribute('data-new-total'),
                      amount: response.data.core_setShippingMethodsOnCart.cart.prices.grand_total.value,
                    },
                    displayItems: cartItem,
                    shippingOptions: extractedShipping,
                  };
                  event.updateWith(updatedShippingOption);
                });
              }
            });
          }
        });

        googlepay.on('shippingoptionchange', function (event) {
          const shippingOption = event.shippingOption;
          if (shippingOption) {
            setShippingMethod({
              variables: {
                cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
                carrierCode: shippingOption.detail,
                methodCode: shippingOption.id,
              },
            }).then(response => {
              const extractedShipping = extractShippingMethods(
                response.data.core_setShippingMethodsOnCart.cart.shipping_addresses[0].available_shipping_methods,
                shippingOption.id
              );
              const updatedShippingOption = {
                status: 'success',
                total: {
                  label: element.getAttribute('data-new-total'),
                  amount: response.data.core_setShippingMethodsOnCart.cart.prices.grand_total.value,
                },
                displayItems: cartItem,
                shippingOptions: extractedShipping,
              };
              event.updateWith(updatedShippingOption);
            });
          }
        });
      };

      script.onerror = (error) => {
        console.error(error);
      };

      document.head.appendChild(script);

      return () => {
        document.head.removeChild(script);
      };
    }
  }, [isEnabledGpay]);

  return (
    <>
      {setShippingLoading || assignEmailLoading || (paymentLoading && <Loader />)}
      <div id="googlepay-element"></div>
    </>
  );
}

export default GooglePay;
