import React, { useState } from 'react';
import PropTypes from 'prop-types';

import Icon from '../../../../../assests/Icon';

const Accordion = ({ items }) => {
  const [expandedIndex, setExpandedIndex] = useState(null);

  const toggleItem = index => {
    setExpandedIndex(index === expandedIndex ? null : index);
  };

  return (
    <>
      <ul className="cmp-acommerce_shopping-cart-container" role="tablist">
        {items.map((item, index) => (
            <li key={index} className={`cmp-acommerce_shopping-cart-items ${index === expandedIndex ? '__active' : ''}`}>
                <a
                    className={`cmp-acommerce_shopping-cart-header ${index === expandedIndex ? '__active' : ''}`}
                    onClick={() => toggleItem(index)}
                    aria-expanded={`${index === expandedIndex ? true : false}`}>
                    <Icon name={`${index === expandedIndex ? 'Minus' : 'Plus'}`} size="accordion"/>
                    <span>{item.header}</span>
                </a>
                <div
                    id={item.id}
                    className="cmp-acommerce_shopping-cart-content"
                    aria-hidden={`${index === expandedIndex ? false : true}`}>
                    {item.content}
                </div>
            </li>
        ))}
      </ul>
    </>
  );
};

Accordion.propTypes = {
    items: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.string.isRequired,
            header: PropTypes.string.isRequired,
            content: PropTypes.string.isRequired,
        })
    ).isRequired,
    defaultExpandedIndex: PropTypes.number,
};

Accordion.defaultProps = {
    defaultExpandedIndex: null,
};

export default Accordion;
