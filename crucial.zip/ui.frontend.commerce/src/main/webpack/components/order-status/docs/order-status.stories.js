import OrderStatus from "../order-status.hbs";

export default {
  title: "Components/React Component/Order-Status",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { OrderStatus };
