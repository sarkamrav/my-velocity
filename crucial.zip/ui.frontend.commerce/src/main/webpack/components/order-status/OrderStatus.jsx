import React, { useState, useEffect } from 'react';
import { Formik, Form } from 'formik';
import InputField from '../inputfield/InputField';
import * as Yup from 'yup';
import Button from '../micro-components/Button/Button';
import Heading from '../heading/Heading';
import Link from '../micro-components/Link/Link';
import PropTypes from 'prop-types';
import useModal from '../../hooks/useModal';
import ModalPopup from '../modal-popup/ModalPopup';
import { gql, useQuery, useLazyQuery } from '@apollo/client';
import ForgetPassword from '../forget-password/ForgetPassword';
import ORDER_LOOKUP from '../../site/js/gql/order-lookup.gql';
import OrderDetail from '../order-detail/OrderDetail';
import Loader from '../micro-components/Loader/Loader';
import Icon from '../../assests/Icon';
import LoginForm from '../login/component/loginform/LoginForm';
import CreateAccount from '../create-account/CreateAccount';
import { getShoppingUrls } from '../../site/js/urlresolver';
import { generateMessage } from '../../utils/utils';
import InfoBanner from '../info-banner/InfoBanner';
import GtmDataLayer from '../gtm-data-layer/GtmDataLayer';
export default function OrderStatus({
  displayHeading,
  displaySubHeading,
  displayGuidelines,
  displayFormHeadline,
  displayOrderNumberLabel,
  displayOrderNumberError,
  displayPasswordLabel,
  displayPasswordError,
  displayFindOrderLabel,
  displayForgotPasswordLabel,
  displayForgotPasswordLink,
  displayOr,
  displayEmailLabel,
  displayEmailError,
  displayEmailInvalidError,
  displayCreditCardLabel,
  displayCreditCardError,
  displayBackLabel,
  displayBackLink,
  signInTitle,
  signInLabel,
  signInDescription,
  useFieldTitle,
  useFieldInfoLine1,
  useFieldInfoLine2,
  useFieldInfoLine3,
  displayLegacyOrders,
  ...restProps
}) {
  const validationSchemaOrder = Yup.object().shape({
    orderNumber: Yup.string().required(`${displayOrderNumberError}`),
    email: Yup.string().email(`${displayEmailInvalidError}`).required(`${displayEmailError}`),
  });

  const { isShowing: isLoginConfirmation, toggle: loginToggleConfirmation } = useModal();
  const { isShowing: isCAConfirmation, toggle: caToggleConfirmation } = useModal();
  const { isShowing: isForgetPasswordLogin, toggle: forgetToggleConfirmation } = useModal();

  const handleUserForm = () => {
    loginToggleConfirmation();
    caToggleConfirmation();
  };

  const forgetPasswordHandler = () => {
    loginToggleConfirmation();
    forgetToggleConfirmation();
  };

  const cancelFormHandler = () => {
    loginToggleConfirmation();
  };

  const createAccountHandler = event => {
    console.log('event', event);
    if (event === 'login') {
      caToggleConfirmation();
      loginToggleConfirmation();
    }

    if (event === 'shopping') {
      caToggleConfirmation();
      loginToggleConfirmation();
    }
  };

  const [getOrderLookup, { error: queryError, loading: queryLoading, data: queryData }] = useLazyQuery(ORDER_LOOKUP);
  const array = JSON.parse(displayGuidelines);

  const [langAttribute, setLangAttribute] = useState('');
  useEffect(() => {
    const htmlTag = document.querySelector('html');
    const lang = htmlTag.getAttribute('lang');
    setLangAttribute(lang.replace('-', '_'));
  }, []);

  useEffect(() => {
    if (queryData) {
      setLookupDetail(queryData);
    }
  }, [queryData]);

  const handleButtonClick = values => {
    if (values.orderNumber && values.email) {
      window.location.href = `${getShoppingUrls()?.orderDetailURL}?order_number=${values.orderNumber}&&email=${
        values.email
      }`;
    }
  };

  return (
    <>
      {queryLoading && <Loader />}
      <section className="cmp-acommerce_order-status__section">
        <div className="custom-container">
          <InfoBanner message={generateMessage()} />
          <p className="headinginfo">{displayHeading} </p>
          <div className="cmp-acommerce_order-status__info">
            <div className="cmp-acommerce_order-status__main">
              <div className="cmp-acommerce_order-status__guidelines">
                <p className="cmp-acommerce_order-status__sub-heading">{displaySubHeading}</p>
                <span className="field-label-info">{useFieldTitle}</span>
                <ul>
                  {array.map((item, index) => (
                    <li className="cmp-acommerce_order-status__description" key={index}>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="cmp-acommerce_order-status__forms">
                <Formik
                  initialValues={{
                    orderNumber: '',
                    email: '',
                  }}
                  validationSchema={validationSchemaOrder}>
                  {({ values, errors, touched, isSubmitting }) => (
                    <Form className="cmp-acommerce_order-status__form">
                      <div className="cmp-acommerce_order-status__form-group">
                        <InputField name="orderNumber" label={displayOrderNumberLabel} type="text" isMandatory />
                        <InputField name="email" label={displayEmailLabel} type="text" isMandatory />
                      </div>

                      <Button onClick={() => handleButtonClick(values)}>{displayFindOrderLabel}</Button>
                    </Form>
                  )}
                </Formik>
              </div>
              <p className="link">
                <Link
                  text={displayLegacyOrders}
                  href={`https://gc.digitalriver.com/sstore?Action=DisplayHomePage&SiteID=findmyor&Locale=${langAttribute}`}
                  type=""
                  link=""
                />
              </p>
              <p className="back-link sm-hidden">
                <Icon name="ArrowLeft" />
                <Link text={displayBackLabel} href="/" type="back" link={displayBackLink} />
              </p>
            </div>
            <div className="cmp-acommerce_order-status__login">
              <p className="login_title">{signInTitle}</p>
              <div className="login_description">{signInDescription}</div>
              <Button
                className="login_cta"
                onClick={() => {
                  loginToggleConfirmation();
                }}>
                {signInLabel}
              </Button>
              <p className="back-link lg-hidden">
                <Icon name="ArrowLeft" />
                <Link text={displayBackLabel} href="/" type="back" link={displayBackLink} />
              </p>
            </div>
          </div>
        </div>

        {isLoginConfirmation && (
          <ModalPopup isShowing={isLoginConfirmation} hide={loginToggleConfirmation} className="auth-popup">
            <LoginForm changeFormHandler={handleUserForm} forgetPasswordHandler={forgetPasswordHandler} />
          </ModalPopup>
        )}
        {isCAConfirmation && (
          <ModalPopup className="auth-popup" isShowing={isCAConfirmation} hide={caToggleConfirmation}>
            <CreateAccount cancelFormHandler={cancelFormHandler} createAccountHandler={createAccountHandler} />
          </ModalPopup>
        )}
        {isForgetPasswordLogin && (
          <ModalPopup isShowing={isForgetPasswordLogin} hide={forgetToggleConfirmation} className="auth-popup">
            <ForgetPassword cancelFormHandler={cancelFormHandler} forgetPasswordHandler={forgetPasswordHandler} />
          </ModalPopup>
        )}
        <GtmDataLayer basicGtmData='true'/>
      </section>
    </>
  );
}

OrderStatus.propTypes = {
  displayHeading: PropTypes.string,
  displaySubHeading: PropTypes.string,
  displayGuidelines: PropTypes.string,
  displayFormHeadline: PropTypes.string,
  displayOrderNumberLabel: PropTypes.string,
  displayOrderNumberError: PropTypes.string,
  displayPasswordLabel: PropTypes.string,
  displayPasswordError: PropTypes.string,
  displayFindOrderLabel: PropTypes.string,
  displayForgotPasswordLabel: PropTypes.string,
  displayForgotPasswordLink: PropTypes.string,
  displayOr: PropTypes.string,
  displayEmailLabel: PropTypes.string,
  displayEmailError: PropTypes.string,
  displayEmailInvalidError: PropTypes.string,
  displayCreditCardLabel: PropTypes.string,
  displayCreditCardError: PropTypes.string,
  displayBackLabel: PropTypes.string,
  displayBackLink: PropTypes.string,
  displayLegacyOrders: PropTypes.string,
};

OrderStatus.defaultProps = {
  displayHeading: 'Look Up Your Order',
  displaySubHeading: 'Dont have an account? Look up your order.',
  displayFormHeadline: 'Please enter the following information:',
  displayOrderNumberLabel: 'Order Number:',
  displayOrderNumberError: 'Enter a valid value',
  displayPasswordLabel: 'Password:',
  displayPasswordError: 'Please enter a password',
  displayFindOrderLabel: 'Find Order',
  displayForgotPasswordLabel: 'Forgot your order password?',
  displayForgotPasswordLink: '#',
  displayOr: 'OR',
  displayEmailLabel: 'Email Address:',
  displayEmailError: 'Please enter a valid email address',
  displayEmailInvalidError: 'Please enter a valid email address',
  displayCreditCardLabel: 'Credit Card(last 4 digits)',
  displayCreditCardError: 'Credit Card(last 4 digits)',
  displayBackLabel: 'Back',
  displayBackLink: '#',
  displayLegacyOrders: 'Cant find your order? Click here to view.',
};
