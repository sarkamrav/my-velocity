import React, { useState, useEffect } from 'react';
import { useQuery, useLazyQuery } from '@apollo/client';
import ORDER_DETAIL from '../../site/js/gql/order-detail.gql';
import OrderInfo from './components/OrderInfo/OrderInfo';
import Button from '../micro-components/Button/Button';
import Link from '../micro-components/Link/Link';
import Icon from '../../assests/Icon';
import { getShoppingUrls } from '../../site/js/urlresolver';
import Loader from '../micro-components/Loader/Loader';
import ORDER_LOOKUP from '../../site/js/gql/order-lookup.gql';
import { generateMessage } from '../../utils/utils';
import InfoBanner from '../info-banner/InfoBanner';
import GtmDataLayer from '../gtm-data-layer/GtmDataLayer';
export default function OrderDetail({
  displayHeading,
  displayReturnLabel,
  displayInvoiceLabel,
  displayBackLabel,
  lookupDetail,
  noInfoFound,
  unauthorized,
  ...restProps
}) {
  const orderNumber = new URLSearchParams(window.location.search).get('order_number');
  const email = new URLSearchParams(window.location.search).get('email');
  const [error, setError] = useState('');
  const [setQueryFired] = useState(false);
  const [setLookupQueryFired] = useState(false);
  const [requestReturn, setRequestReturn] = useState(false);

  const {
    error: queryError,
    loading: queryLoading,
    data: queryData,
  } = useQuery(ORDER_DETAIL, {
    variables: { orderNumber },
    skip: email,
    onCompleted: () => setQueryFired(true),
  });

  const [getOrderLookup, { error: statusQueryError, loading: statusQueryLoading, data: statusQueryData }] =
    useLazyQuery(ORDER_LOOKUP, {
      onCompleted: () => setLookupQueryFired(true),
    });

  const [orderdetail, setOrderDetail] = useState(lookupDetail);

  let user_token = localStorage.getItem('user_token');

  useEffect(() => {
    if (user_token && orderNumber) {
      setOrderDetail(queryData);
    } else if (orderNumber && email && statusQueryData) {
      setOrderDetail(statusQueryData);
    } else {
      getOrderLookup({
        variables: {
          orderNumber: orderNumber,
          email: email,
        },
      });
    }
  }, [queryData, user_token, statusQueryData, orderNumber]);

  const datalen = queryData?.core_customer?.orders?.total_count === 0;
  useEffect(() => {
    if (user_token && !orderdetail && !queryLoading && datalen) {
      setError(noInfoFound);
    } else if (!user_token && queryError && orderNumber) {
      setError(queryError?.message || unauthorized);
    } else if (statusQueryError && orderNumber && email) {
      setError(statusQueryError?.message || noInfoFound);
    } else if (!statusQueryData && user_token && !queryData && !queryLoading && !statusQueryLoading) {
      setError(noInfoFound);
    } else if (queryLoading && queryData) {
      setError('');
    } else {
      setError('');
    }
  }, [user_token, queryError, queryLoading, statusQueryError]);

  const orderDate = queryData?.core_customer?.orders?.items[0]?.order_date;
  const showInvoice = orderdetail?.core_customer?.orders?.items[0]?.invoices?.length > 0;

  const redirection = () => {
    if (user_token) {
      window.location.href = getShoppingUrls()?.orderHistoryPageURL;
    } else {
      window.location.href = getShoppingUrls()?.orderSearchURL;
    }
  };

  const orderReturnRedirection = () => {
    window.location.href = `${getShoppingUrls()?.orderReturnPageURL}?order_number=${
      orderdetail?.core_customer?.orders?.items[0]?.number
    }`;
  };

  useEffect(() => {
    if (orderdetail) {
      const ordersItem = orderdetail?.core_customer?.orders?.items[0]?.items;
      const eligibleReturn = ordersItem?.some(item => item.eligible_for_return);
      const returnableQuantity = ordersItem?.some(item => item.quantity_returned < item.quantity_invoiced);
      setRequestReturn(eligibleReturn && returnableQuantity);
    }
  }, [orderdetail]);

  return (
    <section className="cmp-acommerce_order-detail-section">
      {(queryLoading || statusQueryLoading) && <Loader />}
      <div className="custom-container">
        <InfoBanner message={generateMessage()} />
        <div className="cmp-acommerce_order-detail__main">
          <p className="headinginfo">{displayHeading} </p>
          <OrderInfo {...restProps} orderdetail={orderdetail} />

          {error && <div className="no_order-error">{error}</div>}

          {orderDate && (
            <div className="cmp-acommerce_order-detail__actions">
              {showInvoice && (
                <Button
                  onClick={() =>
                    (window.location.href = `${getShoppingUrls().invoiceURL}?order_number=${new URLSearchParams(
                      window.location.search
                    ).get('order_number')}`)
                  }>
                  {displayInvoiceLabel}
                </Button>
              )}

              {requestReturn && orderdetail?.core_customer?.orders?.items[0]?.status_code === 'complete' && (
                <Button onClick={orderReturnRedirection}>{displayReturnLabel}</Button>
              )}
            </div>
          )}
          <p className="back-link">
            <Icon name="ArrowLeft" />
            <Link text={displayBackLabel} type="back" onClick={redirection} />
          </p>
        </div>
      </div>
      <GtmDataLayer basicGtmData="true" />
    </section>
  );
}

OrderDetail.defaultProps = {
  displayHeading: 'Order Details',
  displayOrderNumber: 'Order Number:',
  displayOrderDate: 'Order Date:',
  displayOrderStatus: 'Order Status:',
  displayBillingAddress: 'Billing Address',
  displayShippingAddress: 'Shipping Address',
  displayQuantity: 'Qty',
  displayProductName: 'Product Name',
  displayReturnLabel: 'Request A Return',
  displayReturnLink: '#',
  displayInvoiceLabel: 'View Invoice',
  displayBackLabel: 'Look Up Your Order',
  displayBackLink: '#',
};
