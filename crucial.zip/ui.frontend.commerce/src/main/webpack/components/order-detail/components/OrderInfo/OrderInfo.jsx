import React from 'react';
import PropTypes from 'prop-types';
import './order-info.scss';
import Address from '../../../Address/Address';
import { formatDateString } from '../../../../utils/utils';

const OrderInfo = ({
  displayOrderNumber,
  displayOrderDate,
  displayOrderStatus,
  displayBillingAddress,
  displayShippingAddress,
  displayQuantity,
  displayProductName,
  orderdetail,
  trackingLink,
  trackShippent,
  quantityShipped,
  displayReturnHeading,
  displayReturnStatus,
  displayQuantityPendingReturn
}) => {
  let user_token = localStorage.getItem('user_token');
  const returnedItems = orderdetail?.core_customer?.orders?.items[0]?.returns?.items;
  const formattedReturnedItems = returnedItems?.flatMap(returnObj => 
    returnObj?.items?.map(item => ({...item.order_item, status: item.status})));

  let itemsList = '';
  let itemListMain = [];
  if (user_token) {
    itemsList = orderdetail?.core_customer?.orders?.items[0];
    itemListMain = orderdetail?.core_customer?.orders?.items[0]?.items;
    itemListMain = itemListMain?.filter(itemMain => {
      const matchedIndex = formattedReturnedItems.findIndex(itemReturned => itemReturned.id === itemMain.id);
      if (matchedIndex !== -1) {
        const matchedItem = formattedReturnedItems[matchedIndex];
        if (itemMain.quantity_ordered === matchedItem.quantity_returned) {
            formattedReturnedItems.splice(matchedIndex, 1, { ...itemMain });
            return false;
        } else if (itemMain.quantity_ordered > matchedItem.quantity_returned) {
            const updatedItem = { ...matchedItem };
            formattedReturnedItems.splice(matchedIndex, 1, updatedItem);
            return true;
        }
      }
      return true;
  });
  } else {
    itemsList = orderdetail?.core_orderLookup;
    itemListMain = orderdetail?.core_orderLookup?.items;
  }

  const redirection = () => {
    console.log('ittedlist########', itemsList?.shipments[0]?.tracking[0]);
    const trackingUrl = itemsList?.shipments[0]?.tracking[0]?.url;
    if (trackingUrl) {
    window.open(trackingUrl, '_blank');
    }
  };

  // this will return updated qty 
  const uniqueProduct = (pId) => {
    const totalProduct = itemListMain?.find(item => item.id === pId);
    const returnedProduct = formattedReturnedItems?.find(item => item.id === pId);
    return totalProduct?.quantity_ordered - ((returnedProduct)?returnedProduct.quantity_returned : 0);
  };

  return (
    <div className="cmp-acommerce_order-info">
      <ul className="cmp-acommerce_order-info__list">
        {itemsList?.number && (
          <li>
            <strong>{displayOrderNumber} </strong>
            {itemsList?.number}
          </li>
        )}

        {itemsList?.order_date && (
          <li>
            <strong>{displayOrderDate} </strong>
            {formatDateString(itemsList?.order_date)}
          </li>
        )}
        {itemsList?.status && (
          <li>
            <strong>{displayOrderStatus} </strong>
            {itemsList?.status}
          </li>
        )}
        <li>
          {itemsList && (
            <div className="cmp-acommerce_order-info__address-group">
              <Address title={displayBillingAddress} address={itemsList?.billing_address} />
              <Address title={displayShippingAddress} address={itemsList?.shipping_address} />
            </div>
          )}
        </li>
      </ul>
      {itemsList && (
        <div className="cmp-acommerce_order-info__product-table">
          <div className="cmp-acommerce_order-info__product-table__head">
            <div className="product-quantity">
              <strong>{displayQuantity}</strong>
            </div>
            <div className="product-name">
              <strong>{displayProductName}</strong>
            </div>
          </div>
          <div className="cmp-acommerce_order-info__product-table__body">
            {itemListMain?.map((product, index) => (
              <div className="product-row" key={`${product.quantity}-${index}`}>
                <div className="product-quantity">
                  <div className="product-quantity-label lg-hidden">{displayQuantity}</div>
                  <div className="product-quantity-value">{uniqueProduct(product.id)}</div>
                </div>
                <div className="product-name">
                  <div className="product-name-label lg-hidden">{displayProductName}</div>
                  <div className="product-name-value">
                    <span className="product-title">{product.product_name}</span>
                    <ul className="product-list">
                      <li key={`${product.product_sku}-${index}`}>{product.product_sku}</li>
                      {itemsList?.status !== 'Canceled' && (
                      <li>
                        <span>{trackShippent}: </span>
                        <span className="track-shippment-url" onClick={redirection}>
                          {trackingLink}
                        </span>
                      </li>
                      )}
                      <li>
                        <span>{quantityShipped}: </span>
                        <span>{product.quantity_ordered}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* return refund items  */}
      {formattedReturnedItems?.length > 0 && <h3>{displayReturnHeading}</h3>}
      {formattedReturnedItems && formattedReturnedItems?.length > 0 && (
        <div className="cmp-acommerce_order-info__product-table">
          <div className="cmp-acommerce_order-info__product-table__head">
            <div className="product-quantity">
              <strong>{displayQuantity}</strong>
            </div>
            <div className="product-name">
              <strong>{displayProductName}</strong>
            </div>
          </div>
          <div className="cmp-acommerce_order-info__product-table__body">
            {formattedReturnedItems?.map((product, index) => (
              <div className="product-row" key={`${product.quantity}-${index}`}>
                <div className="product-quantity">
                  <div className="product-quantity-label lg-hidden">{displayQuantity}</div>
                  <div className="product-quantity-value">{product.quantity_returned}</div>
                </div>
                <div className="product-name">
                  <div className="product-name-label lg-hidden">{displayProductName}</div>
                  <div className="product-name-value">
                    <span className="product-title">{product.product_name}</span>
                    <ul className="product-list">
                      <li key={`${product.product_sku}-${index}`}>{product.product_sku}</li>
                      <li>{displayReturnStatus} : {product.status}</li>
                      {console.log('itemlist************', itemsList)}
                      {itemsList?.status !== 'Canceled' && (
                      <li>
                        <span>{trackShippent}: </span>
                        <span className="track-shippment-url" onClick={redirection}>
                          {trackingLink}
                        </span>
                      </li>
                      )}
                      <li>
                        <span>{quantityShipped}: </span>
                        <span>{product.quantity_ordered}</span>
                      </li>
                      <li>
                        <span>{displayQuantityPendingReturn}: </span>
                        <span>{product.quantity_returned}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

OrderInfo.propTypes = {
  displayOrderNumber: PropTypes.string,
  displayOrderDate: PropTypes.string,
  displayOrderStatus: PropTypes.string,
  displayBillingAddress: PropTypes.string,
  displayShippingAddress: PropTypes.string,
  displayQuantity: PropTypes.string,
  displayProductName: PropTypes.string,
  displayReturnHeading: PropTypes.string,
  displayReturnStatus: PropTypes.string,
  displayQuantityPendingReturn: PropTypes.string
};

OrderInfo.defaultProps = {
  displayOrderNumber: 'Order Number:',
  displayOrderDate: 'Order Date:',
  displayOrderStatus: 'Order Status:',
  displayBillingAddress: 'Billing Address',
  displayShippingAddress: 'Shipping Address',
  displayQuantity: 'Qty',
  displayProductName: 'Product Name',
  displayReturnHeading: 'Return request',
  displayReturnStatus: 'Status',
  displayQuantityPendingReturn:'Quantity pending return'
};

export default OrderInfo;
