import React, { useState, useEffect } from "react";
import { getCurrentLocalFromPage } from "../../site/js/utils/get-locale";

export default function GtmDataLayer({ basicGtmData, shipping, cartData, orderDetails }) {
  const gtmPageData = document.getElementById('gtm-page-data');
  const scriptGtmTag = document.getElementById("gtm-script-id");
  if (scriptGtmTag && gtmPageData) {
    let gtmDataLayer = {
      siteLocale: getCurrentLocalFromPage(),
      siteId: 'crucial',
      siteCMS: 'Adobe Commerce',
      pageName: window.location.pathname,
      pageType: gtmPageData.getAttribute('data-title'),
      customer: {}
    };

    if (cartData) {
      useEffect(() => {
        let productsArray = [];
        cartData?.core_cart?.items?.map(item => {
          if (item?.product?.sku) {
            let productObj = {
              name: item.product.name,
              displayName: item.product.name,
              id: item.product.uid,
              priceWithoutVAT: '('+item.prices.price.value+'/1)',
              price: '('+item.prices.price.value+'/1)',
              listPrice: '('+item.prices.price.value+'/1)',
              discount: 0,
              category: '',
              brand: 'Micron',
              SKU: item.product.sku,
              partNumber: item.product.sku,
              referenceID: item.product.sku,
              variant: '',
              quantity: item.quantity,
              coupon: 0,
              subscriptionFlag: false,
              initialSubFlag: false,
              trialFlag: false,
              //price_usd: item.prices.price.value,
              //listPrice_usd: item.prices.price.value,
              //discount_usd: 0
            };
            productsArray.push(productObj);
          }
          let tax = cartData?.core_cart?.prices?.total_tax?.value ? Number(cartData?.core_cart?.prices?.total_tax?.value) : 0.00;
          let shippingAmt = Number(shipping ? shipping : 0);
          let subTotal = Number(cartData?.core_cart?.prices?.grand_total.value) - tax;
          var revenue = subTotal + shippingAmt + tax;
          const ecommerceObj = {
            currencyCode: cartData?.core_cart?.prices?.grand_total.currency,
            purchase: {
              actionField: {
                id: cartData?.core_cart?.digital_river?.checkout_id,
                affiliation: 'Adobe Commerce',
                revenue: revenue.toFixed(2),
                shipping: shippingAmt,
                tax: tax,
                subtotal: subTotal.toFixed(2),
                discount: cartData?.core_cart?.prices?.discount?.amount?.value,
                coupon: 0,
                //revenue_usd: cartData?.core_cart?.prices?.grand_total.value,
                //tax_usd: 0,
                //shipping_usd: 0,
                //discount_usd: 0
              }
            }
          }
          gtmDataLayer.ecommerce = ecommerceObj;
          gtmDataLayer.products = productsArray;
        });
        window.dataLayer = window.dataLayer || [];
        window.dataLayer = window.dataLayer.filter(item => {
          return item.siteLocale ? false : true;
        });
        window.dataLayer.push(gtmDataLayer);
        updateScriptTag();
      }, [cartData, shipping]);
    }

    if (basicGtmData) {
      useEffect(() => {
        window.dataLayer = window.dataLayer || [];
        window.dataLayer = window.dataLayer.filter(item => {
          return item.siteLocale ? false : true;
        });
        window.dataLayer.push(gtmDataLayer);
        updateScriptTag();
      }, []);
    }


    if (orderDetails) {
      useEffect(() => {
        let productsArray = [];
        orderDetails?.items?.map(item => {
          if (item?.product_sku) {
            let productObj = {
              name: item.product_name,
              displayName: item.product_name,
              id: item.id,
              priceWithoutVAT: item.product_sale_price.value,
              price: item.product_sale_price.value,
              listPrice: item.product_sale_price.value,
              discount: JSON.stringify(item.discounts),
              category: '',
              brand: 'Micron',
              SKU: item.product_sku,
              partNumber: item.product_sku,
              referenceID: item.product_sku,
              variant: '',
              quantity: item.quantity_ordered,
              coupon: 0,
              subscriptionFlag: false,
              initialSubFlag: false,
              trialFlag: false,
              //price_usd: item.prices.price.value,
              //listPrice_usd: item.prices.price.value,
              //discount_usd: 0
            };
            productsArray.push(productObj);
          }
          let tax = orderDetails?.total?.total_tax?.value ? Number(orderDetails?.total?.total_tax?.value) : 0.00;
          let shippingAmt = orderDetails?.total?.total_shipping.value;
          let subTotal = orderDetails?.total?.subtotal?.value;
          var revenue = orderDetails?.total?.grand_total?.value;
          const ecommerceObj = {
            currencyCode: orderDetails?.total?.grand_total?.currency,
            purchase: {
              actionField: {
                id: orderDetails?.number,
                affiliation: 'Adobe Commerce',
                revenue: revenue,
                shipping: shippingAmt,
                tax: tax,
                subtotal: subTotal,
                discount: JSON.stringify(orderDetails?.total?.discounts),
                coupon: 0,
                //revenue_usd: cartData?.core_cart?.prices?.grand_total.value,
                //tax_usd: 0,
                //shipping_usd: 0,
                //discount_usd: 0
              }
            }
          }
          gtmDataLayer.ecommerce = ecommerceObj;
          gtmDataLayer.products = productsArray;
          gtmDataLayer.event = gtmPageData.getAttribute('data-event');
        });
        window.dataLayer = window.dataLayer || [];
        window.dataLayer = window.dataLayer.filter(item => {
          return item.siteLocale ? false : true;
        });
        window.dataLayer.push(gtmDataLayer);
        updateScriptTag();
      }, [orderDetails]);
    }

    function updateScriptTag() {

      const gtmId = gtmPageData.getAttribute('data-gtm-id');
      scriptGtmTag.src = '//www.googletagmanager.com/gtm.js?id=' + gtmId;
      scriptGtmTag.async = true;
    }

  }
  return (
    <>

    </>
  );
}
