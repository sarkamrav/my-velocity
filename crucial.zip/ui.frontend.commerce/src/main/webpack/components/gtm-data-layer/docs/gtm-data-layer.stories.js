import GtmDataLayer from "../gtm-data-layer.hbs";

export default {
  title: "Components/React Component/Gtm-Data-Layer",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { GtmDataLayer };
