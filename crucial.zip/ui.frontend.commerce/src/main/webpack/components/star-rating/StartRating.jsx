import React from 'react';
import Icon from '../../assests/Icon';
import PropTypes from 'prop-types';

const StarRating = ({ value, className }) => {
  const rating = parseFloat(value);
  const filledStars = Math.min(Math.floor(rating), 5);
  const hasPartialStar = rating % 1;

  const filledStarIcons = Array.from({ length: filledStars }, (_, index) => <Icon key={index} name="FilledStar" />);

  let partialStarIcon = null;
  if (hasPartialStar > 0) {
    if (hasPartialStar <= 0.3) {
      partialStarIcon = <Icon name="QuarterFilledStar" />;
    } else if (hasPartialStar <= 0.6) {
      partialStarIcon = <Icon name="HalfFilledStar" />;
    } else if (hasPartialStar <= 0.8) {
      partialStarIcon = <Icon name="ThreeQuarterFilledStar" />;
    } else {
      partialStarIcon = <Icon name="FilledStar" />;
    }
  }

  const emptyStarIconsLength =
    isNaN(filledStars) || (isNaN(partialStarIcon) && isNaN(rating)) ? 5 : 5 - filledStars - (partialStarIcon ? 1 : 0);

  const emptyStarIcons = Array.from({ length: emptyStarIconsLength }, (_, index) => (
    <Icon key={index} name="EmptyStar" />
  ));

  return (
    <div className={className}>
      {filledStarIcons}
      {partialStarIcon}
      {emptyStarIcons}
      <span>{isNaN(rating) ? '(0.0)' : `(${rating.toFixed(1)})`}</span>
    </div>
  );
};

StarRating.propTypes = {
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};

StarRating.defaultProps = {
  value: '0',
};
export default StarRating;
