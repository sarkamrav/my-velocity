import React, { useState, useMemo } from 'react';
import { gql, useQuery, ApolloClient, ApolloProvider, useLazyQuery } from '@apollo/client';
import {
  apolloClientConfigForProduct,
  apolloClientConfigUsingGet,
  clientConfigUsingGet,
  getUserTokenFromLoaclStorate,
} from '../../configs/ReactApolloClientSetup/ApolloClientConfig.js';
import ProductListPage from '../product-list-page/ProductListPage';
import Currency from '../currency/Currency.jsx';
import AlternateProduct from '../alternate-product/AlternateProduct.jsx';
import CryptoJS from 'crypto-js';
import ProductInformation from '../product-information/ProductInformation';
import { getCookie, setCookie } from '../../utils/cookies_operation.js';
import DynamicPricing from '../dynamic-pricing/DynamicPricing.jsx';
import CompatibleProductsPriceCart from '../compatible-products-price-cart/CompatibleProductsPriceCart.jsx';
import Ssdproductcard from '../ssdproductcard/Ssdproductcard.jsx';
export default function HeadersForCatalogServices({ name, ...props }) {
  const CATALOG_HEADER = gql`
    query {
      core_dataServicesStorefrontInstanceContext {
        environment
        environment_id
        customer_group
        store_code
        store_view_code
        website_code
      }
    }
  `;

  const [headerQueryFired, setHeaderQueryFired] = useState(false);

  let client;
  let clientForGet;
  const gqlClientFotGet = useMemo(() => clientConfigUsingGet(), []);
  const [getShopHeaders, { data }] = useLazyQuery(CATALOG_HEADER, {
    client: gqlClientFotGet, // Override the client here for get call
  });

  if (!isHeaderDetailsAvailable() && !headerQueryFired) {
    getShopHeaders();
    setHeaderQueryFired(true);
  } else {
    if (name === 'currency') {
      client = new ApolloClient(apolloClientConfigUsingGet());
    } else {
      client = new ApolloClient(apolloClientConfigForProduct());
    }
  }

  function isHeaderDetailsAvailable() {
    let headerDetails = getCookie('headerDetails');
    return (
      headerDetails &&
      JSON.parse(headerDetails)?.lang == document.querySelector('[lang]')?.getAttribute('lang') &&
      JSON.parse(headerDetails)?.loggedIn == isUserLoggedIn()
    );
  }

  function isUserLoggedIn() {
    if (getUserTokenFromLoaclStorate()) {
      return 'true';
    }
    return 'false';
  }

  if (data) {
    document.cookie = 'headerDetails=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
    const encryptionKey = 'crucialAdobeCommerce';
    let headerDetails = JSON.parse(JSON.stringify(data.core_dataServicesStorefrontInstanceContext));
    headerDetails.environment = CryptoJS.AES.encrypt(headerDetails.environment, encryptionKey).toString();
    headerDetails.environment_id = CryptoJS.AES.encrypt(headerDetails.environment_id, encryptionKey).toString();
    headerDetails.customer_group = CryptoJS.AES.encrypt(headerDetails.customer_group, encryptionKey).toString();
    headerDetails.store_code = CryptoJS.AES.encrypt(headerDetails.store_code, encryptionKey).toString();
    headerDetails.store_view_code = CryptoJS.AES.encrypt(headerDetails.store_view_code, encryptionKey).toString();
    headerDetails.website_code = CryptoJS.AES.encrypt(headerDetails.website_code, encryptionKey).toString();
    headerDetails.currentTime = new Date().getTime().toString() + 20;
    headerDetails.lang = document.querySelector('[lang]')?.getAttribute('lang');
    if (getUserTokenFromLoaclStorate()) {
      headerDetails.loggedIn = 'true';
    } else {
      headerDetails.loggedIn = 'false';
    }
    setCookie('headerDetails', JSON.stringify(headerDetails), 20);
    if (name === 'currency') {
      client = new ApolloClient(apolloClientConfigUsingGet());
    } else {
      client = new ApolloClient(apolloClientConfigForProduct());
    }
  }

  return (
    <>
      <ApolloProvider client={client}>
        {(data || (isHeaderDetailsAvailable() && getCookie('headerDetails'))) && name === 'ProductListPage' && <ProductListPage {...props} />}
        {(data || (isHeaderDetailsAvailable() && getCookie('headerDetails'))) && name === 'ProductInformation' && <ProductInformation {...props} />}
        {(data || (isHeaderDetailsAvailable() && getCookie('headerDetails'))) && name === 'currency' && <Currency />}
        {(data || (isHeaderDetailsAvailable() && getCookie('headerDetails'))) && name === 'AlternateProduct' && <AlternateProduct {...props} />}
        {(data || (isHeaderDetailsAvailable() && getCookie('headerDetails'))) && name === 'DynamicPricing' && <DynamicPricing {...props} />}
        {(data || (isHeaderDetailsAvailable() && getCookie('headerDetails'))) && name === 'CompatibleProductsPriceCart' && (
          <CompatibleProductsPriceCart {...props} />
        )}
        {(data || (isHeaderDetailsAvailable() && getCookie('headerDetails'))) && name === 'SsdProductCard' && <Ssdproductcard {...props} />}
      </ApolloProvider>
    </>
  );
}
