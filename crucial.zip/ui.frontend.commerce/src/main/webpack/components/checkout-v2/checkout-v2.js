import React from 'react';
import { createRoot } from 'react-dom/client';
import CheckoutV2 from './CheckoutV2.jsx';
import { ApolloClient, ApolloProvider } from '@apollo/client';
import ApolloClientConfig from '../../configs/ReactApolloClientSetup/ApolloClientConfig';
import { StoreProvider } from '../../contexts/common/StoreContext';
export default class {
  static init(el) {
    const client = new ApolloClient(ApolloClientConfig);
    const props = JSON.parse(JSON.stringify(el.dataset));
    createRoot(el).render(
      <StoreProvider>
        <ApolloProvider client={client}>
          <CheckoutV2 {...props} />
        </ApolloProvider>
      </StoreProvider>
    );
  }
}
