import CheckoutV2 from "../checkout-v2.hbs";

export default {
  title: "Components/React Component/Checkout-V2",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { CheckoutV2 };
