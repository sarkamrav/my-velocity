import React, { useEffect, useState } from 'react';
import {
  getCatalogServiceHeaders,
  getUserTokenFromLoaclStorate,
} from '../../configs/ReactApolloClientSetup/ApolloClientConfig';
import { Formik, Form } from 'formik';
import * as Yup from 'yup';
import Radio from '../micro-components/Radio/Radio';
import Icon from '../../assests/Icon';
import Payment from './components/payment-fragment/Payment';
import AddressFragment from './components/address-fragment/AddressFragment';
import { findPosition } from '../../utils/utils';
import ShippingMethod from './components/shipping-method-fragment/ShippingMethod';
import OrderSummary from './components/order-summary/OrderSummary';
import TaxExemption from './components/tax-exemption-fragment/TaxExemption';
import { useMutation } from '@apollo/client';
import { clearCookie, getCookie, setCookie } from '../../utils/cookies_operation';
import { CREATE_EMPTY_CART, CLEAR_CART } from '../../site/js/gql/mutations/cart.gql';
import { MERGE_GUEST_CART } from '../../site/js/gql/mutations/checkout-v2.gql';
import { REMOVE_VAT_FROM_CHECKOUT } from '../../site/js/gql/mutations/vatUpdate.gql';
import { createPortal } from 'react-dom';
import Loader from '../micro-components/Loader/Loader';

export default function CheckoutV2({
  heading,
  shippingHeading,
  subHeadingOne,
  subHeadingTwo,
  asteriskLabel,
  asteriskRequiredLabel,
  orderTypeLabel,
  stepOrderTypePersonal,
  stepOrderTypeBusiness,
  ...restProps
}) {
  // Variable to update cart in the order summary component
  const [updateCart, setUpdateCart] = useState(false);

  // Logic for merging carts when user logs in for tax exemption starts here ----------------------------------------------
  // State variable for merged cart data and Mutations required to create a new empty
  // cart for logged in user and merge the guest cart
  const [savedCartData, setSavedCartData] = useState();
  const [createEmptyCart] = useMutation(CREATE_EMPTY_CART);
  const [clearCart] = useMutation(CLEAR_CART);
  const [setMergedCart] = useMutation(MERGE_GUEST_CART);

  // -------------------- Logic to check for logged in user -----------------
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  // Effect to check if the user is logged in and do necessary things like merging carts if
  // came from Tax exemption popup only so that no unncessary calls are made
  useEffect(() => {
    if (getUserTokenFromLoaclStorate()) {
      setIsLoggedIn(true);
      if (getCookie('tax_exempt_login')) {
        createEmptyCart({
          context: {
            headers: {
              authorization: `Bearer ${getUserTokenFromLoaclStorate()}`,
            },
          },
        })
          .then(data => {
            return clearCart({
              context: {
                headers: {
                  authorization: `Bearer ${getUserTokenFromLoaclStorate()}`,
                },
              },
              variables: {
                uid: data?.data?.core_createEmptyCart,
              },
            });
          })
          .then(data => {
            setCookie('cart_id', JSON.stringify(data?.data?.core_clearCart?.cart?.id));
            return setMergedCart({
              context: {
                headers: {
                  authorization: `Bearer ${getUserTokenFromLoaclStorate()}`,
                },
              },
              variables: {
                source_cart_id: getCookie('guest_cart_id'),
                destination_cart_id: data?.data?.core_clearCart?.cart?.id,
              },
            });
          })
          .then(({ data }) => {
            clearCookie('tax_exempt_login');
            clearCookie('guest_cart_id');
            setSavedCartData(data);
            setUpdateCart(true);
          })
          .catch(error => console.log(`Server responded with an error - ${error.message}`));
      }
    } else {
      setIsLoggedIn(false);
    }
  }, []);
  // Logic to check for logged in user and merge carts when tax exemption is done ends here -----------------

  // Variables to enable the next steps in the checkout
  const [enableShipping, setEnableShipping] = useState(false);
  const [enablePayment, setEnablePayment] = useState(false);
  const [enableTax, setEnableTax] = useState(false);

  useEffect(() => {
    if (enableShipping) {
      window.scrollTo({
        top: findPosition(document.querySelector('.cmp-acommerce_checkout-v2-shipping-method')),
        behavior: 'smooth',
      });
    }
  }, [enableShipping]);

  // Radio options for purchase type selection
  const purchases = [
    {
      label: stepOrderTypePersonal,
      value: 'individual',
    },
    {
      label: stepOrderTypeBusiness,
      value: 'business',
    },
  ];

  const initialPurchase = {
    purchase: purchases[0]?.value,
  };
  const purchaseSchema = Yup.object({
    purchase: Yup.string(),
  });

  const [isBusinessPurchased, setIsBusinessPurchased] = useState(false);
  const [purchaseType, setPurchaseType] = useState(purchases[0]?.value);

  //For checkboxes
  // const initialCheckboxes = {
  //   termsConditions: true,
  //   emailReminder: false,
  // };
  // const checkboxesValidation = Yup.object({
  //   termsConditions: Yup.bool(),
  //   emailReminder: Yup.bool(),
  // });

  // Mutation to fire when user edits the sections or changes from business to personal purchase
  // Purpose: Reset the VAT ID on the checkout session
  const [removeVAT, { loading: removeVATLoading }] = useMutation(REMOVE_VAT_FROM_CHECKOUT);

  return (
    <div className="cmp-acommerce_checkout-v2__section">
      <div className="custom-container">
        <div className="cmp-acommerce_checkout-v2__head">
          <h2 className="cmp-acommerce_checkout-v2__heading">{heading}</h2>
        </div>
        <div className="cmp-acommerce_checkout-v2__body">
          <div className="cmp-acommerce_checkout-v2__main">
            <div className="cmp-acommerce_checkout-v2__details">
              <h4 className="cmp-acommerce_checkout-v2__heading--secondary">{shippingHeading}</h4>
              <p className="cmp-acommerce_checkout-v2__sub-heading">
                {subHeadingOne}
                <b>{subHeadingTwo}</b>
                <br />
                <br />
                {asteriskLabel} (
                <Icon className="mandatory_asterisk" name="Asterisk" />) {asteriskRequiredLabel}
              </p>
            </div>
            <div className="cmp-acommerce_checkout-v2__radio-group order-type">
              <Formik initialValues={initialPurchase} validationSchema={purchaseSchema} enableReinitialize>
                {({ values }) => {
                  useEffect(() => {
                    values.purchase === 'business' ? setIsBusinessPurchased(true) : setIsBusinessPurchased(false);
                    setPurchaseType(values.purchase);
                    if (isLoggedIn && getCatalogServiceHeaders() !== 'en_us') {
                      removeVAT({
                        variables: {
                          cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
                        },
                      }).catch(error => console.log(`Server responded with an error - ${error.message}`));
                    }
                  }, [values.purchase]);
                  return (
                    <Form>
                      <Radio options={purchases} label={orderTypeLabel} isMandatory name="purchase" />
                    </Form>
                  );
                }}
              </Formik>
            </div>
            <AddressFragment
              {...restProps}
              isBusinessPurchased={isBusinessPurchased}
              purchaseType={purchaseType}
              setEnableShipping={setEnableShipping}
              setEnableTax={setEnableTax}
              setEnablePayment={setEnablePayment}
              isLoggedIn={isLoggedIn}
              savedCartData={savedCartData}
              removeVAT={removeVAT}
            />
            <ShippingMethod
              enableShipping={enableShipping}
              setEnableTax={setEnableTax}
              setEnablePayment={setEnablePayment}
              isLoggedIn={isLoggedIn}
              removeVAT={removeVAT}
              {...restProps}
            />
            {isBusinessPurchased && (
              <TaxExemption
                {...restProps}
                isLoggedIn={isLoggedIn}
                enableTax={enableTax}
                setEnablePayment={setEnablePayment}
                setUpdateCart={setUpdateCart}
              />
            )}
            <Payment enablePayment={enablePayment} {...restProps} />
          </div>
          <OrderSummary {...restProps} updateCart={updateCart} setUpdateCart={setUpdateCart} />
        </div>
      </div>
      {removeVATLoading && createPortal(<Loader />, document.body)}
    </div>
  );
}
