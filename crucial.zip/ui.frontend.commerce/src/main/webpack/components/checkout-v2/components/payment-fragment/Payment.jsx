import React, { useEffect, useState } from 'react';
import { useStoreContext } from '../../../../contexts/common/StoreContext';
import { SET_PAYMENT_METHOD_TO_CART } from '../../../../site/js/gql/mutations/set-payment-method-to-cart.gql';
import { useLazyQuery, useMutation } from '@apollo/client';
import { clearCookie, getCookie, setCookie } from '../../../../utils/cookies_operation';
import Loader from '../../../micro-components/Loader/Loader';
import { PLACE_ORDER } from '../../../../site/js/gql/mutations/placeOrder.gql';
import { createPortal } from 'react-dom';
import { getShoppingUrls } from '../../../../site/js/urlresolver';
import Dropdown from '../../../micro-components/Dropdown/Dropdown';
import { Form, Formik } from 'formik';
import { GET_SAVED_PAYMENT, SAVE_PAYMENT } from '../../../../site/js/gql/mutations/account/save-payment.gql';
import Button from '../../../micro-components/Button/Button';
import { GET_DR_SOURCE_DATA } from '../../../../site/js/gql/get-dr-source.gql';
import { getUserTokenFromLoaclStorate } from '../../../../configs/ReactApolloClientSetup/ApolloClientConfig';
import {
  GET_COMBINED_SOURCE_DATA,
  SET_BILLING_ADDRESS_ON_CART,
} from '../../../../site/js/gql/mutations/checkout-v2.gql';
const getToken = () => `Bearer ${getUserTokenFromLoaclStorate()}`;
export default function PaymentV2({ enablePayment, paymentHeading, placeOrderLabel, drPublicKey, selectPayment, selectSavedPaymentLabel }) {
  const initialValues = {
    saved_payment_method: '',
  };
  const initialOptions = [
    {
      options: [
        {
          value: '',
          label: selectPayment,
        },
      ],
    },
  ];
  const { state } = useStoreContext();
  const [showLoader, setShowLoader] = useState(false);
  const [isLogged, setIsLogged] = useState(false);
  const [paymentOption, setPaymentOption] = useState(initialOptions);
  const [formdata, setFormdata] = useState(initialValues);
  const [placeOrderAllowed, setPlaceOrderAllowed] = useState(false);
  const [showError, setShowError] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    if (getUserTokenFromLoaclStorate()) {
      setIsLogged(true);
    }
  }, []);

  const [getSavedCard, { data: paymentData, loading: cardLoading }] = useLazyQuery(GET_SAVED_PAYMENT, {
    context: {
      headers: {
        Authorization: getToken(),
      },
    },
  });

  const [savePayment] = useMutation(SAVE_PAYMENT, {
    context: {
      headers: {
        Authorization: getToken(),
      },
    },
  });

  const [getSourceData, { loading: dataLoading }] = useLazyQuery(GET_DR_SOURCE_DATA);
  const [getComboSourceData, { loading: comboDataLoading }] = useLazyQuery(GET_COMBINED_SOURCE_DATA);
  const [setBillingAddressOnCart] = useMutation(SET_BILLING_ADDRESS_ON_CART);

  useEffect(async () => {
    await getSavedCard();
  }, []);

  useEffect(() => {
    if (paymentData) {
      let paymentArrayOptions = initialOptions;
      paymentData?.core_getSavedCard?.forEach(item => {
        paymentArrayOptions.forEach(cardOptions => {
          cardOptions.options.push({
            value: item.id,
            label: `${item.brand} *************${item.lastFourDigits}`,
          });
        });
      });
      setPaymentOption(paymentArrayOptions);
    }
  }, [paymentData]);

  // Payment method setup
  const [setPaymentMethodOnCart, { loading: paymentLoading }] = useMutation(SET_PAYMENT_METHOD_TO_CART);
  const [placeOrder, { loading: placeOrderLoading }] = useMutation(PLACE_ORDER);

  useEffect(() => {
    if (
      enablePayment &&
      state.checkout.shippingMethodData.session_id &&
      document.getElementById('cmp-acommerce_drop-in').innerHTML === ''
    ) {
      const { firstname, lastname, telephone, street, city, region, postcode, country } =
        state?.checkout?.addressData?.billing_address;
      const email = state?.checkout?.addressData?.email;
      const script = document.createElement('script');
      script.src = 'https://js.digitalriverws.com/v1/DigitalRiver.js';
      script.async = true;
      script.onload = () => {
        try {
          const digitalriverpayments = new DigitalRiver(drPublicKey);
          const configuration = {
            sessionId: state.checkout.shippingMethodData.session_id,
            billingAddress: {
              firstName: firstname,
              lastName: lastname,
              email: email || getCookie('user_email'),
              phoneNumber: telephone,
              address: {
                line1: street?.[0],
                line2: street?.[1],
                city: city,
                state: region.code,
                postalCode: postcode,
                country: country.code,
              },
            },
            options: {
              flow: 'checkout',
              button: {
                type: 'submitOrder',
              },
              redirect: {
                disableAutomaticRedirects: true,
                returnUrl: window.location.href,
                cancelUrl: window.location.href,
              },
              showComplianceSection: false,
              showSavePaymentAgreement: isLogged,
              showTermsOfSaleDisclosure: true,
            },
            onSuccess: async function (data) {
              setShowLoader(true);
              if (data.readyForStorage) {
                await savePayment({
                  variables: {
                    source_id: data.source.id,
                  },
                });
              }
              await setPaymentMethodOnCart({
                variables: {
                  code: 'dr_drop_in_payment',
                  cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
                  additional_data: JSON.stringify(data.source),
                  source_id: data.source.id,
                },
              });
              await placeOrder({
                variables: {
                  cartId: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
                },
              }).then(response => {
                setCookie('crucialPaymentSource', JSON.stringify(data.source), 5);
                clearCookie('cart_product_urls');
                window.location.href = `${getShoppingUrls().thankYouURL}?order_number=${
                  response.data.core_placeOrder.order.order_number
                }`;
              });
            },
            onError: function (data) {
              setErrorMessage(data.errors[0].message);
              setShowError(true);
            },
          };
          const dropin = digitalriverpayments.createDropin(configuration);
          dropin.mount('cmp-acommerce_drop-in');
        } catch (error) {
          console.error('Digital River initialization error:', error);
        }
      };
      document.body.appendChild(script);
      return () => {
        document.body.removeChild(script);
      };
    }
  }, [enablePayment, state]);

  useEffect(() => {
    const link = document.createElement('link');
    link.href = 'https://js.digitalriverws.com/v1/css/DigitalRiver.css';
    link.rel = 'stylesheet';
    link.type = 'text/css';
    document.head.appendChild(link);

    return () => {
      document.head.removeChild(link);
    };
  }, []);

  const handleSaveSubmit = async values => {
    try {
      const script = document.createElement('script');
      script.src = 'https://js.digitalriverws.com/v1/DigitalRiver.js';
      script.async = true;

      script.onload = async () => {
        try {
          const digitalriverpayments = new DigitalRiver(drPublicKey);
          const response = await getSourceData({
            variables: {
              sourceId: values.saved_payment_method,
            },
          });

          const decodedData = JSON.parse(atob(response.data.core_get_digital_river_source.dr_source));
          setShowLoader(true);
          const authResponse = await digitalriverpayments.authenticateSource({
            sessionId: state?.checkout?.shippingMethodData?.session_id,
            sourceId: values.saved_payment_method,
            sourceClientSecret: decodedData.clientSecret,
            returnUrl: window.location.href,
          });

          if (authResponse.status === 'authentication_not_required') {
            const comboSourceResponse = await getComboSourceData({
              variables: {
                sourceId: values.saved_payment_method,
                checkoutId: state?.checkout?.shippingMethodData?.checkout_id,
              },
            });

            const comboDecodedData = JSON.parse(
              atob(comboSourceResponse.data.core_attach_dr_source_to_checkout.dr_checkout)
            );

            await setBillingAddressOnCart({
              variables: {
                cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
                firstName: comboDecodedData.payment.sources[0].owner.firstName,
                lastName: comboDecodedData.payment.sources[0].owner.lastName,
                company: comboDecodedData.payment.sources[0].owner.company || '',
                streetAddress: [
                  comboDecodedData.payment.sources[0].owner.address.line1,
                  comboDecodedData.payment.sources[0].owner.address.line2 || '',
                ],
                city: comboDecodedData.payment.sources[0].owner.address.city,
                region: comboDecodedData.payment.sources[0].owner.address.state,
                postalCode: comboDecodedData.payment.sources[0].owner.address.postalCode,
                country: comboDecodedData.payment.sources[0].owner.address.country,
                telephone: comboDecodedData.billTo.phone || '',
              },
            });

            await setPaymentMethodOnCart({
              variables: {
                code: 'dr_drop_in_payment',
                cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
                additional_data: JSON.stringify(comboDecodedData.payment),
                source_id: comboDecodedData.id,
              },
            });

            const orderResponse = await placeOrder({
              variables: {
                cartId: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
              },
            });

            setCookie('crucialPaymentSource', JSON.stringify(comboDecodedData), 5);
            clearCookie('cart_product_urls');
            setShowLoader(false);
            window.location.href = `${getShoppingUrls().thankYouURL}?order_number=${
              orderResponse.data.core_placeOrder.order.order_number
            }`;
          }
        } catch (error) {
          console.error('Error during DigitalRiver process:', error);
          setShowLoader(false);
        }
      };

      script.onerror = () => {
        console.error('Error loading DigitalRiver script');
        setShowLoader(false);
      };

      document.body.appendChild(script);

      // Cleanup function to remove the script
      return () => {
        document.body.removeChild(script);
      };
    } catch (error) {
      console.error('Error in handleSaveSubmit:', error);
      setShowLoader(false);
    }
  };

  useEffect(() => {
    if (showError) {
      const element = document.querySelector('.cmp-acommerce_drop-in-payment-error-wrapper');
      if (element) {
        element.scrollIntoView({
          behavior: 'smooth',
        });
      }
      const timer = setTimeout(() => {
        setShowError(false);
        setErrorMessage('');
      }, 3000);

      return () => clearTimeout(timer);
    }
  }, [showError]);

  return (
    <>
      <div
        className={`cmp-acommerce_checkout-v2__fragment cmp-acommerce_checkout-v2__fragment${
          enablePayment ? '' : '--disable'
        } cmp-acommerce_checkout-v2-payment-method`}>
        <div className="cmp-acommerce_checkout-v2__fragment-head">
          <h4 className="cmp-acommerce_checkout-v2__fragment-heading">{paymentHeading}</h4>
        </div>
        {enablePayment && (
          <div className="cmp-acommerce_checkout-v2__fragment-body">
            <div className="cmp-acommerce_drop-in-payment-wrapper">
              {showError && (
                <div className="cmp-acommerce_drop-in-payment-error-wrapper">
                  <p className="submiterror">{errorMessage}</p>
                </div>
              )}
              {isLogged && (
                <Formik initialValues={formdata} onSubmit={handleSaveSubmit} enableReinitialize>
                  {({ values }) => {
                    useEffect(() => {
                      if (values.saved_payment_method) {
                        setFormdata(prev => ({
                          ...prev,
                          saved_payment_method: values.saved_payment_method,
                        }));
                        setPlaceOrderAllowed(true);
                      } else {
                        setPlaceOrderAllowed(false);
                      }
                    }, [values.saved_payment_method]);
                    return (
                      <Form>
                        {Object.keys(paymentOption).length && (
                          <>
                            <Dropdown
                              name="saved_payment_method"
                              options={paymentOption}
                              label={selectSavedPaymentLabel}
                              className="cmp-acommerce_checkout-v2__address-form__dropdown cmp-saved-card-list"
                            />
                            {placeOrderAllowed && (
                              <Button className="cmp-acommerce_checkout-v2__address-form__submit-button saved_card_submit">
                                {placeOrderLabel}
                              </Button>
                            )}
                          </>
                        )}
                      </Form>
                    );
                  }}
                </Formik>
              )}
              <div id="cmp-acommerce_drop-in"></div>
            </div>
          </div>
        )}
      </div>
      {(showLoader || dataLoading || placeOrderLoading || paymentLoading || cardLoading || comboDataLoading) &&
        createPortal(<Loader />, document.body)}
    </>
  );
}
