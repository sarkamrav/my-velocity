import React, { useEffect, useState } from 'react';
import { useQuery } from '@apollo/client';
import Link from '../../../micro-components/Link/Link';
import Loader from '../../../micro-components/Loader/Loader';
import { getCookie, setCookie } from '../../../../utils/cookies_operation';
import { getShoppingUrls } from '../../../../site/js/urlresolver.js';
import { CHECKOUT_V2_GET_CART } from '../../../../site/js/gql/mutations/checkout-v2.gql';
import { getUserTokenFromLoaclStorate } from '../../../../configs/ReactApolloClientSetup/ApolloClientConfig';
import GtmDataLayer from '../../../gtm-data-layer/GtmDataLayer.jsx';
import { formatLocalePrice } from '../../../../utils/utils.js';

export default function OrderSummary({
  updateCart,
  setUpdateCart,
  orderSummaryHeading,
  estimateShippingLabel,
  subTotal,
  addressEditLabel,
  discountLabel,
  shippingLabel,
  taxLabel,
}) {
  const [cartInfo, setCartInfo] = useState({});
  const [shippingAmount, setShippingAmount] = useState(0);
  const [taxAmount, setTaxAmount] = useState();
  const [showShipping, setShowShipping] = useState(false);
  const [showTax, setShowTax] = useState(false);
  const [showEstimatedShipping, setShowEstimatedShipping] = useState(false);
  const [estimatedShippingAmount, setEstimatedShippingAmount] = useState(0);
  const [cartQty, setCartQty] = useState(0);

  // To get cart data
  const {
    data: cartData,
    loading: cartLoading,
    error: cartError,
    refetch: refetchCart,
  } = useQuery(CHECKOUT_V2_GET_CART, {
    variables: {
      cart_id: JSON.parse(getCookie('cart_id')),
    },
  });

  useEffect(() => {
    if (getCookie('new_shipping_values') !== undefined) {
      setEstimatedShippingAmount(JSON.parse(getCookie('new_shipping_values'))?.estimatedShipPrice);
      setShowEstimatedShipping(true);
    }
  }, []);

  useEffect(() => {
    // fetch the cart if updateCart is true
    if (updateCart) {
      refetchCart();
      setUpdateCart(false);
    }
  }, [updateCart, refetchCart, setUpdateCart]);

  useEffect(() => {
    setCartInfo(cartData);
  }, [cartData]);

  // Destructure data
  const viewCartData = cartInfo?.core_cart || {};
  const { items, prices, shipping_addresses } = viewCartData;
  const discount = cartInfo?.core_cart?.prices?.discount || {};
  const currencySymbol = getCookie('currency') ? JSON.parse(getCookie('currency')).currencySymbol : '';
  const shippingAddress = shipping_addresses || [];

  // Redirect the checkout page to cart page if the page is accessed with empty cart
  useEffect(() => {
    if (items && items.length === 0) {
      window.location.href = getShoppingUrls().cartURL;
    }
    if (items !== undefined && items.length > 0) {
      setCartQty(items.length);
    }
  }, [items]);

  useEffect(() => {
    if (shippingAddress.length > 0) {
      if (shipping_addresses[0]?.selected_shipping_method !== null) {
        setShippingAmount(shipping_addresses[0]?.selected_shipping_method.amount.value.toFixed(2));
        setShowShipping(true);
      }
    }
  }, [shipping_addresses]);

  useEffect(() => {
    if (prices !== undefined && prices.total_tax.value !== null) {
      setTaxAmount(prices.total_tax.value.toFixed(2));
      setShowTax(true);
    }
  }, [prices]);

  // Log cart error
  if (cartError) {
    console.error('cartError', cartError);
  }

  return (
    <div className="cmp-acommerce_billing-info__side">
      <div className="cmp-acommerce_billing-info__order-summary">
        <div className="cmp-acommerce_billing-info__order-summary__head">
          <span className="order-summary-title">
            <b>
              {orderSummaryHeading} {`(${cartQty})`}
            </b>
          </span>
          <Link type="default" href={getShoppingUrls().cartURL} text={addressEditLabel} />
        </div>
        {cartLoading && <Loader />}
        <div className="cmp-acommerce_billing-info__order-summary__body">
          <div className="cmp-acommerce_billing-info__order-summary__product">
            {items?.map((item, index) => (
              <div className="cmp-acommerce_billing-info__order-summary__row" key={index}>
                <span>{item.quantity}</span>
                <span className="product-image">
                  <img loading="lazy" src={item.product.image.url} alt={item.product.image.label} />
                </span>
                <span className="product-name">{item.product.name}</span>
                <span>
                  <b>{formatLocalePrice(item?.prices?.row_total?.value, currencySymbol)}</b>
                </span>
              </div>
            ))}
          </div>
          {discount.amount !== undefined && (
            <div className="cmp-acommerce_billing-info__order-summary__row">
              <div className="discount-container">
                <div className="discount_title">{discountLabel}</div>
              </div>
              <div className="discount-value-container">
                <div className="discount_value">
                  {'-'}
                  {formatLocalePrice(discount?.amount?.value, currencySymbol)}
                </div>
              </div>
            </div>
          )}
          {!showShipping && showEstimatedShipping && (
            <div className="cmp-acommerce_billing-info__order-summary__row">
              <span>{estimateShippingLabel}</span>
              <span>{formatLocalePrice(estimatedShippingAmount, currencySymbol)}</span>
            </div>
          )}
          {showShipping && (
            <div className="cmp-acommerce_billing-info__order-summary__row">
              <span>{shippingLabel}</span>
              <span>{formatLocalePrice(shippingAmount, currencySymbol)}</span>
            </div>
          )}
          {showTax && (
            <div className="cmp-acommerce_billing-info__order-summary__row">
              <span>{taxLabel}</span>
              <span>{formatLocalePrice(taxAmount, currencySymbol)}</span>
            </div>
          )}
          <div className="cmp-acommerce_billing-info__order-summary__row">
            <span className="order-summary-title">
              <b>{subTotal}</b>
            </span>
            <span className="order-summary-title">
              <b>
                {/* {currencySymbol}
                {!shippingAmount && estimatedShippingAmount
                  ? (Number(estimatedShippingAmount) + Number(prices?.grand_total.value)).toFixed(2)
                  : Number(prices?.grand_total.value).toFixed(2)} */}
                {formatLocalePrice(
                  !shippingAmount && estimatedShippingAmount
                    ? estimatedShippingAmount + prices?.grand_total.value
                    : prices?.grand_total.value,
                  currencySymbol
                )}
              </b>
            </span>
          </div>
        </div>
      </div>
      <GtmDataLayer shipping={showShipping ? shippingAmount : estimatedShippingAmount} cartData={cartData} />
    </div>
  );
}
