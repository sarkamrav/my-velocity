import React, { useState, useEffect } from 'react';
import Icon from '../../../../assests/Icon';
import InputField from '../../../inputfield/InputField';
import Dropdown from '../../../micro-components/Dropdown/Dropdown';
import Button from '../../../micro-components/Button/Button';
import { months, years } from '../../../../utils/common';
import { Formik, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { TAX_EXEMPTION } from '../../../../site/js/gql/mutations/taxExemption.gql';
import { UPDATE_VAT_TO_CHECKOUT } from '../../../../site/js/gql/mutations/vatUpdate.gql';
import { STATE_QUERY } from '../../../../site/js/gql/states.gql';
import { useLazyQuery, useMutation } from '@apollo/client';
import { createPortal } from 'react-dom';
import Loader from '../../../micro-components/Loader/Loader';
import { fileToBase64, formatDateToISOString } from '../../../../utils/utils';
import { getCatalogServiceHeaders, getVatId } from '../../../../configs/ReactApolloClientSetup/ApolloClientConfig';
import ModalPopup from '../../../modal-popup/ModalPopup';
import LoginForm from '../../../login/component/loginform/LoginForm';
import CreateAccount from '../../../create-account/CreateAccount';
import ForgetPassword from '../../../forget-password/ForgetPassword';
import useModal from '../../../../hooks/useModal';
import { clearCookie, getCookie, setCookie } from '../../../../utils/cookies_operation';
import { useStoreContext } from '../../../../contexts/common/StoreContext';

const TaxExemption = ({
  isLoggedIn,
  enableTax,
  setUpdateCart,
  loginForTax,
  taxExemptButton,
  companyNameLabel,
  taxExemptionCertificateLabel,
  taxExemptionTooltipButton,
  taxExemptionTooltipLabel,
  taxExemptionStartDate,
  taxExemptionExpireDate,
  taxExemptionUploadCertificate,
  taxExemptionSupportFile,
  taxMaximumFileSize,
  taxExemptionSubmit,
  taxExemptionCancel,
  taxExemptionError,
  authorityRequired,
  monthRequiredError,
  yearRequiredError,
  endDateError,
  endDateEarlierError,
  fileRequiredError,
  fileLargeError,
  fileInvalidError,
  companyRequiredError,
  taxUploadFile,
  requiredFields,
  taxSubmission,
  taxApplied,
  validFrom,
  through,
  taxFileUploaded,
  taxExemptionSuccess,
  drPublicKey,
  invalidVat,
}) => {
  const locale = getCatalogServiceHeaders();
  const { state } = useStoreContext();
  const country =
    state?.checkout?.addressData?.shipping_address && state?.checkout?.addressData?.shipping_address[0]?.country;
  const cart_id = getCookie('cart_id') && JSON.parse(getCookie('cart_id'));
  const [showTooltip, setShowTooltip] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showError, setShowError] = useState(false);
  const [openForm, setOpenForm] = useState(false);
  const initialTaxAuthorities = [
    {
      options: [{ value: '', label: taxExemptionCertificateLabel }],
    },
  ];
  const [taxAuthorities, setTaxAuthorities] = useState(initialTaxAuthorities);
  const [taxInfo, setTaxInfo] = useState({});

  // Logic to handle the Login popup on the component starts here -------------------------------------------
  const { isShowing: isLoginConfirmation, toggle: loginToggleConfirmation } = useModal();
  const { isShowing: isCAConfirmation, toggle: caToggleConfirmation } = useModal();
  const { isShowing: isForgetPasswordLogin, toggle: forgetToggleConfirmation } = useModal();

  const handleUserForm = () => {
    loginToggleConfirmation();
    caToggleConfirmation();
  };

  const forgetPasswordHandler = () => {
    loginToggleConfirmation();
    forgetToggleConfirmation();
  };

  const cancelFormHandler = () => {
    loginToggleConfirmation();
  };

  const createAccountHandler = event => {
    if (event === 'login') {
      caToggleConfirmation();
      loginToggleConfirmation();
    }

    if (event === 'shopping') {
      //needs to verify
      caToggleConfirmation();
      loginToggleConfirmation();
    }
  };
  // Logic to handle the Login popup on the component ends here -------------------------------------------

  // Tax exemption form handling and data submission logic starts here ------------------------------------
  const taxInitialValues = {
    taxCompanyName: '',
    taxAuthority: '',
    startDateMonth: '',
    startDateYear: '',
    expirationDateMonth: '',
    expirationDateYear: '',
    certificate: '',
  };

  const [taxFormdata, setTaxFormdata] = useState(taxInitialValues);

  const getTaxValidationSchema = () => {
    return Yup.object({
      taxCompanyName: Yup.string().required(companyRequiredError),
      taxAuthority: Yup.string().required(authorityRequired),
      startDateMonth: Yup.string().required(monthRequiredError),
      startDateYear: Yup.string().required(yearRequiredError),
      expirationDateMonth: Yup.string().required(monthRequiredError),
      expirationDateYear: Yup.string()
        .required(yearRequiredError)
        .test('is-greater', endDateError, function (value) {
          const { startDateYear, startDateMonth } = this.parent;
          if (!value || !startDateYear || !startDateMonth) {
            return true; // Skip validation if either field is not set yet
          }

          const startDate = new Date(parseInt(startDateYear), parseInt(startDateMonth) - 1); // Month is zero-based
          const expirationDate = new Date(parseInt(value), parseInt(this.parent.expirationDateMonth) - 1);

          return expirationDate >= startDate;
        })
        .test('not-in-past', endDateEarlierError, function (value) {
          const { expirationDateMonth } = this.parent;
          if (!value || !expirationDateMonth) {
            return true; // Skip validation if either field is not set yet
          }

          const currentDate = new Date();
          const expirationDate = new Date(parseInt(value), parseInt(expirationDateMonth) - 1);

          return expirationDate >= currentDate;
        }),
      certificate: Yup.mixed()
        .required(fileRequiredError)
        .test('fileSize', fileLargeError, value => value && value.size <= 1024 * 1024 * 2)
        .test(
          'fileType',
          fileInvalidError,
          value => value && ['image/png', 'image/jpeg', 'application/pdf'].includes(value.type)
        ),
    });
  };

  const [taxValidationSchema, setTaxValidationSchema] = useState(getTaxValidationSchema());

  const [getAvailableStates, { loading: stateLoading, error: stateError }] = useLazyQuery(STATE_QUERY);

  const getTaxAuthorities = () => {
    getAvailableStates({ variables: { id: 'US' } })
      .then(states => {
        if (states.data.core_country.available_regions) {
          const stateArrayOptions = taxAuthorities;
          states.data.core_country.available_regions.forEach(state => {
            stateArrayOptions.forEach(stateOption => {
              stateOption.options.push({
                value: state.code,
                label: state.name,
              });
            });
          });
          setTaxAuthorities(stateArrayOptions);
        }
      })
      .catch(error => console.log(`Server responded with an error - ${error.message}`));
  };

  useEffect(() => {
    if (enableTax && country?.code === 'US') {
      getTaxAuthorities();
    } else {
      setTaxAuthorities(initialTaxAuthorities);
      setOpenForm(false);

      if (country?.code !== 'US') {
        setShowSuccess(false);
        setShowError(false);
        setUpdateCart(true);
      }
    }
  }, [enableTax]);

  // Mutation for tax exemption
  const [getTaxExemption, { loading: taxLoading, error: taxError, data: taxData }] = useMutation(TAX_EXEMPTION);

  // Handler to submit tax form data
  const handleTaxExemption = async values => {
    const {
      taxCompanyName,
      taxAuthority,
      startDateMonth,
      expirationDateMonth,
      startDateYear,
      expirationDateYear,
      certificate,
    } = values;

    let startDate = new Date(Date.UTC(parseInt(startDateYear), parseInt(startDateMonth) - 1, 1, 0, 0, 0, 0));

    let endDate = new Date(Date.UTC(parseInt(expirationDateYear), parseInt(expirationDateMonth), 0, 23, 59, 59, 999));

    const base64 = await fileToBase64(certificate);

    getTaxExemption({
      variables: {
        cart_id: cart_id,
        company_name: taxCompanyName,
        tax_authority: taxAuthority,
        start_date: formatDateToISOString(startDate),
        end_date: formatDateToISOString(endDate),
        file: base64,
      },
    })
      .then(data => {
        if (data?.data?.core_import_tax_exempt_certificate?.status) {
          setShowSuccess(true);
          setTaxFormdata(taxInitialValues);
          setUpdateCart(true);
          // resetForm();
          setShowError(false);
          setTaxInfo(values);
        } else {
          setUpdateCart(false);
          setShowSuccess(false);
          setShowError(true);
        }
      })
      .catch(error => console.log('Request failed with this message, ', error?.message));
  };

  // Handler to cancel tax form data
  const handleCancel = (e, resetForm) => {
    e.preventDefault();
    setShowError(false);
    setShowSuccess(false);
    setTaxFormdata(taxInitialValues);
    resetForm();
  };

  // Tax exemption form handling and data submission logic ends here ------------------------------------

  // Logic for handling VAT related operations starts here ----------------------------------------------
  const [loadVAT, setLoadVAT] = useState(false);
  const [vatNumber, setVatNumber] = useState(false);
  const [vatError, setVatError] = useState(true);

  // Mutation for adding vat id to checkout
  const [updateVAT, { loading: vatIdLoading, error: vatIdError, data: vatIdData }] =
    useMutation(UPDATE_VAT_TO_CHECKOUT);

  // Script to run only in case of non US locales as this component will not be shown for US
  useEffect(() => {
    if (country?.code !== 'US') {
      let script = document.createElement('script');
      script.src = 'https://js.digitalriverws.com/v1/DigitalRiver.js';
      script.type = 'text/javascript';
      script.onload = function () {
        setLoadVAT(true);
      };
      script.onerror = function () {
        console.error('An error occurred while loading the DigitalRiver script.');
      };
      document.head.appendChild(script);

      return () => {
        document.head.removeChild(script);
      };
    }
  }, []);

  // Once the above script is run, fire this effect everytime form is opened
  // loadVAT is made true when script is loaded in the above useEffect
  // To avoid node not found errors as there is conditional rendering, we fire
  // useEffect only when openForm is also true as the node will be there in the
  // VirtualDOM
  useEffect(() => {
    if (loadVAT && openForm) {
      if (document.querySelector('#tax-vat-parent')) {
        let digitalriver = new DigitalRiver(drPublicKey);

        let options = {
          classes: {
            base: 'DRElement',
            complete: 'taxId-complete',
            empty: 'taxId-empty',
            focus: 'taxId-focus',
          },
          style: {
            base: {
              color: '#495057',
              height: '35px',
              fontSize: '1rem',
              fontFamily: 'apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,sans-serif',
            },
            complete: {
              color: 'green',
              ':-webkit-autofill': {
                color: 'green',
              },
            },
          },
          taxIdentifier: {
            country: country?.code,
            type: 'business',
          },
        };

        let taxIdentifier = digitalriver.createElement('taxidentifier', options);
        taxIdentifier.mount('tax-vat-parent');
        taxIdentifier.on('change', event => {
          if (event.complete) {
            setVatNumber(event.identifier.value);
            setVatError(false);
          } else {
            setVatError(true);
          }
        });
      }
    }
  }, [loadVAT, openForm]);

  const handleVatSubmit = () => {
    if (getVatId(country?.code)) {
      updateVAT({
        variables: {
          cart_id: cart_id,
          type: getVatId(country?.code),
          value: vatNumber,
        },
      })
        .then(data => {
          if (data?.data?.core_add_vat_id_to_checkout?.status) {
            setShowSuccess(true);
            setUpdateCart(true);
            // resetForm();
            setShowError(false);
            setTaxInfo(values);
          } else {
            setUpdateCart(false);
            setShowSuccess(false);
            setShowError(true);
          }
        })
        .catch(error => console.log('Request failed with this message, ', error?.message));
    } else {
      setShowSuccess(false);
      setShowError(true);
    }
  };
  // Logic for handling VAT related operations ends here ----------------------------------------------

  return (
    <>
      <div
        className={`cmp-acommerce_checkout-v2__fragment cmp-acommerce_checkout-v2__fragment${
          enableTax ? '' : '--disable'
        } tax-fragment ${taxLoading ? 'submitting' : ''}`}>
        {!isLoggedIn ? (
          <div className="cmp-acommerce_checkout-v2__fragment-head">
            <h4
              className="cmp-acommerce_checkout-v2__fragment-login"
              onClick={() => {
                setCookie('guest_cart_id', cart_id);
                setCookie('tax_exempt_login', true);
                loginToggleConfirmation();
              }}>
              <Icon name={`${openForm ? 'Minus' : 'Plus'}`} className="tax-form-icon" />
              {loginForTax}
            </h4>
          </div>
        ) : (
          <div className="cmp-acommerce_checkout-v2__fragment-head">
            <h4
              className="cmp-acommerce_checkout-v2__fragment-heading tax-form-open"
              onClick={() => {
                setOpenForm(prev => !prev);
              }}>
              {/* {openForm ? (
                <Icon name="Minus" className="tax-form-icon" />
              ) : (
                <Icon name="Plus" className="tax-form-icon" />
              )} */}
              <Icon name="Plus" className={`tax-form-icon ${openForm ? 'hide' : 'show'}`} />
              <Icon name="Minus" className={`tax-form-icon ${openForm ? 'show' : 'hide'}`} />
              {!showSuccess ? (
                <>{taxExemptButton}</>
              ) : (
                <>
                  {taxApplied}
                  <Icon name="CheckMark" />
                </>
              )}
            </h4>
          </div>
        )}
        {openForm && (
          <div className="cmp-acommerce_checkout-v2__fragment-body">
            {!showSuccess ? (
              country?.code === 'US' ? (
                <Formik
                  initialValues={taxFormdata}
                  validationSchema={taxValidationSchema}
                  enableReinitialize
                  onSubmit={handleTaxExemption}>
                  {({ values, setFieldValue, resetForm }) => {
                    return (
                      <Form>
                        <div className="tax-exemption">
                          <InputField
                            name="taxCompanyName"
                            label={companyNameLabel}
                            type="text"
                            hidden={true}
                            isMandatory
                          />
                          <div className="cmp-acommerce_checkout-v2__form-group tax-authority">
                            <div className="tax-authority">
                              <label className="cmp-acommerce_dropdown-label">
                                {taxExemptionCertificateLabel}
                                <span className="mandatory_asterisk">*</span>
                                <button
                                  type="button"
                                  className="tax-authority__tooltip-button"
                                  onClick={() => setShowTooltip(prev => !prev)}>
                                  {taxExemptionTooltipButton}
                                  {showTooltip && (
                                    <span className="tax-authority__tooltip-info">{taxExemptionTooltipLabel}</span>
                                  )}
                                </button>
                              </label>
                              <Dropdown
                                name="taxAuthority"
                                options={taxAuthorities}
                                isMandatory
                                className="tax-exemption-select"
                              />
                            </div>
                          </div>
                          <div className="cmp-acommerce_checkout-v2__flex-group">
                            <div className="cmp-acommerce_checkout-v2__form-group">
                              <label className="cmp-acommerce_dropdown-label">
                                <strong>{taxExemptionStartDate}</strong>
                                <span className="mandatory_asterisk">*</span>
                              </label>
                              <div className="cmp-acommerce_checkout-v2__form-group date">
                                <Dropdown name="startDateMonth" options={months} className="tax-exemption-select" />
                                <Dropdown name="startDateYear" options={years} className="tax-exemption-select" />
                              </div>
                            </div>
                            <div className="cmp-acommerce_checkout-v2__form-group">
                              <label className="cmp-acommerce_dropdown-label">
                                <strong>{taxExemptionExpireDate}</strong>
                                <span className="mandatory_asterisk">*</span>
                              </label>
                              <div className="cmp-acommerce_checkout-v2__form-group date">
                                <Dropdown
                                  name="expirationDateMonth"
                                  options={months}
                                  className="tax-exemption-select"
                                />
                                <Dropdown name="expirationDateYear" options={years} className="tax-exemption-select" />
                              </div>
                            </div>
                          </div>
                          <div className="cmp-acommerce_checkout-v2__form-group certificate">
                            <label htmlFor="certificate">
                              {taxExemptionUploadCertificate}
                              <span className="mandatory_asterisk">*</span>
                            </label>
                            <span htmlFor="certificate">{taxExemptionSupportFile}</span>
                            <span>{taxMaximumFileSize}</span>
                            <input
                              type="file"
                              name="certificate"
                              id="certificate"
                              onChange={event => {
                                setFieldValue('certificate', event.currentTarget.files[0]);
                              }}
                            />
                            <label className="certificate__input" htmlFor="certificate">
                              {taxUploadFile}
                            </label>
                            {values.certificate?.name && <span>{values.certificate?.name}</span>}
                            <ErrorMessage name="certificate" component="div" className="form-input-error" />
                          </div>
                        </div>
                        <span className="required-fields">
                          <span className="mandatory_asterisk">*</span>
                          {requiredFields}
                        </span>
                        <div className="cmp-acommerce_checkout-v2__form-actions">
                          <Button>{taxExemptionSubmit}</Button>
                          <Button onClick={e => handleCancel(e, resetForm)} className="tax-exemption-cancel">
                            {taxExemptionCancel}
                          </Button>
                        </div>
                        {/* {taxLoading && (
                          <div className="cmp-acommerce_checkout-v2__form-submission">
                            <Icon name="LoadingRing" className="cmp-acommerce_checkout-v2__form-submission__ring" />
                            {taxSubmission}
                          </div>
                        )} */}
                        {showError && <div className="submiterror">{taxExemptionError}</div>}
                        {vatIdError && <div className="submiterror">{vatIdError?.message}</div>}
                      </Form>
                    );
                  }}
                </Formik>
              ) : (
                <div>
                  <div id="tax-vat-parent"></div>
                  <div className="cmp-acommerce_checkout-v2__form-actions">
                    <Button onClick={handleVatSubmit} disabled={vatError}>
                      {taxExemptionSubmit}
                    </Button>
                    <Button
                      onClick={() => {
                        setOpenForm(false);
                        setShowError(false);
                        setShowSuccess(false);
                      }}
                      className="tax-exemption-cancel">
                      {taxExemptionCancel}
                    </Button>
                  </div>
                  {showError && (
                    <div className="submiterror">{getVatId(country?.code) ? taxExemptionError : invalidVat}</div>
                  )}
                  {taxError && <div className="submiterror">{taxError?.message}</div>}
                </div>
              )
            ) : country?.code === 'US' ? (
              <>
                <p>
                  <strong>{taxInfo?.taxCompanyName}</strong>
                </p>
                <p>
                  {taxExemptionCertificateLabel}: {taxInfo?.taxAuthority}
                </p>
                <p>
                  {validFrom} {months[0].options.find(month => month.value === taxInfo?.startDateMonth)?.label}{' '}
                  {taxInfo?.startDateYear} {through}{' '}
                  {months[0].options.find(month => month.value === taxInfo?.expirationDateMonth)?.label}{' '}
                  {taxInfo?.expirationDateYear}
                </p>
                <br />
                <p>
                  <strong>{taxFileUploaded}:</strong> {taxInfo?.certificate?.name}
                </p>
              </>
            ) : (
              <p>{taxExemptionSuccess}</p>
            )}
          </div>
        )}
      </div>
      {(stateLoading || taxLoading || vatIdLoading) && createPortal(<Loader />, document.body)}
      {isLoginConfirmation && (
        <ModalPopup
          isShowing={isLoginConfirmation}
          hide={() => {
            // Need to delete these cookies here as
            clearCookie('tax_exempt_login');
            clearCookie('guest_cart_id');
            loginToggleConfirmation();
          }}
          className="auth-popup">
          <LoginForm changeFormHandler={handleUserForm} forgetPasswordHandler={forgetPasswordHandler} />
        </ModalPopup>
      )}
      {isCAConfirmation && (
        <ModalPopup
          className="auth-popup"
          isShowing={isCAConfirmation}
          hide={() => {
            // Need to delete these cookies here as
            clearCookie('tax_exempt_login');
            clearCookie('guest_cart_id');
            caToggleConfirmation();
          }}>
          <CreateAccount cancelFormHandler={cancelFormHandler} createAccountHandler={createAccountHandler} />
        </ModalPopup>
      )}
      {isForgetPasswordLogin && (
        <ModalPopup
          isShowing={isForgetPasswordLogin}
          hide={() => {
            // Need to delete these cookies here as
            clearCookie('tax_exempt_login');
            clearCookie('guest_cart_id');
            forgetToggleConfirmation();
          }}
          className="auth-popup">
          <ForgetPassword cancelFormHandler={cancelFormHandler} forgetPasswordHandler={forgetPasswordHandler} />
        </ModalPopup>
      )}
    </>
  );
};

export default TaxExemption;
