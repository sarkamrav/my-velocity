import React, { useEffect, useState, useMemo, forwardRef } from 'react';
import { createPortal } from 'react-dom';
import Icon from '../../../../assests/Icon';
import { Formik, Form } from 'formik';
import * as Yup from 'yup';
import InputField from '../../../inputfield/InputField';
import Checkbox from '../../../micro-components/Checkbox/Checkbox';
import { useLazyQuery, useMutation, useQuery } from '@apollo/client';
import { COUNTRY_QUERY } from '../../../../site/js/gql/countries.gql';
import { STATE_QUERY } from '../../../../site/js/gql/states.gql';
import Dropdown from '../../../micro-components/Dropdown/Dropdown';
import Button from '../../../micro-components/Button/Button';
import Loader from '../../../micro-components/Loader/Loader';
import Address from '../../../Address/Address';
import { getCookie } from '../../../../utils/cookies_operation';
import {
  ASSIGN_EMAIL_GUEST,
  SET_SHIPPING_ADDRESS_ON_CART,
  SET_BILLING_AS_SHIPPING,
  SET_BILLING_ADDRESS_ON_CART,
} from '../../../../site/js/gql/mutations/checkout-v2.gql';
import { UPDATE_QUOTE_FIELD } from '../../../../site/js/gql/mutations/updateQuoteField.gql';
import GuestShippingForm from './GuestShippingForm/GuestShippingForm';
import UserShippingForm from './UserShippingForm/UserShippingForm';
import { GET_ADDRESS } from '../../../../site/js/gql/get-address.gql';
import CUSTOMER_INFO_STU_EMP from '../../../../site/js/gql/get-customer-info.gql';
import { useStoreContext } from '../../../../contexts/common/StoreContext';
import { fetchAddressData } from '../../../../contexts/common/actions/checkoutaction';
import { getCatalogServiceHeaders } from '../../../../configs/ReactApolloClientSetup/ApolloClientConfig';
import { clientConfigUsingGet } from '../../../../configs/ReactApolloClientSetup/ApolloClientConfig.js';
import AddressSearch from 'react-loqate';
import { isJsonString } from '../../../../utils/utils.js';

const AddressFragment = ({
  isLoggedIn,
  isBusinessPurchased,
  purchaseType,
  setEnableShipping,
  setEnableTax,
  setEnablePayment,
  removeVAT,
  shippingAddressTitle,
  billingAddressTitle,
  addressEditLabel,
  addressFormName,
  firstnameRequiredError,
  firstnameLengthError,
  lastnameRequiredError,
  lastnameLengthError,
  addressLine1RequiredError,
  addressLengthError,
  cityRequiredError,
  cityLengthError,
  stateRequiredError,
  zipcodeRequiredError,
  zipCodeLengthError,
  countryRequiredError,
  emailInvalidError,
  emailRequiredError,
  emailUnmatchError,
  verifyEmailRequiredError,
  companyRequiredError,
  companyLengthError,
  customerPoLabel,
  customerPoError,
  poLengthError,
  phoneNumberRequiredError,
  phoneNumberLengthError,
  emailLabel,
  verifyEmailLabel,
  additionalInformationLabel,
  selectOne,
  notApplicable,
  countryLabel,
  stateLabel,
  firstNameLabel,
  lastNameLabel,
  addressLine1Label,
  addressLine2Label,
  cityLabel,
  zipCodeLabel,
  companyNameLabel,
  phoneNumberLabel,
  sameAddress,
  saveContinue,
  welcomeBack,
  savedAddresses,
  addShippingAddress,
  cancel,
  emailReminderLabel,
  specialPackageLabel,
  standardPackage,
  clamshellPackage,
  addressSearch,
  addressPlaceholder,
  zipcodeShippingError,
  zipcodeBillingError,
  zipcodeError,
  loqateKey,
  serverError,
  poBoxError,
  savedDefault,
}) => {
  const { dispatch } = useStoreContext();
  const [billingAddressForm, setBillingAddressForm] = useState(false);
  const cart_id = getCookie('cart_id') && JSON.parse(getCookie('cart_id'));
  const [poNumber, setPoNumber] = useState('');
  const [searchedShippingAddress, setSearchedShippingAddress] = useState({});
  const [searchedBillingAddress, setSearchedBillingAddress] = useState({});

  // Logic to get customer email if logged in
  const [userEmail, setUserEmail] = useState('');
  const [getUserEmail, {}] = useLazyQuery(CUSTOMER_INFO_STU_EMP);
  useEffect(() => {
    if (isLoggedIn) {
      getUserEmail().then(data => {
        setUserEmail(data?.data?.core_customer?.email);
        setShippingMethodData(prev => ({
          ...prev,
          email: data?.data?.core_customer?.email,
        }));
      });
    }
  }, [isLoggedIn]);

  // ----------------Formik and Yup code starts here--------------
  // Initial values for the form details
  const initialValues = {
    billingAddressSearch: '',
    shippingAddressSearch: '',
    differentAddress: true,
    firstName: '',
    lastName: '',
    addressLine1: '',
    addressLine2: '',
    city: '',
    state: '',
    postalCode: '',
    country: '',
    phoneNumber: '',
    emailReminder: false,
    additionalInfo: false,
    companyName: '',
    shippingAddress: '',
    shippingFirstName: '',
    shippingLastName: '',
    shippingAddressLine1: '',
    shippingAddressLine2: '',
    shippingCity: '',
    shippingState: '',
    shippingPostalCode: '',
    shippingCountry: '',
    shippingPhoneNumber: '',
    shippingCompanyName: '',
    po_number: '',
    pack_count_tray: 'standard',
    email: '',
    verifyemail: '',
  };
  const [formdata, setFormdata] = useState(initialValues);

  // Function to generate validation schema dynamically
  const getValidationSchema = () => {
    return Yup.object({
      billingAddressSearch: Yup.string(),
      shippingAddressSearch: Yup.string(),
      differentAddress: Yup.bool(),
      shippingAddress: Yup.string(),
      shippingFirstName: Yup.string().required(firstnameRequiredError).max('35', firstnameLengthError),
      shippingLastName: Yup.string().required(lastnameRequiredError).max('35', lastnameLengthError),
      shippingAddressLine1: Yup.string()
        .required(addressLine1RequiredError)
        .max('35', addressLengthError)
        .test('no-po-box', poBoxError, value => !/P\.?\s?O\.?\s?Box/i.test(value)),
      shippingAddressLine2: Yup.string()
        .max('35', addressLengthError)
        .test('no-po-box', poBoxError, value => !/P\.?\s?O\.?\s?Box/i.test(value)),
      shippingCity: Yup.string().required(cityRequiredError).max('128', cityLengthError),
      shippingState:
        isLoggedIn && !editShippingAddress && !addingAddress
          ? Yup.string().nullable()
          : shippingStates && shippingStates[0]?.options?.length > 1
          ? Yup.string().required(stateRequiredError)
          : Yup.string().nullable(),
      shippingPostalCode: Yup.string().required(zipcodeRequiredError).max('32', zipCodeLengthError),
      shippingCountry: Yup.string().required(countryRequiredError),
      shippingCompanyName: isBusinessPurchased
        ? Yup.string().required(companyRequiredError).max('40', companyLengthError)
        : Yup.string().max('40', companyLengthError),
      shippingPhoneNumber: Yup.string()
        .required(phoneNumberRequiredError)
        .min('6', phoneNumberLengthError)
        .max('32', phoneNumberLengthError),
      ...(isBusinessPurchased && {
        po_number: Yup.string().required(customerPoError).max('64', poLengthError),
      }),
      ...(!isLoggedIn && {
        email: Yup.string().email(emailInvalidError).required(emailRequiredError),
        verifyemail: Yup.string()
          .oneOf([Yup.ref('email'), null], emailUnmatchError)
          .required(verifyEmailRequiredError),
      }),
      ...(billingAddressForm && {
        firstName: Yup.string().required(firstnameRequiredError).max('35', firstnameLengthError),
        lastName: Yup.string().required(lastnameRequiredError).max('35', lastnameLengthError),
        addressLine1: Yup.string()
          .required(addressLine1RequiredError)
          .max('35', addressLengthError)
          .test('no-po-box', poBoxError, value => !/P\.?\s?O\.?\s?Box/i.test(value)),
        addressLine2: Yup.string()
          .max('35', addressLengthError)
          .test('no-po-box', poBoxError, value => !/P\.?\s?O\.?\s?Box/i.test(value)),
        city: Yup.string().required(cityRequiredError).max('128', cityLengthError),
        state:
          states && states[0]?.options?.length > 1
            ? Yup.string().required(stateRequiredError)
            : Yup.string().nullable(),
        postalCode: Yup.string().required(zipcodeRequiredError).max('32', zipCodeLengthError),
        country: Yup.string().required(countryRequiredError),
        companyName: Yup.string().max('40', companyLengthError),
        phoneNumber: Yup.string()
          .required(phoneNumberRequiredError)
          .min('6', phoneNumberLengthError)
          .max('32', phoneNumberLengthError),
      }),
      additionalInfo: Yup.bool(),
      emailReminder: Yup.bool(),
      ...(isLoggedIn &&
        isBusinessPurchased && {
          pack_count_tray: Yup.string(),
        }),
    });
  };

  // ----------------Logic to get countries and states to populate dropdowns------------
  // Initial options for dropdowns
  const initialOptions = [
    {
      id: null,
      options: [
        {
          value: '',
          label: selectOne,
        },
      ],
    },
  ];

  // Need separate states objects for billing and shipping
  // to avoid doubling the options on page load in the state dropdowns
  //  for Shipping and Billing address forms
  const initialShippingStates = [
    {
      options: [
        {
          value: '',
          label: selectOne,
        },
      ],
    },
  ];
  const initialBillingStates = [
    {
      options: [
        {
          value: '',
          label: selectOne,
        },
      ],
    },
  ];

  const initialStates = [
    {
      id: null,
      options: [
        {
          value: '',
          label: notApplicable,
        },
      ],
    },
  ];

  // Options for Special package radio inputs
  // Special packaging options
  const specialPackageOptions = [
    {
      label: standardPackage,
      value: 'standard',
    },
    {
      label: clamshellPackage,
      value: 'clamshell',
    },
  ];

  // Logic for countries and states including variables and queries starts -----------------------------------
  const [countries, setCountries] = useState(initialOptions);
  const [states, setStates] = useState(initialStates);
  const [shippingStates, setShippingStates] = useState(initialStates);
  const [selectedCountry, setSelectedCountry] = useState('');
  const [selectedShippingCountry, setSelectedShippingCountry] = useState('');

  // Country query and state query
  const gqlClientFotGet = useMemo(() => clientConfigUsingGet(), []);
  const { data: countryData } = useQuery(COUNTRY_QUERY, { client: gqlClientFotGet });
  const [getAvailableStates, { loading: stateLoading }] = useLazyQuery(STATE_QUERY);

  // Function to get the default country from locale
  const locale = getCatalogServiceHeaders();
  const getDefaultCountry = () => {
    if (
      locale === 'en_us' ||
      locale === 'en_gb' ||
      locale === 'fr' ||
      locale === 'de' ||
      locale === 'es_es' ||
      locale === 'it'
    ) {
      return locale?.includes('_') ? locale?.split('_')[1].toUpperCase() : locale.toUpperCase();
    }
  };

  // Effect to populate countries variable and use in dropdowns
  useEffect(() => {
    if (countryData) {
      let countriesArrayOptions = initialOptions;
      [...countryData.core_countries]
        .sort((a, b) => a.full_name_english.localeCompare(b.full_name_english))
        .forEach(item => {
          countriesArrayOptions.forEach(countriesOptions => {
            countriesOptions.options.push({
              value: item.id,
              label: item.full_name_locale,
            });
          });
        });
      setCountries(countriesArrayOptions);

      // Autopopulate the country dropdowns for Shipping form as well billing form
      if (getDefaultCountry()) {
        if (!isLoggedIn || (isLoggedIn && addressOptions[0]?.options.length === 0)) {
          setFormdata(prev => ({
            ...prev,
            country: getDefaultCountry(),
            shippingCountry: getDefaultCountry(),
          }));
        } else {
          setFormdata(prev => ({
            ...prev,
            country: getDefaultCountry(),
          }));
        }
      }
    }
  }, [countryData]);

  // Effect to get states when a country is selected
  useEffect(() => {
    if (selectedCountry) {
      getAvailableStates({ variables: { id: selectedCountry } })
        .then(states => {
          if (states.data.core_country.available_regions) {
            const stateArrayOptions = initialBillingStates;
            stateArrayOptions[0].id = states.data.core_country.two_letter_abbreviation;
            [...states.data.core_country.available_regions]
              .sort((a, b) => a.name.localeCompare(b.name))
              .forEach(state => {
                stateArrayOptions.forEach(stateOption => {
                  stateOption.options.push({
                    value: state.code,
                    label: state.name,
                  });
                });
              });
            setStates(stateArrayOptions);
          } else {
            setStates(initialStates);
          }
        })
        .catch(error => console.log(`Server responded with an error - ${error.message}`));
    } else {
      setStates(initialStates);
    }
  }, [selectedCountry]);

  // Effect to get shipping states when a country is selected
  useEffect(() => {
    if (selectedShippingCountry) {
      getAvailableStates({ variables: { id: selectedShippingCountry } })
        .then(states => {
          if (states.data.core_country.available_regions) {
            const stateArrayOptions = initialShippingStates;
            stateArrayOptions[0].id = states.data.core_country.two_letter_abbreviation;
            [...states.data.core_country.available_regions]
              .sort((a, b) => a.name.localeCompare(b.name))
              .forEach(state => {
                stateArrayOptions.forEach(stateOption => {
                  stateOption.options.push({
                    value: state.code,
                    label: state.name,
                  });
                });
              });
            setShippingStates(stateArrayOptions);
          } else {
            setShippingStates(initialStates);
          }
        })
        .catch(error => console.log(`Server responded with an error - ${error.message}`));
    } else {
      setShippingStates(initialStates);
    }
  }, [selectedShippingCountry]);
  // Logic for countries and states including variables and queries ends -----------------------------------

  // Logic for getting and setting addresses of logged in users starts -------------------------------------
  const initialAddress = [
    {
      options: [],
    },
  ];
  const [addressOptions, setAddressOptions] = useState(initialAddress);
  const [customerAddresses, setCustomerAddresses] = useState([]);
  const [selectedShippingAddress, setSelectedShippingAddress] = useState({});
  const [editShippingAddress, setEditShippingAddress] = useState(false);
  const [editAddresses, setEditAddreses] = useState(false);

  // Query to get the available addresses of logged in user
  const [getCustomerAddress, { data: customerAddressData, loading: customerAddressLoading }] =
    useLazyQuery(GET_ADDRESS);

  // Function to find address by ID
  const findAddressById = id => {
    return customerAddresses.find(address => address.id === id);
  };

  // Handler to edit the selected address from the address dropdown
  const handleEditAddress = id => {
    setSearchedShippingAddress({});
    setSearchedBillingAddress({});
    // resetForm();
    let address = findAddressById(id);
    setFormdata(prev => ({
      ...prev,
      shippingAddress: id,
      shippingCountry: address?.country_code,
      shippingFirstName: address?.firstname,
      shippingLastName: address?.lastname,
      shippingAddressLine1: address?.street[0],
      shippingAddressLine2: address?.street[1] || '',
      shippingCity: address?.city,
      shippingCompanyName: address?.company || '',
      shippingState: address?.region?.region_code,
      shippingPhoneNumber: address?.telephone,
      shippingPostalCode: address?.postcode,
    }));
    setEditShippingAddress(true);
  };

  // Variable and handler to track and perform adding new address when user is logged in
  const [addingAddress, setAddingAddress] = useState(false);
  const [addingAddressOnce, setAddingAddressOnce] = useState(false);
  const handleAddAddress = resetForm => {
    setAddingAddress(true);
    setAddingAddressOnce(true);
    setSearchedShippingAddress({});
    setSearchedBillingAddress({});
    setFormdata(initialValues);
    resetForm();
    if (getDefaultCountry()) {
      setFormdata(prev => ({
        ...prev,
        shippingCountry: getDefaultCountry(),
        country: getDefaultCountry(),
      }));
    }
    if (isLoggedIn) {
      setSelectedShippingAddress(
        customerAddressData?.core_customer?.addresses?.find(option => option?.default_shipping) ||
          customerAddressData?.core_customer?.addresses[0]
      );
    }
    setEditShippingAddress(true);
  };

  // Effect to populate saved addresses only when the user is logged in
  // Also if the user has logged in for tax exemption then to retrieve the data that was previously submitted
  useEffect(() => {
    if (isLoggedIn) {
      getCustomerAddress();
    }
  }, [isLoggedIn]);

  useEffect(() => {
    if (customerAddressData && customerAddressData?.core_customer?.addresses?.length > 0) {
      setCustomerAddresses(customerAddressData?.core_customer?.addresses);
      let addressArrayOptions = initialAddress;
      customerAddressData?.core_customer?.addresses?.forEach(item => {
        const getValueByAttributeCode = attributeCode => {
          const attribute = item?.custom_attributes?.find(attr => attr.attribute_code === attributeCode);
          return attribute ? attribute.value : '';
        };
        const nickName = getValueByAttributeCode('nick_name');
        addressArrayOptions.forEach(addressOption => {
          addressOption.options.push({
            value: item.id,
            label: nickName
              ? item?.default_shipping
                ? `${nickName} (${savedDefault})`
                : nickName
              : item?.default_shipping
              ? `${item?.street[0]} (${savedDefault})`
              : item?.street[0],
          });
        });
      });
      let defaultAddress =
        customerAddressData?.core_customer?.addresses?.find(option => option?.default_shipping) ||
        customerAddressData?.core_customer?.addresses[0];
      setAddressOptions(addressArrayOptions);
      setSelectedShippingAddress(defaultAddress);
      setFormdata(prev => ({
        ...prev,
        shippingAddress: defaultAddress?.id,
        shippingFirstName: defaultAddress?.firstname,
        shippingLastName: defaultAddress?.lastname,
        shippingAddressLine1: defaultAddress?.street[0],
        shippingAddressLine2: defaultAddress?.street[1] || '',
        shippingCity: defaultAddress?.city,
        shippingState: defaultAddress?.region?.region_code || '',
        shippingCountry: defaultAddress?.country_code,
        shippingPhoneNumber: defaultAddress?.telephone,
        shippingPostalCode: defaultAddress?.postcode,
        shippingCompanyName: defaultAddress?.company || '',
      }));
    }
  }, [customerAddressData]);

  // Logic for getting and setting addresses of logged in users ends -------------------------------------

  // Variables and Mutations for getting and setting address for customer on cart starts ---------------------
  const [billingAddress, setBillingAddress] = useState({});
  const [shippingAddress, setShippingAddress] = useState({});

  const [setShippingAddressOnCart, { error: shippingAddressError }] = useMutation(SET_SHIPPING_ADDRESS_ON_CART);

  const [setBillingAsShipping, { error: sameBillingError }] = useMutation(SET_BILLING_AS_SHIPPING);

  const [setBillingAddressOnCart, { error: billingAddressError }] = useMutation(SET_BILLING_ADDRESS_ON_CART);

  // Mutations for getting and setting address for customer on cart ends ---------------------

  // Mutation to update the quotes on the cart
  const [updateQuoteField, { error: updateQuoteError }] = useMutation(UPDATE_QUOTE_FIELD);

  //Mutation to Add email to guest
  const [setGuestEmailOnCart, { error: guestEmailError }] = useMutation(ASSIGN_EMAIL_GUEST);

  // Submit handler and edit handle logic starts ---------------------------------------------------------------
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [submitLoader, setSubmitLoader] = useState(false);

  // Handler to make address edit operations
  const handleEdit = () => {
    setSearchedShippingAddress({});
    setSearchedBillingAddress({});
    setEditAddreses(true);
    setSubmitSuccess(false);
    setEnableShipping(false);
    setEnableTax(false);
    setEnablePayment(false);

    if (isLoggedIn && getCatalogServiceHeaders() !== 'en_us') {
      removeVAT({
        variables: {
          cart_id: cart_id,
        },
      }).catch(error => console.log(`Server responded with an error - ${error.message}`));
    }
  };

  // State to dispatch the finalised data to store when the submit is successful
  // to be used in the later payments section
  const [shippingMethodData, setShippingMethodData] = useState({});
  useEffect(() => {
    if (shippingMethodData) {
      dispatch(fetchAddressData(shippingMethodData));
    }
  }, [shippingMethodData]);

  // Handler to make submit operations
  const handleSubmit = async values => {
    setErrorMessage('');
    setSubmitLoader(true);

    try {
      if (!isLoggedIn) {
        await setGuestEmailOnCart({
          variables: {
            cart_id: cart_id,
            email: values.email,
          },
        }).then(data => {
          setShippingMethodData(prev => ({
            ...prev,
            email: data?.data?.core_setGuestEmailOnCart?.cart?.email,
          }));
          setUserEmail(data?.data?.core_setGuestEmailOnCart?.cart?.email);
        });
      }

      // If both shipping/billing use same address
      if (!billingAddressForm) {
        // Creating a common address object with shipping form values
        // to use for both addresses
        // Creating a street array as api accepts array for street field
        const streetAddressValues = [values.shippingAddressLine1];
        if (values.shippingAddressLine2) {
          streetAddressValues.push(values.shippingAddressLine2);
        }

        // Either get the form values or the dropdown selected address values
        const commonAddress = {
          firstName: values.shippingFirstName,
          lastName: values.shippingLastName,
          company: values.shippingCompanyName,
          streetAddress: streetAddressValues,
          city: values.shippingCity,
          region: values.shippingState !== null ? values.shippingState : '',
          postalCode: values.shippingPostalCode,
          country: values.shippingCountry,
          telephone: values.shippingPhoneNumber,
        };

        // Added saveAddress variable
        // It will be true when user is logged in and is adding a new address
        // It will be true when user is guest
        // It will be false when user is using a saved address
        await setShippingAddressOnCart({
          variables: {
            cart_id: cart_id,
            ...commonAddress,
            saveAddress: isLoggedIn ? (addressOptions[0]?.options.length === 0 ? true : addingAddress) : false,
          },
        }).then(({ data }) => {
          setShippingAddress(data?.core_setShippingAddressesOnCart?.cart?.shipping_addresses[0]);
          setShippingMethodData(prev => ({
            ...prev,
            shipping_address: data?.core_setShippingAddressesOnCart?.cart?.shipping_addresses,
          }));
        });

        await setBillingAsShipping({
          variables: {
            cart_id: cart_id,
            sameAsShipping: true,
          },
        }).then(({ data }) => {
          setBillingAddress(data?.core_setBillingAddressOnCart?.cart?.billing_address);
          setShippingMethodData(prev => ({
            ...prev,
            billing_address: data?.core_setBillingAddressOnCart?.cart?.billing_address,
          }));
        });
      } else {
        // Different billing address and shipping address
        const billingStreetAddressValues = [values.addressLine1];
        if (values.addressLine2) {
          billingStreetAddressValues.push(values.addressLine2);
        }
        const billingAddress = {
          firstName: values.firstName,
          lastName: values.lastName,
          company: values.companyName,
          streetAddress: billingStreetAddressValues,
          city: values.city,
          region: values.state !== null ? values.state : '',
          postalCode: values.postalCode,
          country: values.country,
          telephone: values.phoneNumber,
        };

        const shippingStreetAddressValues = [values.shippingAddressLine1];
        if (values.shippingAddressLine2) {
          shippingStreetAddressValues.push(values.shippingAddressLine2);
        }
        const shippingAddress = {
          firstName: values.shippingFirstName,
          lastName: values.shippingLastName,
          company: values.shippingCompanyName,
          streetAddress: shippingStreetAddressValues,
          city: values.shippingCity,
          region: values.shippingState !== null ? values.shippingState : '',
          postalCode: values.shippingPostalCode,
          country: values.shippingCountry,
          telephone: values.shippingPhoneNumber,
        };

        await setShippingAddressOnCart({
          variables: {
            cart_id: cart_id,
            ...shippingAddress,
            saveAddress: isLoggedIn ? (addressOptions[0]?.options.length === 0 ? true : addingAddress) : false,
          },
        }).then(({ data }) => {
          setShippingAddress(data?.core_setShippingAddressesOnCart?.cart?.shipping_addresses[0]);
          setShippingMethodData(prev => ({
            ...prev,
            shipping_address: data?.core_setShippingAddressesOnCart?.cart?.shipping_addresses,
          }));
        });

        await setBillingAddressOnCart({
          variables: {
            cart_id: cart_id,
            ...billingAddress,
          },
        }).then(({ data }) => {
          setBillingAddress(data?.core_setBillingAddressOnCart?.cart?.billing_address);
          setShippingMethodData(prev => ({
            ...prev,
            billing_address: data?.core_setBillingAddressOnCart?.cart?.billing_address,
          }));
        });
      }

      await updateQuoteField({
        variables: {
          cart_id: cart_id,
          order_type: purchaseType,
          po_number: isBusinessPurchased ? values.po_number : '',
          pack_count_tray: isBusinessPurchased && isLoggedIn ? values.pack_count_tray : '',
          opt_in: values.additionalInfo,
          request_email: values.emailReminder,
        },
      }).then(() => setPoNumber(values.po_number));
      setSubmitLoader(false);
      setSubmitSuccess(true);
      setEnableShipping(true);
    } catch (error) {
      setSubmitLoader(false);
      setSubmitSuccess(false);
      setEnableShipping(false);
      console.log(`Server responded with an error - ${error.message}`);
    }
  };
  // Submit handler and edit handle logic ends ---------------------------------------------------------------

  // Variable and useEffect to display error from the API on the page
  const [errorMessage, setErrorMessage] = useState('');
  useEffect(() => {
    setErrorMessage('');
    if (shippingAddressError || sameBillingError || billingAddressError) {
      // Check if the API returned a stringified object and zipcode error
      if (shippingAddressError) {
        let parsedMessage = shippingAddressError?.message;
        if (isJsonString(parsedMessage)) {
          parsedMessage = JSON.parse(shippingAddressError?.message);
        }
        if (
          (typeof parsedMessage === 'object' &&
            parsedMessage?.code === 'invalid_parameter' &&
            parsedMessage?.parameter === 'address.postalCode') ||
          (typeof parsedMessage === 'object' && parsedMessage?.code === 'postal_code_invalid')
        ) {
          !billingAddressForm ? setErrorMessage(zipcodeError) : setErrorMessage(zipcodeShippingError);
        } else if (typeof parsedMessage === 'object' && parsedMessage?.code === 'missing_parameter') {
          setErrorMessage(serverError);
        } else {
          setErrorMessage(shippingAddressError?.message);
        }
        return;
      }

      if (sameBillingError) {
        let parsedMessage = sameBillingError?.message;
        if (isJsonString(parsedMessage)) {
          parsedMessage = JSON.parse(sameBillingError?.message);
        }
        if (
          (typeof parsedMessage === 'object' &&
            parsedMessage?.code === 'invalid_parameter' &&
            parsedMessage?.parameter === 'billingAddress.postalCode') ||
          (typeof parsedMessage === 'object' && parsedMessage?.code === 'postal_code_invalid')
        ) {
          setErrorMessage(prev => (prev?.length > 0 ? prev.concat(`. ${zipcodeError}`) : zipcodeError));
        } else if (typeof parsedMessage === 'object' && parsedMessage?.code === 'missing_parameter') {
          setErrorMessage(serverError);
        } else {
          setErrorMessage(prev =>
            prev?.length > 0 ? prev.concat(`. ${sameBillingError?.message}`) : sameBillingError?.message
          );
        }
        return;
      }

      if (billingAddressError) {
        let parsedMessage = billingAddressError?.message;
        if (isJsonString(parsedMessage)) {
          parsedMessage = JSON.parse(billingAddressError?.message);
        }
        if (
          (typeof parsedMessage === 'object' &&
            parsedMessage?.code === 'invalid_parameter' &&
            parsedMessage?.parameter === 'billingAddress.postalCode') ||
          (typeof parsedMessage === 'object' && parsedMessage?.code === 'postal_code_invalid')
        ) {
          setErrorMessage(prev => (prev?.length > 0 ? prev.concat(`. ${zipcodeBillingError}`) : zipcodeBillingError));
        } else if (typeof parsedMessage === 'object' && parsedMessage?.code === 'missing_parameter') {
          setErrorMessage(serverError);
        } else {
          setErrorMessage(prev =>
            prev?.length > 0 ? prev.concat(`. ${billingAddressError?.message}`) : billingAddressError?.message
          );
        }
      }
    } else {
      setErrorMessage(guestEmailError?.message);
    }
  }, [shippingAddressError, sameBillingError, billingAddressError, guestEmailError]);

  // Formik validation schema logic needs to be at the end of all useEffects, so that
  // variable changes are registered properly here
  const [validationSchema, setValidationSchema] = useState(getValidationSchema());

  // Effect to update validation schema when shipping address form changes
  useEffect(() => {
    setValidationSchema(getValidationSchema());
  }, [isLoggedIn, billingAddressForm, isBusinessPurchased, states, shippingStates, editShippingAddress, addingAddress]);
  // ----------------Formik and Yup code ends here--------------

  return (
    <>
      <Formik initialValues={formdata} validationSchema={validationSchema} onSubmit={handleSubmit} enableReinitialize>
        {({ values, resetForm, setFieldValue, setFieldTouched, errors, isSubmitting }) => {
          // Effect to detect form submission and focus the first input with the error,
          // in case there are errors
          useEffect(() => {
            if (isSubmitting) {
              document.querySelector('.form-input-error')?.previousElementSibling?.lastChild?.focus();
            }
          }, [isSubmitting, errors]);

          // Effect to show/hide billing address form
          useEffect(() => {
            values.differentAddress ? setBillingAddressForm(false) : setBillingAddressForm(true);
            // To avoid multiple validations when the billing form is there
            // To avoid the situation when user touches one input
            // and validation is thrown for all inputs
            [
              'billingAddressSearch',
              'country',
              'firstName',
              'lastName',
              'company',
              'addressLine1',
              'addressLine2',
              'city',
              'state',
              'postalCode',
              'phoneNumber',
            ].map(input => {
              setFieldTouched(input, false);
            });
          }, [values.differentAddress]);

          // Effects to reset state when country is selected (shipping and billing)
          useEffect(() => {
            if (values.country) {
              setSelectedCountry(values.country);
              setFieldValue(
                'state',
                states[0]?.options.length > 1
                  ? states[0]?.options?.find(item => item.value === values.state)?.value || ''
                  : ''
              );
            } else {
              setSelectedCountry('');
              setFieldValue('state', '');
              setFieldValue('country', '');
            }
          }, [values.country, values.state, states]);

          useEffect(() => {
            // If the user is logged in and not editing the address, only then let it change the field value
            // As while editing the values will change for the form
            // And without this condition, canceling the edit option does not reset the form values to selected saved address
            if (
              (isLoggedIn && !editShippingAddress && addressOptions[0]?.options.length > 0) ||
              (isLoggedIn && addingAddressOnce)
            ) {
              if (isLoggedIn && addingAddressOnce) {
                setAddingAddressOnce(false);
              }
              return;
            }

            if (values.shippingCountry) {
              setSelectedShippingCountry(values.shippingCountry);
              setFieldValue(
                'shippingState',
                shippingStates[0]?.options.length > 1 && shippingStates[0].id === values.shippingCountry
                  ? shippingStates[0]?.options?.find(item => item.value === values.shippingState)?.value || ''
                  : shippingStates[0]?.options.length === 1
                  ? ''
                  : values.shippingState
              );
            } else {
              setSelectedShippingCountry('');
              setFieldValue('shippingState', '');
              setFieldValue('shippingCountry', '');
            }
          }, [values.shippingCountry, values.shippingState, shippingStates, editShippingAddress]);

          // Reset the sections when user changes the order type
          useEffect(() => {
            if (submitSuccess) {
              handleEdit(values, resetForm);
            }
          }, [isBusinessPurchased]);

          // Effect to make shipping address dropdown effective for logged in users
          // to be able to select and see the address details
          useEffect(() => {
            if (values.shippingAddress) {
              let address = findAddressById(Number(values.shippingAddress));
              setSelectedShippingAddress(address);
              setFormdata(prev => ({
                ...prev,
                shippingAddress: address?.id,
                shippingFirstName: address?.firstname,
                shippingLastName: address?.lastname,
                shippingAddressLine1: address?.street[0],
                shippingAddressLine2: address?.street[1] || '',
                shippingCity: address?.city,
                shippingState: address?.region?.region_code,
                shippingCountry: address?.country_code,
                shippingPhoneNumber: address?.telephone,
                shippingPostalCode: address?.postcode,
                shippingCompanyName: address?.company || '',
              }));
            }
            // To close the edit form when address is changed from dropdown
            if (values.shippingAddress !== formdata.shippingAddress) {
              setEditShippingAddress(false);
            }
          }, [values.shippingAddress]);

          // Effect to populate the shipping address form with the searched address through Loqate
          useEffect(() => {
            if (Object.keys(searchedShippingAddress).length > 0) {
              setFormdata(prev => ({
                ...prev,
                ...values,
                shippingCountry: searchedShippingAddress.CountryIso2,
                shippingState:
                  shippingStates[0]?.options?.find(item => item.value === searchedShippingAddress.Province)?.value ||
                  '',
                shippingPostalCode: searchedShippingAddress.PostalCode,
                shippingCity: searchedShippingAddress.City,
                shippingAddressLine1: searchedShippingAddress.Line1,
              }));
            }
          }, [searchedShippingAddress]);

          // Effect to populate the billing address form with the searched address through Loqate
          useEffect(() => {
            if (Object.keys(searchedBillingAddress).length > 0) {
              setFormdata(prev => ({
                ...prev,
                ...values,
                country: searchedBillingAddress.CountryIso2,
                state: states[0]?.options?.find(item => item.value === searchedBillingAddress.Province)?.value || '',
                postalCode: searchedBillingAddress.PostalCode,
                city: searchedBillingAddress.City,
                addressLine1: searchedBillingAddress.Line1,
              }));
            }
          }, [searchedBillingAddress]);

          return (
            <Form>
              <div className="cmp-acommerce_checkout-v2__fragment">
                <div className="cmp-acommerce_checkout-v2__fragment-head">
                  <h4 className="cmp-acommerce_checkout-v2__fragment-heading">
                    {shippingAddressTitle} {submitSuccess && <Icon name="CheckMark" />}
                  </h4>
                  {submitSuccess && (
                    <div
                      className="cmp-acommerce_checkout-v2__fragment-edit"
                      onClick={() => handleEdit(values, resetForm)}>
                      <Icon name="Pencil" />
                      {addressEditLabel}
                    </div>
                  )}
                </div>
                <div className="cmp-acommerce_checkout-v2__fragment-body">
                  {!submitSuccess ? (
                    <>
                      {isLoggedIn && addressOptions[0]?.options.length > 0 ? (
                        <UserShippingForm
                          specialPackageLabel={specialPackageLabel}
                          emailLabel={emailLabel}
                          verifyEmailLabel={verifyEmailLabel}
                          additionalInformationLabel={additionalInformationLabel}
                          shippingAddressTitle={shippingAddressTitle}
                          countryLabel={countryLabel}
                          firstNameLabel={firstNameLabel}
                          lastNameLabel={lastNameLabel}
                          addressLine1Label={addressLine1Label}
                          addressLine2Label={addressLine2Label}
                          cityLabel={cityLabel}
                          stateLabel={stateLabel}
                          zipCodeLabel={zipCodeLabel}
                          companyNameLabel={companyNameLabel}
                          phoneNumberLabel={phoneNumberLabel}
                          customerPoLabel={customerPoLabel}
                          welcomeBack={welcomeBack}
                          savedAddresses={savedAddresses}
                          addressEditLabel={addressEditLabel}
                          addShippingAddress={addShippingAddress}
                          loqateKey={loqateKey}
                          addressSearch={addressSearch}
                          addressPlaceholder={addressPlaceholder}
                          countries={countries}
                          shippingStates={shippingStates}
                          isBusinessPurchased={isBusinessPurchased}
                          addressOptions={addressOptions}
                          selectedShippingAddress={selectedShippingAddress}
                          handleEditAddress={handleEditAddress}
                          handleAddAddress={handleAddAddress}
                          resetForm={resetForm}
                          editShippingAddress={editShippingAddress}
                          userEmail={userEmail}
                          setSearchedShippingAddress={setSearchedShippingAddress}
                          specialPackageOptions={specialPackageOptions}
                        />
                      ) : (
                        <GuestShippingForm
                          addressFormName={addressFormName}
                          emailLabel={emailLabel}
                          verifyEmailLabel={verifyEmailLabel}
                          emailReminderLabel={emailReminderLabel}
                          additionalInformationLabel={additionalInformationLabel}
                          shippingAddressTitle={shippingAddressTitle}
                          countryLabel={countryLabel}
                          firstNameLabel={firstNameLabel}
                          lastNameLabel={lastNameLabel}
                          addressLine1Label={addressLine1Label}
                          addressLine2Label={addressLine2Label}
                          cityLabel={cityLabel}
                          stateLabel={stateLabel}
                          zipCodeLabel={zipCodeLabel}
                          companyNameLabel={companyNameLabel}
                          phoneNumberLabel={phoneNumberLabel}
                          customerPoLabel={customerPoLabel}
                          loqateKey={loqateKey}
                          addressSearch={addressSearch}
                          addressPlaceholder={addressPlaceholder}
                          countries={countries}
                          shippingStates={shippingStates}
                          isBusinessPurchased={isBusinessPurchased}
                          isLoggedIn={isLoggedIn}
                          setSearchedShippingAddress={setSearchedShippingAddress}
                        />
                      )}
                      <div className="cmp-acommerce_checkout-v2__address-form__name billing-address">
                        <Icon name="Bill" /> <span>{billingAddressTitle}</span>
                      </div>
                      <Checkbox
                        name="differentAddress"
                        label={sameAddress}
                        className="cmp-acommerce_checkout-v2__address-form__checkbox same-address"
                      />

                      {billingAddressForm && (
                        <div className="cmp-acommerce_checkout-v2__address-form">
                          <div className="input-field-wrapper">
                            <AddressSearch
                              locale={locale}
                              countries={[
                                locale?.includes('_') ? locale?.split('_')[1]?.toUpperCase() : locale?.toUpperCase(),
                              ]}
                              apiKey={loqateKey}
                              onSelect={address => {
                                setSearchedBillingAddress(address);
                              }}
                              components={{
                                List: forwardRef(({ className, ...rest }, ref) => (
                                  <ul
                                    className="cmp-acommerce_checkout-v2__address-form__search-list"
                                    ref={ref}
                                    {...rest}
                                  />
                                )),
                                ListItem: forwardRef(({ className, suggestion, ...rest }, ref) => (
                                  <li
                                    className="cmp-acommerce_checkout-v2__address-form__search-list__item"
                                    onKeyDown={e => {
                                      if (e.key === 'ArrowDown') {
                                        e.preventDefault();
                                        const next = e.target.nextSibling;
                                        if (next) {
                                          next.focus();
                                        }
                                      }
                                      if (e.key === 'ArrowUp') {
                                        e.preventDefault();
                                        const previous = e.target.previousSibling;
                                        if (previous) {
                                          previous.focus();
                                        }
                                      }
                                    }}
                                    {...rest}
                                    ref={ref}>
                                    {`${suggestion.Text} ${suggestion.Description}`}
                                  </li>
                                )),
                                Input: forwardRef(({ className, ...rest }, ref) => (
                                  <div className="address-search">
                                    <span className="cmp-acommerce_checkout-v2__address-form__search-label">
                                      {addressSearch}
                                    </span>
                                    <input
                                      className="cmp-acommerce_checkout-v2__address-form__search-input"
                                      id="billingAddressSearch"
                                      name="billingAddressSearch"
                                      autoComplete="new-address"
                                      placeholder={addressPlaceholder}
                                      type="text"
                                      {...rest}
                                      ref={ref}
                                    />
                                  </div>
                                )),
                              }}
                            />
                          </div>
                          <Dropdown
                            name="country"
                            options={countries}
                            isMandatory
                            label={countryLabel}
                            className="cmp-acommerce_checkout-v2__address-form__dropdown"
                          />
                          <InputField name="firstName" label={firstNameLabel} type="text" isMandatory hidden={true} />
                          <InputField name="lastName" label={lastNameLabel} type="text" isMandatory hidden={true} />
                          <InputField
                            name="addressLine1"
                            label={addressLine1Label}
                            type="text"
                            isMandatory
                            hidden={true}
                          />
                          <InputField name="addressLine2" label={addressLine2Label} type="text" hidden={true} />
                          <InputField name="city" label={cityLabel} type="text" isMandatory hidden={true} />
                          <Dropdown
                            name="state"
                            options={states}
                            isMandatory={states[0].options.length > 1}
                            label={stateLabel}
                            className="cmp-acommerce_checkout-v2__address-form__dropdown"
                            isDisabled={states[0].options.length > 1 ? false : true}
                          />
                          <InputField name="postalCode" label={zipCodeLabel} type="text" isMandatory hidden={true} />
                          <InputField name="companyName" label={companyNameLabel} type="text" hidden={true} />
                          <InputField
                            name="phoneNumber"
                            label={phoneNumberLabel}
                            type="text"
                            isMandatory
                            hidden={true}
                          />
                        </div>
                      )}
                      <div className="cmp-acommerce_checkout-v2__address-form__submit">
                        <div className="cmp-acommerce_checkout-v2__address-form__buttons">
                          <Button className="cmp-acommerce_checkout-v2__address-form__submit-button">
                            {saveContinue}
                          </Button>
                          {/* {(editShippingAddress || editAddresses) && ( */}
                          {editShippingAddress && (
                            <Button
                              className="cmp-acommerce_checkout-v2__address-form__cancel-button"
                              type="secondary"
                              onClick={e => {
                                e.preventDefault();
                                setAddingAddress(false);
                                setAddingAddressOnce(false);
                                if (editShippingAddress) {
                                  setEditShippingAddress(false);
                                  setFieldValue('shippingAddress', selectedShippingAddress?.id);
                                  setFieldValue('shippingCountry', selectedShippingAddress?.country_code);
                                  setFieldValue('shippingFirstName', selectedShippingAddress?.firstname);
                                  setFieldValue('shippingLastName', selectedShippingAddress?.lastname);
                                  setFieldValue('shippingAddressLine1', selectedShippingAddress?.street[0]);
                                  setFieldValue('shippingAddressLine2', selectedShippingAddress?.street[1] || '');
                                  setFieldValue('shippingCity', selectedShippingAddress?.city);
                                  setFieldValue('shippingCompanyName', selectedShippingAddress?.company || '');
                                  setFieldValue('shippingState', selectedShippingAddress?.region?.region_code);
                                  setFieldValue('shippingPhoneNumber', selectedShippingAddress?.telephone);
                                  setFieldValue('shippingPostalCode', selectedShippingAddress?.postcode);
                                }
                              }}>
                              {cancel}
                            </Button>
                          )}
                        </div>
                        {(shippingAddressError ||
                          sameBillingError ||
                          billingAddressError ||
                          guestEmailError ||
                          updateQuoteError) && <p className="submiterror">{errorMessage}</p>}
                      </div>
                    </>
                  ) : (
                    <div className="cmp-acommerce_checkout-v2__addresses">
                      <Address
                        title={shippingAddressTitle}
                        address={shippingAddress}
                        email={userEmail}
                        poNumber={isBusinessPurchased ? poNumber : ''}
                      />
                      <Address title={billingAddressTitle} address={billingAddress} email={userEmail} />
                    </div>
                  )}
                </div>
              </div>
            </Form>
          );
        }}
      </Formik>
      {(customerAddressLoading || submitLoader || stateLoading) && createPortal(<Loader />, document.body)}
    </>
  );
};

export default AddressFragment;
