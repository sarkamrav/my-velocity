import React, { forwardRef } from 'react';
import Icon from '../../../../../assests/Icon';
import InputField from '../../../../inputfield/InputField';
import Dropdown from '../../../../micro-components/Dropdown/Dropdown';
import AddressSearch from 'react-loqate';
import Radio from '../../../../micro-components/Radio/Radio';
import { getCatalogServiceHeaders } from '../../../../../configs/ReactApolloClientSetup/ApolloClientConfig';

const UserShippingForm = ({
  shippingAddressTitle,
  countryLabel,
  firstNameLabel,
  lastNameLabel,
  addressLine1Label,
  addressLine2Label,
  cityLabel,
  stateLabel,
  zipCodeLabel,
  companyNameLabel,
  phoneNumberLabel,
  customerPoLabel,
  welcomeBack,
  savedAddresses,
  addressEditLabel,
  addShippingAddress,
  specialPackageLabel,
  loqateKey,
  addressSearch,
  addressPlaceholder,
  countries,
  shippingStates,
  isBusinessPurchased,
  addressOptions,
  selectedShippingAddress,
  handleEditAddress,
  handleAddAddress,
  resetForm,
  editShippingAddress,
  userEmail,
  specialPackageOptions,
  setSearchedShippingAddress,
}) => {
  const locale = getCatalogServiceHeaders();
  return (
    <div className="cmp-acommerce_checkout-v2__address-form">
      {!editShippingAddress && (
        <>
          {addressOptions[0]?.options.length > 0 && (
            <>
              <p>{welcomeBack}</p>
              <Dropdown
                name="shippingAddress"
                options={addressOptions}
                label={savedAddresses}
                className="cmp-acommerce_checkout-v2__address-form__dropdown"
              />
            </>
          )}
          <div className="cmp-acommerce_checkout-v2__address-form__name">
            <span>{shippingAddressTitle}</span>
          </div>
          {selectedShippingAddress && Object.keys(selectedShippingAddress).length > 0 && (
            <div className="address-container">
              <ul className="address-details">
                <li className="address-details-name">
                  <strong>
                    {selectedShippingAddress?.firstname} {selectedShippingAddress?.lastname}
                  </strong>
                  <span
                    className="cmp-acommerce_checkout-v2__fragment-edit"
                    onClick={() => handleEditAddress(selectedShippingAddress?.id, resetForm)}>
                    <Icon name="Pencil" />
                    {addressEditLabel}
                  </span>
                </li>
                {selectedShippingAddress?.street?.map((addline, index) => (
                  <li key={addline + index}>{addline}</li>
                ))}
                <li>
                  {selectedShippingAddress?.region?.region && `${selectedShippingAddress?.region?.region},`}{' '}
                  {selectedShippingAddress?.country_code} {selectedShippingAddress?.postcode}
                </li>
                <li>{selectedShippingAddress?.telephone}</li>
                {userEmail && <li>{userEmail}</li>}
              </ul>
            </div>
          )}
          {isBusinessPurchased && (
            <div className="cmp-acommerce_checkout-v2__address-form__business-inputs">
              {(selectedShippingAddress?.company === '' ||
                selectedShippingAddress?.company === undefined ||
                selectedShippingAddress?.company === null) && (
                <InputField
                  name="shippingCompanyName"
                  label={companyNameLabel}
                  type="text"
                  hidden={true}
                  isMandatory={isBusinessPurchased}
                />
              )}
              <InputField name="po_number" label={customerPoLabel} isMandatory type="text" hidden={true} />
              <div className="cmp-acommerce_checkout-v2__address-form__name">
                <Icon name="Package" /> <span>{specialPackageLabel}</span>
              </div>
              <Radio
                options={specialPackageOptions}
                name="pack_count_tray"
                className="cmp-acommerce_checkout-v2__address-form__radio"
              />
            </div>
          )}
          <div className="cmp-acommerce_checkout-v2__address-form__add" onClick={() => handleAddAddress(resetForm)}>
            <Icon name="Plus" /> {addShippingAddress}
          </div>
        </>
      )}
      {editShippingAddress && (
        <>
          <div className="input-field-wrapper">
            <AddressSearch
              locale={locale}
              countries={[locale?.includes('_') ? locale?.split('_')[1].toUpperCase() : locale.toUpperCase()]}
              apiKey={loqateKey}
              onSelect={address => {
                setSearchedShippingAddress(address);
              }}
              components={{
                List: forwardRef(({ className, ...rest }, ref) => (
                  <ul className="cmp-acommerce_checkout-v2__address-form__search-list" ref={ref} {...rest} />
                )),
                ListItem: forwardRef(({ className, suggestion, ...rest }, ref) => (
                  <li
                    className="cmp-acommerce_checkout-v2__address-form__search-list__item"
                    onKeyDown={e => {
                      if (e.key === 'ArrowDown') {
                        e.preventDefault();
                        const next = e.target.nextSibling;
                        if (next) {
                          next.focus();
                        }
                      }
                      if (e.key === 'ArrowUp') {
                        e.preventDefault();
                        const previous = e.target.previousSibling;
                        if (previous) {
                          previous.focus();
                        }
                      }
                    }}
                    {...rest}
                    ref={ref}>
                    {`${suggestion.Text} ${suggestion.Description}`}
                  </li>
                )),
                Input: forwardRef(({ className, ...rest }, ref) => (
                  <div className="address-search">
                    <span className="cmp-acommerce_checkout-v2__address-form__search-label">{addressSearch}</span>
                    <input
                      className="cmp-acommerce_checkout-v2__address-form__search-input"
                      id="shippingAddressSearch"
                      name="shippingAddressSearch"
                      autocomplete="new-address"
                      placeholder={addressPlaceholder}
                      type="text"
                      {...rest}
                      ref={ref}
                    />
                  </div>
                )),
              }}
            />
          </div>
          <Dropdown
            name="shippingCountry"
            options={countries}
            isMandatory
            label={countryLabel}
            className="cmp-acommerce_checkout-v2__address-form__dropdown"
          />
          <InputField name="shippingFirstName" label={firstNameLabel} type="text" isMandatory hidden={true} />
          <InputField name="shippingLastName" label={lastNameLabel} type="text" isMandatory hidden={true} />
          <InputField name="shippingAddressLine1" label={addressLine1Label} type="text" isMandatory hidden={true} />
          <InputField name="shippingAddressLine2" label={addressLine2Label} type="text" hidden={true} />
          <InputField name="shippingCity" label={cityLabel} type="text" isMandatory hidden={true} />
          <Dropdown
            name="shippingState"
            options={shippingStates}
            isMandatory={shippingStates[0].options.length > 1}
            label={stateLabel}
            className="cmp-acommerce_checkout-v2__address-form__dropdown"
            isDisabled={shippingStates[0].options.length > 1 ? false : true}
          />
          <InputField name="shippingPostalCode" label={zipCodeLabel} type="text" isMandatory hidden={true} />
          <InputField
            name="shippingCompanyName"
            label={companyNameLabel}
            type="text"
            hidden={true}
            isMandatory={isBusinessPurchased}
          />
          <InputField name="shippingPhoneNumber" label={phoneNumberLabel} type="text" isMandatory hidden={true} />
          {isBusinessPurchased && (
            <>
              <InputField name="po_number" label={customerPoLabel} isMandatory type="text" hidden={true} />
              <div className="cmp-acommerce_checkout-v2__address-form__name">
                <Icon name="Package" /> <span>{specialPackageLabel}</span>
              </div>
              <Radio
                options={specialPackageOptions}
                name="pack_count_tray"
                className="cmp-acommerce_checkout-v2__address-form__radio"
              />
            </>
          )}
        </>
      )}
    </div>
  );
};

export default UserShippingForm;
