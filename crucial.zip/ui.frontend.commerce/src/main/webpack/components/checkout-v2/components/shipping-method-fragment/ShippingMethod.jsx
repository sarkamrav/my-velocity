import React, { useEffect, useState } from 'react';
import { Formik, Form } from 'formik';
import Radio from '../../../micro-components/Radio/Radio';
import * as Yup from 'yup';
import { useStoreContext } from '../../../../contexts/common/StoreContext';
import Button from '../../../micro-components/Button/Button';
import { useMutation } from '@apollo/client';
import { getCookie } from '../../../../utils/cookies_operation';
import Icon from '../../../../assests/Icon';
import Loader from '../../../micro-components/Loader/Loader';
import { SET_SHIPPING_METHOD } from '../../../../site/js/gql/mutations/checkout-v2.gql';
import { fetchShippingMethodData } from '../../../../contexts/common/actions/checkoutaction';
import GET_CART from '../../../../site/js/gql/get-cart.gql';
import { createPortal } from 'react-dom';
import { getCatalogServiceHeaders } from '../../../../configs/ReactApolloClientSetup/ApolloClientConfig';

export default function ShippingMethod({
  setEnablePayment,
  enableShipping,
  shippingMethodHeading,
  saveContinue,
  addressEditLabel,
  setEnableTax,
  removeVAT,
  isLoggedIn,
  noShippingMethodAvailable,
}) {
  const { state, dispatch } = useStoreContext();
  const [availableShippingMethod, setAvailableShippingMethod] = useState([]);
  const [activeMethod, setActiveMethod] = useState({});
  const [isEdit, setIsEdit] = useState(false);
  const [paymentData, setPaymentData] = useState({});

  useEffect(() => {
    if (state?.checkout?.addressData?.shipping_address) {
      setAvailableShippingMethod(state.checkout.addressData.shipping_address[0].available_shipping_methods);
    }
  }, [state]);

  // Effect to reset the section when the previous section
  // is set to edit mode by the user
  useEffect(() => {
    if (!enableShipping) {
      handleEdit();
    }
  }, [enableShipping]);

  const method = availableShippingMethod?.map(item => ({
    label: item.carrier_title,
    value: item.method_code,
    method_code: item.method_code,
    carrier_code: item.carrier_code,
    amount: item.amount.value,
  }));

  const initialMethod = {
    shipping_method: activeMethod.value || method[0]?.value,
  };

  const methodSchema = Yup.object({
    shipping_method: Yup.string().required('Shipping method is required'),
  });

  const [setShippingMethod, { loading: shippingLoading }] = useMutation(SET_SHIPPING_METHOD);
  useEffect(() => {
    if (paymentData) {
      dispatch(fetchShippingMethodData(paymentData));
    }
  }, [paymentData]);

  const handleSubmit = values => {
    const selectedMethod = method.find(item => item.method_code === values.shipping_method);
    setActiveMethod(selectedMethod);
    setShippingMethod({
      variables: {
        cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
        carrierCode: selectedMethod.carrier_code,
        methodCode: selectedMethod.method_code,
      },
      refetchQueries: [
        {
          query: GET_CART,
          variables: {
            cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
          },
        },
      ],
    }).then(response => {
      setPaymentData(response.data.core_setShippingMethodsOnCart.cart.digital_river);
      setIsEdit(true);
      setEnableTax(true);
      setEnablePayment(true);
    });
  };

  const handleEdit = () => {
    setIsEdit(false);
    setEnableTax(false);
    setEnablePayment(false);

    if (isLoggedIn && getCatalogServiceHeaders() !== 'en_us') {
      removeVAT({
        variables: {
          cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
        },
      }).catch(error => console.log(`Server responded with an error - ${error.message}`));
    }
  };

  return (
    <>
      <div
        className={`cmp-acommerce_checkout-v2__fragment cmp-acommerce_checkout-v2__fragment${
          enableShipping ? '' : '--disable'
        } cmp-acommerce_checkout-v2-shipping-method`}>
        <div className="cmp-acommerce_checkout-v2__fragment-head">
          <h4 className="cmp-acommerce_checkout-v2__fragment-heading">
            {shippingMethodHeading} {isEdit && <Icon name="CheckMark" />}
          </h4>
          {isEdit && (
            <div className="cmp-acommerce_checkout-v2__fragment-edit" onClick={handleEdit}>
              <Icon name="Pencil" />
              {addressEditLabel}
            </div>
          )}
        </div>
        {!isEdit && (
          <div className="cmp-acommerce_checkout-v2__fragment-body">
            <div className="cmp-acommerce_checkout-v2__radio-group">
              <Formik
                initialValues={initialMethod}
                validationSchema={methodSchema}
                onSubmit={handleSubmit}
                enableReinitialize>
                {({ values }) => {
                  const isValuesEmpty =
                    (Array.isArray(values) && values.length === 0) ||
                    (typeof values === 'object' && Object.keys(values).length === 0) ||
                    values.shipping_method === undefined;

                  return (
                    <Form>
                      {!isValuesEmpty && (
                        <Radio
                          options={method}
                          carrier_code={'free'}
                          method_code={'free'}
                          isMandatory
                          name="shipping_method"
                        />
                      )}
                      {isValuesEmpty && <div className="shipping-error-message">{noShippingMethodAvailable}</div>}
                      <div className="cmp-acommerce_checkout-v2__address-form__submit">
                        <Button
                          disabled={isValuesEmpty}
                          className="cmp-acommerce_checkout-v2__address-form__submit-button">
                          {saveContinue}
                        </Button>
                      </div>
                    </Form>
                  );
                }}
              </Formik>
            </div>
          </div>
        )}
        {isEdit && (
          <div className="cmp-acommerce_checkout-v2__fragment-body">
            <span>{activeMethod.label}</span>
          </div>
        )}
      </div>
      {shippingLoading && createPortal(<Loader />, document.body)}
    </>
  );
}
