import React, { forwardRef, useEffect, useState } from 'react';
import Icon from '../../../../../assests/Icon';
import InputField from '../../../../inputfield/InputField';
import Checkbox from '../../../../micro-components/Checkbox/Checkbox';
import Dropdown from '../../../../micro-components/Dropdown/Dropdown';
import AddressSearch from 'react-loqate';
import { getCatalogServiceHeaders } from '../../../../../configs/ReactApolloClientSetup/ApolloClientConfig';

const GuestShippingForm = ({
  addressFormName,
  emailLabel,
  verifyEmailLabel,
  emailReminderLabel,
  additionalInformationLabel,
  shippingAddressTitle,
  countryLabel,
  firstNameLabel,
  lastNameLabel,
  addressLine1Label,
  addressLine2Label,
  cityLabel,
  stateLabel,
  zipCodeLabel,
  companyNameLabel,
  phoneNumberLabel,
  customerPoLabel,
  loqateKey,
  addressSearch,
  addressPlaceholder,
  countries,
  shippingStates,
  isBusinessPurchased,
  isLoggedIn,
  setSearchedShippingAddress,
}) => {
  const locale = getCatalogServiceHeaders();
  return (
    <>
      {!isLoggedIn && (
        <div className="cmp-acommerce_checkout-v2__address-form__name">
          <Icon name="Email" /> <span>{addressFormName}</span>
        </div>
      )}
      <div className="cmp-acommerce_checkout-v2__address-form">
        {!isLoggedIn && (
          <>
            <InputField name="email" label={emailLabel} type="email" isMandatory hidden={true} />
            <InputField name="verifyemail" label={verifyEmailLabel} type="email" isMandatory hidden={true} />
            <div className="cmp-acommerce_checkout-v2__address-form__checkbox-group">
              <Checkbox
                name="additionalInfo"
                label={additionalInformationLabel}
                className="cmp-acommerce_checkout-v2__address-form__checkbox"
              />
              <Checkbox
                name="emailReminder"
                label={emailReminderLabel}
                className="cmp-acommerce_checkout-v2__address-form__checkbox"
              />
            </div>
          </>
        )}
        <div className="cmp-acommerce_checkout-v2__address-form__name">
          <Icon name="Truck" /> <span>{shippingAddressTitle}</span>
        </div>
        <div className="input-field-wrapper">
          <AddressSearch
            locale={locale}
            countries={[locale?.includes('_') ? locale?.split('_')[1].toUpperCase() : locale.toUpperCase()]}
            apiKey={loqateKey}
            onSelect={address => {
              setSearchedShippingAddress(address);
            }}
            components={{
              List: forwardRef(({ className, ...rest }, ref) => (
                <ul className="cmp-acommerce_checkout-v2__address-form__search-list" ref={ref} {...rest} />
              )),
              ListItem: forwardRef(({ className, suggestion, ...rest }, ref) => (
                <li
                  className="cmp-acommerce_checkout-v2__address-form__search-list__item"
                  onKeyDown={e => {
                    if (e.key === 'ArrowDown') {
                      e.preventDefault();
                      const next = e.target.nextSibling;
                      if (next) {
                        next.focus();
                      }
                    }
                    if (e.key === 'ArrowUp') {
                      e.preventDefault();
                      const previous = e.target.previousSibling;
                      if (previous) {
                        previous.focus();
                      }
                    }
                  }}
                  {...rest}
                  ref={ref}>
                  {`${suggestion.Text} ${suggestion.Description}`}
                </li>
              )),
              Input: forwardRef(({ className, ...rest }, ref) => (
                <div className="address-search">
                  <span className="cmp-acommerce_checkout-v2__address-form__search-label">{addressSearch}</span>
                  <input
                    className="cmp-acommerce_checkout-v2__address-form__search-input"
                    id="shippingAddressSearch"
                    name="shippingAddressSearch"
                    autoComplete="new-address"
                    placeholder={addressPlaceholder}
                    type="text"
                    {...rest}
                    ref={ref}
                  />
                </div>
              )),
            }}
          />
        </div>
        <Dropdown
          name="shippingCountry"
          options={countries}
          isMandatory
          label={countryLabel}
          className="cmp-acommerce_checkout-v2__address-form__dropdown"
        />
        <InputField name="shippingFirstName" label={firstNameLabel} type="text" isMandatory hidden={true} />
        <InputField name="shippingLastName" label={lastNameLabel} type="text" isMandatory hidden={true} />
        <InputField name="shippingAddressLine1" label={addressLine1Label} type="text" isMandatory hidden={true} />
        <InputField name="shippingAddressLine2" label={addressLine2Label} type="text" hidden={true} />
        <InputField name="shippingCity" label={cityLabel} type="text" isMandatory hidden={true} />
        <Dropdown
          name="shippingState"
          options={shippingStates}
          isMandatory={shippingStates[0].options.length > 1}
          label={stateLabel}
          className="cmp-acommerce_checkout-v2__address-form__dropdown"
          isDisabled={shippingStates[0].options.length > 1 ? false : true}
        />
        <InputField name="shippingPostalCode" label={zipCodeLabel} type="text" isMandatory hidden={true} />
        <InputField
          name="shippingCompanyName"
          label={companyNameLabel}
          type="text"
          hidden={true}
          isMandatory={isBusinessPurchased}
        />
        <InputField name="shippingPhoneNumber" label={phoneNumberLabel} type="text" isMandatory hidden={true} />
        {isBusinessPurchased && (
          <InputField name="po_number" label={customerPoLabel} isMandatory type="text" hidden={true} />
        )}
      </div>
    </>
  );
};

export default GuestShippingForm;
