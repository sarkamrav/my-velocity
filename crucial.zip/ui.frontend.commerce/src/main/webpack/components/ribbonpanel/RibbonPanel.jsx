import React from 'react';
import PropTypes from 'prop-types';

export default function RibbonPanel({ style, children }) {
  return (
    <div className="ribbon-card" style={style}>
      <span className="ribbon-title">{children}</span>
    </div>
  );
}

RibbonPanel.propTypes = {
  children: PropTypes.node.isRequired,
};
