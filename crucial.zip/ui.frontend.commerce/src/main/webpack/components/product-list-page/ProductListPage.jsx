import React, { useState, useEffect, useMemo } from 'react';
import productData from '../../mocks/productmock';
import ProductCard from './components/productcard/ProductCard';
import Button from '../micro-components/Button/Button';
import FilterContainer from './components/filtercontainer/FilterContainer';
import { PLP_PRODUCT_LIST } from '../../site/js/gql/plp-productfetch.gql';
import { SET_STOCK_NOTIFICATION } from '../../site/js/gql/mutations/stock-notification.gql.js';
import { gql, useMutation, useLazyQuery, ApolloClient } from '@apollo/client';
import productFilterMock from '../../mocks/productfiltermock';
import { useStoreContext } from '../../contexts/common/StoreContext';
// import ProductContext from "../../productcontext";
import DropdownFilter from './components/dropdownfilter/DropdownFilter';
import ModalPopup from '../modal-popup/ModalPopup.jsx';
import useModal from '../../hooks/useModal.jsx';
import Icon from '../../assests/Icon.js';
import {
  addFilterData,
  fetchFilterData,
  removeFilterData,
  fetchProductData,
  updateCompareDataList,
  addItemsToCompareList,
} from '../../contexts/common/actions/plpactions';
import ProgressBar from '../progressbar/ProgressBar';
import LayoutContainer from './components/layoutcontainer/LayoutContainer';
import CustomSlider from './components/customslider/CustomSlider';
import PropTypes from 'prop-types';
import syncText from '../../utils/syncText';
import { useLocation, useNavigate } from 'react-router-dom';
// import { CREATE_COMPARE_LIST } from '../../site/js/gql/mutations/createCompareList.gql.js';
import Loader from '../micro-components/Loader/Loader.jsx';
import { apolloClientConfigUsingGet } from '../../configs/ReactApolloClientSetup/ApolloClientConfig';

export default function ProductListPage({
  productCategory,
  displayStatus,
  plpLoadmore,
  plpFilterAndSort,
  productNoresultfound,
  plpPaginationmsg,
  plpClearall,
  stylesMap,
  plpSortFilterTitle,
  plpNoFiltersApplied,
  loginDataAttributes,
  ...restProps
}) {
  // const { productCategory, displayStatus, plpLoadmore, plpFilterAndSort, ...restProps } = props;
  const productCategoryList = JSON.parse(productCategory);
  const brandstyles = JSON.parse(stylesMap);

  // Object.entries(brandstyles).map(
  //   ([title, link]) =>
  //     attribute == 'categories' && (
  //       // <div className ='category-title' key={title}>
  //       <a href={link} className={location.pathname.trim() == link ? 'link_selected' : ''}>
  //         {title}
  //       </a>

  //       // <br />
  //       // </div>
  //     )
  // )
  const [showHandleCompareModal, setHandleCompareModal] = useState(false);
  const [productListData, setProductListData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [count, setCount] = useState(0);
  const [error, setError] = useState(null);
  const [phraseData, setPhraseData] = useState('');
  const [showText, setShowText] = useState('');
  const [compareListDataUID, setCompareListDataUID] = useState('');
  const { isShowing: isConfirmationShowing, toggle: toggleConfirmation } = useModal();
  const [compareItems, setCompareItems] = useState({});
  const [comparfiltereData, setCompareFilterData] = useState([null, null, null, null]);
  const [isDrawerOpen, setDrawer] = useState(true);
  const { state, dispatch } = useStoreContext();
  const [secondQueryLoading, setSecondQueryLoading] = useState(false);

  const ITEMS_PER_PAGE = 12;
  const MAXIMUM_ITEMS_PER_PAGE = 500;

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(0);
  const [fetchMore, setFetchMore] = useState(false);
  const [initialFetch, setInitialFetch] = useState(false);

  const [dropdownFilterVal, setDropdownFilterVal] = useState('name');

  const [checkBoxFilterData, setCheckBoxFilterData] = useState([]);

  const [dropdownVal, setDropdownVal] = useState([{ options: [] }]);

  // const [createCompareList, { error: compareError, loading: comapreLoading, data: compareListdata }] =
  //   useMutation(CREATE_COMPARE_LIST);

  // useEffect(() => {
  //   async function createcomapreListData() {
  //     const resdata = await createCompareList();
  //     if (resdata) {
  //       setCompareListDataUID(resdata?.data?.core_createCompareList?.uid);
  //     }
  //   }
  //   createcomapreListData();
  //   // if (compareListdata) {
  //   //   console.log('compareListdata', compareListdata);
  //   // }
  // }, [createCompareList]);

  // console.log('compareItemscompareItems', compareItems);

  const handleLoadMore = () => {
    //if customer is close to the last page let's make the query
    if (
      productListData?.productSearch?.total_count > MAXIMUM_ITEMS_PER_PAGE &&
      itemsPerPage + ITEMS_PER_PAGE > MAXIMUM_ITEMS_PER_PAGE
    ) {
      setFetchMore(true);
    }
    const remainingItems = productListData?.productSearch?.total_count - itemsPerPage;
    const nextItemsToLoad = remainingItems > ITEMS_PER_PAGE ? ITEMS_PER_PAGE : remainingItems;
    setItemsPerPage(prev => prev + nextItemsToLoad);
  };

  const clearAll = () => {
    setParams([]);
    navigate(location.pathname);
  };

  const navigate = useNavigate();
  const location = useLocation();

  const queryParams = new URLSearchParams(location.search);
  const [params, setParams] = useState(queryParams.get('selectedValues')?.split('--') || []);

  const newData = [];
  const updateNewData = (paramsplitData, newData) => {
    const attribute = paramsplitData[1];
    const value = paramsplitData[0];

    // Find the index of the object with the matching attribute
    const existingIndex = newData.findIndex(item => item.attribute === attribute);

    if (existingIndex !== -1) {
      // If it exists, update the `in` array if the value is not already present
      const existingItem = newData[existingIndex];
      if (!existingItem.in.includes(value)) {
        existingItem.in.push(value);
      }
    } else {
      // If it does not exist, add a new object
      newData.push({ attribute: attribute, in: [value] });
    }
  };

  // useEffect(() => {
  //   params?.map(paramdata => {
  //     const paramsplitData = paramdata?.split('@');

  //     if (paramsplitData[1] !== 'price') {
  //       // newData.push({ attribute: paramsplitData[1], in: [paramsplitData[0]] });
  //       updateNewData(paramsplitData, newData);
  //     } else {
  //       newData.push({
  //         attribute: paramsplitData[1],
  //         range: {
  //           from: Math.round(paramsplitData[0].split('-')[0]),
  //           to: Math.round(paramsplitData[0].split('-')[1]),
  //         },
  //       });
  //     }
  //     setCheckBoxFilterData(newData);
  //   });
  // }, [params]);

  // Function to remove a parameter from the query string
  const removeParam = param => {
    const updatedParams = params.filter(p => p !== param);
    if (updatedParams.length === 0) {
      setParams([]);
      navigate(location.pathname); // Remove query params if no parameters left
    } else {
      setParams(updatedParams);
      navigate(`?selectedValues=${updatedParams.join('--')}`);
    }
  };

  // Render buttons for each query parameter
  const renderButtons = () => {
    return params.map((param, index) => (
      <span className="btn_wrapper">
        {param.split('@')[0]}
        <button className="close-btn" key={index} onClick={() => removeParam(param)}>
          <span>&times;</span>
        </button>
      </span>
    ));
  };

  useEffect(() => {
    // Update params if location changes
    const newParams = queryParams.get('selectedValues')?.split('--') || [];
    setParams(newParams);
    if (queryParams?.size == 0) {
      setCheckBoxFilterData([]);
    }
    setInitialFetch(false);
  }, [location.search]);

  // useEffect(() => {
  //   const getDataFromURL = () => {
  //     const pathSegments = location.pathname.split('/');
  //     let dataToSend = '';
  //     if (location.pathname.includes('catalog')) {
  //       for (let i = pathSegments.indexOf('catalog') + 1; i < pathSegments.length; i++) {
  //         dataToSend += pathSegments[i].replace(/\.html$/, '') === 'memory' ? 'ram' : '/' + pathSegments[i];
  //       }
  //     } else if (location.pathname.includes('promo')) {
  //       for (let i = pathSegments.indexOf('promo'); i < pathSegments.length; i++) {
  //         dataToSend += pathSegments[i].replace(/\.html$/, '') === 'promo' ? 'promo' : '/' + pathSegments[i];
  //       }
  //     }
  //     if (dataToSend.startsWith('/')) {
  //       dataToSend = dataToSend.substring(1);
  //     }
  //     setPhraseData(dataToSend.replace(/\.html$/, ''));
  //   };
  //   getDataFromURL();
  // }, [location.pathname]);

  const gqlClientFotGet = useMemo(() => new ApolloClient(apolloClientConfigUsingGet()), []);
  const [getPlpList, { loading: queryLoading, error: queryError, data: queryData }] = useLazyQuery(PLP_PRODUCT_LIST, {
    client: gqlClientFotGet,
  });

  const [getAllPlpList] = useLazyQuery(PLP_PRODUCT_LIST, { client: gqlClientFotGet });

  useEffect(() => {
    const pathSegments = location.pathname.split('/');
    let dataToSend = '';
    if (location.pathname.includes('catalog')) {
      for (let i = pathSegments.indexOf('catalog') + 1; i < pathSegments.length; i++) {
        dataToSend += pathSegments[i].replace(/\.html$/, '') === 'memory' ? 'ram' : '/' + pathSegments[i];
      }
    } else if (location.pathname.includes('promo')) {
      for (let i = pathSegments.indexOf('promo'); i < pathSegments.length; i++) {
        dataToSend += pathSegments[i].replace(/\.html$/, '') === 'promo' ? 'promo' : '/' + pathSegments[i];
      }
    }
    if (dataToSend.startsWith('/')) {
      dataToSend = dataToSend.substring(1);
    }
    const phraseData = dataToSend.replace(/\.html$/, '');

    let filterData = [];
    params?.map(paramdata => {
      const paramsplitData = paramdata?.split('@');

      if (paramsplitData[1] !== 'price') {
        // newData.push({ attribute: paramsplitData[1], in: [paramsplitData[0]] });
        updateNewData(paramsplitData, newData);
      } else {
        newData.push({
          attribute: paramsplitData[1],
          range: {
            from: Math.round(paramsplitData[0].split('-')[0]),
            to: Math.round(paramsplitData[0].split('-')[1]),
          },
        });
      }
      setCheckBoxFilterData(newData);
      filterData = newData;
    });

    if (params.length == 0) {
      setCheckBoxFilterData([]);
      filterData = [];
    }

    let phrase = ''; // first page category
    // let phrase = '';
    let sortObjName = dropdownFilterVal; // attribute - dropdown
    let filter = [{ attribute: 'categoryPath', eq: 'ram' }, ...filterData];

    if (fetchMore) {
      setSecondQueryLoading(true);
      getAllPlpList({
        variables: {
          phrase,
          sortObjName,
          filter,
          current_page: currentPage + 1,
          page_size: MAXIMUM_ITEMS_PER_PAGE,
          imageRole: ['thumbnail'],
        },
      }).then(remainingData => {
        if (remainingData) {
          setProductListData(prev => ({
            ...prev,
            productSearch: {
              ...prev.productSearch,
              items: [...prev?.productSearch?.items, ...remainingData.data?.productSearch?.items],
            },
          }));
        }
        setCurrentPage(prev => prev + 1);
        setFetchMore(false);
        setSecondQueryLoading(false);
      });
    } else if (!initialFetch) {
      getPlpList({
        variables: {
          phrase,
          sortObjName,
          filter,
          current_page: 1,
          page_size: ITEMS_PER_PAGE,
          imageRole: ['thumbnail'],
        },
      }).then(data => {
        if (data?.data) {
          setProductListData(data.data);
          setCurrentPage(1);
          setItemsPerPage(ITEMS_PER_PAGE);
          if (data?.data?.productSearch?.total_count > ITEMS_PER_PAGE) {
            getAllPlpList({
              variables: {
                phrase,
                sortObjName,
                filter,
                current_page: 1,
                page_size: MAXIMUM_ITEMS_PER_PAGE,
                imageRole: ['thumbnail'],
              },
            }).then(remainingData => {
              if (remainingData) {
                setProductListData(remainingData.data);
              }
            });
          }
        }
      });
      setInitialFetch(true);
    }
  }, [params, dropdownFilterVal, fetchMore]);

  useEffect(() => {
    if (queryError) {
      setError(queryError);
    }
  }, [queryData, queryError]);

  const cardListData = productListData?.productSearch?.items?.slice(0, itemsPerPage);

  const handleCount = value => {
    if (value) {
      setCount(count + value);
    }
  };

  const handleComapre = () => {
    setHandleCompareModal(!showHandleCompareModal);
  };

  const totalItemCount = productListData?.productSearch?.total_count || 0;

  const totalcountMsg = displayMessage => {
    if (totalItemCount > 0 && totalItemCount < ITEMS_PER_PAGE) {
      return syncText(displayMessage, [totalItemCount, totalItemCount]);
    } else if (totalItemCount >= ITEMS_PER_PAGE) {
      return syncText(displayMessage, [itemsPerPage, totalItemCount]);
    } else {
      return productNoresultfound;
    }
  };

  // const filtermessage = totalItemCount ? totalcountMsg(displayStatus) : productNoresultfound;

  useEffect(() => {
    if (queryData) {
      setShowText(totalcountMsg(displayStatus));
    }
  }, [totalItemCount, showText, itemsPerPage]);

  if (error || queryError) {
    return <div>Error: {error || queryError.message}</div>;
  }

  const handleDropdownFilter = val => {
    const pagePathArray = window.location.pathname.split('/');
    if (window.digitalData) {
      digitalData.search = digitalData.search || {};
      digitalData.pageInfo = digitalData.pageInfo || {};
      digitalData.search.searchEvent = 'plp sort';
      digitalData.pageInfo.plpType = 'plp sort type ' + pagePathArray[pagePathArray.indexOf('catalog') + 1];
      digitalData.pageInfo.sort = val;
      digitalData.pageInfo.onsiteSearchResults = totalItemCount;

      if (typeof _satellite !== 'undefined' && _satellite.track) {
        _satellite.track('crucial_plp_filtering_tracking');
      }
    }

    setDropdownFilterVal(val);
    if (dropdownFilterVal != val) {
      setInitialFetch(false);
    }
  };

  const compareData = val => {
    setCompareItems(val);
  };

  const addCompareFilterData = val => {
    const index = comparfiltereData.indexOf(null);
    if (index !== -1) {
      const newSelectedCards = [...comparfiltereData];
      newSelectedCards[index] = val;
      setCompareFilterData(newSelectedCards);
    }
  };

  const removeCompareFilterData = val => {
    const finaldata = comparfiltereData.filter(obj => obj && obj.id !== val);
    while (finaldata.length < 4) {
      finaldata.push(null);
    }
    setCompareFilterData(finaldata);
  };

  const showComapareDrawer = comparfiltereData?.filter(card => card !== null).length;

  return (
    <LayoutContainer>
      <div className="plp_container">
        {(queryLoading || secondQueryLoading) && <Loader />}
        <div className="header_loaded_result_text">{showText}</div>
        <div className="filter_container_header">
          <div className="selected_filter_wrapper">
            {/* <div className="header_loaded_result_text">{filtermessage}</div> */}

            {/* <Expand /> */}
            <div className="filter-sort-container">
              <span className="filter-sort-title">{plpSortFilterTitle}</span>
              {/* Render buttons for each query parameter */}
              {params.length > 0 ? renderButtons() : <em>{plpNoFiltersApplied}</em>}
              {params?.length > 0 && (
                <button className="btn-clear-all" onClick={clearAll}>
                  {plpClearall}
                </button>
              )}
            </div>

            <button className="filter_sort" onClick={toggleConfirmation}>
              {plpFilterAndSort}
            </button>
          </div>
          <div className="dropdown_filter">
            <DropdownFilter
              options={productListData?.attributeMetadata?.sortable}
              dropdownFilterVal={dropdownFilterVal}
              dropdownVal={dropdownVal}
              setDropdownVal={setDropdownVal}
              {...restProps}
              filterby={handleDropdownFilter}
            />
          </div>
        </div>
        <div className="product_list_container">
          <div className="filter_dropdown_mobile_modal">
            {isConfirmationShowing && (
              <ModalPopup
                closeTitle="Done"
                isShowing={isConfirmationShowing}
                hide={toggleConfirmation}
                className="filter-popup"
                isMobile={isConfirmationShowing}>
                <div className="filter_dropdown filter_dropdown_mobile ">
                  <div className="filter-sort-mobile-title">{plpFilterAndSort}</div>
                  {checkBoxFilterData?.length > 0 && <span className="filter_count">+{params?.length}</span>}
                  {checkBoxFilterData.length > 0 ? (
                    renderButtons()
                  ) : (
                    <div className="no_filter_text">{plpNoFiltersApplied}</div>
                  )}
                  {params?.length > 0 && (
                    <button className="btn-clear-all" onClick={clearAll}>
                      {plpClearall}
                    </button>
                  )}
                  <div>
                    <DropdownFilter
                      className="dropdownfilter_mobile"
                      filterby={handleDropdownFilter}
                      dropdownFilterVal={dropdownFilterVal}
                      options={productListData?.attributeMetadata?.sortable}
                      dropdownVal={dropdownVal}
                      setDropdownVal={setDropdownVal}
                      {...restProps}
                    />
                  </div>
                  {productListData?.productSearch?.facets?.map(filterDatalist => {
                    return (
                      <FilterContainer
                        key={filterDatalist?.attribute}
                        filterDatalist={filterDatalist}
                        productCategoryList={productCategoryList}
                        totalItemCount={totalItemCount}
                      />
                    );
                  })}
                </div>
              </ModalPopup>
            )}
          </div>

          <div className="filter_dropdown filter_dropdown_desktop">
            {productListData?.productSearch?.facets?.map(filterDatalist => {
              return (
                <FilterContainer
                  key={filterDatalist?.attribute}
                  filterDatalist={filterDatalist}
                  productCategoryList={productCategoryList}
                  totalItemCount={totalItemCount}
                />
              );
            })}
          </div>
          <div className="product_item_container">
            <div className="products">
              {/* {showHandleCompareModal && (
                <CompareModal
                  // show={showHandleCompareModal}
                  setModal={handleComapre}
                  compareItems={compareItems}
                  handleClose={handleComapre}
                />
              )} */}
              {/* {showHandleCompareModal && <CustomSlider compareDataList={compareItems} />} */}
              {cardListData?.map((contents, index) => (
                <ProductCard
                  key={contents?.productView?.id + index}
                  count={count}
                  handleCount={value => handleCount(value)}
                  handleComapre={handleComapre}
                  productdata={contents}
                  brandstyles={brandstyles}
                  compareData={compareData}
                  fetchMore={fetchMore}
                  addCompareFilterData={addCompareFilterData}
                  removeCompareFilterData={removeCompareFilterData}
                  compareListDataUID={compareListDataUID}
                  comparfiltereData={comparfiltereData}
                  {...restProps}
                />
              ))}
            </div>
            <div className="pagination_container">
              {productListData?.productSearch?.total_count > 0 && (
                <>
                  {productListData?.productSearch?.total_count >= ITEMS_PER_PAGE ? (
                    <ProgressBar currentCount={itemsPerPage} totalCount={productListData?.productSearch?.total_count} />
                  ) : (
                    <ProgressBar
                      currentCount={productListData?.productSearch?.total_count}
                      totalCount={productListData?.productSearch?.total_count}
                    />
                  )}
                </>
              )}

              {queryData && <div className="footer_loaded_result_text">{totalcountMsg(plpPaginationmsg)}</div>}
              {itemsPerPage < productListData?.productSearch?.total_count ? (
                <Button type="primary" size="small" onClick={handleLoadMore}>
                  {plpLoadmore}
                </Button>
              ) : null}
            </div>

            {/* {showComapareDrawer < 0 && (
              <div className={`compare_drawer ${isDrawerOpen ? 'open_drawer' : 'closed_drawer'}`}>
                <div className="compare_drawer_toggle_view">
                  <button className="compare_drawer_icon_wrapper" onClick={() => setDrawer(!isDrawerOpen)}>
                    <Icon
                      name="ArrowDown"
                      size="smallest"
                      className={`compare_drawer_arrow ${isDrawerOpen ? 'open' : 'close'}`}
                    />
                  </button>
                </div>
                <div className={`compare_drawer__card_container ${isDrawerOpen ? 'open-view' : 'close-view'}`}>
                  {comparfiltereData?.map(data => {
                    return (
                      <div className={data ? 'filled_card' : 'card'}>
                        <div>
                          <button
                            onClick={() => {
                              removeCompareFilterData(data?.id);
                            }}>
                            x
                          </button>
                          <img src={data?.img} alt="product_img" className="itm-image"></img>
                          <span className="item-title">{data?.title}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )} */}
          </div>
        </div>
      </div>
    </LayoutContainer>
  );
}
