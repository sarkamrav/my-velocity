import React, { useState } from 'react';
import './modal.scss';

const Modal = ({ handleClose, show, compareDataList }) => {
  const showHideClassName = show ? 'modal display-block' : 'modal display-none';
  return (
    <div className={showHideClassName}>
      <div className="modal-wrapper" style={{ width: '80%' }}>
        <button onClick={handleClose}>close</button>
        <div className="modal-row">
          {compareDataList &&
            compareDataList.map(list => {
              return (
                <div className="compare_data_column" style={{ width: `calc(100% / ${compareDataList?.length})` }}>
                  <header className="modal_header">
                    <div className="product_name">{list.name}</div>
                  </header>
                  <main className="product_description">
                    <div className="product_info">
                      <ul>
                        <li>Brand</li>
                        <li>{list.name}</li>
                      </ul>
                      <ul>
                        <li>Product Type</li>
                        <li>{list.name}</li>
                      </ul>
                      <ul>
                        <li>Speed</li>
                        <li>{list.name}</li>
                      </ul>
                      <ul>
                        <li>Technology</li>
                        <li>{list.name}</li>
                      </ul>
                      <ul>
                        <li>Part Number</li>
                        <li>{list.name}</li>
                      </ul>
                      <ul>
                        <li>Configuration</li>
                        <li>{list.name}</li>
                      </ul>
                      <ul>
                        <li>Density</li>
                        <li>{list.name}</li>
                      </ul>
                      <ul>
                        <li>Device Type</li>
                        <li>{list.name}</li>
                      </ul>
                    </div>
                  </main>
                  <footer>footer</footer>
                  <div />

                  <div />
                </div>
              );
            })}
        </div>
      </div>
    </div>
  );
};

export default Modal;
