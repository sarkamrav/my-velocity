import React, { useState } from 'react';
import FilterCheckbox from '../filtercheckbox/FilterCheckbox';
import PropTypes from 'prop-types';
import Icon from '../../../../assests/Icon';
import './filtercontainer.scss';

function FilterContainer({ filterDatalist, productCategoryList, totalItemCount }) {
  const [showCategory, setShowCategory] = useState(false);
  const { attribute, buckets, title } = filterDatalist;

  //Function to toggle the category
  const handleShowCategory = () => {
    setShowCategory(!showCategory);
  };

  const isCategory = attribute === 'categories';

  return (
    <div className="filter_category">
      {filterDatalist?.buckets?.length > 0 && (
        <div className={`filter_category__type  ${isCategory ? 'disabled_events' : ''}`} onClick={handleShowCategory}>
          {title}
          <Icon
            name="ChevronDown"
            size="extra-small"
            className={`${showCategory ? 'isOpen' : 'isClosed'} ${isCategory ? 'show_chevron' : ''} `}
          />
        </div>
      )}

      {!showCategory &&
        Object.entries(productCategoryList).map(
          ([title, link]) =>
            attribute == 'categories' && (
              <a href={link} className={location.pathname.trim() == link ? 'link_selected' : ''}>
                {title}
              </a>
            )
        )}

      {attribute !== 'categories' && showCategory && filterDatalist?.buckets?.length > 0 && (
        <div className="row_section">
          {buckets.map(data => (
            <FilterCheckbox key={data.id} options={data} attribute={attribute} totalItemCount={totalItemCount} />
          ))}
        </div>
      )}
    </div>
  );
}

FilterContainer.propTypes = {
  filterDatalist: PropTypes.shape({}),
};

FilterContainer.defaultProps = {
  filterDatalist: null,
};

export default FilterContainer;
