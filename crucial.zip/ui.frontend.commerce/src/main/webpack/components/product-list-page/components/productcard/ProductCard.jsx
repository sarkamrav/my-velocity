// import { FaShoppingCart, FaRegBookmark, FaStar, FaFireAlt } from 'react-icons/fa';
import React, { useState, useEffect } from 'react';
import Button from '../../../micro-components/Button/Button';
import RibbonPanel from '../../../ribbonpanel/RibbonPanel';
import PropTypes from 'prop-types';
import {
  updateCompareDataList,
  removeCompareDataList,
  addItemsToCompareList,
} from '../../../../contexts/common/actions/plpactions';
import { useStoreContext } from '../../../../contexts/common/StoreContext';
import { findObjectByName, formatLocalePrice } from '../../../../utils/utils';
import StarRating from '../../../star-rating/StartRating';
import ModalPopup from '../../../modal-popup/ModalPopup.jsx';
import useModal from '../../../../hooks/useModal.jsx';
import { ADD_PRODUCTS_TO_CART, CREATE_EMPTY_CART } from '../../../../site/js/gql/mutations/cart.gql.js';
import AddToCartModal from '../../../product-information/components/add-to-cart-modal/AddToCartModal.jsx';
import SelectRetailers from '../../../product-information/components/select-retailers/SelectRetailers.jsx';
import { useMutation, useQuery } from '@apollo/client';
import {
  getCatalogServiceHeaders,
  getUserTokenFromLoaclStorate,
} from '../../../../configs/ReactApolloClientSetup/ApolloClientConfig.js'; // Fixed the spelling of 'LocalStorage'
import { getCookie, setCookie, checkCookie } from '../../../../utils/cookies_operation.js';
import GET_CART from '../../../../site/js/gql/get-cart.gql.js';
import LoginForm from '../../../login/component/loginform/LoginForm.jsx';
import CreateAccount from '../../../create-account/CreateAccount.jsx';
import ForgetPassword from '../../../forget-password/ForgetPassword.jsx';
import { SET_STOCK_NOTIFICATION } from '../../../../site/js/gql/mutations/stock-notification.gql.js';
//import { ADD_PRODUCTS_COMPARE_LIST } from '../../../../site/js/gql/mutations/add-products-to-compare-list.gql.js';
//import { REMOVE_PRODUCTS_COMPARE_LIST } from '../../../../site/js/gql/mutations/remove-products-to-compare-list.gql.js';
import { getShoppingUrls } from '../../../../site/js/urlresolver.js';
import Icon from '../../../../assests/Icon.js';
import Loader from '../../../micro-components/Loader/Loader.jsx';
import { hideSignInDiv } from '../../../../site/js/noncommerce-login.js';
import { applyScanPromoCode } from '../../../../utils/applyScanPromo.js';

export function ProductCard({
  productdata,
  compareListDataUID,
  count,
  brandstyles,
  handleCount,
  handleComapre,
  compareData,
  comparfiltereData,
  incVat,
  isInPdp = false,
  ...props
}) {
  const {
    plpAddtocart,
    plpBuyingoptions,
    plpAlsoavailable,
    guestNotifyMessage,
    loggedInNotifyMessage,
    plpNotifyTitle,
    addCompareFilterData,
    fetchMore,
    removeCompareFilterData,
  } = props;

  const [isChecked, setIsChecked] = useState(false);
  const [isCompare, setIsCompare] = useState(false);
  const [showConfirmPopup, setShowConfirmPopup] = useState(false);
  const [cartItem, setCartItem] = useState(false);
  const [pdpUrl, setPdpUrl] = useState('');
  const [buyingOptionUrl, setBuyingOptionUrl] = useState('');
  const [brandcolor, setBrandColor] = useState('');
  const [notifyMessage, setNotifyMessage] = useState(guestNotifyMessage);
  const [nofityMessegeShown, setNofityMessegeShown] = useState(true);
  const [compResData, setCompResData] = useState(null);
  const [hideNonCommerceLocale, setHideNonCommerceLocale] = useState(false);

  const { isShowing: isConfirmationShowing, toggle: toggleConfirmation } = useModal();
  const { isShowing: isMaxCompare, toggle: maxCompaireToggleConfirmation } = useModal();
  const { isShowing: isLoginConfirmation, toggle: loginToggleConfirmation } = useModal();
  const { isShowing: isCAConfirmation, toggle: caToggleConfirmation } = useModal();
  const { isShowing: isForgetPasswordLogin, toggle: forgetToggleConfirmation } = useModal();

  const locale = getCatalogServiceHeaders();

  //non commerce locale hide
  useEffect(() => {
    setHideNonCommerceLocale(hideSignInDiv);
  }, []);

  useEffect(() => {
    setIsChecked(comparfiltereData?.some(item => item && item.id === id));
  }, [comparfiltereData, id]);

  const { state, dispatch } = useStoreContext();

  const fallbackUrl = getShoppingUrls().placeHolderImage;

  const handleUserForm = () => {
    loginToggleConfirmation();
    caToggleConfirmation();
  };

  /* to show forget password screen */
  const forgetPasswordHandler = () => {
    loginToggleConfirmation();
    forgetToggleConfirmation();
    // setSignupForm(false);
    // setForgetPasswordForm(true);
  };

  const cancelFormHandler = () => {
    loginToggleConfirmation();
  };

  const createAccountHandler = event => {
    if (event === 'login') {
      caToggleConfirmation();
      loginToggleConfirmation();
    }

    if (event === 'shopping') {
      //needs to verify
      caToggleConfirmation();
      loginToggleConfirmation();
    }
  };
  const [stockNotification, { loading: notificationloading, error, data: stockdata }] =
    useMutation(SET_STOCK_NOTIFICATION);
  // const [addProductsToCompare, { loading: addompareloading, data: addProductData }] =
  //   useMutation(ADD_PRODUCTS_COMPARE_LIST);
  // const [removeProductsToCompare, { loading: removecompareloading, data: removeProductData }] =
  //   useMutation(REMOVE_PRODUCTS_COMPARE_LIST);
  useEffect(() => {
    let previousScript = document.getElementById('cswidgetjs');
    if (previousScript) {
      previousScript.remove();
    }
    const script = document.createElement('script');
    script.src = 'https://cscoreproweustor.blob.core.windows.net/widget/scripts/cswidget.loader.js';
    script.async = true;
    document.body.appendChild(script);
    return () => {
      document.body.removeChild(script);
    };
  }, []);

  const {
    id,
    inStock,
    name,
    price,
    attributes,
    sku,
    images,
    externalId,
    categories_url_list = {},
  } = isInPdp ? productdata : productdata.productView;

  const productRatings = findObjectByName(attributes, 'rating_count');
  useEffect(() => {
    const isEol = findObjectByName(attributes, 'is_eol');
    const isNewProduct = findObjectByName(attributes, 'is_new_product');
    const isPreOrder = findObjectByName(attributes, 'pre_order');

    // Filter out undefined objects
    const validObjects = [isEol, isNewProduct, isPreOrder].filter(obj => obj !== undefined);

    // Find the first object with value 'true'
    const data = validObjects.find(obj => obj?.value == 'yes');
    if (data) {
      setBrandColor(data);
    }
  }, []);

  // const productRatigsCount = parseFloat(productRatings?.value).toFixed(1);
  // console.log('isBrandAvailable', parseFloat(productRatings?.value).toFixed(1));

  // console.log('attributes', attributes);
  const btnText = inStock ? plpAddtocart : plpBuyingoptions;

  const isRegularPriceMore = price?.regular?.amount?.value > price?.final?.amount?.value;

  const currency = price?.final?.amount?.currency;
  const currencySymbol = getCookie('currency') && JSON.parse(getCookie('currency')).currencySymbol;

  useEffect(() => {
    const productBrandName = findObjectByName(attributes, 'technology');
    let urlPath;
    let categoryName;
    let urlKey;

    if (categories_url_list?.categories?.length) {
      categories_url_list?.categories.map(obj => {
        if (obj.level === 3) {
          urlPath = obj.url_path.replace('ram', 'memory');
          urlKey = obj.url_key;
        }
        if (obj.level === 2) {
          categoryName = obj.url_path.replace('ram', 'memory');
        }
      });
    }

    const urlPathSegments = location.pathname.split('/');
    const catalogIndex = urlPathSegments.indexOf('catalog');
    const lowercaseBrandName = productBrandName?.value?.toLowerCase();
    const loginElement = document.querySelector('[data-name="Login"]');
    const isAuthor = loginElement?.hasAttribute('data-is-author');
    const rootPagePath = loginElement?.getAttribute('data-root-page');
    if (catalogIndex !== -1 && productBrandName?.value) {
      console.log('?? 1st');
      isAuthor
        ? setPdpUrl(
            `${rootPagePath}/${urlPathSegments[catalogIndex + 1].replace(
              /\.html$/,
              ''
            )}.html/${lowercaseBrandName}/${sku}`
          )
        : setPdpUrl(`/${urlPathSegments[catalogIndex + 1]}/${lowercaseBrandName}/${sku}`);
      isAuthor
        ? setBuyingOptionUrl(
            `${rootPagePath}/buying-options.html/${urlPathSegments[catalogIndex + 1].replace(
              /\.html$/,
              ''
            )}/${lowercaseBrandName}/${sku}`
          )
        : setBuyingOptionUrl(`/buying-options/${urlPathSegments[catalogIndex + 1]}/${lowercaseBrandName}/${sku}`);
    } else if (categories_url_list?.categories?.length) {
      console.log('?? 2nd', categories_url_list?.categories);
      isAuthor ? setPdpUrl(`${rootPagePath}/${categoryName}.html/${urlKey}/${sku}`) : setPdpUrl(`/${urlPath}/${sku}`);
      isAuthor
        ? setBuyingOptionUrl(`${rootPagePath}/buying-options.html/${categoryName}.html/${urlKey}/${sku}`)
        : setBuyingOptionUrl(`/buying-options/${urlPath}/${sku}`);
    }
  }, [categories_url_list, location.pathname, sku, fetchMore]);

  const { regular: { amount: { value: regularPrice } = {} } = {}, final: { amount: { value: finalPrice } = {} } = {} } =
    price || {};

  const dataElement = document.querySelector('[data-name="ProductListPage"]');

  // const checkboxChangeHandler = async () => {
  //   // if (count <= 3) {
  //   //   console.log('countcountcountcount', count);
  //   if (!isChecked) {
  //     if (count <= 3) {
  //       setIsChecked(!isChecked);
  //       setIsCompare(true);
  //       handleCount(1);
  //       // dispatch(updateCompareDataList(productdata));

  //       const resdata = await addProductsToCompare({
  //         variables: {
  //           uid: compareListDataUID,
  //           productList: [externalId],
  //         },
  //       });
  //       if (resdata) {
  //         console.log('resdata', resdata?.data?.core_addProductsToCompareList?.items);
  //         setCompResData(resdata);
  //         dispatch(addItemsToCompareList(resdata?.data?.core_addProductsToCompareList?.items));
  //         compareData(resdata?.data?.core_addProductsToCompareList?.items);
  //         addCompareFilterData({ id: id, img: images[0]?.url ? images[0]?.url : fallbackUrl, title: name });
  //       }
  //     } else {
  //       maxCompaireToggleConfirmation();
  //     }

  //     // console.log('xxxxx', resdata);
  //   } else {
  //     setIsChecked(!isChecked);
  //     setIsCompare(false);
  //     handleCount(-1);
  //     // dispatch(removeCompareDataList(productdata?.productView?.id));

  //     const resdata = await removeProductsToCompare({
  //       variables: {
  //         uid: compareListDataUID,
  //         productList: [externalId],
  //       },
  //     });

  //     if (resdata) {
  //       setCompResData(resdata);
  //       compareData(resdata?.data?.core_removeProductsFromCompareList?.items);
  //       dispatch(addItemsToCompareList(resdata?.data?.core_removeProductsFromCompareList?.items));
  //       removeCompareFilterData(id);
  //     }
  //   }
  //   // }
  //   // else {
  //   //   // handleCount(-1);
  //   //   console.log('countcountcountcount1', count);
  //   //   maxCompaireToggleConfirmation();
  //   // }
  // };

  const cartKey = 'cart_id';

  const accessToken = getUserTokenFromLoaclStorate() || '';

  const [createEmptyCart] = useMutation(CREATE_EMPTY_CART, {
    context: {
      headers: {
        authorization: accessToken ? `Bearer ${accessToken}` : '',
      },
    },
    onCompleted(data) {
      // const addToCartElement = document.querySelector('.addCart');
      const cartData = JSON.stringify(data.core_createEmptyCart);
      setCookie(cartKey, cartData, 2880);
      addProductToCart({
        variables: {
          cartId: JSON.parse(getCookie(cartKey)),
          SKU: sku,
          quantity: 1,
        },
      });
    },
  });

  const handleAddCart = () => {
    // const addToCartElement = document.querySelector('.addCart');
    if (!checkCookie(cartKey)) {
      createEmptyCart();
    } else {
      //Analytics code for add to cart event on plp
      if (window.digitalData) {
        digitalData.cart = digitalData.cart || {};
        digitalData.cart.addtocart = digitalData.cart.addtocart || [];
        digitalData.cart.oderOffer = '';
        let prodInfoObject = {
          skuToAdd: sku,
          qtyNumber: 1,
          prodCategory: pdpUrl.split('/')[1],
          prodSubCategory: pdpUrl.split('/')[2],
          prodTitle: name,
          pagePath: window.location.pathname,
          prodPrice: regularPrice,
          offerPrice: finalPrice,
          currency: price?.final?.amount?.currency,
          prodImage: images[0]?.url,
          cartID: JSON.parse(getCookie(cartKey)),
          loggedIn: localStorage.getItem('user_token') ? true : false,
          configToAdd: undefined,
          modOut: undefined,
          productOfferId: undefined,
          rfgpn: undefined,
        };
        digitalData.cart.addtocart.push({ productInfo: prodInfoObject });
        digitalData.cart.cartId = JSON.parse(getCookie(cartKey));
        if (typeof _satellite !== 'undefined' && _satellite.track) {
          // Fire the Add to Cart Event
          _satellite.track('add_to_cart');
        }
      }

      addProductToCart({
        variables: {
          cartId: JSON.parse(getCookie(cartKey)),
          SKU: sku,
          quantity: 1,
        },
      });
    }
  };

  const [addProductToCart, { data: addToCartData, loading: cartDataLoading, error: addToCartError }] = useMutation(
    ADD_PRODUCTS_TO_CART,
    {
      context: {
        headers: {
          authorization: accessToken ? `Bearer ${accessToken}` : '',
        },
      },
      onCompleted() {
        toggleConfirmation();
        // Update miniCart quantity.
        if (document.querySelector('.cmp-acommerce_cart-qty')) {
          document.querySelector('.cmp-acommerce_cart-qty').innerText =
            Math.floor(document.querySelector('.cmp-acommerce_cart-qty').innerText) + 1;
        }

        // Add product URL and SKU to the cookie to read on shopping cart and verify order pages
        let productUrlObj = {
          sku: sku,
          url: pdpUrl,
        };

        let productCookieData = (getCookie('cart_product_urls') && JSON.parse(getCookie('cart_product_urls'))) || [];

        let existingProduct = productCookieData.find(item => item.sku === sku);

        if (existingProduct) {
          existingProduct.url = pdpUrl;
        } else {
          productCookieData.push(productUrlObj);
        }

        setCookie('cart_product_urls', JSON.stringify(productCookieData));
        applyScanPromoCode();
      },
    }
  );

  if (addToCartError) {
    console.error(addToCartError);
    document.cookie = 'cart_id=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
    createEmptyCart();
  }

  const { data: viewCartData } = useQuery(GET_CART, {
    skip: !addToCartData,
    context: {
      headers: {
        authorization: accessToken ? `Bearer ${accessToken}` : '',
      },
    },
    variables: { cart_id: getCookie(cartKey) && JSON.parse(getCookie(cartKey)) },
  });
  if (viewCartData) {
    setCookie('cart_items', JSON.stringify(viewCartData), 2880);
  }
  // console.log("name",name);
  // const analyticsCall = ()=> {
  //This is analytics poc code. We will use this when we do actual implementation.
  //         digitalData.cart.addtocart = digitalData.cart.addtocart || [];
  //         digitalData.cart.oderOffer = "";
  //         let prodInfoObject = {
  //             "skuToAdd": "CP16G60C36U5B",
  //             "qtyNumber": 1,
  //             "prodCategory": "memory",
  //             "prodSubCategory": "DDR5",
  //             "prodTitle": "Crucial Pro Overclocking 16GB DDR5-6000 UDIMM Black",
  //             "rfgpn": "",
  //             "modOut": "",
  //             "pagePath": "/content/crucial/en-us/home/catalog/memory/ddr5",
  //             "prodPrice": 79.99,
  //             "offerPrice": "",
  //             "currency": "USD",
  //             "prodImage": "https://content.crucial.com/content/dam/crucial/dram-products/ddr5-pro/overclocking/photography/isolated/crucial-ddr5-pro-overclocking-single-dynamic-right-view.psd.transform/small-png/image.png",
  //             "capacity": "N/A",
  //             "cartID": 1124424374339
  //         };
  //         digitalData.cart.addtocart.push({"productInfo": prodInfoObject});
  //
  //         if (typeof _satellite !== 'undefined' && _satellite.track) {
  //             // Fire the Add to Cart Event
  //             _satellite.track('add_to_cart');
  //         }
  //   };

  //   const handleCompare = () =>{
  //     setIsCompare(true);
  //   };

  // const handleAddCart = () => {
  //   setShowConfirmPopup(true);
  // };

  const btnHandler = () => {
    if (btnText === plpAddtocart) {
      handleAddCart();

      // toggleConfirmation();
    } else {
      window.location.href = buyingOptionUrl;
    }
  };

  // console.log('cartItem', cartItem);
  const handleViewCart = () => {
    setShowConfirmPopup(false);
  };

  const notifyHandler = async () => {
    let user_token = localStorage.getItem('user_token');
    if (user_token) {
      const resdata = await stockNotification({
        variables: {
          productNumber: externalId && Number(externalId),
        },
      });

      const isResponseSuccess = resdata?.data?.core_registerProductStockAlert;
      if (isResponseSuccess?.success) {
        setNotifyMessage(loggedInNotifyMessage);
        setNofityMessegeShown(false);
      }
    } else {
      loginToggleConfirmation();
    }
  };

  // const handleContinueShopping = () => {
  //   setShowConfirmPopup(false);
  // };

  // const fallbackUrl =
  //   'http://integration2-hohc4oi-hyx5gew4gsdtk.us-5.magentosite.cloud/static/version1714474492/frontend/Magento/luma/en_US/Magento_Catalog/images/product/placeholder/image.jpg';

  // const gradientBackground = {
  //   background: brandcolor?.label, // Example gradient
  // };
  // console.log('comparfiltereData', comparfiltereData);÷

  return (
    <>
      {(notificationloading || cartDataLoading) && <Loader />}
      <div className="productCardWrapper">
        <div key={id} className="productCard">
          <a href={pdpUrl} className="image_container">
            <img
              loading="lazy"
              src={images[0]?.url ? images[0]?.url : fallbackUrl}
              alt="product_img"
              className="productImage"></img>
          </a>
          {/* {prefix && <RibbonPanel>{prefix}</RibbonPanel>} */}
          {!isInPdp
            ? Object.entries(brandstyles).map(
                ([title, link]) =>
                  title == brandcolor?.name && (
                    <RibbonPanel style={{ background: link }}>{brandcolor?.label}</RibbonPanel>
                  )
              )
            : ''}

          {/* <RibbonPanel style={gradientBackground}>new</RibbonPanel> */}
          <div className="productCard__content">
            <div className="description">
              {/* <p className="title_prefix">{productBrandName?.label}</p> */}
              <p className="title_prefix">Crucial</p>

              <h3 className="product_title">
                <a className="product-title_link" href={pdpUrl}>
                  {name}
                </a>
              </h3>
              <div className="product_detail">
                <span className="sku_number">{sku}</span>
                <div className="productRating">
                  <StarRating value={productRatings?.value} className="ratings-star" />
                </div>
              </div>
            </div>

            {price && !hideNonCommerceLocale && (
              <div className="productPrice">
                <span className={isRegularPriceMore ? 'final_price_red' : 'final_price'}>
                  {formatLocalePrice(price?.final?.amount?.value, currencySymbol)}
                  {/* Display symbol on right side for these three locales */}
                  {locale !== 'en_us' && <span className="vat_text">{incVat}</span>}
                </span>
                {isRegularPriceMore && (
                  <span className="regular_price">
                    {formatLocalePrice(price?.regular?.amount?.value, currencySymbol)}
                    {locale !== 'en_us' && <span className="vat_text">{incVat}</span>}
                  </span>
                )}
              </div>
            )}
            <div className="productcard_footer">
              {!hideNonCommerceLocale && (
                <Button
                  type="primary"
                  onClick={btnHandler}
                  // onClick={btnHandler}
                  // onClick={e => {
                  //   e.preventDefault();
                  //   toggleConfirmation();
                  // }}
                >
                  {btnText}
                </Button>
              )}

              {!inStock && !hideNonCommerceLocale && (
                <p className="guest-notify-title-link-wrapper">
                  {nofityMessegeShown && !hideNonCommerceLocale && (
                    <span className="guest-notify-title-link" onClick={notifyHandler}>
                      {plpNotifyTitle}{' '}
                    </span>
                  )}
                  <span>{notifyMessage}</span>
                </p>
              )}

              {inStock && (
                <div className="select_retailer_title">
                  <SelectRetailers dataElement={dataElement} sku={sku} {...props} />
                </div>
              )}
              {/* 
              <div className="compare-wrapper">
                <div
                  className="customCheckbox__container"
                  id={name}
                  style={{ position: 'relative' }}
                  onClick={checkboxChangeHandler}
                  name={name}>
                  <div className="customCheckbox__checkbox">
                    {isChecked ? <Icon name="Checkbox" /> : <Icon name="CheckboxEmpty" />}
                  </div>
                  <label className="compare-link" htmlFor={name}>
                    Compare
                  </label>
                  {isCompare && count >= 2 ? (
                    <label
                      className="compare-click-link"
                      htmlFor={name}
                      onClick={e => {
                        e.stopPropagation();
                        handleComapre();
                      }}>
                      Compare now
                    </label>
                  ) : (
                    <label className="compare-link" htmlFor={name}>
                      Compare
                    </label>
                  )}
                </div>
              </div> */}
            </div>
          </div>
        </div>
        {isMaxCompare && (
          <ModalPopup isShowing={isMaxCompare} hide={maxCompaireToggleConfirmation}>
            <p>Please refine your Selection</p>
            <p>The maximum number of products that can be compared is 4.Please refine your selection</p>
          </ModalPopup>
        )}
        {isConfirmationShowing && (
          <ModalPopup isShowing={isConfirmationShowing} hide={toggleConfirmation}>
            <AddToCartModal
              productImage={images[0]?.url}
              productName={name}
              price={price}
              finalPrice={finalPrice}
              regularPrice={regularPrice}
              currency={currency}
              viewCart={handleViewCart}
              continueShopping={toggleConfirmation}
            />
          </ModalPopup>
        )}
        {isLoginConfirmation && (
          <ModalPopup isShowing={isLoginConfirmation} hide={loginToggleConfirmation} className="auth-popup">
            <LoginForm changeFormHandler={handleUserForm} forgetPasswordHandler={forgetPasswordHandler} {...props} />
          </ModalPopup>
        )}
        {isCAConfirmation && (
          <ModalPopup className="auth-popup" isShowing={isCAConfirmation} hide={caToggleConfirmation}>
            <CreateAccount
              cancelFormHandler={cancelFormHandler}
              createAccountHandler={createAccountHandler}
              {...props}
            />
          </ModalPopup>
        )}
        {isForgetPasswordLogin && (
          <ModalPopup isShowing={isForgetPasswordLogin} hide={forgetToggleConfirmation} className="auth-popup">
            <ForgetPassword
              cancelFormHandler={cancelFormHandler}
              forgetPasswordHandler={forgetPasswordHandler}
              {...props}
            />
          </ModalPopup>
        )}
      </div>
    </>
  );
}

export default ProductCard;
