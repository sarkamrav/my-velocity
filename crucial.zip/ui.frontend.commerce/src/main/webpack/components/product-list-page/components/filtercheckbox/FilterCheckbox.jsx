import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import PropTypes from 'prop-types';
import CustomCheckbox from '../../../customcheckbox/CustomCheckbox';
import './filtercheckbox.scss';

function FilterCheckbox({ options, attribute, totalItemCount }) {
  const [selectedValues, setSelectedValues] = useState([]);
  const { title, id } = options;

  const navigate = useNavigate();
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);

  const isCheckboxChecked = selectedValues.includes(title + '@' + attribute);

  // Parse query parameters on page load
  useEffect(() => {
    const selectedValuesParam = queryParams.get('selectedValues');
    if (selectedValuesParam) {
      setSelectedValues(selectedValuesParam.split('--'));
    } else {
      setSelectedValues([]);
    }
  }, [location.search]);

  // Function to update query parameters
  const updateQueryParams = values => {
    if (values.length === 0) {
      navigate(location.pathname);
    } else {
      navigate({
        search: `?selectedValues=${values.join('--')}`,
      });
    }
  };

  // Function to handle checkbox click
  const handleCheckboxChange = value => {
    let updatedValues;
    // const finalval = value + '-' + attribute;
    if (selectedValues.includes(value)) {
      updatedValues = selectedValues.filter(val => val !== value);
    } else {
      updatedValues = [...selectedValues, value];
    }
    if (window.digitalData) {
      const pagePathArray = window.location.pathname.split('/');
      digitalData.search = digitalData.search || {};
      digitalData.pageInfo = digitalData.pageInfo || {};
      digitalData.search.searchEvent = 'search filter';
      digitalData.pageInfo.filterItem = JSON.stringify(updatedValues).replace('[', '').replace(']', '').toLowerCase();
      digitalData.pageInfo.plpType = 'plp filter type:' + pagePathArray[pagePathArray.indexOf('catalog') + 1];
      digitalData.pageInfo.onsiteSearchResults = totalItemCount;

      if (typeof _satellite !== 'undefined' && _satellite.track) {
        _satellite.track('crucial_plp_filtering_tracking');
      }
    }
    updateQueryParams(updatedValues);
    setSelectedValues(updatedValues);
  };

  // Construct GraphQL query with checkbox values
  // useEffect(() => {
  //   const GET_DATA = gql`
  //       query GetData($checkboxValues: [String]) {
  //       // Your query fields here
  //       }
  //   `;

  //   client.query({
  //       query: GET_DATA,
  //       variables: {
  //       checkboxValues: checkboxValues,
  //       },
  //   });
  // }, [checkboxValues, client]);

  return (
    <div className="category_row">
      <CustomCheckbox
        id={id}
        name={title}
        title={title}
        checked={isCheckboxChecked}
        handleChange={() => handleCheckboxChange(title + '@' + attribute)}
      />
    </div>
  );
}

FilterCheckbox.propTypes = {
  options: PropTypes.shape({
    id: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
  }),
};

export default FilterCheckbox;
