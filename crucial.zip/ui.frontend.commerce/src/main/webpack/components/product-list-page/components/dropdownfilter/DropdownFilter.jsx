import React, { useState, useRef, useEffect } from 'react';

function DropdownWithRadio({ options, dropdownVal, setDropdownVal, dropdownFilterVal, filterby, className, ...props }) {
  const titleRef = useRef(null);
  const [textWidth, setTextWidth] = useState(0);
  useEffect(() => {
    if (options) {
      setDropdownVal(prevState => {
        const newState = [...prevState];
        newState[0].options = [...options];
        return newState;
      });
    }
  }, [options]);

  const { plpSortby } = props;

  useEffect(() => {
    if (titleRef.current) {
      setTextWidth(titleRef.current.offsetWidth);
    }
  }, [props.plpSortby]);

  const handleChange = event => {
    filterby && filterby(event.target.value);
  };

  return (
    <div className="sortby-dropdown-container">
      <option className="sortby-title" ref={titleRef}>
        {plpSortby}:
      </option>
      <select
        className="sortby-dropdown"
        style={{ paddingLeft: `${textWidth + 8}px` }}
        onChange={handleChange}
        value={dropdownFilterVal}>
        {options?.map((option, index) => (
          <option key={index} value={option.attribute}>
            {option.label}
          </option>
        ))}
      </select>
    </div>
  );
}

export default DropdownWithRadio;
