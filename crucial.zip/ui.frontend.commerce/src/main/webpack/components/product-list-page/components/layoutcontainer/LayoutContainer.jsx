import React from 'react';
import PropTypes from 'prop-types';
import './layoutcontainer.scss';

const LayoutContainer = ({ children }) => {
  return (
    <div className="cmp_container">
      {children}
    </div>
  );
};

export default LayoutContainer;

LayoutContainer.propTypes = {
 children: PropTypes.node.isRequired
};
