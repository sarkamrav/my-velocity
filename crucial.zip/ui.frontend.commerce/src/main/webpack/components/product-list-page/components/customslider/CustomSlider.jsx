import React, { useRef } from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import useCustomSlider from '../../../../hooks/useCustomSlider';

const CustomSlider = ({ compareDataList }) => {
  const { sliderRef, settings, handleDotClick } = useCustomSlider();

  return (
    <div className="custom-slider">
      <Slider ref={sliderRef} {...settings}>
        {compareDataList.map((slide, index) => (
          <div key={index}>
            <h2>{slide.uid}</h2>
            {/* Add other content of the slide */}
          </div>
        ))}
      </Slider>
      <div className="dots">
        {compareDataList.map((_, index) => (
          <span key={index} onClick={() => handleDotClick(index)} />
        ))}
      </div>
    </div>
    // <div>hi</div>
  );
};

CustomSlider.propTypes = {
  // compareDataList: PropTypes.arrayOf(PropTypes.object).isRequired,
};

export default CustomSlider;
