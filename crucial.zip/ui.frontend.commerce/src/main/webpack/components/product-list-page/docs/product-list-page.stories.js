import ProductListPage from "../product-list-page.hbs";

export default {
  title: "Components/React Component/Product-List-Page",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { ProductListPage };
