import React, { useEffect, useState, useRef } from 'react';
import Link from '../micro-components/Link/Link';
import { useLazyQuery, useMutation, useQuery } from '@apollo/client';
import {
  DELETE_SAVED_CARD,
  GET_SAVED_PAYMENT,
  SAVE_PAYMENT,
  SAVED_GET_CUSTOMER,
  SET_AS_DEFAULT,
} from '../../site/js/gql/mutations/account/save-payment.gql';
import Icon from '../../assests/Icon';
import { createPortal } from 'react-dom';
import Loader from '../micro-components/Loader/Loader';
import { GET_DR_SOURCE_DATA } from '../../site/js/gql/get-dr-source.gql';
import { getUserTokenFromLoaclStorate } from '../../configs/ReactApolloClientSetup/ApolloClientConfig';
const getToken = () => `Bearer ${getUserTokenFromLoaclStorate()}`;

export default function SavedPayments({
  displayHeading,
  displaySubHeading,
  displayOptionsHeading,
  displayNewPaymentLabel,
  displayNewAddressLabel,
  displayNewAddressLink,
  displayBackLabel,
  displayBackLink,
  noDefaultBilling,
  displayCreditCardLabel,
  displayExpirationLabel,
  displaySubmitLabel,
  displayEditLabel,
  displayDeleteLabel,
  displayDefaultLabel,
  defaultLabel,
  confirmCardDelete,
  cardDefaultSetMessage,
  cardDeleteMessage,
}) {
  const [savedPayments, setSavedPayments] = useState({});
  const [defaultBilling, setDefaultBilling] = useState({});
  const [hideForm, setHideForm] = useState(false);
  const [loader, setLoader] = useState(false);
  const [isEditable, setIsEditable] = useState(false);
  const [editSourceData, setEditSourceData] = useState({});
  const buttonRef = useRef(null);
  const [cardNumber, setCardNumber] = useState('');
  const [deleteSuccess, setDeleteSuccess] = useState(false);
  const [defaultSuccess, setDefaultSuccess] = useState(false);

  // Query selector
  const element = document.querySelector('[data-name="SavedPayments"]');

  const { data: paymentData, loading: cardLoading } = useQuery(GET_SAVED_PAYMENT, {
    context: {
      headers: {
        Authorization: getToken(),
      },
    },
  });

  const { data: customerData } = useQuery(SAVED_GET_CUSTOMER, {
    context: {
      headers: {
        Authorization: getToken(),
      },
    },
  });

  const [savePayment] = useMutation(SAVE_PAYMENT, {
    context: {
      headers: {
        Authorization: getToken(),
      },
    },
  });

  const [deleteCard, { loading: deleteCardLoading }] = useMutation(DELETE_SAVED_CARD, {
    context: {
      headers: {
        Authorization: getToken(),
      },
    },
  });

  const [setAsDefault, { loading: defaultLoading }] = useMutation(SET_AS_DEFAULT, {
    context: {
      headers: {
        Authorization: getToken(),
      },
    },
  });

  const [getSourceData, { loading: sourceLoading }] = useLazyQuery(GET_DR_SOURCE_DATA);

  const getDefaultAddress = (response, id) => {
    const addresses = response.core_customer.addresses;
    return addresses.find(address => address.id === id);
  };

  const messageDisplay = () => {
    if (defaultSuccess) {
      return <div className="submitsuccess">{cardDefaultSetMessage}</div>;
    } else if (deleteSuccess) {
      return <div className="submitsuccess">{cardDeleteMessage}</div>;
    }
  };

  if (!getUserTokenFromLoaclStorate() && !document.querySelector('[data-component="login"]')?.hasAttribute('data-is-author')) {
    window.location.href = '/';
  }

  function handleEdit(event) {
    const source = atob(event.target.getAttribute('data-source-id'));
    const cardNumber = `${event.target.getAttribute('data-brand')} ************${event.target.getAttribute(
      'data-card'
    )}`;
    setCardNumber(cardNumber);
    getSourceData({
      variables: {
        sourceId: source,
      },
    }).then(response => {
      const temp = atob(response.data.core_get_digital_river_source.dr_source);
      setEditSourceData(JSON.parse(temp));
      setIsEditable(true);
    });
  }

  const handleDelete = async event => {
    if (confirm(confirmCardDelete)) {
      const source = atob(event.target.getAttribute('data-source-id'));
      await deleteCard({
        variables: {
          source_id: source,
        },
        refetchQueries: [
          {
            query: GET_SAVED_PAYMENT,
            context: {
              headers: {
                Authorization: getToken(),
              },
            },
          },
        ],
      }).then(() => {
        setDeleteSuccess(true);
        setTimeout(() => setDeleteSuccess(false), 5000);
      });
    }
  };

  const handleSetAsDefault = async event => {
    const source = atob(event.target.getAttribute('data-source-id'));
    await setAsDefault({
      variables: {
        source_id: source,
      },
      refetchQueries: [
        {
          query: GET_SAVED_PAYMENT,
          context: {
            headers: {
              Authorization: getToken(),
            },
          },
        },
      ],
    }).then(() => {
      setDefaultSuccess(true);
      setTimeout(() => setDefaultSuccess(false), 5000);
    });
  };

  useEffect(() => {
    if (customerData) {
      if (customerData?.core_customer?.default_billing) {
        const default_billing_id = Number(customerData?.core_customer?.default_billing);
        const customerDefaultBilling = getDefaultAddress(customerData, default_billing_id);
        setDefaultBilling(customerDefaultBilling);
      } else {
        setHideForm(true);
      }
    }
  }, [customerData]);

  useEffect(() => {
    if (paymentData) {
      setSavedPayments(paymentData.core_getSavedCard);
    }
  }, [paymentData]);

  useEffect(() => {

      if (Object.keys(defaultBilling).length > 0) {
        setLoader(true);
        const script = document.createElement('script');
        script.src = 'https://js.digitalriverws.com/v1/DigitalRiver.js';
        script.async = true;
        script.onload = () => {
          const digitalriverpayments = new DigitalRiver(element.getAttribute('data-dr-public-key'));
          const configuration = {
            options: {
              flow: 'managePaymentMethods',
              showComplianceSection: false,
              showSavePaymentAgreement: false,
              usage: 'convenience',
            },
            billingAddress: {
              firstName: defaultBilling.firstname,
              lastName: defaultBilling.lastname,
              email: customerData?.core_customer?.email,
              phoneNumber: defaultBilling.telephone,
              address: {
                line1: defaultBilling.street[0],
                line2: defaultBilling.street[1] || '',
                city: defaultBilling.city,
                state: defaultBilling.region.region_code,
                postalCode: defaultBilling.postcode,
                country: defaultBilling.country_code,
              },
            },
            paymentMethodConfiguration: {
              enabledPaymentMethods: ['creditCard'],
            },
            onSuccess: async data => {
              await savePayment({
                variables: {
                  source_id: data.source.id,
                },
              }).then(() => {
                window.location.reload();
            });
          },
          onError: error => {
            console.error('Error:', error);
          },
        };

        const dropin = digitalriverpayments.createDropin(configuration);
        dropin.mount('drop-in');
        setLoader(false);
      };

      document.body.appendChild(script);

      // Cleanup function to remove the script and DigitalRiver instance
      return () => {
        document.body.removeChild(script);
      };
    }
  }, [defaultBilling]);

  useEffect(() => {
    if (isEditable) {
      const parentDiv = document.querySelector('.cmp-acommerce_card-expiration');
      const label = document.querySelector('.cmp-acommerce_saved-card-expiry-label');
      const newDiv = document.createElement('div');
      newDiv.id = 'card-exp';
      newDiv.className = 'DRElement';
      parentDiv.insertBefore(newDiv, label.nextSibling);
      const loadDigitalRiverScript = () => {
        const script = document.createElement('script');
        script.src = 'https://js.digitalriverws.com/v1/DigitalRiver.js';
        script.async = true;
        script.onload = () => {
          initializeDigitalRiver();
        };
        document.body.appendChild(script);
      };

      const initializeDigitalRiver = () => {
        const digitalriver = new DigitalRiver('pk_test_cfec641a625845029e124c5b0866ffc5');
        const options = {
          classes: {
            base: 'DRElement',
            complete: 'complete',
            empty: 'empty',
            focus: 'focus',
            invalid: 'invalid',
            webkitAutofill: 'autofill',
          },
          style: {
            base: {
              height: '42px',
              border: '1px solid black',
              borderWidth: '1px',
              borderStyle: 'solid',
              borderColor: '#E6E6E6',
              fontSize: '16px',
              fontWeight: 500,
              fontSmoothing: 'auto',
              fontVariant: 'normal',
              boxSizing: 'border-box',
            },
            empty: {
              height: '42px',
              border: '1px solid black',
              borderWidth: '1px',
              borderStyle: 'solid',
              borderColor: '#E6E6E6',
              fontSize: '16px',
              fontWeight: 500,
              fontSmoothing: 'auto',
              fontVariant: 'normal',
              boxSizing: 'border-box',
            },
            invalid: {
              color: 'red',
              height: '42px',
              border: '1px solid black',
              borderWidth: '1px',
              borderStyle: 'solid',
              borderColor: '#E6E6E6',
              fontSize: '16px',
              fontWeight: 500,
              fontSmoothing: 'auto',
              fontVariant: 'normal',
              boxSizing: 'border-box',
            },
          },
        };
        let cardNumberElement = document.getElementById('saved_credit_card_number');
        cardNumberElement.value = cardNumber;

        window.cardExpiration = digitalriver.createElement('cardexpiration', options);

        cardExpiration.mount('card-exp');

        const sourceData = {
          id: editSourceData.id,
          clientSecret: editSourceData.clientSecret,
        };

        let handleClick = () => {
          digitalriver.updateSource(cardExpiration, sourceData).then(result => {
            if (result.error) {
              const errorMessage = result.error.errors[0].message;
              console.log('source Error', errorMessage);
            } else {
              window.location.reload();
            }
          });
        };

        buttonRef.current.addEventListener('click', handleClick);

        return () => {
          buttonRef.current.removeEventListener('click', handleClick);
        };
      };

      loadDigitalRiverScript();
    }
  }, [isEditable]);

  return (
    <>
      <section className="cmp-acommerce_saved-payments__section">
        <div className="custom-container">
          <div className="cmp-acommerce_saved-payments__main row">
            <div className="cmp-acommerce_saved-payments__form column small-12 medium-8">
              <h2 className="cmp-acommerce_saved-payments__heading">{displayHeading}</h2>
              <div className="cmp-acommerce_saved-payments__sub-heading">
                <p>{displaySubHeading}</p>
              </div>
              {messageDisplay()}
              {hideForm ? (
                <>
                  <p>{noDefaultBilling}</p>
                </>
              ) : (
                <>
                  {!isEditable && (
                    <>
                      <link
                        rel="stylesheet"
                        href="https://js.digitalriverws.com/v1/css/DigitalRiver.css"
                        type="text/css"
                      />
                      <div id="drop-in"></div>
                    </>
                  )}
                  {isEditable && (
                    <>
                      <div className="cmp-acommerce_edit-saved-payments-form">
                        <div className="cmp-acommerce_saved-card-field">
                          <label htmlFor="saved_credit_card_number">{displayCreditCardLabel}</label>
                          <input
                            type="text"
                            name="saved_credit_card_number"
                            id="saved_credit_card_number"
                            disabled={true}
                          />
                        </div>
                        <div className="cmp-acommerce_saved-card-field cmp-acommerce_card-expiration">
                          <label className="cmp-acommerce_saved-card-expiry-label">{displayExpirationLabel}</label>
                        </div>
                        <button className="cmp-acommerce_button button-primary edit-submit" ref={buttonRef}>
                          {displaySubmitLabel}
                        </button>
                      </div>
                    </>
                  )}
                </>
              )}
            </div>
            <div className="cmp-acommerce_saved-payments__links column small-12 medium-4 large-3 large-offset-1">
              <div className="cmp-acommerce_saved-payments__links__container">
                <h3 className="cmp-acommerce_saved-payments__links__heading">{displayOptionsHeading}</h3>
                <ul className="cmp-acommerce_saved-payments__links__list">
                  <li>
                    <Link
                      type="secondary"
                      text={displayNewPaymentLabel}
                      className="saved-payments-link"
                      onClick={() => window.location.reload()}
                    />
                  </li>
                  <li>
                    <Link
                      type="secondary"
                      text={displayNewAddressLabel}
                      href={displayNewAddressLink}
                      className="saved-payments-link"
                    />
                  </li>
                </ul>
              </div>
              <div className="cmp-acommerce_saved-payments__links__container__saved-card">
                {Object.keys(savedPayments).length > 0 &&
                  savedPayments.map((card, index) => {
                    return (
                      <div className="cmp_acommerce-saved-cards" key={index}>
                        {card.is_default && <p className="cmp-acommerce_is-default-card">{defaultLabel}</p>}
                        <p className="acommerce-card-number">**** **** **** {card.lastFourDigits}</p>
                        <p>
                          {card.expirationMonth}/{card.expirationYear}
                        </p>
                        <p>
                          {defaultBilling.firstName} {defaultBilling.lastName} <br />
                          {defaultBilling.street}
                          <br />
                          {defaultBilling.city},{defaultBilling?.region?.region_code}
                          <br />
                          {defaultBilling.postcode}
                          <br />
                          {defaultBilling.country_code}
                          <br />
                          {defaultBilling.telephone}
                        </p>
                        <div className="cmp_acommerce-card-action">
                          <Link
                            text={displayEditLabel}
                            onClick={handleEdit}
                            data-source-id={btoa(card.id)}
                            data-card={card.lastFourDigits}
                            data-brand={card.brand}
                          />{' '}
                          <span className="separator">|</span>
                          <Link text={displayDeleteLabel} onClick={handleDelete} data-source-id={btoa(card.id)} />{' '}
                          {!card.is_default && (<>
                            <span className="separator">|</span>
                            <Link
                                text={displayDefaultLabel}
                                onClick={handleSetAsDefault}
                                data-source-id={btoa(card.id)}
                            />
                          </>)}
                        </div>
                      </div>
                    );
                  })}
              </div>
              <div className="back-link lg-hidden">
                <Icon name="ArrowLeft"/>
                <Link text={displayBackLabel} type="back" link={displayBackLink} />
              </div>
            </div>
          </div>
        </div>
      </section>
      {(loader || cardLoading || deleteCardLoading || sourceLoading || defaultLoading) &&
        createPortal(<Loader />, document.body)}
    </>
  );
}
