import SavedPayments from "../saved-payments.hbs";

export default {
  title: "Components/React Component/Saved-Payments",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { SavedPayments };
