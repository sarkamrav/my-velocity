import React from 'react';
import Icon from '../../assests/Icon';
import PropTypes from 'prop-types';

const AlertBanner = ({ type, message }) => {
  return (
    <div className={`alert-banner ${type}`}>
      {type === 'success' && <Icon name="CheckCircle" />}
      {type === 'error' && <Icon name="Cross" />}
      <span className="message">{message}</span>
    </div>
  );
};

AlertBanner.propTypes = {
  type: PropTypes.oneOf(['success', 'error', 'info']).isRequired,
  message: PropTypes.string.isRequired,
};

export default AlertBanner;
