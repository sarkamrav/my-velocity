import React, { useState, useEffect, useMemo } from 'react';
import { useQuery, useLazyQuery, useMutation, ApolloClient } from '@apollo/client';
import LayoutContainer from '../product-list-page/components/layoutcontainer/LayoutContainer';
import StarRating from '../star-rating/StartRating';
import Button from '../micro-components/Button/Button';
import Icon from '../../assests/Icon';
import { createPortal } from 'react-dom';
import Loader from '../micro-components/Loader/Loader';
import AddToCartModal from '../product-information/components/add-to-cart-modal/AddToCartModal';
import ModalPopup from '../modal-popup/ModalPopup';
import GET_PRODUCT from '../../site/js/gql/get-product.gql';
import { ADD_PRODUCTS_TO_CART, CREATE_EMPTY_CART } from '../../site/js/gql/mutations/cart.gql.js';
import useModal from '../../hooks/useModal.jsx';
import { getCookie, setCookie, checkCookie } from '../../utils/cookies_operation.js';
import {
  getUserTokenFromLoaclStorate,
  apolloClientConfigUsingGet,
} from '../../configs/ReactApolloClientSetup/ApolloClientConfig.js'; // Fixed the spelling of 'LocalStorage'
import { findObjectByName } from '../../utils/common.js';
import { applyScanPromoCode } from '../../utils/applyScanPromo.js';

export default function AlternateProduct({ addToCart }) {
  const [configProduct, setConfigProduct] = useState([]);
  const [alternateProduct, setAlternateProduct] = useState('');
  const currencySymbol = JSON.parse(getCookie('currency')).currencySymbol;
  const [cart, setCart] = useState(1);
  const [productUrl, setProductUrl] = useState('');
  const [productSku, setProductSku] = useState('');
  const pageUrl = new URL(window.location.href);
  const urlAttrArray = pageUrl.pathname.split('/');
  const sku = urlAttrArray[urlAttrArray.length - 1];
  const { isShowing: isConfirmationShowing, toggle: toggleConfirmation } = useModal();
  const cartKey = 'cart_id';
  const accessToken = getUserTokenFromLoaclStorate() || '';

  // Product with replacement option - CP2K48G56C46U5
  const gqlClientFotGet = useMemo(() => new ApolloClient(apolloClientConfigUsingGet()), []);
  const { error, loading, data } = useQuery(GET_PRODUCT, {
    client: gqlClientFotGet,
    variables: { SKU: sku, isPdp: false },
  });

  const [getReplacementProduct, { error: alternateError, loading: alternateLoading, data: alternateData }] =
    useLazyQuery(GET_PRODUCT, { client: gqlClientFotGet });

  // Mutation to create an empty cart and then add the alternate product
  // to it with selected quantity
  const [createEmptyCart] = useMutation(CREATE_EMPTY_CART, {
    onCompleted(data) {
      const cartData = JSON.stringify(data.core_createEmptyCart);
      setCookie(cartKey, cartData, 2880);
      addProductToCart({
        variables: {
          cartId: JSON.parse(getCookie(cartKey)),
          SKU: alternateProduct.sku,
          quantity: cart,
        },
      });
    },
  });

  // Mutattion to add product to the cart directly
  const [addProductToCart, { data: addToCartData }] = useMutation(ADD_PRODUCTS_TO_CART, {
    context: {
      headers: {
        authorization: accessToken ? `Bearer ${accessToken}` : '',
      },
    },
    onCompleted() {
      toggleConfirmation();
      //Update miniCart quantity.
      document.querySelector('.cmp-acommerce_cart-qty').innerText =
        Math.floor(document.querySelector('.cmp-acommerce_cart-qty').innerText) + cart;
      // Add product url and sku to the cookie to read on shopping cart and verify order pages
      let productUrlObj = {
        sku: productSku,
        url: productUrl || '',
      };
      let productCookieData = (getCookie('cart_product_urls') && JSON.parse(getCookie('cart_product_urls'))) || [];
      let existingProduct = productCookieData.find(item => item.sku === productSku);
      if (existingProduct) {
        existingProduct.url = productUrl;
      } else {
        productCookieData.push(productUrlObj);
      }
      console.log(productUrlObj);
      setCookie('cart_product_urls', JSON.stringify(productCookieData));
      applyScanPromoCode();
    },
  });

  // When the main product data is received, set the alternate product sku
  useEffect(() => {
    if (data) {
      let sku = data.products[0]?.attributes?.find(
        attribute => attribute?.name === 'replacement_product_option'
      )?.value;
      setProductSku(sku);
    }
  }, [data]);

  // When the alternate product sku is set, get the alternate product details
  useEffect(() => {
    if (productSku !== '') {
      getReplacementProduct({
        variables: {
          SKU: productSku,
          isPdp: false,
        },
      });
    }
  }, [productSku]);

  const increaseCart = () => setCart(cart + 1);
  const decreaseCart = () => cart > 0 && setCart(cart - 1);

  // Set the alternate product to populate the component
  useEffect(() => {
    if (alternateData) {
      const alternates = alternateData?.products?.filter(item => item.stock_status !== 'OUT_OF_STOCK');
      alternates && alternates.length && setAlternateProduct(alternates.products[0]);
    }
  }, [alternateData]);

  // To prepare the product url and append to anchor tags
  useEffect(() => {
    if (alternateProduct !== '') {
      const urlArray = window.location.href.split('/buying-options');
      setProductUrl(urlArray[1]);
    }
  }, [alternateProduct, location.pathname]);

  // Handler to add product to cart
  const handleAddCart = () => {
    //Analytics for add to cart
    if (window.digitalData) {
      digitalData.cart = digitalData.cart || {};
      digitalData.cart.addtocart = digitalData.cart.addtocart || [];
      digitalData.cart.oderOffer = '';
      let prodInfoObject = {
        skuToAdd: alternateProduct.sku,
        qtyNumber: Math.floor(cart),
        prodCategory: window.location.pathname.split('/')[2],
        prodSubCategory: window.location.pathname.split('/')[3],
        prodTitle: alternateProduct.name,
        pagePath: window.location.pathname,
        prodPrice: alternateProduct?.price?.regular?.amount?.value,
        offerPrice: alternateProduct?.price?.regular?.amount?.value,
        currency: alternateProduct?.price?.final?.amount?.currency,
        prodImage: alternateProduct.images[0]?.url,
        cartID: JSON.parse(getCookie(cartKey)),
        loggedIn: localStorage.getItem('user_token') ? true : false,
        configToAdd: undefined,
        modOut: undefined,
        productOfferId: undefined,
        rfgpn: undefined,
      };
      digitalData.cart.addtocart.push({ productInfo: prodInfoObject });
      digitalData.cart.cartId = JSON.parse(getCookie(cartKey));
      if (typeof _satellite !== 'undefined' && _satellite.track) {
        // Fire the Add to Cart Event
        _satellite.track('add_to_cart');
      }
    }
    // const addToCartElement = document.querySelector('.addCart');
    // Check if a cart Id already exists in the cookies
    // If not than create one empty cart to use the id
    if (!checkCookie(cartKey)) {
      createEmptyCart();
    } else {
      addProductToCart({
        variables: {
          cartId: JSON.parse(getCookie(cartKey)),
          SKU: alternateProduct.sku,
          quantity: cart,
        },
      });
    }
  };

  // Handler to redirect to the cart page
  const handleViewCart = () => {
    setShowConfirmPopup(false);
  };

  return (
    <>
      {alternateProduct !== '' ? (
        <LayoutContainer>
          <div className="alternate-product-card">
            <a href={productUrl} className="alternate-product-card__image-link">
              <img loading="lazy" src={alternateProduct.images[0].url} alt="img" />
            </a>
            <div className="alternate-product-card__productinfo">
              <div className="alternate-product-card__productinfo--title">
                <a href={productUrl}>{alternateProduct.name}</a>
              </div>
              <div className="alternate-product-card__productinfo--skuinfo">{alternateProduct.sku.toUpperCase()}</div>
              <div
                className="alternate-product-card__productinfo--productinfo"
                dangerouslySetInnerHTML={{ __html: alternateProduct.shortDescription }}></div>
              <div className="alternate-product-card__productinfo--ratingwrapper">
                <StarRating
                  value={alternateProduct.attributes.find(item => item.name === 'rating_count')?.value || 0}
                  className="alternate-product-card__productinfo--ratings-info"
                />
              </div>
            </div>
            <div className="alternate-product-card__priceinfo">
              <div className="alternate-product-card__activeprice">
                {currencySymbol}
                {alternateProduct?.price?.regular?.amount?.value}
              </div>
              <div className="alternate-product-card__productquantity">
                <div className="input-group">
                  <div className="input-group-button">
                    <button
                      type="button"
                      className="qty-minus"
                      data-quantity="minus"
                      data-field="quantity"
                      onClick={decreaseCart}
                      disabled={cart === 1}>
                      <Icon name="Minus" size="qty-btn" />
                    </button>
                  </div>
                  <input
                    className="qty-input"
                    type="number"
                    name="quantity"
                    id="quantity"
                    value={cart}
                    min="1"
                    max="9"
                    onChange={event => {
                      const value = parseInt(event.target.value);
                      setCart(value > 9 ? 9 : value < 1 ? 1 : value);
                    }}
                  />
                  <div className="input-group-button">
                    <button
                      type="button"
                      className="qty-plus"
                      data-quantity="plus"
                      data-field="quantity"
                      onClick={increaseCart}
                      disabled={cart === 9}>
                      <Icon name="Plus" size="qty-btn" />
                    </button>
                  </div>
                </div>
              </div>
              <Button onClick={handleAddCart}>{addToCart}</Button>
            </div>
          </div>
        </LayoutContainer>
      ) : null}
      {(loading || alternateLoading) && createPortal(<Loader />, document.body)}
      {isConfirmationShowing && (
        <ModalPopup isShowing={isConfirmationShowing} hide={toggleConfirmation}>
          <AddToCartModal
            productImage={alternateProduct.images[0]?.url}
            productName={alternateProduct.name}
            currency={alternateProduct.price?.final?.amount?.currency}
            finalPrice={alternateProduct?.price?.regular?.amount?.value}
            configProduct={configProduct}
            regularPrice={alternateProduct?.price?.regular?.amount?.value}
            viewCart={handleViewCart}
            continueShopping={toggleConfirmation}
            cartQty={cart}
          />
        </ModalPopup>
      )}
    </>
  );
}
