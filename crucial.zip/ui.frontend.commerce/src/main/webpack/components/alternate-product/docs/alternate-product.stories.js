import AlternateProduct from "../alternate-product.hbs";

export default {
  title: "Components/React Component/Alternate Product",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { AlternateProduct };
