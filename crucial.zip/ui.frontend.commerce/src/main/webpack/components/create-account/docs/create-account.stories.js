import CreateAccount from "../create-account.hbs";

export default {
  title: "Components/React Component/Create-Account",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { CreateAccount };
