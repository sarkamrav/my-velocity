import React from "react";
import {gql, useQuery} from '@apollo/client';
import InputField from "../../../inputfield/InputField";

export default function CustomerType({ name }) {
  const CUSTOMER_TYPE = gql`
    query {
      core_customAttributeMetadata(attributes: [{ attribute_code: "customer_type", entity_type: "customer" }]) {
        items {
          attribute_options {
            value
            label
          }
        }
      }
    }
  `;

  const { error, loading, data } = useQuery(CUSTOMER_TYPE);
  let attributes = [{ value: '', label: 'Select customer type*' }];
  let attributesOption = [{options: attributes}];

  if(data) {
    data.core_customAttributeMetadata.items[0].attribute_options.map((option)=>{
      attributes.push({value: option.value, label: option.label});
    });
  }

  return (
    <>
      {
        loading &&
        <InputField
          label="Customer Type:*"
          name="customerType"
          type="select"
          aria-placeholder='Select customer type'
          options={attributesOption}
        />
      }
      {
        data && data.core_customAttributeMetadata.items &&
        <InputField
          label="Customer Type:*"
          name="customerType"
          type="select"
          aria-placeholder='Select customer type'
          options={attributesOption}
        />
      }
    </>
  );
}
