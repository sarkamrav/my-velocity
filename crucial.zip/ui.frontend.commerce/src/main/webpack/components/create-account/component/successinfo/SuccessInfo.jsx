import React from 'react';
import Button from '../../../micro-components/Button/Button';
import { createAttributeString } from '../../../../utils/utils';

function SuccessInfo({ successInfoHandler, caToggleConfirmation }) {
  return (
    <div className="successinfo">
      <p className="successinfo__title">{createAttributeString('caThankyouTitle')}</p>
      {/* <p className='successinfo__description'>Your account has been created.</p> */}
      <span className="successinfo__subtitle">{createAttributeString('caDescriptionTitle')}</span>

      <p className="successinfo__linkwrapper">
        <Button
          type="primary"
          size="small"
          onClick={() => {
            // Check if the page is guest-checkout page then
            // rather than opening the login modal, close the modal
            // to use the login form on page for merge cart and clear cart
            if (window.location.href.includes('guest-checkout')) {
              caToggleConfirmation();
            } else {
              successInfoHandler('login');
            }
          }}>
          {createAttributeString('backToLoginCta')}
        </Button>
        <Button type="primary" size="small" onClick={() => successInfoHandler('create account')}>
          {' '}
          {createAttributeString('registerProductCta')}
        </Button>
        <Button type="primary" size="small" onClick={() => successInfoHandler('shopping')}>
          {createAttributeString('continueShoppingCta')}
        </Button>
      </p>
    </div>
  );
}

export default SuccessInfo;
