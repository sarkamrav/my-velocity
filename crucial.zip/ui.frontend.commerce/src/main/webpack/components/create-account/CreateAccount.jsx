import React, { useState, useEffect } from 'react';
import { Formik, Form, Field, ErrorMessage, useFormikContext } from 'formik';
import InputField from '../inputfield/InputField';
import * as Yup from 'yup';
import Button from '../micro-components/Button/Button';
import { useMutation } from '@apollo/client';
import SuccessInfo from './component/successinfo/SuccessInfo';
import CustomerType from './component/customer-type/CustomerType';
import { CREATE_ACCOUNT } from '../../site/js/gql/mutations/createaccount.gql';
import CUSTOMER_TYPE from '../../site/js/gql/customer-type.gql';
import Checkbox from '../micro-components/Checkbox/Checkbox';
import Dropdown from '../micro-components/Dropdown/Dropdown';
import Loader from '../micro-components/Loader/Loader';
import { useQuery } from '@apollo/client';
import { createAttributeString } from '../../utils/utils';

const CreateAccount = ({
  cancelFormHandler,
  createAccountHandler,
  createAccountCheckboxLabel,
  caToggleConfirmation,
  ...props
}) => {
  // const { values, setFieldValue } = useFormikContext();
  const [submitted, setSubmitted] = useState(false);
  const [dropdownVal, setDropdownVal] = useState([{ options: [{ value: '', label: 'Select customer type' }] }]);
  const [createAccount, { error, loading, data }] = useMutation(CREATE_ACCOUNT);
  const { error: queryError, loading: queryLoading, data: queryData } = useQuery(CUSTOMER_TYPE);

  useEffect(() => {
    if (queryData) {
      const transformedOptions = queryData?.core_customAttributeMetadata?.items[0].attribute_options?.map(option => ({
        value: option.value,
        label: option.label,
      }));

      if (transformedOptions) {
        setDropdownVal(prevState => {
          const newState = [...prevState];
          newState[0].options = [...newState[0].options, ...transformedOptions];
          return newState;
        });
      }
    }
  }, [queryData]);

  const successInfoHandler = event => {
    setSubmitted(!submitted);
    createAccountHandler(event);
  };

  // Form validation schema
  const validationSchema = Yup.object().shape({
    firstName: Yup.string().required('Please enter your first name'),
    lastName: Yup.string().required('Please enter your last name'),
    email: Yup.string().email('Enter a valid email address.').required('Please enter a valid email address'),
    password: Yup.string()
      .required('Please enter a password')
      .min(8, 'Password must be between 8 - 32 characters.')
      .max(32, 'Password must be between 8 - 32 characters.'),
    verifyPassword: Yup.string()
      .oneOf([Yup.ref('password'), null], 'The passwords do not match. Enter matching passwords.')
      .required('Please verify your password'),
    customerType: Yup.string().required('Select a Customer Type *'),
  });

  /* Form submit handler */
  const handleSubmit = async (values, { setSubmitting }) => {
    try {
      console.log('values', values);
      const { firstName, lastName, email, password, customerType, companyName, rememberMe } = values;
      const { data } = await createAccount({
        variables: {
          firstname: firstName,
          lastname: lastName,
          email: email,
          password: password,
          company_name: companyName,
          customer_type: customerType,
          is_subscribed: rememberMe,
        },
      });

      if (data) {
        setSubmitted(true);
      }
    } catch (error) {
      console.error('Error creating account:', error);
    }
  };

  return (
    <>
      {(queryLoading || loading) && <Loader />}
      {!submitted && (
        <Formik
          initialValues={{
            firstName: '',
            lastName: '',
            email: '',
            password: '',
            verifyPassword: '',
            customerType: '',
            companyName: '',
            rememberMe: false,
          }}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}>
          {({ values, errors, touched, isSubmitting }) => (
            <>
              <div className="crucialformcontainer__createaccount">
                <p className="crucialformcontainer__title">{createAttributeString('createAccountTitle')}</p>
                <div
                  className="crucialformcontainer__description"
                  dangerouslySetInnerHTML={{ __html: createAttributeString('createAccountDescription') }}
                />

                {error && <span className="submiterror">{error.message}</span>}
                <Form className="crucialformcontainer__createformwrapper">
                  <div className="crucialformcontainer__createform">
                    <InputField
                      name="firstName"
                      label={createAttributeString('firstNameLabel')}
                      type="text"
                      isMandatory
                    />
                    <InputField
                      name="lastName"
                      label={createAttributeString('lastNameLabel')}
                      type="text"
                      isMandatory
                    />
                    <InputField name="companyName" label={createAttributeString('companyNameLabel')} type="text" />
                    <InputField
                      name="email"
                      label={createAttributeString('emailAddressLabel')}
                      type="email"
                      isMandatory
                    />
                    <InputField
                      name="password"
                      label={createAttributeString('passwordLabel')}
                      type="password"
                      isMandatory
                    />
                    <InputField
                      name="verifyPassword"
                      label={createAttributeString('verifyPasswordLabel')}
                      type="password"
                      isMandatory
                    />
                    <Dropdown
                      className="createaccount-customertype input-field-wrapper"
                      options={dropdownVal}
                      name="customerType"
                      label={createAttributeString('createAccountCustomerTypeLabel')}
                      isMandatory
                    />
                  </div>
                  <Checkbox
                    name="rememberMe"
                    className="createaccount-checkbox"
                    label={createAttributeString('createAccountCheckboxLabel')}
                  />
                  <div className="crucialformcontainer__createaccountcta">
                    <Button>{createAttributeString('createAccountCta')}</Button>
                  </div>
                </Form>
              </div>
            </>
          )}
        </Formik>
      )}
      {submitted && (
        <SuccessInfo successInfoHandler={successInfoHandler} caToggleConfirmation={caToggleConfirmation} {...props} />
      )}
    </>
  );
};

export default CreateAccount;
