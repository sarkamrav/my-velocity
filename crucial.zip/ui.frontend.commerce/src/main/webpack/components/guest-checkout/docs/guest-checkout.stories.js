import GuestCheckout from "../guest-checkout.hbs";

export default {
  title: "Components/React Component/Guest-Checkout",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { GuestCheckout };
