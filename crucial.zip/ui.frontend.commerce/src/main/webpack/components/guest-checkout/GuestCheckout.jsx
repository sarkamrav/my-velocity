import React from 'react';
import GuestLoginForm from './components/guest-loginform/GuestLoginForm';
import GuestNewCustomerForm from './components/guest-newcustomerform/GuestNewCustomerForm';
import OrderSummary from '../checkout-v2/components/order-summary/OrderSummary';

const GuestCheckout = ({ ...restProps }) => {
  // i18n translation variable
  const element = document.querySelector('[data-name="GuestCheckout"]');

  return (
    <div className="contentContainer guest-checkout">
      <div className="guest-checkout__main">
        <div className="guest-checkout__head">
          <h2 className="guest-checkout__heading">{element?.getAttribute('data-checkout')}</h2>
        </div>
        <div className="guest-checkout__Content guest-checkout__ThreePgCheckoutAddressPaymentInfo">
          <div className="guest-checkout__CheckoutPayment">
            <div className="guest-checkout__placeholderFields guest-checkout__billingFields">
              <div className="cmp-acommerce_login_form_main_wrap">
                <GuestLoginForm element={element} />
                <GuestNewCustomerForm element={element} />
              </div>
              <OrderSummary {...restProps} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

GuestCheckout.propTypes = {};

export default GuestCheckout;
