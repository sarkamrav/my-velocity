import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import Button from '../../../micro-components/Button/Button';
import useModal from '../../../../hooks/useModal';
import CreateAccount from '../../../create-account/CreateAccount';
import LoginForm from '../../../login/component/loginform/LoginForm';
import ForgetPassword from '../../../forget-password/ForgetPassword';
import ModalPopup from '../../../modal-popup/ModalPopup';
import { getUserTokenFromLoaclStorate } from '../../../../configs/ReactApolloClientSetup/ApolloClientConfig';
import { getShoppingUrls } from '../../../../site/js/urlresolver';

const GuestNewCustomerForm = ({ element }) => {
  const { isShowing: isLoginConfirmation, toggle: loginToggleConfirmation } = useModal();
  const { isShowing: isCAConfirmation, toggle: caToggleConfirmation } = useModal();
  const { isShowing: isForgetPasswordLogin, toggle: forgetToggleConfirmation } = useModal();
  // const { isShowing: isLoginConfirmation, toggle: loginToggleConfirmation } = useModal();
  const handleGuestCheckout = () => {
    window.location = getShoppingUrls().billingURL;
  };
  const handleUserForm = () => {
    loginToggleConfirmation();
    caToggleConfirmation();
  };

  /* to show forget password screen */
  const forgetPasswordHandler = () => {
    loginToggleConfirmation();
    forgetToggleConfirmation();
  };

  const cancelFormHandler = () => {
    loginToggleConfirmation();
  };

  const createAccountHandler = event => {
    if (event === 'login') {
      caToggleConfirmation();
      loginToggleConfirmation();
    }

    if (event === 'shopping') {
      caToggleConfirmation();
      loginToggleConfirmation();
    }
  };

  useEffect(() => {
    if (getUserTokenFromLoaclStorate()) {
      window.location = getShoppingUrls().billingURL;
    }
  }, []);
  return (
    <>
      <div className="guest-checkout__checkoutTypeContainer">
        <div className="guest-checkout__checkoutType">
          <h4 className="cmp-acommerce_billing-info__form__heading">{element?.getAttribute('data-new-customers')}</h4>
          <p className="cmp-acommerce_billing-info__form__sub-heading">
            {element?.getAttribute('data-create-account-message')}
          </p>
          <div className="guest-checkout__checkoutType-actions">
            <Button className="guest-checkout__create-acc" onClick={caToggleConfirmation}>
              {element?.getAttribute('data-create-account')}
            </Button>
            <span className="guest-checkout__or">{element?.getAttribute('data-or')}</span>
            <Button className="guest-checkout__guest-billing" type="secondary" onClick={handleGuestCheckout}>
              {element?.getAttribute('data-continue')}
            </Button>
          </div>
        </div>
      </div>
      {isLoginConfirmation && (
        <ModalPopup isShowing={isLoginConfirmation} hide={loginToggleConfirmation} className="auth-popup">
          <LoginForm changeFormHandler={handleUserForm} forgetPasswordHandler={forgetPasswordHandler} />
        </ModalPopup>
      )}
      {isCAConfirmation && (
        <ModalPopup className="auth-popup" isShowing={isCAConfirmation} hide={caToggleConfirmation}>
          <CreateAccount
            cancelFormHandler={cancelFormHandler}
            createAccountHandler={createAccountHandler}
            caToggleConfirmation={caToggleConfirmation}
          />
        </ModalPopup>
      )}
      {isForgetPasswordLogin && (
        <ModalPopup isShowing={isForgetPasswordLogin} hide={forgetToggleConfirmation} className="auth-popup">
          <ForgetPassword cancelFormHandler={cancelFormHandler} forgetPasswordHandler={forgetPasswordHandler} />
        </ModalPopup>
      )}
    </>
  );
};

GuestNewCustomerForm.propTypes = {
  onAccountCreation: PropTypes.func.isRequired,
  onCheckoutAsGuest: PropTypes.func.isRequired,
};

export default GuestNewCustomerForm;
