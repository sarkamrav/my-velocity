import React, { useEffect, useState } from 'react';
import { Formik, Form } from 'formik';
import * as Yup from 'yup';
import InputField from '../../../inputfield/InputField';
import Button from '../../../micro-components/Button/Button';
import Link from '../../../micro-components/Link/Link';
import { useMutation } from '@apollo/client';
import { USER_TOKEN } from '../../../../site/js/gql/mutations/UserToken';
import { CLEAR_CART, CREATE_EMPTY_CART } from '../../../../site/js/gql/mutations/cart.gql';
import { getCookie, setCookie } from '../../../../utils/cookies_operation';
import { MERGE_GUEST_CART } from '../../../../site/js/gql/mutations/checkout.gql';
import Loader from '../../../micro-components/Loader/Loader';
import { getShoppingUrls } from '../../../../site/js/urlresolver';
import ModalPopup from '../../../modal-popup/ModalPopup';
import useModal from '../../../../hooks/useModal';
import ForgetPassword from '../../../forget-password/ForgetPassword';

const GuestCheckoutLoginForm = ({ element }) => {
  const [oldCart, setOldCart] = useState('');
  const [showLoader, setShowLoader] = useState(false);
  // Mutation for user login
  const [getToken, { data: tokenData, loading: tokenLoading, error: tokenError }] = useMutation(USER_TOKEN);

  const [createEmptyCart, { data: emptyCartData }] = useMutation(CREATE_EMPTY_CART);

  const [clearCart, { data: clearCartData }] = useMutation(CLEAR_CART);

  const [setMergedCart, { loading: assignmentLoading }] = useMutation(MERGE_GUEST_CART);
  const { isShowing: isForgetPasswordLogin, toggle: forgetToggleConfirmation } = useModal();

  // Define validation schema using Yup
  const validationSchema = Yup.object().shape({
    email: Yup.string()
      .email(element?.getAttribute('data-invalid-email'))
      .required(element?.getAttribute('data-email-required')),
    password: Yup.string().required(element?.getAttribute('data-password-required')),
  });

  useEffect(() => {
    setOldCart(JSON.parse(getCookie('cart_id')));
  }, []);

  /* to show forget password screen */
  const forgetPasswordHandler = e => {
    e && e.preventDefault();
    forgetToggleConfirmation();
  };

  const handleSubmit = async values => {
    try {
      const { email, password } = values;
      await getToken({
        variables: {
          email,
          password,
        },
      });
    } catch (error) {
      console.error('Error creating account:', error);
    }
  };

  useEffect(() => {
    if (tokenData) {
      const tokenJson = {
        ...tokenData.core_generateCustomerToken,
        timeStored: new Date().getTime().toString(),
        ttl: '1080000',
      };
      const tokenString = JSON.stringify(tokenJson);
      localStorage.setItem('user_token', tokenString);
      document.cookie = `user_token=${tokenString}; expires=${new Date(Date.now() + 1080000).toUTCString()}`;

      createEmptyCart({
        context: {
          headers: {
            authorization: `Bearer ${JSON.parse(getCookie('user_token') || '{}').token}`,
          },
        },
      });
    }
  }, [tokenData, createEmptyCart]);

  useEffect(() => {
    if (emptyCartData) {
      clearCart({
        context: {
          headers: {
            authorization: `Bearer ${JSON.parse(getCookie('user_token') || '{}').token}`,
          },
        },
        variables: {
          uid: emptyCartData.core_createEmptyCart,
        },
      });
    }
  }, [emptyCartData, clearCart]);

  useEffect(() => {
    if (clearCartData) {
      setMergedCart({
        context: {
          headers: {
            authorization: `Bearer ${JSON.parse(getCookie('user_token') || '{}').token}`,
          },
        },
        variables: {
          source_cart_id: oldCart,
          destination_cart_id: emptyCartData.core_createEmptyCart,
        },
      }).then(() => {
        window.location = getShoppingUrls().billingURL;
      });
    }
  }, [oldCart, clearCartData, setMergedCart]);

  useEffect(() => {
    if (emptyCartData) {
      setCookie('cart_id', JSON.stringify(emptyCartData.core_createEmptyCart), 2880);
    }
  }, [emptyCartData]);

  useEffect(() => {
    if (tokenLoading || assignmentLoading) {
      setShowLoader(true);
    } else {
      setShowLoader(false);
    }
  }, [tokenLoading, assignmentLoading]);

  return (
    <>
      {showLoader && <Loader />}
      <div className="guest-checkout__loginContainer">
        <fieldset className="guest-checkout__login">
          <h4 className="cmp-acommerce_billing-info__form__heading">{element?.getAttribute('data-account-info')}</h4>
          <p className="cmp-acommerce_billing-info__form__sub-heading">{element?.getAttribute('data-please-login')}</p>
          <div className="guest-checkout__checkoutContainer">
            {/* Wrap the form with Formik */}
            <Formik
              initialValues={{
                email: '',
                password: '',
              }}
              validationSchema={validationSchema}
              onSubmit={values => {
                handleSubmit(values);
              }}>
              <Form>
                <p className="submiterror">{tokenError && tokenError?.message}</p>
                <div className="cmp-acommerce_guest-checkout__row">
                  <div className="cmp-acommerce_guest-checkout__form-group">
                    <InputField name="email" label="Email address" isMandatory type="email" hidden={true} />
                  </div>
                  <div className="cmp-acommerce_guest-checkout__form-group">
                    <InputField name="password" label="Password" isMandatory type="password" hidden={true} />
                  </div>
                  <div className="cmp-acommerce_guest-checkout__form-group">
                    <div className="guest-checkout__checkoutLogin">
                      <Button className="guest-checkout__login">Login</Button>
                      <Link
                        className="forgot-password__link"
                        onClick={e => forgetPasswordHandler(e)}
                        type="default"
                        link="#"
                        text="Forgot Password?"
                      />
                    </div>
                  </div>
                </div>
              </Form>
            </Formik>
          </div>
        </fieldset>
      </div>
      {isForgetPasswordLogin && (
        <ModalPopup isShowing={isForgetPasswordLogin} hide={forgetToggleConfirmation} className="auth-popup">
          <ForgetPassword cancelFormHandler={forgetToggleConfirmation} forgetPasswordHandler={forgetPasswordHandler} />
        </ModalPopup>
      )}
    </>
  );
};

export default GuestCheckoutLoginForm;
