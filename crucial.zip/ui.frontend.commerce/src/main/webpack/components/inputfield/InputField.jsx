import React from 'react';
import PropTypes from 'prop-types';
import TextInput from '../input/TextInput';

import { ErrorMessage, useField } from 'formik';

const InputField = ({ placeholder, label, hidden, type, options, ...props }) => {
  const [field, meta] = useField(props);

  const hasError = meta.touched && meta.error;

  return (
    <div className="input-field-wrapper">
      {type === 'select' ? (
        <select
          className={`form-control formik-input formik-select ${hasError ? 'is-invalid' : 'valid'}`}
          {...field}
          {...props}>
          {options.map(optionGroup =>
            optionGroup.hasOwnProperty('optGroup') ? (
              <optgroup label={optionGroup.optGroup} key={optionGroup.optGroup}>
                {optionGroup.options.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </optgroup>
            ) : (
              optionGroup.options.map(option => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))
            )
          )}
        </select>
      ) : (
        <>
          <TextInput
            type={type}
            label={label}
            placeholder={placeholder}
            field={field}
            name={field.name}
            {...props}
            className={`${hasError ? 'is-invalid' : 'valid'} ${field.value !== '' ? 'is-filled' : ''}`}
          />
        </>
      )}
      <ErrorMessage
        component="div"
        name={field.name}
        className={`form-input-error ${meta.error?.length > 60 ? 'long-error' : ''}`}
      />
    </div>
  );
};

InputField.propTypes = {
  label: PropTypes.string.isRequired,
  hidden: PropTypes.bool,
  type: PropTypes.oneOf(['input', 'select', 'email', 'text', 'password']),
  options: PropTypes.arrayOf(
    PropTypes.shape({
      optGroup: PropTypes.string,
      options: PropTypes.arrayOf(
        PropTypes.shape({
          value: PropTypes.string.isRequired,
          label: PropTypes.string.isRequired,
        })
      ),
    })
  ),
};

InputField.defaultProps = {
  type: 'input',
  hidden: false,
};

export default InputField;
