import React from 'react';
import Address from '../../../Address/Address';
import { formatDateString, formatLocalePrice } from '../../../../utils/utils';
import { getCookie } from '../../../../utils/cookies_operation.js';

const InvoiceInfo = ({
  displayOrderNumber,
  displayOrderDate,
  displayOrderStatus,
  displayBillingAddress,
  displayShippingAddress,
  displayQuantity,
  displayProductName,
  displayProductPrice,
  displayProductExtendedPrice,
  displaySubTotal,
  displayTax,
  displayShipping,
  displayTotal,
  orderDetail,
}) => {
  const itemsList = orderDetail?.invoices[0]?.items;
  const orderTotal = orderDetail?.invoices[0]?.total;
  const currencySymbol = getCookie('currency') && JSON.parse(getCookie('currency'))?.currencySymbol;

  return (
    <div className="cmp-acommerce_invoice-info">
      <ul className="cmp-acommerce_invoice-info__list">
        {orderDetail?.number && (
          <li>
            <strong>{displayOrderNumber} </strong>
            {orderDetail?.number}
          </li>
        )}

        {orderDetail?.order_date && (
          <li>
            <strong>{displayOrderDate} </strong>
            {formatDateString(orderDetail?.order_date)}
          </li>
        )}
        {orderDetail?.status && (
          <li>
            <strong>{displayOrderStatus} </strong>
            {orderDetail?.status}
          </li>
        )}
        <li>
          <div className="cmp-acommerce_invoice-info__address-group">
            <Address title={displayBillingAddress} address={orderDetail?.billing_address} />
            <Address title={displayShippingAddress} address={orderDetail?.shipping_address} />
          </div>
        </li>
      </ul>
      <div className="cmp-acommerce_invoice-info__product-table">
        <div className="cmp-acommerce_invoice-info__product-table__head sm-hidden">
          <div className="product-quantity">
            <strong>{displayQuantity}</strong>
          </div>
          <div className="product-name">
            <strong>{displayProductName}</strong>
          </div>
          <div className="product-price">
            <strong>{displayProductPrice}</strong>
          </div>
          <div className="product-price">
            <strong>{displayProductExtendedPrice}</strong>
          </div>
        </div>
        <div className="cmp-acommerce_invoice-info__product-table__body">
          {itemsList?.map((product, index) => (
            <div className="product-row" key={`${product.quantity}-${index}`}>
              <div className="product-quantity">
                <div className="product-quantity-label lg-hidden">{displayQuantity}</div>
                <div className="product-quantity-value">{product.quantity_invoiced}</div>
              </div>
              <div className="product-name">
                <div className="product-name-label lg-hidden">{displayProductName}</div>
                <div className="product-name-value">
                  <span className="product-title">{product.product_name}</span>
                  <ul className="product-list">
                    <li key={`${product.product_sku}-${index}`}>{product.product_sku.toUpperCase()}</li>
                  </ul>
                </div>
              </div>
              <div className="product-price">
                <div className="product-name-label lg-hidden">{displayProductPrice}</div>
                <div className="product-name-value">
                  <span className="product-title">
                    {formatLocalePrice(product?.product_sale_price?.value, currencySymbol)}
                  </span>
                </div>
              </div>
              <div className="product-price">
                <div className="product-name-label lg-hidden">{displayProductExtendedPrice}</div>
                <div className="product-name-value">
                  <span className="product-title">
                    {formatLocalePrice(product.product_sale_price?.value * product?.quantity_invoiced, currencySymbol)}
                  </span>
                </div>
              </div>
            </div>
          ))}
          <div className="price-row">
            <div className="price-name">{displaySubTotal}</div>
            <div className="price-value">{formatLocalePrice(orderTotal?.subtotal?.value, currencySymbol)}</div>
          </div>
          {orderTotal?.discounts?.map((discount, index) => (
            <div className="price-row" key={discount?.label + index}>
              <div className="price-name">{discount?.label}</div>
              <div className="price-value">-{formatLocalePrice(discount?.amount?.value, currencySymbol)}</div>
            </div>
          ))}
          <div className="price-row">
            <div className="price-name">{displayShipping}</div>
            <div className="price-value">{formatLocalePrice(orderTotal?.total_shipping?.value, currencySymbol)}</div>
          </div>
          <div className="price-row">
            <div className="price-name">{displayTax}</div>
            <div className="price-value">{formatLocalePrice(orderTotal?.total_tax?.value, currencySymbol)}</div>
          </div>
          <div className="price-row">
            <div className="price-name">
              <strong>{displayTotal}</strong>
            </div>
            <div className="price-value">
              <strong>{formatLocalePrice(orderTotal?.grand_total?.value, currencySymbol)}</strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvoiceInfo;
