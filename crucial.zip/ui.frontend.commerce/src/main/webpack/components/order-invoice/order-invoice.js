import React from 'react';
import { createRoot } from 'react-dom/client';
import OrderInvoice from './OrderInvoice.jsx';
import { ApolloClient, ApolloProvider } from '@apollo/client';
import ApolloClientConfig from '../../configs/ReactApolloClientSetup/ApolloClientConfig.js';

export default class {
  static init(el) {
    const client = new ApolloClient(ApolloClientConfig);
    const props = JSON.parse(JSON.stringify(el.dataset));
    createRoot(el).render(
      <ApolloProvider client={client}>
        <OrderInvoice {...props} />
      </ApolloProvider>
    );
  }
}
