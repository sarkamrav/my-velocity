import React, { useState, useEffect } from 'react';
import { useLazyQuery } from '@apollo/client';
import ORDER_INVOICE from '../../site/js/gql/order-invoice.gql';
import Link from '../micro-components/Link/Link';
import Icon from '../../assests/Icon';
import { getShoppingUrls } from '../../site/js/urlresolver';
import InvoiceInfo from './components/InvoiceInfo/InvoiceInfo';
import { createPortal } from 'react-dom';
import Loader from '../micro-components/Loader/Loader';
import ORDER_LOOKUP from '../../site/js/gql/order-lookup.gql';
import GtmDataLayer from '../gtm-data-layer/GtmDataLayer';

export default function OrderDetail({
  displayHeading,
  displayPrint,
  displayBackLabel,
  displayLoadingOrder,
  displayNoOrder,
  displayEmptyOrder,
  ...restProps
}) {
  const userLoggedIn = localStorage.getItem('user_token') ? true : false;
  const orderNumber = new URLSearchParams(window.location.search).get('order_number');
  const params = new URL(window.location.href).search.split('&');
  let email = params.find(param => param.includes('email'));
  email = email?.split('=')[1];

  // Query to get the details for logged in customers
  const [getOrderDetails, { error: queryError, loading: queryLoading, data: queryData }] = useLazyQuery(ORDER_INVOICE, {
    variables: {
      orderNumber,
    },
  });

  // Query to get the details for the guest customers
  const [getOrderLookup, { error: lookUpError, loading: lookUpLoading, data: lookUpData }] = useLazyQuery(
    ORDER_LOOKUP,
    {
      variables: {
        orderNumber,
        email,
      },
    }
  );

  const [orderDetail, setOrderDetail] = useState(null);

  useEffect(() => {
    if (orderNumber) {
      if (userLoggedIn) {
        getOrderDetails();
      } else {
        getOrderLookup();
      }
    }
  }, []);

  useEffect(() => {
    if (queryData) {
      setOrderDetail(queryData?.core_customer?.orders?.items[0]);
    } else {
      setOrderDetail(lookUpData?.core_orderLookup);
    }
  }, [queryData, lookUpData]);

  if (!orderNumber) {
    return (
      <section className="cmp-acommerce_order-invoice-section">
        <div className="custom-container">
          <div className="cmp-acommerce_order-invoice__main">
            <h2 className="cmp-acommerce_order-invoice__heading">{displayHeading} </h2>
            <h4 className="cmp-acommerce_order-invoice__sub-heading">{displayNoOrder}</h4>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="cmp-acommerce_order-invoice-section">
      <div className="custom-container">
        <div className="cmp-acommerce_order-invoice__main">
          {queryLoading || lookUpLoading ? (
            <>
              <h2 className="cmp-acommerce_order-invoice__heading">{displayHeading} </h2>
              <h4 className="cmp-acommerce_order-invoice__sub-heading">{displayLoadingOrder}</h4>
            </>
          ) : queryError || lookUpError ? (
            <>
              <h2 className="cmp-acommerce_order-invoice__heading">{displayHeading} </h2>
              <p className="submiterror">{queryError?.message || lookUpError?.message}</p>
            </>
          ) : queryData?.core_customer?.orders?.items?.length || lookUpData?.core_orderLookup?.items?.length ? (
            <>
              <h2 className="cmp-acommerce_order-invoice__heading">{displayHeading} </h2>
              {queryError || lookUpError ? (
                <p className="submiterror">{queryError?.message || lookUpError?.message}</p>
              ) : (
                <>
                  <div>
                    <span className="cmp-acommerce_order-invoice__print" onClick={() => window.print()}>
                      <Icon name="Printer" />
                      {displayPrint}
                    </span>
                  </div>
                  <InvoiceInfo {...restProps} orderDetail={orderDetail} />
                </>
              )}
            </>
          ) : (
            <>
              <h2 className="cmp-acommerce_order-invoice__heading">{displayHeading} </h2>
              <h4 className="cmp-acommerce_order-invoice__sub-heading">{displayEmptyOrder}</h4>
            </>
          )}
          <p className="back-link">
            <Icon name="ArrowLeft" />
            <Link
              text={displayBackLabel}
              type="back"
              href={`${getShoppingUrls()?.orderDetailURL}?order_number=${orderNumber}`}
              className="cmp-acommerce_order-invoice__link"
            />
          </p>
        </div>
      </div>
      {(queryLoading || lookUpLoading) && createPortal(<Loader />, document.body)}
      <GtmDataLayer basicGtmData='true'/>
    </section>
  );
}
