import Invoice from "../invoice.hbs";

export default {
  title: "Components/React Component/Invoice",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { Invoice };
