import OrderInvoice from "../order-invoice.hbs";

export default {
  title: "Components/React Component/Order-Invoice",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { OrderInvoice };
