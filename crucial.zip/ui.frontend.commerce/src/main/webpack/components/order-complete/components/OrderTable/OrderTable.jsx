import React from 'react';

const OrderTable = ({ products, displayQuantity, displayProductName, printInstruction }) => {
  return (
    <div
      className={`cmp-acommerce_order-complete__product-table printable-section ${
        printInstruction === 'all' ? 'print' : ''
      }`}>
      <div className="cmp-acommerce_order-complete__product-table__head sm-hidden">
        <div className="product-quantity">
          <strong>{displayQuantity}</strong>
        </div>
        <div className="product-name">
          <strong>{displayProductName}</strong>
        </div>
      </div>
      <div className="cmp-acommerce_order-complete__product-table__body">
        {products?.map((product, index) => (
          <div className="product-row" key={`${product?.product_sku}-${index}`}>
            <div className="product-quantity">
              <div className="product-quantity-label lg-hidden">{displayQuantity}</div>
              <div className="product-quantity-value">{product.quantity_ordered}</div>
            </div>
            <div className="product-name">
              <div className="product-name-label lg-hidden">{displayProductName}</div>
              <div className="product-name-value">
                <span className="product-title">{product?.product_name}</span>
                <ul className="product-list">
                  <li>{product?.product_sku.toUpperCase()}</li>
                </ul>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OrderTable;
