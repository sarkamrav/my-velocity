import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { useLazyQuery } from '@apollo/client';
import Loader from '../micro-components/Loader/Loader.jsx';
import OrderTable from './components/OrderTable/OrderTable.jsx';
import ORDER_DETAIL from '../../site/js/gql/order-detail.gql.js';
import ORDER_LOOKUP from '../../site/js/gql/order-lookup.gql.js';
import Icon from '../../assests/Icon.js';
import { getCookie, clearCookie } from '../../utils/cookies_operation.js';
import { getShoppingUrls } from '../../site/js/urlresolver.js';
import { convertDateString, formatLocalePrice } from '../../utils/utils.js';
import GtmDataLayer from '../gtm-data-layer/GtmDataLayer.jsx';

export default function OrderComplete({
  isAuthor,
  displayHeading,
  displayOrderHeading,
  displayOrderPrint,
  displayOrderDate,
  displayOrderNumber,
  displayOrderTotal,
  displayOrderDisclaimer,
  displayQuantity,
  displayProductName,
  displayShippingAddressTitle,
  displayLoadingDetails,
  displayEmptyOrder,
  viewInvoice,
  orderInstructionsHeading,
  continueShopping,
  taxExemptValid,
  paymentHeading,
  printInstructions,
  orderInstructions,
  drPublicKey,
}) {
  const [printInstruction, setPrintInstruction] = useState('');
  const [orderDetails, setOrderDetails] = useState();
  const search = window.location.search;
  const params = new URLSearchParams(search);
  const orderNumber = params.get('order_number');
  const currency = getCookie('currency') && JSON.parse(getCookie('currency'))?.currencySymbol;
  const userLoggedIn = localStorage.getItem('user_token') ? true : false;
  const billingInfo = getCookie('crucialPaymentSource') && JSON.parse(getCookie('crucialPaymentSource'));
  const [loadPayment, setLoadPayment] = useState(false);
  const [shippingInfo, setShippingInfo] = useState([]);
  const [getOrder, { data: orderData, loading: orderLoading, error: orderError }] = useLazyQuery(ORDER_DETAIL);

  const [getOrderLookup, { error: lookUpError, loading: lookUpLoading, data: lookUpData }] = useLazyQuery(ORDER_LOOKUP);

  // Missing billingInfo means direct access to the page which is illogical so redirecting
  if (!billingInfo && isAuthor === undefined) {
    window.location.href = '/';
  }

  useEffect(() => {
    if (orderData) {
      setOrderDetails(orderData?.core_customer?.orders?.items[0]);
    } else {
      setOrderDetails(lookUpData?.core_orderLookup);
    }
  }, [orderData, lookUpData]);

  const handleprint = section => {
    setPrintInstruction(section);
  };

  useEffect(() => {
    if (printInstruction !== '') {
      window.print();
    }
  }, [printInstruction]);

  useEffect(() => {
    clearCookie('cart_id');
    // There are two different calls made for guest/logged in users to get the order details
    // getOrder for Logged in
    // getOrderLookup for Guest - Same is being used on Lookup order page
    if (userLoggedIn) {
      getOrder({
        variables: {
          orderNumber: orderNumber,
        },
      }).then(response => {
        const addressResponse = response?.data?.core_customer?.orders?.items[0]?.shipping_address;
        const formatedAddress = {
          firstname: addressResponse?.firstname,
          lastname: addressResponse?.lastname,
          company: addressResponse?.company || '',
          street: [addressResponse?.street[0], addressResponse?.street[1] || ''],
          city: addressResponse?.city,
          region: addressResponse?.region,
          postcode: addressResponse?.postcode,
          country_code: addressResponse?.country_code,
        };
        setShippingInfo(formatedAddress);
      });
    } else {
      getOrderLookup({
        variables: {
          email: billingInfo && billingInfo?.owner?.email,
          orderNumber: orderNumber,
        },
      }).then(response => {
        const addressResponse = response?.data?.core_orderLookup.shipping_address;
        const formatedAddress = {
          firstname: addressResponse?.firstname,
          lastname: addressResponse?.lastname,
          company: addressResponse?.company || '',
          street: [addressResponse?.street[0], addressResponse?.street[1] || ''],
          city: addressResponse?.city,
          region: addressResponse?.region,
          postcode: addressResponse?.postcode,
          country_code: addressResponse?.country_code,
        };
        setShippingInfo(formatedAddress);
      });
    }

    // Check if the payment method was Wire Transfer and trigger the script to load
    // payment instructions drop in from DR
    if (billingInfo?.type === 'wireTransfer') {
      let script = document.createElement('script');
      script.src = 'https://js.digitalriverws.com/v1/DigitalRiver.js';
      script.type = 'text/javascript';
      script.onload = function () {
        setLoadPayment(true);
      };
      script.onerror = function () {
        console.error('An error occurred while loading the DigitalRiver script.');
      };
      document.head.appendChild(script);
      return () => {
        document.head.removeChild(script);
      };
    }
  }, []);

  // Trigger the payment instructions drop in when payment method is Wire transfer
  useEffect(() => {
    if (loadPayment && billingInfo?.type === 'wireTransfer') {
      let digitalriver = new DigitalRiver(drPublicKey);

      let options = {
        sourceId: billingInfo?.id,
        sourceClientSecret: billingInfo?.clientSecret,
      };

      let delayedPaymentInstructions = digitalriver.createElement('delayedpaymentinstructions', options);
      delayedPaymentInstructions.mount('delayed-payment-container');
    }
  }, [loadPayment]);
  return (
    <>
      <section className="cmp-acommerce_order-complete__section">
        <div className="custom-container print">
          <div className="cmp-acommerce_order-complete__head printable-section print">
            <div className="cmp-acommerce_order-complete__head__heading-group">
              <h2 className="cmp-acommerce_order-complete__heading-main">{displayHeading}</h2>
              <div className="order-print" onClick={() => handleprint('all')}>
                <Icon name="Printer" /> <span>{displayOrderPrint}</span>
              </div>
            </div>
          </div>
          {billingInfo?.type === 'wireTransfer' && (
            <div
              className={`cmp-acommerce_order-complete__payment-instructions printable-section ${
                printInstruction === 'wireTransfer' ? 'print' : ''
              }`}>
              <h4 className="cmp-acommerce_order-complete__heading">{paymentHeading}</h4>
              <div className="order-print" onClick={() => handleprint('wireTransfer')}>
                <Icon name="Printer" /> <span>{printInstructions}</span>
              </div>
              <div id="delayed-payment-container"></div>
            </div>
          )}
          {orderLoading || lookUpLoading ? (
            <h4>{displayLoadingDetails}</h4>
          ) : orderError || lookUpError ? (
            <p className="submiterror printable-section">{orderError?.message || lookUpError?.message}</p>
          ) : orderData?.core_customer?.orders?.items?.length || (lookUpData && Object.keys(lookUpData)?.length) ? (
            <>
              <div
                className={`cmp-acommerce_order-complete__information printable-section ${
                  printInstruction === 'all' ? 'print' : ''
                }`}>
                <h4 className="cmp-acommerce_order-complete__heading">{displayOrderHeading}</h4>
                {(orderError || lookUpError) && (
                  <div className="submiterror">{orderError?.message || lookUpError?.message}</div>
                )}
                <div className="cmp-acommerce_order-complete__order-info">
                  <span>
                    <strong>{displayOrderDate}</strong>
                  </span>{' '}
                  <span>{convertDateString(orderDetails?.order_date)}</span>
                </div>
                <div className="cmp-acommerce_order-complete__order-info">
                  <span>
                    <strong>{displayOrderNumber}</strong>
                  </span>{' '}
                  <span>{orderDetails?.number}</span>
                </div>
                <div className="cmp-acommerce_order-complete__order-info">
                  <span>
                    <strong>{displayOrderTotal}</strong>
                  </span>{' '}
                  <span>{formatLocalePrice(orderDetails?.total?.grand_total?.value, currency)}</span>
                </div>
                <p className="cmp-acommerce_order-complete__sub-heading">{displayOrderDisclaimer}</p>
              </div>
              <OrderTable
                products={orderDetails?.items}
                displayQuantity={displayQuantity}
                displayProductName={displayProductName}
                printInstruction={printInstruction}
              />
              <div
                className={`cmp-acommerce_order-complete__address printable-section ${
                  printInstruction === 'all' ? 'print' : ''
                }`}>
                <Icon name="Truck" />
                <h4 className="cmp-acommerce_order-complete__heading">{displayShippingAddressTitle}</h4>
                <div className="cmp-acommerce_order-complete__address-body">
                  <span className="addrName">
                    {shippingInfo?.firstname} {shippingInfo?.lastname}
                  </span>
                  {shippingInfo?.company && <span className="companyName">{shippingInfo?.company}</span>}
                  <span className="addressLine1">{shippingInfo.street}</span>
                  <span className="location">
                    {shippingInfo?.city}, {shippingInfo?.region} {shippingInfo?.postcode}
                  </span>
                  <span className="country">{shippingInfo.country_code}</span>
                </div>
              </div>
              <div
                className={`cmp-acommerce_order-complete__instructions printable-section ${
                  printInstruction === 'all' ? 'print' : ''
                }`}>
                <Icon name="Notepad" />
                <h4 className="cmp-acommerce_order-complete__heading">{orderInstructionsHeading}</h4>
                <div dangerouslySetInnerHTML={{ __html: orderInstructions }}></div>
              </div>
              <div className="cmp-acommerce_order-complete__actions printable-section">
                {orderDetails?.invoices?.length > 0 && (
                  <a
                    className="cmp-acommerce_order-complete__link"
                    href={`${getShoppingUrls().invoiceURL}?order_number=${orderNumber}${
                      !userLoggedIn && billingInfo ? '&email=' + billingInfo?.owner?.email : ''
                    }`}>
                    {viewInvoice}
                  </a>
                )}
                <a className="cmp-acommerce_order-complete__link" href="/">
                  {continueShopping}
                </a>
              </div>
            </>
          ) : (
            <h4 className="cmp-acommerce_order-invoice__sub-heading printable-section">{displayEmptyOrder}</h4>
          )}
        </div>
      </section>
      {(orderLoading || lookUpLoading) && createPortal(<Loader />, document.body)}
      {orderDetails && <GtmDataLayer orderDetails={orderDetails} />}
    </>
  );
}
