import React, { useEffect, useState } from 'react';
import Icon from '../../../../assests/Icon';
import InputField from '../../../inputfield/InputField';
import Dropdown from '../../../micro-components/Dropdown/Dropdown';
import Button from '../../../micro-components/Button/Button';
import { months, years } from '../../../../utils/common';
import { Formik, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { TAX_EXEMPTION } from '../../../../site/js/gql/mutations/taxExemption.gql';
import { STATE_QUERY } from '../../../../site/js/gql/states.gql';
import { useLazyQuery, useMutation } from '@apollo/client';
import { createPortal } from 'react-dom';
import Loader from '../../../micro-components/Loader/Loader';
import { formatDateToISOString } from '../../../../utils/utils';

const TaxExemption = ({ taxCompanyName, cart_id, locale, setUpdateCart }) => {
  // i18n translation variable
  const element = document.querySelector('[data-name="BillingInfo"]');

  const [showTooltip, setShowTooltip] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showError, setShowError] = useState(false);
  const [taxAuthorities, setTaxAuthorities] = useState([
    {
      options: [{ value: '', label: 'Exemption Certificate Tax Authority*' }],
    },
  ]);

  const taxInitialValues = {
    taxCompanyName: taxCompanyName || '',
    taxAuthority: '',
    startDateMonth: '',
    startDateYear: '',
    expirationDateMonth: '',
    expirationDateYear: '',
    certificate: '',
  };

  const [taxFormdata, setTaxFormdata] = useState(taxInitialValues);

  const getTaxValidationSchema = () => {
    return Yup.object({
      taxCompanyName: Yup.string().required(element?.getAttribute('data-company-required-error')),
      taxAuthority: Yup.string().required(element?.getAttribute('data-authority-required')),
      startDateMonth: Yup.string().required(element?.getAttribute('data-month-required-error')),
      startDateYear: Yup.string().required(element?.getAttribute('data-year-required-error')),
      expirationDateMonth: Yup.string().required(element?.getAttribute('data-month-required-error')),
      expirationDateYear: Yup.string()
        .required(element?.getAttribute('data-year-required-error'))
        .test('is-greater', element?.getAttribute('data-end-date-error'), function (value) {
          const { startDateYear, startDateMonth } = this.parent;
          if (!value || !startDateYear || !startDateMonth) {
            return true; // Skip validation if either field is not set yet
          }

          const startDate = new Date(parseInt(startDateYear), parseInt(startDateMonth) - 1); // Month is zero-based
          const expirationDate = new Date(parseInt(value), parseInt(this.parent.expirationDateMonth) - 1);

          return expirationDate >= startDate;
        })
        .test('not-in-past', element?.getAttribute('data-end-date-earlier-error'), function (value) {
          const { expirationDateMonth } = this.parent;
          if (!value || !expirationDateMonth) {
            return true; // Skip validation if either field is not set yet
          }

          const currentDate = new Date();
          const expirationDate = new Date(parseInt(value), parseInt(expirationDateMonth) - 1);

          return expirationDate >= currentDate;
        }),
      certificate: Yup.mixed()
        .required(element?.getAttribute('data-file-required-error'))
        .test(
          'fileSize',
          element?.getAttribute('data-file-large-error'),
          value => value && value.size <= 1024 * 1024 * 2
        )
        .test(
          'fileType',
          element?.getAttribute('data-file-invalid-error'),
          value => value && ['image/png', 'image/jpg', 'application/pdf'].includes(value.type)
        ),
    });
  };

  const [taxValidationSchema, setTaxValidationSchema] = useState(getTaxValidationSchema());

  const [getAvailableStates, { loading: stateLoading, error: stateError }] = useLazyQuery(STATE_QUERY);

  const getTaxAuthorities = () => {
    getAvailableStates({ variables: { id: locale === 'en_us' ? 'US' : 'CA' } })
      .then(states => {
        if (states.data.core_country.available_regions) {
          const stateArrayOptions = taxAuthorities;
          states.data.core_country.available_regions.forEach(state => {
            stateArrayOptions.forEach(stateOption => {
              stateOption.options.push({
                value: state.code,
                label: state.name,
              });
            });
          });
          setTaxAuthorities(stateArrayOptions);
        }
      })
      .catch(error => console.log(`Server responded with an error - ${error.message}`));
  };

  useEffect(() => {
    getTaxAuthorities();
  }, []);

  // Mutation for tax exemption
  const [getTaxExemption, { loading: taxLoading, error: taxError, data: taxData }] = useMutation(TAX_EXEMPTION);

  const handleTaxExemption = (e, values, validateForm, setTouched, resetForm) => {
    e.preventDefault();
    // Mark all fields as touched
    setTouched({
      taxCompanyName: true,
      taxAuthority: true,
      startDateMonth: true,
      startDateYear: true,
      expirationDateMonth: true,
      expirationDateYear: true,
      certificate: true,
    });

    const fileToBase64 = file => {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();

        reader.onload = () => {
          const base64String = reader.result.split(',')[1];
          resolve(base64String);
        };

        reader.onerror = error => {
          reject(error);
        };

        reader.readAsDataURL(file);
      });
    };

    // Validate the form manually and proceed wth operation only when no error is left
    // Auto validation is not working for some reason
    validateForm().then(async errors => {
      if (Object.keys(errors).length === 0) {
        const {
          taxCompanyName,
          taxAuthority,
          startDateMonth,
          expirationDateMonth,
          startDateYear,
          expirationDateYear,
          certificate,
        } = values;

        let startDate = new Date(Date.UTC(parseInt(startDateYear), parseInt(startDateMonth) - 1, 1, 0, 0, 0, 0));

        let endDate = new Date(
          Date.UTC(parseInt(expirationDateYear), parseInt(expirationDateMonth), 0, 23, 59, 59, 999)
        );

        const base64 = await fileToBase64(certificate);

        getTaxExemption({
          variables: {
            cart_id: cart_id,
            company_name: taxCompanyName,
            tax_authority: taxAuthority,
            start_date: formatDateToISOString(startDate),
            end_date: formatDateToISOString(endDate),
            file: base64,
          },
        })
          .then(data => {
            if (data?.data?.core_import_tax_exempt_certificate?.status) {
              setShowSuccess(true);
              setTaxFormdata(taxInitialValues);
              setUpdateCart(true);
              resetForm();
              setShowError(false);
              setTimeout(() => {
                setShowSuccess(false);
              }, 3500);
            } else {
              setShowSuccess(false);
              setShowError(true);
            }
          })
          .catch(error => console.log('Request failed with this message, ', error?.message));
      }
    });
  };

  const handleCancel = (e, resetForm) => {
    e.preventDefault();
    setTaxFormdata(taxInitialValues);
    resetForm();
  };

  return (
    <>
      <Formik initialValues={taxFormdata} validationSchema={taxValidationSchema} enableReinitialize>
        {({ values, setFieldValue, validateForm, setTouched, resetForm }) => {
          return (
            <Form className="cmp-acommerce_billing-form">
              <div className="tax-exemption">
                <h4 className="cmp-acommerce_billing-info__form__heading">
                  {element?.getAttribute('data-tax-exemption-label')}
                </h4>
                <div className="cmp-acommerce_billing-info__form-group">
                  <InputField
                    name="taxCompanyName"
                    label={element?.getAttribute('data-company-name')}
                    type="text"
                    hidden={true}
                    isMandatory
                  />
                </div>
                <div className="cmp-acommerce_billing-info__form-group tax-authority">
                  <div className="tax-authority">
                    <Dropdown
                      name="taxAuthority"
                      options={taxAuthorities}
                      label={element?.getAttribute('data-tax-exemption-certificate-label')}
                      isMandatory
                    />
                    <button
                      type="button"
                      className="tax-authority__tooltip-button"
                      onClick={() => setShowTooltip(prev => !prev)}>
                      {element?.getAttribute('data-tax-exemption-tooltip-button')}
                      {showTooltip && (
                        <span className="tax-authority__tooltip-info">
                          {element?.getAttribute('data-tax-exemption-tooltip-label')}
                        </span>
                      )}
                    </button>
                  </div>
                  {stateError && <p className="submiterror">{stateError?.message}</p>}
                </div>
                <div className="cmp-acommerce_billing-info__form-group">
                  <div className="cmp-acommerce_dropdown-label">
                    <strong>{element?.getAttribute('data-tax-exemption-start-date')}</strong>
                    <Icon name="Asterisk" className="mandatory_asterisk" />
                  </div>
                  <div className="cmp-acommerce_billing-info__form-group date">
                    <Dropdown name="startDateMonth" options={months} />
                    <Dropdown name="startDateYear" options={years} />
                  </div>
                </div>
                <div className="cmp-acommerce_billing-info__form-group">
                  <div className="cmp-acommerce_dropdown-label">
                    <strong>{element?.getAttribute('data-tax-exemption-expire-date')}</strong>
                    <Icon name="Asterisk" className="mandatory_asterisk" />
                  </div>
                  <div className="cmp-acommerce_billing-info__form-group date">
                    <Dropdown name="expirationDateMonth" options={months} />
                    <Dropdown name="expirationDateYear" options={years} />
                  </div>
                </div>
                <div className="cmp-acommerce_billing-info__form-group certificate">
                  <label className="certificate__label" htmlFor="certificate">
                    {element?.getAttribute('data-tax-exemption-upload-certificate')}
                    <Icon name="Asterisk" className="mandatory_asterisk" />
                  </label>
                  <input
                    type="file"
                    name="certificate"
                    id="certificate"
                    onChange={event => {
                      setFieldValue('certificate', event.currentTarget.files[0]);
                    }}
                  />
                  <span>{element?.getAttribute('data-tax-exemption-support-file')}</span>
                  <ErrorMessage name="certificate" component="div" className="form-input-error" />
                </div>
              </div>
              <div className="cmp-acommerce_billing-info__form-actions">
                <Button onClick={e => handleTaxExemption(e, values, validateForm, setTouched, resetForm)}>
                  {element?.getAttribute('data-tax-exemption-submit')}
                </Button>
                <Button onClick={e => handleCancel(e, resetForm)} className="tax-exemption-cancel">
                  {element?.getAttribute('data-tax-exemption-cancel')}
                </Button>
              </div>
              {showSuccess && (
                <div className="submitsuccess">{element?.getAttribute('data-tax-exemption-success')}</div>
              )}
              {showError && <div className="submiterror">{element?.getAttribute('data-tax-exemption-error')}</div>}
              {taxError && <div className="submiterror">{taxError?.message}</div>}
            </Form>
          );
        }}
      </Formik>
      {(stateLoading || taxLoading) && createPortal(<Loader />, document.body)}
    </>
  );
};

export default TaxExemption;
