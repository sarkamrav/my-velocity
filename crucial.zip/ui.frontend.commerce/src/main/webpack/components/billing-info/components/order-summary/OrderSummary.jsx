import React, { useEffect, useState } from 'react';
import { useQuery } from '@apollo/client';
import GET_CART from '../../../../site/js/gql/get-cart.gql';
import Link from '../../../micro-components/Link/Link';
import Loader from '../../../micro-components/Loader/Loader';
import { getCookie, setCookie } from '../../../../utils/cookies_operation';
import { getShoppingUrls } from '../../../../site/js/urlresolver.js';

export default function OrderSummary({
  updateCart,
  setUpdateCart,
  orderSummary,
  estimatedShipping,
  subTotal,
  dataaddresseditlabel,
}) {
  const [cartInfo, setCartInfo] = useState({});

  // To get cart Data
  const {
    data: cartData,
    loading: cartLoading,
    error: cartError,
    refetch: refetchCart,
  } = useQuery(GET_CART, {
    variables: {
      cart_id: JSON.parse(getCookie('cart_id')),
    },
  });

  useEffect(() => {
    // Refetch the cart
    if (updateCart) {
      refetchCart();
      setUpdateCart(false);
    }
  }, [updateCart]);

  useEffect(() => {
    setCartInfo(cartData);
  }, [cartData]);

  // Destructure data
  const viewCartData = cartInfo?.core_cart || {};
  const { items, prices } = viewCartData;
  const discount = cartInfo?.core_cart?.prices?.discount || {};
  const currencySymbol = getCookie('currency') && JSON.parse(getCookie('currency')).currencySymbol;

  useEffect(() => {
    if (viewCartData?.digital_river?.session_id) {
      setCookie('dropinsid', JSON.stringify(viewCartData?.digital_river?.session_id));
    }
  }, [viewCartData?.digital_river?.session_id]);

  // Cart Error
  if (cartError) {
    console.error('cartError', cartError);
  }

  return (
    <div className="cmp-acommerce_billing-info__side">
      <div className="cmp-acommerce_billing-info__order-summary">
        <div className="cmp-acommerce_billing-info__order-summary__head">
          <span className="order-summary-title">
            <b>{orderSummary}</b>
          </span>
          <Link type="default" href={getShoppingUrls().cartURL} text={dataaddresseditlabel} />
        </div>
        {cartLoading && <Loader />}
        <div className="cmp-acommerce_billing-info__order-summary__body">
          <div className="cmp-acommerce_billing-info__order-summary__product">
            {items?.map((item, index) => {
              return (
                <div className="cmp-acommerce_billing-info__order-summary__row" key={index}>
                  <span>{item.quantity}</span>
                  <span className="product-image">
                    <img loading="lazy" src={item.product.image.url} alt={item.product.image.label} />
                  </span>
                  <span className="product-name">{item.product.name}</span>
                  <span>
                    <b>
                      {currencySymbol}
                      {item.prices.row_total.value}
                    </b>
                  </span>
                </div>
              );
            })}
          </div>
          {discount.amount !== undefined && (
            <div className="cmp-acommerce_billing-info__order-summary__row">
              <div className="discount-container">
                <div className="discount_title">Discount</div>
              </div>
              <div className="discount-value-container">
                <div className="discount_value">
                  {'-'}
                  {currencySymbol}
                  {Math.abs(parseInt(discount?.amount?.value))}
                </div>
              </div>
            </div>
          )}
          <div className="cmp-acommerce_billing-info__order-summary__row">
            <span>{estimatedShipping}</span>
            <span>$0.00</span>
          </div>
          <div className="cmp-acommerce_billing-info__order-summary__row">
            <span className="order-summary-title">
              <b>{subTotal}</b>
            </span>
            <span className="order-summary-title">
              <b>
                {currencySymbol}
                {prices?.grand_total.value}
              </b>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
