import React, { useEffect, useState, useMemo } from 'react';
import { useLazyQuery, useMutation, useQuery } from '@apollo/client';
import { Formik, Form } from 'formik';
import * as Yup from 'yup';
import StepNavigator from '../micro-components/step-navigator/StepNavigator';
import InputField from '../inputfield/InputField';
import Link from '../micro-components/Link/Link';
import Dropdown from '../micro-components/Dropdown/Dropdown';
import Checkbox from '../micro-components/Checkbox/Checkbox';
import Radio from '../micro-components/Radio/Radio';
import Icon from '../../assests/Icon';
import { COUNTRY_QUERY } from '../../site/js/gql/countries.gql';
import { STATE_QUERY } from '../../site/js/gql/states.gql';
import { getCookie, setCookie } from '../../utils/cookies_operation';
import {
  ASSIGN_EMAIL_GUEST,
  SET_BILLING_ADDRESS_FOR_DIFFERENT_ADDRESS,
  SET_BILLING_ADDRESS_FOR_SAME_ADDRESS,
} from '../../site/js/gql/mutations/checkout.gql';
import { GET_ADDRESS } from '../../site/js/gql/get-address.gql';
import OrderSummary from './components/order-summary/OrderSummary';
import Loader from '../micro-components/Loader/Loader';
import { UPDATE_QUOTE_FIELD } from '../../site/js/gql/mutations/updateQuoteField.gql';
import { SET_PAYMENT_METHOD_TO_CART } from '../../site/js/gql/mutations/set-payment-method-to-cart.gql';
import Button from '../micro-components/Button/Button';
import { getShoppingUrls } from '../../site/js/urlresolver';
import { createPortal } from 'react-dom';
import TaxExemption from './components/TaxExemption/TaxExemption';
import {
  getCatalogServiceHeaders,
  getUserTokenFromLoaclStorate,
  clientConfigUsingGet,
} from '../../configs/ReactApolloClientSetup/ApolloClientConfig';
import CUSTOMER_CART_INFO from '../../site/js/gql/customer-cart-info.gql';

export default function BillingInfo({ loginForTax }) {
  // i18n translation variable
  const element = document.querySelector('[data-name="BillingInfo"]');

  // State variables to manage various UI states
  const [taxExemption, setTaxExemption] = useState(false);
  const [shippingAddressForm, setShippingAddressForm] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isBusinessPurchased, setIsBusinessPurchased] = useState(false);
  const [selectedBillingAddress, setSelectedBillingAddress] = useState(null);
  const [selectedShippingAddress, setSelectedShippingAddress] = useState(null);
  const [customerAddress, setCustomerAddress] = useState({});
  const cart_id = getCookie('cart_id') && JSON.parse(getCookie('cart_id'));
  const [billingObject, setBillingObject] = useState({});
  const locale = getCatalogServiceHeaders();

  // Initial options for dropdowns
  const initialOptions = [
    {
      options: [
        {
          value: '',
          label: element?.getAttribute('data-select-one'),
        },
      ],
    },
  ];

  const initialStates = [
    {
      options: [
        {
          value: '',
          label: element?.getAttribute('data-not-applicable'),
        },
      ],
    },
  ];

  const initialAddress = [
    {
      options: [
        {
          value: '',
          label: 'New Address',
        },
      ],
    },
  ];

  // Special packaging options
  const specialPackageOption = [
    {
      label: 'Standard packaging / no preference',
      value: 'standard',
    },
    {
      label: 'Single clamshell package',
      value: 'clamshell',
    },
  ];

  // Initial form values
  const initialValues = {
    differentAddress: false,
    billingAddress: '',
    purchase: 'individual',
    firstName: '',
    lastName: '',
    addressLine1: '',
    addressLine2: '',
    city: '',
    state: '',
    postalCode: '',
    country: '',
    telephone: '',
    additionalInfo: false,
    companyName: '',
    shippingAddress: '',
    shippingFirstName: '',
    shippingLastName: '',
    shippingAddressLine1: '',
    shippingAddressLine2: '',
    shippingCity: '',
    shippingState: '',
    shippingZipCode: '',
    shippingCountry: '',
    shippingPhoneNumber: '',
    shippingCompanyName: '',
    po_number: '',
    pack_count_tray: 'standard',
    opt_in: false,
    email: '',
    verifyemail: '',
  };

  // Steps
  const steps = [
    {
      title: element?.getAttribute('data-step-billing-label'),
    },
    {
      title: element?.getAttribute('data-step-verify-label'),
    },
    {
      title: element?.getAttribute('data-step-order-complete-label'),
    },
  ];

  // Purchase
  const purchases = [
    {
      label: element?.getAttribute('data-step-order-type-personal'),
      value: 'individual',
    },
    {
      label: element?.getAttribute('data-step-order-type-bussiness'),
      value: 'business',
    },
  ];

  // Is logged
  // Effect to check if the user is logged in
  useEffect(() => {
    if (getUserTokenFromLoaclStorate()) {
      setIsLoggedIn(true);
    } else {
      setIsLoggedIn(false);
    }
  }, []);

  // State variables to manage dynamic data
  const [countries, setCountries] = useState(initialOptions);
  const [states, setStates] = useState(initialStates);
  const [shippingStates, setShippingStates] = useState(initialStates);
  const [selectedCountry, setSelectedCountry] = useState('');
  const [selectedShippingCountry, setSelectedShippingCountry] = useState('');
  const [formData, setFormData] = useState(initialValues);
  const [addressOptions, setAddressOptions] = useState(initialAddress);
  const [taxAuthorities, setTaxAuthorities] = useState([
    {
      options: [{ value: '', label: 'Exemption Certificate Tax Authority*' }],
    },
  ]);
  const [updateCart, setUpdateCart] = useState(false);

  // Function to generate validation schema dynamically
  const getValidationSchema = () => {
    return Yup.object({
      billingAddress: Yup.string(),
      differentAddress: Yup.bool(),
      purchase: Yup.string().required(element?.getAttribute('data-purchase-required-error')),
      firstName: Yup.string().required(element?.getAttribute('data-firstname-required-error')),
      lastName: Yup.string().required(element?.getAttribute('data-lastname-required-error')),
      addressLine1: Yup.string()
        .required(element?.getAttribute('data-address-line1-required-error'))
        .test('no-po-box', element?.getAttribute('data-po-box-error'), value => !/P\.?\s?O\.?\s?Box/i.test(value)),
      addressLine2: Yup.string().test(
        'no-po-box',
        element?.getAttribute('data-po-box-error'),
        value => !/P\.?\s?O\.?\s?Box/i.test(value)
      ),
      city: Yup.string().required(element?.getAttribute('data-city-required-error')),
      state: Yup.string().required(element?.getAttribute('data-state-required-error')),
      postalCode: Yup.string().required(element?.getAttribute('data-zipcode-required-error')),
      country: Yup.string().required(element?.getAttribute('data-country-required-error')),
      ...(!isLoggedIn && {
        email: Yup.string()
          .email(element?.getAttribute('data-email-invalid-error'))
          .required(element?.getAttribute('data-email-required-error')),
        verifyemail: Yup.string()
          .oneOf([Yup.ref('email'), null], element?.getAttribute('data-email-unmatch-error'))
          .required(element?.getAttribute('data-verify-email-required-error')),
      }),
      ...(isBusinessPurchased && {
        companyName: Yup.string().required(element?.getAttribute('data-company-required-error')),
      }),
      ...(!taxExemption && {
        companyName: Yup.string(),
      }),
      ...(shippingAddressForm && {
        shippingAddress: Yup.string(),
        shippingFirstName: Yup.string().required(element?.getAttribute('data-firstname-required-error')),
        shippingLastName: Yup.string().required(element?.getAttribute('data-lastname-required-error')),
        shippingAddressLine1: Yup.string().required(element?.getAttribute('data-address-line1-required-error')),
        shippingAddressLine2: Yup.string(),
        shippingCity: Yup.string().required(element?.getAttribute('data-city-required-error')),
        shippingState: Yup.string().required(element?.getAttribute('data-state-required-error')),
        shippingZipCode: Yup.string().required(element?.getAttribute('data-zipcode-required-error')),
        shippingCountry: Yup.string().required(element?.getAttribute('data-country-required-error')),
        shippingCompanyName: Yup.string(),
        shippingPhoneNumber: Yup.string().required(element?.getAttribute('data-phone-number-required-error')),
      }),
      telephone: Yup.string().required(element?.getAttribute('data-phone-number-required-error')),
      additionalInfo: Yup.bool(),
      ...(isLoggedIn &&
        isBusinessPurchased && {
          pack_count_tray: Yup.string().required(element?.getAttribute('data-package-option-required')),
        }),
    });
  };

  const [validationSchema, setValidationSchema] = useState(getValidationSchema());

  // Queries and mutations
  const gqlClientFotGet = useMemo(() => clientConfigUsingGet(), []);
  const { data: countryData, error: countryError } = useQuery(COUNTRY_QUERY, { client: gqlClientFotGet });
  const [getAvailableStates, { loading: stateLoading, error: stateError }] = useLazyQuery(STATE_QUERY);
  const { data: customerAddressData } = useQuery(GET_ADDRESS);
  const [
    setBillingAddressForSameAddress,
    { error: billingAddressError, loading: billingAddressLoading, data: billingAddressData },
  ] = useMutation(SET_BILLING_ADDRESS_FOR_SAME_ADDRESS);
  const [setBillingAddressForDifferentAddress, { loading: shippingAddressLoading }] = useMutation(
    SET_BILLING_ADDRESS_FOR_DIFFERENT_ADDRESS
  );

  const [updateQuoteField, { data: updateQuoteData }] = useMutation(UPDATE_QUOTE_FIELD);

  //Mutation for Add email to guest
  const [setGuestEmailOnCart, { data: guestEmailData, loading: guestEmailLoading }] = useMutation(ASSIGN_EMAIL_GUEST);

  // Query for customer cart
  const [getCustomerEmail, { data: customerCart }] = useLazyQuery(CUSTOMER_CART_INFO, {
    context: {
      headers: {
        Authorization: `Bearer ${getCookie('user_token') && JSON.parse(getCookie('user_token')).token}`,
      },
    },
  });

  useEffect(() => {
    if (guestEmailData) {
      setCookie('dropinsid', JSON.stringify(guestEmailData?.core_setGuestEmailOnCart?.cart?.digital_river?.session_id));
    }
    if (billingAddressData) {
      setCookie(
        'dropinsid',
        JSON.stringify(billingAddressData?.core_setBillingAddressOnCart?.cart?.digital_river?.session_id)
      );
    }
    if (customerCart) {
      setCookie('dropinsid', JSON.stringify(customerCart?.core_customerCart?.digital_river?.session_id));
    }
  }, [guestEmailData, billingAddressData, customerCart]);

  // Scroll Payment section on submit
  useEffect(() => {
    if (updateQuoteData) {
      window.scrollTo({
        top: document.querySelector(`.cmp-acommerce_payment_main_wrap`).offsetTop - 120,
        behavior: 'smooth',
      });
    }
  }, [updateQuoteData]);

  // Error Handling
  if (countryError || stateError || billingAddressError) {
    console.error('Error:', countryError?.message, stateError?.message, billingAddressError?.message);
  }

  // Effect to populate saved addresses
  useEffect(() => {
    if (customerAddressData) {
      setCustomerAddress(customerAddressData.core_customer.addresses);
      let addressArrayOptions = initialAddress;
      customerAddressData?.core_customer?.addresses?.forEach(item => {
        const getValueByAttributeCode = attributeCode => {
          const attribute = item?.custom_attributes?.find(attr => attr.attribute_code === attributeCode);
          return attribute ? attribute.value : '';
        };
        const nickName = getValueByAttributeCode('nick_name');
        addressArrayOptions.forEach(addressOption => {
          addressOption.options.push({
            value: item.id,
            label: nickName ? nickName : item?.street[0],
          });
        });
      });
      setAddressOptions(addressArrayOptions);
    }
  }, [customerAddressData]);

  // Function to find address by ID
  const findAddressById = id => {
    return customerAddress.find(address => address.id === id);
  };

  // Effect to update validation schema when shipping address form changes
  useEffect(() => {
    setValidationSchema(getValidationSchema());
  }, [shippingAddressForm, isLoggedIn, isBusinessPurchased, taxExemption]);

  // Effect to populate countries from API
  useEffect(() => {
    if (countryData) {
      let countriesArrayOptions = initialOptions;
      countryData.core_countries.forEach(item => {
        countriesArrayOptions.forEach(countriesOptions => {
          countriesOptions.options.push({
            value: item.id,
            label: item.full_name_locale,
          });
        });
      });
      setCountries(countriesArrayOptions);
    }
  }, [countryData]);

  // Effect to get states when a country is selected
  useEffect(() => {
    if (selectedCountry) {
      getAvailableStates({ variables: { id: selectedCountry } })
        .then(states => {
          if (states.data.core_country.available_regions) {
            const stateArrayOptions = initialOptions;
            states.data.core_country.available_regions.forEach(state => {
              stateArrayOptions.forEach(stateOption => {
                stateOption.options.push({
                  value: state.code,
                  label: state.name,
                });
              });
            });
            setStates(stateArrayOptions);
          } else {
            setStates(initialStates);
          }
        })
        .catch(error => console.log(`Server responded with an error - ${error.message}`));
    } else {
      setStates(initialStates);
    }
  }, [selectedCountry]);

  // Effect to get shipping states when a country is selected
  useEffect(() => {
    if (selectedShippingCountry) {
      getAvailableStates({ variables: { id: selectedShippingCountry } })
        .then(states => {
          if (states.data.core_country.available_regions) {
            const stateArrayOptions = initialOptions;
            states.data.core_country.available_regions.forEach(state => {
              stateArrayOptions.forEach(stateOption => {
                stateOption.options.push({
                  value: state.code,
                  label: state.name,
                });
              });
            });
            setShippingStates(stateArrayOptions);
          } else {
            setShippingStates(initialStates);
          }
        })
        .catch(error => console.log(`Server responded with an error - ${error.message}`));
    } else {
      setStates(initialStates);
    }
  }, [selectedShippingCountry]);

  // Effect to get states when billing address is selected
  useEffect(() => {
    if (selectedBillingAddress) {
      getAvailableStates({ variables: { id: selectedBillingAddress.country_code } })
        .then(states => {
          if (states.data.core_country.available_regions) {
            const stateArrayOptions = initialStates;
            states.data.core_country.available_regions.forEach(state => {
              stateArrayOptions.forEach(stateOption => {
                stateOption.options.push({
                  value: state.code,
                  label: state.name,
                });
              });
            });
            setStates(stateArrayOptions);
            setFormData(prev => ({
              ...prev,
              country: selectedBillingAddress.country_code,
              state: selectedBillingAddress.region.region_code,
              city: selectedBillingAddress.city,
              firstName: selectedBillingAddress.firstname,
              lastName: selectedBillingAddress.lastname,
              addressLine1: selectedBillingAddress.street[0],
              addressLine2: selectedBillingAddress.street[1],
              postalCode: selectedBillingAddress.postcode,
              companyName: selectedBillingAddress.company || '',
              taxCompanyName: selectedBillingAddress.company || '',
              telephone: selectedBillingAddress.telephone,
              billingAddress: selectedBillingAddress.id,
            }));
          } else {
            setStates(initialStates);
          }
        })
        .catch(error => console.log(`Server responded with an error - ${error.message}`));
    }

    if (selectedShippingAddress) {
      getAvailableStates({ variables: { id: selectedShippingAddress.country_code } })
        .then(states => {
          if (states.data.core_country.available_regions) {
            const stateArrayOptions = initialStates;
            states.data.core_country.available_regions.forEach(state => {
              stateArrayOptions.forEach(stateOption => {
                stateOption.options.push({
                  value: state.code,
                  label: state.name,
                });
              });
            });
            setShippingStates(stateArrayOptions);
            setFormData(prev => ({
              ...prev,
              shippingCountry: selectedShippingAddress.country_code,
              shippingState: selectedShippingAddress.region.region_code,
              shippingCity: selectedShippingAddress.city,
              shippingFirstName: selectedShippingAddress.firstname,
              shippingLastName: selectedShippingAddress.lastname,
              shippingAddressLine1: selectedShippingAddress.street[0],
              shippingAddressLine2: selectedShippingAddress.street[1],
              shippingPostalCode: selectedShippingAddress.postcode,
              shippingCompanyName: selectedShippingAddress.company || '',
              shippingTelephone: selectedShippingAddress.telephone,
              shippingBillingAddress: selectedShippingAddress.id,
            }));
          } else {
            setShippingStates(initialStates);
          }
        })
        .catch(error => console.log(`Server responded with an error - ${error.message}`));
    }
  }, [selectedBillingAddress, selectedShippingAddress]);

  // Handle Form Submit
  const handleSubmit = async values => {
    if (!isLoggedIn) {
      await setGuestEmailOnCart({
        variables: {
          cart_id: cart_id,
          email: values.email,
        },
      });
    } else {
      await getCustomerEmail();
    }
    const streetAddressValues = [values.addressLine1];
    if (values.addressLine2) {
      streetAddressValues.push(values.addressLine2);
    }
    const commonAddress = {
      firstName: values.firstName,
      lastName: values.lastName,
      company: values.company,
      streetAddress: streetAddressValues,
      city: values.city,
      region: values.state,
      postalCode: values.postalCode,
      country: values.country,
      telephone: values.telephone,
    };

    try {
      if (!values.differentAddress) {
        await setBillingAddressForSameAddress({
          variables: {
            cart_id: cart_id,
            ...commonAddress,
            use_for_shipping: !values.differentAddress,
          },
        });
        await updateQuoteField({
          variables: {
            cart_id: cart_id,
            order_type: values.purchase,
            po_number: values.po_number,
            pack_count_tray: values.pack_count_tray,
            opt_in: values.opt_in,
          },
        });
      } else {
        await setBillingAddressForSameAddress({
          variables: {
            cart_id: cart_id,
            ...commonAddress,
            use_for_shipping: false,
          },
        });

        const shippingStreetAddressValues = [values.shippingAddressLine1];
        if (values.shippingAddressLine2) {
          shippingStreetAddressValues.push(values.shippingAddressLine2);
        }
        const shippingAddress = {
          shippingFirstName: values.shippingFirstName,
          shippingLastName: values.shippingLastName,
          shippingCompany: values.shippingCompanyName,
          shippingStreetAddress: shippingStreetAddressValues,
          shippingCity: values.shippingCity,
          shippingRegion: values.shippingState,
          shippingPostalCode: values.shippingZipCode,
          shippingCountry: values.shippingCountry,
          shippingTelephone: values.shippingPhoneNumber,
          shippingSaveInAddressBook: true,
        };

        await setBillingAddressForDifferentAddress({
          variables: {
            cart_id: cart_id,
            ...shippingAddress,
          },
        });

        await updateQuoteField({
          variables: {
            cart_id: cart_id,
            order_type: values.purchase,
            po_number: values.po_number,
            pack_count_tray: values.pack_count_tray,
            opt_in: values.opt_in,
          },
        });
      }
    } catch (error) {
      console.error('Something went wrong', error);
    }
  };

  // Effect for setting billing Address
  const [billingAddressResponse, setBillingAddressResponse] = useState({});
  useEffect(() => {
    if (billingAddressData) {
      const billingResponse = billingAddressData?.core_setBillingAddressOnCart?.cart?.billing_address;
      setBillingAddressResponse(billingResponse);
      setShowPaymentMethod(true);
    }
    if (guestEmailData) {
      const guestEmailResponse = guestEmailData?.core_setGuestEmailOnCart?.cart?.email;
      setBillingAddressResponse(prevResponse => ({
        ...prevResponse,
        email: guestEmailResponse,
      }));
    }
    if (customerCart) {
      const customerEmailResponse = customerCart?.core_customerCart?.email;
      setBillingAddressResponse(prevResponse => ({
        ...prevResponse,
        email: customerEmailResponse,
      }));
    }
  }, [billingAddressData, guestEmailData, customerCart]);

  // Payment method setup
  const [setPaymentMethodOnCart] = useMutation(SET_PAYMENT_METHOD_TO_CART, {
    onCompleted: () => {
      setCookie('crucialPaymentSource', JSON.stringify(billingObject));
      window.location = getShoppingUrls().orderVerifyURL;
    },
  });

  // Digital River Payment Integration
  const [showPaymentMethod, setShowPaymentMethod] = useState(false);
  useEffect(() => {
    if (showPaymentMethod) {
      const script = document.createElement('script');
      script.src = 'https://js.digitalriverws.com/v1/DigitalRiver.js';
      script.async = true;
      script.onload = () => {
        const digitalriverpayments = new DigitalRiver('pk_test_cfec641a625845029e124c5b0866ffc5', {
          locale: 'en-GB',
        });
        const { firstname, lastname, email, telephone, street, city, region, postcode, country } =
          billingAddressResponse;
        const configuration = {
          sessionId: getCookie('dropinsid') && JSON.parse(getCookie('dropinsid')),
          billingAddress: {
            firstName: firstname,
            lastName: lastname,
            email: email || getCookie('user_email'),
            phoneNumber: telephone,
            address: {
              line1: street?.[0],
              line2: street?.[1],
              city: city,
              state: region.code,
              postalCode: postcode,
              country: country.code,
            },
          },
          options: {
            flow: 'checkout',
            button: {
              type: 'custom',
              buttonText: 'continue',
            },
            redirect: {
              disableAutomaticRedirects: true,
              returnUrl: window.location.href,
              cancelUrl: window.location.href,
            },
            showComplianceSection: true,
            showSavePaymentAgreement: true,
            showTermsOfSaleDisclosure: true,
          },
          onSuccess: function (data) {
            setBillingObject({
              ...data.source,
              page_source: 'billing',
            });
            setPaymentMethodOnCart({
              variables: {
                code: 'dr_drop_in_payment',
                cart_id: cart_id,
                additional_data: JSON.stringify(data.source),
                source_id: data.source.id,
              },
            });
          },
          onError: function (data) {
            console.log('Dropin Error', data);
          },
        };
        const dropin = digitalriverpayments.createDropin(configuration);
        dropin.mount('cmp-acommerce_drop-in-payment-wrapper');
      };

      document.body.appendChild(script);

      return () => {
        document.body.removeChild(script);
      };
    }
  }, [showPaymentMethod, guestEmailData]);

  // Adding Digital River CSS
  useEffect(() => {
    const link = document.createElement('link');
    link.href = 'https://js.digitalriverws.com/v1/css/DigitalRiver.css';
    link.rel = 'stylesheet';
    link.type = 'text/css';
    document.head.appendChild(link);

    return () => {
      document.head.removeChild(link);
    };
  }, []);

  const [showLoader, setShowLoader] = useState(false);

  useEffect(() => {
    if (guestEmailLoading || stateLoading || billingAddressLoading || shippingAddressLoading) {
      setShowLoader(true);
    } else {
      setShowLoader(false);
    }
  }, [guestEmailLoading, stateLoading, billingAddressLoading, shippingAddressLoading]);

  return (
    <>
      <div className="cmp-acommerce_billing-info__section">
        <div className="custom-container">
          <div className="cmp-acommerce_billing-info__head">
            <h2 className="cmp-acommerce_billing-info__heading">{element?.getAttribute('data-heading')}</h2>
            <StepNavigator steps={steps} type="secondary" activeStep={Number(0)} />
          </div>
          <div className="cmp-acommerce_billing-info__body">
            <div className="cmp-acommerce_billing-info__main">
              <div className="cmp-acommerce_billing-info__form">
                <div className="cmp-acommerce_billing-info__form__details">
                  <h4 className="cmp-acommerce_billing-info__form__heading">
                    {element?.getAttribute('data-form-heading')}
                  </h4>
                  <p className="cmp-acommerce_billing-info__form__sub-heading">
                    {element?.getAttribute('data-sub-heading')}
                    <b>{element?.getAttribute('data-sub-address')}</b>
                    <br />
                    <br />
                    <Icon className="mandatory_asterisk" name="Asterisk" />
                    {element?.getAttribute('data-asterisk-label')} (
                    <Icon className="mandatory_asterisk" name="Asterisk" />){' '}
                    {element?.getAttribute('data-asterisk-required-label')}
                  </p>
                </div>
                <Formik
                  initialValues={formData}
                  validationSchema={validationSchema}
                  onSubmit={handleSubmit}
                  enableReinitialize>
                  {({ values, setFieldValue }) => {
                    useEffect(() => {
                      values.differentAddress ? setShippingAddressForm(true) : setShippingAddressForm(false);
                    }, [values]);

                    useEffect(() => {
                      if (values.country) {
                        setSelectedCountry(values.country);
                        setFieldValue('state', '');
                      } else {
                        setSelectedCountry('');
                        setFieldValue('state', '');
                        setFieldValue('country', '');
                      }
                    }, [values.country]);

                    useEffect(() => {
                      if (values.shippingCountry) {
                        setSelectedShippingCountry(values.shippingCountry);
                        setFieldValue('shippingState', '');
                      } else {
                        setSelectedShippingCountry('');
                        setFieldValue('shippingState', '');
                        setFieldValue('shippingCountry', '');
                      }
                    }, [values.shippingCountry]);

                    useEffect(() => {
                      if (values.billingAddress) {
                        setSelectedBillingAddress(findAddressById(values.billingAddress));
                      }
                      if (values.shippingAddress) {
                        setSelectedShippingAddress(findAddressById(values.shippingAddress));
                      }
                    }, [values.billingAddress, values.shippingAddress]);

                    useEffect(() => {
                      if (values.purchase === 'business') {
                        setIsBusinessPurchased(true);
                      } else {
                        setIsBusinessPurchased(false);
                      }
                    }, [values.purchase]);

                    return (
                      <Form className="cmp-acommerce_billing-form">
                        <Checkbox
                          name="differentAddress"
                          label={element?.getAttribute('data-address-label')}
                          className="cmp-acommerce_billing-info__form-checkbox"
                        />
                        {isLoggedIn && (
                          <div className="cmp-acommerce_billing-info__form-group address">
                            <h4>
                              {element?.getAttribute('data-address-heading')}
                              <span className="address-link">
                                (<Link type="default" link="#" text="Edit" />)
                              </span>
                            </h4>
                            <Dropdown options={addressOptions && addressOptions} name="billingAddress" />
                          </div>
                        )}
                        <div className="cmp-acommerce_billing-info__form-group order-type">
                          <Radio
                            options={purchases}
                            label={element?.getAttribute('data-order-type-label')}
                            isMandatory
                            name="purchase"
                          />
                        </div>
                        <div className="cmp-acommerce_billing-info__form-group">
                          <InputField
                            name="firstName"
                            label={element?.getAttribute('data-first-name-label')}
                            type="text"
                            isMandatory
                            hidden={true}
                          />
                        </div>
                        <div className="cmp-acommerce_billing-info__form-group">
                          <InputField
                            name="lastName"
                            label={element?.getAttribute('data-last-name-label')}
                            type="text"
                            isMandatory
                            hidden={true}
                          />
                        </div>
                        <div className="cmp-acommerce_billing-info__form-group">
                          <InputField
                            name="addressLine1"
                            label={element?.getAttribute('data-address-line1-label')}
                            type="text"
                            hidden={true}
                            isMandatory
                          />
                          {/*<AddressSearch*/}
                          {/*  locale="en-GB"*/}
                          {/*  apiKey="FR88-JA31-WE72-ZW59"*/}
                          {/*  onSelect={address => console.log(address)}*/}
                          {/*  classes={'form__field valid'}*/}
                          {/*/>*/}
                        </div>
                        <div className="cmp-acommerce_billing-info__form-group">
                          <InputField
                            name="addressLine2"
                            label={element?.getAttribute('data-address-line2-label')}
                            type="text"
                            hidden={true}
                          />
                        </div>
                        <div className="cmp-acommerce_billing-info__form-group">
                          <InputField
                            name="city"
                            label={element?.getAttribute('data-city-label')}
                            type="text"
                            isMandatory
                            hidden={true}
                          />
                        </div>
                        <div className="cmp-acommerce_billing-info__form-group">
                          <Dropdown
                            name="state"
                            options={states}
                            label={element?.getAttribute('data-state-label')}
                            isMandatory
                            isDisabled={states[0].options.length > 1 ? false : true}
                          />
                        </div>
                        <div className="cmp-acommerce_billing-info__form-group">
                          <InputField
                            name="postalCode"
                            label={element?.getAttribute('data-zip-code-label')}
                            type="text"
                            isMandatory
                            hidden={true}
                          />
                        </div>
                        <div className="cmp-acommerce_billing-info__form-group">
                          <Dropdown
                            name="country"
                            options={countries}
                            label={element?.getAttribute('data-country-label')}
                            isMandatory
                          />
                        </div>
                        {!taxExemption && (
                          <div className="cmp-acommerce_billing-info__form-group">
                            <InputField
                              name="companyName"
                              label="Company name"
                              type="text"
                              isMandatory={isBusinessPurchased}
                              hidden={true}
                            />
                          </div>
                        )}
                        <div className="cmp-acommerce_billing-info__form-group">
                          <InputField
                            name="telephone"
                            label={element?.getAttribute('data-phone-number')}
                            type="text"
                            isMandatory
                            hidden={true}
                          />
                        </div>
                        {!isLoggedIn && (
                          <>
                            <div className="cmp-acommerce_billing-info__form-group">
                              <InputField
                                name="email"
                                label={element?.getAttribute('data-email-label')}
                                type="email"
                                isMandatory
                                hidden={true}
                              />
                            </div>
                            <div className="cmp-acommerce_billing-info__form-group">
                              <InputField
                                name="verifyemail"
                                label={element?.getAttribute('data-verify-email-label')}
                                type="email"
                                isMandatory
                                hidden={true}
                              />
                            </div>
                          </>
                        )}
                        {isBusinessPurchased && (
                          <div className="cmp-acommerce_billing-info__form-group">
                            <InputField
                              name="customerPO"
                              label={element?.getAttribute('data-customer-po-label')}
                              type="text"
                              hidden={true}
                            />
                          </div>
                        )}
                        <div className={`shipping-address-form ${shippingAddressForm ? 'show' : ''}`}>
                          <h4 className="cmp-acommerce_billing-info__form__heading">
                            {element?.getAttribute('data-shipping-info-label')}
                          </h4>
                          {isLoggedIn && (
                            <div className="cmp-acommerce_billing-info__form-group address">
                              <h4>{element?.getAttribute('data-address-heading')}</h4>
                              <Dropdown options={addressOptions && addressOptions} name="shippingAddress" />
                            </div>
                          )}
                          <div className="cmp-acommerce_billing-info__form-group">
                            <InputField
                              name="shippingFirstName"
                              label={element?.getAttribute('data-first-name-label')}
                              type="text"
                              isMandatory
                              hidden={true}
                            />
                          </div>
                          <div className="cmp-acommerce_billing-info__form-group">
                            <InputField
                              name="shippingLastName"
                              label={element?.getAttribute('data-last-name-label')}
                              type="text"
                              isMandatory
                              hidden={true}
                            />
                          </div>
                          <div className="cmp-acommerce_billing-info__form-group">
                            <InputField
                              name="shippingAddressLine1"
                              label={element?.getAttribute('data-address-line1-label')}
                              type="text"
                              isMandatory
                              hidden={true}
                            />
                          </div>
                          <div className="cmp-acommerce_billing-info__form-group">
                            <InputField
                              name="shippingAddressLine2"
                              label={element?.getAttribute('data-address-line2-label')}
                              type="text"
                              hidden={true}
                            />
                          </div>
                          <div className="cmp-acommerce_billing-info__form-group">
                            <InputField
                              name="shippingCity"
                              label={element?.getAttribute('data-city-label')}
                              type="text"
                              isMandatory
                              hidden={true}
                            />
                          </div>
                          <div className="cmp-acommerce_billing-info__form-group">
                            <Dropdown
                              name="shippingState"
                              options={shippingStates}
                              label={element?.getAttribute('data-state-label')}
                              isMandatory
                              isDisabled={states[0].options.length > 1 ? false : true}
                            />
                          </div>
                          <div className="cmp-acommerce_billing-info__form-group">
                            <InputField
                              name="shippingZipCode"
                              label={element?.getAttribute('data-zip-code-label')}
                              type="text"
                              isMandatory
                              hidden={true}
                            />
                          </div>
                          <div className="cmp-acommerce_billing-info__form-group">
                            <Dropdown
                              name="shippingCountry"
                              options={countries}
                              label={element?.getAttribute('data-country-label')}
                              isMandatory
                            />
                          </div>
                          <div className="cmp-acommerce_billing-info__form-group">
                            <InputField
                              name="shippingCompanyName"
                              label={element?.getAttribute('data-company-name')}
                              type="text"
                              isMandatory={isBusinessPurchased}
                              hidden={true}
                            />
                          </div>
                          <div className="cmp-acommerce_billing-info__form-group">
                            <InputField
                              name="shippingPhoneNumber"
                              label={element?.getAttribute('data-phone-number')}
                              type="text"
                              isMandatory
                              hidden={true}
                            />
                          </div>
                        </div>
                        {isLoggedIn && isBusinessPurchased && (
                          <div className="special-packaging-form">
                            <h4 className="cmp-acommerce_billing-info__form__heading">
                              {element?.getAttribute('data-shipping-info-label')}
                            </h4>
                            <Radio options={specialPackageOption} name="pack_count_tray" isMandatory />
                          </div>
                        )}
                        {(locale === 'en_us' || locale === 'ca') && (
                          <>
                            {taxExemption && (
                              <TaxExemption
                                taxCompanyName={formData.companyName}
                                cart_id={cart_id}
                                locale={locale}
                                setUpdateCart={setUpdateCart}
                              />
                            )}
                            {isLoggedIn ? (
                              <p className="tax-exemption-form" onClick={() => setTaxExemption(prev => !prev)}>
                                {element?.getAttribute('data-tax-exempt-button')}
                              </p>
                            ) : (
                              <Link
                                text={element?.getAttribute('data-login-for-tax')}
                                href={getShoppingUrls().guestURL}
                                className="cmp-acommerce_billing-info__guest-link"
                              />
                            )}
                          </>
                        )}

                        <div className="cmp-acommerce_billing-info__form-group additional-info">
                          <h4 className="cmp-acommerce_billing-info__form__heading">
                            {element?.getAttribute('data-additional-information-heading')}
                          </h4>
                          <Checkbox
                            name="opt_in"
                            label={element?.getAttribute('data-additional-information-label')}
                            className="additional-info-checkbox"
                          />
                        </div>

                        <Button className="cmp-acommerce_billing-info__submit">
                          {element?.getAttribute('data-continue-payment-label')}
                        </Button>
                        {/*DropInPayment*/}
                        {showPaymentMethod && (
                          <div className="cmp-acommerce_payment_main_wrap">
                            <h4 className="cmp-acommerce_billing-info__form__heading">
                              {element?.getAttribute('data-payment-heading')}
                            </h4>
                            <div id="cmp-acommerce_drop-in-payment-wrapper"></div>
                            <link
                              rel="stylesheet"
                              href="https://js.digitalriverws.com/v1/css/DigitalRiver.css"
                              type="text/css"
                            />
                          </div>
                        )}
                      </Form>
                    );
                  }}
                </Formik>
              </div>
            </div>
            <OrderSummary
              orderSummary={element?.getAttribute('data-order-summary')}
              estimatedShipping={element?.getAttribute('data-estimated-shipping')}
              subTotal={element?.getAttribute('data-sub-total')}
              dataaddresseditlabel={element?.getAttribute('data-address-edit-label')}
              updateCart={updateCart}
              setUpdateCart={setUpdateCart}
            />
          </div>
        </div>
      </div>
      {showLoader && createPortal(<Loader />, document.body)}
    </>
  );
}
