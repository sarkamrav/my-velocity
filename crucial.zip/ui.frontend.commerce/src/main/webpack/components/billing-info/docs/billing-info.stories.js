import BillingInfo from "../billing-info.hbs";

export default {
  title: "Components/React Component/Billing-Info",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { BillingInfo };
