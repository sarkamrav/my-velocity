import AccountHome from "../account-home.hbs";

export default {
  title: "Components/React Component/Account-Home",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { AccountHome };
