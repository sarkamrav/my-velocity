import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { Formik, Form } from 'formik';
import InputField from '../inputfield/InputField';
import * as Yup from 'yup';
import Button from '../micro-components/Button/Button';
import Link from '../micro-components/Link/Link';
import Checkbox from '../micro-components/Checkbox/Checkbox';
import Loader from '../micro-components/Loader/Loader';
import PropTypes from 'prop-types';
import { gql, useMutation, useQuery } from '@apollo/client';
import { UPDATE_CUSTOMER } from '../../site/js/gql/mutations/updateCustomer.gql';
import Icon from '../../assests/Icon';
export default function AccountHome({
  displayHeading,
  displaySubHeading1,
  displaySubHeading2,
  displayFirstnameLabel,
  displayFirstnameRequiredError,
  displayLastnameLabel,
  displayLastnameRequiredError,
  displayEmailLabel,
  displayEmailRequiredError,
  displayEmailInvalidError,
  displayVerifyEmailLabel,
  displayVerifyEmailRequiredError,
  displayVerifyEmailInvalidError,
  displayVerifyEmailUnmatchError,
  displayCurrentPasswordLabel,
  displayPasswordLabel,
  displayCurrentPasswordRequiredError,
  displayNewPasswordMinError,
  displayNewPasswordMaxError,
  displayNewPasswordPatternError,
  displayVerifyPasswordLabel,
  displayVerifyPasswordRequiredError,
  displayPasswordUnmatchError,
  displayNotification,
  displayRequiredText,
  displayUpdateButtonLabel,
  displayBackLabel,
  displayBackLink,
  displayNavigationHeading,
  displaySignOutLabel,
  displaySignOutLink,
  linkUrls,
}) {
  const initialValues = {
    firstname: '',
    lastname: '',
    password: '',
    newPassword: '',
    verifyNewPassword: '',
    email: '',
    verifyEmail: '',
    is_subscribed: false,
  };

  const [formdata, setFormdata] = useState(initialValues);
  const ACCOUNT_INFO = gql`
    query {
      core_customer {
        email
        firstname
        lastname
        customer_type
        is_subscribed
      }
    }
  `;

  const { error: customerError, loading: customerLoading, data: customerData } = useQuery(ACCOUNT_INFO);
  const [updateCustomer, { error: updateError, loading: updateLoading, data: updateData }] =
    useMutation(UPDATE_CUSTOMER);

  useEffect(() => {
    if (customerData) {
      const { firstname, lastname, email, is_subscribed } = customerData.core_customer;
      setFormdata(prev => ({
        ...prev,
        firstname: firstname,
        lastname,
        email,
        verifyEmail: email,
        is_subscribed,
      }));
    }
  }, [customerData]);

  const linkUrlJson = JSON.parse(linkUrls);

  const baseSchema = Yup.object().shape({
    firstname: Yup.string().required(displayFirstnameRequiredError),
    lastname: Yup.string().required(displayLastnameRequiredError),
    email: Yup.string().email(displayEmailInvalidError).required(displayEmailRequiredError),
    verifyEmail: Yup.string()
      .email(displayVerifyEmailInvalidError)
      .required(displayVerifyEmailRequiredError)
      .oneOf([Yup.ref('email'), null], displayVerifyEmailUnmatchError),
    password: Yup.string().required(displayCurrentPasswordRequiredError),
    newPassword: Yup.string()
      .nullable()
      .notRequired()
      .min(8, displayNewPasswordMinError)
      .max(32, displayNewPasswordMaxError)
      .matches(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^*~:;&><[\]{}|_\-+=?])[A-Za-z\d!@#$%^*~:;&><[\]{}|_\-+=?]*$/,
        displayNewPasswordPatternError
      )
      .test('password-requirements', displayNewPasswordPatternError, value => {
        if (!value) {
          return true;
        } // If password is not provided, it's valid.

        const requirements = [
          /[A-Z]/.test(value), // Upper case letter
          /[a-z]/.test(value), // Lower case letter
          /\d/.test(value), // Numbers
          /[!@#$%^*~:;&><[\]{}|_\-+=?]/.test(value), // Special characters
        ];
        return requirements.filter(Boolean).length >= 3;
      }),
    verifyNewPassword: Yup.string().oneOf([Yup.ref('newPassword'), null], displayPasswordUnmatchError),
    is_subscribed: Yup.bool(),
  });

  // Custom validation function
  const validationSchema = baseSchema.test(
    'verify-new-password-required',
    `${displayVerifyPasswordRequiredError}`,
    function (values) {
      const { newPassword, verifyNewPassword } = values;
      if (newPassword && !verifyNewPassword) {
        return this.createError({ path: 'verifyNewPassword', message: `${displayVerifyPasswordRequiredError}` });
      }
      return true;
    }
  );

  const handleSubmit = values => {
    const { firstname, lastname, email, password, is_subscribed, newPassword } = values;

    const apiVariables = {
      firstname,
      lastname,
      email,
      customer_type: customerData.core_customer.customer_type,
      password,
      ...(newPassword && {
        newPassword,
      }),
      is_subscribed,
    };

    updateCustomer({
      variables: apiVariables,
    })
      .then(() => {
        window.location.href = '/';
      })
      .catch(error => console.log(error.message));
  };

  // In case of error scroll to top to view the error
  if (customerError || updateError) {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  }

  // To sign the user out
  const handleSignout = e => {
    e.stopPropagation();
    document.cookie = 'cart_id=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
    localStorage.removeItem('user_token');
    document.cookie = 'user_token=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
    document.cookie = 'cart_items=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
    document.cookie = 'user_email=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
    document.cookie = 'student_popup=; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;';
    window.location.href = '/';
  };

  return (
    <section className="cmp-acommerce_account-home__section">
      <div className="custom-container">
        <div className="cmp-acommerce_account-home__main row">
          <div className="cmp-acommerce_account-home__form column small-12 medium-8">
            <h2 className="cmp-acommerce_account-home__heading">{displayHeading}</h2>
            <div className="cmp-acommerce_account-home__sub-heading">
              <p>{displaySubHeading1}</p>
              <p>{displaySubHeading2}</p>
            </div>
            <Formik
              initialValues={formdata}
              validationSchema={validationSchema}
              onSubmit={(values, { resetForm }) => {
                handleSubmit(values, resetForm);
              }}
              enableReinitialize>
              {() => (
                <>
                  <input name="Action" type="hidden" value="DisplayAccountMenuPage" />
                  <input name="SiteID" type="hidden" value="crucial" />
                  <input name="Locale" type="hidden" value="en_US" />
                  <input value="com.digitalriver.template.form.EditProfileForm" name="Form" type="hidden" />
                  <input name="CallingPageID" type="hidden" value="EditProfilePage" />
                  <input
                    name="CSRFAuthKey"
                    type="hidden"
                    value="YFZnswUHPGthanV3YAAAJX1/BggEBnVrbGsgbC9SBnB3ZgNUVQRgY/cVAA=="
                  />
                  <Form>
                    {(updateError || customerError) && (
                      <p className="submiterror">{updateError?.message || customerError?.message}</p>
                    )}
                    <div className="cmp-acommerce_account-home__form-container">
                      <InputField
                        name="firstname"
                        label={displayFirstnameLabel}
                        type="text"
                        hidden={true}
                        isMandatory
                      />
                      <InputField name="lastname" label={displayLastnameLabel} type="text" hidden={true} isMandatory />
                      <InputField
                        name="password"
                        label={displayCurrentPasswordLabel}
                        type="password"
                        isMandatory
                        hidden={true}
                      />
                      <InputField name="newPassword" label={displayPasswordLabel} type="password" hidden={true} />
                      <InputField
                        name="verifyNewPassword"
                        label={displayVerifyPasswordLabel}
                        type="password"
                        hidden={true}
                      />
                      <InputField name="email" label={displayEmailLabel} type="email" hidden={true} isMandatory />
                      <InputField
                        name="verifyEmail"
                        label={displayVerifyEmailLabel}
                        type="email"
                        hidden={true}
                        isMandatory
                      />
                    </div>
                    <Checkbox
                      name="is_subscribed"
                      label={displayNotification}
                      className="cmp-acommerce_account-home__form-checkbox"
                    />
                    <div className="required-text">{displayRequiredText}<span className="mandatory_asterisk">*</span></div>
                    <Button>{displayUpdateButtonLabel}</Button>
                  </Form>
                </>
              )}
            </Formik>
            <div className="back-link sm-hidden">
              <Icon name="ArrowLeft" />
              <Link text={displayBackLabel} type="back" href={displayBackLink} />
            </div>
          </div>
          <div className="cmp-acommerce_account-home__links column small-12 medium-4 large-3 large-offset-1">
            <div className="cmp-acommerce_account-home__links__container">
              <h3 className="cmp-acommerce_account-home__links__heading">{displayNavigationHeading}</h3>
              <ul className="cmp-acommerce_account-home__links__list">
                {Object.keys(linkUrlJson).map(key => (
                  <li key={key}>
                    {/* onClick={handleSignout} */}
                  <Link text={key} type="default" href={linkUrlJson[key]} />
                  </li>
                ))}
                <li>
                  <Link onClick={handleSignout} text={displaySignOutLabel} type="default" href={displaySignOutLink} />
                </li>
              </ul>
            </div>
            <div className="back-link lg-hidden">
              <Icon name="ArrowLeft" />
              <Link text={displayBackLabel} type="back" href={displayBackLink} />
            </div>
          </div>
        </div>
      </div>
      {(customerLoading || updateLoading) && createPortal(<Loader />, document.body)}
    </section>
  );
}

AccountHome.propTypes = {
  displayHeading: PropTypes.string,
  displaySubHeading1: PropTypes.string,
  displaySubHeading2: PropTypes.string,
  displayFirstnameLabel: PropTypes.string,
  displayFirstnameRequiredError: PropTypes.string,
  displayLastnameLabel: PropTypes.string,
  displayLastnameRequiredError: PropTypes.string,
  displayPasswordLabel: PropTypes.string,
  displayCurrentPasswordLabel: PropTypes.string,
  displayCurrentPasswordRequiredError: PropTypes.string,
  displayVerifyPasswordLabel: PropTypes.string,
  displayPasswordUnmatchError: PropTypes.string,
  displayEmailLabel: PropTypes.string,
  displayEmailRequiredError: PropTypes.string,
  displayEmailInvalidError: PropTypes.string,
  displayVerifyEmailLabel: PropTypes.string,
  displayVerifyEmailRequiredError: PropTypes.string,
  displayVerifyEmailInvalidError: PropTypes.string,
  displayVerifyEmailUnmatchError: PropTypes.string,
  displayNotification: PropTypes.string,
  displayUpdateButtonLabel: PropTypes.string,
  displayBackLabel: PropTypes.string,
  displayBackLink: PropTypes.string,
  displayNavigationHeading: PropTypes.string,
  displaySignOutLabel: PropTypes.string,
  displaySignOutLink: PropTypes.string,
  linkUrls: PropTypes.string,
};

AccountHome.defaultProps = {
  displayHeading: 'Account Home',
  displaySubHeading1: 'Please fill in the information on the left and click the "update" button.',
  displaySubHeading2:
    'Password must be between 8 - 32 characters. Password must include three of the following: Upper case letter, lower case letter, numbers and the special characters: ! @ # $ % ^ * ~ : ; & > < [ ] { } | - _ + = ?',
  displayFirstnameLabel: 'First Name',
  displayFirstnameRequiredError: 'Enter a valid value.',
  displayLastnameLabel: 'Last Name',
  displayLastnameRequiredError: 'Enter a valid value.',
  displayPasswordLabel: 'Password',
  displayCurrentPasswordLabel: 'Current Password',
  displayCurrentPasswordRequiredError: 'Please enter your current password',
  displayNewPasswordMinError: 'Password must be at least 8 characters long',
  displayNewPasswordMaxError: 'Password must be at most 32 characters long',
  displayNewPasswordPatternError:
    'Password must be between 8 - 32 characters. Password must include three of the following: Upper case letter, lower case letter, numbers and the special characters: ! @ # $ % ^ * ~ : ; & > < [ ] { } | - _ + = ?',
  displayVerifyPasswordLabel: 'Verify Password',
  displayPasswordUnmatchError: 'Verify both the passwords',
  displayEmailLabel: 'Email Address',
  displayEmailRequiredError: 'Enter a valid value.',
  displayEmailInvalidError: 'Enter a valid email address.',
  displayVerifyEmailLabel: 'Please verify your email address:',
  displayVerifyEmailRequiredError: 'Enter a valid value.',
  displayVerifyEmailInvalidError: 'Enter a valid email address.',
  displayVerifyEmailUnmatchError: 'Both email addresses must be the same.',
  displayNotification:
    "We'd like to keep you informed via email about product updates, upgrades, special offers and pricing. If you do not wish to be contacted via email, please ensure that the box is not checked.",
  displayRequiredText: 'Required',
  displayUpdateButtonLabel: 'Update',
  displayBackLabel: 'Back to Store',
  displayBackLink: '#',
  displayNavigationHeading: 'My Account',
  displaySignOutLabel: 'Sign out',
  displaySignOutLink: '#',
  linkUrls: '{Address Book:/content/crucial/en-us/home/account-home/address-book.html}',
};
