import React from 'react';
import { useFormikContext } from 'formik';
import PropTypes from 'prop-types';
function TextInput({ type, isMandatory, name, label, changeHandler, placeholder, className, field, ...props }) {
  const formik = useFormikContext();

  const handleChange = e => {
    const { name, value } = e.target;
    if (changeHandler) {
      changeHandler();
    } else {
      // Call Formik's setFieldValue to update the form value
      formik.setFieldValue(name, value);
    }
  };

  const handleAutoFill = () => {
    if (window.location.pathname.includes('guest-checkout') || window.location.pathname.includes('account-home')) {
      if (name === 'email' || name === 'password') {
        return `new-${name}`;
      }
    }
  };

  return (
    <div className="form__group">
      <label htmlFor={name} className="form__label">
        {label}
        {isMandatory && <span className="mandatory_asterisk">*</span>}
      </label>
      <input
        className={`form__field ${className}`}
        id={name}
        type={type}
        {...field}
        {...props}
        onChange={handleChange}
        placeholder={placeholder}
        autoComplete={handleAutoFill()}
      />
    </div>
  );
}

TextInput.propTypes = {
  placeholder: PropTypes.string,
  isMandatory: PropTypes.bool,
};

TextInput.defaultProps = {
  placeholder: '',
  isMandatory: false,
};

export default TextInput;
