import React from 'react';
import Link from '../../../micro-components/Link/Link';
import { getCookie } from '../../../../utils/cookies_operation';
import { formatLocalePrice } from '../../../../utils/utils';
import { getCatalogServiceHeaders } from '../../../../configs/ReactApolloClientSetup/ApolloClientConfig';

const ProductsTable = ({ products, prices, currentShippingPrice, attributes, incVat }) => {
  // Getting currency symbol from the cookie
  const currencySymbol = getCookie('currency') && JSON.parse(getCookie('currency')).currencySymbol;
  const productUrls = getCookie('cart_product_urls') && JSON.parse(getCookie('cart_product_urls'));
  const locale = getCatalogServiceHeaders();
  return (
    <div className="cmp-acommerce_verify-order__order-details">
      <div className="cmp-acommerce_verify-order__order-details__table">
        <div className="cmp-acommerce_verify-order__order-details__table-head">
          <div className="verify-order-quantity">{attributes.displayQuantity}</div>
          <div className="verify-order-group">
            <div className="verify-order-product-name">{attributes.displayProductName}</div>
            <div className="verify-order-stock-status">{attributes.displayStockStatus}</div>
            <div className="verify-order-price">
              {attributes.displayPrice}
              {locale !== 'en_us' && <span>{incVat}</span>}
            </div>
          </div>
        </div>
        <div className="cmp-acommerce_verify-order__order-details__table-body">
          {products.map(product => (
            <div className="cmp-acommerce_verify-order__order-details__table-row" key={product.uid}>
              <div className="verify-order-quantity">{product?.quantity}</div>
              <div className="verify-order-group">
                <div className="verify-order-product-name">
                  <Link
                    text={product?.product?.name}
                    href={productUrls?.find(item => item.sku === product?.product.sku)?.url}
                    className="verify-order-product-link"
                  />
                  <p className="verify-order-product-sku">
                    {attributes.displaySkuLabel} {product?.product.sku.toUpperCase()}
                  </p>
                </div>
                <div className="verify-order-stock-status">
                  {product?.availableInStockQty > 0 ? 'In stock' : 'Out of stock'}
                </div>
                <div className="verify-order-price">
                  {formatLocalePrice(product?.prices.row_total?.value, currencySymbol)}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="cmp-acommerce_verify-order__order-details__prices">
        {Object.keys(prices).length > 0 && (
          <>
            {
              // To be modified when user selects the shipping method
              <div className="cmp-acommerce_verify-order__order-details__prices-type verify-order-shipping">
                <span className="price-name">{attributes.displayShippingPriceLabel}</span>
                <span className="price-value">{formatLocalePrice(currentShippingPrice, currencySymbol)}</span>
              </div>
            }
            {prices?.discounts.length > 0 && (
              <div className="cmp-acommerce_verify-order__order-details__prices-type verify-order-tax">
                {prices.discounts.map(discount => (
                  <>
                    <span className="price-name">{discount.label}</span>
                    <span className="price-value">-{formatLocalePrice(discount.amount.value, currencySymbol)}</span>
                  </>
                ))}
              </div>
            )}
            {prices?.total_tax?.value > 0 && (
              <div className="cmp-acommerce_verify-order__order-details__prices-type verify-order-tax">
                <span className="price-name">{attributes.displayTaxPriceLabel}</span>
                <span className="price-value">{formatLocalePrice(prices?.total_tax?.value, currencySymbol)}</span>
              </div>
            )}
            <div className="cmp-acommerce_verify-order__order-details__prices-type verify-order-total">
              <span className="price-name">{attributes.displayTotalPriceLabel}</span>
              <span className="price-value">{formatLocalePrice(prices?.grand_total?.value, currencySymbol)}</span>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default ProductsTable;
