import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import Dropdown from '../micro-components/Dropdown/Dropdown';
import { Formik, Form } from 'formik';
import Button from '../micro-components/Button/Button';
import * as Yup from 'yup';
import { useMutation, useLazyQuery } from '@apollo/client';
import { GET_CART_DETAILS } from '../../site/js/gql/get-cart-details.gql';
import { SET_SHIPPING_METHOD } from '../../site/js/gql/mutations/setShippingMethod.gql.js';
import { UPDATE_QUOTE_FIELD } from '../../site/js/gql/mutations/updateQuoteField.gql.js';
import Loader from '../micro-components/Loader/Loader';
import ProductsTable from './components/ProductsTable/ProductsTable';
import { clearCookie, getCookie, setCookie } from '../../utils/cookies_operation.js';
import Icon from '../../assests/Icon.js';
import { getShoppingUrls } from '../../site/js/urlresolver.js';
import { GET_DR_SOURCE_DATA, GET_PAYPAL_SOURCE_DATA } from '../../site/js/gql/get-dr-source.gql';
import {
  QUICK_SET_PAYMENT_METHOD_TO_CART,
  QUICK_SET_SHIPPING,
} from '../../site/js/gql/mutations/cart-quick-action.gql';
import { ASSIGN_EMAIL_GUEST } from '../../site/js/gql/mutations/checkout.gql';
import { getUserTokenFromLoaclStorate } from '../../configs/ReactApolloClientSetup/ApolloClientConfig';
import { REFRESH_DR_ORDER } from '../../site/js/gql/mutations/order-refresh.gql';

export default function VerifyOrder({
  displayHeading,
  displayShippingMethodHeading,
  displayReferenceNumberLabel,
  displayAgreementTextOne,
  displayAgreementTextTwo,
  displayAgreementTextThree,
  displayAgreementLinkOne,
  displayAgreementLinkTwo,
  displayAgreementRequiredError,
  displayEmailReminder,
  displaySubmitButtonLabel,
  displaySubmitDisclaimer,
  displayGettingOrderDetails,
  displayPleaseWait,
  displayShoppingCart,
  displayFollowCheckout,
  displayContinueShopping,
  displayShoppingCartEmpty,
  incVat,
  ...otherAttributes
}) {
  // States for the entire page content
  const [products, setProducts] = useState([]);
  const [prices, setPrices] = useState({});
  const [shippingMethods, setShippingMethods] = useState([]);
  const [referenceNumber, setReferenceNumber] = useState('');
  const [loader, setLoader] = useState(false);

  // States to manage shipping method related calls and changes
  const [currentShippingMethod, setCurrentShippingMethod] = useState(null);
  const [currentShippingPrice, setCurrentShippingPrice] = useState(0);

  // Get cart id and billing info cookies
  const cartId = getCookie('cart_id') && JSON.parse(getCookie('cart_id'));

  // Initial values for Initial values for Formik
  const initialValues = {
    shippingMethod: '',
    termsCondition: false,
    emailReminder: false,
  };

  // Validation schema for Form validations
  const validationSchema = Yup.object().shape({
    shippingMethod: Yup.string(),
    termsCondition: Yup.bool().oneOf([true], displayAgreementRequiredError),
    emailReminder: Yup.bool(),
  });

  // Formulate form data to submit
  const [formdata, setFormdata] = useState(initialValues);

  // Default options for shipping method dropdown
  const [shippingOptions, setShippingOptions] = useState([
    {
      options: [
        {
          label: 'No shipping options',
          value: '',
          charge: 0,
          carrierCode: '',
          methodCode: '',
        },
      ],
    },
  ]);

  // Trigger the cart query to get cart details on page load
  const [getCartDetails, { error: cartError, loading: cartLoading, data: cartData }] = useLazyQuery(GET_CART_DETAILS, {
    variables: { cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')) },
  });

  // Mutation to fire when shipping method is selected for the cart
  const [setCartShippingMethod, { error: shippingMethodError, loading: shippingMethodLoading }] =
    useMutation(SET_SHIPPING_METHOD);

  // Mutation to send the terms of sale and privacy policy checkboxes
  const [updateQuotation, { loading: quoteLoading }] = useMutation(UPDATE_QUOTE_FIELD);

  // New state variables and mutations for the new code
  const [setShipping] = useMutation(QUICK_SET_SHIPPING);
  const [getSourceData] = useLazyQuery(GET_DR_SOURCE_DATA);
  const [sourceData, setSourceData] = useState({});
  const [payPalData, setPayPalData] = useState({});
  const [quickPayAddress, setQuickPayAddress] = useState({});
  const [assignGuestEmail] = useMutation(ASSIGN_EMAIL_GUEST);
  const [setPayementMethod, { error: paymentError, loading: paymentLoading }] = useMutation(
    QUICK_SET_PAYMENT_METHOD_TO_CART
  );
  const [setRefreshOrder] = useMutation(REFRESH_DR_ORDER);
  // Query to get paypal source data
  const [getPayPalSource] = useLazyQuery(GET_PAYPAL_SOURCE_DATA);

  // On page load check for cookies and make call accordingly

  // Effect to get source data from URL parameters
  const [sourceID, setSourceID] = useState('');
  useEffect(() => {
    setLoader(true);
    const url = new URL(window.location.href);
    const params = new URLSearchParams(url.search);
    setSourceID(params.get('sourceId'));
  }, []);

  useEffect(() => {
    if (sourceID) {
      getSourceData({
        variables: {
          sourceId: sourceID,
        },
      }).then(res => {
        const decodedData = atob(res.data.core_get_digital_river_source.dr_source);
        setSourceData(JSON.parse(decodedData));
      });
    }
  }, [sourceID]);

  // Effect to set quick pay address based on source data
  useEffect(() => {
    if (sourceData) {
      if (sourceData.type === 'amazonPay') {
        const fullName = sourceData.amazonPay.shipping.recipient;
        const nameParts = fullName.split(' ');
        setQuickPayAddress(prev => ({
          ...prev,
          email: sourceData.amazonPay.shipping.email,
          country: sourceData.amazonPay.shipping.address.country,
          state: sourceData.amazonPay.shipping.address.state,
          city: sourceData.amazonPay.shipping.address.city,
          firstName: nameParts[0],
          lastName: nameParts[1],
          addressLine1: sourceData.amazonPay.shipping.address.line1,
          addressLine2: sourceData.amazonPay.shipping.address.line2 || '',
          postalCode: sourceData.amazonPay.shipping.address.postalCode,
          phoneNumber: sourceData.amazonPay.shipping.phoneNumber,
        }));
      }
      if (sourceData.type === 'payPal') {
        getPayPalSource({
          variables: {
            sourceId: sourceID,
            checkoutId: getCookie('checkout_id') && JSON.parse(getCookie('checkout_id')),
          },
        }).then(res => {
          const decodedData = atob(res.data.core_attach_dr_source_to_checkout.dr_checkout);
          setPayPalData(JSON.parse(decodedData));
        });
      }
    }
  }, [sourceData]);

  useEffect(() => {
    if (Object.keys(payPalData).length) {
      const { name, phone, email, address } = payPalData.billTo || {};
      const nameParts = name.split(' ');
      setQuickPayAddress(prev => ({
        ...prev,
        email: email,
        country: address.country,
        state: address.state,
        city: address.city,
        firstName: nameParts[0],
        lastName: nameParts[1],
        addressLine1: address.line1,
        addressLine2: address.line2 || '',
        postalCode: address.postalCode,
        phoneNumber: phone,
      }));
    }
  }, [payPalData]);

  // Effect to set shipping information based on quick pay address
  useEffect(() => {
    if (Object.keys(quickPayAddress).length > 0) {
      setShipping({
        variables: {
          cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')),
          city: quickPayAddress.city,
          countryCode: quickPayAddress.country,
          postcode: quickPayAddress.postalCode,
          region: quickPayAddress.state,
          street: [quickPayAddress.addressLine1, quickPayAddress.addressLine2],
          firstname: quickPayAddress.firstName,
          lastname: quickPayAddress.lastName || quickPayAddress.firstName,
          telephone: quickPayAddress.phoneNumber,
        },
      }).then(response => {
        setShippingMethods(
          response.data.core_setShippingAddressesOnCart.cart.shipping_addresses[0]?.available_shipping_methods
        );
        getCartDetails();
      });
    }
  }, [quickPayAddress]);

  // Populate states as per the response and update the page
  useEffect(() => {
    if (cartData) {
      const { shipping_addresses, items, prices, digital_river } = cartData.core_cart;
      digital_river && setReferenceNumber(digital_river?.checkout_id);
      shipping_addresses.length > 0 && setShippingMethods(shipping_addresses[0]?.available_shipping_methods);
      items.length > 0 && setProducts(items);
      prices && setPrices(prices);
      setLoader(false);
    }
  }, [cartData]);

  // Update the shipping methods options to display on the dropdown and select the first one by default
  useEffect(() => {
    if (shippingMethods.length) {
      let shipping_options = shippingOptions;

      shipping_options.map(options => (options.options.length = 0));

      shippingMethods.map(method => {
        shipping_options.map(options => {
          options.options.push({
            label: method?.carrier_title,
            value: method?.method_code,
            charge: method?.amount.value,
            carrierCode: method?.carrier_code,
            methodCode: method?.method_code,
          });
        });
      });

      setShippingOptions(shipping_options);

      setFormdata(prev => ({
        ...prev,
        shippingMethod: shipping_options[0].options[0].value,
      }));
    }
  }, [shippingMethods]);

  // Fire the shipping method query on changing the shipping method
  useEffect(() => {
    if (currentShippingMethod && currentShippingMethod?.value !== '') {
      setCartShippingMethod({
        variables: {
          cartId: JSON.parse(getCookie('cart_id')),
          carrierCode: currentShippingMethod.carrierCode,
          methodCode: currentShippingMethod.methodCode,
        },
        refetchQueries: [
          {
            query: GET_CART_DETAILS,
            variables: { cart_id: getCookie('cart_id') && JSON.parse(getCookie('cart_id')) },
          },
        ],
      })
        .then(data => {
          if (data.data.core_setShippingMethodsOnCart != null) {
            if (data.data.core_setShippingMethodsOnCart.cart.prices) {
              setPrices(data.data.core_setShippingMethodsOnCart.cart.prices);
              setCurrentShippingPrice(shipping_addresses?.selected_shipping_method?.amount?.value);
              setLoader(false);
            }
          }
        })
        .catch(error => console.log(error.message));
    }
  }, [currentShippingMethod]);

  // Submit handler to place the order
  const handleSubmit = async values => {
    try {
      const cartId = JSON.parse(getCookie('cart_id'));
      if (cartId) {
        if (!getUserTokenFromLoaclStorate()) {
          try {
            await assignGuestEmail({
              variables: {
                cart_id: cartId,
                email: quickPayAddress.email,
              },
            });
          } catch (error) {
            console.error('Error assigning guest email:', error?.message);
            return;
          }
        }

        try {
          await updateQuotation({
            variables: {
              cart_id: cartId,
              tos_accepted: values.termsCondition,
              request_email: values.emailReminder,
            },
          });
        } catch (error) {
          console.error('Error updating quotation:', error?.message);
          return;
        }

        try {
          const response = await setPayementMethod({
            variables: {
              cart_id: cartId,
              source_id: sourceData.id,
              additional_data: JSON.stringify(sourceData),
              code: 'dr_drop_in_payment',
            },
          });

          try {
            await setRefreshOrder({
              variables: {
                dr_order_number: response?.data?.core_placeOrder?.order?.dr_order_id,
                order_number: response?.data?.core_placeOrder?.order?.order_number,
              },
            });

            setLoader(false);
            document.cookie = 'checkout_id=; Path=/; Expires=Thu, 01 Jan 2000 00:00:01 GMT;';
            setCookie('crucialPaymentSource', JSON.stringify(sourceData), 5);
            clearCookie('cart_product_urls');
            window.location.href = `${getShoppingUrls().thankYouURL}?order_number=${
              response?.data?.core_placeOrder?.order?.order_number
            }`;
          } catch (error) {
            console.error('Error refreshing order:', error?.message);
          }
        } catch (error) {
          console.error('Error setting payment method:', error?.message);
        }
      }
    } catch (error) {
      console.error('Error processing handleSubmit:', error?.message);
    }
  };

  // In case of error scroll to top to view the error
  if (cartError || paymentError) {
    setLoader(false);
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  }

  return (
    <>
      <section className="cmp-acommerce_verify-order__section">
        <div className="custom-container">
          {cartId ? (
            cartLoading || loader ? (
              <div className="cmp-acommerce_verify-order__head no-border">
                <h2 className="cmp-acommerce_verify-order__heading">{displayHeading}</h2>
                <h3>{displayGettingOrderDetails}</h3>
                <p>{displayPleaseWait}</p>
              </div>
            ) : cartError ? (
              <p className="submiterror">{cartError?.message}</p>
            ) : (
              <>
                <div className="cmp-acommerce_verify-order__head">
                  <h2 className="cmp-acommerce_verify-order__heading">{displayHeading}</h2>
                </div>
                {paymentError && <p className="submiterror">{paymentError?.message}</p>}

                <Formik
                  initialValues={formdata}
                  validationSchema={validationSchema}
                  onSubmit={values => {
                    handleSubmit(values);
                  }}
                  enableReinitialize>
                  {({ values, handleChange, handleBlur, touched, errors }) => {
                    useEffect(() => {
                      let shippingOption = shippingOptions[0]?.options?.find(
                        option => option.value === values.shippingMethod
                      );
                      setCurrentShippingMethod(shippingOption);
                    }, [values.shippingMethod]);

                    return (
                      <Form>
                        <div className="cmp-acommerce_verify-order__shipping-container">
                          <h6 className="cmp-acommerce_verify-order__shipping-heading">
                            {displayShippingMethodHeading}
                          </h6>
                          <div className="cmp-acommerce_verify-order__shipping-dropdown">
                            <Dropdown
                              name="shippingMethod"
                              options={shippingOptions}
                              className="cmp-acommerce_verify-order__shipping-dropdown__input"
                              isDisabled={!shippingMethods.length}
                            />
                            {shippingMethodError && <p className="submiterror">{shippingMethodError?.message}</p>}
                          </div>
                        </div>
                        <div className="cmp-acommerce_verify-order__reference-number">
                          <strong>{displayReferenceNumberLabel}</strong> <span>{referenceNumber}</span>
                        </div>
                        {products.length > 0 && Object.keys(prices).length > 0 && (
                          <ProductsTable
                            products={products}
                            prices={prices}
                            attributes={otherAttributes}
                            currentShippingPrice={currentShippingPrice}
                            incVat={incVat}
                          />
                        )}
                        <div className="cmp-acommerce_verify-order__checkboxes">
                          <div className="cmp-acommerce_checkbox cmp-acommerce_verify-order__checkbox">
                            <div className="cmp-acommerce_checkbox-group">
                              <div className="cmp-acommerce_checkbox-input-group">
                                <input
                                  type="checkbox"
                                  id="termsCondition"
                                  name="termsCondition"
                                  checked={values.termsCondition}
                                  onChange={handleChange}
                                  onBlur={handleBlur}
                                  className="cmp-acommerce_checkbox-input"
                                />
                                <Icon name="Checkbox" />
                              </div>
                              <label htmlFor="termsCondition" className="cmp-acommerce_checkbox-label">
                                {displayAgreementTextOne}{' '}
                                <a
                                  // eslint-disable-next-line max-len
                                  href="/store/defaults/en_US/DisplayDRTermsAndConditionsPage?_gl=1*d0rsv3*_up*MQ..*_ga*NzA1OTA1NTI1LjE3MTgwMTgxNTk.*_ga_6H4RYWV7QY*MTcxODAxODE1OS4xLjAuMTcxODAxODE1OS4wLjAuMTY4MDM0MjM3NQ.."
                                  target="_blank">
                                  {displayAgreementLinkOne}
                                </a>{' '}
                                {displayAgreementTextTwo}{' '}
                                <a href="/store/defaults/en_US/DisplayDRPrivacyPolicyPage" target="_blank">
                                  {displayAgreementLinkTwo}
                                </a>{' '}
                                {displayAgreementTextThree}
                              </label>
                            </div>
                            {touched.termsCondition && errors.termsCondition ? (
                              <div className="form-input-error">{errors.termsCondition}</div>
                            ) : null}
                          </div>
                          <div className="cmp-acommerce_checkbox cmp-acommerce_verify-order__checkbox">
                            <div className="cmp-acommerce_checkbox-group">
                              <div className="cmp-acommerce_checkbox-input-group">
                                <input
                                  type="checkbox"
                                  id="emailReminder"
                                  name="emailReminder"
                                  checked={values.emailReminder}
                                  onChange={handleChange}
                                  onBlur={handleBlur}
                                  className="cmp-acommerce_checkbox-input"
                                />
                                <Icon name="Checkbox" />
                              </div>
                              <label htmlFor="emailReminder" className="cmp-acommerce_checkbox-label">
                                {displayEmailReminder}
                              </label>
                            </div>
                            {touched.termsCondition && errors.emailReminder ? (
                              <div className="form-input-error">{errors.emailReminder}</div>
                            ) : null}
                          </div>
                        </div>
                        <div className="cmp-acommerce_verify-order__submit">
                          <Button disabled={cartError}>{displaySubmitButtonLabel}</Button>
                          <p>{displaySubmitDisclaimer}</p>
                        </div>
                      </Form>
                    );
                  }}
                </Formik>
              </>
            )
          ) : (
            <div className="cmp-acommerce_verify-order__head no-border">
              <h2 className="cmp-acommerce_verify-order__heading">{displayHeading}</h2>
              {cartId ? (
                <>
                  <h3>{displayFollowCheckout}</h3>
                  <Button onClick={() => (window.location = '/shopping-cart')}>{displayShoppingCart}</Button>
                </>
              ) : (
                <>
                  <h3>{displayShoppingCartEmpty}</h3>
                  <Button onClick={() => (window.location = '/')}>{displayContinueShopping}</Button>
                </>
              )}
            </div>
          )}
        </div>
      </section>
      {(cartLoading || shippingMethodLoading || loader || quoteLoading || paymentLoading) &&
        createPortal(<Loader />, document.body)}
    </>
  );
}
