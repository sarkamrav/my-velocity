import OrderHistory from "../order-history.hbs";

export default {
  title: "Components/React Component/Order-History",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { OrderHistory };
