import React from 'react';
import Link from '../micro-components/Link/Link';
import PropTypes from 'prop-types';
import Icon from '../../assests/Icon';
import OrderTabs from './components/OrderTab/OrderTab';
import { generateMessage } from '../../utils/utils';
import InfoBanner from '../info-banner/InfoBanner';
export default function OrderHistory({ displayHeading, displayBackLabel, ...restProps }) {
  const { accountHomeUrl } = restProps;
  return (
    <section className="cmp-acommerce_order-history__section">
      <div className="custom-container">
        <InfoBanner message={generateMessage()} />
        <div className="cmp-acommerce_order-history__main">
          <p className="headinginfo">{displayHeading} </p>
          <div className="App">
            <OrderTabs {...restProps} />
          </div>
          <p className="back-link">
            <Icon name="ArrowLeft" />
            <Link
              text={displayBackLabel}
              type="back"
              href={accountHomeUrl}
              className="cmp-acommerce_order-history__back"
            />
          </p>
        </div>
      </div>
    </section>
  );
}

OrderHistory.propTypes = {
  displayHeading: PropTypes.string,
  displayBackLabel: PropTypes.string,
  displayBackLink: PropTypes.string,
  accountHomeUrl: PropTypes.string,
};

OrderHistory.defaultProps = {
  displayHeading: 'Order History',
  displayBackLabel: 'Back to store',
  displayBackLink: '#',
  accountHomeUrl: '#',
};
