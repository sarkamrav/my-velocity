import React, { useState, useEffect } from 'react';
import './order-list.scss';
import PropTypes from 'prop-types';
import Link from '../../../micro-components/Link/Link';
import { formatDateString, formatLocalePrice } from '../../../../utils/utils';
import { getShoppingUrls } from '../../../../site/js/urlresolver';
import { getCookie } from '../../../../utils/cookies_operation.js';

//Function to parse and format date
const parseDateString = dateString => {
  const [day, month, year] = dateString.split('/').map(Number);
  return new Date(year, month - 1, day);
};

const formatDate = date => {
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  return `${day}/${month}/${year}`;
};

const formatDateStringLegacy = dateString => {
  if (!dateString) {
    return '';
  }
  try {
    const date = parseDateString(dateString);
    return formatDate(date);
  } catch (error) {
    console.error('Error formatting date:', error);
    return dateString; // Return original string if formatting fails
  }
};

const OrderList = ({
  displayOrderNumber,
  displayOrderDate,
  displayCreationDate,
  displayStatus,
  displayOrderAmount,
  orderhistory,
  legacyOrderhistory,
}) => {
  const [currencyVal, setCurrencyVal] = useState('');

  useEffect(() => {
    const currencyObject = getCookie('currency');
    if (currencyObject !== null) {
      const object = JSON.parse(currencyObject);
      const currency = object?.currencySymbol;
      setCurrencyVal(currency);
    }
  }, []);

  const redirection = (orderNumber, isLegacy) => {
    const url = isLegacy
      ? `${getShoppingUrls()?.orderDetailLegacyURL}?order_number=${orderNumber}&legacy=true`
      : `${getShoppingUrls()?.orderDetailURL}?order_number=${orderNumber}`;
    window.location.href = url;
  };

  const renderOrders = (orders, isLegacy) => {
    return orders.map(order => (
      <div key={order.order_number || order.id} className="cmp-acommerce_order-list__row row-group">
        <div className="cmp-acommerce_order-list__column">
          <span className="cmp-acommerce_order-list__item">
            <span className="cmp-acommerce_order-list__item-name lg-hidden">
              <strong>{displayOrderNumber}</strong>
            </span>
            <span className="cmp-acommerce_order-list__item-value">
              <Link
                text={order.order_number || order.id}
                onClick={() => redirection(order.order_number || order.id, isLegacy)}
                link={`/${order.order_number || order.id}`}
                type="secondary"
                className="cmp-acommerce_order-list__item-link"
              />
            </span>
          </span>
        </div>
        <div className="cmp-acommerce_order-list__column">
          <span className="cmp-acommerce_order-list__item">
            <span className="cmp-acommerce_order-list__item-name lg-hidden">
              <strong>{displayOrderDate}</strong>
            </span>
            <span className="cmp-acommerce_order-list__item-value">
              {isLegacy ? formatDateStringLegacy(order.creation_date) : formatDateString(order.order_date)}
            </span>
          </span>
        </div>
        <div className="cmp-acommerce_order-list__column">
          <span className="cmp-acommerce_order-list__item">
            <span className="cmp-acommerce_order-list__item-name lg-hidden">
              <strong>{displayCreationDate}</strong>
            </span>
            <span className="cmp-acommerce_order-list__item-value">
              {isLegacy ? formatDateStringLegacy(order.creation_date) : formatDateString(order.order_date)}
            </span>
          </span>
        </div>
        <div className="cmp-acommerce_order-list__column">
          <span className="cmp-acommerce_order-list__item">
            <span className="cmp-acommerce_order-list__item-name lg-hidden">
              <strong>{displayStatus}</strong>
            </span>
            <span className="cmp-acommerce_order-list__item-value">{order.status}</span>
          </span>
        </div>
        <div className="cmp-acommerce_order-list__column">
          <span className="cmp-acommerce_order-list__item">
            <span className="cmp-acommerce_order-list__item-name lg-hidden">
              <strong>{displayOrderAmount}</strong>
            </span>
            <span className="cmp-acommerce_order-list__item-value">
              {formatLocalePrice(isLegacy ? order.total : order.total?.grand_total?.value, currencyVal)}
            </span>
          </span>
        </div>
      </div>
    ));
  };

  return (
    <div className="cmp-acommerce_order-list">
      <div className="cmp-acommerce_order-list__header sm-hidden">
        <div className="cmp-acommerce_order-list__row">
          <div className="cmp-acommerce_order-list__column">
            <span className="cmp-acommerce_order-list__item">
              <span className="cmp-acommerce_order-list__item-name">
                <strong>{displayOrderNumber}</strong>
              </span>
            </span>
          </div>
          <div className="cmp-acommerce_order-list__column">
            <span className="cmp-acommerce_order-list__item">
              <span className="cmp-acommerce_order-list__item-name">
                <strong>{displayOrderDate}</strong>
              </span>
            </span>
          </div>
          <div className="cmp-acommerce_order-list__column">
            <span className="cmp-acommerce_order-list__item">
              <span className="cmp-acommerce_order-list__item-name">
                <strong>{displayCreationDate}</strong>
              </span>
            </span>
          </div>
          <div className="cmp-acommerce_order-list__column">
            <span className="cmp-acommerce_order-list__item">
              <span className="cmp-acommerce_order-list__item-name">
                <strong>{displayStatus}</strong>
              </span>
            </span>
          </div>
          <div className="cmp-acommerce_order-list__column">
            <span className="cmp-acommerce_order-list__item">
              <span className="cmp-acommerce_order-list__item-name">
                <strong>{displayOrderAmount}</strong>
              </span>
            </span>
          </div>
        </div>
      </div>
      <div className="cmp-acommerce_order-list__body">
        {orderhistory && renderOrders(orderhistory, false)}
        {legacyOrderhistory && renderOrders(legacyOrderhistory, true)}
      </div>
    </div>
  );
};

OrderList.propTypes = {
  displayOrderNumber: PropTypes.string,
  displayOrderDate: PropTypes.string,
  displayCreationDate: PropTypes.string,
  displayStatus: PropTypes.string,
  displayOrderAmount: PropTypes.string,
  orderhistory: PropTypes.array,
  legacyOrderhistory: PropTypes.array,
};

OrderList.defaultProps = {
  displayOrderNumber: 'Order Number',
  displayOrderDate: 'Order Date',
  displayCreationDate: 'Creation Date',
  displayStatus: 'Status',
  displayOrderAmount: 'Order Amount',
};

export default OrderList;
