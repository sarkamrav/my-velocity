import React, { useEffect, useState } from 'react';
import './order-tab.scss';
import OrderList from '../OrderList/OrderList';
import { useQuery, useLazyQuery } from '@apollo/client';
import ORDER_HISTORY from '../../../../site/js/gql/order-history.gql';
import ORDER_LEGACY_HISTORY from '../../../../site/js/gql/order-legacy-history.gql';
import Loader from '../../../micro-components/Loader/Loader';

const OrderTab = restProps => {
  const { loading: queryLoading, data: queryData } = useQuery(ORDER_HISTORY, {
    onCompleted: data => {
      getLegacyOrderData();
      console.log('Order History:', data);
    },
  });

  const [getLegacyOrderData, { data: legacyData }] = useLazyQuery(ORDER_LEGACY_HISTORY);

  const [orderhistory, setOrderHostory] = useState(null);
  const [legacyOrderhistory, setLegacyOrderHistory] = useState(null);
  const [activeTab, setActiveTab] = useState('Commerce orders');

  useEffect(() => {
    if (legacyData) {
      setLegacyOrderHistory(legacyData);
      console.log('Legacy Order History:', legacyData);
    }
    if (queryData) {
      setOrderHostory(queryData);
      console.log('Order History if:', queryData);
    }
  }, [legacyData, queryData]);

  const orderhistoryList = orderhistory?.core_customer?.orders?.items;
  const legacyOrderHistoryList = legacyOrderhistory?.core_drOrders;

  const tabs = ['Commerce orders', 'Archive orders'];

  return (
    <div className="cmp-acommerece-order-tab">
      {queryLoading && <Loader/>}
      <div className="tabs">
        {tabs.map(tab => (
          <div key={tab} className={`tab ${activeTab === tab ? 'selected' : ''}`} onClick={() => setActiveTab(tab)}>
            {tab}
            <div className={`tab-line ${activeTab === tab ? 'active' : ''}`}></div>
          </div>
        ))}
      </div>
      <div className="tab-content">
        {activeTab === 'Commerce orders' && <OrderList {...restProps} orderhistory={orderhistoryList} />}
        {activeTab === 'Archive orders' && <OrderList {...restProps} legacyOrderhistory={legacyOrderHistoryList} />}
      </div>
    </div>
  );
};

export default OrderTab;
