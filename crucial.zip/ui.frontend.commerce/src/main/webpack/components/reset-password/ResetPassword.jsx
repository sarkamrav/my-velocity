import React, { useState, useEffect } from 'react';
import { gql, useMutation } from '@apollo/client';
import { Formik, Form } from 'formik';
import * as Yup from 'yup';
import InputField from '../inputfield/InputField';
import LayoutContainer from '../product-list-page/components/layoutcontainer/LayoutContainer';
import Loader from '../micro-components/Loader/Loader';
import Button from '../micro-components/Button/Button';
import { RESET_PASSWORD } from '../../site/js/gql/mutations/resetPassword.gql';
import ResetSuccess from './component/resetsuccess/ResetSuccess';

export default function ResetPassword(props) {
  const { resetPasswordTitle, resetPasswordCta, resetFormDescription, passwordLabel, verifyPasswordLabel } = props;
  const [submitted, setSubmitted] = useState(false);
  const [resetPassword, { loading, error, data: resetData }] = useMutation(RESET_PASSWORD);
  const [resetPasswordToken, setResetPasswordToken] = useState('');
  const [userEmail, setUserEmail] = useState('');

  const validationSchema = Yup.object().shape({
    password: Yup.string()
      .required('Please enter a password')
      .min(8, 'Password must be between 8 - 32 characters.')
      .max(32, 'Password must be between 8 - 32 characters.'),
    verifyPassword: Yup.string()
      .oneOf([Yup.ref('password'), null], 'The passwords do not match. Enter matching passwords.')
      .required('Please verify your password'),
  });

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const token = params.get('token');
    const email = params.get('email');

    if (token) {
      setResetPasswordToken(token);
    }
    if (email) {
      setUserEmail(decodeURIComponent(encodeURIComponent(email).replace(/%20/g, '+')));
    }
  }, []);

  const handleSubmit = async (values, { setSubmitting }) => {
    const { password } = values;
    try {
      const response = await resetPassword({
        variables: {
          email: userEmail, // Replace with the actual email from your form or props
          resetPasswordToken: resetPasswordToken, // Replace with the actual token
          newPassword: password,
        },
      });
    } catch (error) {
      console.error('resetaccount:', error);
    }
  };

  useEffect(() => {
    if (resetData?.core_resetPassword) {
      setSubmitted(resetData?.core_resetPassword);
    }
  }, [resetData]);

  return (
    <LayoutContainer>
      <>
        {loading && <Loader />}

        {!submitted && (
          <Formik
            initialValues={{
              password: '',
              verifyPassword: '',
            }}
            validationSchema={validationSchema}
            onSubmit={handleSubmit}>
            {({ isSubmitting }) => (
              <div className="resetpassword">
                <p className="resetpassword__title">{resetPasswordTitle}</p>
                {/* <div className="divider"></div> */}
                <div className="crucialformlogincontainer__description">{resetFormDescription}</div>
                {error && <div className="submiterror">{error?.message}</div>}
                <Form className="resetpassword__formcontainer">
                  <div className="resetpassword__formcontainer--form">
                    <InputField name="password" label={passwordLabel} type="password" isMandatory />
                    <InputField name="verifyPassword" label={verifyPasswordLabel} type="password" isMandatory />
                  </div>
                  <div className="resetpassword__formcontainer--cta">
                    <Button size="small" disabled={isSubmitting}>
                      {resetPasswordCta}
                    </Button>
                  </div>
                </Form>
              </div>
            )}
          </Formik>
        )}
        {submitted && <ResetSuccess {...props} />}
      </>
    </LayoutContainer>
  );
}
