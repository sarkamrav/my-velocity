import React from 'react';
import Button from '../../../micro-components/Button/Button';
import LoginForm from '../../../login/component/loginform/LoginForm.jsx';
import CreateAccount from '../../../create-account/CreateAccount.jsx';
import ForgetPassword from '../../../forget-password/ForgetPassword.jsx';
import useModal from '../../../../hooks/useModal.jsx';
import ModalPopup from '../../../modal-popup/ModalPopup.jsx';

function ResetSuccess(props) {
  const { rpThankyouTitle, backToLoginCta, rpDescriptionTitle, continueShoppingCta } = props;
  const { isShowing: isLoginConfirmation, toggle: loginToggleConfirmation } = useModal();
  const { isShowing: isCAConfirmation, toggle: caToggleConfirmation } = useModal();
  const { isShowing: isForgetPasswordLogin, toggle: forgetToggleConfirmation } = useModal();

  const forgetPasswordHandler = () => {
    loginToggleConfirmation();
    forgetToggleConfirmation();
    // setSignupForm(false);
    // setForgetPasswordForm(true);
  };

  const cancelFormHandler = () => {
    loginToggleConfirmation();
  };

  const createAccountHandler = event => {
    console.log('event', event);
    if (event === 'login') {
      caToggleConfirmation();
      loginToggleConfirmation();
    }

    if (event === 'shopping') {
      //needs to verify
      caToggleConfirmation();
      loginToggleConfirmation();
    }
  };

  const handleUserForm = () => {
    loginToggleConfirmation();
    caToggleConfirmation();
  };

  const resetsuccessHandler = () => {
    window.location.href = '/';
  };
  return (
    <div className="resetsuccess">
      <p className="resetsuccess__title">{rpThankyouTitle}</p>
      <span className="resetsuccess__subtitle">{rpDescriptionTitle}</span>

      <p className="resetsuccess__linkwrapper">
        <Button
          type="primary"
          size="small"
          onClick={() => {
            loginToggleConfirmation();
          }}>
          {backToLoginCta}
        </Button>
        <Button type="primary" size="small" onClick={() => resetsuccessHandler('shopping')}>
          {continueShoppingCta}
        </Button>
      </p>
      {isLoginConfirmation && (
        <ModalPopup isShowing={isLoginConfirmation} hide={loginToggleConfirmation} className="auth-popup">
          <LoginForm changeFormHandler={handleUserForm} forgetPasswordHandler={forgetPasswordHandler} {...props} />
        </ModalPopup>
      )}
      {isCAConfirmation && (
        <ModalPopup className="auth-popup" isShowing={isCAConfirmation} hide={caToggleConfirmation}>
          <CreateAccount cancelFormHandler={cancelFormHandler} createAccountHandler={createAccountHandler} {...props} />
        </ModalPopup>
      )}
      {isForgetPasswordLogin && (
        <ModalPopup isShowing={isForgetPasswordLogin} hide={forgetToggleConfirmation} className="auth-popup">
          <ForgetPassword
            cancelFormHandler={cancelFormHandler}
            forgetPasswordHandler={forgetPasswordHandler}
            {...props}
          />
        </ModalPopup>
      )}
    </div>
  );
}

export default ResetSuccess;
