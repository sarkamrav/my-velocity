import React, { useEffect, useState, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { Formik, Form } from 'formik';
import * as Yup from 'yup';
import InputField from '../inputfield/InputField';
import Link from '../micro-components/Link/Link';
import PropTypes from 'prop-types';
import Button from '../micro-components/Button/Button';
import { useMutation, useQuery, useLazyQuery } from '@apollo/client';
import { COUNTRY_QUERY } from '../../site/js/gql/countries.gql';
import { STATE_QUERY } from '../../site/js/gql/states.gql';
import { CREATE_ADDRESS } from '../../site/js/gql/mutations/createAddress.gql';
import { GET_ADDRESS } from '../../site/js/gql/get-address.gql';
import { UPDATE_ADDRESS } from '../../site/js/gql/mutations/updateAddress.gql';
import { DELETE_ADDRESS } from '../../site/js/gql/mutations/deleteAddress.gql';
import { DEFAULT_ADDRESS } from '../../site/js/gql/mutations/defaultAddress.gql';
import Dropdown from '../micro-components/Dropdown/Dropdown';
import Loader from '../micro-components/Loader/Loader';
import Icon from '../../assests/Icon';
import { clientConfigUsingGet } from '../../configs/ReactApolloClientSetup/ApolloClientConfig.js';

const AddressBook = ({
  displayHeading,
  displaySubHeading,
  displayNicknameLabel,
  displayNicknameError,
  displayFirstnameLabel,
  displayFirstnameError,
  displayLastnameLabel,
  displayLastnameError,
  displayAddressLine1,
  displayAddressLine1Error,
  displayAddressLine2,
  displayCity,
  displayCityError,
  displayState,
  displayStateError,
  displayZipCode,
  displayZipCodeError,
  displayCountry,
  displayCountryError,
  displayCompanyName,
  displayPhoneNumber,
  displayPhoneNumberError,
  displayReset,
  displaySubmit,
  displayBackLabel,
  displayBackLink,
  displaySavedAddressesHeading,
  displayEdit,
  displayDelete,
  displaySaveDefault,
  displayAddAddress,
  displayAddAddressLink,
  displayDefault,
  selectState,
  selectCountry,
  addressCreated,
  addressUpdated,
  addressDeleted,
}) => {
  const initialValues = {
    nickname: '',
    firstname: '',
    lastname: '',
    addressLine1: '',
    addressLine2: '',
    city: '',
    state: '',
    postcode: '',
    country_code: '',
    company: '',
    telephone: '',
  };

  // For later use to store form data
  const [formData, setFormData] = useState(initialValues);

  // To populate dropdowns with an initial state
  const initialOptions = [
    {
      options: [
        {
          value: '',
          label: selectCountry,
        },
      ],
    },
  ];

  const initialStates = [
    {
      options: [
        {
          value: '',
          label: selectState,
        },
      ],
    },
  ];

  // Initial values for countries and states to be later populated by the API
  const [countries, setCountries] = useState(initialOptions);
  const [states, setStates] = useState(initialStates);
  const [addresses, setAddresses] = useState([]);

  // Variable to trigger the State query when country is selected
  const [selectedCountry, setSelectedCountry] = useState('');

  // To decide between submitting and editing the form and hit the respective API
  const [isEditing, setIsEditing] = useState(false);
  const [editingAddress, setEditingAddress] = useState({});
  const [currentAddressId, setCurrentAddressId] = useState(null);

  // To show the success messages
  const [createSuccess, setCreateSuccess] = useState(false);
  const [updateSuccess, setUpdateSuccess] = useState(false);
  const [deleteSuccess, setDeleteSuccess] = useState(false);

  const [errorMessage, setErrorMessage] = useState('');

  const getValidationSchema = () =>
    Yup.object({
      nickname: Yup.string().required(`${displayNicknameError}`),
      firstname: Yup.string().required(`${displayFirstnameError}`),
      lastname: Yup.string().required(`${displayLastnameError}`),
      addressLine1: Yup.string().required(`${displayAddressLine1Error}`),
      city: Yup.string().required(`${displayCityError}`),
      // state: Yup.string().required(`${displayStateError}`),
      state:
        states && states[0]?.options?.length > 1 ? Yup.string().required(displayStateError) : Yup.string().nullable(),
      postcode: Yup.string().required(`${displayZipCodeError}`),
      country_code: Yup.string().required(`${displayCountryError}`),
      telephone: Yup.string().required(`${displayPhoneNumberError}`),
      company: Yup.string(),
    });

  // To get addresses on page load
  const {
    loading: addressQueryLoading,
    error: addressQueryError,
    data: addressQueryData,
    refetch: addressRefetch,
  } = useQuery(GET_ADDRESS);

  // To get countries on page load
  const gqlClientFotGet = useMemo(() => clientConfigUsingGet(), []);
  const {
    loading: countryQueryLoading,
    error: countryQueryError,
    data: countryQueryData,
  } = useQuery(COUNTRY_QUERY, { client: gqlClientFotGet });

  // To get states on selecting a country
  const [getStates, { loading: stateQueryLoading, error: stateQueryError, data: stateQueryData }] =
    useLazyQuery(STATE_QUERY);

  // Create Address mutation
  const [createAddress, { loading: createAddressLoading, error: createAddressError, data: createAddressData }] =
    useMutation(CREATE_ADDRESS);

  // Update address mutation
  const [updateAddress, { loading: updateAddressLoading, error: updateAddressError, data: updateAddressData }] =
    useMutation(UPDATE_ADDRESS);

  // Delete address mutation
  const [deleteAddress, { loading: deleteAddressLoading, error: deleteAddressError, data: deleteAddressData }] =
    useMutation(DELETE_ADDRESS);

  // Default address mutation
  const [setDefaultAddress, { loading: defaultAddressLoading, error: defaultAddressError, data: defaultAddressData }] =
    useMutation(DEFAULT_ADDRESS);

  // Addresses available for the customer
  useEffect(() => {
    if (addressQueryData) {
      setAddresses(addressQueryData.core_customer.addresses);
    }
  }, [addressQueryData]);

  // To populate countries on receiving from API
  useEffect(() => {
    if (countryQueryData) {
      let countriesArrayOptions = initialOptions;
      [...countryQueryData.core_countries]
        .sort((a, b) => a.full_name_english.localeCompare(b.full_name_english))
        .map(item => {
          countriesArrayOptions.map(countriesOptions => {
            countriesOptions.options.push({
              value: item.id,
              label: item.full_name_english,
            });
          });
        });
      setCountries(countriesArrayOptions);
    }
  }, [countryQueryData]);

  // To trigger states query when a country is selected
  useEffect(() => {
    if (selectedCountry) {
      getStates({ variables: { id: selectedCountry } })
        .then(states => {
          if (states.data.core_country.available_regions) {
            const stateArrayOptions = initialStates;
            const statesFromApi = states.data.core_country.available_regions;
            [...statesFromApi]
              .sort((a, b) => a.name.localeCompare(b.name))
              .map(state => {
                stateArrayOptions.map(stateOption => {
                  stateOption.options.push({
                    value: state.code,
                    label: state.name,
                  });
                });
              });
            setStates(stateArrayOptions);
          } else {
            setStates(initialStates);
          }
        })
        .catch(error => console.log(`Server responed with an error - ${error.message}`));
    } else {
      setStates(initialStates);
    }
  }, [selectedCountry]);

  // Handler to delete addresses
  const handleDelete = (e, id) => {
    e.preventDefault();
    setErrorMessage('');
    deleteAddress({
      variables: {
        id: id,
      },
    })
      .then(() => {
        let updatedAddresses = addresses.filter(address => address.id !== id);
        setAddresses(updatedAddresses);
        setEditingAddress({});
        setIsEditing(false);
        setErrorMessage('');
        setDeleteSuccess(true);
        setTimeout(() => setDeleteSuccess(false), 5000);
      })
      .catch(error => console.log(`Server responed with an error - ${error.message}`));
  };

  // Handler to edit an address
  const handleEdit = (e, address) => {
    e.preventDefault();
    setIsEditing(true);
    setEditingAddress(address);
    setErrorMessage('');
    setCurrentAddressId(address.id);
    getStates({ variables: { id: address.country_code } })
      .then(states => {
        if (states.data.core_country.available_regions) {
          const stateArrayOptions = initialStates;
          const statesFromApi = states.data.core_country.available_regions;
          statesFromApi.map(state => {
            stateArrayOptions.map(stateOption => {
              stateOption.options.push({
                value: state.code,
                label: state.name,
              });
            });
          });
          setStates(stateArrayOptions);
        } else {
          setStates(initialStates);
        }
      })
      .catch(error => console.log(`Server responed with an error - ${error.message}`));
  };

  // Effect to populate form when editing an address
  useEffect(() => {
    if (isEditing) {
      setFormData(prev => ({
        ...prev,
        country_code: editingAddress?.country_code,
        state: editingAddress?.region?.region_code || '',
        city: editingAddress?.city,
        nickname: editingAddress?.custom_attributes?.[0]?.value || '',
        firstname: editingAddress?.firstname,
        lastname: editingAddress?.lastname,
        addressLine1: editingAddress?.street[0],
        addressLine2: editingAddress?.street[1] || '',
        postcode: editingAddress?.postcode,
        company: editingAddress?.company || '',
        telephone: editingAddress?.telephone,
      }));
      document.querySelector('input[name="nickname"]').focus();
    }
  }, [states, editingAddress]);

  // Handler to set an address as default
  const handleDefault = (e, id) => {
    e.preventDefault();
    setDefaultAddress({
      variables: {
        id: id,
        default_shipping: true,
        default_billing: true,
      },
    })
      .then(() => addressRefetch())
      .catch(error => console.log(`Server responed with an error - ${error.message}`));
  };

  // Handler to reset the form
  const handleReset = (e, resetForm) => {
    e.preventDefault();
    setIsEditing(false);
    setEditingAddress({});
    resetForm();
    setFormData(initialValues);
    setSelectedCountry('');
  };

  // Handler to submit data and add/edit address
  const handleSubmit = (values, resetForm) => {
    const state = stateQueryData.core_country.available_regions?.find(item => item.code === values.state);
    let streets = [values.addressLine1];
    if (values.addressLine2) {
      streets.push(values.addressLine2);
    }

    if (!isEditing) {
      createAddress({
        variables: {
          ...values,
          region_id: state?.id || null,
          region: state?.name || '',
          region_code: state?.code || '',
          street: streets,
        },
      })
        .then(() => {
          addressRefetch();
          setErrorMessage('');
          setCreateSuccess(true);
          setEditingAddress({});
          setIsEditing(false);
          setTimeout(() => setCreateSuccess(false), 5000);
        })
        .then(() => {
          resetForm();
          setStates(initialStates);
          setFormData(initialValues);
        })
        .catch(error => console.log(`Server responed with an error - ${error.message}`));
    } else {
      updateAddress({
        variables: {
          ...values,
          region_id: state?.id || null,
          region: state?.name || '',
          region_code: state?.code || '',
          street: streets,
          id: currentAddressId,
        },
      })
        .then(() => {
          let editedAddressIndex = addresses?.findIndex(address => address.id === currentAddressId);
          if (editedAddressIndex !== -1) {
            const updatedAddress = {
              ...addresses[editedAddressIndex],
              ...values,
              region: {
                region_id: state?.id || null,
                region: state?.name || '',
                region_code: state?.code || '',
              },
              street: streets,
              custom_attributes: [
                {
                  attribute_code: 'nick_name',
                  value: values.nickname,
                },
              ],
            };
            const updatedAddresses = [
              ...addresses.slice(0, editedAddressIndex),
              updatedAddress,
              ...addresses.slice(editedAddressIndex + 1),
            ];
            setAddresses(updatedAddresses);
          }
          setEditingAddress({});
          setIsEditing(false);
          resetForm();
          setFormData(initialValues);
          setSelectedCountry('');
          setErrorMessage('');
          setUpdateSuccess(true);
          setTimeout(() => setUpdateSuccess(false), 5000);
        })
        .catch(error => console.log(`Server responed with an error - ${error.message}`));
    }
  };

  // we are setting error message received from api into state
  // so that we can clear it in further different api calls
  useEffect(() => {
    if (
      createAddressError?.message ||
      updateAddressError?.message ||
      deleteAddressError?.message ||
      defaultAddressError?.message ||
      countryQueryError?.message ||
      stateQueryError?.message
    ) {
      setErrorMessage(
        createAddressError?.message ||
          updateAddressError?.message ||
          deleteAddressError?.message ||
          defaultAddressError?.message ||
          countryQueryError?.message ||
          stateQueryError?.message
      );
    }
  }, [
    createAddressError?.message,
    updateAddressError?.message,
    deleteAddressError?.message,
    defaultAddressError?.message,
    countryQueryError?.message,
    stateQueryError?.message,
  ]);

  const messageDisplay = () => {
    if (createSuccess) {
      return <div className="submitsuccess">{addressCreated}</div>;
    } else if (updateSuccess) {
      return <div className="submitsuccess">{addressUpdated}</div>;
    } else if (deleteSuccess) {
      return <div className="submitsuccess">{addressDeleted}</div>;
    } else if (errorMessage) {
      return <div className="submiterror">{errorMessage}</div>;
    }
  };

  // Formik validation schema logic needs to be at the end of all useEffects, so that
  // variable changes are registered properly here
  const [validationSchema, setValidationSchema] = useState(getValidationSchema());

  // Effect to update validation schema when shipping address form changes
  useEffect(() => {
    setValidationSchema(getValidationSchema());
  }, [states]);
  // ----------------Formik and Yup code ends here--------------

  return (
    <section className="cmp-acommerce_addressbook__section addressbook">
      <div className="custom-container">
        <div className="cmp-acommerce_addressbook__main row">
          <div className="cmp-acommerce_addressbook__form column small-12 medium-8">
            <h2 className="cmp-acommerce_addressbook__heading">{displayHeading}</h2>
            <div className="cmp-acommerce_addressbook__sub-heading">
              <p>{displaySubHeading}</p>
            </div>
            <Formik
              initialValues={formData}
              validationSchema={validationSchema}
              onSubmit={(values, { resetForm }) => {
                handleSubmit(values, resetForm);
              }}
              enableReinitialize>
              {({ values, setFieldValue, resetForm, isSubmitting, errors }) => {
                useEffect(() => {
                  if (isSubmitting) {
                    document?.querySelector('.form-input-error')?.previousElementSibling?.lastChild?.focus();
                  }
                }, [isSubmitting, errors]);
                useEffect(() => {
                  if (values.country_code) {
                    setSelectedCountry(values.country_code);
                    setFieldValue('state', values.state);
                  } else {
                    setSelectedCountry('');
                    setFieldValue('state', '');
                    setFieldValue('country_code', '');
                  }
                }, [values.country_code]);

                return (
                  <Form>
                    <div className="cmp-acommerce_addressbook__form-container">
                      {messageDisplay()}
                      <div className="cmp-acommerce_addressbook__form-fieldset">
                        <InputField
                          name="nickname"
                          label={displayNicknameLabel}
                          type="text"
                          hidden={true}
                          isMandatory
                        />
                        <InputField
                          name="firstname"
                          label={displayFirstnameLabel}
                          type="text"
                          hidden={true}
                          isMandatory
                        />
                        <InputField
                          name="lastname"
                          label={displayLastnameLabel}
                          type="text"
                          hidden={true}
                          isMandatory
                        />
                        <InputField
                          name="addressLine1"
                          label={displayAddressLine1}
                          type="text"
                          hidden={true}
                          isMandatory
                        />
                        <InputField name="addressLine2" label={displayAddressLine2} type="text" hidden={true} />
                        <InputField name="city" label={displayCity} type="text" hidden={true} isMandatory />
                        {/* <InputField name="state" label={displayState} type="select" options={states} /> */}
                        <Dropdown
                          className="input-field-wrapper"
                          options={states}
                          name="state"
                          label={displayState}
                          isMandatory={states[0].options.length > 1}
                          isDisabled={states[0].options.length > 1 ? false : true}
                        />
                        <InputField name="postcode" label={displayZipCode} type="text" hidden={true} isMandatory />
                        <Dropdown
                          className="input-field-wrapper"
                          options={countries}
                          name="country_code"
                          label={displayCountry}
                          isMandatory
                        />
                        <InputField name="company" label={displayCompanyName} type="text" hidden={true} />
                        <InputField name="telephone" label={displayPhoneNumber} type="text" hidden={true} isMandatory />
                      </div>
                      <div className="cmp-acommerce_addressbook__form-actions">
                        <Button>{displaySubmit}</Button>
                        <Button type="secondary" onClick={e => handleReset(e, resetForm, setFieldValue, values)}>
                          {displayReset}
                        </Button>
                      </div>
                    </div>
                    <div className="back-link sm-hidden">
                      <Icon name="ArrowLeft" />
                      <Link text={displayBackLabel} type="back" href={displayBackLink} />
                    </div>
                  </Form>
                );
              }}
            </Formik>
          </div>
          <div className="cmp-acommerce_addressbook__addresses column small-12 medium-4 large-3 large-offset-1">
            <h5 className="cmp-acommerce_addressbook__heading-small">{displaySavedAddressesHeading}</h5>
            <div className="cmp-acommerce_addressbook__addresses-container">
              {addressQueryError ? (
                <div className="submiterror">{addressQueryError?.message}</div>
              ) : (
                <>
                  <Link
                    type="default"
                    text={`+ ${displayAddAddress}`}
                    link={displayAddAddressLink}
                    className="add-new-address-link"
                  />
                  {addresses.length ? (
                    addresses?.map((address, index) => (
                      <div className="address-box" key={`${address.address_heading}-${index + 1}`}>
                        {address.default_shipping && address.default_billing && (
                          <div className="default-address-flag">
                            <Icon name="FilledStar" />
                            <span>{displayDefault}</span>
                          </div>
                        )}
                        <span className="addressbook_addrHeading">
                          <strong>{address?.custom_attributes && address?.custom_attributes[0]?.value}</strong>
                        </span>
                        <span className="addressbook_addrName">{`${address.firstname} ${address.lastname}`}</span>
                        <span className="addressbook_companyName">{address.company}</span>
                        <span className="addressbook_addressLine1">{address.street[0]}</span>
                        <span className="addressbook_addressLine2">{address?.street[1]}</span>
                        <span className="addressbook_location">{`${address.city}, ${
                          address.region.region !== null ? address.region.region : ''
                        } ${address.postcode}`}</span>
                        <span className="addressbook_country">{address.country_code}</span>
                        <span className="addressbook_phoneNumber">{address.telephone}</span>
                        <div className="addressbook-link-group">
                          <Link
                            type="secondary"
                            text={displayEdit}
                            link="#"
                            className="addressbook-link"
                            onClick={e => handleEdit(e, address)}
                          />
                          {!address.default_shipping && (
                            <>
                              <span className="seperator">|</span>
                              <Link
                                type="secondary"
                                text={displayDelete}
                                link="#"
                                className="addressbook-link"
                                onClick={e => handleDelete(e, address.id)}
                              />
                              <span className="seperator">|</span>
                              <Link
                                type="secondary"
                                text={displaySaveDefault}
                                link="#"
                                className="addressbook-link"
                                onClick={e => handleDefault(e, address.id)}
                              />
                            </>
                          )}
                        </div>
                      </div>
                    ))
                  ) : (
                    <p>No saved addresses</p>
                  )}
                </>
              )}
            </div>
            <div className="back-link lg-hidden">
              <Icon name="ArrowLeft" />
              <Link text={displayBackLabel} type="back" href={displayBackLink} />
            </div>
          </div>
          {(countryQueryLoading ||
            stateQueryLoading ||
            addressQueryLoading ||
            updateAddressLoading ||
            deleteAddressLoading ||
            defaultAddressLoading ||
            createAddressLoading) &&
            createPortal(<Loader />, document.body)}
        </div>
      </div>
    </section>
  );
};

AddressBook.propTypes = {
  displayHeading: PropTypes.string,
  displaySubHeading: PropTypes.string,
  displayNicknameLabel: PropTypes.string,
  displayNicknameError: PropTypes.string,
  displayFirstnameLabel: PropTypes.string,
  displayFirstnameError: PropTypes.string,
  displayLastnameLabel: PropTypes.string,
  displayLastnameError: PropTypes.string,
  displayAddressLine1: PropTypes.string,
  displayAddressLine1Error: PropTypes.string,
  displayAddressLine2: PropTypes.string,
  displayCity: PropTypes.string,
  displayCityError: PropTypes.string,
  displayState: PropTypes.string,
  displayStateError: PropTypes.string,
  displayZipCode: PropTypes.string,
  displayZipCodeError: PropTypes.string,
  displayCountry: PropTypes.string,
  displayCountryError: PropTypes.string,
  displayCompanyName: PropTypes.string,
  displayPhoneNumber: PropTypes.string,
  displayPhoneNumberError: PropTypes.string,
  displayReset: PropTypes.string,
  displaySubmit: PropTypes.string,
  displayBackLabel: PropTypes.string,
  displayBackLink: PropTypes.string,
  displaySavedAddressesHeading: PropTypes.string,
  displayEdit: PropTypes.string,
  displayDelete: PropTypes.string,
  displaySaveDefault: PropTypes.string,
  displayAddAddress: PropTypes.string,
  displayAddAddressLink: PropTypes.string,
};

AddressBook.defaultProps = {
  displayHeading: 'Address book',
  displaySubHeading:
    'Please complete the fields below and click the "submit" button to add a new address to your account.',
  displayNicknameLabel: 'Nickname',
  displayNicknameError: 'Please enter your nickname',
  displayFirstnameLabel: 'First Name',
  displayFirstnameError: 'Please enter your first name',
  displayLastnameLabel: 'Last Name',
  displayLastnameError: 'Please enter your last name',
  displayAddressLine1: 'Address Line 1',
  displayAddressLine1Error: 'Please enter your street address',
  displayAddressLine2: 'Address Line 2',
  displayCity: 'City',
  displayCityError: 'Please enter your city',
  displayState: 'State',
  displayStateError: 'Enter a valid value.',
  displayZipCode: 'Zip Code',
  displayZipCodeError: 'Please enter your postal code',
  displayCountry: 'Country',
  displayCountryError: 'Please enter your country',
  displayCompanyName: 'Company Name',
  displayPhoneNumber: 'Phone Number',
  displayPhoneNumberError: 'Please enter a valid phone number',
  displayReset: 'Reset',
  displaySubmit: 'Submit',
  displayBackLabel: 'Account home',
  displayBackLink: '#',
  displaySavedAddressesHeading: 'Saved addresses',
  displayEdit: 'Edit',
  displayDelete: 'Delete',
  displaySaveDefault: 'Set as default',
  displayAddAddress: 'Add new address',
  displayAddAddressLink: '#',
  displayDefault: 'Default',
};

export default AddressBook;
