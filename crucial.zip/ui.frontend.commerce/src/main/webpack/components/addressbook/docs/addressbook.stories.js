import Addressbook from "../addressbook.hbs";

export default {
  title: "Components/React Component/Addressbook",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { Addressbook };
