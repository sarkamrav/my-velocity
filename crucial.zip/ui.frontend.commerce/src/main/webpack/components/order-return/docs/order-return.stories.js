import OrderReturn from "../order-return.hbs";

export default {
  title: "Components/React Component/Order-Return",
  // More on argTypes: https://storybook.js.org/docs/html/api/argtypes
  argTypes: {},
};

export { OrderReturn };
