import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { formatDateString } from '../../../../utils/utils';
import Link from '../../../micro-components/Link/Link';
import { getShoppingUrls } from '../../../../site/js/urlresolver';
import Icon from '../../../../assests/Icon';
import { getCookie } from '../../../../utils/cookies_operation.js';

const ReturnInfo = ({
  displayOrderNumber,
  displayOrderDate,
  displayQuantity,
  displayProductName,
  displayProductPrice,
  displayProductSku,
  displayQuantityAvailable,
  displayQuantityReturn,
  displayPleaseChoose,
  displayPleaseChooseMultiple,
  displayReturnAll,
  displayOutOfRange,
  displayVerifyReturn,
  displayVerifyEmail,
  orderDetail,
  selectedProducts,
  setSelectedProducts,
  productQty,
  setProductQty,
  setRangeError,
  ready,
  noItemsToReturn,
  itemsToReturn,
  setItemsToReturn,
}) => {
  const itemsList = orderDetail?.core_customer?.orders?.items[0];
  const returnableItemsFromAPI = orderDetail?.core_customer?.orders?.items[0]?.returns?.items;
  let orderItems = returnableItemsFromAPI.flatMap(returnObj => returnObj.items.map(item => item.order_item));
  // const orderid = orderDetail?.core_customer?.orders?.items[0].id;
  // const returnableItems = orderDetail?.core_customer?.orders?.items[0]?.items.filter(
  //   item => item.eligible_for_return === true && item.quantity_ordered - item?.quantity_returned > 0
  //   // item => item.eligible_for_return === true
  // );
  // Create a function to check if an item is in the second array
  function isInSecondArray(item, itemsSec) {
    return itemsSec.some(secItem => secItem.id === item.id && secItem.product_sku === item.product_sku);
  }
  const returnableItems = orderDetail?.core_customer?.orders?.items[0]?.items.filter(
    item => !isInSecondArray(item, orderItems) && item.quantity_ordered - item?.quantity_returned > 0
  );

  const userEmail = orderDetail?.core_customer?.email;

  const [isItemsSet, setItems] = useState(true);

  useEffect(() => {
    if (returnableItems?.length === 1 && isItemsSet) {
      setItemsToReturn([
        {
          order_item_uid: returnableItems[0]?.id,
          quantity_to_return: returnableItems[0]?.quantity_ordered - returnableItems[0]?.quantity_returned,
          selected_custom_attributes: { attribute_code: 'reason', value: '' },
          product_name: returnableItems[0]?.product_name,
          price: returnableItems[0]?.product_sale_price?.value,
        },
      ]);
      setItems(false);
    }
  }, [returnableItems]);
  const currencySymbol = (getCookie('currency') && JSON.parse(getCookie('currency')).currencySymbol) || '';

  const [quantityInputs, setQuantityInputs] = useState({});

  // To create the quantity inputs for user to enter the desired the quantity number to return
  useEffect(() => {
    returnableItems.map(item => {
      setQuantityInputs(prev => ({
        ...prev,
        [`${item?.product_sku}`]: {
          value: '1',
          min: 1,
          max: item?.quantity_ordered,
        },
      }));
    });

    if (returnableItems.length === 1) {
      document.querySelector('.product-row').classList.add('single-added');
      setSelectedProducts(prev => ({
        ...prev,
        [`${returnableItems[0]?.product_sku}`]: returnableItems[0],
      }));

      setProductQty(prev => ({
        ...prev,
        [`${returnableItems[0]?.product_sku}`]: quantityInputs[`${returnableItems[0]?.product_sku}`]?.value || 1,
      }));
    }
  }, [ready]);

  // Handler to add/remove selected products
  // Will take effect only when there are more than one products in the order
  const handleSelect = (add, product, index) => {
    if (add) {
      console.log('product', product);
      setItemsToReturn([
        ...itemsToReturn,
        {
          index: index,
          product_name: product?.product_name,
          order_item_uid: product?.id,
          price: product?.product_sale_price?.value,
          quantity_to_return: 1,
        },
      ]);
      setSelectedProducts(prev => ({
        ...prev,
        [`${product?.product_sku}`]: product,
      }));

      setProductQty(prev => ({
        ...prev,
        [`${product?.product_sku}`]: quantityInputs[`${product?.product_sku}`]?.value || 1,
      }));

      [...document.querySelectorAll('.product-row')].map((row, i) => {
        if (i === index) {
          row.classList.add('added');
        }
      });
      if (![...document.querySelectorAll('.cmp-acommerce_return-info-checkbox')].find(item => item.checked === false)) {
        document.querySelector('.cmp-acommerce_return-info-all').checked = true;
      }
    } else {
      setItemsToReturn(itemsToReturn?.filter(data => data.index !== index));

      let products = { ...selectedProducts };
      let quantities = { ...productQty };
      delete products[`${product?.product_sku}`];
      delete quantities[`${product?.product_sku}`];
      setSelectedProducts(products);
      setProductQty(quantities);
      [...document.querySelectorAll('.product-row')].map((row, i) => {
        if (i === index) {
          row.classList.remove('added');
        }
      });
      if ([...document.querySelectorAll('.cmp-acommerce_return-info-checkbox')].find(item => item.checked === false)) {
        document.querySelector('.cmp-acommerce_return-info-all').checked = false;
      }
    }
  };

  // Handler to select/deselect all
  // Will take effect only when there are more than one products in the order
  const handleAll = add => {
    if (add) {
      if (itemsToReturn.length > 0) {
        setItemsToReturn([]);
        returnableItems?.map((Item, index) => {
          console.log('Item', Item);
          setItemsToReturn(prev => [
            ...prev,
            {
              index: index,
              order_item_uid: Item?.id,
              product_name: Item?.product_name,
              quantity_to_return: Item?.quantity_ordered - Item?.quantity_returned,
              price: Item?.product_sale_price?.value,
            },
          ]);
        });
      } else {
        returnableItems?.map((Item, index) => {
          setItemsToReturn(prev => [
            ...prev,
            {
              index: index,
              order_item_uid: Item?.id,
              product_name: Item?.product_name,
              quantity_to_return: Item?.quantity_ordered - Item?.quantity_returned,
              price: Item?.product_sale_price?.value,
            },
          ]);
        });
      }

      returnableItems?.map(product => {
        setSelectedProducts(prev => ({
          ...prev,
          [`${product?.product_sku}`]: product,
        }));
      });
      Object.keys(quantityInputs)?.map(key => {
        setProductQty(prev => ({
          ...prev,
          [`${key}`]: quantityInputs[key]?.value,
        }));
      });
      [...document.querySelectorAll('.product-row')].map(row => {
        row.classList.add('added');
      });
      [...document.querySelectorAll('.cmp-acommerce_return-info-checkbox')].map(item => (item.checked = true));
    } else {
      setItemsToReturn([]);
      setSelectedProducts({});
      setProductQty({});
      [...document.querySelectorAll('.product-row')].map(row => {
        row.classList.remove('added');
      });
      [...document.querySelectorAll('.cmp-acommerce_return-info-checkbox')].map(item => (item.checked = false));
    }
  };

  // Update product quantities for the products that are selected for return
  const handleQuantity = (e, product, index) => {
    console.log('index,index', index);

    setItemsToReturn(prevItems => {
      return prevItems.map(item => (item.index === index ? { ...item, quantity_to_return: e.target.value } : item));
    });

    setQuantityInputs(prev => ({
      ...prev,
      [`${product?.product_sku}`]: {
        ...prev[`${product?.product_sku}`],
        value: e.target.value,
      },
    }));

    setProductQty(prev => ({
      ...prev,
      [`${product?.product_sku}`]: e.target.value,
    }));
  };

  // To set global input error when the value is out of range
  useEffect(() => {
    if ([...document.querySelectorAll('.value-error')].length > 0) {
      setRangeError(true);
    } else {
      setRangeError(false);
    }
  }, [quantityInputs]);

  return (
    <div className="cmp-acommerce_return-info">
      {!ready ? (
        <>
          <ul className="cmp-acommerce_return-info__list">
            {itemsList?.number && (
              <li>
                <strong>{displayOrderNumber} </strong>
                <Link
                  href={`${getShoppingUrls().orderDetailURL}?order_number=${itemsList?.number}`}
                  text={itemsList?.number}
                />
              </li>
            )}

            {itemsList?.order_date && (
              <li>
                <strong>{displayOrderDate} </strong>
                {formatDateString(itemsList?.order_date)}
              </li>
            )}
          </ul>
          {returnableItems?.length > 1 ? (
            <p className="cmp-acommerce_return-info__instruction">{displayPleaseChooseMultiple}</p>
          ) : (
            <p className="cmp-acommerce_return-info__instruction">
              <strong>{displayPleaseChoose}</strong>
            </p>
          )}
        </>
      ) : (
        <>
          <p className="cmp-acommerce_return-info__instruction">
            <strong>{displayVerifyReturn}</strong>
          </p>
          <p className="cmp-acommerce_return-info__instruction">
            {displayVerifyEmail} <span className="cmp-acommerce_return-info__email">{userEmail}</span>
          </p>
        </>
      )}

      {returnableItems?.length > 1 && !ready && (
        <div className="cmp-acommerce_return-info__return-all">
          <div className="cmp-acommerce_checkbox-input-group cmp-acommerce_return-info__checkbox-group">
            <input
              type="checkbox"
              className="cmp-acommerce_checkbox-input cmp-acommerce_return-info-all"
              onChange={e => handleAll(e.target.checked)}
            />
            <Icon name="Checkbox" />
          </div>
          <span>
            <strong>{displayReturnAll}</strong>
          </span>
        </div>
      )}

      <div className="cmp-acommerce_return-info__product-table">
        <div className="cmp-acommerce_return-info__product-table__head sm-hidden">
          <div className="product-name">
            <strong>{displayProductName}</strong>
          </div>
          <div className="product-sku">
            <strong>{displayProductSku}</strong>
          </div>
          <div className="product-price">
            <strong>{displayProductPrice}</strong>
          </div>
          <div className="product-quantity">
            <strong>{displayQuantity}</strong>
          </div>
          <div className="quantity-available">
            <strong>{displayQuantityAvailable}</strong>
          </div>
          <div className="quantity-return">
            <strong>{displayQuantityReturn}</strong>
          </div>
        </div>

        <div className="cmp-acommerce_return-info__product-table__body">
          {!ready ? (
            <>
              {returnableItems?.length == 0 && <div className="submiterror">{noItemsToReturn}</div>}
              {returnableItems?.map((product, index) => (
                <div className="product-row" key={`${product?.quantity}-${index}`}>
                  <div className="product-name">
                    <div className="product-name-label lg-hidden">{displayProductName}</div>
                    <div className="product-name-value display-flex">
                      {returnableItems?.length > 1 && (
                        <div className="cmp-acommerce_checkbox-input-group cmp-acommerce_return-info__checkbox-group">
                          <input
                            type="checkbox"
                            className="cmp-acommerce_checkbox-input cmp-acommerce_return-info-checkbox"
                            onChange={e => handleSelect(e.target.checked, product, index)}
                          />
                          <Icon name="Checkbox" />
                        </div>
                      )}
                      <span className="product-title">{product?.product_name}</span>
                    </div>
                  </div>
                  <div className="product-sku">
                    <div className="product-quantity-label lg-hidden">{displayProductSku}</div>
                    <div className="product-quantity-value">{product?.product_sku.toUpperCase()}</div>
                  </div>
                  <div className="product-price">
                    <div className="product-quantity-label lg-hidden">{displayProductPrice}</div>
                    <div className="product-quantity-value">
                      {currencySymbol}
                      {product?.product_sale_price?.value}
                    </div>
                  </div>
                  <div className="product-quantity">
                    <div className="product-quantity-label lg-hidden">{displayQuantity}</div>
                    <div className="product-quantity-value">{product?.quantity_ordered}</div>
                  </div>
                  <div className="quantity-available">
                    <div className="product-quantity-label lg-hidden">{displayQuantityAvailable}</div>
                    <div className="product-quantity-value">
                      {product?.quantity_ordered - product?.quantity_returned}
                    </div>
                  </div>
                  <div className="quantity-return">
                    <div className="product-quantity-label lg-hidden">{displayQuantityReturn}</div>
                    <div className="product-quantity-value">
                      {product?.quantity_ordered > 1 ? (
                        <>
                          <input
                            className="quantity-return-value"
                            type="number"
                            value={quantityInputs[`${product?.product_sku}`]?.value}
                            min={quantityInputs[`${product?.product_sku}`]?.min}
                            max={quantityInputs[`${product?.product_sku}`]?.max}
                            onChange={e => handleQuantity(e, product, index)}
                          />
                          {(quantityInputs[`${product?.product_sku}`]?.value >
                            quantityInputs[`${product?.product_sku}`]?.max ||
                            quantityInputs[`${product?.product_sku}`]?.value <
                              quantityInputs[`${product?.product_sku}`]?.min) &&
                            quantityInputs[`${product?.product_sku}`]?.value && (
                              <span className="submiterror value-error">{displayOutOfRange}</span>
                            )}
                        </>
                      ) : (
                        <span>{product?.quantity_ordered - product?.quantity_returned}</span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </>
          ) : (
            <>
              {Object.keys(selectedProducts)?.map((product, index) => (
                <div className="product-row" key={`${product}-${index}`}>
                  <div className="product-name">
                    <div className="product-name-label lg-hidden">{displayProductName}</div>
                    <div className="product-name-value display-flex">
                      <span className="product-title">{selectedProducts[`${product}`]?.product_name}</span>
                    </div>
                  </div>
                  <div className="product-sku">
                    <div className="product-quantity-label lg-hidden">{displayProductSku}</div>
                    <div className="product-quantity-value">
                      {selectedProducts[`${product}`]?.product_sku.toUpperCase()}
                    </div>
                  </div>
                  <div className="product-price">
                    <div className="product-quantity-label lg-hidden">{displayProductPrice}</div>
                    <div className="product-quantity-value">
                      {currencySymbol}
                      {selectedProducts[`${product}`]?.product_sale_price?.value}
                    </div>
                  </div>
                  <div className="product-quantity">
                    <div className="product-quantity-label lg-hidden">{displayQuantity}</div>
                    <div className="product-quantity-value">{selectedProducts[`${product}`]?.quantity_ordered}</div>
                  </div>
                  <div className="quantity-available">
                    <div className="product-quantity-label lg-hidden">{displayQuantityAvailable}</div>
                    <div className="product-quantity-value">{selectedProducts[`${product}`]?.quantity_ordered}</div>
                  </div>
                  <div className="quantity-return">
                    <div className="product-quantity-label lg-hidden">{displayQuantityReturn}</div>
                    <div className="product-quantity-value">
                      <span>{productQty[`${product}`]}</span>
                    </div>
                  </div>
                </div>
              ))}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

ReturnInfo.defaultProps = {
  displayOrderNumber: 'Order Number:',
  displayOrderDate: 'Order Date:',
  displayQuantity: 'Qty',
  displayProductName: 'Product name',
};

export default ReturnInfo;
