import React from 'react';
import Button from '../../../micro-components/Button/Button';
import { getCookie } from '../../../../utils/cookies_operation.js';

const ReturnSuccess = ({
  displaySuccessLineOne,
  displaySuccessLineTwoOne,
  displaySuccessLineTwoTwo,
  displaySuccessLineTwoThree,
  displayPhysicalReference,
  displayReferenceNumber,
  displayRefund,
  displayRefundDetails,
  displayRefundQuantity,
  displayThankYou,
  displayContinueShopping,
  displayProductName,
  name,
  refrenceNumber,
  itemsToReturn,
}) => {
  const currency = getCookie('currency') && JSON.parse(getCookie('currency')).currencySymbol;

  const calculateRefund = items => {
    return items.reduce((total, item) => {
      return total + item.price * item.quantity_to_return;
    }, 0);
  };
  return (
    <div className="cmp-acommerce_order-return__success">
      <div className="cmp-acommerce_order-return__para">
        <p className="cmp-acommerce_order-return__message">{displaySuccessLineOne}</p>
        <p className="cmp-acommerce_order-return__message_ref"><strong>{displayPhysicalReference} #{refrenceNumber}  {currency}
        {calculateRefund(itemsToReturn)}</strong></p>
        <p className="cmp-acommerce_order-return__message">
          {displaySuccessLineTwoOne}
          {displaySuccessLineTwoTwo}
          {displaySuccessLineTwoThree}
        </p>
      </div>
      <div className="cmp-acommerce_order-return__details">
        {/* <div className="cmp-acommerce_order-return__details-head">
          <span>{displayPhysicalReference}</span>
        </div> */}
        {/* <div className="cmp-acommerce_order-return__details-body">
          <div className="cmp-acommerce_order-return__details-row">
            <div className="cmp-acommerce_order-return__details-col-1">
              <strong>{displayReferenceNumber}</strong>
            </div>
            <div className="cmp-acommerce_order-return__details-col-2">
              <strong>{displayRefund}</strong>
            </div>
          </div>
          <div className="cmp-acommerce_order-return__details-row">
            <div className="cmp-acommerce_order-return__details-col-1">{refrenceNumber}</div>
            <div className="cmp-acommerce_order-return__details-col-2">
              {currency}
              {calculateRefund(itemsToReturn)}
            </div>
          </div>
        </div> */}
      </div>
      <div className="cmp-acommerce_order-return__details">
        {/* <div className="cmp-acommerce_order-return__details-head">
          <span>{displayRefundDetails}</span>
        </div> */}
        <div className="cmp-acommerce_order-return__details-body">
          <div className="cmp-acommerce_order-return__details-row">
            <div className="cmp-acommerce_order-return__details-col-2">
              <strong>{displayRefundQuantity}</strong>
            </div>
            <div className="cmp-acommerce_order-return__details-col-1">
              <strong>{displayProductName}</strong>
            </div>
          </div>
          {itemsToReturn?.map(data => {
            return (
              <div className="cmp-acommerce_order-return__details-row">
                <div className="cmp-acommerce_order-return__details-col-2 order-return-qty_val">{data?.quantity_to_return}</div>
                <div className="cmp-acommerce_order-return__details-col-1">{data?.product_name}</div>
              </div>
            );
          })}
        </div>
      </div>
      <p className="cmp-acommerce_order-return__message order-return_message_tq">{displayThankYou}</p>
      <Button onClick={() => (window.location.href = '/')}>{displayContinueShopping}</Button>
    </div>
  );
};

export default ReturnSuccess;
