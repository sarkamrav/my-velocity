import React, { useState, useEffect } from 'react';
import { useLazyQuery } from '@apollo/client';
import { Formik, Form } from 'formik';
import * as Yup from 'yup';
import ORDER_DETAIL from '../../site/js/gql/order-detail.gql';
import Dropdown from '../micro-components/Dropdown/Dropdown';
import Button from '../micro-components/Button/Button';
import Link from '../micro-components/Link/Link';
import Icon from '../../assests/Icon';
import { getShoppingUrls } from '../../site/js/urlresolver';
import ReturnInfo from './components/ReturnInfo/ReturnInfo';
import { createPortal } from 'react-dom';
import Loader from '../micro-components/Loader/Loader';
import TextArea from '../micro-components/TextArea/TextArea';
import { order } from '../../utils/common.js';
import { useQuery } from '@apollo/client';
import ReturnSuccess from './components/ReturnSuccess/ReturnSuccess.jsx';
import { GET_RETURN_REASONS } from '../../site/js/gql/mutations/get-return-reason.gqls.js';
import { RETURN_REQUEST } from '../../site/js/gql/mutations/return-request.gql.js';
import { useMutation } from '@apollo/client';
import { getCookie } from '../../utils/cookies_operation.js';
import GtmDataLayer from '../gtm-data-layer/GtmDataLayer.jsx';
export default function OrderReturn({
  displayHeading,
  displayBackLabel,
  displayLoadingOrder,
  displayNoOrder,
  displayReasonLabel,
  displayReasonError,
  displayCommentLabel,
  displayCommentInstruction,
  displayRequired,
  displayCommentRequiredError,
  displayNext,
  displaySubmitLabel,
  displayCancelLabel,
  displayEmptyOrder,
  defaultDropdownTitle,
  ...restProps
}) {
  // Get the order number from the URL
  const orderNumber = new URLSearchParams(window.location.search).get('order_number');
  const currency = getCookie('currency') && JSON.parse(getCookie('currency')).currencySymbol;
  const {
    loading: returnReasonLoading,
    error: returnReasonError,
    data: returnReasonData,
  } = useQuery(GET_RETURN_REASONS);
  // Initial values for the form
  const initialValues = {
    reason: '',
    comment: '',
  };

  const [formdata, setFormdata] = useState(initialValues);
  const [ready, setReady] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [selectedProducts, setSelectedProducts] = useState({});
  const [productQty, setProductQty] = useState({});
  const [rangeError, setRangeError] = useState(false);
  const [error, setError] = useState(null);

  const [itemsToReturn, setItemsToReturn] = useState([]);
  const [refrenceNumber, setReferenceNumber] = useState('');
  // Validation schema for Form validations
  const validationSchema = Yup.object().shape({
    reason: Yup.string().required(displayReasonError),
    comment: Yup.string().required('Please add a comment'),
  });

  const [requestReturn, { data: requestReturnData, loading: requestReturnLoading, error: requestReturnError }] =
    useMutation(RETURN_REQUEST, {
      onError: error => {
        setError(error.message); // Update the error state with the error message
      },
      onCompleted: data => {
        setSubmitSuccess(true);
        setReferenceNumber(data?.core_requestReturn?.return?.number);
      },
    });

  // Default options for shipping method dropdown
  const [reasonOptions, setReasonOptions] = useState([{ options: [{ value: '', label: defaultDropdownTitle }] }]);

  useEffect(() => {
    const transformedOptions = returnReasonData?.core_returnReasons?.map(option => ({
      value: option.id,
      label: option.name,
    }));
    if (transformedOptions) {
      setReasonOptions(prevState => {
        const newState = [...prevState];
        newState[0].options = [...newState[0].options, ...transformedOptions];
        return newState;
      });
    }
  }, [returnReasonData]);

  // Query to get the order details
  const [getOrderDetails, { error: queryError, loading: queryLoading, data: queryData }] = useLazyQuery(ORDER_DETAIL, {
    variables: {
      orderNumber,
    },
  });

  // State for order details data
  const [orderDetail, setOrderDetail] = useState(null);
  // const [orderDetail, setOrderDetail] = useState(order.data);

  // Check if order Number is there in the URL else save the API call
  useEffect(() => {
    if (orderNumber) {
      getOrderDetails();
    }
  }, []);

  // Populate the state when data is received from the API call
  useEffect(() => {
    if (queryData) {
      setOrderDetail(queryData);
    }
  }, [queryData]);

  useEffect(() => {
    console.log('Products selected', selectedProducts);
    console.log('Quantity input', productQty);
  }, [selectedProducts, productQty]);

  const handleSubmit = values => {
    setFormdata(values);
    setReady(true);
  };

  const orderid = orderDetail?.core_customer?.orders?.items[0].id;
  const userEmail = orderDetail?.core_customer?.email;
  const selectedReason = { attribute_code: 'reason', value: formdata?.reason };

  const transformedItems = items => {
    console.log('Transform', items);
    return items.map(({ index, product_name, price, quantity_to_return, ...rest }) => ({
      ...rest,
      quantity_to_return: Number(quantity_to_return),
      selected_custom_attributes: selectedReason,
    }));
  };

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [ready, submitSuccess]);

  const submitHandler = () => {
    requestReturn({
      variables: {
        input: {
          order_uid: orderid,
          contact_email: userEmail,
          comment_text: formdata.comment,
          items: transformedItems(itemsToReturn),
        },
      },
    });
  };

  // If no order number in the URL, show error!
  if (!orderNumber) {
    return (
      <section className="cmp-acommerce_order-return-section">
        <div className="custom-container">
          <div className="cmp-acommerce_order-return__main">
            <h2 className="cmp-acommerce_order-return__heading">{displayHeading} </h2>
            <h4>{displayNoOrder}</h4>
          </div>
        </div>
      </section>
    );
  }

  const getReasonLabel = id => {
    const filteredOptions = reasonOptions[0].options.filter(data => data.value == id);
    return filteredOptions.length > 0 ? filteredOptions[0].label : null;
  };

  return (
    <section className="cmp-acommerce_order-return-section">
      <div className="custom-container">
        <div className="cmp-acommerce_order-return__main">
          <h2 className="cmp-acommerce_order-return__heading">{displayHeading} </h2>

          {queryLoading && (
            <>
              <h4>{displayLoadingOrder}</h4>
            </>
          )}
          {queryError && <p className="submiterror">{queryError?.message}</p>}
          {error && !requestReturnLoading && <p className="submiterror">{error}</p>}

          {orderDetail?.core_customer?.orders?.total_count > 0 && !queryLoading && (
            <>
              {/* <h2 className="cmp-acommerce_order-return__heading">{displayHeading} </h2> */}
              {!submitSuccess && (
                <ReturnInfo
                  {...restProps}
                  orderDetail={orderDetail}
                  setSelectedProducts={setSelectedProducts}
                  productQty={productQty}
                  setProductQty={setProductQty}
                  selectedProducts={selectedProducts}
                  rangeError={rangeError}
                  setRangeError={setRangeError}
                  itemsToReturn={itemsToReturn}
                  setItemsToReturn={setItemsToReturn}
                  ready={ready}
                />
              )}
              {!ready ? (
                <>
                  <Formik
                    initialValues={formdata}
                    validationSchema={validationSchema}
                    onSubmit={values => {
                      handleSubmit(values);
                    }}
                    enableReinitialize>
                    {({ errors }) => {
                      return (
                        <Form>
                          <p>
                            {displayCommentInstruction}({displayRequired}
                            <span className="mandatory_asterisk">*</span>)
                          </p>
                          <div className="cmp-acommerce_order-return__form">
                            <Dropdown
                              name="reason"
                              options={reasonOptions}
                              isMandatory
                              label={displayReasonLabel}
                              className="cmp-acommerce_order-return__form-dropdown"
                              isDisabled={!reasonOptions.length}
                            />
                            <TextArea
                              label={displayCommentLabel}
                              name="comment"
                              isMandatory
                              className="cmp-acommerce_order-return__form-textarea"
                            />
                            <Button
                              disabled={
                                Object.keys(errors).length > 0 ||
                                rangeError ||
                                Object.keys(selectedProducts).length === 0
                              }>
                              {displayNext}
                            </Button>
                          </div>
                        </Form>
                      );
                    }}
                  </Formik>
                </>
              ) : !submitSuccess ? (
                <div className="cmp-acommerce_order-return__submit">
                  <p>
                    <strong>{displayReasonLabel}</strong>: {getReasonLabel(formdata.reason)}
                  </p>
                  <p>
                    <strong>{displayCommentLabel}</strong>: {formdata.comment}
                  </p>
                  <div className="actions">
                    <Button onClick={submitHandler}>{displaySubmitLabel}</Button>
                    <Button
                      onClick={() => {
                        setReady(false);
                        setSelectedProducts({});
                        setProductQty({});
                      }}
                      className="cancel">
                      {displayCancelLabel}
                    </Button>
                  </div>
                </div>
              ) : (
                <ReturnSuccess refrenceNumber={refrenceNumber} itemsToReturn={itemsToReturn} {...restProps} />
              )}
              <p className="back-link">
                <Icon name="ArrowLeft" />
                <Link
                  type="back"
                  text={displayBackLabel}
                  href={`${getShoppingUrls()?.orderDetailURL}?order_number=${orderNumber}`}
                />
              </p>
            </>
          )}

          {orderDetail?.core_customer?.orders?.total_count == 0 && !queryLoading && (
            <>
              {/* <h2 className="cmp-acommerce_order-return__heading">{displayHeading} </h2> */}
              <h4>{displayEmptyOrder}</h4>
            </>
          )}
        </div>
      </div>
      {(queryLoading || requestReturnLoading) && createPortal(<Loader />, document.body)}
      <GtmDataLayer basicGtmData='true'/>
    </section>
  );
}
