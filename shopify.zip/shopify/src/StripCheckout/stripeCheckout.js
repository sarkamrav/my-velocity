import React from 'react';
import { useNavigate } from 'react-router-dom';

import StripeCheckout from 'react-stripe-checkout';

function Checkout({amount}) {
const navigate = useNavigate();
    const onToken = () =>{
        localStorage.removeItem("persist:root")
        navigate("/")
        window.location.reload();
    }

    // console.log("process", process.env.PUPLISHER_KEY)

  return (
    <>
    <div>stripeCheckout</div>
<StripeCheckout
            label="Proceed to Payment"
            name="Shopify" // the pop-in header title
            description={`Your total price is ${amount}rs. `} // the pop-in header subtitle
            image="https://www.vidhub.co/assets/logos/vidhub-icon-2e5c629f64ced5598a56387d4e3d0c7c.png" // the pop-in header image (default none)
            panelLabel="Pay Money" // prepended to the amount in the bottom pay button
            amount={amount } // cents
            shippingAddress 
            billingAddress
            token={onToken}
            stripeKey= "pk_test_51H4QE0GcFhhvf78e30Pl8mfONvZtp2SXfnTcb5SUvUQdMRSRhnu06JD6L2RtNlRbgBtSG12qcSXxzCKwP0LlFNe100jhDbH2lX" />
    </>

  )
}

export default Checkout


