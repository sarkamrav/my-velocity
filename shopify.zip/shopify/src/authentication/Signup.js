import React ,{ useState } from 'react';
import axios from 'axios';
import { useDispatch } from 'react-redux';
import { useNavigate } from "react-router-dom";

function Signup() {
const [userdata,setUserData] = useState({});
const dispatch = useDispatch();
const navigate = useNavigate();

const onChanageHandler =(e)=>{
   setUserData({...userdata,
      [e.target.name] : e.target.value})
}

console.log("usedata",userdata)

const formHandler = async(e)=>{
   e.preventDefault();
   // dispatch(createuser(userdata));
   // navigate("/login");
       try {
          const response = await axios.post("https://650d6a1aa8b42265ec2c2ef3.mockapi.io/users/",{...userdata});
          navigate("/login")
       } catch (err){
          console.log(err)
       }
}

  return (
     <form >
  <div className="container">
    <h1>Sign Up</h1>
    <p>Please fill in this form to create an account.</p>
 <div>
  <div>
 <label for="name"><b>Name</b></label>
    <input type="text"  placeholder="Enter Name" name="name" onChange ={onChanageHandler} required/>
 </div>
 <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" onChange ={onChanageHandler} required/>
 </div>

<div>
<label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" onChange ={onChanageHandler} required/>
</div>
<div>
<label for="psw-repeat"><b>Repeat Password</b></label>
    <input type="password" placeholder="Repeat Password" name="confirmpassword" onChange ={onChanageHandler} required/>

</div>



    <p>By creating an account you agree to our <a href="#" >Terms & Privacy</a>.</p>


      <button type="button" className="cancelbtn">Cancel</button>
      <button type="submit" className="signupbtn" onClick ={formHandler}>Sign Up</button>
  </div>
</form>

  )
}

export default Signup

