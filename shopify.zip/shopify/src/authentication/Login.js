import React, { useState, useRef, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { createUser } from "../slices/LoginSlice";
// import {validator} from '../util/util'
import { useDispatch } from "react-redux";

function Login() {
  const [loginData, setLoginData] = useState({});
  const [error, setError] = useState("");

  const nameRef = useRef("");
  const passwordRef = useRef("");
  const errorRef = useRef("");

  const navigate = useNavigate();
  const dispatch = useDispatch();
  console.log("loginData", loginData);
  const onChanageHandler = (e) => {
    setLoginData({ ...loginData, [e.target.name]: e.target.value });
  };

  //  useEffect(() => {
  //   if ((error) && errorRef.current) {
  //     window.scroll({ top: errorRef.current.offsetTop , behavior: 'smooth' });

  //   }
  // }, [error]);

  const loginHandler = async (e) => {
    e.preventDefault();

    // const isError = validator(nameRef.current.value, passwordRef.current.value)
    // setError(isError)
    // const isError = false

    // if(!isError){
    try {
      const response = await axios.get(
        "https://650d6a1aa8b42265ec2c2ef3.mockapi.io/users/"
      );
      console.log("response1", response.data);
      response?.data.map((data) => {
        if (
          data.name == loginData.name &&
          data.password == loginData.password
        ) {
          const user = {
            data,
            isLoggedin: true,
          };
          const userData = localStorage.setItem(
            "userdata",
            JSON.stringify(user)
          );
          dispatch(createUser(user));
          navigate("/");
        }
      });
    } catch (err) {
      console.log(err);
    }
    // }
  };

  return (
    <form>
      <div className="container">
        <h1>Login with your valid name and password</h1>
        {error && (
          <h1 style={{ color: "red" }} ref={errorRef}>
            Please enter correct credentials
          </h1>
        )}
        <div>
          <label for="name">
            <b>Name</b>
          </label>
          <input
            type="text"
            placeholder="Enter Name"
            name="name"
            onChange={onChanageHandler}
            required
          />
        </div>

        <div>
          <label for="psw">
            <b>Password</b>
          </label>
          <input
            type="password"
            placeholder="Enter Password"
            name="password"
            onChange={onChanageHandler}
            required
          />
        </div>

        <button type="submit" className="signupbtn" onClick={loginHandler}>
          Login
        </button>
      </div>
    </form>
  );
}

export default Login;
