import { createSlice } from '@reduxjs/toolkit';
import axios from 'axios';

const initialState= {
  cart :[],
  wishlist: []
}

 const cartSlice  = createSlice({
  name : "cartSlice",
  initialState,
  reducers : {
    cartData : (state,action) =>{
       state.cart.push(action.payload)
     },
     wishListData : (state,action) =>{
      state.wishlist.push(action.payload)
    },

  },
  
 })

// Action creators are generated for each case reducer function

export const {cartData,wishListData} =  cartSlice.actions;

export default cartSlice.reducer

