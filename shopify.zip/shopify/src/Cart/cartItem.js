import React from 'react';
import styled from 'styled-components';

const CartItemWrapper =styled.div`
 height: 200px;
 background: grey;
 margin-bottom:10px;
 display : grid;
 justify-content: center;
 align-items:center;
 grid-template-columns: repeat(5,1fr);

 img {
    height: 70%;
    object-fit: contain;
    width: 40%;
 }
`

function cartItem({productdata}) {
  const {description,image,quantity ,price,rating,title} = productdata;
  return (
    <CartItemWrapper>
      <div> 
        <img src ={image} />
      </div>
      <div>
         {price}
      </div>
      <div> {quantity}</div>
      <div>{price*quantity}</div>
      <button>Delete</button>

    </CartItemWrapper>
  )
}

export default cartItem