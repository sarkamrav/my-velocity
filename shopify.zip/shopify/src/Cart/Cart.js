import React from 'react';
import { useSelector } from 'react-redux';
import styled from 'styled-components';
import CartItem from './cartItem';
import  Checkout from '../StripCheckout/stripeCheckout';
const ProductItemWrapper = styled.div`
   display: flex;
    padding: 20px;
    flex-direction: column;
    justify-content: space-between;
    justify-content:center;
    button {
        width:100px;
        padding:5px;
        margin-left:50%;
    }

`
function Cart() {
    const cartItems = useSelector(state => state.cartSlice.cart)
  return (
    <>
        <ProductItemWrapper>
    {cartItems?.map(data =>{
    return <CartItem  productdata ={data}/>
    })

}

{cartItems.length>0 ? <Checkout amount ={100}/> :<p>Please add items to the cart</p>}
</ProductItemWrapper>
    </>


  )
}

export default Cart