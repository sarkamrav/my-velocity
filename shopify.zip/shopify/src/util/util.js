export const validator = (name,password ) =>{
    let nameRegx  = /^[A-Za-z0-9]{3,10}$/;
    let passwordRegx = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,10}$/;
    if(!nameRegx.test(name)){
      return 'name should be more than 3 charater';
    }

    if(!passwordRegx.test(password)){
        return 'password must contain alteast uppercase, digiit,special charater';
    }
  
   return null;
}