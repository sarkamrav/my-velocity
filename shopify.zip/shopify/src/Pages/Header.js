import React, { useEffect } from 'react'
import styled from 'styled-components';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import {createUser,logoutUser} from '../slices/LoginSlice';
import { useDispatch } from 'react-redux';

const HeaderWrapper = styled.div`
height:50px;
display:flex;
align-items:center;
justify-content: space-around;
background-color:grey`;

function Header() {
const user =useSelector(state => state.LoginSlice.users);
const cartItem  = useSelector(state => state.cartSlice.cart.length);
const wishListItem  = useSelector(state => state.cartSlice.wishlist.length);
const dispatch = useDispatch();
   console.log("user",user)

   useEffect(()=>{
      const userdata  = localStorage.getItem("userdata") && JSON.parse(localStorage.getItem("userdata"));
      dispatch(createUser(userdata))
   },[]);

   const logoutHandler = ()=>{
    localStorage.clear()
    dispatch(logoutUser())
   }

  return (
    <HeaderWrapper>
      <Link to= "/">Dashboard</Link>
      {user?.isLoggedin ?
      <>
      <p>{user.data.name}</p>
      <Link>wishlist</Link>
      <Link to ="/cart">cart (<span>{cartItem}</span>)</Link> 
      <Link to ="/wishlist">Wishlist (<span>{wishListItem}</span>)</Link> 
      <Link to= "/" onClick = {logoutHandler}>logout</Link>
      </> :
      <>
      <Link to ="/signup">Signup</Link>
     <Link to= "/login">login</Link>
      </>
      }
    
    </HeaderWrapper>
  )
}

export default Header
