const presetEnv = require('postcss-preset-env');

module.exports = {
  plugins: [
    presetEnv({
      stage: 0,
      autoprefixer: {
        grid: true,
      },
      importFrom: [
        './src/themes/mediaqueries.css',
      ],
      features: {
        'custom-properties': {
          preserve: true,
          importFrom: [
            './src/themes/variables.css',
          ],
        },
      },
    }),
  ],
};
