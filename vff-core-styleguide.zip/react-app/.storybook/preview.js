import React from "react";
import { INITIAL_VIEWPORTS } from '@storybook/addon-viewport';

import '../src/themes/variables.css';
import '../src/themes/global.css';
import '../src/themes/utilities.css';
import '../src/themes/typography.css'; // In development/production, this is generated in a separate file. This must be included in storybook config however.

React.useLayoutEffect = React.useEffect;

export const parameters = {
  backgrounds: {
    values: [
      { name: 'Light', value: '#fff' },
      { name: 'Grey', value: '#ddd' },
      { name: 'Dark', value: '#1d1c1f' },
    ],
  },
  a11y: {
    element: '#root',
    config: {},
    options: {},
    manual: true,
  },
  viewport: {
    viewports: INITIAL_VIEWPORTS,
  },
  layout: 'fullscreen',
  html: {
    prettier: {
      tabWidth: 2,
      useTabs: false,
    },
  },
};
