const customStoryBookRules = [
  {
    test: /\.js$/,
    use: 'babel-loader',
    exclude: /node_modules/,
  },
  {
    test: /\.css$/,
    use: [
      'style-loader',
      {
        loader: "css-loader",
        options: {
          modules: {
            localIdentName: '[path][name]_[local]',
          },
        },
      },
      'postcss-loader',
    ],
  },
  {
    test: /\.(png|jpe?g|gif|ico)$/,
    type: 'asset/resource',
    generator: {
      filename: 'resources/images/[name][ext]',
    },
  },
  {
    test: /icomoon\.(ttf|eot|svg|woff(2)?)(\?[a-z0-9]+)?$/,
    type: 'asset/resource',
    generator: {
      filename: 'resources/fonts/[name]-[hash][ext]',
    },
  },
  {
    test: /\.svg$/,
    use: [
      {
        loader: '@svgr/webpack',
        options: {
          svgoConfig: {
            plugins: {
              removeViewBox: false,
            },
          },
        },
      },
    ],
    exclude: /node_modules/,
  },
];

module.exports = {
  stories: ['../src/**/*.stories.@(js|mdx)'],
  core: {
    builder: "webpack5",
  },
  addons: [
    '@storybook/addon-a11y',
    '@storybook/addon-knobs',
    '@storybook/addon-viewport',
    '@storybook/addon-backgrounds',
    '@storybook/addon-actions',
    '@whitespace/storybook-addon-html',
    '@storybook/addon-queryparams',
    '@storybook/addon-postcss'
  ],
  webpackFinal: (config) => {
    return ({
      ...config,
      module: {
        ...config.module,
        rules: customStoryBookRules
      }
    });
  },
};
