/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 ~ Copyright 2018 Adobe Systems Incorporated
 ~
 ~ Licensed under the Apache License, Version 2.0 (the "License");
 ~ you may not use this file except in compliance with the License.
 ~ You may obtain a copy of the License at
 ~
 ~     http://www.apache.org/licenses/LICENSE-2.0
 ~
 ~ Unless required by applicable law or agreed to in writing, software
 ~ distributed under the License is distributed on an "AS IS" BASIS,
 ~ WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 ~ See the License for the specific language governing permissions and
 ~ limitations under the License.
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
// Document: https://www.npmjs.com/package/aem-clientlib-generator
module.exports = {
  // default working directory (can be changed per 'cwd' in every asset option)
  context: __dirname,

  // path to the clientlib root folder (output)
  clientLibRoot: '../ui.apps/src/main/content/jcr_root/apps/vff-core/clientlibs/site',

  libs: [{
    name: 'head',
    allowProxy: true,
    categories: ['vff-core.site.app.head'],
    cssProcessor: ['default:none', 'min:none'],
    jsProcessor: ['default:none', 'min:none'],
    serializationFormat: 'xml',
    assets: {
      js: [
        'dist/common-chunk.js',
        'dist/head.js',
        'dist/runtime.js',
        'dist/imageRendition.js'
      ],
      css: [
        'dist/typography.css',
        'dist/main.css',
      ],
      resources: {
        base: 'css',
        files: [
          { src: 'dist/resources/images/*.*', dest: 'resources/images/' },
          { src: 'dist/resources/fonts/*.*', dest: 'resources/fonts/'}
        ],
      }
    }
  }, {
    name: 'foot',
    allowProxy: true,
    categories: ['vff-core.site.app.foot'],
    cssProcessor: ['default:none', 'min:none'],
    jsProcessor: ['default:none', 'min:none'],
    serializationFormat: 'xml',
    assets: {
      js: [
        'dist/vendor.js',
        'dist/main.js',
      ],
    }
  },
    {
      name: 'deep-linking',
      allowProxy: true,
      categories: ['vff-core.site.app.deep-linking'],
      cssProcessor: ['default:none', 'min:none'],
      jsProcessor: ['default:none', 'min:none'],
      serializationFormat: 'xml',
      assets: {
        js: [
          'dist/deepLinking.js',
        ],
      }
    }
  ]
};

