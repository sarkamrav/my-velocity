import _ from 'lodash';
import { getHeadingId } from '../components/Accordion/utils';
import '../themes/variables.css';
import '../themes/normalize.css';
import '../themes/global.css';
import '../themes/utilities.css';
import analyticsSend from '../utils/analytics';
import {
  getNavigationHeight,
  getPartnerBannerTabHeight,
  isElementVisible,
  smoothScrollToElement,
} from '../utils/common';
import './personalisation';
import * as renderers from './renderers';

const ANALYTICS_METADATA = 'analytics-metadata';

window.onmousedown = (e) => {
  // We only want to capture events on A tags. Buttons will not be available in RTE.
  const eventTarget = _.get(e, 'target') || {};
  const eventTargetParent = _.get(e, 'target.parentElement') || {};
  const eventTargetParentOfParent = _.get(e, 'target.parentElement.parentElement') || {};
  const isEventTargetATag = eventTarget.tagName === 'A';
  const isEventTargetParentATag = eventTargetParent.tagName === 'A';
  const isEventTargetParentOfParentATag = eventTargetParentOfParent.tagName === 'A';
  const targetForAnalytics =
    (isEventTargetATag && eventTarget) ||
    (isEventTargetParentATag && eventTargetParent) ||
    (isEventTargetParentOfParentATag && eventTargetParentOfParent);

  if (
    (isEventTargetATag || isEventTargetParentATag || isEventTargetParentOfParentATag) &&
    targetForAnalytics.closest(`[${ANALYTICS_METADATA}]`) !== null
  ) {
    const linkData = {
      eventAction: 'click',
      eventCategory: 'hyperlink',
      eventName: 'hyperlink-interaction',
      hyperlinkElementClass: [].slice.call(targetForAnalytics.classList).join(' '),
      hyperlinkElementDestination: targetForAnalytics.href,
      hyperlinkElementName: targetForAnalytics.title,
      eventElementName: targetForAnalytics.title,
      hyperlinkElementText: targetForAnalytics.text,
      eventElementText: targetForAnalytics.text,
    };

    let analyticsMetaData = {};
    const closestMetadata = targetForAnalytics.closest(`[${ANALYTICS_METADATA}]`).getAttribute(ANALYTICS_METADATA);

    if (closestMetadata) {
      try {
        analyticsMetaData = JSON.parse(closestMetadata);
      } catch (error) {
        analyticsMetaData = window.vffCoreWebsite[closestMetadata] || {};
      }
    }

    analyticsSend({
      ...linkData,
      ...targetForAnalytics.dataset,
      ...analyticsMetaData,
    });
  }
};

// Used for rendering of all components
window.bootstrapComponents = () => {
  _.each(renderers, (renderer) => renderer.bootstrap());
};

// Used for rendering of a single type of component, or a specific instance
window.bootstrapComponent = (elementName, id = null, hydrate = false) => {
  _.each(renderers, (renderer) => {
    if (renderer.elementName === elementName) {
      renderer.bootstrap(id, hydrate);
    }
  });
};

// Initial run of the renderers for all components
window.bootstrapComponents();

function scrollToElement(element) {
  const offset = getNavigationHeight() + getPartnerBannerTabHeight();

  smoothScrollToElement(element, offset);
}

/**
 * Fires a custom event on the given element that causes ancestor components
 * that are currently hiding the given element to show it.
 *
 * @example 1
 * In a structure like the following, the Accordion component hears the event
 * and opens up the 2nd accordion item (if it is currently closed), then the
 * Tabs component will hear the event next and open up the 2nd tab item (if it
 * is currently closed).
 *
 * Tabs
 *  - Tab 1
 *      ...
 *  - Tab 2
 *      Accordion
 *        - Accordion Item 1
 *          ...
 *        - Accordion Item 2
 *          <p>Element</p> (target element to make visible)
 *
 * @example 2
 * In a structure like the following, the Accordion component hears the event
 * and opens up the 2nd accordion item (if it is currently closed), then the
 * Tabs component will hear the event next and open up the 2nd tab item (if it
 * is currently closed).
 *
 * PartnerBannerTabs
 * BannerTabs
 *  - BannerTab 1
 *    ...
 *  - BannerTab 2
 *    ...
 *  - BannerTab 3
 *      Tabs
 *        - Tab 1
 *          ...
 *        - Tab 2
 *          Accordion
 *            - Accordion Item 1
 *              ...
 *            - Accordion Item 2
 *              <p>Element</p> (target element to make visible)
 *
 * @param {HTMLElement} element
 * @returns {Promise<>}
 */
function ensureElementIsVisible(element) {
  // 1. Dispatch event on the given element to show content
  const event = new CustomEvent('ensureElementIsVisible', { bubbles: true, cancelable: false });
  element.dispatchEvent(event);

  // 2. Wait until it is visible (Up to a certain limit)
  return new Promise((resolve) => {
    const MAX_WAIT_TIME = 5000;
    const INTERVAL_TIME = 100;

    let elapsedTime = INTERVAL_TIME;

    const interval = setInterval(() => {
      if (elapsedTime > MAX_WAIT_TIME) {
        // If this occurs, make sure any ancestor components that contain this
        // element are handling the custom event we are dispatching

        // eslint-disable-next-line no-console
        console.error('Timed out waiting for element to become visible', element);
      }

      if (elapsedTime > MAX_WAIT_TIME || isElementVisible(element)) {
        clearInterval(interval);
        resolve();
      }

      // Dispatch again in case the components haven't heard the event (ie. they
      // haven't attached their event listeners yet)
      element.dispatchEvent(event);

      elapsedTime += INTERVAL_TIME;
    }, INTERVAL_TIME);
  });
}

function getHashElement(hash) {
  const id = hash.substring(1); // Remove prefix hash

  return (
    // Tabs
    document.getElementById(`tab-${id}`) ||
    // Partner banner tab
    document.getElementById(`partnerTab-${id}`) ||
    // Accordion
    document.getElementById(getHeadingId(id)) ||
    // Default - Try finding the element by id straight from hash
    document.getElementById(id)
  );
}

function isAuthorableComponent(id) {
  return !!document.getElementById(id);
}

window.addEventListener('load', () => {
  const element = getHashElement(window.location.hash);

  if (element) {
    // Ensure browser is at the top of the page
    window.scrollTo(0, 0);

    ensureElementIsVisible(element).then(() => scrollToElement(element));
  }
});

window.addEventListener('click', (event) => {
  if (event.target.tagName !== 'A') return;
  if (!event.target.hash) return;

  if (event.target.pathname !== window.location.pathname) {
    event.preventDefault();
    const linkTarget = event.target.getAttribute('target');
    window.open(event.target.href, linkTarget || '_self');
    return;
  }

  const id = event.target.hash.substring(1);
  const element = getHashElement(event.target.hash);
  const isAuthorComponent = isAuthorableComponent(event.target.hash);

  if (element) {
    event.preventDefault();

    // Rewrite target element ID temporarily to stop the browser scrolling to
    // the element when we change the hash
    if (isAuthorComponent) {
      element.id = `${element.id}_`;
    }

    window.location.hash = event.target.hash;

    // Restore ID of target element
    if (isAuthorComponent) {
      element.id = id;
    }

    ensureElementIsVisible(element).then(() => scrollToElement(element));
  }
});
