/**
 * This has been exported in a separate bundle in webpack to be included in the <head />.
 */
import { renderImage } from '../utils/common';

/* eslint-disable no-param-reassign */
function renderImageRendition() {
  const elements = document.querySelectorAll('[rendition-image]');

  // Convert HTMLCollection to an array
  [].slice.call(elements).forEach((element) => {
    const props = window.vffCoreWebsite[element.getAttribute('rendition-image')];
    renderImage(element, props);
  });
}

window.addEventListener(
  'DOMContentLoaded',
  () => {
    renderImageRendition();
  },
  true,
);

let resizeTimer;

window.addEventListener('resize', () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(renderImageRendition, 250);
});
