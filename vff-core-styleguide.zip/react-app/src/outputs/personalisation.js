import _ from 'lodash';
import api from '../utils/api';

/**
 * For personalisation team to utilise.
 * window.personaliseAndReplaceComponent(
 *  '/content/experience-fragments/velocity/offers/mac/credits_cards_bankin/american_express/amex_mgm/amex-mgm-op-seg3/_jcr_content/root/offer_item_bau.webitemmodel.json',
 *  'aem-offer-card',
 *  'boffer_shop_wine_dine_flybuys_177688057_flybuys-dec-double-status_flybuys-dec-double-status'
 * )
 */
window.personaliseAndReplaceComponent = (url, elementName, id) => {
  api.aemApi
    .get(url)
    .then((response) => {
      const { data } = response;

      // Populate the window with the response for bootstrapping
      window.vffCoreWebsite[id] = data;

      // Populate the image rendition if required
      const renditionImageKey = data.renditionImageKey || _.get(data, 'bgAttr.rendition-image');
      if (renditionImageKey) {
        window.vffCoreWebsite[renditionImageKey] = data.renditions;
      }

      // Populate the analytics metadata if required
      const analyticsMetadataKey = _.get(data, 'analyticsMetadata.analytics-metadata');
      if (analyticsMetadataKey) {
        window.vffCoreWebsite[analyticsMetadataKey] = data.analyticsMetadataMap;
      }

      window.bootstrapComponent(elementName, id);

      // Initial kick off for the rendition image
      if (renditionImageKey) {
        const newRendition = document.querySelector(`[rendition-image=${renditionImageKey}]`);
        if (newRendition) {
          window.vffCoreWebsite.coreRenderImage(newRendition, data.renditions);
        }
      }
    })
    .catch(() => console.error('--- Failed to update component ---', url, elementName, id));
};

/**
 * For personalisation team to utilise.
 * window.personaliseAndReplaceHeroBanner(
 *  '/content/experience-fragments/velocity/hero_banners/flybuys/flybuys/_jcr_content/root/hero_banner.webitemmodel.json',
 *  'hero-banner-carousel-123',
 *  0,
 *  'Title',
 *  'hero-banner-456'
 * )
 */
window.personaliseAndReplaceHeroBanner = (url, carouselJsObjectKey, index, newTitle, newJsObjectKey) => {
  api.aemApi
    .get(url)
    .then((response) => {
      const { data } = response;

      if (data.componentKey !== 'aem-hero-banner') {
        console.log('--- Wrong URL provided, please use a hero banner fragment ---');
        return;
      }

      window.vffCoreWebsite[newJsObjectKey] = data;

      if (data.renditionImageKey) {
        window.vffCoreWebsite[data.renditionImageKey] = data.renditions;
      }

      const analyticsMetadataKey = _.get(data, 'analyticsMetadata.analytics-metadata');
      if (analyticsMetadataKey) {
        window.vffCoreWebsite[analyticsMetadataKey] = data.analyticsMetadataMap;
      }

      window.vffCoreWebsite[carouselJsObjectKey].heroBannerCarouselItems = _.map(
        window.vffCoreWebsite[carouselJsObjectKey].heroBannerCarouselItems,
        (banner, i) => {
          if (index === i) {
            return {
              title: newTitle,
              jsObjectKey: newJsObjectKey,
            };
          }

          return banner;
        },
      );

      window.bootstrapComponent('aem-hero-banner-carousel', carouselJsObjectKey);

      const newRendition = document.querySelector(`[rendition-image=${data.renditionImageKey}]`);
      if (newRendition) {
        window.vffCoreWebsite.coreRenderImage(newRendition, data.renditions);
      }
    })
    .catch((error) => {
      console.error('--- Failed to update component ---', url, index, newTitle, newJsObjectKey, error);
    });
};

window.personaliseFeaturedOfferList = (url, { folistJsObjectKey, newJsObjectKey, topGridIndex, bottomGridIndex }) => {
  api.aemApi
    .get(url)
    .then((response) => {
      const { data } = response;

      if (data.componentKey !== 'aem-offer-card') {
        console.log('--- Wrong URL provided, please use a BAU offer fragment ---');
        return;
      }

      window.vffCoreWebsite[newJsObjectKey] = data;

      const renditionImageKey = _.get(data, 'bgAttr.rendition-image');
      if (renditionImageKey) {
        window.vffCoreWebsite[renditionImageKey] = data.renditions;
      }

      const analyticsMetadataKey = _.get(data, 'analyticsMetadata.analytics-metadata');
      if (analyticsMetadataKey) {
        window.vffCoreWebsite[analyticsMetadataKey] = data.analyticsMetadataMap;
      }

      if (topGridIndex >= 0) {
        window.vffCoreWebsite[folistJsObjectKey].priorityGrid[topGridIndex] = {
          jsObjectKey: newJsObjectKey,
        };
      } else if (bottomGridIndex >= 0) {
        window.vffCoreWebsite[folistJsObjectKey].remainingGrid[bottomGridIndex] = {
          jsObjectKey: newJsObjectKey,
        };
      }

      window.bootstrapComponent('aem-folist', folistJsObjectKey);

      const newRendition = document.querySelector(`[rendition-image=${data.renditionImageKey}]`);
      if (newRendition) {
        window.vffCoreWebsite.coreRenderImage(newRendition, data.renditions);
      }
    })
    .catch((error) => {
      console.error('--- Failed to update component ---', error);
    });
};
