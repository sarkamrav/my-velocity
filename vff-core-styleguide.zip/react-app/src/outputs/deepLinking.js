import deepLinking from '../features/DeepLinking/DeepLinking.bootstrap';

deepLinking.bootstrap();
