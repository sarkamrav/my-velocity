import 'core-js/stable';
import 'regenerator-runtime/runtime';
import 'element-closest/browser'; // IE11 polyfill support for closest()
import get from 'lodash/get';
import omit from 'lodash/omit';
import qs from 'qs';
import smoothscroll from 'smoothscroll-polyfill';
import '../polyfills/customEvents';
import store from '../stores';
import { initializeUser } from '../stores/user';
import analyticsSend from '../utils/analytics';
import api from '../utils/api';
import * as userData from '../stores/utilities';
import ssoHandler from '../utils/ssoHandler';
import { darkSiteManager } from '../utils/darkSiteManager';
import { contentProtection } from '../utils/contentProtection';
import { getCookie } from '../utils/cookies';
import { IMPERSONATE_TOKEN_COOKIE_NAME } from '../utils/constants';

// Scroll to top of the page when hash is found, overwrite default behaviour
if (window.location.hash) {
  window.scrollTo(0, 0); // execute it straight away
  setTimeout(() => {
    window.scrollTo(0, 0); // run it a bit later also for browser compatibility
  }, 1);
}

smoothscroll.polyfill();

function dispatchGlobalEvent(type, result) {
  let event;
  if (typeof Event === 'function') {
    event = new Event(type);
    event.data = result;
  } else {
    event = document.createEvent('Event');
    event.data = result;
    event.initEvent(type, true, true);
  }
  document.dispatchEvent(event);
}

// Check if dark site is enabled and redirect members as per settings
darkSiteManager();

// We don't want to run this on join form and consent page
if (!window.location.hostname.includes('join') && !get(window.vffCoreWebsite, 'websiteData.authenticatedNotRequired')) {
  // As this is a separate bundle outside of the listeners, we need to decorate the window object to include user information for reference
  // Reason being is the timing of requests may not corelate well with loading of bundles
  (async () => {
    try {
      // Only check authentication Keycloak status if not in authoring mode
      let authenticated = false;
      if (!get(window.vffCoreWebsite, 'websiteData.authoringMode')) {
        authenticated = await ssoHandler.init();
      }

      if (authenticated) {
        const experienceMemberApiUri = '/loyalty/v2/experience/members/me';
        const isDashboardRequired = get(window, 'vffCoreWebsite.websiteData.dashboard', false);
        const xpApiResponse = await api.vffV2Api.get(
          isDashboardRequired ? `${experienceMemberApiUri}?include=dashboard` : experienceMemberApiUri,
        );
        const memberData = get(xpApiResponse, 'data', {});

        const user = {
          ...memberData.data,
          ...memberData.included,
          authenticated: true,
          memberDataLoading: false,
          memberDataLoaded: true,
        };

        const tierLevel = userData.getTierLevel(user);
        const subTierLevel = userData.getSubTierLevel(user);

        // Handle different account statuses
        if (window.vffCoreWebsite.websiteData.loginRequired) {
          const incompleteProfileUrl = get(window, 'vffCoreWebsite.websiteData.incompleteProfileUrl', '');
          switch (userData.getAccountStatusCode(user)) {
            case 'INCOMPLETE': // Redirect to a site to allow users to complete their information
              if (!window.location.pathname.startsWith(incompleteProfileUrl) && incompleteProfileUrl) {
                // If a user is being impersonated on lite join, whitelist the preferences page
                const impersonateToken = getCookie(IMPERSONATE_TOKEN_COOKIE_NAME);
                if (
                  !(
                    impersonateToken
                    && window.location.pathname.startsWith(
                      '/my-velocity/my-profile/my-preferences',
                    )
                  )
                ) {
                  window.location.href = incompleteProfileUrl;
                }
              }
              break;
            case 'DUPLICATE':
            case 'SUSPENDED': {
              // Note that when a duplicate/suspended account is already on the /suspended page, we do nothing
              if (!window.location.pathname.startsWith('/suspended')) {
                window.location.href = '/suspended';
              }
              break;
            }
            default: {
              if (window.location.pathname.startsWith('/suspended')) {
                window.location.href = '/my-velocity';
              }
              break;
            }
          }
        }

        contentProtection(
          tierLevel && subTierLevel
            ? {
                tierLevel,
                subTierLevel,
              }
            : null,
        );

        Object.assign(window.vffCoreWebsite, {
          user,
        });

        store.dispatch(initializeUser(user));
        dispatchGlobalEvent('myProfile', user);

        const query = qs.parse(window.location.search, { ignoreQueryPrefix: true });
        if (query.explicit_login === 'web') {
          analyticsSend({
            eventName: 'login-success',
            customerState: 'authenticated',
            eventCategory: 'login',
            eventLocation: 'login-module',
            eventSource: 'web-login',
          });
        }

        // Clear SSO params
        const ssoParams = ['session_state', 'state', 'code', 'explicit_login', 'login_hint'];
        if (ssoParams.some((param) => query[param])) {
          const newQuery = qs.stringify(omit(query, ssoParams), { addQueryPrefix: true });
          window.history.pushState(
            '',
            document.title,
            `${window.location.origin}${window.location.pathname}${newQuery}${window.location.hash}`,
          );

          // On homepage upon explicit login, we need to refresh after the cookies have been set to get the users specific view
          // VWEB-1158: Disabled for now until we rebuild homepage and find an ideal solution
          // if (window.location.pathname === '/') {
          //   window.location.reload();
          // }
        }

        analyticsSend({
          eventName: 'login-state',
          eventCategory: 'login',
          eventAction: 'login',
          customerState: 'authenticated',
          velocityID: userData.getLoyaltyMembershipID(user),
        });
      } else {
        const user = {
          authenticated: false,
          memberDataLoading: false,
          memberDataLoaded: true,
        };

        Object.assign(window.vffCoreWebsite, {
          user,
        });

        store.dispatch(initializeUser(user));
        dispatchGlobalEvent('myProfile', user);

        analyticsSend({
          eventName: 'login-state',
          eventCategory: 'login',
          eventAction: 'login',
          customerState: 'unauthenticated',
        });
      }
    } catch (error) {
      const user = {
        authenticated: false,
        memberDataLoading: false,
        memberDataLoaded: false,
        memberDataLoadError: true,
      };

      Object.assign(window.vffCoreWebsite, {
        user,
      });

      store.dispatch(initializeUser(user));
      dispatchGlobalEvent('myProfile', user);

      analyticsSend({
        eventName: 'login-state',
        eventCategory: 'login',
        eventAction: 'login',
        customerState: 'unauthenticated',
      });
    }
  })();
}
