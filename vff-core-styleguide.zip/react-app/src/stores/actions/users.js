export const userActionTypes = {
  INITIALIZE_USER: 'INITIALIZE_USER',
  UPDATE_CURRENT_POINTS_BALANCE: 'UPDATE_CURRENT_POINTS_BALANCE',
};

export const updateUserPointsBalanceAction = (payload) => ({
  type: userActionTypes.UPDATE_CURRENT_POINTS_BALANCE,
  payload,
});
