// Member data info can be defined here which can be utilized at required places like getEmailAddress(user)

import get from 'lodash/get';

export const getHasLoggedIn = (user) => get(user, 'authenticated', false);
export const getMemberDataLoadError = (user) => get(user, 'memberDataLoadError', false);
export const getMemberDataLoading = (user) => get(user, 'memberDataLoading', true);
export const getMemberDataLoaded = (user) => get(user, 'memberDataLoaded', false);
export const getLoyaltyMembershipID = (user) => get(user, 'member.loyaltyMembershipID', '');
export const getEmailAddress = (user) => get(user, 'member.emailAddress', '');
export const getFirstName = (user) => get(user, 'member.firstName', '');
export const getLastName = (user) => get(user, 'member.lastName', '');
export const getMemberTitle = (user) => get(user, 'member.title', '');
export const getUserInitial = (user) => get(user, 'member.initials', '');
export const getDateOfBirth = (user) => get(user, 'member.dateOfBirth', '');
export const getJoinDate = (user) => get(user, 'account.joinDate', '');
export const getPhones = (user) => get(user, 'data.included.contact.phone', []);
export const getStatusCreditsBalance = (user) => get(user, 'account.statusCreditsBalance', 0);
export const getCurrentPointsBalance = (user) => get(user, 'account.currentPointsBalance', 0);
export const getAccountStatusCode = (user) => get(user, 'account.accountStatusCode', '');
export const getTierLevel = (user) => get(user, 'tiers.mainTierInfo.tierLevel', '');
export const getSubTierLevel = (user) => get(user, 'tiers.mainTierInfo.tierType', '');
