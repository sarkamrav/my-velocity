const UPDATE_SERVER_TIME = 'UPDATE_SERVER_TIME';

const initialState = new Date().toISOString();

export default function serverTime(state = initialState, action) {
  switch (action.type) {
    case UPDATE_SERVER_TIME:
      return new Date().toISOString();

    default:
      return state;
  }
}

export function updateServerTime() {
  return {
    type: UPDATE_SERVER_TIME,
  };
}
