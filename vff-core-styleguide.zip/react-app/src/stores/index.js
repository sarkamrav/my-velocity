import { createStore, applyMiddleware, compose } from 'redux';
import thunk from 'redux-thunk';
import { get } from 'lodash';
import rootReducer from './rootReducer';
import { updateServerTime } from './time';

export function configureStore(initialState = {}) {
  const websiteData = get(window, 'vffCoreWebsite.websiteData', {});

  const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

  const store = createStore(
    rootReducer,
    {
      websiteData,
      ...initialState,
    },
    composeEnhancers(applyMiddleware(thunk)),
  );

  setInterval(() => store.dispatch(updateServerTime()), 1000);

  if (module.hot) {
    module.hot.accept('./rootReducer', () => {
      store.replaceReducer(require('./rootReducer')); // eslint-disable-line
    });
  }

  return store;
}

export default configureStore();
