import { userActionTypes } from './actions/users';

const initialState = {
  memberDataLoading: true,
  memberDataLoaded: false,
  memberDataLoadError: false,
};

export default function user(state = initialState, action) {
  switch (action.type) {
    case userActionTypes.INITIALIZE_USER:
      return {
        ...state,
        ...action.user,
      };
    case userActionTypes.UPDATE_CURRENT_POINTS_BALANCE:
      return {
        ...state,
        account: {
          ...state.account,
          currentPointsBalance: action.payload,
        },
      };

    default:
      return state;
  }
}

export function initializeUser(accountDetails) {
  return {
    type: userActionTypes.INITIALIZE_USER,
    user: accountDetails,
  };
}
