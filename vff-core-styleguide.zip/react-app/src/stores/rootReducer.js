import { combineReducers } from 'redux';
import user from './user';
import websiteData from './websiteData';
import time from './time';

export default combineReducers({
  user,
  websiteData,
  time,
});
