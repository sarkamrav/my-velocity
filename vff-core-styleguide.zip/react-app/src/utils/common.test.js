import { isUrlExcluded } from './common';

describe('Common functions', () => {
  describe('isUrlExcluded()', () => {
    const originalWindowLocation = window.location;

    describe('On domain level page https://dev-join.velocityfrequentflyer.com/?channelname=inet', () => {
      beforeEach(() => {
        delete window.location;
        window.location = {
          ...originalWindowLocation,
          hash: '',
          host: 'dev-join.velocityfrequentflyer.com',
          hostname: 'dev-join.velocityfrequentflyer.com',
          href: 'https://dev-join.velocityfrequentflyer.com/?channelname=inet',
          origin: 'https://dev-join.velocityfrequentflyer.com',
          pathname: '/',
          port: '',
          protocol: 'https:',
          search: '?channelname=inet',
        };
      });

      describe('Excluding child pages', () => {
        test("Should exclude the URL when it's configured", () => {
          const result = isUrlExcluded([
            {
              pagePath: 'https://dev-join.velocityfrequentflyer.com',
              includeChildren: false,
            },
          ]);

          expect(result).toBeTruthy();
        });

        test('Should exclude the URL if the configured URL has trailing slash', () => {
          const result = isUrlExcluded([
            {
              pagePath: 'https://dev-join.velocityfrequentflyer.com/',
              includeChildren: false,
            },
          ]);

          expect(result).toBeTruthy();
        });

        test("Should NOT exclude the URL if it's NOT configure", () => {
          const result = isUrlExcluded([
            {
              pagePath: 'https://dev-join.velocityfrequentflyer.com/test',
              includeChildren: false,
            },
          ]);

          expect(result).toBeFalsy();
        });
      });

      describe('Including child pages', () => {
        test("Should exclude the URL if it's configure", () => {
          const result = isUrlExcluded([
            {
              pagePath: 'https://dev-join.velocityfrequentflyer.com',
              includeChildren: true,
            },
          ]);

          expect(result).toBeTruthy();
        });

        test("Should exclude the URL if it's configure with trailing slash", () => {
          const result = isUrlExcluded([
            {
              pagePath: 'https://dev-join.velocityfrequentflyer.com/',
              includeChildren: true,
            },
          ]);

          expect(result).toBeTruthy();
        });
      });

      afterEach(() => {
        window.location = originalWindowLocation;
      });
    });

    describe('On nested page https://dev-experience.velocityfrequentflyer.com/partners-offers/hotels/direct-earn-points', () => {
      beforeEach(() => {
        delete window.location;
        window.location = {
          ...originalWindowLocation,
          hash: '',
          host: 'dev-experience.velocityfrequentflyer.com',
          hostname: 'dev-experience.velocityfrequentflyer.com',
          href: 'https://dev-experience.velocityfrequentflyer.com/partners-offers/hotels/direct-earn-points',
          origin: 'https://dev-experience.velocityfrequentflyer.com',
          pathname: '/partners-offers/hotels/direct-earn-points',
          port: '',
          protocol: 'https:',
          search: '',
        };
      });

      describe('Excluding child pages', () => {
        test("Should exclude the URL when it's configured", () => {
          const result = isUrlExcluded([
            {
              pagePath: 'https://dev-experience.velocityfrequentflyer.com/partners-offers/hotels/direct-earn-points',
              includeChildren: false,
            },
          ]);

          expect(result).toBeTruthy();
        });

        test('Should exclude the URL if the configured URL has a trailing slash', () => {
          const result = isUrlExcluded([
            {
              pagePath: 'https://dev-experience.velocityfrequentflyer.com/partners-offers/hotels/direct-earn-points/',
              includeChildren: false,
            },
          ]);

          expect(result).toBeTruthy();
        });
      });

      describe('Including child pages', () => {
        test('Should exclude the URL if a parent page is configured', () => {
          const result = isUrlExcluded([
            {
              pagePath: 'https://dev-experience.velocityfrequentflyer.com/partners-offers',
              includeChildren: true,
            },
          ]);

          expect(result).toBeTruthy();
        });

        test("Should exclude the URL if it's is configured as a parent page", () => {
          const result = isUrlExcluded([
            {
              pagePath: 'https://dev-experience.velocityfrequentflyer.com/partners-offers/hotels/direct-earn-points',
              includeChildren: true,
            },
          ]);

          expect(result).toBeTruthy();
        });

        test("Should exclude the URL if it's is configured as a parent page with trailing slash", () => {
          const result = isUrlExcluded([
            {
              pagePath: 'https://dev-experience.velocityfrequentflyer.com/partners-offers/hotels/direct-earn-points/',
              includeChildren: true,
            },
          ]);

          expect(result).toBeTruthy();
        });
      });

      afterEach(() => {
        window.location = originalWindowLocation;
      });
    });
  });
});
