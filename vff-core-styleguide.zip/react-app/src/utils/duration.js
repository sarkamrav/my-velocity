import { Interval } from 'luxon';

export function getDurationBetween(startDate, endDate) {
  const i = Interval.fromDateTimes(startDate, endDate);
  const duration = i.length('milliseconds');
  const days = Math.floor(duration / (1000 * 3600 * 24));
  const hours = Math.floor(duration / 3600 / 1000);

  return {
    duration,
    days,
    hours,
  };
}

export function getDistanceInWords(startDate, endDate) {
  const i = Interval.fromDateTimes(startDate, endDate)
    .toDuration(['years', 'months', 'days', 'hours', 'minutes'])
    .toObject();

  let result = '';

  if (i.years > 0) {
    result = `${i.years} year${i.years > 1 ? 's' : ''}`;
    if (i.months > 0) {
      result += ` ${i.months} month${i.months > 1 ? 's' : ''}`;
    }
  } else if (i.months > 0) {
    result = `${i.months} month${i.months > 1 ? 's' : ''}`;
    if (i.days > 0) {
      result += ` ${i.days} day${i.days > 1 ? 's' : ''}`;
    }
  } else if (i.days > 0) {
    result = `${i.days} day${i.days > 1 ? 's' : ''}`;
    if (i.hours > 0) {
      result += ` ${i.hours} hour${i.hours > 1 ? 's' : ''}`;
    }
  } else if (i.hours > 0) {
    result = `${i.hours} hour${i.hours > 1 ? 's' : ''}`;
  }

  return result;
}

export function millisecondsToTime(duration) {
  let seconds = Math.floor((duration / 1000) % 60);
  let minutes = Math.floor((duration / (1000 * 60)) % 60);
  let hours = Math.floor((duration / (1000 * 60 * 60)) % 24);

  hours = hours < 10 ? `0${hours}` : hours;
  minutes = minutes < 10 ? `0${minutes}` : minutes;
  seconds = seconds < 10 ? `0${seconds}` : seconds;

  return `${hours}:${minutes}:${seconds}`;
}
