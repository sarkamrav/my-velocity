export function getRecaptchaResponse(siteKey, actionName) {
  if (!siteKey) {
    throw new Error('Recaptcha site key not available.');
  }

  if (window.grecaptcha && siteKey) {
    return new Promise((resolve, reject) => {
      window.grecaptcha.ready(async () => {
        try {
          const token = await window.grecaptcha.execute(siteKey, { action: actionName });
          resolve(token);
        } catch (err) {
          reject(err);
        }
      });
    });
  }

  return undefined;
}
