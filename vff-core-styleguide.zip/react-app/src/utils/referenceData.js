import { COUNTRY_CODE } from './constants';

export const countriesByCode = [
  {
    code: COUNTRY_CODE.AUSTRALIA,
    label: 'Australia',
    phoneCode: '61',
  },
  {
    code: COUNTRY_CODE.NEW_ZEALAND,
    label: 'New Zealand',
    phoneCode: '64',
  },
  {
    code: COUNTRY_CODE.CHRISTMAS_ISLAND,
    label: 'Christmas Island',
    phoneCode: '61',
  },
  {
    code: COUNTRY_CODE.COCOS_ISLANDS,
    label: 'Cocos Islands',
    phoneCode: '61',
  },
  {
    code: COUNTRY_CODE.COOK_ISLANDS,
    label: 'Cook Islands',
    phoneCode: '682',
  },
  {
    code: COUNTRY_CODE.FIJI,
    label: 'Fiji',
    phoneCode: '679',
  },
  {
    code: COUNTRY_CODE.PAPUA_NEW_GUINEA,
    label: 'Papua New Guinea',
    phoneCode: '675',
  },
  {
    code: COUNTRY_CODE.SAMOA_INDEPENDENT_STATE_OF,
    label: 'Samoa-Independent State Of',
    phoneCode: '685',
  },
  {
    code: COUNTRY_CODE.SOLOMON_ISLANDS,
    label: 'Solomon Islands',
    phoneCode: '677',
  },
  {
    code: COUNTRY_CODE.TONGA,
    label: 'Tonga',
    phoneCode: '676',
  },
  {
    code: COUNTRY_CODE.VANUATU,
    label: 'Vanuatu',
    phoneCode: '678',
  },
  {
    code: COUNTRY_CODE.AFGHANISTAN,
    label: 'Afghanistan',
    phoneCode: '93',
  },
  {
    code: COUNTRY_CODE.ALAND_ISLANDS,
    label: 'Aland Islands',
    phoneCode: '358',
  },
  {
    code: COUNTRY_CODE.ALBANIA,
    label: 'Albania',
    phoneCode: '355',
  },
  {
    code: COUNTRY_CODE.ALGERIA,
    label: 'Algeria',
    phoneCode: '213',
  },
  {
    code: COUNTRY_CODE.AMERICAN_SAMOA,
    label: 'American Samoa',
    phoneCode: '1684',
  },
  {
    code: COUNTRY_CODE.ANDORRA,
    label: 'Andorra',
    phoneCode: '376',
  },
  {
    code: COUNTRY_CODE.ANGOLA,
    label: 'Angola',
    phoneCode: '244',
  },
  {
    code: COUNTRY_CODE.ANGUILLA,
    label: 'Anguilla',
    phoneCode: '1264',
  },
  {
    code: COUNTRY_CODE.ANTARCTICA,
    label: 'Antarctica',
    phoneCode: '672',
  },
  {
    code: COUNTRY_CODE.ANTIGUA_AND_BARBUDA,
    label: 'Antigua And Barbuda',
    phoneCode: '1268',
  },
  {
    code: COUNTRY_CODE.ARGENTINA,
    label: 'Argentina',
    phoneCode: '54',
  },
  {
    code: COUNTRY_CODE.ARMENIA,
    label: 'Armenia',
    phoneCode: '374',
  },
  {
    code: COUNTRY_CODE.ARUBA,
    label: 'Aruba',
    phoneCode: '297',
  },
  {
    code: COUNTRY_CODE.AUSTRIA,
    label: 'Austria',
    phoneCode: '43',
  },
  {
    code: COUNTRY_CODE.AZERBAIJAN,
    label: 'Azerbaijan',
    phoneCode: '994',
  },
  {
    code: COUNTRY_CODE.BAHAMAS,
    label: 'Bahamas',
    phoneCode: '1242',
  },
  {
    code: COUNTRY_CODE.BAHRAIN,
    label: 'Bahrain',
    phoneCode: '973',
  },
  {
    code: COUNTRY_CODE.BANGLADESH,
    label: 'Bangladesh',
    phoneCode: '880',
  },
  {
    code: COUNTRY_CODE.BARBADOS,
    label: 'Barbados',
    phoneCode: '1246',
  },
  {
    code: COUNTRY_CODE.BELARUS,
    label: 'Belarus',
    phoneCode: '375',
  },
  {
    code: COUNTRY_CODE.BELGIUM,
    label: 'Belgium',
    phoneCode: '32',
  },
  {
    code: COUNTRY_CODE.BELIZE,
    label: 'Belize',
    phoneCode: '501',
  },
  {
    code: COUNTRY_CODE.BENIN,
    label: 'Benin',
    phoneCode: '229',
  },
  {
    code: COUNTRY_CODE.BERMUDA,
    label: 'Bermuda',
    phoneCode: '1441',
  },
  {
    code: COUNTRY_CODE.BHUTAN,
    label: 'Bhutan',
    phoneCode: '975',
  },
  {
    code: COUNTRY_CODE.BOLIVIA,
    label: 'Bolivia',
    phoneCode: '591',
  },
  {
    code: COUNTRY_CODE.BONAIRE_ST_EUSTATIUS_AND_SABA,
    label: 'Bonaire St Eustatius And Saba',
    phoneCode: '599',
  },
  {
    code: COUNTRY_CODE.BOSNIA_HERZEGOVINA,
    label: 'Bosnia-Herzegovina',
    phoneCode: '387',
  },
  {
    code: COUNTRY_CODE.BOTSWANA,
    label: 'Botswana',
    phoneCode: '267',
  },
  {
    code: COUNTRY_CODE.BOUVET_ISLAND,
    label: 'Bouvet Island',
    phoneCode: '47',
  },
  {
    code: COUNTRY_CODE.BRAZIL,
    label: 'Brazil',
    phoneCode: '55',
  },
  {
    code: COUNTRY_CODE.BRITISH_INDIAN_OCEAN_TERRITORY,
    label: 'British Indian Ocean Territory',
    phoneCode: '246',
  },
  {
    code: COUNTRY_CODE.BRUNEI_DARUSSALAM,
    label: 'Brunei Darussalam',
    phoneCode: '673',
  },
  {
    code: COUNTRY_CODE.BULGARIA,
    label: 'Bulgaria',
    phoneCode: '359',
  },
  {
    code: COUNTRY_CODE.BURKINA_FASO,
    label: 'Burkina Faso',
    phoneCode: '226',
  },
  {
    code: COUNTRY_CODE.BURUNDI,
    label: 'Burundi',
    phoneCode: '257',
  },
  {
    code: COUNTRY_CODE.CAMBODIA,
    label: 'Cambodia',
    phoneCode: '855',
  },
  {
    code: COUNTRY_CODE.CAMEROON_REPUBLIC_OF,
    label: 'Cameroon-Republic Of',
    phoneCode: '237',
  },
  {
    code: COUNTRY_CODE.CANADA,
    label: 'Canada',
    phoneCode: '1',
  },
  {
    code: COUNTRY_CODE.CAPE_VERDE_REPUBLIC_OF,
    label: 'Cape Verde-Republic Of',
    phoneCode: '238',
  },
  {
    code: COUNTRY_CODE.CAYMAN_ISLANDS,
    label: 'Cayman Islands',
    phoneCode: '1345',
  },
  {
    code: COUNTRY_CODE.CENTRAL_AFRICAN_REPUBLIC,
    label: 'Central African Republic',
    phoneCode: '236',
  },
  {
    code: COUNTRY_CODE.CHAD,
    label: 'Chad',
    phoneCode: '235',
  },
  {
    code: COUNTRY_CODE.CHILE,
    label: 'Chile',
    phoneCode: '56',
  },
  {
    code: COUNTRY_CODE.CHINA,
    label: 'China',
    phoneCode: '86',
  },
  {
    code: COUNTRY_CODE.COLOMBIA,
    label: 'Colombia',
    phoneCode: '57',
  },
  {
    code: COUNTRY_CODE.COMOROS,
    label: 'Comoros',
    phoneCode: '269',
  },
  {
    code: COUNTRY_CODE.CONGO_BRAZZAVILLE,
    label: 'Congo Brazzaville',
    phoneCode: '242',
  },
  {
    code: COUNTRY_CODE.CONGO_THE_DEMOCRATIC_REP_OF,
    label: 'Congo The Democratic Rep Of',
    phoneCode: '243',
  },
  {
    code: COUNTRY_CODE.COSTA_RICA,
    label: 'Costa Rica',
    phoneCode: '506',
  },
  {
    code: COUNTRY_CODE.COTE_D_IVOIRE,
    label: 'Cote D Ivoire',
    phoneCode: '225',
  },
  {
    code: COUNTRY_CODE.CROATIA,
    label: 'Croatia',
    phoneCode: '385',
  },
  {
    code: COUNTRY_CODE.CUBA,
    label: 'Cuba',
    phoneCode: '53',
  },
  {
    code: COUNTRY_CODE.CURACAO,
    label: 'Curacao',
    phoneCode: '599',
  },
  {
    code: COUNTRY_CODE.CYPRUS,
    label: 'Cyprus',
    phoneCode: '357',
  },
  {
    code: COUNTRY_CODE.CZECH_REPUBLIC,
    label: 'Czech Republic',
    phoneCode: '420',
  },
  {
    code: COUNTRY_CODE.DENMARK,
    label: 'Denmark',
    phoneCode: '45',
  },
  {
    code: COUNTRY_CODE.DJIBOUTI,
    label: 'Djibouti',
    phoneCode: '253',
  },
  {
    code: COUNTRY_CODE.DOMINICA,
    label: 'Dominica',
    phoneCode: '1767',
  },
  {
    code: COUNTRY_CODE.DOMINICAN_REPUBLIC_1,
    label: 'Dominican Republic',
    phoneCode: '1809',
  },
  {
    code: COUNTRY_CODE.DOMINICAN_REPUBLIC_2,
    label: 'Dominican Republic',
    phoneCode: '1829',
  },
  {
    code: COUNTRY_CODE.DOMINICAN_REPUBLIC_3,
    label: 'Dominican Republic',
    phoneCode: '1849',
  },
  {
    code: COUNTRY_CODE.ECUADOR,
    label: 'Ecuador',
    phoneCode: '593',
  },
  {
    code: COUNTRY_CODE.EGYPT,
    label: 'Egypt',
    phoneCode: '20',
  },
  {
    code: COUNTRY_CODE.EL_SALVADOR,
    label: 'El Salvador',
    phoneCode: '503',
  },
  {
    code: COUNTRY_CODE.EQUATORIAL_GUINEA,
    label: 'Equatorial Guinea',
    phoneCode: '240',
  },
  {
    code: COUNTRY_CODE.ERITREA,
    label: 'Eritrea',
    phoneCode: '291',
  },
  {
    code: COUNTRY_CODE.ESTONIA,
    label: 'Estonia',
    phoneCode: '372',
  },
  {
    code: COUNTRY_CODE.ESWATINI,
    label: 'Eswatini',
    phoneCode: '268',
  },
  {
    code: COUNTRY_CODE.ETHIOPIA,
    label: 'Ethiopia',
    phoneCode: '251',
  },
  {
    code: COUNTRY_CODE.FALKLAND_ISLANDS,
    label: 'Falkland Islands',
    phoneCode: '500',
  },
  {
    code: COUNTRY_CODE.FAROE_ISLANDS,
    label: 'Faroe Islands',
    phoneCode: '298',
  },
  {
    code: COUNTRY_CODE.FINLAND,
    label: 'Finland',
    phoneCode: '358',
  },
  {
    code: COUNTRY_CODE.FRANCE,
    label: 'France',
    phoneCode: '33',
  },
  {
    code: COUNTRY_CODE.FRENCH_GUIANA,
    label: 'French Guiana',
    phoneCode: '594',
  },
  {
    code: COUNTRY_CODE.FRENCH_POLYNESIA,
    label: 'French Polynesia',
    phoneCode: '689',
  },
  {
    code: COUNTRY_CODE.FRENCH_SOUTHERN_TERRITORIES,
    label: 'French Southern Territories',
    phoneCode: '262',
  },
  {
    code: COUNTRY_CODE.GABON,
    label: 'Gabon',
    phoneCode: '241',
  },
  {
    code: COUNTRY_CODE.GAMBIA,
    label: 'Gambia',
    phoneCode: '220',
  },
  {
    code: COUNTRY_CODE.GEORGIA,
    label: 'Georgia',
    phoneCode: '995',
  },
  {
    code: COUNTRY_CODE.GERMANY,
    label: 'Germany',
    phoneCode: '49',
  },
  {
    code: COUNTRY_CODE.GHANA,
    label: 'Ghana',
    phoneCode: '233',
  },
  {
    code: COUNTRY_CODE.GIBRALTAR,
    label: 'Gibraltar',
    phoneCode: '350',
  },
  {
    code: COUNTRY_CODE.GREECE,
    label: 'Greece',
    phoneCode: '30',
  },
  {
    code: COUNTRY_CODE.GREENLAND,
    label: 'Greenland',
    phoneCode: '299',
  },
  {
    code: COUNTRY_CODE.GRENADA,
    label: 'Grenada',
    phoneCode: '1473',
  },
  {
    code: COUNTRY_CODE.GUADELOUPE,
    label: 'Guadeloupe',
    phoneCode: '590',
  },
  {
    code: COUNTRY_CODE.GUAM,
    label: 'Guam',
    phoneCode: '1671',
  },
  {
    code: COUNTRY_CODE.GUATEMALA,
    label: 'Guatemala',
    phoneCode: '502',
  },
  {
    code: COUNTRY_CODE.GUERNSEY,
    label: 'Guernsey',
    phoneCode: '441481',
  },
  {
    code: COUNTRY_CODE.GUINEA,
    label: 'Guinea',
    phoneCode: '224',
  },
  {
    code: COUNTRY_CODE.GUINEA_BISSAU,
    label: 'Guinea Bissau',
    phoneCode: '245',
  },
  {
    code: COUNTRY_CODE.GUYANA,
    label: 'Guyana',
    phoneCode: '592',
  },
  {
    code: COUNTRY_CODE.HAITI,
    label: 'Haiti',
    phoneCode: '509',
  },
  {
    code: COUNTRY_CODE.HEARD_AND_MCDONALD_ISLANDS,
    label: 'Heard And Mcdonald Islands',
    phoneCode: '672',
  },
  {
    code: COUNTRY_CODE.HONDURAS,
    label: 'Honduras',
    phoneCode: '504',
  },
  {
    code: COUNTRY_CODE.HONG_KONG_SAR_OF_CHINA,
    label: 'Hong Kong -Sar Of China-',
    phoneCode: '852',
  },
  {
    code: COUNTRY_CODE.HUNGARY,
    label: 'Hungary',
    phoneCode: '36',
  },
  {
    code: COUNTRY_CODE.ICELAND,
    label: 'Iceland',
    phoneCode: '354',
  },
  {
    code: COUNTRY_CODE.INDIA,
    label: 'India',
    phoneCode: '91',
  },
  {
    code: COUNTRY_CODE.INDONESIA,
    label: 'Indonesia',
    phoneCode: '62',
  },
  {
    code: COUNTRY_CODE.IRAN,
    label: 'Iran',
    phoneCode: '98',
  },
  {
    code: COUNTRY_CODE.IRAQ,
    label: 'Iraq',
    phoneCode: '964',
  },
  {
    code: COUNTRY_CODE.IRELAND,
    label: 'Ireland',
    phoneCode: '353',
  },
  {
    code: COUNTRY_CODE.ISLE_OF_MAN,
    label: 'Isle Of Man',
    phoneCode: '441624',
  },
  {
    code: COUNTRY_CODE.ISRAEL,
    label: 'Israel',
    phoneCode: '972',
  },
  {
    code: COUNTRY_CODE.ITALY,
    label: 'Italy',
    phoneCode: '39',
  },
  {
    code: COUNTRY_CODE.JAMAICA,
    label: 'Jamaica',
    phoneCode: '1876',
  },
  {
    code: COUNTRY_CODE.JAPAN,
    label: 'Japan',
    phoneCode: '81',
  },
  {
    code: COUNTRY_CODE.JERSEY,
    label: 'Jersey',
    phoneCode: '441534',
  },
  {
    code: COUNTRY_CODE.JORDAN,
    label: 'Jordan',
    phoneCode: '962',
  },
  {
    code: COUNTRY_CODE.KAZAKHSTAN,
    label: 'Kazakhstan',
    phoneCode: '7',
  },
  {
    code: COUNTRY_CODE.KENYA,
    label: 'Kenya',
    phoneCode: '254',
  },
  {
    code: COUNTRY_CODE.KIRIBATI,
    label: 'Kiribati',
    phoneCode: '686',
  },
  {
    code: COUNTRY_CODE.KOREA_DEM_PEOPLES_REP_OF,
    label: 'Korea Dem Peoples Rep Of',
    phoneCode: '850',
  },
  {
    code: COUNTRY_CODE.KOREA_REPUBLIC_OF,
    label: 'Korea Republic Of',
    phoneCode: '82',
  },
  {
    code: COUNTRY_CODE.KUWAIT,
    label: 'Kuwait',
    phoneCode: '965',
  },
  {
    code: COUNTRY_CODE.KYRGYZSTAN,
    label: 'Kyrgyzstan',
    phoneCode: '996',
  },
  {
    code: COUNTRY_CODE.LAO_PEOPLES_DEM_REPUBLIC,
    label: 'Lao Peoples Dem Republic',
    phoneCode: '856',
  },
  {
    code: COUNTRY_CODE.LATVIA,
    label: 'Latvia',
    phoneCode: '371',
  },
  {
    code: COUNTRY_CODE.LEBANON,
    label: 'Lebanon',
    phoneCode: '961',
  },
  {
    code: COUNTRY_CODE.LESOTHO,
    label: 'Lesotho',
    phoneCode: '266',
  },
  {
    code: COUNTRY_CODE.LIBERIA,
    label: 'Liberia',
    phoneCode: '231',
  },
  {
    code: COUNTRY_CODE.LIBYA,
    label: 'Libya',
    phoneCode: '218',
  },
  {
    code: COUNTRY_CODE.LIECHTENSTEIN,
    label: 'Liechtenstein',
    phoneCode: '423',
  },
  {
    code: COUNTRY_CODE.LITHUANIA,
    label: 'Lithuania',
    phoneCode: '370',
  },
  {
    code: COUNTRY_CODE.LUXEMBOURG,
    label: 'Luxembourg',
    phoneCode: '352',
  },
  {
    code: COUNTRY_CODE.MACAO_SAR_OF_CHINA,
    label: 'Macao -Sar Of China-',
    phoneCode: '853',
  },
  {
    code: COUNTRY_CODE.MADAGASCAR,
    label: 'Madagascar',
    phoneCode: '261',
  },
  {
    code: COUNTRY_CODE.MALAWI,
    label: 'Malawi',
    phoneCode: '265',
  },
  {
    code: COUNTRY_CODE.MALAYSIA,
    label: 'Malaysia',
    phoneCode: '60',
  },
  {
    code: COUNTRY_CODE.MALDIVES,
    label: 'Maldives',
    phoneCode: '960',
  },
  {
    code: COUNTRY_CODE.MALI,
    label: 'Mali',
    phoneCode: '223',
  },
  {
    code: COUNTRY_CODE.MALTA,
    label: 'Malta',
    phoneCode: '356',
  },
  {
    code: COUNTRY_CODE.MARSHALL_ISLANDS,
    label: 'Marshall Islands',
    phoneCode: '692',
  },
  {
    code: COUNTRY_CODE.MARTINIQUE,
    label: 'Martinique',
    phoneCode: '596',
  },
  {
    code: COUNTRY_CODE.MAURITANIA,
    label: 'Mauritania',
    phoneCode: '222',
  },
  {
    code: COUNTRY_CODE.MAURITIUS,
    label: 'Mauritius',
    phoneCode: '230',
  },
  {
    code: COUNTRY_CODE.MAYOTTE,
    label: 'Mayotte',
    phoneCode: '262',
  },
  {
    code: COUNTRY_CODE.MEXICO,
    label: 'Mexico',
    phoneCode: '52',
  },
  {
    code: COUNTRY_CODE.MICRONESIA,
    label: 'Micronesia',
    phoneCode: '691',
  },
  {
    code: COUNTRY_CODE.MOLDOVA,
    label: 'Moldova',
    phoneCode: '373',
  },
  {
    code: COUNTRY_CODE.MONACO,
    label: 'Monaco',
    phoneCode: '377',
  },
  {
    code: COUNTRY_CODE.MONGOLIA,
    label: 'Mongolia',
    phoneCode: '976',
  },
  {
    code: COUNTRY_CODE.MONTENEGRO,
    label: 'Montenegro',
    phoneCode: '382',
  },
  {
    code: COUNTRY_CODE.MONTSERRAT,
    label: 'Montserrat',
    phoneCode: '1664',
  },
  {
    code: COUNTRY_CODE.MOROCCO,
    label: 'Morocco',
    phoneCode: '212',
  },
  {
    code: COUNTRY_CODE.MOZAMBIQUE,
    label: 'Mozambique',
    phoneCode: '258',
  },
  {
    code: COUNTRY_CODE.MYANMAR,
    label: 'Myanmar',
    phoneCode: '95',
  },
  {
    code: COUNTRY_CODE.NAMIBIA,
    label: 'Namibia',
    phoneCode: '264',
  },
  {
    code: COUNTRY_CODE.NAURU,
    label: 'Nauru',
    phoneCode: '674',
  },
  {
    code: COUNTRY_CODE.NEPAL,
    label: 'Nepal',
    phoneCode: '977',
  },
  {
    code: COUNTRY_CODE.NETHERLANDS,
    label: 'Netherlands',
    phoneCode: '31',
  },
  {
    code: COUNTRY_CODE.NEW_CALEDONIA,
    label: 'New Caledonia',
    phoneCode: '687',
  },
  {
    code: COUNTRY_CODE.NICARAGUA,
    label: 'Nicaragua',
    phoneCode: '505',
  },
  {
    code: COUNTRY_CODE.NIGER,
    label: 'Niger',
    phoneCode: '227',
  },
  {
    code: COUNTRY_CODE.NIGERIA,
    label: 'Nigeria',
    phoneCode: '234',
  },
  {
    code: COUNTRY_CODE.NIUE,
    label: 'Niue',
    phoneCode: '683',
  },
  {
    code: COUNTRY_CODE.NORFOLK_ISLAND,
    label: 'Norfolk Island',
    phoneCode: '672',
  },
  {
    code: COUNTRY_CODE.NORTH_MACEDONIA,
    label: 'North Macedonia',
    phoneCode: '389',
  },
  {
    code: COUNTRY_CODE.NORTHERN_MARIANA_ISLANDS,
    label: 'Northern Mariana Islands',
    phoneCode: '1670',
  },
  {
    code: COUNTRY_CODE.NORWAY,
    label: 'Norway',
    phoneCode: '47',
  },
  {
    code: COUNTRY_CODE.OMAN,
    label: 'Oman',
    phoneCode: '968',
  },
  {
    code: COUNTRY_CODE.PAKISTAN,
    label: 'Pakistan',
    phoneCode: '92',
  },
  {
    code: COUNTRY_CODE.PALAU,
    label: 'Palau',
    phoneCode: '680',
  },
  {
    code: COUNTRY_CODE.PALESTINE_STATE_OF,
    label: 'Palestine - State Of',
    phoneCode: '970',
  },
  {
    code: COUNTRY_CODE.PANAMA,
    label: 'Panama',
    phoneCode: '507',
  },
  {
    code: COUNTRY_CODE.PARAGUAY,
    label: 'Paraguay',
    phoneCode: '595',
  },
  {
    code: COUNTRY_CODE.PERU,
    label: 'Peru',
    phoneCode: '51',
  },
  {
    code: COUNTRY_CODE.PHILIPPINES,
    label: 'Philippines',
    phoneCode: '63',
  },
  {
    code: COUNTRY_CODE.PITCAIRN,
    label: 'Pitcairn',
    phoneCode: '64',
  },
  {
    code: COUNTRY_CODE.POLAND,
    label: 'Poland',
    phoneCode: '48',
  },
  {
    code: COUNTRY_CODE.PORTUGAL,
    label: 'Portugal',
    phoneCode: '351',
  },
  {
    code: COUNTRY_CODE.PUERTO_RICO,
    label: 'Puerto Rico',
    phoneCode: '1787',
  },
  {
    code: COUNTRY_CODE.PUERTO_RICO,
    label: 'Puerto Rico',
    phoneCode: '1939',
  },
  {
    code: COUNTRY_CODE.QATAR,
    label: 'Qatar',
    phoneCode: '974',
  },
  {
    code: COUNTRY_CODE.REUNION,
    label: 'Reunion',
    phoneCode: '262',
  },
  {
    code: COUNTRY_CODE.ROMANIA,
    label: 'Romania',
    phoneCode: '40',
  },
  {
    code: COUNTRY_CODE.RUSSIA,
    label: 'Russia',
    phoneCode: '7',
  },
  {
    code: COUNTRY_CODE.RWANDA,
    label: 'Rwanda',
    phoneCode: '250',
  },
  {
    code: COUNTRY_CODE.SAINT_BARTHELEMY,
    label: 'Saint Barthelemy',
    phoneCode: '590',
  },
  {
    code: COUNTRY_CODE.SAINT_KITTS_AND_NEVIS,
    label: 'Saint Kitts And Nevis',
    phoneCode: '1869',
  },
  {
    code: COUNTRY_CODE.SAINT_MARTIN,
    label: 'Saint Martin',
    phoneCode: '590',
  },
  {
    code: COUNTRY_CODE.SAN_MARINO,
    label: 'San Marino',
    phoneCode: '378',
  },
  {
    code: COUNTRY_CODE.SAO_TOME_AND_PRINCIPE,
    label: 'Sao Tome And Principe',
    phoneCode: '239',
  },
  {
    code: COUNTRY_CODE.SAUDI_ARABIA,
    label: 'Saudi Arabia',
    phoneCode: '966',
  },
  {
    code: COUNTRY_CODE.SENEGAL,
    label: 'Senegal',
    phoneCode: '221',
  },
  {
    code: COUNTRY_CODE.SERBIA,
    label: 'Serbia',
    phoneCode: '381',
  },
  {
    code: COUNTRY_CODE.SEYCHELLES,
    label: 'Seychelles',
    phoneCode: '248',
  },
  {
    code: COUNTRY_CODE.SIERRA_LEONE,
    label: 'Sierra Leone',
    phoneCode: '232',
  },
  {
    code: COUNTRY_CODE.SINGAPORE,
    label: 'Singapore',
    phoneCode: '65',
  },
  {
    code: COUNTRY_CODE.SINT_MAARTEN,
    label: 'Sint Maarten',
    phoneCode: '1721',
  },
  {
    code: COUNTRY_CODE.SLOVAKIA,
    label: 'Slovakia',
    phoneCode: '421',
  },
  {
    code: COUNTRY_CODE.SLOVENIA,
    label: 'Slovenia',
    phoneCode: '386',
  },
  {
    code: COUNTRY_CODE.SOMALIA,
    label: 'Somalia',
    phoneCode: '252',
  },
  {
    code: COUNTRY_CODE.SOUTH_AFRICA,
    label: 'South Africa',
    phoneCode: '27',
  },
  {
    code: COUNTRY_CODE.SOUTH_GEORGIA_AND_SANDWICH_ISL,
    label: 'South Georgia And Sandwich Isl',
    phoneCode: '500',
  },
  {
    code: COUNTRY_CODE.SOUTH_SUDAN,
    label: 'South Sudan',
    phoneCode: '211',
  },
  {
    code: COUNTRY_CODE.SPAIN,
    label: 'Spain',
    phoneCode: '34',
  },
  {
    code: COUNTRY_CODE.SRI_LANKA,
    label: 'Sri Lanka',
    phoneCode: '94',
  },
  {
    code: COUNTRY_CODE.ST_VINCENT_AND_THE_GRENADINES,
    label: 'St Vincent And The Grenadines',
    phoneCode: '1784',
  },
  {
    code: COUNTRY_CODE.ST_HELENA_ISLAND,
    label: 'St. Helena Island',
    phoneCode: '290',
  },
  {
    code: COUNTRY_CODE.ST_LUCIA,
    label: 'St. Lucia',
    phoneCode: '1758',
  },
  {
    code: COUNTRY_CODE.ST_PIERRE_AND_MIQUELON,
    label: 'St. Pierre And Miquelon',
    phoneCode: '508',
  },
  {
    code: COUNTRY_CODE.SUDAN,
    label: 'Sudan',
    phoneCode: '249',
  },
  {
    code: COUNTRY_CODE.SURINAME,
    label: 'Suriname',
    phoneCode: '597',
  },
  {
    code: COUNTRY_CODE.SVALBARD_AND_JAN_MAYEN,
    label: 'Svalbard And Jan Mayen',
    phoneCode: '47',
  },
  {
    code: COUNTRY_CODE.SWEDEN,
    label: 'Sweden',
    phoneCode: '46',
  },
  {
    code: COUNTRY_CODE.SWITZERLAND,
    label: 'Switzerland',
    phoneCode: '41',
  },
  {
    code: COUNTRY_CODE.SYRIAN_ARAB_REPUBLIC,
    label: 'Syrian Arab Republic',
    phoneCode: '963',
  },
  {
    code: COUNTRY_CODE.TAIWAN,
    label: 'Taiwan',
    phoneCode: '886',
  },
  {
    code: COUNTRY_CODE.TAJIKISTAN,
    label: 'Tajikistan',
    phoneCode: '992',
  },
  {
    code: COUNTRY_CODE.TANZANIA_UNITED_REPUBLIC,
    label: 'Tanzania-United Republic',
    phoneCode: '255',
  },
  {
    code: COUNTRY_CODE.THAILAND,
    label: 'Thailand',
    phoneCode: '66',
  },
  {
    code: COUNTRY_CODE.TIMOR_LESTE,
    label: 'Timor Leste',
    phoneCode: '670',
  },
  {
    code: COUNTRY_CODE.TOGO,
    label: 'Togo',
    phoneCode: '228',
  },
  {
    code: COUNTRY_CODE.TOKELAU,
    label: 'Tokelau',
    phoneCode: '690',
  },
  {
    code: COUNTRY_CODE.TRINIDAD_AND_TOBAGO,
    label: 'Trinidad And Tobago',
    phoneCode: '1868',
  },
  {
    code: COUNTRY_CODE.TUNISIA,
    label: 'Tunisia',
    phoneCode: '216',
  },
  {
    code: COUNTRY_CODE.TURKIYE,
    label: 'Turkiye',
    phoneCode: '90',
  },
  {
    code: COUNTRY_CODE.TURKMENISTAN,
    label: 'Turkmenistan',
    phoneCode: '993',
  },
  {
    code: COUNTRY_CODE.TURKS_AND_CAICOS_ISLANDS,
    label: 'Turks And Caicos Islands',
    phoneCode: '1649',
  },
  {
    code: COUNTRY_CODE.TUVALU,
    label: 'Tuvalu',
    phoneCode: '688',
  },
  {
    code: COUNTRY_CODE.US_MINOR_OUTLYING_ISLANDS,
    label: 'U.S. Minor Outlying Islands',
    phoneCode: '1',
  },
  {
    code: COUNTRY_CODE.UGANDA,
    label: 'Uganda',
    phoneCode: '256',
  },
  {
    code: COUNTRY_CODE.UKRAINE,
    label: 'Ukraine',
    phoneCode: '380',
  },
  {
    code: COUNTRY_CODE.UNITED_ARAB_EMIRATES,
    label: 'United Arab Emirates',
    phoneCode: '971',
  },
  {
    code: COUNTRY_CODE.UNITED_KINGDOM,
    label: 'United Kingdom',
    phoneCode: '44',
  },
  {
    code: COUNTRY_CODE.UNITED_STATES_OF_AMERICA,
    label: 'United States Of America',
    phoneCode: '1',
  },
  {
    code: COUNTRY_CODE.URUGUAY,
    label: 'Uruguay',
    phoneCode: '598',
  },
  {
    code: COUNTRY_CODE.UZBEKISTAN,
    label: 'Uzbekistan',
    phoneCode: '998',
  },
  {
    code: COUNTRY_CODE.VATICAN,
    label: 'Vatican',
    phoneCode: '379',
  },
  {
    code: COUNTRY_CODE.VENEZUELA,
    label: 'Venezuela',
    phoneCode: '58',
  },
  {
    code: COUNTRY_CODE.VIETNAM,
    label: 'Vietnam',
    phoneCode: '84',
  },
  {
    code: COUNTRY_CODE.VIRGIN_ISLANDS_BRITISH,
    label: 'Virgin Islands-British',
    phoneCode: '1284',
  },
  {
    code: COUNTRY_CODE.VIRGIN_ISLANDS_UNITED_STATES,
    label: 'Virgin Islands-United States',
    phoneCode: '1340',
  },
  {
    code: COUNTRY_CODE.WALLIS_AND_FUTUNA_ISLANDS,
    label: 'Wallis And Futuna Islands',
    phoneCode: '681',
  },
  {
    code: COUNTRY_CODE.WESTERN_SAHARA,
    label: 'Western Sahara',
    phoneCode: '212',
  },
  {
    code: COUNTRY_CODE.YEMEN_REPUBLIC,
    label: 'Yemen Republic',
    phoneCode: '967',
  },
  {
    code: COUNTRY_CODE.ZAMBIA,
    label: 'Zambia',
    phoneCode: '260',
  },
  {
    code: COUNTRY_CODE.ZIMBABWE,
    label: 'Zimbabwe',
    phoneCode: '263',
  },
];

export const countryCodeOptions = [
  {
    bottomSeparator: true,
    options: [
      {
        label: 'Australia (+61)',
        value: COUNTRY_CODE.AUSTRALIA,
        placeholder: '+61',
      },
      {
        label: 'New Zealand (+64)',
        value: COUNTRY_CODE.NEW_ZEALAND,
        placeholder: '+64',
      },
    ],
  },
  {
    bottomSeparator: true,
    options: [
      {
        label: 'Christmas Island (+61)',
        value: COUNTRY_CODE.CHRISTMAS_ISLAND,
        placeholder: '+61',
      },
      {
        label: 'Cocos Islands (+61)',
        value: COUNTRY_CODE.COCOS_ISLANDS,
        placeholder: '+61',
      },
      {
        label: 'Cook Islands (+682)',
        value: COUNTRY_CODE.COOK_ISLANDS,
        placeholder: '+682',
      },
      {
        label: 'Fiji (+679)',
        value: COUNTRY_CODE.FIJI,
        placeholder: '+679',
      },
      {
        label: 'Papua New Guinea (+675)',
        value: COUNTRY_CODE.PAPUA_NEW_GUINEA,
        placeholder: '+675',
      },
      {
        label: 'Samoa-Independent State Of (+685)',
        value: COUNTRY_CODE.SAMOA_INDEPENDENT_STATE_OF,
        placeholder: '+685',
      },
      {
        label: 'Solomon Islands (+677)',
        value: COUNTRY_CODE.SOLOMON_ISLANDS,
        placeholder: '+677',
      },
      {
        label: 'Tonga (+676)',
        value: COUNTRY_CODE.TONGA,
        placeholder: '+676',
      },
      {
        label: 'Vanuatu (+678)',
        value: COUNTRY_CODE.VANUATU,
        placeholder: '+678',
      },
    ],
  },
  {
    options: [
      {
        label: 'Afghanistan (+93)',
        value: COUNTRY_CODE.AFGHANISTAN,
        placeholder: '+93',
      },
      {
        label: 'Aland Islands (+358)',
        value: COUNTRY_CODE.ALAND_ISLANDS,
        placeholder: '+358',
      },
      {
        label: 'Albania (+355)',
        value: COUNTRY_CODE.ALBANIA,
        placeholder: '+355',
      },
      {
        label: 'Algeria (+213)',
        value: COUNTRY_CODE.ALGERIA,
        placeholder: '+213',
      },
      {
        label: 'American Samoa (+1684)',
        value: COUNTRY_CODE.AMERICAN_SAMOA,
        placeholder: '+1684',
      },
      {
        label: 'Andorra (+376)',
        value: COUNTRY_CODE.ANDORRA,
        placeholder: '+376',
      },
      {
        label: 'Angola (+244)',
        value: COUNTRY_CODE.ANGOLA,
        placeholder: '+244',
      },
      {
        label: 'Anguilla (+1264)',
        value: COUNTRY_CODE.ANGUILLA,
        placeholder: '+1264',
      },
      {
        label: 'Antarctica (+672)',
        value: COUNTRY_CODE.ANTARCTICA,
        placeholder: '+672',
      },
      {
        label: 'Antigua And Barbuda (+1268)',
        value: COUNTRY_CODE.ANTIGUA_AND_BARBUDA,
        placeholder: '+1268',
      },
      {
        label: 'Argentina (+54)',
        value: COUNTRY_CODE.ARGENTINA,
        placeholder: '+54',
      },
      {
        label: 'Armenia (+374)',
        value: COUNTRY_CODE.ARMENIA,
        placeholder: '+374',
      },
      {
        label: 'Aruba (+297)',
        value: COUNTRY_CODE.ARUBA,
        placeholder: '+297',
      },
      {
        label: 'Austria (+43)',
        value: COUNTRY_CODE.AUSTRIA,
        placeholder: '+43',
      },
      {
        label: 'Azerbaijan (+994)',
        value: COUNTRY_CODE.AZERBAIJAN,
        placeholder: '+994',
      },
      {
        label: 'Bahamas (+1242)',
        value: COUNTRY_CODE.BAHAMAS,
        placeholder: '+1242',
      },
      {
        label: 'Bahrain (+973)',
        value: COUNTRY_CODE.BAHRAIN,
        placeholder: '+973',
      },
      {
        label: 'Bangladesh (+880)',
        value: COUNTRY_CODE.BANGLADESH,
        placeholder: '+880',
      },
      {
        label: 'Barbados (+1246)',
        value: COUNTRY_CODE.BARBADOS,
        placeholder: '+1246',
      },
      {
        label: 'Belarus (+375)',
        value: COUNTRY_CODE.BELARUS,
        placeholder: '+375',
      },
      {
        label: 'Belgium (+32)',
        value: COUNTRY_CODE.BELGIUM,
        placeholder: '+32',
      },
      {
        label: 'Belize (+501)',
        value: COUNTRY_CODE.BELIZE,
        placeholder: '+501',
      },
      {
        label: 'Benin (+229)',
        value: COUNTRY_CODE.BENIN,
        placeholder: '+229',
      },
      {
        label: 'Bermuda (+1441)',
        value: COUNTRY_CODE.BERMUDA,
        placeholder: '+1441',
      },
      {
        label: 'Bhutan (+975)',
        value: COUNTRY_CODE.BHUTAN,
        placeholder: '+975',
      },
      {
        label: 'Bolivia (+591)',
        value: COUNTRY_CODE.BOLIVIA,
        placeholder: '+591',
      },
      {
        label: 'Bonaire St Eustatius And Saba (+599)',
        value: COUNTRY_CODE.BONAIRE_ST_EUSTATIUS_AND_SABA,
        placeholder: '+599',
      },
      {
        label: 'Bosnia-Herzegovina (+387)',
        value: COUNTRY_CODE.BOSNIA_HERZEGOVINA,
        placeholder: '+387',
      },
      {
        label: 'Botswana (+267)',
        value: COUNTRY_CODE.BOTSWANA,
        placeholder: '+267',
      },
      {
        label: 'Bouvet Island (+47)',
        value: COUNTRY_CODE.BOUVET_ISLAND,
        placeholder: '+47',
      },
      {
        label: 'Brazil (+55)',
        value: COUNTRY_CODE.BRAZIL,
        placeholder: '+55',
      },
      {
        label: 'British Indian Ocean Territory (+246)',
        value: COUNTRY_CODE.BRITISH_INDIAN_OCEAN_TERRITORY,
        placeholder: '+246',
      },
      {
        label: 'Brunei Darussalam (+673)',
        value: COUNTRY_CODE.BRUNEI_DARUSSALAM,
        placeholder: '+673',
      },
      {
        label: 'Bulgaria (+359)',
        value: COUNTRY_CODE.BULGARIA,
        placeholder: '+359',
      },
      {
        label: 'Burkina Faso (+226)',
        value: COUNTRY_CODE.BURKINA_FASO,
        placeholder: '+226',
      },
      {
        label: 'Burundi (+257)',
        value: COUNTRY_CODE.BURUNDI,
        placeholder: '+257',
      },
      {
        label: 'Cambodia (+855)',
        value: COUNTRY_CODE.CAMBODIA,
        placeholder: '+855',
      },
      {
        label: 'Cameroon-Republic Of (+237)',
        value: COUNTRY_CODE.CAMEROON_REPUBLIC_OF,
        placeholder: '+237',
      },
      {
        label: 'Canada (+1)',
        value: COUNTRY_CODE.CANADA,
        placeholder: '+1',
      },
      {
        label: 'Cape Verde-Republic Of (+238)',
        value: COUNTRY_CODE.CAPE_VERDE_REPUBLIC_OF,
        placeholder: '+238',
      },
      {
        label: 'Cayman Islands (+1345)',
        value: COUNTRY_CODE.CAYMAN_ISLANDS,
        placeholder: '+1345',
      },
      {
        label: 'Central African Republic (+236)',
        value: COUNTRY_CODE.CENTRAL_AFRICAN_REPUBLIC,
        placeholder: '+236',
      },
      {
        label: 'Chad (+235)',
        value: COUNTRY_CODE.CHAD,
        placeholder: '+235',
      },
      {
        label: 'Chile (+56)',
        value: COUNTRY_CODE.CHILE,
        placeholder: '+56',
      },
      {
        label: 'China (+86)',
        value: COUNTRY_CODE.CHINA,
        placeholder: '+86',
      },
      {
        label: 'Colombia (+57)',
        value: COUNTRY_CODE.COLOMBIA,
        placeholder: '+57',
      },
      {
        label: 'Comoros (+269)',
        value: COUNTRY_CODE.COMOROS,
        placeholder: '+269',
      },
      {
        label: 'Congo Brazzaville (+242)',
        value: COUNTRY_CODE.CONGO_BRAZZAVILLE,
        placeholder: '+242',
      },
      {
        label: 'Congo The Democratic Rep Of (+243)',
        value: COUNTRY_CODE.CONGO_THE_DEMOCRATIC_REP_OF,
        placeholder: '+243',
      },
      {
        label: 'Costa Rica (+506)',
        value: COUNTRY_CODE.COSTA_RICA,
        placeholder: '+506',
      },
      {
        label: 'Cote D Ivoire (+225)',
        value: COUNTRY_CODE.COTE_D_IVOIRE,
        placeholder: '+225',
      },
      {
        label: 'Croatia (+385)',
        value: COUNTRY_CODE.CROATIA,
        placeholder: '+385',
      },
      {
        label: 'Cuba (+53)',
        value: COUNTRY_CODE.CUBA,
        placeholder: '+53',
      },
      {
        label: 'Curacao (+599)',
        value: COUNTRY_CODE.CURACAO,
        placeholder: '+599',
      },
      {
        label: 'Cyprus (+357)',
        value: COUNTRY_CODE.CYPRUS,
        placeholder: '+357',
      },
      {
        label: 'Czech Republic (+420)',
        value: COUNTRY_CODE.CZECH_REPUBLIC,
        placeholder: '+420',
      },
      {
        label: 'Denmark (+45)',
        value: COUNTRY_CODE.DENMARK,
        placeholder: '+45',
      },
      {
        label: 'Djibouti (+253)',
        value: COUNTRY_CODE.DJIBOUTI,
        placeholder: '+253',
      },
      {
        label: 'Dominica (+1767)',
        value: COUNTRY_CODE.DOMINICA,
        placeholder: '+1767',
      },
      {
        label: 'Dominican Republic (+1809)',
        value: COUNTRY_CODE.DOMINICAN_REPUBLIC_1,
        placeholder: '+1809',
      },
      {
        label: 'Dominican Republic (+1829)',
        value: COUNTRY_CODE.DOMINICAN_REPUBLIC_2,
        placeholder: '+1829',
      },
      {
        label: 'Dominican Republic (+1849)',
        value: COUNTRY_CODE.DOMINICAN_REPUBLIC_3,
        placeholder: '+1849',
      },
      {
        label: 'Ecuador (+593)',
        value: COUNTRY_CODE.ECUADOR,
        placeholder: '+593',
      },
      {
        label: 'Egypt (+20)',
        value: COUNTRY_CODE.EGYPT,
        placeholder: '+20',
      },
      {
        label: 'El Salvador (+503)',
        value: COUNTRY_CODE.EL_SALVADOR,
        placeholder: '+503',
      },
      {
        label: 'Equatorial Guinea (+240)',
        value: COUNTRY_CODE.EQUATORIAL_GUINEA,
        placeholder: '+240',
      },
      {
        label: 'Eritrea (+291)',
        value: COUNTRY_CODE.ERITREA,
        placeholder: '+291',
      },
      {
        label: 'Estonia (+372)',
        value: COUNTRY_CODE.ESTONIA,
        placeholder: '+372',
      },
      {
        label: 'Eswatini (+268)',
        value: COUNTRY_CODE.ESWATINI,
        placeholder: '+268',
      },
      {
        label: 'Ethiopia (+251)',
        value: COUNTRY_CODE.ETHIOPIA,
        placeholder: '+251',
      },
      {
        label: 'Falkland Islands (+500)',
        value: COUNTRY_CODE.FALKLAND_ISLANDS,
        placeholder: '+500',
      },
      {
        label: 'Faroe Islands (+298)',
        value: COUNTRY_CODE.FAROE_ISLANDS,
        placeholder: '+298',
      },
      {
        label: 'Finland (+358)',
        value: COUNTRY_CODE.FINLAND,
        placeholder: '+358',
      },
      {
        label: 'France (+33)',
        value: COUNTRY_CODE.FRANCE,
        placeholder: '+33',
      },
      {
        label: 'French Guiana (+594)',
        value: COUNTRY_CODE.FRENCH_GUIANA,
        placeholder: '+594',
      },
      {
        label: 'French Polynesia (+689)',
        value: COUNTRY_CODE.FRENCH_POLYNESIA,
        placeholder: '+689',
      },
      {
        label: 'French Southern Territories (+262)',
        value: COUNTRY_CODE.FRENCH_SOUTHERN_TERRITORIES,
        placeholder: '+262',
      },
      {
        label: 'Gabon (+241)',
        value: COUNTRY_CODE.GABON,
        placeholder: '+241',
      },
      {
        label: 'Gambia (+220)',
        value: COUNTRY_CODE.GAMBIA,
        placeholder: '+220',
      },
      {
        label: 'Georgia (+995)',
        value: COUNTRY_CODE.GEORGIA,
        placeholder: '+995',
      },
      {
        label: 'Germany (+49)',
        value: COUNTRY_CODE.GERMANY,
        placeholder: '+49',
      },
      {
        label: 'Ghana (+233)',
        value: COUNTRY_CODE.GHANA,
        placeholder: '+233',
      },
      {
        label: 'Gibraltar (+350)',
        value: COUNTRY_CODE.GIBRALTAR,
        placeholder: '+350',
      },
      {
        label: 'Greece (+30)',
        value: COUNTRY_CODE.GREECE,
        placeholder: '+30',
      },
      {
        label: 'Greenland (+299)',
        value: COUNTRY_CODE.GREENLAND,
        placeholder: '+299',
      },
      {
        label: 'Grenada (+1473)',
        value: COUNTRY_CODE.GRENADA,
        placeholder: '+1473',
      },
      {
        label: 'Guadeloupe (+590)',
        value: COUNTRY_CODE.GUADELOUPE,
        placeholder: '+590',
      },
      {
        label: 'Guam (+1671)',
        value: COUNTRY_CODE.GUAM,
        placeholder: '+1671',
      },
      {
        label: 'Guatemala (+502)',
        value: COUNTRY_CODE.GUATEMALA,
        placeholder: '+502',
      },
      {
        label: 'Guernsey (+441481)',
        value: COUNTRY_CODE.GUERNSEY,
        placeholder: '+441481',
      },
      {
        label: 'Guinea (+224)',
        value: COUNTRY_CODE.GUINEA,
        placeholder: '+224',
      },
      {
        label: 'Guinea Bissau (+245)',
        value: COUNTRY_CODE.GUINEA_BISSAU,
        placeholder: '+245',
      },
      {
        label: 'Guyana (+592)',
        value: COUNTRY_CODE.GUYANA,
        placeholder: '+592',
      },
      {
        label: 'Haiti (+509)',
        value: COUNTRY_CODE.HAITI,
        placeholder: '+509',
      },
      {
        label: 'Heard And Mcdonald Islands (+672)',
        value: COUNTRY_CODE.HEARD_AND_MCDONALD_ISLANDS,
        placeholder: '+672',
      },
      {
        label: 'Honduras (+504)',
        value: COUNTRY_CODE.HONDURAS,
        placeholder: '+504',
      },
      {
        label: 'Hong Kong -Sar Of China- (+852)',
        value: COUNTRY_CODE.HONG_KONG_SAR_OF_CHINA,
        placeholder: '+852',
      },
      {
        label: 'Hungary (+36)',
        value: COUNTRY_CODE.HUNGARY,
        placeholder: '+36',
      },
      {
        label: 'Iceland (+354)',
        value: COUNTRY_CODE.ICELAND,
        placeholder: '+354',
      },
      {
        label: 'India (+91)',
        value: COUNTRY_CODE.INDIA,
        placeholder: '+91',
      },
      {
        label: 'Indonesia (+62)',
        value: COUNTRY_CODE.INDONESIA,
        placeholder: '+62',
      },
      {
        label: 'Iran (+98)',
        value: COUNTRY_CODE.IRAN,
        placeholder: '+98',
      },
      {
        label: 'Iraq (+964)',
        value: COUNTRY_CODE.IRAQ,
        placeholder: '+964',
      },
      {
        label: 'Ireland (+353)',
        value: COUNTRY_CODE.IRELAND,
        placeholder: '+353',
      },
      {
        label: 'Isle Of Man (+441624)',
        value: COUNTRY_CODE.ISLE_OF_MAN,
        placeholder: '+441624',
      },
      {
        label: 'Israel (+972)',
        value: COUNTRY_CODE.ISRAEL,
        placeholder: '+972',
      },
      {
        label: 'Italy (+39)',
        value: COUNTRY_CODE.ITALY,
        placeholder: '+39',
      },
      {
        label: 'Jamaica (+1876)',
        value: COUNTRY_CODE.JAMAICA,
        placeholder: '+1876',
      },
      {
        label: 'Japan (+81)',
        value: COUNTRY_CODE.JAPAN,
        placeholder: '+81',
      },
      {
        label: 'Jersey (+441534)',
        value: COUNTRY_CODE.JERSEY,
        placeholder: '+441534',
      },
      {
        label: 'Jordan (+962)',
        value: COUNTRY_CODE.JORDAN,
        placeholder: '+962',
      },
      {
        label: 'Kazakhstan (+7)',
        value: COUNTRY_CODE.KAZAKHSTAN,
        placeholder: '+7',
      },
      {
        label: 'Kenya (+254)',
        value: COUNTRY_CODE.KENYA,
        placeholder: '+254',
      },
      {
        label: 'Kiribati (+686)',
        value: COUNTRY_CODE.KIRIBATI,
        placeholder: '+686',
      },
      {
        label: 'Korea Dem Peoples Rep Of (+850)',
        value: COUNTRY_CODE.KOREA_DEM_PEOPLES_REP_OF,
        placeholder: '+850',
      },
      {
        label: 'Korea Republic Of (+82)',
        value: COUNTRY_CODE.KOREA_REPUBLIC_OF,
        placeholder: '+82',
      },
      {
        label: 'Kuwait (+965)',
        value: COUNTRY_CODE.KUWAIT,
        placeholder: '+965',
      },
      {
        label: 'Kyrgyzstan (+996)',
        value: COUNTRY_CODE.KYRGYZSTAN,
        placeholder: '+996',
      },
      {
        label: 'Lao Peoples Dem Republic (+856)',
        value: COUNTRY_CODE.LAO_PEOPLES_DEM_REPUBLIC,
        placeholder: '+856',
      },
      {
        label: 'Latvia (+371)',
        value: COUNTRY_CODE.LATVIA,
        placeholder: '+371',
      },
      {
        label: 'Lebanon (+961)',
        value: COUNTRY_CODE.LEBANON,
        placeholder: '+961',
      },
      {
        label: 'Lesotho (+266)',
        value: COUNTRY_CODE.LESOTHO,
        placeholder: '+266',
      },
      {
        label: 'Liberia (+231)',
        value: COUNTRY_CODE.LIBERIA,
        placeholder: '+231',
      },
      {
        label: 'Libya (+218)',
        value: COUNTRY_CODE.LIBYA,
        placeholder: '+218',
      },
      {
        label: 'Liechtenstein (+423)',
        value: COUNTRY_CODE.LIECHTENSTEIN,
        placeholder: '+423',
      },
      {
        label: 'Lithuania (+370)',
        value: COUNTRY_CODE.LITHUANIA,
        placeholder: '+370',
      },
      {
        label: 'Luxembourg (+352)',
        value: COUNTRY_CODE.LUXEMBOURG,
        placeholder: '+352',
      },
      {
        label: 'Macao -Sar Of China- (+853)',
        value: COUNTRY_CODE.MACAO_SAR_OF_CHINA,
        placeholder: '+853',
      },
      {
        label: 'Madagascar (+261)',
        value: COUNTRY_CODE.MADAGASCAR,
        placeholder: '+261',
      },
      {
        label: 'Malawi (+265)',
        value: COUNTRY_CODE.MALAWI,
        placeholder: '+265',
      },
      {
        label: 'Malaysia (+60)',
        value: COUNTRY_CODE.MALAYSIA,
        placeholder: '+60',
      },
      {
        label: 'Maldives (+960)',
        value: COUNTRY_CODE.MALDIVES,
        placeholder: '+960',
      },
      {
        label: 'Mali (+223)',
        value: COUNTRY_CODE.MALI,
        placeholder: '+223',
      },
      {
        label: 'Malta (+356)',
        value: COUNTRY_CODE.MALTA,
        placeholder: '+356',
      },
      {
        label: 'Marshall Islands (+692)',
        value: COUNTRY_CODE.MARSHALL_ISLANDS,
        placeholder: '+692',
      },
      {
        label: 'Martinique (+596)',
        value: COUNTRY_CODE.MARTINIQUE,
        placeholder: '+596',
      },
      {
        label: 'Mauritania (+222)',
        value: COUNTRY_CODE.MAURITANIA,
        placeholder: '+222',
      },
      {
        label: 'Mauritius (+230)',
        value: COUNTRY_CODE.MAURITIUS,
        placeholder: '+230',
      },
      {
        label: 'Mayotte (+262)',
        value: COUNTRY_CODE.MAYOTTE,
        placeholder: '+262',
      },
      {
        label: 'Mexico (+52)',
        value: COUNTRY_CODE.MEXICO,
        placeholder: '+52',
      },
      {
        label: 'Micronesia (+691)',
        value: COUNTRY_CODE.MICRONESIA,
        placeholder: '+691',
      },
      {
        label: 'Moldova (+373)',
        value: COUNTRY_CODE.MOLDOVA,
        placeholder: '+373',
      },
      {
        label: 'Monaco (+377)',
        value: COUNTRY_CODE.MONACO,
        placeholder: '+377',
      },
      {
        label: 'Mongolia (+976)',
        value: COUNTRY_CODE.MONGOLIA,
        placeholder: '+976',
      },
      {
        label: 'Montenegro (+382)',
        value: COUNTRY_CODE.MONTENEGRO,
        placeholder: '+382',
      },
      {
        label: 'Montserrat (+1664)',
        value: COUNTRY_CODE.MONTSERRAT,
        placeholder: '+1664',
      },
      {
        label: 'Morocco (+212)',
        value: COUNTRY_CODE.MOROCCO,
        placeholder: '+212',
      },
      {
        label: 'Mozambique (+258)',
        value: COUNTRY_CODE.MOZAMBIQUE,
        placeholder: '+258',
      },
      {
        label: 'Myanmar (+95)',
        value: COUNTRY_CODE.MYANMAR,
        placeholder: '+95',
      },
      {
        label: 'Namibia (+264)',
        value: COUNTRY_CODE.NAMIBIA,
        placeholder: '+264',
      },
      {
        label: 'Nauru (+674)',
        value: COUNTRY_CODE.NAURU,
        placeholder: '+674',
      },
      {
        label: 'Nepal (+977)',
        value: COUNTRY_CODE.NEPAL,
        placeholder: '+977',
      },
      {
        label: 'Netherlands (+31)',
        value: COUNTRY_CODE.NETHERLANDS,
        placeholder: '+31',
      },
      {
        label: 'New Caledonia (+687)',
        value: COUNTRY_CODE.NEW_CALEDONIA,
        placeholder: '+687',
      },
      {
        label: 'Nicaragua (+505)',
        value: COUNTRY_CODE.NICARAGUA,
        placeholder: '+505',
      },
      {
        label: 'Niger (+227)',
        value: COUNTRY_CODE.NIGER,
        placeholder: '+227',
      },
      {
        label: 'Nigeria (+234)',
        value: COUNTRY_CODE.NIGERIA,
        placeholder: '+234',
      },
      {
        label: 'Niue (+683)',
        value: COUNTRY_CODE.NIUE,
        placeholder: '+683',
      },
      {
        label: 'Norfolk Island (+672)',
        value: COUNTRY_CODE.NORFOLK_ISLAND,
        placeholder: '+672',
      },
      {
        label: 'North Macedonia (+389)',
        value: COUNTRY_CODE.NORTH_MACEDONIA,
        placeholder: '+389',
      },
      {
        label: 'Northern Mariana Islands (+1670)',
        value: COUNTRY_CODE.NORTHERN_MARIANA_ISLANDS,
        placeholder: '+1670',
      },
      {
        label: 'Norway (+47)',
        value: COUNTRY_CODE.NORWAY,
        placeholder: '+47',
      },
      {
        label: 'Oman (+968)',
        value: COUNTRY_CODE.OMAN,
        placeholder: '+968',
      },
      {
        label: 'Pakistan (+92)',
        value: COUNTRY_CODE.PAKISTAN,
        placeholder: '+92',
      },
      {
        label: 'Palau (+680)',
        value: COUNTRY_CODE.PALAU,
        placeholder: '+680',
      },
      {
        label: 'Palestine - State Of (+970)',
        value: COUNTRY_CODE.PALESTINE_STATE_OF,
        placeholder: '+970',
      },
      {
        label: 'Panama (+507)',
        value: COUNTRY_CODE.PANAMA,
        placeholder: '+507',
      },
      {
        label: 'Paraguay (+595)',
        value: COUNTRY_CODE.PARAGUAY,
        placeholder: '+595',
      },
      {
        label: 'Peru (+51)',
        value: COUNTRY_CODE.PERU,
        placeholder: '+51',
      },
      {
        label: 'Philippines (+63)',
        value: COUNTRY_CODE.PHILIPPINES,
        placeholder: '+63',
      },
      {
        label: 'Pitcairn (+64)',
        value: COUNTRY_CODE.PITCAIRN,
        placeholder: '+64',
      },
      {
        label: 'Poland (+48)',
        value: COUNTRY_CODE.POLAND,
        placeholder: '+48',
      },
      {
        label: 'Portugal (+351)',
        value: COUNTRY_CODE.PORTUGAL,
        placeholder: '+351',
      },
      {
        label: 'Puerto Rico (+1787)',
        value: COUNTRY_CODE.PUERTO_RICO,
        placeholder: '+1787',
      },
      {
        label: 'Puerto Rico (+1939)',
        value: COUNTRY_CODE.PUERTO_RICO,
        placeholder: '+1939',
      },
      {
        label: 'Qatar (+974)',
        value: COUNTRY_CODE.QATAR,
        placeholder: '+974',
      },
      {
        label: 'Reunion (+262)',
        value: COUNTRY_CODE.REUNION,
        placeholder: '+262',
      },
      {
        label: 'Romania (+40)',
        value: COUNTRY_CODE.ROMANIA,
        placeholder: '+40',
      },
      {
        label: 'Russia (+7)',
        value: COUNTRY_CODE.RUSSIA,
        placeholder: '+7',
      },
      {
        label: 'Rwanda (+250)',
        value: COUNTRY_CODE.RWANDA,
        placeholder: '+250',
      },
      {
        label: 'Saint Barthelemy (+590)',
        value: COUNTRY_CODE.SAINT_BARTHELEMY,
        placeholder: '+590',
      },
      {
        label: 'Saint Kitts And Nevis (+1869)',
        value: COUNTRY_CODE.SAINT_KITTS_AND_NEVIS,
        placeholder: '+1869',
      },
      {
        label: 'Saint Martin (+590)',
        value: COUNTRY_CODE.SAINT_MARTIN,
        placeholder: '+590',
      },
      {
        label: 'San Marino (+378)',
        value: COUNTRY_CODE.SAN_MARINO,
        placeholder: '+378',
      },
      {
        label: 'Sao Tome And Principe (+239)',
        value: COUNTRY_CODE.SAO_TOME_AND_PRINCIPE,
        placeholder: '+239',
      },
      {
        label: 'Saudi Arabia (+966)',
        value: COUNTRY_CODE.SAUDI_ARABIA,
        placeholder: '+966',
      },
      {
        label: 'Senegal (+221)',
        value: COUNTRY_CODE.SENEGAL,
        placeholder: '+221',
      },
      {
        label: 'Serbia (+381)',
        value: COUNTRY_CODE.SERBIA,
        placeholder: '+381',
      },
      {
        label: 'Seychelles (+248)',
        value: COUNTRY_CODE.SEYCHELLES,
        placeholder: '+248',
      },
      {
        label: 'Sierra Leone (+232)',
        value: COUNTRY_CODE.SIERRA_LEONE,
        placeholder: '+232',
      },
      {
        label: 'Singapore (+65)',
        value: COUNTRY_CODE.SINGAPORE,
        placeholder: '+65',
      },
      {
        label: 'Sint Maarten (+1721)',
        value: COUNTRY_CODE.SINT_MAARTEN,
        placeholder: '+1721',
      },
      {
        label: 'Slovakia (+421)',
        value: COUNTRY_CODE.SLOVAKIA,
        placeholder: '+421',
      },
      {
        label: 'Slovenia (+386)',
        value: COUNTRY_CODE.SLOVENIA,
        placeholder: '+386',
      },
      {
        label: 'Somalia (+252)',
        value: COUNTRY_CODE.SOMALIA,
        placeholder: '+252',
      },
      {
        label: 'South Africa (+27)',
        value: COUNTRY_CODE.SOUTH_AFRICA,
        placeholder: '+27',
      },
      {
        label: 'South Georgia And Sandwich Isl (+500)',
        value: COUNTRY_CODE.SOUTH_GEORGIA_AND_SANDWICH_ISL,
        placeholder: '+500',
      },
      {
        label: 'South Sudan (+211)',
        value: COUNTRY_CODE.SOUTH_SUDAN,
        placeholder: '+211',
      },
      {
        label: 'Spain (+34)',
        value: COUNTRY_CODE.SPAIN,
        placeholder: '+34',
      },
      {
        label: 'Sri Lanka (+94)',
        value: COUNTRY_CODE.SRI_LANKA,
        placeholder: '+94',
      },
      {
        label: 'St Vincent And The Grenadines (+1784)',
        value: COUNTRY_CODE.ST_VINCENT_AND_THE_GRENADINES,
        placeholder: '+1784',
      },
      {
        label: 'St. Helena Island (+290)',
        value: COUNTRY_CODE.ST_HELENA_ISLAND,
        placeholder: '+290',
      },
      {
        label: 'St. Lucia (+1758)',
        value: COUNTRY_CODE.ST_LUCIA,
        placeholder: '+1758',
      },
      {
        label: 'St. Pierre And Miquelon (+508)',
        value: COUNTRY_CODE.ST_PIERRE_AND_MIQUELON,
        placeholder: '+508',
      },
      {
        label: 'Sudan (+249)',
        value: COUNTRY_CODE.SUDAN,
        placeholder: '+249',
      },
      {
        label: 'Suriname (+597)',
        value: COUNTRY_CODE.SURINAME,
        placeholder: '+597',
      },
      {
        label: 'Svalbard And Jan Mayen (+47)',
        value: COUNTRY_CODE.SVALBARD_AND_JAN_MAYEN,
        placeholder: '+47',
      },
      {
        label: 'Sweden (+46)',
        value: COUNTRY_CODE.SWEDEN,
        placeholder: '+46',
      },
      {
        label: 'Switzerland (+41)',
        value: COUNTRY_CODE.SWITZERLAND,
        placeholder: '+41',
      },
      {
        label: 'Syrian Arab Republic (+963)',
        value: COUNTRY_CODE.SYRIAN_ARAB_REPUBLIC,
        placeholder: '+963',
      },
      {
        label: 'Taiwan (+886)',
        value: COUNTRY_CODE.TAIWAN,
        placeholder: '+886',
      },
      {
        label: 'Tajikistan (+992)',
        value: COUNTRY_CODE.TAJIKISTAN,
        placeholder: '+992',
      },
      {
        label: 'Tanzania-United Republic (+255)',
        value: COUNTRY_CODE.TANZANIA_UNITED_REPUBLIC,
        placeholder: '+255',
      },
      {
        label: 'Thailand (+66)',
        value: COUNTRY_CODE.THAILAND,
        placeholder: '+66',
      },
      {
        label: 'Timor Leste (+670)',
        value: COUNTRY_CODE.TIMOR_LESTE,
        placeholder: '+670',
      },
      {
        label: 'Togo (+228)',
        value: COUNTRY_CODE.TOGO,
        placeholder: '+228',
      },
      {
        label: 'Tokelau (+690)',
        value: COUNTRY_CODE.TOKELAU,
        placeholder: '+690',
      },
      {
        label: 'Trinidad And Tobago (+1868)',
        value: COUNTRY_CODE.TRINIDAD_AND_TOBAGO,
        placeholder: '+1868',
      },
      {
        label: 'Tunisia (+216)',
        value: COUNTRY_CODE.TUNISIA,
        placeholder: '+216',
      },
      {
        label: 'Turkiye (+90)',
        value: COUNTRY_CODE.TURKIYE,
        placeholder: '+90',
      },
      {
        label: 'Turkmenistan (+993)',
        value: COUNTRY_CODE.TURKMENISTAN,
        placeholder: '+993',
      },
      {
        label: 'Turks And Caicos Islands (+1649)',
        value: COUNTRY_CODE.TURKS_AND_CAICOS_ISLANDS,
        placeholder: '+1649',
      },
      {
        label: 'Tuvalu (+688)',
        value: COUNTRY_CODE.TUVALU,
        placeholder: '+688',
      },
      {
        label: 'U.S. Minor Outlying Islands (+1)',
        value: COUNTRY_CODE.US_MINOR_OUTLYING_ISLANDS,
        placeholder: '+1',
      },
      {
        label: 'Uganda (+256)',
        value: COUNTRY_CODE.UGANDA,
        placeholder: '+256',
      },
      {
        label: 'Ukraine (+380)',
        value: COUNTRY_CODE.UKRAINE,
        placeholder: '+380',
      },
      {
        label: 'United Arab Emirates (+971)',
        value: COUNTRY_CODE.UNITED_ARAB_EMIRATES,
        placeholder: '+971',
      },
      {
        label: 'United Kingdom (+44)',
        value: COUNTRY_CODE.UNITED_KINGDOM,
        placeholder: '+44',
      },
      {
        label: 'United States Of America (+1)',
        value: COUNTRY_CODE.UNITED_STATES_OF_AMERICA,
        placeholder: '+1',
      },
      {
        label: 'Uruguay (+598)',
        value: COUNTRY_CODE.URUGUAY,
        placeholder: '+598',
      },
      {
        label: 'Uzbekistan (+998)',
        value: COUNTRY_CODE.UZBEKISTAN,
        placeholder: '+998',
      },
      {
        label: 'Vatican (+379)',
        value: COUNTRY_CODE.VATICAN,
        placeholder: '+379',
      },
      {
        label: 'Venezuela (+58)',
        value: COUNTRY_CODE.VENEZUELA,
        placeholder: '+58',
      },
      {
        label: 'Vietnam (+84)',
        value: COUNTRY_CODE.VIETNAM,
        placeholder: '+84',
      },
      {
        label: 'Virgin Islands-British (+1284)',
        value: COUNTRY_CODE.VIRGIN_ISLANDS_BRITISH,
        placeholder: '+1284',
      },
      {
        label: 'Virgin Islands-United States (+1340)',
        value: COUNTRY_CODE.VIRGIN_ISLANDS_UNITED_STATES,
        placeholder: '+1340',
      },
      {
        label: 'Wallis And Futuna Islands (+681)',
        value: COUNTRY_CODE.WALLIS_AND_FUTUNA_ISLANDS,
        placeholder: '+681',
      },
      {
        label: 'Western Sahara (+212)',
        value: COUNTRY_CODE.WESTERN_SAHARA,
        placeholder: '+212',
      },
      {
        label: 'Yemen Republic (+967)',
        value: COUNTRY_CODE.YEMEN_REPUBLIC,
        placeholder: '+967',
      },
      {
        label: 'Zambia (+260)',
        value: COUNTRY_CODE.ZAMBIA,
        placeholder: '+260',
      },
      {
        label: 'Zimbabwe (+263)',
        value: COUNTRY_CODE.ZIMBABWE,
        placeholder: '+263',
      },
    ],
  },
];
