import get from 'lodash/get';
import find from 'lodash/find';
import map from 'lodash/map';
import toLower from 'lodash/toLower';
import reduce from 'lodash/reduce';
import startsWith from 'lodash/startsWith';
import SmoothScroll from 'smooth-scroll';
import qs from 'qs';
import jwtDecode from 'jwt-decode';
import { DateTime } from 'luxon';
import toUpper from 'lodash/toUpper';
import omit from 'lodash/omit';

export const serverTimeZone = { zone: 'Australia/Brisbane' };

// Points Pro challenge status card status
export const CHALLENGE_STATUSES = {
  NOT_ACCEPTED: 'challengeNotAccepted', // Challenge not accepted and campaign not started
  ACCEPTED: 'challengeAccepted', // Challenge accepted and campaign not started
  ACTIVITY_STARTED: 'challengePreviouslyAccepted', // Challenge accepted and campaign started
  REGISTRATION_ENDED: 'challengeNotAcceptedBeforeTime', // Challenge not accepted and campaign started
  ACTIVITY_ENDED: 'challengeEnded', // Challenge accepted and Campaign ended
  INELIGIBLE: 'ineligibleMember', // member is not eligible
};

export const ACTIVATION_STATUSES = {
  REGISTERED: 'REGISTERED',
  ACTIVE: 'REGISTRABLE',
  INACTIVE: 'NON_REGISTRABLE',
};

export const API_RESPONSE_CODES = {
  PROMOTION_CLOSED: 'Promotion Closed',
  PROMOTION_CAP_REACHED: 'Promotion Cap Reached',
  SUCCESS: 'SUCCESS',
  ALREADY_ACTIVATED: 'Already Activated',
};

export const POST_API_RESPONSE_CODES = {
  SUCCESS: 'SUCCESS',
  ALREADY_ACTIVATED: 'Already Activated',
};

// Do NOT change following string value unless confirm with AEM team
export const COMPONENT_NAME = {
  iconTiles: 'aem-icon-tiles',
  iconTilesCarousel: 'aem-icon-tiles-carousel',
  stripBanner: 'aem-strip-banner',
  singleFeaturedContent: 'aem-single-featured-content',
  richTextContent: 'aem-rich-text',
  accordionModule: 'aem-accordion',
  accordionComparison: 'aem-accordion_comparison',
  activatedOffer: 'aem-activated-offer',
  activatedOfferList: 'aem-activated-offer-list',
  banner: 'aem-banner',
  breadCrumb: 'aem-breadcrumb',
  callOut: 'aem-callout',
  cancellationForm: 'aem-cancellation-form',
  changePassword: 'aem-my-security-change-password',
  contentTiles: 'aem-content-tiles',
  cookieNotice: 'aem-cookie-notice',
  deepLinking: 'aem-deep-linking',
  downloadDigitalCard: 'aem-download-digital-card',
  familyPointsPooling: 'aem-family_pooling_container',
  familyPointsTransfer: 'aem-family_points_transfer_container',
  footer: 'aem-footer',
  fullPageBanner: 'aem-full-page-banner',
  heroBanner: 'aem-hero-banner',
  heroBannerCarousel: 'aem-hero-banner-carousel',
  imageTiles: 'aem-image-tiles',
  inPageBanner: 'aem-in-page-banner',
  joinPage: 'aem-join-page',
  liteAndPromoJoinPage: 'aem-lite-promo-join-page',
  joinFormWelcomePage: 'aem-join-form-welcome-page',
  linkGroups: 'aem-link-groups',
  logoList: 'aem-logo-list',
  activityStatement: 'aem-activity-statement',
  mileageCalculator: 'aem-mileage-calculator',
  myBenefitsWestpac: 'aem-my-benefits',
  managePin: 'aem-my_security_manage_pin',
  navigation: 'aem-navigation',
  notification: 'aem-notification',
  partnerBanner: 'aem-partner-banner',
  partnerLists: 'aem-partner_list',
  partnerOfferList: 'aem-partner-olist',
  productTiles: 'aem-product-tiles',
  quickLinks: 'aem-quicklinks',
  responsiveTabs: 'aem-tabs',
  retroClaims: 'aem-retro-claims',
  connectedPartners: 'aem-my-connected-partners',
  partnerConsent: 'aem-partner-consent',
  searchBar: 'aem-search-bar',
  searchResult: 'aem-search-result',
  searchBanner: 'aem-search-banner',
  statusMatchForm: 'aem-status-match-form',
  video: 'aem-video',
  allOfferList: 'aem-all-offer-list',
  featuredOfferList: 'aem-folist',
  iconLinkTiles: 'aem-icon-link-tiles',
  accountDeletionForm: 'aem-account-deletion-form',
  requestCard: 'aem-request-a-card',
  benefitSelector: 'aem-benefit-selector',
  benefitSelectorV2: 'aem-benefit-selector-v2',
  manageSecurityQuestion: 'aem-manage-security-question',
  myDetails: 'aem-my-details-form',
  commentsAndFeedback: 'aem-comments-feedback-form',
  outageForm: 'aem-outage-form',
  myDetailsIncompleteMember: 'aem-incomplete-member-form',
  unsubscribe: 'aem-unsubscribe-user',
  grantRequest: 'aem-travel-coordinator-grant',
  forgotMember: 'aem-forgot-membership-form',
  createPassword: 'aem-create-password-form',
  travelCoordinatorList: 'aem-travel-coordinator-list',
  resetPassword: 'aem-reset-password-form',
  preferenceCenter: 'aem-preference-centre-form',
  downloadDigitalCardGWallet: 'aem-download-digital-card-google-wallet',
  businessFlyerBanner: 'aem-business-flyer-banner',
  businessFlyerNavigation: 'aem-business-flyer-navigation',
  businessFlyerTile: 'aem-business-flyer-offer-tile',
  businessFlyerOfferList: 'aem-business-flyer-olist',
  genericContentBlockList: 'aem-generic-content-block-list',
  shopAndEarnBanner: 'aem-shop-earn-banner',
  challengeStatusCard: 'aem-accept-challenge',
  faqSection: 'aem-faq-content-section',
  buyPointsCallToAction: 'aem-buy-points-cta-button',
};

// Below are the sample JSON example from image renditions:
// {
//   "imagesSet": {
//   "1280": "/content/dam/vff/velocity/1200x630-shanghai-fb-velocity-frequent-flyer.jpg/jcr:content/renditions/cq5dam.web.1280.1280.jpeg"
// },
//   "imageRenditionsMap": {
//   "small": {
//     "imagesSet": {
//       "720": "/content/dam/vff/velocity-new/partners-offers/airlines/delta-air-lines/images/1920x1280-delta-redeem-for-upgrades-vff.jpg/jcr:content/renditions/vffcore.web.720.0.jpg",
//           "960": "/content/dam/vff/velocity-new/partners-offers/airlines/delta-air-lines/images/1920x1280-delta-redeem-for-upgrades-vff.jpg/jcr:content/renditions/vffcore.web.960.0.jpg",
//           "1200": "/content/dam/vff/velocity-new/partners-offers/airlines/delta-air-lines/images/1920x1280-delta-redeem-for-upgrades-vff.jpg/jcr:content/renditions/vffcore.web.1200.0.jpg",
//           "1920": "/content/dam/vff/velocity-new/partners-offers/airlines/delta-air-lines/images/1920x1280-delta-redeem-for-upgrades-vff.jpg/jcr:content/renditions/vffcore.web.1920.0.jpg"
//     },
//     "imageAlignment": {
//       "horizontal": "left",
//           "vertical": "center"
//     },
//     "imageDefault": "/content/dam/vff/velocity-new/partners-offers/airlines/delta-air-lines/images/1920x1280-delta-redeem-for-upgrades-vff.jpg/jcr:content/renditions/vffcore.web.720.0.jpg"
//   },
//   "medium": {
//     "imageAlignment": {
//       "horizontal": "25%",
//           "vertical": "75%"
//     }
//   }
// },
//   "imageDefault": "/content/dam/vff/velocity/1200x630-shanghai-fb-velocity-frequent-flyer.jpg/jcr:content/renditions/cq5dam.web.1280.1280.jpeg"
// }
// The key in the below MEDIA_MAP should match with the key from the imageRenditionsMap,
// If the key for the media is missing, it will default to center center.
export const MEDIA_MAP = {
  small: '(max-width: 767px)',
  medium: '(min-width: 768px) and (max-width: 991px)',
  large: '(min-width: 992px) and (max-width: 1199px)',
  x_large: '(min-width: 1200px)',
};

export const focusableCssSelector =
  'a[href]:not([disabled]), button:not([disabled]), textarea:not([disabled]), input[type="text"]:not([disabled]), input[type="radio"]:not([disabled]), input[type="checkbox"]:not([disabled]), select:not([disabled])';

// Only browsers on Mac have devicePixelRatio, otherwise default to 1
const devicePixelRatio = Math.min(window.devicePixelRatio || 1, 2);

export const renderImage = (element, props) => {
  if (props && props.imagesSet) {
    const isBackground = element.tagName === 'DIV';

    const imageRenditionsMap = get(props, 'imageRenditionsMap');
    let matchesMedia;
    let imagesSetMap = props.imagesSet;
    if (imageRenditionsMap) {
      matchesMedia = find(imageRenditionsMap, (value, key) => {
        const mediaQuery = MEDIA_MAP[key];
        return mediaQuery && window.matchMedia(mediaQuery).matches;
      });
      imagesSetMap = get(matchesMedia, 'imagesSet', props.imagesSet);
    }

    // Get the imagesSet and parse to int
    const imagesSet = Object.keys(imagesSetMap).map((size) => parseInt(size, 10));

    // Get the container width
    const containerWidth = element.offsetWidth;

    // Convert in physical pixels
    const containerPixels = containerWidth * devicePixelRatio;

    // Find closest in array to containerPixels to determine displayed image
    const closest = imagesSet.reduce((prev, curr) =>
      Math.abs(curr - containerPixels) < Math.abs(prev - containerPixels) ? curr : prev,
    );

    if (isBackground) {
      let imageAlignmentHorizontal;
      let imageAlignmentVertical;
      if (matchesMedia) {
        imageAlignmentHorizontal = get(matchesMedia, 'imageAlignment.horizontal', 'center');
        imageAlignmentVertical = get(matchesMedia, 'imageAlignment.vertical', 'center');
      } else {
        imageAlignmentHorizontal = get(props, 'imageAlignment.horizontal');
        imageAlignmentVertical = get(props, 'imageAlignment.vertical');
      }

      // eslint-disable-next-line no-param-reassign
      element.style.backgroundImage = `url("${imagesSetMap[closest]}")`;

      if (imageAlignmentHorizontal && imageAlignmentVertical) {
        // eslint-disable-next-line no-param-reassign
        element.style.backgroundPosition = `${imageAlignmentHorizontal} ${imageAlignmentVertical}`;
      }
    } else {
      // eslint-disable-next-line no-param-reassign
      element.src = imagesSetMap[closest];
    }
  }
};

export function formatMembershipNumber(value) {
  if (!value) {
    return '';
  }
  return value.toString().replace(/(\d+)(\d{3})(\d{3})/g, '$1 $2 $3');
}

export const memberTier = {
  R: 'red',
  S: 'silver',
  G: 'gold',
  P: 'platinum',
  V: 'vip',
};

export const formatNumber = (number) => number.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');

export const getNameInitials = (firstName, lastName) => `${firstName.substring(0, 1)}${lastName.substring(0, 1)}`;

export function isPassiveEventListenerSupported() {
  let supportsPassive = false;

  try {
    const opts = Object.defineProperty({}, 'passive', {
      get: () => {
        supportsPassive = true;
        return supportsPassive;
      },
    });
    window.addEventListener('testPassive', null, opts);
    window.removeEventListener('testPassive', null, opts);
  } catch (e) {
    // do nothing
  }

  return supportsPassive;
}

export function getUniqueKey(value) {
  return (value || '').replace('/content/vff/velocity/en_au/home/', '').replace(/\//g, ':');
}

export function getNavigationHeight() {
  const headerMirror = document.getElementById('vff-header-mirror');
  return headerMirror ? headerMirror.offsetHeight : 0;
}

export function getPartnerBannerTabHeight() {
  const partnerBannerTab = document.getElementById('partner-banner-tabs-container');
  return partnerBannerTab ? partnerBannerTab.offsetHeight : 0;
}

export function scrollToRef(ref) {
  if (ref.current) {
    window.scroll({ top: ref.current.offsetTop - getNavigationHeight(), behavior: 'smooth' });
  }
}

export function scrollToElement(element, offset = 0) {
  if (element) {
    window.scroll({
      top: element.getBoundingClientRect().top + window.scrollY - getNavigationHeight() - offset,
      behavior: 'smooth',
    });
    setTimeout(() => element.focus(), 200);
  }
}

export function smoothScrollToElement(element, offset = 0) {
  if (element) {
    const scroll = new SmoothScroll();
    scroll.animateScroll(element, null, {
      offset,
      updateURL: false,
      speed: 500,
      speedAsDuration: true,
      easing: 'easeInOutCubic',
    });
  }
}

export function isElementVisible(element) {
  return !!(element.offsetWidth || element.offsetHeight || element.getClientRects().length);
}

export function isInternalLink(url) {
  if (!url || typeof url !== 'string') {
    return false;
  }

  if (url.charAt(0) === '/') {
    return true;
  }

  if (url.indexOf('velocityfrequentflyer.com') !== -1) {
    return true;
  }

  return false;
}

export function getPropsDataFromJsObjectKeyArray(componentData, windowObject, objectKey, itemDataKey) {
  return {
    ...componentData,
    [objectKey]: map(componentData[objectKey], (item) => {
      const itemData = get(windowObject, `[${item.jsObjectKey}]`) || {};

      return {
        ...item,
        ...(itemDataKey ? { [itemDataKey]: itemData } : itemData),
      };
    }),
  };
}

export function getNestedProperty(obj, path) {
  return path.split('.').reduce((res, prop) => {
    if (res === null || res === undefined) {
      return undefined;
    }
    return res[prop];
  }, obj);
}

export function getHashId() {
  return window.location.hash.replace('#', '');
}

// Decorate this for consumption for my velocity
window.vffCoreWebsite = {
  ...window.vffCoreWebsite,
  coreRenderImage: renderImage,
};

export function getCurrentUrl() {
  return window.location.href;
}

export function getParameterFromUrl(name, isOriginalCase = false, asIsDecoder = false) {
  const query = qs.parse(window.location.search, {
    ignoreQueryPrefix: true,
    ...(asIsDecoder ? { decoder: (value) => value } : {}),
  });

  return isOriginalCase ? query[name] : toLower(query[name]);
}

export function parseUrl(href) {
  const match = href.match(/^(https?:)\/\/(([^:/?#]*)(?::([0-9]+))?)([/]?[^?#]*)(\?[^#]*|)(#.*|)$/);

  return (
    match && {
      href,
      protocol: match[1],
      host: match[2],
      hostname: match[3],
      port: match[4],
      pathname: match[5],
      search: match[6],
      hash: match[7],
    }
  );
}

export function decodeJwtToken(token) {
  let decodeToken;

  try {
    decodeToken = jwtDecode(token);
  } catch (e) {
    decodeToken = {};
  }

  return decodeToken;
}

export function getGivenNameFromJwtToken(token) {
  return decodeJwtToken(token).given_name || '';
}

export function getFamilyNameFromJwtToken(token) {
  return decodeJwtToken(token).family_name || '';
}

export function isCtaAvailable(ctaContainer) {
  return ctaContainer && ctaContainer.ctaLabel;
}

export function isAbsoluteUrl(url) {
  const regEx = /^(http|https)?:\/\//i;
  return regEx.test(url);
}

export function isUrlExcluded(excludedPaths) {
  return reduce(
    excludedPaths,
    (result, currentPath) => {
      function isPathExcluded() {
        const parsedExcludedPathObject = new URL(
          `${isAbsoluteUrl(currentPath.pagePath) ? currentPath.pagePath : `${window.location.origin}${currentPath.pagePath}`}`,
        );
        const windowPathname = `${window.location.pathname}/`;

        return currentPath?.includeChildren
          ? startsWith(windowPathname, parsedExcludedPathObject.pathname) &&
              window.location.origin === parsedExcludedPathObject.origin
          : (window.location.pathname === parsedExcludedPathObject.pathname ||
              windowPathname === parsedExcludedPathObject.pathname) &&
              window.location.origin === parsedExcludedPathObject.origin;
      }

      return result || isPathExcluded();
    },
    false,
  );
}

export function isEnableVipTier() {
  return get(window, 'vffCoreWebsite.websiteData.enableVipTierDesign', false);
}

export const addDaysToToday = (days) => DateTime.now().plus({ days }).toFormat('yyyy-MM-dd');

export const contactDeviceType = {
  mobile: 'MOBILE',
  landline: 'LANDLINE',
};

export const findPhoneByType = (contacts, type) => find(contacts, (contact) => toUpper(contact.deviceType) === type);
export const getMobileDisplay = ({ countryCode, number }) =>
  `${countryCode ? '+' : ''}${countryCode || ''}${number || ''}`;

export const getLandlineDisplay = ({ countryCode, areaCode, number }) =>
  `${countryCode ? '+' : ''}${countryCode || ''}${areaCode || ''}${number || ''}`;

export const getAuthorableErrorMsg = (error, authoredMsg) => {
  const errorCode = get(error, 'response.data.code', '');
  const errorFields = get(error, 'response.data.errorFields', '');
  const errorMsgObj = get(authoredMsg, 'apiErrorMessages');
  const getCodeSpecificError = find(errorMsgObj, (errorMsg) => errorMsg.code === errorCode && !errorMsg.errorFieldName);
  const getFieldSpecificError = reduce(
    errorFields,
    (result, errorField) =>
      result ||
      find(errorMsgObj, {
        code: errorCode,
        errorFieldName: errorField.field,
      }),
    null,
  );

  // `computedErrorMessage` returns the filtered errorMessage accordingly
  return getFieldSpecificError || getCodeSpecificError || get(authoredMsg, 'defaultErrorMessage');
};

export const loadJsFile = (url, callback) => {
  const s = document.createElement('script');
  s.setAttribute('src', url);

  s.onload = function () {
    if (callback) {
      callback();
    }
  };
  document.body.appendChild(s);
};

export const clearParams = (params) => {
  const query = qs.parse(window.location.search, { ignoreQueryPrefix: true });

  if (params.some((param) => query[param])) {
    const newQuery = qs.stringify(omit(query, params), { addQueryPrefix: true });
    window.history.pushState(
      '',
      document.title,
      `${window.location.origin}${window.location.pathname}${newQuery}${window.location.hash}`,
    );
  }
};

export const sleeper = (ms = 1000) =>
  new Promise((resolve) => {
    setTimeout(resolve, ms);
  });

export const relativeTimeDifference = (startTime, endTime, totalTime = 3000) => {
  const timeDifference = endTime - startTime;
  return timeDifference <= totalTime ? totalTime - timeDifference : 0;
};

export const analyticsEventAction = {
  click: 'click',
  impression: 'impression',
};

export const analyticsEventName = {
  clickCta: 'click-cta',
  modalsImpression: 'modals-impression',
  formStart: 'form-start',
  formSuccess: 'form-success',
  formFailure: 'form-failure',
  formStep: 'form-step',
  extensionImpression: 'extension-impression',
  ctaInteraction: 'cta-interaction',
  activatedOffer: 'activate-offer',
  activatedOfferSuccess: 'activate-offer-success',
  activatedOfferFail: 'activate-offer-fail',
  joinFormSuccessWelcomePage: 'joinform-success-welcome-page',
};

export const analyticsEventCategory = {
  offerListing: 'offer-listing',
  join: 'join',
};

export const analyticsCustomerType = {
  guest: 'Guest',
  member: 'member',
};

export const getCountryCode = (country) => ({
  label: country?.placeholder || country?.label.split(' ')[0],
  value: country?.value,
});
