const setCookie = (cname, cvalue, exdays, sessionCookie = false, isTopLevelDomain = false) => {
  if (sessionCookie) {
    document.cookie = `${cname}=${cvalue};${isTopLevelDomain ? 'domain=velocityfrequentflyer.com;' : ''}path=/`;
    return;
  }
  const d = new Date();
  d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000);
  const expires = `expires=${d.toUTCString()}`;
  document.cookie = `${cname}=${cvalue};${expires};${isTopLevelDomain ? 'domain=velocityfrequentflyer.com;' : ''}path=/`;
};

const getCookie = (cname) => {
  const name = `${cname}=`;
  const ca = document.cookie.split(';');
  let result = '';
  ca.forEach((cookie) => {
    let c = cookie;
    while (c.charAt(0) === ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) === 0) {
      result = c.substring(name.length, c.length);
    }
  });
  return result;
};

export { setCookie, getCookie };
