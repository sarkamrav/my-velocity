import get from 'lodash/get';
import { getCookie, setCookie } from './cookies';
import { isUrlExcluded } from './common';

export function darkSiteManager() {
  const darkSiteCookieId = 'vffDarkSite';
  const darkSiteCookieValue = 'enabled';
  const darkSiteSetting = get(window, 'vffCoreWebsite.darkSiteSetting');

  if (darkSiteSetting?.darkSiteEnabled) {
    const hasDarkSiteCookieSet = getCookie(darkSiteCookieId) === darkSiteCookieValue;

    if (!hasDarkSiteCookieSet) {
      const isRedirectionExcluded = isUrlExcluded(darkSiteSetting.excludedPaths);

      if (!isRedirectionExcluded) {
        setCookie(darkSiteCookieId, darkSiteCookieValue, null, true, true);

        if (darkSiteSetting.darkSiteUrl) {
          window.location.href = darkSiteSetting.darkSiteUrl;
        }
      }
    }
  }
}
