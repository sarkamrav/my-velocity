import { contentProtection } from './contentProtection';

describe('contentProtection()', () => {
  const originalWindowLocation = window.location;

  beforeEach(() => {
    delete window.location;
    window.location = {
      href: '',
    };

    document.body.classList.remove = jest.fn();
  });

  describe('Enabled', () => {
    const contentProtectionMock = {
      redirectionUrl: '/my-velocity',
      whitelistTiers: [
        {
          tierLevel: 'V',
          subTierLevel: 'S',
        },
        {
          mainTier: 'V',
          subTierLevel: 'L',
        },
        {
          mainTier: 'V',
          subTierLevel: 'P',
        },
      ],
    };

    beforeEach(() => {
      window.vffCoreWebsite = {};
      window.vffCoreWebsite.contentProtectionSetting = contentProtectionMock;
    });

    test('Should redirect member away when tier is NOT white listed', () => {
      contentProtection({
        tierLevel: 'R',
        subTierLevel: 'S',
      });

      expect(window.location.href).toBe(contentProtectionMock.redirectionUrl);
    });

    test('Should NOT redirect member away when tier is white listed', () => {
      contentProtection({
        tierLevel: 'V',
        subTierLevel: 'S',
      });

      expect(window.location.href).toBe('');
    });

    test('Should show content when tier is white listed', () => {
      contentProtection({
        tierLevel: 'V',
        subTierLevel: 'S',
      });

      expect(document.body.classList.remove).toHaveBeenLastCalledWith('vffutils__display--none');
    });

    afterEach(() => {
      window.vffCoreWebsite.contentProtectionSetting = null;
    });
  });

  describe('Disabled', () => {
    test('Should Not redirect or show content', () => {
      contentProtection({
        tierLevel: 'R',
        subTierLevel: 'S',
      });

      expect(window.location.href).toBe('');
      expect(document.body.classList.remove).not.toHaveBeenCalled();
    });
  });

  afterEach(() => {
    window.location = originalWindowLocation;
    document.body.classList.remove.mockRestore();
  });
});
