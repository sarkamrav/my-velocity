import { getCookie, setCookie } from './cookies';

const keycloakStorageKey = 'keycloak-token';
const cookieSessionActive = 'session-active';
const cookieAuthenticated = 'authenticated';
const cookieMember = 'member';
const memberCookieTimeoutDays = 9999;

const cookieVffAccountData = 'vff-account-data'; // legacy cookie
const cookieVffMemberData = 'vff_memberData'; // cookie created by Tealium

class KeycloakStorageHandler {
  static validateTokens() {
    if (!KeycloakStorageHandler.sessionCookieExists()) {
      KeycloakStorageHandler.removeStorageToken();
    }
  }

  static isSessionActive() {
    return KeycloakStorageHandler.authenticatedCookieExists() && KeycloakStorageHandler.sessionCookieExists();
  }

  static getKeycloakData() {
    const stored = localStorage.getItem(keycloakStorageKey);
    return KeycloakStorageHandler.isSessionActive() && stored ? JSON.parse(stored) : {};
  }

  static setAuthenticatedCookie(token) {
    const tokenTimeoutLength = token.exp * 1000;
    const currentTime = Date.now();
    const timeDifferenceInDays = (tokenTimeoutLength - currentTime) / (1000 * 60 * 60 * 24);
    if (!KeycloakStorageHandler.authenticatedCookieExists()) {
      setCookie(cookieAuthenticated, 'true', timeDifferenceInDays);
    }
  }

  static setMemberCookie() {
    if (!getCookie(cookieMember)) {
      setCookie(cookieMember, 'true', memberCookieTimeoutDays);
    }
  }

  static removeStorageToken() {
    localStorage.removeItem(keycloakStorageKey);
    KeycloakStorageHandler.removeCookie(cookieSessionActive);
    KeycloakStorageHandler.removeCookie(cookieAuthenticated);

    KeycloakStorageHandler.removeCookie(cookieVffAccountData);
    KeycloakStorageHandler.removeCookie(cookieVffMemberData, true);
  }

  static removeCookie(cookieName, isTopLevelDomain = false) {
    setCookie(cookieName, '', -1, false, isTopLevelDomain);
  }

  static setStorageToken(tokenData) {
    localStorage.setItem(keycloakStorageKey, JSON.stringify(tokenData));
    if (!KeycloakStorageHandler.sessionCookieExists()) {
      setCookie(cookieSessionActive, 'true', 0, true);
    }
  }

  static getStorageToken() {
    return JSON.parse(localStorage.getItem(keycloakStorageKey));
  }

  static authenticatedCookieExists() {
    return getCookie(cookieAuthenticated) === 'true';
  }

  static memberCookieExists() {
    return getCookie(cookieMember) === 'true';
  }

  static sessionCookieExists() {
    return getCookie(cookieSessionActive) === 'true';
  }
}

export default KeycloakStorageHandler;
