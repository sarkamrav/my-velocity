import { get } from 'lodash';
import cookie from 'cookie';
import store from '../stores';
import * as userData from '../stores/utilities';

function analyticsSend(additionalData = {}) {
  const user = get(store.getState(), 'user', {});

  const data = {
    ...(window.digitalLayer || {}),

    memberStatusTier: userData.getTierLevel(user),
    memberStatusSubTier: userData.getSubTierLevel(user),
    memberPointsBalance: userData.getCurrentPointsBalance(user),
    memberStatusCreditBalance: userData.getStatusCreditsBalance(user),
    joinDate: userData.getJoinDate(user),
    // customerState: user ? 'authenticated' : 'unauthenticated', // Added this back in place due to old my-velocity firing this information. (TODO: move Tealium code into repository. This has been omitted due to Tealium handling on their side.)
    customerType: cookie.parse(document.cookie).member ? 'member' : 'guest',
    velocityID: userData.getLoyaltyMembershipID(user),

    ...additionalData,
  };

  if (window.utag && window.utag.link) {
    window.utag.link(data);
  } else {
    // eslint-disable-next-line no-console
    console.log('*** utag link ***', data);
  }
}

// Decorate this for consumption for my velocity
window.vffCoreWebsite = {
  ...window.vffCoreWebsite,
  coreAnalytics: {
    send: analyticsSend,
  },
};

export default analyticsSend;
