import get from 'lodash/get';

export const newRelicErrorPrefix = {
  velocityWebsite: 'velocity-website-',
  unhandledError: 'unhandled-error-',
  errorApi: 'error-api-',
};

export const sendToNewRelic = (action, payload) => {
  try {
    if (window && window.newrelic) {
      window.newrelic.addPageAction(`${newRelicErrorPrefix.velocityWebsite}${action}`, payload);
    }
  } catch (error) {
    console.warn(error); // eslint-disable-line
  }
};

export const getApiError = (module, error = {}) => ({
  module,
  error: get(error, 'response.data'),
});

export const getApiActionName = (baseUrl = '', pathname = '') =>
  baseUrl ? `${newRelicErrorPrefix.errorApi}${baseUrl}${pathname}` : `${newRelicErrorPrefix.errorApi}multiple-urls`;
