import _ from 'lodash';
import createAxios from 'axios';
import qs from 'qs';

import store from '../stores';
import ssoHandler from './ssoHandler';
import { getCookie } from './cookies';
import { IMPERSONATE_TOKEN_COOKIE_NAME } from './constants';

const getCommonSettings = (isClientChannelRequired) => ({
  headers: {
    common: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      ...(isClientChannelRequired ? { 'Client-Channel': 'WEB' } : {}),
    },
  },
});

function initializeAxiosForExternalParty(baseURL) {
  const axios = createAxios.create({
    ...getCommonSettings(),
    baseURL,
  });

  return axios;
}

function initializeAxiosForBusinessFlyer(baseURL, apiKey, isClientChannelRequired = false) {
  const axios = createAxios.create({
    ...getCommonSettings(isClientChannelRequired),
    baseURL,
  });

  axios.interceptors.request.use((config) => ({
    ...config,
    headers: {
      ...config.headers,
      ...(apiKey ? { 'X-APIKey': apiKey } : {}),
    },
  }));

  return axios;
}

function initializeAxiosWithoutKeycloak(baseURL, apiKey, isClientChannelRequired = false) {
  const axios = createAxios.create({
    ...getCommonSettings(isClientChannelRequired),
    baseURL,
  });

  axios.interceptors.request.use((config) => ({
    ...config,
    headers: {
      ...config.headers,
      ...(apiKey ? { 'X-APIKey': apiKey } : {}),
    },
  }));

  return axios;
}

function initializeAxios(baseURL, isBearer = false, apiKey, isClientChannelRequired = false, jwtAndBearer = true) {
  const axios = createAxios.create({
    ...getCommonSettings(isClientChannelRequired),
    baseURL,
  });

  axios.interceptors.request.use((config) => {
    try {
      const keycloak = JSON.parse(localStorage.getItem('keycloak-token'));
      // `impersonateToken` needs to replace the keycloak token while impersonating
      const impersonateToken = getCookie(IMPERSONATE_TOKEN_COOKIE_NAME);
      if (impersonateToken) {
        keycloak.token = impersonateToken;
      }

      const baseConfig = {
        ...config,
        headers: {
          ...config.headers,
          ...(apiKey ? { 'X-APIKey': apiKey } : {}),
        },
      };

      if (keycloak) {
        const bearerOrJwt = isBearer
          ? { Authorization: `Bearer ${keycloak.token}` }
          : { 'X-JWT-ID-Token': keycloak.token };
        const tokenInfo = jwtAndBearer ? bearerOrJwt : {};

        return {
          ...baseConfig,
          headers: {
            ...baseConfig.headers,
            ...tokenInfo,
          },
        };
      }

      return baseConfig;
    } catch (error) {
      return config;
    }
  });

  // This may not be required due to onTokenExpired
  axios.interceptors.response.use(undefined, (error) => {
    const { status, config: originalRequest } = error.response;

    // Potential unauthenticated/forbidden calls
    if (_.includes([401, 403], status)) {
      // If this is not a retryRequest, refresh the token and fire the request again
      if (!originalRequest.__isRetryRequest) {
        return new Promise((resolve, reject) => {
          ssoHandler?.keycloakAuth
            .updateToken(30)
            .success((refreshed) => {
              originalRequest.__isRetryRequest = true;

              if (!refreshed) {
                reject(error);
              }

              if (refreshed) {
                ssoHandler.saveAuthInfo();
                resolve(axios(originalRequest));
              }
            })
            .error(() => {
              // If the refreshToken attempt fails, let's redirect them to login page
              const url = `${window.location.origin}${window.location.pathname}`;
              const querystring = qs.parse(window.location.search, { ignoreQueryPrefix: true });

              try {
                ssoHandler.keycloakAuth.login({
                  redirectUri: `${url}${qs.stringify(
                    {
                      ...querystring,
                      explicit_login: 'web',
                    },
                    { addQueryPrefix: true },
                  )}`,
                });
              } catch (e) {
                reject(e);
              }

              reject(error);
            });
        });
      }
    }

    return Promise.reject(error);
  });

  return axios;
}

class Api {
  constructor() {
    this.vffApi = initializeAxios(
      _.get(window, 'vffCoreWebsite.websiteData.vffApiUrl'),
      false,
      _.get(store.getState(), 'websiteData.lmsApiKey'),
    );
    this.vffPointsBoosterApi = initializeAxios(
      _.get(window, 'vffCoreWebsite.websiteData.vffApiUrl'),
      false,
      _.get(store.getState(), 'websiteData.lmsApiKey'),
      true,
    );
    this.vffApiNoKeycloak = initializeAxiosWithoutKeycloak(
      _.get(window, 'vffCoreWebsite.websiteData.vffApiUrl'),
      _.get(store.getState(), 'websiteData.lmsApiKey'),
      true,
    );
    this.vffV2Api = initializeAxios(
      _.get(window, 'vffCoreWebsite.websiteData.vffApiUrl'),
      true,
      _.get(store.getState(), 'websiteData.lmsApiKey'),
      true,
    );
    this.vffV2ApiNoToken = initializeAxios(
      _.get(window, 'vffCoreWebsite.websiteData.vffApiUrl'),
      true,
      _.get(store.getState(), 'websiteData.lmsApiKey'),
      true,
      false,
    );
    this.vffV2NoKeycloak = initializeAxiosWithoutKeycloak(
      _.get(window, 'vffCoreWebsite.websiteData.vffApiUrl'),
      _.get(store.getState(), 'websiteData.lmsApiKey'),
      true,
    );
    this.vffBauV2Api = initializeAxios(
      _.get(window, 'vffCoreWebsite.websiteData.vffApiUrl'),
      true,
      _.get(store.getState(), 'websiteData.lmsApiKey'),
    );
    this.vaCloudApi = initializeAxios(
      _.get(window, 'vffCoreWebsite.websiteData.vaCloudApiUrl'),
      true,
      _.get(store.getState(), 'websiteData.vaCloudApiKey'),
    );
    this.aemApi = initializeAxios(_.get(window, 'vffCoreWebsite.websiteData.aemApiUrl', '/'));
    this.aemVaProxyApi = initializeAxiosWithoutKeycloak(
      _.get(window, 'vffCoreWebsite.websiteData.aemApiUrl'),
      _.get(store.getState(), 'websiteData.lmsApiKey'),
      true,
    );
    this.funnelback = initializeAxiosForExternalParty(_.get(window, 'vffCoreWebsite.websiteData.funnelbackUrl'));
    this.velocityConnectPartnerApi = initializeAxiosForExternalParty(
      _.get(window, 'vffCoreWebsite.websiteData.vffApiUrl'),
    );
    this.loyaltySmeV1Merchants = initializeAxiosForBusinessFlyer(
      _.get(window, 'vffCoreWebsite.websiteData.vffApiUrl'),
      _.get(window, 'vffCoreWebsite.websiteData.businessFlyerApiKey'),
      false,
    );
  }
}

const api = new Api();

// Decorate this for consumption for my velocity
window.vffCoreWebsite = {
  ...window.vffCoreWebsite,
  coreApi: api,
};

export default api;
