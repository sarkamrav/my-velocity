import get from 'lodash/get';
import findIndex from 'lodash/findIndex';

/*
 * This function redirect members to another page if their tiers are not in the tier white list on secure page template
 */
export function contentProtection(currentTierInfo) {
  const contentProtectionSetting = get(window, 'vffCoreWebsite.contentProtectionSetting', null);

  if (contentProtectionSetting) {
    const isMemberTierWhiteListed = findIndex(contentProtectionSetting.whitelistTiers, currentTierInfo) >= 0;

    if (!isMemberTierWhiteListed) {
      window.location.href = contentProtectionSetting.redirectionUrl;
    }

    if (isMemberTierWhiteListed) {
      document.body.classList.remove('vffutils__display--none');
    }
  }
}
