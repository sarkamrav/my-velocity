import * as common from './common';
import { darkSiteManager } from './darkSiteManager';
import * as cookies from './cookies';

describe('darkSiteManager()', () => {
  let isUrlExcludedSpy;
  let getCookieSpy;
  let setCookieSpy;
  const originalWindowLocation = window.location;

  beforeEach(() => {
    delete window.location;
    window.location = {
      href: '',
    };
    isUrlExcludedSpy = jest.spyOn(common, 'isUrlExcluded');
    getCookieSpy = jest.spyOn(cookies, 'getCookie');
    setCookieSpy = jest.spyOn(cookies, 'setCookie');
  });

  describe('When dark site is enabled', () => {
    const darkSiteEnabledMock = {
      excludedPaths: [
        {
          pagePath: 'https://dev-join.velocityfrequentflyer.com/',
          includeChildren: false,
        },
      ],
      darkSiteEnabled: true,
      darkSiteUrl: 'https://development.virginaustralia.io/au/en/information/current-information/',
    };

    beforeEach(() => {
      window.vffCoreWebsite.darkSiteSetting = darkSiteEnabledMock;
    });

    describe('No cookie', () => {
      test('Should set cookie and redirect member to dark site when URL is not excluded', () => {
        isUrlExcludedSpy.mockReturnValue(false);
        getCookieSpy.mockReturnValue(undefined);
        darkSiteManager();

        expect(getCookieSpy).toHaveBeenCalled();
        expect(getCookieSpy).toHaveBeenCalled();
        expect(window.location.href).toBe(darkSiteEnabledMock.darkSiteUrl);
      });

      test('Should NOT set cookie and redirect member to dark site when URL is excluded', () => {
        isUrlExcludedSpy.mockReturnValue(true);
        getCookieSpy.mockReturnValue(undefined);
        darkSiteManager();

        expect(getCookieSpy).toHaveBeenCalled();
        expect(setCookieSpy).not.toHaveBeenCalled();
        expect(window.location.href).toBe('');
      });
    });

    describe('With cookie', () => {
      test('Should NOT redirect member to dark site', () => {
        getCookieSpy.mockReturnValue('enabled');
        darkSiteManager();

        expect(isUrlExcludedSpy).not.toHaveBeenCalled();
        expect(window.location.href).toBe('');
      });
    });

    afterEach(() => {
      window.vffCoreWebsite.darkSiteSetting = null;
    });
  });

  describe('When dark site is disabled', () => {
    test('Should NOT redirect member to dark site', () => {
      window.vffCoreWebsite.darkSiteSetting = {
        excludedPaths: [
          {
            pagePath: 'https://dev-join.velocityfrequentflyer.com/',
            includeChildren: false,
          },
        ],
        darkSiteEnabled: false,
        darkSiteUrl: 'https://development.virginaustralia.io/au/en/information/current-information/',
      };

      darkSiteManager();

      expect(getCookieSpy).not.toHaveBeenCalled();
      expect(isUrlExcludedSpy).not.toHaveBeenCalled();
      expect(setCookieSpy).not.toHaveBeenCalled();
      expect(window.location.href).toBe('');

      window.vffCoreWebsite.darkSiteSetting = null;
    });
  });

  afterEach(() => {
    window.location = originalWindowLocation;
    isUrlExcludedSpy.mockRestore();
    getCookieSpy.mockRestore();
    setCookieSpy.mockRestore();
  });
});
