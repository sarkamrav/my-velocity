/* eslint-disable class-methods-use-this */
import _ from 'lodash';
import qs from 'qs';
import KeycloakStorageHandler from './keycloakStorageHandler';

class SsoHandler {
  constructor() {
    const ssoConfig = _.get(window.vffCoreWebsite, 'keycloak');
    KeycloakStorageHandler.validateTokens();

    if (ssoConfig && window.Keycloak) {
      this.keycloakAuth = new window.Keycloak(ssoConfig);
    }
  }

  getKeycloakUser = () => this.keycloakAuth.tokenParsed;

  init = (loginRequired = false) =>
    new Promise((resolve, reject) => {
      if (this.keycloakAuth) {
        this.keycloakAuth
          .init({
            responseMode: 'fragment',
            onLoad: 'check-sso',
            ...KeycloakStorageHandler.getKeycloakData(),
          })
          .success((authenticated) => {
            if (authenticated) {
              this.saveAuthInfo();
            } else if (loginRequired || window.vffCoreWebsite.websiteData.loginRequired) {
              // If AEM flags the page as login required, create the login URL with the login_hint
              const url = `${window.location.origin}${window.location.pathname}`;
              const querystring = qs.parse(window.location.search, { ignoreQueryPrefix: true });

              const loginUrl = this.keycloakAuth.createLoginUrl({
                redirectUri: `${url}${qs.stringify(querystring, { addQueryPrefix: true })}`,
                loginHint: querystring.login_hint,
              });
              window.location.href = loginUrl;
            }
            resolve(authenticated);
          })
          .error(() => {
            reject();
          });

        this.keycloakAuth.onTokenExpired = () => {
          this.keycloakAuth
            .updateToken(30)
            .success((refreshed) => {
              if (refreshed) {
                this.saveAuthInfo();
              }
            })
            .error(() => this.clearAuthData());
        };
        this.keycloakAuth.onAuthRefreshError = this.clearAuthData;
        this.keycloakAuth.onAuthLogout = this.clearAuthData;
      } else {
        reject(new Error('Keycloak has not been set up.'));
      }
    });

  saveAuthInfo = () => {
    KeycloakStorageHandler.setMemberCookie();
    KeycloakStorageHandler.setAuthenticatedCookie(this.keycloakAuth.refreshTokenParsed);
    KeycloakStorageHandler.setStorageToken({
      idToken: this.keycloakAuth.idToken,
      token: this.keycloakAuth.token,
      refreshToken: this.keycloakAuth.refreshToken,
      timeSkew: this.keycloakAuth.timeSkew,
    });
  };

  getStorageToken = () => KeycloakStorageHandler.getStorageToken();

  clearAuthData = () => {
    if (this.keycloakAuth && this.keycloakAuth.clearToken) {
      this.keycloakAuth.clearToken();
      KeycloakStorageHandler.removeStorageToken();
    }
  };

  getPostLogoutUri = () => _.get(window.vffCoreWebsite, 'websiteData.postUpgradeLogoutUri');

  logout = (e) => {
    if (e && e.preventDefault) {
      e.preventDefault();
    }

    const logoutUri = _.get(window.vffCoreWebsite, 'websiteData.logoutRedirectUri');
    const postLogoutUri = this.getPostLogoutUri();

    if (postLogoutUri) {
      window.location = `${postLogoutUri}${this.keycloakAuth?.idToken ? `&id_token_hint=${this.keycloakAuth.idToken}` : ''}`;
    } else if (logoutUri) {
      window.location = logoutUri;
    } else {
      this.keycloakAuth.logout({ redirectUri: window.location.origin });
    }
  };
}

export default new SsoHandler();
