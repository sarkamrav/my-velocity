import isString from 'lodash/isString';
import each from 'lodash/each';
import isEmpty from 'lodash/isEmpty';
import { DateTime } from 'luxon';
import { serverTimeZone } from './common';

// eslint-disable-next-line default-param-last
export default function syncText(input = '', tags = {}, format) {
  let response = input || '';

  each((input || '').match(new RegExp('{{(.*?)}}', 'g')), (value) => {
    const key = value.replace('{{', '').replace('}}', '');
    let newValue = isEmpty(tags) ? '' : tags[key] || ''; // Empty string as default syncText

    // Matches date (i.e. 2019-12-25)
    // Hardcodes AEST due to Crane dependency
    if (isString(newValue) && newValue.match(/([12]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01]))/)) {
      newValue = `${DateTime.fromISO(newValue, serverTimeZone).toFormat(format || 'dd MMMM yyyy')} ${format ? '' : 'AEST'}`;
    }

    response = response.replace(new RegExp(`{{${key}}}`, 'g'), newValue);
  });

  return response;
}
