import { useState, useEffect } from 'react';

export default function useServerRendering() {
  const [rendered, setRendered] = useState(false);

  useEffect(() => {
    setRendered(true);
  }, []);

  return {
    rendered,
    setRendered,
  };
}
