import { useEffect, useCallback } from 'react';
import analyticsSend from '../utils/analytics';

export default function useAnalyticsOnMount(data = {}, canSendAnalytics = true) {
  const sendMountedAnalytics = useCallback(() => {
    if (canSendAnalytics) {
      analyticsSend(data);
    }
  }, [canSendAnalytics, data]);

  useEffect(() => {
    document.addEventListener('myProfile', sendMountedAnalytics);

    return () => {
      document.removeEventListener('myProfile', sendMountedAnalytics);
    };
  }, [sendMountedAnalytics]);

  return null;
}
