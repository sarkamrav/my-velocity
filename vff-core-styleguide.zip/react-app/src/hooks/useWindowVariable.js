import { useState, useEffect } from 'react';
import { getNestedProperty } from '@utils/common';

export const keys = {
  experian: 'vffCoreWebsite.websiteData.experianApiKey',
};

const useWindowVariable = (variablePath) => {
  const isBrowser = typeof window !== 'undefined';
  const [value, setValue] = useState(isBrowser ? getNestedProperty(window, variablePath) : undefined);

  useEffect(() => {
    if (isBrowser) {
      setValue(getNestedProperty(window, variablePath));
    }
  }, [variablePath, isBrowser]);

  return value;
};

export default useWindowVariable;
