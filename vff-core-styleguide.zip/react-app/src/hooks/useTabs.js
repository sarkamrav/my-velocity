import { useState } from 'react';
import { first } from 'lodash';

export default function useTabs(tabs) {
  const [selectedTab, setSelectedTab] = useState(first(tabs));

  return [tabs, selectedTab, setSelectedTab];
}
