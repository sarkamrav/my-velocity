import { useState } from 'react';

const useExtensionDetection = () => {
  const [shopAndEarnExtensionId, upadteShopAndEarnExtensionId] = useState(null);
  const { body } = document;

  const elemToObserve = body;
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (mutation.target.hasAttribute('shop-and-earn-extension-id')) {
        upadteShopAndEarnExtensionId(body.getAttribute('shop-and-earn-extension-id'));
      }
    });
  });
  observer.observe(elemToObserve, { attributes: true });

  return {
    shopAndEarnExtensionId,
  };
};

export default useExtensionDetection;
