import { useEffect, useState } from 'react';
import _ from 'lodash';
import { useSelector } from 'react-redux';
import api from '../utils/api';
import * as userData from '../stores/utilities';
import { getApiActionName, getApiError, sendToNewRelic } from '../utils/newRelic';

export default function usePartnerActivatedOffers(partnerKey, makeApiCall = true) {
  const { user } = useSelector((state) => ({ user: state.user }));
  const [apiOffers, setApiOffers] = useState([]);
  const [loading, setLoading] = useState(false);

  const loyaltyMembershipID = userData.getLoyaltyMembershipID(user);

  useEffect(() => {
    // TODO: This logic is the same as AllOffersList, minus the filtering. We show activated offers related to the partners here.
    // Ideally we will collapse these lists together.
    async function loadActivatedOffers() {
      try {
        setLoading(true);

        const response = await api.vffV2Api.get('/loyalty/v2/promotions/registrations', {
          params: {
            excludeBAUOffers: true,
          },
        });
        const aemOffers = _.filter(response.data.data, (responseOffer) =>
          _.includes(['REGISTRABLE', 'REGISTERED'], responseOffer.registrationStatus),
        );
        const contentResponse = await api.aemApi.get(
          `/api/v1/activated-offers/_jcr_content.promoCode${
            _.size(aemOffers) > 0 ? `-${_(aemOffers).map('promotionCode').join('_')}` : ''
          }.webmodel.json`,
        );

        const contentOffers = _.get(contentResponse, 'data.activatedoffers', []);
        setApiOffers(
          _(response.data.data)
            .filter((responseOffer) =>
              _.some(contentOffers, {
                promoCode: responseOffer.promotionCode,
                partner: {
                  value: partnerKey,
                },
              }),
            )
            .map((responseOffer) => ({
              ...responseOffer,
              ..._.find(contentOffers, { promoCode: responseOffer.promotionCode }),
            }))
            .value(),
        );

        setLoading(false);
      } catch (error) {
        // Do nothing, as we will continue showing the BAU offers on the marketing page
        setLoading(false);

        sendToNewRelic(getApiActionName(), getApiError('use-partner-activated-offers', error));
      }
    }

    if (makeApiCall && loyaltyMembershipID) {
      // Load up activated if required
      loadActivatedOffers();
    }
  }, [loyaltyMembershipID, makeApiCall, partnerKey]);

  return {
    partnerApiOffers: apiOffers,
    partnerApiOffersLoading: loading,
  };
}
