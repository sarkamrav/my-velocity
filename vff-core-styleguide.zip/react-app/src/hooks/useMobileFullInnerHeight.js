import { useState, useEffect, useRef } from 'react';
import _ from 'lodash';

export default function useMobileFullInnerHeight(offsetHeightInPixel = 0, isMobileFullInnerHeightRequired = true) {
  const [containerInlineStyle, setContainerInlineStyle] = useState({});
  const innerWidthRef = useRef(window.innerWidth);

  useEffect(() => {
    function updateContainerHeight() {
      const height = window.matchMedia('(max-width: 767px)').matches
        ? { height: window.innerHeight - offsetHeightInPixel }
        : {};
      setContainerInlineStyle(height);
    }

    function updateContainerHeightOnResize() {
      if (innerWidthRef.current !== window.innerWidth) {
        updateContainerHeight();
        innerWidthRef.current = window.innerWidth;
      }
    }

    const debouncedUpdateContainerHeight = _.debounce(updateContainerHeightOnResize, 200, { trailing: true });

    if (isMobileFullInnerHeightRequired) {
      updateContainerHeight();
      window.addEventListener('resize', debouncedUpdateContainerHeight, false);
    }

    return () => {
      if (isMobileFullInnerHeightRequired) {
        document.removeEventListener('resize', debouncedUpdateContainerHeight, false);
      }
    };
  }, [isMobileFullInnerHeightRequired, offsetHeightInPixel]);

  return [containerInlineStyle];
}
