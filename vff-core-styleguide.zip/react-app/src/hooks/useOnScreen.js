import { useEffect, useState } from 'react';

function useOnScreen(ref, rootMargin = '0px') {
  const [isIntersecting, setIntersecting] = useState(false);

  useEffect(() => {
    const observerRefValue = ref?.current;
    const observer = new IntersectionObserver(
      ([entry]) => {
        setIntersecting(entry.isIntersecting);
      },
      {
        rootMargin,
      },
    );
    if (observerRefValue) {
      observer.observe(observerRefValue);
    }
    return () => {
      observer.unobserve(observerRefValue);
    };
  }, [ref, rootMargin]);
  return isIntersecting;
}

export default useOnScreen;
