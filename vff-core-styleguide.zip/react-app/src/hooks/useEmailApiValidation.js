/* eslint-disable react-hooks/exhaustive-deps */
import { useState, useCallback, useEffect, useRef } from 'react';
import axios from 'axios';
import { debounce } from 'lodash';
import { email as _emailValidator } from '@components/Form/validators';
import useWindowVariable, { keys } from './useWindowVariable';

const emailRegexValidator = _emailValidator();

const useEmailApiValidation = (
  values,
  message = 'Email address cannot be used, please use an alternative',
  didYouMeanMessage = 'Email address cannot be used, did you mean',
) => {
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const experianApiKey = useWindowVariable(keys.experian);
  const axiosSource = useRef(axios.CancelToken.source());

  const email = async (newValue) => {
    const emailHasWrongFormat = emailRegexValidator(newValue);
    if (emailHasWrongFormat) {
      setError('');
      return;
    }
    setLoading(true);
    try {
      // Cancel the previous request
      axiosSource.current.cancel('Cancelling the previous request.');

      // Create a new cancel token
      axiosSource.current = axios.CancelToken.source();

      const res = await axios.post(
        `https://api.experianaperture.io/email/validate/v2`,
        {
          email: newValue,
        },
        {
          headers: {
            'Auth-Token': experianApiKey,
          },
          cancelToken: axiosSource.current.token, // Pass the cancel token to the request
        },
      );
      const confidence = res?.data?.result?.confidence;
      const didYouMean = res?.data?.result?.did_you_mean;
      if (confidence === 'verified' || confidence === 'unknown') {
        setError('');
        return;
      }
      if (didYouMean) {
        setError(`${didYouMeanMessage} ${didYouMean}?`);
        return;
      }
      setError(message);
    } catch (e) {
      setError('');
    } finally {
      setLoading(false);
    }
  };

  const debouncedEmail = useCallback(
    debounce(email, 500),
    [], // Needs to be in a useCallback to prevent re-creation on every render
  );

  useEffect(() => {
    if (values.email) {
      debouncedEmail(values.email);
    } else {
      setError('');
    }

    return () => {
      // Cancel any ongoing request when the component unmounts
      axiosSource.current.cancel('Component unmounted.');
    };
  }, [values.email]);

  return {
    error,
    loading,
  };
};

export default useEmailApiValidation;
