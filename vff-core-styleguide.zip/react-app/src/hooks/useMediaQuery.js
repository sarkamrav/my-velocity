import { useState, useEffect, useCallback } from 'react';
import debounce from 'lodash/debounce';

const getMatches = (mediaQuery) => {
  if (typeof window !== 'undefined') {
    return window.matchMedia(mediaQuery).matches;
  }
  return false;
};

export default function useMediaQuery(query) {
  const [matches, setMatches] = useState(getMatches(query));

  const handleChange = useCallback(() => {
    setMatches(getMatches(query));
  }, [query]);

  useEffect(() => {
    handleChange();
    const debouncedHandleChange = debounce(handleChange, 500);

    window.addEventListener('resize', debouncedHandleChange);

    return () => {
      window.removeEventListener('resize', debouncedHandleChange);
    };
  }, [handleChange, query]);

  return matches;
}
