import React from 'react';
import cx from 'classnames';
import PropTypes from 'prop-types';
import _ from 'lodash';

import LinkGroup from './LinkGroup/LinkGroup';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME } from '../../utils/common';

import styles from './LinkGroups.css';

const LinkGroups = ({ title, tiles: linkGroups }) => (
  <ErrorBoundary section={COMPONENT_NAME.linkGroups}>
    <div className={styles.container}>
      {title ? (
        <h2 className="heading heading--2 color color--black" dangerouslySetInnerHTML={{ __html: title }} />
      ) : null}

      <div
        className={cx(styles.linkGroups, {
          [styles.oneGroup]: linkGroups.length === 1,
        })}
      >
        {_.map(linkGroups, (linkGroup) => (
          <LinkGroup key={linkGroup.jsObjectKey} {...linkGroup} />
        ))}
      </div>
    </div>
  </ErrorBoundary>
);

LinkGroups.propTypes = {
  title: PropTypes.string,
  tiles: PropTypes.arrayOf(PropTypes.shape({})),
};

LinkGroups.defaultProps = {
  title: '',
  tiles: [],
};

export default LinkGroups;
