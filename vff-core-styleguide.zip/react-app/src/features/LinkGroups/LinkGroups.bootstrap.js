import React from 'react';
import ReactDOM from 'react-dom';
import { map, size } from 'lodash';
import LinkGroups from './LinkGroups';
import { COMPONENT_NAME, getPropsDataFromJsObjectKeyArray } from '../../utils/common';

const ELEMENT_NAME = COMPONENT_NAME.linkGroups;

function renderComponent(elements, hydrate) {
  map(elements, (element) => {
    const componentData = window.vffCoreWebsite[element.getAttribute(ELEMENT_NAME)];
    const props = getPropsDataFromJsObjectKeyArray(componentData, window.vffCoreWebsite, 'tiles');

    if (props) {
      const component = <LinkGroups {...props} />;

      if (hydrate) {
        ReactDOM.hydrate(component, element);
      } else {
        ReactDOM.render(component, element);
      }
    }
  });
}

export default {
  elementName: ELEMENT_NAME,
  bootstrap: (id = null, hydrate = true) => {
    const elements = document.querySelectorAll(`[${ELEMENT_NAME}${id ? `=${id}` : ''}]`);

    if (size(elements) > 0) {
      renderComponent(elements, hydrate);
    }
  },
};
