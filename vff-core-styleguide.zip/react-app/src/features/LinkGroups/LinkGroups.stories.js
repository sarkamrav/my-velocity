import React from 'react';
import { getPropsDataFromJsObjectKeyArray } from '../../utils/common';
import LinkGroups from './LinkGroups';

/* eslint-disable camelcase */
import LinkGroupMockOneGroupOnly from './mocks/link-groups_MQnpVmz6--one-group-only.mock.json';
import LinkGroupsMock from './mocks/link-groups_MQnpVmz6.mock.json';
import link_group_QbUvs8w9 from './mocks/link-group_QbUvs8w9.mock.json';
import link_group_ycgRfFyD from './mocks/link-group_ycgRfFyD.mock.json';
import link_group_ZT8U7xtv from './mocks/link-group_ZT8U7xtv.mock.json';
/* eslint-enable camelcase */

export default {
  title: 'Link Groups',
};

export const Default = () => {
  const simulatedWindowObject = {
    uniqueImageTileKey: LinkGroupsMock,
    'link-group_ycgRfFyD': link_group_ycgRfFyD,
    'link-group_ZT8U7xtv': link_group_ZT8U7xtv,
    'link-group_QbUvs8w9': link_group_QbUvs8w9,
  };

  const props = getPropsDataFromJsObjectKeyArray(LinkGroupsMock, simulatedWindowObject, 'tiles');

  return <LinkGroups {...props} />;
};

export const OneGroupOnly = () => {
  const simulatedWindowObject = {
    uniqueImageTileKey: LinkGroupMockOneGroupOnly,
    'link-group_ycgRfFyD': link_group_ycgRfFyD,
  };

  const props = getPropsDataFromJsObjectKeyArray(LinkGroupMockOneGroupOnly, simulatedWindowObject, 'tiles');

  return <LinkGroups {...props} />;
};
