import React from 'react';
import { Provider } from 'react-redux';

import StatusMatchForm from './StatusMatchForm';
import { configureStore } from '../../stores';
import StatusMatchMock from './mocks/StatusMatchForm.mock.json';
import userData from '../Navigation/mocks/user.mock.json';

export default {
  title: 'Status Match Form',
};

export const AllTypes = () => (
  <Provider
    store={configureStore({
      user: {
        memberDataLoaded: true,
        memberDataLoading: false,
        authenticated: true,
        ...userData,
      },
    })}
  >
    <StatusMatchForm {...StatusMatchMock} />
  </Provider>
);
