import React, { useState, useCallback, useMemo } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import _ from 'lodash';
import { format, addMonths, addDays, isBefore, startOfDay, endOfDay } from 'date-fns';

import Button from '../../components/Button/Button';
import DatePicker from '../../components/Form/DatePicker/DatePicker';
import Input from '../../components/Form/Input/Input';
import { fieldId, normalizeFormField } from '../../components/Form/utils';
import * as normalize from '../../components/Form/normalizers';
import FormGroup from '../../components/Form/FormGroup/FormGroup';
import FormRow from '../../components/Form/FormRow/FormRow';
import Select from '../../components/Form/Select/Select';
import Loading from '../../components/Loading/Loading';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME } from '../../utils/common';
import * as userData from '../../stores/utilities';

import styles from './StatusMatchForm.css';

const StatusMatchForm = ({
  user,
  redirectUrl,
  formAction,
  membershipId,
  effectiveDate,
  firstName,
  lastName,
  email,
  vffMembershipId,
  priority,
  external,
  recordType,
  type,
  membershipStatus,
  orgId,
}) => {
  const fieldNames = {
    membershipId: membershipId.fieldId,
    membershipStatus: membershipStatus.fieldId,
    firstName: firstName.fieldId,
    lastName: lastName.fieldId,
    email: email.fieldId,
    vffMembershipId: vffMembershipId.fieldId,
    effectiveDate: effectiveDate.fieldId,
  };

  const initialValues = {
    [fieldNames.membershipId]: '',
    [fieldNames.membershipStatus]: null,
    [fieldNames.effectiveDate]: '',
  };

  const fieldNormalizers = useMemo(
    () => ({
      [fieldNames.membershipId]: [normalize.onlyNumbers],
    }),
    [fieldNames.membershipId],
  );

  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const hasLoggedIn = userData.getHasLoggedIn(user);
  const memberDataLoading = userData.getMemberDataLoading(user);

  function setFieldValue(fieldName, value) {
    setValues((prevState) => ({
      ...prevState,
      [fieldName]: value,
    }));
  }

  function setFieldError(fieldName, value) {
    setErrors((prevState) => ({
      ...prevState,
      [fieldName]: value,
    }));
  }

  function handleSubmit(e) {
    if (!values[fieldNames.membershipStatus] || !values[fieldNames.membershipId] || !values[fieldNames.effectiveDate]) {
      e.preventDefault();
      setErrors({
        [fieldNames.membershipStatus]: !values[fieldNames.membershipStatus] ? 'Please enter membership status' : '',
        [fieldNames.membershipId]: !values[fieldNames.membershipId] ? 'Please enter membership Id' : '',
        [fieldNames.effectiveDate]: !values[fieldNames.effectiveDate] ? 'Please choose effective date' : '',
      });
    }
  }

  const handleFieldChange = useCallback(
    (fieldName) => (newValue) => {
      const normalizedValue = normalizeFormField(newValue, fieldNormalizers[fieldName]);

      setFieldValue(fieldName, normalizedValue);
      setFieldError(fieldName, '');
    },
    [fieldNormalizers],
  );

  const handleFieldChangeEvent = useCallback(
    (event) => {
      handleFieldChange(event.target.name)(event.target.value);
    },
    [handleFieldChange],
  );

  const startDate = startOfDay(addDays(new Date(), effectiveDate.startDateBufferDays || 8));
  const endDate = endOfDay(effectiveDate.endTime ? new Date(effectiveDate.endTime) : addDays(new Date(), 30));

  return (
    <ErrorBoundary section={COMPONENT_NAME.statusMatchForm}>
      <div className={styles.container}>
        {memberDataLoading && <Loading className={styles.loadingImage} />}

        {hasLoggedIn && (
          <form onSubmit={handleSubmit} className={styles.form} action={formAction} method="POST">
            <input type="hidden" name="orgid" value={orgId} />
            <input type="hidden" name="retURL" value={redirectUrl} />

            <FormRow>
              <FormGroup>
                <Input
                  label={membershipId.fieldLabel}
                  id={fieldNames.membershipId}
                  name={fieldNames.membershipId}
                  maxLength="100"
                  size="20"
                  value={values[fieldNames.membershipId]}
                  onChange={handleFieldChangeEvent}
                  error={errors[fieldNames.membershipId]}
                />
              </FormGroup>

              <FormGroup>
                <Select
                  id={fieldId(fieldNames.membershipStatus)}
                  name={`${fieldNames.membershipStatus}-mirror`}
                  label={membershipStatus.fieldLabel}
                  items={[
                    {
                      bottomSeparator: false,
                      options: _.map(membershipStatus.fieldOptions, (option) => ({
                        label: option.text,
                        value: option.value,
                      })),
                    },
                  ]}
                  selectedItem={values[fieldNames.membershipStatus]}
                  error={errors[fieldNames.membershipStatus]}
                  onChange={handleFieldChange(fieldNames.membershipStatus)}
                  autoComplete="membership-status"
                  isSearchable={false}
                />
              </FormGroup>
            </FormRow>

            <FormRow>
              <FormGroup>
                <DatePicker
                  inputProps={{
                    label: effectiveDate.fieldLabel,
                    placeholder: 'Select date',
                    readOnly: true,
                  }}
                  dayPickerProps={{
                    disabledDays: isBefore(startDate, endDate)
                      ? {
                          before: startDate,
                          after: endDate,
                        }
                      : [
                          new Date(),
                          {
                            before: new Date(),
                            after: new Date(),
                          },
                        ],
                    toMonth: effectiveDate.endTime ? new Date(effectiveDate.endTime) : addMonths(new Date(), 1),
                    fromMonth: new Date(),
                  }}
                  value={values[fieldNames.effectiveDate]}
                  onDayChange={(day) => {
                    setFieldValue(fieldNames.effectiveDate, day);
                    setFieldError(fieldNames.effectiveDate, '');
                  }}
                  error={errors[fieldNames.effectiveDate]}
                />
              </FormGroup>

              {effectiveDate.fieldHelpText && (
                <RichTextContent className={styles.helpText} content={effectiveDate.fieldHelpText} />
              )}
            </FormRow>

            <input
              type="hidden"
              name={fieldNames.membershipStatus}
              value={_.get(values, `${fieldNames.membershipStatus}.value`, '')}
            />
            <input
              type="hidden"
              id={fieldNames.firstName}
              maxLength="250"
              name={fieldNames.firstName}
              size="20"
              value={userData.getFirstName(user)}
            />
            <input
              type="hidden"
              id={fieldNames.lastName}
              maxLength="250"
              name={fieldNames.lastName}
              size="20"
              value={userData.getLastName(user)}
            />
            <input
              type="hidden"
              id={fieldNames.email}
              maxLength="80"
              name={fieldNames.email}
              size="20"
              value={userData.getEmailAddress(user)}
            />
            <input
              type="hidden"
              id={fieldNames.vffMembershipId}
              maxLength="100"
              name={fieldNames.vffMembershipId}
              size="20"
              value={userData.getLoyaltyMembershipID(user)}
            />
            <input type="hidden" id={priority.fieldId} name={priority.fieldName} value={priority.fieldValue} />
            <input type="hidden" id={external.fieldId} name={external.fieldName} value={external.fieldValue} />
            <input type="hidden" id={recordType.fieldId} name={recordType.fieldName} value={recordType.fieldValue} />
            <input
              type="hidden"
              name={fieldNames.effectiveDate}
              value={format(values[fieldNames.effectiveDate], 'DD/MM/YYYY')}
              size="12"
            />
            <input
              type="hidden"
              id={type.fieldId}
              maxLength="80"
              name={type.fieldName}
              size="20"
              value={type.fieldValue}
            />

            <div className={styles.submitContainer}>
              <Button type="submit" buttonType="secondary">
                <span>Submit</span>
              </Button>
            </div>
          </form>
        )}
      </div>
    </ErrorBoundary>
  );
};

StatusMatchForm.propTypes = {
  user: PropTypes.shape({
    givenName: PropTypes.string,
    surname: PropTypes.string,
    loyaltyMembershipID: PropTypes.string,
  }),
  redirectUrl: PropTypes.string,
  formAction: PropTypes.string,
  orgId: PropTypes.string,
  membershipId: PropTypes.shape({
    fieldId: PropTypes.string,
    fieldLabel: PropTypes.string,
  }),
  effectiveDate: PropTypes.shape({
    fieldId: PropTypes.string,
    startDateBufferDays: PropTypes.number,
    endTime: PropTypes.number,
    fieldHelpText: PropTypes.string,
    fieldLabel: PropTypes.string,
  }),
  firstName: PropTypes.shape({
    fieldId: PropTypes.string,
  }),
  lastName: PropTypes.shape({
    fieldId: PropTypes.string,
  }),
  email: PropTypes.shape({
    fieldId: PropTypes.string,
  }),
  vffMembershipId: PropTypes.shape({
    fieldId: PropTypes.string,
  }),
  priority: PropTypes.shape({
    fieldId: PropTypes.string,
    fieldName: PropTypes.string,
    fieldValue: PropTypes.string,
  }),
  external: PropTypes.shape({
    fieldId: PropTypes.string,
    fieldName: PropTypes.string,
    fieldValue: PropTypes.string,
  }),
  recordType: PropTypes.shape({
    fieldId: PropTypes.string,
    fieldName: PropTypes.string,
    fieldValue: PropTypes.string,
  }),
  type: PropTypes.shape({
    fieldId: PropTypes.string,
    fieldName: PropTypes.string,
    fieldValue: PropTypes.string,
  }),
  membershipStatus: PropTypes.shape({
    fieldId: PropTypes.string,
    fieldLabel: PropTypes.string,
    fieldOptions: PropTypes.arrayOf(PropTypes.shape({})),
  }),
};

StatusMatchForm.defaultProps = {
  user: null,
  redirectUrl: '',
  formAction: '',
  orgId: '',
  membershipId: null,
  effectiveDate: null,
  firstName: null,
  lastName: null,
  email: null,
  vffMembershipId: null,
  priority: null,
  external: null,
  recordType: null,
  type: null,
  membershipStatus: null,
};

export default connect((state) => ({
  user: state.user,
}))(StatusMatchForm);
