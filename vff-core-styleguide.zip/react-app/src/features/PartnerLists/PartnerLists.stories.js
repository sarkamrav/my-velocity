import React from 'react';

import partnerListsMock from './mocks/PartnerLists.mock.json';
import PartnerLists from './PartnerLists';

export default {
  title: 'Partner Lists',
};

export const Default = () => <PartnerLists {...partnerListsMock} />;
