import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import cx from 'classnames';

import Icon from '../../components/Icon/Icon';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME } from '../../utils/common';
import HintLabel from '../../components/HintLabel/HintLabel';

import styles from './PartnerLists.css';

const PartnerLists = ({ title, tiles, analyticsMetadata }) => (
  <ErrorBoundary section={COMPONENT_NAME.partnerLists}>
    {_.size(tiles) > 0 ? (
      <div className={styles.container} {...analyticsMetadata}>
        {title ? (
          <h3 className="heading heading--3 color color--purple font-weight font-weight--extra-bold">{title}</h3>
        ) : null}

        <ul className={styles.list}>
          {_.map(tiles, (tile) => {
            const { logo, ctaContainer = {}, label = {}, excludeFromList } = tile;

            return (
              !excludeFromList && (
                <li className={styles.listItem} key={ctaContainer.ctaLabel}>
                  <HintLabel className={styles.topRight} label={label} />
                  {/* eslint-disable-next-line react/jsx-no-target-blank */}
                  <a
                    className={styles.link}
                    href={ctaContainer.ctaUrl}
                    title={ctaContainer.ctaTitle}
                    target={ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
                    rel={ctaContainer.ctaOpenInNewTab ? 'noopener noreferrer' : null}
                  >
                    <div className={styles.logoContainer}>
                      <img className={styles.partnerLogo} src={logo} alt={ctaContainer.ctaLabel} />
                    </div>

                    <span className={cx(styles.fakeLink, 'font-size font-size--large color font-weight')}>
                      {ctaContainer.ctaLabel}
                      <Icon className={styles.chevron} name="ChevronNew" size="smallest" />
                    </span>
                  </a>
                </li>
              )
            );
          })}
        </ul>
      </div>
    ) : null}
  </ErrorBoundary>
);

PartnerLists.propTypes = {
  title: PropTypes.string,
  tiles: PropTypes.arrayOf(PropTypes.shape({})),
  analyticsMetadata: PropTypes.shape({}),
};

PartnerLists.defaultProps = {
  title: null,
  tiles: [],
  analyticsMetadata: {},
};

export default PartnerLists;
