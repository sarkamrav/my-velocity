import React from 'react';
import PropTypes from 'prop-types';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import styles from './IconTile.css';

const IconTile = ({ tile }) => (
  <div className={styles.tile}>
    <div className={styles.iconContainer}>
      <img src={tile.iconUrl} alt={tile.title} className={styles.icon} />
    </div>
    <span className={styles.title}>{tile.title}</span>
    <RichTextContent content={tile.description} className={styles.description} />
  </div>
);

IconTile.propTypes = {
  tile: PropTypes.shape({
    iconUrl: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
  }).isRequired,
};

export default IconTile;
