import React from 'react';
import styles from '@sambego/storybook-styles';
import IconTiles from './IconTiles';
import IconTilesCarousel from './IconTilesCarousel';
import mocks from './mocks/IconTiles.mocks.json';

export default {
  title: 'Icon tiles',

  decorators: [
    styles({
      maxWidth: '1110px',
      margin: '0 auto',
    }),
  ],
};

export const Default = () => <IconTiles {...mocks} />;

export const Carousel = () => <IconTilesCarousel {...mocks} />;
