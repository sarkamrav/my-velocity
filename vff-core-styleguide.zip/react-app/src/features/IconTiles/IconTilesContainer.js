import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import Container from '../../components/Container/Container';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import styles from './IconTiles.css';

const IconTilesContainer = ({
  title,
  description,
  children,
  analyticsMetadata,
  bottomDescription,
  containerClassName,
}) => (
  <Container className={cx(styles.container, containerClassName)} {...analyticsMetadata}>
    {title ? <h3 className={cx(styles.title, 'heading heading--3 color color--purple')}>{title}</h3> : null}
    {description ? <RichTextContent content={description} className={styles.description} /> : null}
    {children}
    {bottomDescription ? <RichTextContent content={bottomDescription} className={styles.description} /> : null}
  </Container>
);

IconTilesContainer.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
  bottomDescription: PropTypes.string,
  children: PropTypes.node.isRequired,
  analyticsMetadata: PropTypes.shape({}),
  containerClassName: PropTypes.string,
};

IconTilesContainer.defaultProps = {
  title: null,
  description: null,
  bottomDescription: null,
  analyticsMetadata: {},
  containerClassName: '',
};

export default IconTilesContainer;
