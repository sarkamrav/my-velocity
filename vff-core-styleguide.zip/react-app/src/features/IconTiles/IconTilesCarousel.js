import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import Slider from 'react-slick';

import IconTile from './IconTile';
import IconTilesContainer from './IconTilesContainer';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME } from '../../utils/common';

import styles from './IconTiles.css';

const IconTilesCarousel = ({ tiles, responsive, containerClassName, ...rest }) => (
  <ErrorBoundary section={COMPONENT_NAME.iconTilesCarousel}>
    <IconTilesContainer containerClassName={containerClassName} {...rest}>
      <div className={styles.carouselContainer}>
        <Slider
          arrows={false}
          infinite={false}
          className={styles.carousel}
          dots
          slidesToShow={4}
          responsive={responsive}
        >
          {_.map(tiles, (tile) => (
            <IconTile key={tile.title} tile={tile} />
          ))}
        </Slider>
      </div>
    </IconTilesContainer>
  </ErrorBoundary>
);

IconTilesCarousel.propTypes = {
  tiles: PropTypes.arrayOf(
    PropTypes.shape({
      iconUrl: PropTypes.string.isRequired,
      title: PropTypes.string.isRequired,
      description: PropTypes.string.isRequired,
    }),
  ),
  responsive: PropTypes.arrayOf(PropTypes.shape()),
  containerClassName: PropTypes.string,
};

IconTilesCarousel.defaultProps = {
  tiles: [],
  responsive: [
    {
      breakpoint: 992,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
      },
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
      },
    },
  ],
  containerClassName: '',
};

export default IconTilesCarousel;
