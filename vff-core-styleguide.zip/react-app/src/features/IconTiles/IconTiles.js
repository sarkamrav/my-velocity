import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';

import IconTile from './IconTile';
import IconTilesContainer from './IconTilesContainer';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME } from '../../utils/common';

import styles from './IconTiles.css';

const IconTiles = ({ tiles, ...rest }) => (
  <ErrorBoundary section={COMPONENT_NAME.iconTiles}>
    <IconTilesContainer {...rest}>
      <div className={styles.tiles}>
        {_.map(tiles, (tile) => (
          <IconTile key={tile.title} tile={tile} />
        ))}
      </div>
    </IconTilesContainer>
  </ErrorBoundary>
);

IconTiles.propTypes = {
  tiles: PropTypes.arrayOf(
    PropTypes.shape({
      iconUrl: PropTypes.string.isRequired,
      title: PropTypes.string.isRequired,
      description: PropTypes.string.isRequired,
    }),
  ),
};

IconTiles.defaultProps = {
  tiles: [],
};

export default IconTiles;
