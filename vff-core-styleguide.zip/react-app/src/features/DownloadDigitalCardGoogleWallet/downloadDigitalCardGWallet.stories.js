import React from 'react';
import MockAdapter from 'axios-mock-adapter';
import { Provider } from 'react-redux';
import api from '../../utils/api';
import downloadDigitalCardGWalletData from './mocks/downloadDigitalCardGWallet.json';
import { configureStore } from '../../stores';
import DownloadDigitalCardGWallet from './downloadDigitalCardGWallet';
import userData from '../Navigation/mocks/user.mock.json';

export default {
  title: 'Download Digital card - Google Wallet',
};

export const DownloadDigitalCardGoogleWallet = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });
  mockVff.onGet('/loyalty/v2/digital-cards/google-pay').reply(200, {
    data: {
      token:
        'eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiIzMzAyOTI4NjgxMzctY29tcHV0ZUBkZXZlbG9wZXIuZ3NlcnZpY2VhY2NvdW50LmNvbSIsImF1ZCI6Imdvb2dsZSIsInR5cCI6InNhdmV0b2FuZHJvaWRwYXkiLCJpYXQiOjE2NjE3NTU3OTAsInBheWxvYWQiOnsibG95YWx0eU9iamVjdHMiOlt7ImFjY291bnRJZCI6IjAwMDAgNDU1IDk3MiIsImFjY291bnROYW1lIjoiTVIgQW5kcmV3IE1hc3RlclRlc3QiLCJiYXJjb2RlIjp7ImFsdGVybmF0ZVRleHQiOiIwMDAwNDU1OTcyIiwidHlwZSI6ImF6dGVjIiwidmFsdWUiOiJMMU1hc3RlclRlc3QvQW5kcmV3IE1SVkEgMDAwMDQ1NTk3MiAgICAgIFJFRCAgICAgICAgICAifSwiY2xhc3NJZCI6IjMyMDU1NjMxNTMzMDgzNDIwNjkuTG95YWx0eUNsYXNzIiwiaWQiOiIzMjA1NTYzMTUzMzA4MzQyMDY5LkRFVi4wMDAwNDU1OTcyIiwiaW5mb01vZHVsZURhdGEiOnsibGFiZWxWYWx1ZVJvd3MiOlt7ImNvbHVtbnMiOlt7ImxhYmVsIjoiUG9pbnRzIEJhbGFuY2UiLCJ2YWx1ZSI6IjEwLDAwMCJ9XX1dfSwibG95YWx0eVBvaW50cyI6eyJiYWxhbmNlIjp7InN0cmluZyI6IiJ9LCJsYWJlbCI6IiJ9LCJzdGF0ZSI6ImFjdGl2ZSIsInZlcnNpb24iOjF9XX0sIm9yaWdpbnMiOlsiaHR0cHM6Ly9leHBlcmllbmNlLnZlbG9jaXR5ZnJlcXVlbnRmbHllci5jb206NDQzIiwiaHR0cHM6Ly9kZXYxLWV4cGVyaWVuY2UudmVsb2NpdHlmcmVxdWVudGZseWVyLmNvbS8iLCJodHRwczovL3Rlc3QxLWV4cGVyaWVuY2UudmVsb2NpdHlmcmVxdWVudGZseWVyLmNvbS8iLCJodHRwczovL3N0YWdpbmcxLWV4cGVyaWVuY2UudmVsb2NpdHlmcmVxdWVudGZseWVyLmNvbS8iLCJodHRwOi8vbG9jYWxob3N0OjkwMDEiXX0.ewvmy4ZPcZtliXKvwkC-ldJtyax_PYIgNsrzPho8YRFuj42ehfD1GXvZ4uLv1VbKd9_aqkxLH13Z661LZSMpUaNBn5uQgMcwM202jsyMkYndDMJGc0MxZaODaNh5QbUfQnm1BXZLDdKABszmIvBC2Yzufe05EnqAd9iRsYLMf1_FmztVY0ZUCztFeRzgZ2T3PMvqEXcPtUkI2IeLR9ngd0dBp6Y55znEfDF2UXmFvsNnJoPsvfnx9LCD-3luxhB_9lSfLvD0S83YZ_Fv0AyL8cbmm56camDcVklpy9e_gc4GBlJf7Z24B4NbblO-pBqRnxqyHO4GT4qcDDazUz-_rg',
    },
  });
  mockVff.onPost('/loyalty/v2/digital-cards/google-pay').reply(200, {
    data: {
      sucess: true,
    },
  });
  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <DownloadDigitalCardGWallet {...downloadDigitalCardGWalletData} />
      </Provider>
    </div>
  );
};

export const DownloadDigitalCardGoogleWalletError = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });
  mockVff.onGet('/loyalty/v2/digital-cards/google-pay').reply(200, {
    data: {
      token:
        'bG9wZXIuZ3NlcnZpY2VhY2NvdW50LmNvbSIsImF1ZCI6Imdvb2dsZSIsInR5cCI6InNhdmV0b2FuZHJvaWRwYXkiLCJpYXQiOjE2NjE3NTU3OTAsInBheWxvYWQiOnsibG95YWx0eU9iamVjdHMiOlt7ImFjY291bnRJZCI6IjAwMDAgNDU1IDk3MiIsImFjY291bnROYW1lIjoiTVIgQW5kcmV3IE1hc3RlclRlc3QiLCJiYXJjb2RlIjp7ImFsdGVybmF0ZVRleHQiOiIwMDAwNDU1OTcyIiwidHlwZSI6ImF6dGVjIiwidmFsdWUiOiJMMU1hc3RlclRlc3QvQW5kcmV3IE1SVkEgMDAwMDQ1NTk3MiAgICAgIFJFRCAgICAgICAgICAifSwiY2xhc3NJZCI6IjMyMDU1NjMxNTMzMDgzNDIwNjkuTG95YWx0eUNsYXNzIiwiaWQiOiIzMjA1NTYzMTUzMzA4MzQyMDY5LkRFVi4wMDAwNDU1OTcyIiwiaW5mb01vZHVsZURhdGEiOnsibGFiZWxWYWx1ZVJvd3MiOlt7ImNvbHVtbnMiOlt7ImxhYmVsIjoiUG9pbnRzIEJhbGFuY2UiLCJ2YWx1ZSI6IjEwLDAwMCJ9XX1dfSwibG95YWx0eVBvaW50cyI6eyJiYWxhbmNlIjp7InN0cmluZyI6IiJ9LCJsYWJlbCI6IiJ9LCJzdGF0ZSI6ImFjdGl2ZSIsInZlcnNpb24iOjF9XX0sIm9yaWdpbnMiOlsiaHR0cHM6Ly9leHBlcmllbmNlLnZlbG9jaXR5ZnJlcXVlbnRmbHllci5jb206NDQzIiwiaHR0cHM6Ly9kZXYxLWV4cGVyaWVuY2UudmVsb2NpdHlmcmVxdWVudGZseWVyLmNvbS8iLCJodHRwczovL3Rlc3QxLWV4cGVyaWVuY2UudmVsb2NpdHlmcmVxdWVudGZseWVyLmNvbS8iLCJodHRwczovL3N0YWdpbmcxLWV4cGVyaWVuY2UudmVsb2NpdHlmcmVxdWVudGZseWVyLmNvbS8iLCJodHRwOi8vbG9jYWxob3N0OjkwMDEiXX0.ewvmy4ZPcZtliXKvwkC-ldJtyax_PYIgNsrzPho8YRFuj42ehfD1GXvZ4uLv1VbKd9_aqkxLH13Z661LZSMpUaNBn5uQgMcwM202jsyMkYndDMJGc0MxZaODaNh5QbUfQnm1BXZLDdKABszmIvBC2Yzufe05EnqAd9iRsYLMf1_FmztVY0ZUCztFeRzgZ2T3PMvqEXcPtUkI2IeLR9ngd0dBp6Y55znEfDF2UXmFvsNnJoPsvfnx9LCD-3luxhB_9lSfLvD0S83YZ_Fv0AyL8cbmm56camDcVklpy9e_gc4GBlJf7Z24B4NbblO-pBqRnxqyHO4GT4qcDDazUz-_rg',
    },
  });
  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <DownloadDigitalCardGWallet {...downloadDigitalCardGWalletData} />
      </Provider>
    </div>
  );
};
