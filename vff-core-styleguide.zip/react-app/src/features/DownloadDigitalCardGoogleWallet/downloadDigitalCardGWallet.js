import React, { useState, useCallback, useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import * as userData from '../../stores/utilities';
import Loading from '../../components/Loading/Loading';
import api from '../../utils/api';
import { loadJsFile } from '../../utils/common';
import MessageTile, { messageTileTheme } from '../../components/MessageTile/MessageTile';
import styles from './downloadDigitalCardGWallet.css';

const DownloadDigitalCardGWallet = ({ user, errorMessages }) => {
  const [loading, setLoading] = useState(false);
  const [jwtToken, setJwtToken] = useState(null);
  const [scriptedLoaded, setScriptedLoaded] = useState(null);
  const membershipId = userData.getLoyaltyMembershipID(user);
  const memberDataLoading = userData.getMemberDataLoading(user);
  const hasLoggedIn = userData.getHasLoggedIn(user);
  const memberDataLoadError = userData.getMemberDataLoadError(user);
  const memberDataLoaded = userData.getMemberDataLoaded(user);
  const [pageError, setPageError] = useState(false);

  const buttonRef = useRef();

  const getJwtToken = useCallback(async () => {
    try {
      setLoading(true);
      const response = await api.vffV2Api.get('/loyalty/v2/digital-cards/google-pay');
      setJwtToken(response.data.data.token);
      setLoading(false);
    } catch (error) {
      setLoading(false);
      setPageError(true);
    }
  }, []);

  useEffect(() => {
    if (memberDataLoaded && hasLoggedIn) {
      getJwtToken();
    }
  }, [hasLoggedIn, memberDataLoaded, getJwtToken]);

  const successHandler = useCallback(async () => {
    await api.vffV2Api.post('/loyalty/v2/digital-cards/google-pay', membershipId);
  }, [membershipId]);

  const failureHandler = () => {
    setPageError(true);
  };

  useEffect(() => {
    loadJsFile('https://apis.google.com/js/platform.js', () => setScriptedLoaded(true));
  }, []);

  useEffect(() => {
    if (jwtToken && scriptedLoaded) {
      /*eslint-disable */
      gapi.savetoandroidpay.render(buttonRef.current, {
        jwt: jwtToken,
        onsuccess: successHandler,
        onfailure: failureHandler,
        height: 'standard',
      });
    }
  }, [jwtToken, scriptedLoaded, successHandler]);

  return (
    <div className={styles.formContainer}>
      {!hasLoggedIn && memberDataLoadError && (
        <MessageTile theme="error" description="Sorry, we're having issues with our system." />
      )}

      {((!hasLoggedIn && !memberDataLoadError && memberDataLoading) || (hasLoggedIn && loading)) && <Loading />}

      {pageError && (
        <MessageTile theme={messageTileTheme.error} description={errorMessages?.defaultErrorMessage?.description} />
      )}
      <div ref={buttonRef} />
    </div>
  );
}

DownloadDigitalCardGWallet.propTypes = {
  user: PropTypes.shape({}),
  errorMessages: PropTypes.shape({
    defaultErrorMessage: PropTypes.shape({
      description: PropTypes.string.isRequired,
    }).isRequired,
  }).isRequired,
};

DownloadDigitalCardGWallet.defaultProps = {
  user: null,
};

export default connect((state) => ({
  user: state.user,
}))(DownloadDigitalCardGWallet);
