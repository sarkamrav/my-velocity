import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import cx from 'classnames';

import Icon from '../../components/Icon/Icon';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME } from '../../utils/common';

import styles from './QuickLinks.css';

const QuickLinks = ({ quickLinks, isSideBarMode, analyticsMetadata }) => {
  const analyticsMetadataKey = analyticsMetadata['analytics-metadata'];
  const [analyticsData, setAnalyticsData] = useState(analyticsMetadataKey);

  useEffect(() => {
    const commonAnalyticsData = window.vffCoreWebsite[analyticsMetadataKey] || {};

    setAnalyticsData({
      ...commonAnalyticsData,
      eventName: 'quick-links-interaction',
      eventLocation: 'quickLinks',
    });
  }, [analyticsMetadataKey]);

  return (
    <ErrorBoundary section={COMPONENT_NAME.quickLinks}>
      <ul
        className={cx(styles.container, {
          [styles.oneLink]: quickLinks.length === 1,
          [styles.twoLinks]: quickLinks.length === 2,
          [styles.threeLinks]: quickLinks.length === 3,
          [styles.sidebarMode]: isSideBarMode,
        })}
        analytics-metadata={typeof analyticsData === 'string' ? analyticsData : JSON.stringify({ ...analyticsData })}
      >
        {_.map(quickLinks, (quickLink) => (
          <li className={styles.linkItem} key={quickLink.label}>
            {/* eslint-disable-next-line react/jsx-no-target-blank */}
            <a
              href={quickLink.href}
              title={quickLink.title || quickLink.label}
              target={quickLink.openInNewTab ? '_blank' : '_self'}
              rel={quickLink.openInNewTab ? 'noopener noreferrer' : ''}
              className={styles.link}
            >
              <span className={styles.linkContent}>
                {quickLink.iconUrl ? (
                  <img src={quickLink.iconUrl} alt={quickLink.label} className={styles.linkIcon} />
                ) : null}
                <span className={styles.linkText}>{quickLink.label}</span>
                <Icon className={styles.linkChevron} size="smallest" name="ChevronNew" />
              </span>
            </a>
          </li>
        ))}
      </ul>
    </ErrorBoundary>
  );
};

QuickLinks.propTypes = {
  analyticsMetadata: PropTypes.shape({
    'analytics-metadata': PropTypes.string,
  }),
  quickLinks: PropTypes.arrayOf(PropTypes.shape({})),
  isSideBarMode: PropTypes.bool,
};

QuickLinks.defaultProps = {
  analyticsMetadata: {},
  quickLinks: [],
  isSideBarMode: false,
};

export default QuickLinks;
