import React from 'react';

import quickLinksMock from './QuickLinks.mock.json';
import QuickLinks from './QuickLinks';

export default {
  title: 'Quick Links',
};

export const Default = () => <QuickLinks {...quickLinksMock} />;

Default.storyName = 'default';

export const SideBarMode = () => <QuickLinks {...quickLinksMock} isSideBarMode />;

SideBarMode.storyName = 'side bar mode';
