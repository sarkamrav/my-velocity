import React, { useState, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import get from 'lodash/get';
import isEmpty from 'lodash/isEmpty';
import BenefitSelectorForm from './BenefitSelectorForm/BenefitSelectorForm';
import api from '../../utils/api';
import Loading from '../../components/Loading/Loading';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import BenefitSelectorErrorTile from './BenefitSelectorErrorTile/BenefitSelectorErrorTile';
import MessageTile, { messageTileTheme } from '../../components/MessageTile/MessageTile';
import analyticsSend from '../../utils/analytics';
import { analyticsEventAction, analyticsEventName } from '../../utils/common';
import styles from './BenefitSelector.css';

const BenefitSelector = ({
  user,
  title,
  offerExpired,
  offerUnavailable,
  description,
  optedInDescription,
  selectedOptionDescription,
  errorMessage,
  tiles,
  ctaContainer,
  terms,
  confirmation,
  review,
  analyticsMetadata,
}) => {
  const analyticsMetadataKey = analyticsMetadata['analytics-metadata'];

  const [apiBenefits, setApiBenefits] = useState(null);
  const [isGettingBenefits, setIsGettingBenefits] = useState(false);
  const [hasGetBenefitsLoaded, setHasGetBenefitsLoaded] = useState(false);
  const [hasGetBenefitsFailed, setHasGetBenefitsFailed] = useState(false);

  const [isOptingIn, setIsOptingIn] = useState(false);
  const [hasOpted, setHasOpted] = useState(false);
  const [hasOptedFailed, setHasOptedFailed] = useState(false);
  const [optInApiResponse, setOptInApiResponse] = useState(null);
  const [selectdoffer, setSelectedOffer] = useState(null);
  const [analyticsData, setAnalyticsData] = useState(analyticsMetadataKey);

  const membershipId = get(user, 'member.loyaltyMembershipID', '');
  const hasLoggedIn = get(user, 'authenticated', false);
  const memberDataLoading = get(user, 'memberDataLoading', true);
  const memberDataLoadError = get(user, 'memberDataLoadError', false);
  const firstName = get(user, 'member.firstName', '');

  const optionsForForm = tiles?.filter((el) => apiBenefits?.some((tile) => tile.promotionCode === el.selectedOption));

  // are any offers in the promotion API response?
  const areAnyOffersAvailableInApi = tiles?.length > 0 && optionsForForm?.length > 0;
  const apiBenefitsTiles = apiBenefits?.filter((el) =>
    tiles?.some((tile) => tile?.selectedOption === el?.promotionCode),
  );
  const registeredApiOffer = apiBenefitsTiles?.find((benefits) => benefits.registrationStatus === 'REGISTERED');

  // are all offers REGISTRABLE?
  const areAllOffersRegistrable = apiBenefitsTiles?.every((benefits) => benefits.registrationStatus === 'REGISTRABLE');
  const selectedBenefit = registeredApiOffer || optInApiResponse;

  const isOfferExpired = isEmpty(registeredApiOffer) && !areAllOffersRegistrable && hasGetBenefitsLoaded;

  // event actions and event name for Analytics
  const { click, impression } = analyticsEventAction;
  const { clickCta, formStart, formSuccess, formFailure } = analyticsEventName;

  const isOfferUnavaiable = !isGettingBenefits && hasGetBenefitsLoaded && !areAnyOffersAvailableInApi;

  const getPageState = useCallback(() => {
    if (areAnyOffersAvailableInApi) {
      if (isOfferExpired) return 'offer Expired';
      if (registeredApiOffer) return 'selected-form';
      if (areAllOffersRegistrable) return 'selectable-form';
      return '';
    }
    return 'Offer not available';
  }, [areAnyOffersAvailableInApi, isOfferExpired, registeredApiOffer, areAllOffersRegistrable]);

  useEffect(() => {
    if (isOfferExpired || registeredApiOffer || areAllOffersRegistrable) {
      analyticsSend({
        eventAction: impression,
        eventName: formStart,
        eventCategory: 'forms',
        eventElementName: `benefitSelector${analyticsData.campaignid}`,
        eventElementText: 'step-1',
        eventElementValue: getPageState(),
      });
    }
  }, [
    getPageState,
    isOfferExpired,
    analyticsData.campaignid,
    impression,
    formStart,
    registeredApiOffer,
    areAllOffersRegistrable,
  ]);

  const optInBenefit = useCallback(
    async (formValues) => {
      const selectedItem = apiBenefits?.find((benefit) => benefit?.promotionCode === formValues);
      setSelectedOffer(selectedItem);
      analyticsSend({
        eventAction: click,
        eventName: clickCta,
        eventCategory: 'forms',
        eventElementName: `benefitSelector${analyticsData.campaignid}`,
        eventElementText: review.ctaContainer.ctaLabel.replace(/\s{1,}/g, '-').toLowerCase(),
        eventElementValue: selectedItem.promotionCode,
      });
      try {
        setIsOptingIn(true);
        setHasOpted(false);
        setHasOptedFailed(false);
        const response = await api.vffV2Api.post('/loyalty/v2/promotions/registrations', {
          data: {
            promotionCode: selectedItem.promotionCode,
            promotionProvider: selectedItem.promotionProvider,
            memberId: membershipId,
          },
        });
        setOptInApiResponse(get(response, 'data.data', null));
        setIsOptingIn(false);
        setHasOpted(true);
      } catch (e) {
        const errorDetail = get(e, 'response.data.detail', '');
        setIsOptingIn(false);
        setHasOptedFailed(true);
        analyticsSend({
          eventAction: impression,
          eventName: formFailure,
          eventCategory: 'forms',
          eventElementName: `benefitSelector${analyticsData.campaignid}`,
          eventElementText: 'submit-failed',
          eventElementValue: errorDetail,
        });
      }
    },
    [
      membershipId,
      apiBenefits,
      analyticsData.campaignid,
      click,
      clickCta,
      formFailure,
      impression,
      review.ctaContainer.ctaLabel,
    ],
  );

  useEffect(() => {
    const commonAnalyticsData = window.vffCoreWebsite[analyticsMetadataKey] || {};
    setAnalyticsData({
      ...commonAnalyticsData,
    });
  }, [analyticsMetadataKey]);

  useEffect(() => {
    if (hasOpted) {
      analyticsSend({
        eventAction: impression,
        eventName: formSuccess,
        eventCategory: 'forms',
        eventElementName: `benefitSelector${analyticsData.campaignid}`,
        eventElementText: 'submit-confirmed',
        eventElementValue: selectdoffer?.promotionCode,
      });
    }
  }, [hasOpted, formSuccess, analyticsData.campaignid, impression, selectdoffer?.promotionCode]);

  useEffect(() => {
    async function getBenefits() {
      try {
        setIsGettingBenefits(true);
        setHasGetBenefitsFailed(false);
        const response = await api.vffV2Api.get('/loyalty/v2/promotions/registrations');
        setApiBenefits(get(response, 'data.data', null));
        setIsGettingBenefits(false);
        setHasGetBenefitsLoaded(true);
      } catch (e) {
        setIsGettingBenefits(false);
        setHasGetBenefitsFailed(true);
      }
    }

    if (hasLoggedIn) {
      getBenefits();
    }
  }, [hasLoggedIn, offerUnavailable]);

  return (
    <div className={styles.container}>
      {((!hasLoggedIn && memberDataLoading) || (hasLoggedIn && isGettingBenefits)) && (
        <Loading className={styles.loading} />
      )}

      {((!hasLoggedIn && memberDataLoadError) || (hasLoggedIn && hasGetBenefitsFailed)) && (
        <MessageTile theme={messageTileTheme.error} description="Sorry, we're having issues with our system." />
      )}

      {hasLoggedIn && isOfferUnavaiable && (
        <BenefitSelectorErrorTile
          iconPath={offerUnavailable?.iconUrl}
          title={offerUnavailable?.title}
          content={offerUnavailable?.description}
          ctaContainer={offerUnavailable?.ctaContainer}
        />
      )}

      {hasLoggedIn && !isGettingBenefits && hasGetBenefitsLoaded && areAnyOffersAvailableInApi && (
        <>
          {((isEmpty(registeredApiOffer) && areAllOffersRegistrable) || !isEmpty(registeredApiOffer)) && (
            <>
              {title && <h2 className={styles.mainTitle}>{title}</h2>}

              {description && <RichTextContent className={styles.description} content={description} />}

              {!isEmpty(selectedOptionDescription) && (
                <BenefitSelectorForm
                  selectedBenefit={selectedBenefit}
                  selectedOptionDescription={selectedOptionDescription}
                  options={optionsForForm}
                  optedInDescription={optedInDescription}
                  terms={terms}
                  memberFirstName={firstName}
                  ctaContainer={ctaContainer}
                  review={review}
                  onConfirm={optInBenefit}
                  isOptingIn={isOptingIn}
                  hasOpted={hasOpted}
                  hasOptedFailed={hasOptedFailed}
                  confirmation={confirmation}
                  analyticsMetadataFromParent={
                    typeof analyticsData === 'string'
                      ? {}
                      : {
                          ...analyticsData,
                        }
                  }
                  apiErrorMessage={errorMessage}
                />
              )}
            </>
          )}

          {isOfferExpired && (
            <BenefitSelectorErrorTile
              iconPath={offerExpired?.iconUrl}
              title={offerExpired?.title}
              content={offerExpired?.description}
              ctaContainer={offerExpired?.ctaContainer}
            />
          )}
        </>
      )}
    </div>
  );
};

BenefitSelector.propTypes = {
  user: PropTypes.shape({}),
  title: PropTypes.string,
  description: PropTypes.string,
  optedInDescription: PropTypes.string,
  selectedOptionDescription: PropTypes.string,
  errorMessage: PropTypes.string,
  tiles: PropTypes.arrayOf(PropTypes.shape({})),
  ctaContainer: PropTypes.shape({}),
  terms: PropTypes.shape({}),
  confirmation: PropTypes.shape({}),
  review: PropTypes.shape({
    description: PropTypes.string,
    ctaContainer: PropTypes.shape({
      ctaStyle: PropTypes.string,
      ctaLabel: PropTypes.string,
    }),
  }),
  offerExpired: PropTypes.shape({
    iconUrl: PropTypes.string,
    title: PropTypes.string,
    description: PropTypes.string,
    ctaContainer: PropTypes.shape({}),
  }),
  offerUnavailable: PropTypes.shape({
    iconUrl: PropTypes.string,
    title: PropTypes.string,
    description: PropTypes.string,
    ctaContainer: PropTypes.shape({}),
  }),
  analyticsMetadata: PropTypes.shape({
    'analytics-metadata': PropTypes.string,
  }),
  analyticsMetadataFromParent: PropTypes.shape({}),
};

BenefitSelector.defaultProps = {
  user: null,
  title: null,
  description: null,
  optedInDescription: null,
  selectedOptionDescription: null,
  errorMessage: null,
  tiles: null,
  ctaContainer: null,
  terms: null,
  confirmation: null,
  review: null,
  offerExpired: null,
  offerUnavailable: null,
  analyticsMetadata: {},
  analyticsMetadataFromParent: {},
};
export default connect((state) => ({
  user: state.user,
}))(BenefitSelector);
