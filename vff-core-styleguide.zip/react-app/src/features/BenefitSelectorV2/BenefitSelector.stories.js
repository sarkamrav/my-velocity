import React from 'react';
import MockAdapter from 'axios-mock-adapter';
import { Provider } from 'react-redux';
import BenefitSelector from './BenefitSelector';
import benefitSelectorMock from './mocks/benefitSelector.mock.json';
import api from '../../utils/api';
import { configureStore } from '../../stores';
import userData from '../Navigation/mocks/user.mock.json';

export default {
  title: 'Benefit Selector V2',
};

export const BenefitAvailableOptInSuccess = () => {
  const vffV2Api = new MockAdapter(api.vffV2Api, { delayResponse: 500 });

  vffV2Api.onGet('/loyalty/v2/promotions/registrations').reply(200, {
    data: [
      {
        promotionCode: 'FS-GOLD',
        promotionProvider: 'ADOBE',
        promotionStatus: 'RUNNING',
        promotionShortDescription: 'Double Points on VA Dec 2022',
        promotionLongDescription:
          'Earn Double Points on ALL VA Domestic, Trans-Tasman and ISH  prime flights. Applicable conditions;\n \nActivate between: 5 Dec 2022 – 15 Dec 2022\nBook between: 4 Dec 2022 – 15 Dec 2022\nTravel between: 5 Dec 2022 – 31 Oct 2023\n',
        promotionName: 'Double Points on VA Dec 2022',
        promotionStartDate: '2022-12-05',
        promotionEndDate: '2023-11-01',
        registrationStatus: 'REGISTRABLE',
        mustRegister: true,
        registrationStartDate: '2022-12-05',
        registrationEndDate: '2022-12-14',
        activityStartDate: '2022-12-05',
        registeredAt: '2022-12-04',
        activityEndDate: '2023-10-31',
        achievementCount: 0,
        totalPhaseNumber: 1,
        lastAchievedPhaseNumber: 0,
      },
      {
        promotionCode: '300TB',
        promotionProvider: 'LCP',
        promotionStatus: 'RUNNING',
        promotionShortDescription: 'Double Points on VA Dec 2022',
        promotionLongDescription:
          'Earn Double Points on ALL VA Domestic, Trans-Tasman and ISH  prime flights. Applicable conditions;\n \nActivate between: 5 Dec 2022 – 15 Dec 2022\nBook between: 4 Dec 2022 – 15 Dec 2022\nTravel between: 5 Dec 2022 – 31 Oct 2023\n',
        promotionName: 'Double Points on VA Dec 2022',
        promotionStartDate: '2022-12-05',
        promotionEndDate: '2023-11-01',
        registrationStatus: 'REGISTRABLE',
        mustRegister: true,
        registrationStartDate: '2022-12-05',
        registrationEndDate: '2022-12-14',
        activityEndDate: '2023-10-31',
        achievementCount: 0,
        totalPhaseNumber: 1,
        lastAchievedPhaseNumber: 0,
      },
      {
        promotionCode: 'VADBPT0076',
        promotionProvider: 'LCAP',
        promotionStatus: 'RUNNING',
        promotionShortDescription: 'Double Points on VA Dec 2022',
        promotionLongDescription:
          'Earn Double Points on ALL VA Domestic, Trans-Tasman and ISH  prime flights. Applicable conditions;\n \nActivate between: 5 Dec 2022 – 15 Dec 2022\nBook between: 4 Dec 2022 – 15 Dec 2022\nTravel between: 5 Dec 2022 – 31 Oct 2023\n',
        promotionName: 'Double Points on VA Dec 2022',
        promotionStartDate: '2022-12-05',
        promotionEndDate: '2023-11-01',
        registrationStatus: 'REGISTRABLE',
        mustRegister: true,
        registrationStartDate: '2022-12-05',
        registrationEndDate: '2022-12-14',
        activityStartDate: '2022-12-05',
        registeredAt: '2022-12-04',
        activityEndDate: '2023-10-31',
        achievementCount: 0,
        totalPhaseNumber: 1,
        lastAchievedPhaseNumber: 0,
      },
    ],
  });

  vffV2Api.onPost('/loyalty/v2/promotions/registrations').reply(200, {
    data: {
      channel: 'Client-Channel',
      type: 'REGISTRATION',
      id: 1,
      memberId: '0000476286',
      registrationDate: '2023-01-13T04:58:44.438Z',
      promotionCode: 'FS-GOLD',
      promotionProvider: 'LCP',
    },
  });

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <BenefitSelector {...benefitSelectorMock} />
      </Provider>
    </div>
  );
};

export const BenefitApiLoadError = () => {
  const vffV2Api = new MockAdapter(api.vffV2Api, { delayResponse: 500 });

  vffV2Api.onGet('/loyalty/v2/promotions/registrations').reply(400, {
    data: [],
  });

  vffV2Api.onPost('/loyalty/v2/promotions/registrations').reply(200, {
    data: {
      channel: 'Client-Channel',
      type: 'REGISTRATION',
      id: 1,
      memberId: '0000476286',
      registrationDate: '2023-01-13T04:58:44.438Z',
      promotionCode: 'FS-GOLD',
      promotionProvider: 'LCP',
    },
  });

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <BenefitSelector {...benefitSelectorMock} />
      </Provider>
    </div>
  );
};

export const BenefitOfferExpired = () => {
  const vffV2Api = new MockAdapter(api.vffV2Api, { delayResponse: 500 });

  vffV2Api.onGet('/loyalty/v2/promotions/registrations').reply(200, {
    data: [
      {
        promotionCode: 'FS-GOLD',
        promotionProvider: 'LCP',
        promotionStatus: 'RUNNING',
        promotionShortDescription: 'Double Points on VA Dec 2022',
        promotionLongDescription:
          'Earn Double Points on ALL VA Domestic, Trans-Tasman and ISH  prime flights. Applicable conditions;\n \nActivate between: 5 Dec 2022 – 15 Dec 2022\nBook between: 4 Dec 2022 – 15 Dec 2022\nTravel between: 5 Dec 2022 – 31 Oct 2023\n',
        promotionName: 'Double Points on VA Dec 2022',
        promotionStartDate: '2022-12-05',
        promotionEndDate: '2023-11-01',
        registrationStatus: 'NON_REGISTRABLE',
        mustRegister: true,
        registrationStartDate: '2022-12-05',
        registrationEndDate: '2022-12-14',
        activityStartDate: '2022-12-05',
        registeredAt: '2022-12-04',
        activityEndDate: '2023-10-31',
        achievementCount: 0,
        totalPhaseNumber: 1,
        lastAchievedPhaseNumber: 0,
      },
      {
        promotionCode: 'VADBPT0076',
        promotionProvider: 'LCP',
        promotionStatus: 'RUNNING',
        promotionShortDescription: 'Double Points on VA Dec 2022',
        promotionLongDescription:
          'Earn Double Points on ALL VA Domestic, Trans-Tasman and ISH  prime flights. Applicable conditions;\n \nActivate between: 5 Dec 2022 – 15 Dec 2022\nBook between: 4 Dec 2022 – 15 Dec 2022\nTravel between: 5 Dec 2022 – 31 Oct 2023\n',
        promotionName: 'Double Points on VA Dec 2022',
        promotionStartDate: '2022-12-05',
        promotionEndDate: '2023-11-01',
        registrationStatus: 'NON_REGISTRABLE',
        mustRegister: true,
        registrationStartDate: '2022-12-05',
        registrationEndDate: '2022-12-14',
        activityStartDate: '2022-12-05',
        registeredAt: '2022-12-04',
        activityEndDate: '2023-10-31',
        achievementCount: 0,
        totalPhaseNumber: 1,
        lastAchievedPhaseNumber: 0,
      },
      {
        promotionCode: '300TB',
        promotionProvider: 'LCP',
        promotionStatus: 'RUNNING',
        promotionShortDescription: 'Double Points on VA Dec 2022',
        promotionLongDescription:
          'Earn Double Points on ALL VA Domestic, Trans-Tasman and ISH  prime flights. Applicable conditions;\n \nActivate between: 5 Dec 2022 – 15 Dec 2022\nBook between: 4 Dec 2022 – 15 Dec 2022\nTravel between: 5 Dec 2022 – 31 Oct 2023\n',
        promotionName: 'Double Points on VA Dec 2022',
        promotionStartDate: '2022-12-05',
        promotionEndDate: '2023-11-01',
        registrationStatus: 'NON_REGISTRABLE',
        mustRegister: true,
        registrationStartDate: '2022-12-05',
        registrationEndDate: '2022-12-14',
        activityStartDate: '2022-12-05',
        registeredAt: '2022-12-04',
        activityEndDate: '2023-10-31',
        achievementCount: 0,
        totalPhaseNumber: 1,
        lastAchievedPhaseNumber: 0,
      },
    ],
  });

  vffV2Api.onPost('/loyalty/v2/promotions/registrations').reply(200, {
    data: {
      channel: 'Client-Channel',
      type: 'REGISTRATION',
      id: 1,
      memberId: '0000476286',
      registrationDate: '2021-03-31',
      promotionCode: 'NZBONUSPTS2',
      promotionProvider: 'LCP',
    },
  });

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <BenefitSelector {...benefitSelectorMock} />
      </Provider>
    </div>
  );
};

export const BenefitAvailableOptInFailure = () => {
  const vffV2Api = new MockAdapter(api.vffV2Api, { delayResponse: 500 });

  vffV2Api.onGet('/loyalty/v2/promotions/registrations').reply(200, {
    data: [
      {
        promotionCode: 'FS-GOLD',
        promotionProvider: 'ADOBE',
        promotionStatus: 'RUNNING',
        promotionShortDescription: 'Double Points on VA Dec 2022',
        promotionLongDescription:
          'Earn Double Points on ALL VA Domestic, Trans-Tasman and ISH  prime flights. Applicable conditions;\n \nActivate between: 5 Dec 2022 – 15 Dec 2022\nBook between: 4 Dec 2022 – 15 Dec 2022\nTravel between: 5 Dec 2022 – 31 Oct 2023\n',
        promotionName: 'Double Points on VA Dec 2022',
        promotionStartDate: '2022-12-05',
        promotionEndDate: '2023-11-01',
        registrationStatus: 'REGISTRABLE',
        mustRegister: true,
        registrationStartDate: '2022-12-05',
        registrationEndDate: '2022-12-14',
        activityStartDate: '2022-12-05',
        registeredAt: '2022-12-04',
        activityEndDate: '2023-10-31',
        achievementCount: 0,
        totalPhaseNumber: 1,
        lastAchievedPhaseNumber: 0,
      },
      {
        promotionCode: '300TB',
        promotionProvider: 'LCP',
        promotionStatus: 'RUNNING',
        promotionShortDescription: 'Double Points on VA Dec 2022',
        promotionLongDescription:
          'Earn Double Points on ALL VA Domestic, Trans-Tasman and ISH  prime flights. Applicable conditions;\n \nActivate between: 5 Dec 2022 – 15 Dec 2022\nBook between: 4 Dec 2022 – 15 Dec 2022\nTravel between: 5 Dec 2022 – 31 Oct 2023\n',
        promotionName: 'Double Points on VA Dec 2022',
        promotionStartDate: '2022-12-05',
        promotionEndDate: '2023-11-01',
        registrationStatus: 'REGISTRABLE',
        mustRegister: true,
        registrationStartDate: '2022-12-05',
        registrationEndDate: '2022-12-14',
        activityEndDate: '2023-10-31',
        achievementCount: 0,
        totalPhaseNumber: 1,
        lastAchievedPhaseNumber: 0,
      },
      {
        promotionCode: 'VADBPT0076',
        promotionProvider: 'LCAP',
        promotionStatus: 'RUNNING',
        promotionShortDescription: 'Double Points on VA Dec 2022',
        promotionLongDescription:
          'Earn Double Points on ALL VA Domestic, Trans-Tasman and ISH  prime flights. Applicable conditions;\n \nActivate between: 5 Dec 2022 – 15 Dec 2022\nBook between: 4 Dec 2022 – 15 Dec 2022\nTravel between: 5 Dec 2022 – 31 Oct 2023\n',
        promotionName: 'Double Points on VA Dec 2022',
        promotionStartDate: '2022-12-05',
        promotionEndDate: '2023-11-01',
        registrationStatus: 'REGISTRABLE',
        mustRegister: true,
        registrationStartDate: '2022-12-05',
        registrationEndDate: '2022-12-14',
        activityStartDate: '2022-12-05',
        registeredAt: '2022-12-04',
        activityEndDate: '2023-10-31',
        achievementCount: 0,
        totalPhaseNumber: 1,
        lastAchievedPhaseNumber: 0,
      },
    ],
  });

  vffV2Api.onPost('/loyalty/v2/promotions/registrations').reply(500, {
    status: 400,
    title: 'Server Error',
    code: 4001,
    detail: 'An error occured while handling the request.',
  });

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <BenefitSelector {...benefitSelectorMock} />
      </Provider>
    </div>
  );
};

export const BenefitOptedInState = () => {
  const vffV2Api = new MockAdapter(api.vffV2Api, { delayResponse: 500 });

  vffV2Api.onGet('/loyalty/v2/promotions/registrations').reply(200, {
    data: [
      {
        promotionCode: 'VADBPT0076',
        promotionProvider: 'LCP',
        promotionStatus: 'RUNNING',
        promotionShortDescription: 'Double Points on VA Dec 2022',
        promotionLongDescription:
          'Earn Double Points on ALL VA Domestic, Trans-Tasman and ISH  prime flights. Applicable conditions;\n \nActivate between: 5 Dec 2022 – 15 Dec 2022\nBook between: 4 Dec 2022 – 15 Dec 2022\nTravel between: 5 Dec 2022 – 31 Oct 2023\n',
        promotionName: 'Double Points on VA Dec 2022',
        promotionStartDate: '2022-12-05',
        promotionEndDate: '2023-11-01',
        registrationStatus: 'REGISTERED',
        mustRegister: true,
        registrationStartDate: '2022-12-05',
        registrationEndDate: '2022-12-14',
        activityStartDate: '2022-12-05',
        registeredAt: '2022-12-04',
        activityEndDate: '2023-10-31',
        achievementCount: 0,
        totalPhaseNumber: 1,
        lastAchievedPhaseNumber: 0,
      },
      {
        promotionCode: 'FS-GOLD',
        promotionProvider: 'LCP',
        promotionStatus: 'RUNNING',
        promotionShortDescription: 'Double Points on VA Dec 2022',
        promotionLongDescription:
          'Earn Double Points on ALL VA Domestic, Trans-Tasman and ISH  prime flights. Applicable conditions;\n \nActivate between: 5 Dec 2022 – 15 Dec 2022\nBook between: 4 Dec 2022 – 15 Dec 2022\nTravel between: 5 Dec 2022 – 31 Oct 2023\n',
        promotionName: 'Double Points on VA Dec 2022',
        promotionStartDate: '2022-12-05',
        promotionEndDate: '2023-11-01',
        registrationStatus: 'REGISTRABLE',
        mustRegister: true,
        registrationStartDate: '2022-12-05',
        registrationEndDate: '2022-12-14',
        activityStartDate: '2022-12-05',
        registeredAt: '2022-12-04',
        activityEndDate: '2023-10-31',
        achievementCount: 0,
        totalPhaseNumber: 1,
        lastAchievedPhaseNumber: 0,
      },
    ],
  });

  vffV2Api.onPost('/loyalty/v2/promotions/registrations').reply(200, {
    data: {
      channel: 'Client-Channel',
      type: 'REGISTRATION',
      id: 1,
      memberId: '0000476286',
      registrationDate: '2023-01-13T04:58:44.438Z',
      promotionCode: 'NZBONUSPTS2',
      promotionProvider: 'LCP',
    },
  });

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <BenefitSelector {...benefitSelectorMock} />
      </Provider>
    </div>
  );
};

export const BenefitUnavailable = () => {
  const vffV2Api = new MockAdapter(api.vffV2Api, { delayResponse: 500 });

  vffV2Api.onGet('/loyalty/v2/promotions/registrations').reply(200, {
    data: [],
  });

  vffV2Api.onPost('/loyalty/v2/promotions/registrations').reply(200, {
    data: {
      channel: 'Client-Channel',
      type: 'REGISTRATION',
      id: 1,
      memberId: '0000476286',
      registrationDate: '2021-03-31',
      promotionCode: 'NZBONUSPTS2',
      promotionProvider: 'LCP',
    },
  });

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <BenefitSelector {...benefitSelectorMock} />
      </Provider>
    </div>
  );
};
