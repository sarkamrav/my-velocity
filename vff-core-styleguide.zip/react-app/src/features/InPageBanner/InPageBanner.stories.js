import React from 'react';
import InPageBanner from './InPageBanner';
import inPageBannerMock from './InPageBanner.mock.json';

export default {
  title: 'In Page Banner',
};

export const ImageLeftAlign = () => <InPageBanner {...inPageBannerMock} />;

ImageLeftAlign.storyName = 'image left align';

export const ImageRightAlign = () => <InPageBanner {...inPageBannerMock} alignImageToRight />;

ImageRightAlign.storyName = 'image right align';
