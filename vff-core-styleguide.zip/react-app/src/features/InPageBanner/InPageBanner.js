import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import _ from 'lodash';

import A from '../../components/Button/A';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME } from '../../utils/common';

import styles from './InPageBanner.css';

const InPageBanner = ({
  title,
  description,
  ctaContainer,
  renditions,
  renditionImageKey,
  alignImageToRight,
  contentBackgroundColor,
  imageBackgroundColor,
  analyticsMetadata,
}) => {
  const analyticsMetadataKey = analyticsMetadata['analytics-metadata'];
  const [analyticsData, setAnalyticsData] = useState(analyticsMetadataKey);

  useEffect(() => {
    const commonAnalyticsData = window.vffCoreWebsite[analyticsMetadataKey] || {};

    setAnalyticsData({
      ...commonAnalyticsData,
      eventCategory: 'banner',
      eventLocation: 'inPageBanner',
    });
  }, [analyticsMetadataKey]);

  return (
    <ErrorBoundary section={COMPONENT_NAME.inPageBanner}>
      <div
        className={cx(styles.container, {
          [styles.imageRightAlign]: alignImageToRight,
        })}
      >
        {!_.isEmpty(renditions) ? (
          <div
            className={cx(styles.imageBackground, {
              [styles.darkPurple]: imageBackgroundColor === 'dark-purple',
            })}
            style={{ backgroundImage: `url(${_.get(renditions, 'imageDefault')})` }}
            rendition-image={renditionImageKey}
          />
        ) : null}

        <div
          className={cx(styles.content, {
            [styles.darkPurple]: contentBackgroundColor === 'dark-purple',
          })}
        >
          {title ? <h2 className={styles.title}>{title}</h2> : null}

          {description ? (
            <RichTextContent
              className={styles.description}
              content={description}
              analytics-metadata={
                typeof analyticsData === 'string' ? analyticsData : JSON.stringify({ ...analyticsData })
              }
            />
          ) : null}

          {!_.isEmpty(ctaContainer) ? (
            <A
              className={styles.callToAction}
              href={ctaContainer.ctaUrl}
              title={ctaContainer.ctaTitle}
              target={ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
              buttonType={ctaContainer.ctaStyle}
              ctaAsLink={ctaContainer.ctaAsLink}
              analytics-metadata={
                typeof analyticsData === 'string'
                  ? analyticsData
                  : JSON.stringify({
                      ...analyticsData,
                      eventName: 'cta-interaction',
                    })
              }
            >
              {ctaContainer.ctaLabel}
            </A>
          ) : null}
        </div>
      </div>
    </ErrorBoundary>
  );
};

InPageBanner.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
  ctaContainer: PropTypes.shape({
    ctaUrl: PropTypes.string,
    ctaTitle: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaStyle: PropTypes.string,
    ctaAsLink: PropTypes.bool,
    ctaLabel: PropTypes.string,
  }),
  renditions: PropTypes.shape({}),
  renditionImageKey: PropTypes.string,
  contentBackgroundColor: PropTypes.string,
  imageBackgroundColor: PropTypes.string,
  alignImageToRight: PropTypes.bool,
  analyticsMetadata: PropTypes.shape({
    'analytics-metadata': PropTypes.string,
  }),
};

InPageBanner.defaultProps = {
  title: '',
  description: '',
  ctaContainer: {},
  renditions: {},
  renditionImageKey: '',
  contentBackgroundColor: 'purple',
  imageBackgroundColor: 'purple',
  alignImageToRight: false,
  analyticsMetadata: {},
};

export default InPageBanner;
