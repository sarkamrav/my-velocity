import React from 'react';
import IconLinkTiles from './IconLinkTiles';
import IconLinkTilesMock from './mocks/IconLinkTilesMock.json';

export default {
  title: 'IconLink Tiles',
};

export const Default = () => <IconLinkTiles {...IconLinkTilesMock} />;
