import React from 'react';
import PropTypes from 'prop-types';
import styles from './IconLinkTiles.css';
import IconLinkTile from './Component/IconLinkTile/IconLinkTile';

const IconLinkTiles = ({ iconLinkTiles }) => (
  <div className={styles.container}>
    {iconLinkTiles &&
      iconLinkTiles.map((component) => (
        <IconLinkTile
          title={component.title}
          key={component.title}
          description={component.description}
          iconPath={component.iconPath}
          tooltip={component.tooltip}
          ctaContainer={component.ctaContainer}
        />
      ))}
  </div>
);

IconLinkTiles.propTypes = {
  iconLinkTiles: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
};

export default IconLinkTiles;
