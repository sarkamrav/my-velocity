import React from 'react';
import { Provider } from 'react-redux';
import store from '../../stores';
import FullPageBanner from './FullPageBanner';
import mock404 from './mocks/404.mock';
import mock500 from './mocks/500.mock';

export default {
  title: 'Full Page Banner',
};

export const _404Error = () => (
  <Provider store={store}>
    <div className="vffutils__container-width vffutils__container-width--full">
      <FullPageBanner {...mock404} />
    </div>
  </Provider>
);

export const _500Error = () => (
  <Provider store={store}>
    <div className="vffutils__container-width vffutils__container-width--full">
      <FullPageBanner {...mock500} />
    </div>
  </Provider>
);
