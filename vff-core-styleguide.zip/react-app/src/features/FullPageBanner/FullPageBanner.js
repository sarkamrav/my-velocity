import cx from 'classnames';
import PropTypes from 'prop-types';
import React from 'react';

import CtaButton from '../../components/Button/CtaButton';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import BackgroundImage from './components/BackgroundImage/BackgroundImage';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME } from '../../utils/common';

import styles from './FullPageBanner.css';

/**
 * A banner component meant to be displayed by itself on a page
 */
const FullPageBanner = ({ title, description, ctaContainer, renditions }) => (
  <ErrorBoundary section={COMPONENT_NAME.fullPageBanner}>
    <div className={styles.container}>
      <BackgroundImage renditions={renditions} />

      <div className={styles.content}>
        <h1 className={cx('heading heading--1', styles.heading)}>{title}</h1>

        <div className={styles.spacer} />

        <RichTextContent className={styles.description} content={description} />

        <CtaButton ctaContainer={ctaContainer} />
      </div>
    </div>
  </ErrorBoundary>
);

FullPageBanner.propTypes = {
  title: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
  ctaContainer: PropTypes.shape({
    ctaTitle: PropTypes.string.isRequired,
    ctaUrl: PropTypes.string.isRequired,
    ctaOpenInNewTab: PropTypes.bool.isRequired,
    ctaType: PropTypes.string.isRequired,
    ctaAsLink: PropTypes.bool.isRequired,
    ctaStyle: PropTypes.string.isRequired,
    ctaLabel: PropTypes.string.isRequired,
  }).isRequired,
  /**
   * The background image to display
   *
   * NOTE:
   * Component has been designed to leave space for a graphic in the background
   * image. This space is between the content on mobile and below all the content
   * on desktop. An example of a graphic could be the numbers "404" in the
   * background image of a 404 error page.
   */
  renditions: PropTypes.shape({}).isRequired,
};

export default FullPageBanner;
