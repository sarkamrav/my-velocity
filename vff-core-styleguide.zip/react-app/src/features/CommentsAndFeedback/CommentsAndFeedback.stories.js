import React from 'react';
import { Provider } from 'react-redux';
import MockAdapter from 'axios-mock-adapter';

import { configureStore } from '../../stores';
import CommentsAndFeedback from './CommentsAndFeedback';
import api from '../../utils/api';
import userData from './mocks/user.mock.json';
import mock from './mocks/CommentsAndFeedback.mock.json';
import userDataWithContactMock from './mocks/user--with-contact.mock.json';

export default {
  title: 'Comments and Feedback',
};

export const MemberProfileApiFailed = () => (
  <Provider
    store={configureStore({
      user: {
        memberDataLoaded: false,
        memberDataLoading: false,
        memberDataLoadError: true,
        authenticated: false,
      },
    })}
  >
    <CommentsAndFeedback {...mock} />
  </Provider>
);

export const MemberProfileApiLoading = () => (
  <Provider
    store={configureStore({
      user: {
        memberDataLoaded: false,
        memberDataLoading: true,
        authenticated: false,
      },
    })}
  >
    <CommentsAndFeedback {...mock} />
  </Provider>
);

export const Unauthenticated = () => (
  <Provider
    store={configureStore({
      user: {
        memberDataLoaded: true,
        memberDataLoading: false,
        authenticated: false,
      },
    })}
  >
    <CommentsAndFeedback {...mock} />
  </Provider>
);

export const Authenticated = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api);

  mockVffV2.onGet('/loyalty/v2/experience/members/me?include=contact').reply(200, userDataWithContactMock);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <CommentsAndFeedback {...mock} />
    </Provider>
  );
};

Authenticated.storyName = 'Authenticated - Non VIP';

export const AuthenticatedVip = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api);

  mockVffV2.onGet('/loyalty/v2/experience/members/me?include=contact').reply(200, userDataWithContactMock);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
          ...{
            tiers: {
              mainTierInfo: {
                tierLevel: 'V',
                tierType: 'S',
                category: 'ON_DEMAND',
                validityStartDate: '2021-10-16',
                label: 'STANDARD RED',
              },
            },
          },
        },
      })}
    >
      <CommentsAndFeedback {...mock} />
    </Provider>
  );
};

AuthenticatedVip.storyName = 'Authenticated - VIP';

export const FormSubmissionSuccess = () => {
  const mockVaCloudApi = new MockAdapter(api.vaCloudApi, { delayResponse: 1000 });
  const mockVffV2 = new MockAdapter(api.vffV2Api);

  mockVffV2.onGet('/loyalty/v2/experience/members/me?include=contact').reply(200, userDataWithContactMock);

  // success
  mockVaCloudApi.onPost('/forms/v1/comments-feedback-request').reply(200, {
    id: '5005D000007JdVkQAK',
    success: true,
    errors: [],
  });

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <CommentsAndFeedback {...mock} />
    </Provider>
  );
};

export const FormSubmissionError = () => {
  const mockVaCloudApi = new MockAdapter(api.vaCloudApi, { delayResponse: 1000 });
  const mockVffV2 = new MockAdapter(api.vffV2Api);

  mockVffV2.onGet('/loyalty/v2/experience/members/me?include=contact').reply(200, userDataWithContactMock);
  mockVaCloudApi.onPost('/forms/v1/comments-feedback-request').reply(500);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <CommentsAndFeedback {...mock} />
    </Provider>
  );
};
