import React, { useState, useCallback, useEffect, useRef } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import cx from 'classnames';
import get from 'lodash/get';
import find from 'lodash/find';
import filter from 'lodash/filter';
import isUndefined from 'lodash/isUndefined';
import toLower from 'lodash/toLower';
import every from 'lodash/every';
import omit from 'lodash/omit';
import includes from 'lodash/includes';
import isEmpty from 'lodash/isEmpty';
import useEmailApiValidation from '@hooks/useEmailApiValidation';
import api from '@utils/api';
import Input from '@components/Form/Input/Input';
import Select from '@components/Form/Select/Select';
import Button from '@components/Button/Button';
import MessageTile, { messageTileTheme } from '@components/MessageTile/MessageTile';
import { normalizeFormField, validateFormField } from '@components/Form/utils';
import * as validate from '@components/Form/validators';
import {
  COMPONENT_NAME,
  contactDeviceType,
  findPhoneByType,
  getLandlineDisplay,
  getMobileDisplay,
  scrollToRef,
} from '@utils/common';
import ErrorBoundary from '@components/ErrorBoundary/ErrorBoundary';
import TopContentContainer from '@components/Form/containers/TopContentContainer/TopContentContainer';
import RichTextContent from '@components/RichTextContent/RichTextContent';
import FormContainer, { formContainerColor } from '@components/Form/containers/FormContainer/FormContainer';
import FormContentContainer from '@components/Form/containers/FormContentContainer/FormContentContainer';
import FormFieldContainer from '@components/Form/containers/FormFieldContainer/FormFieldContainer';
import FormRow from '@components/Form/containers/FormRow/FormRow';
import Loading from '@components/Loading/Loading';
import Textarea from '@components/Form/Textarea/Textarea';

import {
  getEmailAddress,
  getFirstName,
  getHasLoggedIn,
  getLastName,
  getLoyaltyMembershipID,
  getMemberDataLoaded,
  getMemberDataLoadError,
  getMemberDataLoading,
  getMemberTitle,
  getPhones,
  getTierLevel,
} from '../../stores/utilities';
import { getApiActionName, getApiError, sendToNewRelic } from '../../utils/newRelic';
import * as normalize from '../../components/Form/normalizers';
import FileUploadInput from '../../components/Form/FileUploadInput/FileUploadInput';

import styles from './CommentsAndFeedback.css';

const formFieldNames = {
  title: 'title',
  firstName: 'firstName',
  lastName: 'lastName',
  email: 'email',
  phoneNumber: 'phoneNumber',
  velocityNumber: 'velocityNumber',
  velocityTier: 'velocityTier',
  feedbackType: 'feedbackType',
  category: 'category',
  referenceNumber: 'referenceNumber',
  subject: 'subject',
  message: 'message',
  attachments: 'attachments',
};

const fieldValidators = {
  [formFieldNames.title]: [validate.required('Title is required')],
  [formFieldNames.firstName]: [
    validate.required('First name is required'),
    validate.nameValidCharacterCheck('Invalid name'),
    validate.minCharacters('Invalid name', 1),
    validate.maxCharacters('Invalid name', 255),
  ],
  [formFieldNames.lastName]: [
    validate.required('Last name is required'),
    validate.nameValidCharacterCheck('Invalid name'),
    validate.minCharacters('Invalid name', 1),
    validate.maxCharacters('Invalid name', 255),
  ],
  [formFieldNames.email]: [
    validate.required('Email is required'),
    validate.email('The email address you have entered is incomplete or invalid'),
  ],
  [formFieldNames.phoneNumber]: [
    validate.optionalMaxCharacters('Max 15 characters only', 15),
    validate.optionalPhoneNumber('please enter a valid phone number'),
  ],
  [formFieldNames.velocityNumber]: [validate.optionalVelocityNumber('Please enter a valid membership No')],
  [formFieldNames.velocityTier]: [],
  [formFieldNames.feedbackType]: [validate.required('Please make a selection')],
  [formFieldNames.category]: [validate.required('Please make a selection')],
  [formFieldNames.referenceNumber]: [validate.optionalMaxCharacters('Max 64 characters only', 64)],
  [formFieldNames.subject]: [validate.optionalMaxCharacters('Max 255 characters only', 255)],
  [formFieldNames.message]: [
    validate.required('Message is required'),
    validate.maxCharacters('Max 1000 characters only', 1000),
  ],
};

const initialValues = {
  [formFieldNames.title]: null,
  [formFieldNames.firstName]: '',
  [formFieldNames.lastName]: '',
  [formFieldNames.email]: '',
  [formFieldNames.phoneNumber]: '',
  [formFieldNames.velocityNumber]: '',
  [formFieldNames.velocityTier]: null,
  [formFieldNames.feedbackType]: null,
  [formFieldNames.category]: null,
  [formFieldNames.subject]: '',
  [formFieldNames.message]: '',
  [formFieldNames.attachments]: [],
};

const mandatoryFields = [
  formFieldNames.title,
  formFieldNames.firstName,
  formFieldNames.lastName,
  formFieldNames.email,
  formFieldNames.feedbackType,
  formFieldNames.category,
  formFieldNames.message,
];

const optionalFields = [
  formFieldNames.phoneNumber,
  formFieldNames.velocityNumber,
  formFieldNames.velocityTier,
  formFieldNames.referenceNumber,
  formFieldNames.subject,
];

const fieldNormalizers = {
  [formFieldNames.velocityNumber]: [normalize.onlyNumbers, normalize.maxLength(10)],
};

const prepareFormData = (formValues) => {
  const data = new FormData();

  const phoneNumber = formValues[formFieldNames.phoneNumber];
  const velocityNumber = formValues[formFieldNames.velocityNumber];
  const velocityTier = formValues[formFieldNames.velocityTier]?.value;
  const referenceTransactionOrder = formValues[formFieldNames.referenceNumber];
  const subject = formValues[formFieldNames.subject];

  data.append('title', formValues[formFieldNames.title]?.value);
  data.append('firstName', formValues[formFieldNames.firstName]);
  data.append('lastName', formValues[formFieldNames.lastName]);
  data.append('email', formValues[formFieldNames.email]);
  data.append('enquiryType', formValues[formFieldNames.feedbackType]?.value);
  data.append('primaryCategory', formValues[formFieldNames.category]?.value);
  data.append('feedbackDescription', formValues[formFieldNames.message]);

  if (phoneNumber) {
    data.append('phoneNumber', phoneNumber);
  }

  if (velocityNumber) {
    data.append('velocityNumber', velocityNumber);
  }

  if (velocityTier) {
    data.append('velocityTier', velocityTier);
  }

  if (referenceTransactionOrder) {
    data.append('referenceTransactionOrder', referenceTransactionOrder);
  }

  if (subject) {
    data.append('subject', subject);
  }

  if (!isEmpty(formValues[formFieldNames.attachments])) {
    formValues[formFieldNames.attachments].forEach((file) => {
      data.append('files', file);
    });
  }

  return data;
};

const CommentsAndFeedback = (props) => {
  const {
    description,
    successMessage,
    titleOptions,
    ctaContainer,
    velocityTierOptions,
    categoryOptions,
    feedbackTypeOptions,
    tooltipText,
    user,
    defaultErrorMessage,
    privacyInformation,
    attachmentDetails,
  } = props;

  const [values, setValues] = useState(initialValues);
  const [touchedFields, setTouchedFields] = useState([]);
  const [errors, setErrors] = useState({});

  const [apiLoading, setApiLoading] = useState(false);
  const [apiError, setApiError] = useState(false);
  const [apiResponse, setApiResponse] = useState(null);

  const [phoneLoading, setPhoneLoading] = useState(false);

  const memberDataLoading = getMemberDataLoading(user);
  const memberDataLoadError = getMemberDataLoadError(user);
  const hasLoggedIn = getHasLoggedIn(user);
  const memberDataLoaded = getMemberDataLoaded(user);

  const successMessageRef = useRef({});
  const errorMessageRef = useRef({});

  const tierLevel = getTierLevel(user);
  const { error: emailApiError, loading: emailApiLoading } = useEmailApiValidation(values);

  const velocityTierByUserType = filter(
    velocityTierOptions,
    (tier) => !tier.tierVisible || tier.tierVisible === tierLevel,
  );

  const setFieldValue = useCallback((fieldName, fieldValue) => {
    setValues((prevState) => ({
      ...prevState,
      [fieldName]: fieldValue,
    }));
  }, []);

  const setFieldError = useCallback((fieldName, errorMessage) => {
    setErrors((prevState) => ({
      ...prevState,
      [fieldName]: errorMessage,
    }));
  }, []);

  // Validates field and returns an error message if it is invalid
  const validateField = useCallback(
    (fieldName, fieldValue) => validateFormField(fieldValue, fieldValidators[fieldName], values),
    [values],
  );

  // Runs and applies field validation
  const runFieldValidation = useCallback(
    (fieldName, fieldValue) => {
      const error = validateField(fieldName, fieldValue);

      if (error) {
        setErrors((currentErrors) => ({
          ...currentErrors,
          [fieldName]: error,
        }));
      } else {
        setErrors((currentErrors) => omit(currentErrors, [fieldName]));
      }
    },
    [validateField],
  );

  const handleFieldChange = useCallback(
    (fieldName) => (newValue) => {
      // Set value
      const normalizedValue = normalizeFormField(newValue, fieldNormalizers[fieldName]);

      setFieldValue(fieldName, normalizedValue);

      // Give immediate error feedback for fields that are already touched
      const isTouched = includes(touchedFields, fieldName);

      const numberOfMandatoryFieldWithoutValue =
        mandatoryFields.length -
        mandatoryFields.reduce((result, mandatoryFieldName) => (values[mandatoryFieldName] ? result + 1 : result), 0);

      if (isTouched || numberOfMandatoryFieldWithoutValue <= 1) {
        runFieldValidation(fieldName, normalizedValue);
      }
    },
    [runFieldValidation, setFieldValue, touchedFields, values],
  );

  const handleFieldChangeEvent = useCallback(
    (event) => handleFieldChange(event.target.name)(event.target.value),
    [handleFieldChange],
  );

  const handleFieldBlur = useCallback(
    (fieldName) => (newValue) => {
      const fieldValue = isUndefined(newValue) ? values[fieldName] : newValue;
      // Add to list of touched fields if required
      if (!includes(touchedFields, fieldName)) {
        setTouchedFields((currentTouchedFields) => [...currentTouchedFields, fieldName]);
      }

      // Set any errors
      runFieldValidation(fieldName, fieldValue);
    },
    [runFieldValidation, touchedFields, values],
  );

  const handleFieldBlurEvent = useCallback(
    (event) => {
      handleFieldBlur(event.target.name)();
    },
    [handleFieldBlur],
  );

  const handleSubmit = useCallback(
    async (e) => {
      e.preventDefault();

      const apiUrl = '/forms/v1/comments-feedback-request';
      const payload = prepareFormData(values);

      try {
        setApiLoading(true);
        setApiError(false);
        setApiResponse(null);

        const response = await api.vaCloudApi.post(apiUrl, payload, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        });

        setApiLoading(false);
        setApiResponse(response.data);
      } catch (error) {
        setApiLoading(false);
        setApiError(true);
      }
    },
    [values],
  );

  const showReferenceNumber = get(values, `${formFieldNames.category}.hasReference`, false);

  const canSubmit =
    every(mandatoryFields, (mandatoryFieldName) => values[mandatoryFieldName] && !errors[mandatoryFieldName]) &&
    isEmpty(errors[formFieldNames.attachments]) &&
    every(
      optionalFields,
      (optionalFieldName) => !values[optionalFieldName] || (values[optionalFieldName] && !errors[optionalFieldName]),
    ) &&
    !emailApiError &&
    !emailApiLoading;

  useEffect(() => {
    if (apiResponse && successMessageRef.current) {
      setValues(initialValues);
      scrollToRef(successMessageRef);
    }
  }, [apiResponse]);

  useEffect(() => {
    if (apiError && errorMessageRef.current) {
      scrollToRef(errorMessageRef);
    }
  }, [apiError]);

  useEffect(() => {
    if (memberDataLoaded && hasLoggedIn) {
      const memberTitle = getMemberTitle(user);
      const selectedTierOption = find(velocityTierOptions, { memberProfileValue: tierLevel });
      const selectedTitle = find(titleOptions, (option) => toLower(option.memberProfileValue) === toLower(memberTitle));

      setValues({
        ...initialValues,
        [formFieldNames.firstName]: getFirstName(user) || '',
        [formFieldNames.lastName]: getLastName(user) || '',
        [formFieldNames.email]: getEmailAddress(user) || '',
        [formFieldNames.velocityNumber]: getLoyaltyMembershipID(user) || '',
        [formFieldNames.velocityTier]: selectedTierOption || null,
        [formFieldNames.title]: selectedTitle || null,
      });
    }
  }, [hasLoggedIn, memberDataLoaded, tierLevel, titleOptions, user, velocityTierOptions]);

  useEffect(() => {
    const getPhoneNumber = async () => {
      const experienceMemberApiUri = '/loyalty/v2/experience/members/me?include=contact';

      try {
        setPhoneLoading(true);
        const response = await api.vffV2Api.get(experienceMemberApiUri);
        const phones = getPhones(response);

        const mobile = findPhoneByType(phones, contactDeviceType.mobile);
        const landline = findPhoneByType(phones, contactDeviceType.landline);

        const phoneDisplay = (mobile && getMobileDisplay(mobile)) || (landline && getLandlineDisplay(landline)) || '';

        setValues((prevState) => ({
          ...prevState,
          [formFieldNames.phoneNumber]: phoneDisplay,
        }));

        setPhoneLoading(false);
      } catch (error) {
        setPhoneLoading(false);

        sendToNewRelic(
          getApiActionName(api.vffV2Api.defaults.baseURL, experienceMemberApiUri),
          getApiError(COMPONENT_NAME.commentsAndFeedback, error),
        );
      }
    };

    if (hasLoggedIn) {
      getPhoneNumber();
    }
  }, [hasLoggedIn]);

  return (
    <ErrorBoundary section={COMPONENT_NAME.commentsAndFeedback}>
      <div className={styles.container}>
        {((!hasLoggedIn && !memberDataLoadError && memberDataLoading) || (hasLoggedIn && phoneLoading)) && (
          <Loading containerClassName={styles.loading} />
        )}

        {!hasLoggedIn && memberDataLoadError && (
          <div className={styles.contentWrapper}>
            <MessageTile theme={messageTileTheme.error} description="Sorry, we're having issues with our system." />
          </div>
        )}

        {memberDataLoaded && !phoneLoading && (
          <>
            <TopContentContainer>
              {apiError && (
                <MessageTile
                  ref={errorMessageRef}
                  className={styles.message}
                  theme={messageTileTheme.error}
                  description={defaultErrorMessage}
                />
              )}

              {apiResponse && (
                <MessageTile
                  ref={successMessageRef}
                  className={styles.message}
                  theme={messageTileTheme.success}
                  description={successMessage}
                />
              )}

              {description && <RichTextContent className={styles.description} content={description} />}
            </TopContentContainer>

            <FormContainer className={styles.formWrapper} theme={formContainerColor.grey}>
              <form onSubmit={handleSubmit}>
                <FormContentContainer>
                  <h2 className={cx('vaHeading vaHeading--5 color color--purple', styles.contactTitle)}>
                    Contact Details
                  </h2>
                </FormContentContainer>

                <FormRow>
                  <FormFieldContainer className={styles.titleFieldContainer}>
                    <Select
                      label="title"
                      name={formFieldNames.title}
                      items={titleOptions}
                      onChange={handleFieldChange(formFieldNames.title)}
                      onBlur={handleFieldBlur(formFieldNames.title)}
                      selectedItem={values[formFieldNames.title]}
                      error={errors[formFieldNames.title]}
                      autoComplete="honorific-prefix"
                      isSearchable={false}
                      placeholder="Select"
                    />
                  </FormFieldContainer>

                  <FormFieldContainer className={styles.firstNameContainer}>
                    <Input
                      label="First name"
                      name={formFieldNames.firstName}
                      onChange={handleFieldChangeEvent}
                      onBlur={handleFieldBlurEvent}
                      value={values[formFieldNames.firstName]}
                      error={errors[formFieldNames.firstName]}
                      autoComplete="given-name"
                    />
                  </FormFieldContainer>

                  <FormFieldContainer className={styles.lastNameContainer}>
                    <Input
                      label="last name"
                      name={formFieldNames.lastName}
                      onChange={handleFieldChangeEvent}
                      onBlur={handleFieldBlurEvent}
                      value={values[formFieldNames.lastName]}
                      error={errors[formFieldNames.lastName]}
                      autoComplete="family-name"
                    />
                  </FormFieldContainer>
                </FormRow>

                <FormRow>
                  <FormFieldContainer className={styles.emailFieldContainer}>
                    <Input
                      label="email"
                      name={formFieldNames.email}
                      onChange={handleFieldChangeEvent}
                      onBlur={handleFieldBlurEvent}
                      value={values[formFieldNames.email]}
                      error={errors[formFieldNames.email] || emailApiError}
                      isLoading={emailApiLoading}
                      autoComplete="home email"
                    />
                  </FormFieldContainer>

                  <FormFieldContainer className={styles.phoneFieldContainer}>
                    <Input
                      label="phone Number (Optional)"
                      name={formFieldNames.phoneNumber}
                      onChange={handleFieldChangeEvent}
                      onBlur={handleFieldBlurEvent}
                      value={values[formFieldNames.phoneNumber]}
                      error={errors[formFieldNames.phoneNumber]}
                      autoComplete="home tel"
                    />
                  </FormFieldContainer>
                </FormRow>

                <FormContentContainer>
                  <h2 className={cx('vaHeading vaHeading--5 color color--purple', styles.myVelocityTitle)}>
                    My Velocity
                  </h2>
                </FormContentContainer>

                <FormRow>
                  <FormFieldContainer>
                    <Input
                      label="velocity number (Optional)"
                      name={formFieldNames.velocityNumber}
                      onChange={handleFieldChangeEvent}
                      onBlur={handleFieldBlurEvent}
                      value={values[formFieldNames.velocityNumber]}
                      error={errors[formFieldNames.velocityNumber]}
                      autoComplete="nope"
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                    />
                  </FormFieldContainer>

                  <FormFieldContainer>
                    <Select
                      label="velocity tier (Optional)"
                      name={formFieldNames.velocityTier}
                      items={velocityTierByUserType}
                      onChange={handleFieldChange(formFieldNames.velocityTier)}
                      onBlur={handleFieldBlur(formFieldNames.velocityTier)}
                      selectedItem={values[formFieldNames.velocityTier]}
                      error={errors[formFieldNames.velocityTier]}
                      autoComplete="off"
                      isSearchable={false}
                      isClearable
                    />
                  </FormFieldContainer>
                </FormRow>

                <FormContentContainer>
                  <h2 className={cx('vaHeading vaHeading--5 color color--purple', styles.feedbackTitle)}>
                    Feedback Details
                  </h2>
                </FormContentContainer>

                <FormRow>
                  <FormFieldContainer>
                    <Select
                      label="feedback type"
                      name={formFieldNames.feedbackType}
                      items={feedbackTypeOptions}
                      onChange={handleFieldChange(formFieldNames.feedbackType)}
                      onBlur={handleFieldBlur(formFieldNames.feedbackType)}
                      selectedItem={values[formFieldNames.feedbackType]}
                      error={errors[formFieldNames.feedbackType]}
                      autoComplete="off"
                      isSearchable={false}
                    />
                  </FormFieldContainer>

                  <FormFieldContainer>
                    <Select
                      label="category"
                      name={formFieldNames.category}
                      items={categoryOptions}
                      onChange={handleFieldChange(formFieldNames.category)}
                      onBlur={handleFieldBlur(formFieldNames.category)}
                      selectedItem={values[formFieldNames.category]}
                      error={errors[formFieldNames.category]}
                      autoComplete="off"
                      isSearchable={false}
                    />
                  </FormFieldContainer>
                </FormRow>

                {showReferenceNumber && (
                  <FormRow>
                    <FormFieldContainer className={styles.referenceFieldContainer}>
                      <Input
                        label="reference no. (Optional)"
                        name={formFieldNames.referenceNumber}
                        onChange={handleFieldChangeEvent}
                        onBlur={handleFieldBlurEvent}
                        tooltip={{ text: tooltipText }}
                        value={values[formFieldNames.referenceNumber]}
                        error={errors[formFieldNames.referenceNumber]}
                        autoComplete="given-name"
                      />
                    </FormFieldContainer>
                  </FormRow>
                )}

                <FormRow>
                  <FormFieldContainer>
                    <Input
                      label="subject (Optional)"
                      name={formFieldNames.subject}
                      onChange={handleFieldChangeEvent}
                      onBlur={handleFieldBlurEvent}
                      value={values[formFieldNames.subject]}
                      error={errors[formFieldNames.subject]}
                      autoComplete="off"
                    />
                  </FormFieldContainer>
                </FormRow>

                <FormRow>
                  <FormFieldContainer>
                    <Textarea
                      label="message"
                      name={formFieldNames.message}
                      optionalLabelText="(1000 character limit)"
                      textAreaClassName={styles.textAreaField}
                      onChange={handleFieldChangeEvent}
                      onBlur={handleFieldBlurEvent}
                      value={values[formFieldNames.message]}
                      error={errors[formFieldNames.message]}
                    />
                  </FormFieldContainer>
                </FormRow>

                <FormRow>
                  <FormFieldContainer noPaddingTop>
                    <FileUploadInput
                      attachmentDetails={attachmentDetails}
                      name={formFieldNames.attachments}
                      setFieldValue={setFieldValue}
                      setFieldError={setFieldError}
                      errors={errors[formFieldNames.attachments]}
                      value={values[formFieldNames.attachments]}
                    />
                  </FormFieldContainer>
                </FormRow>

                <div className={styles.btnContainer}>
                  <Button
                    type="submit"
                    className={styles.continueButton}
                    buttonType={ctaContainer.ctaStyle}
                    title={ctaContainer.ctaTitle}
                    disabled={!canSubmit || apiLoading}
                    loading={apiLoading}
                    onClick={handleSubmit}
                  >
                    {ctaContainer.ctaLabel}
                  </Button>
                </div>

                <FormContentContainer className={styles.privacyInformationContainer}>
                  {privacyInformation && (
                    <RichTextContent className={styles.privacyInformation} content={privacyInformation} />
                  )}
                </FormContentContainer>
              </form>
            </FormContainer>
          </>
        )}
      </div>
    </ErrorBoundary>
  );
};

CommentsAndFeedback.propTypes = {
  user: PropTypes.shape({
    phoneNumbers: PropTypes.arrayOf(PropTypes.shape({})),
    emailAddresses: PropTypes.arrayOf(PropTypes.shape({})),
    title: PropTypes.string,
    givenName: PropTypes.string,
    surname: PropTypes.string,
    loyaltyMembershipID: PropTypes.string,
  }),
  description: PropTypes.string,
  successMessage: PropTypes.string.isRequired,
  titleOptions: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.string.isRequired,
      value: PropTypes.string.isRequired,
    }),
  ).isRequired,
  ctaContainer: PropTypes.shape({
    ctaStyle: PropTypes.string.isRequired,
    ctaAsLink: PropTypes.bool.isRequired,
    ctaLabel: PropTypes.string.isRequired,
    ctaTitle: PropTypes.string.isRequired,
  }).isRequired,
  velocityTierOptions: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.string.isRequired,
      value: PropTypes.string.isRequired,
    }),
  ).isRequired,
  feedbackTypeOptions: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.string.isRequired,
      value: PropTypes.string.isRequired,
    }),
  ).isRequired,
  categoryOptions: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.string.isRequired,
      value: PropTypes.string.isRequired,
    }),
  ).isRequired,
  tooltipText: PropTypes.string,
  defaultErrorMessage: PropTypes.string.isRequired,
  privacyInformation: PropTypes.string,
  attachmentDetails: PropTypes.shape({}),
};

CommentsAndFeedback.defaultProps = {
  user: null,
  privacyInformation: null,
  description: null,
  tooltipText: null,
  attachmentDetails: null,
};

export default connect((state) => ({
  user: state.user,
}))(CommentsAndFeedback);
