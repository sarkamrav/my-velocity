import React from 'react';
import { Provider } from 'react-redux';
import MockAdapter from 'axios-mock-adapter';
import { configureStore } from '../../stores';
import api from '../../utils/api';

import requestCardMock from './mocks/RequestCard.mock.json';
import RequestCard from './RequestCard';
import userData from '../Navigation/mocks/user.mock.json';

export default {
  title: 'Request Card',
};

export const CardReissueSubmissionSuccess = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVff.onGet('/loyalty/v2/cards/reissue').reply(200, {
    data: {
      reissue: true,
    },
  });

  mockVff.onGet('/loyalty/v2/members/profile').reply(200, {
    data: {
      individual: {
        contact: {
          addresses: [
            {
              category: 'PERSONAL',
              lines: ['P_21/34 Bonython St'],
              postalCode: '4000',
              countryCode: 'AU',
              cityName: 'P_WINDSOR',
              stateCode: 'QLD',
              contactValidity: {
                isMain: true,
                isValid: false,
                isConfirmed: true,
              },
            },
            {
              category: 'BUSINESS',
              lines: ['B_21/34 Bonython St'],
              postalCode: '4001',
              countryCode: 'NZ',
              cityName: 'B_WINDSOR',
              stateCode: 'NSW',
              contactValidity: {
                isMain: false,
                isValid: true,
                isConfirmed: false,
              },
            },
          ],
        },
      },
    },
  });

  mockVff.onGet('/loyalty/v2/digital-cards').reply(200, {
    data: {
      membershipId: '1234567890',
      title: 'Mr',
      firstName: 'Donald',
      lastName: 'Duck',
      nameOnCard: 'Mr Donald Duck',
      tierLevel: 'P',
      tierType: 'S',
      tierLabel: 'Standard Platinum',
      pointsBalance: 55,
      cardExpiryDate: '2021-03-03',
      reviewDate: '2021-03-03',
      loungeMembershipExpiryDate: '2021-03-03',
      qrCode: 'L1DUCK/Donald MR       VA 1234567890      RED030321LNG0321',
    },
  });

  mockVff.onPatch('/loyalty/v2/members').reply(200, {
    code: 200,
    title: 'Server success',
    detail: 'Success.',
    status: 200,
    message: 'update completed',
  });

  mockVff.onPost('/loyalty/v2/cards/reissue').reply(200, {
    code: 200,
    title: 'Server success',
    detail: 'Success.',
    status: 200,
    message: 'card request placed',
  });

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <RequestCard {...requestCardMock} />
    </Provider>
  );
};

CardReissueSubmissionSuccess.storyName = 'Card - Form Submission Success';

export const CardReissueFormSubmissionFailed = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVff.onGet('/loyalty/v2/cards/reissue').reply(200, {
    data: {
      reissue: true,
    },
  });

  mockVff.onGet('/loyalty/v2/members/profile').reply(200, {
    data: {
      individual: {
        contact: {
          addresses: [
            {
              category: 'PERSONAL',
              lines: ['P_21/34 Bonython St'],
              postalCode: '4000',
              countryCode: 'AU',
              cityName: 'P_WINDSOR',
              stateCode: 'QLD',
              contactValidity: {
                isMain: true,
                isValid: false,
                isConfirmed: true,
              },
            },
            {
              category: 'BUSINESS',
              lines: ['B_21/34 Bonython St'],
              postalCode: '4001',
              countryCode: 'NZ',
              cityName: 'B_WINDSOR',
              stateCode: 'NSW',
              contactValidity: {
                isMain: false,
                isValid: true,
                isConfirmed: false,
              },
            },
          ],
        },
      },
    },
  });

  mockVff.onGet('/loyalty/v2/digital-cards').reply(200, {
    data: {
      membershipId: '1234567890',
      title: 'Mr',
      firstName: 'Donald',
      lastName: 'Duck',
      nameOnCard: 'Mr Donald Duck',
      tierLevel: 'P',
      tierType: 'S',
      tierLabel: 'Standard Platinum',
      pointsBalance: 55,
      cardExpiryDate: '2021-03-03',
      reviewDate: '2021-03-03',
      loungeMembershipExpiryDate: '2021-03-03',
      qrCode: 'L1DUCK/Donald MR       VA 1234567890      RED030321LNG0321',
    },
  });
  mockVff.onPatch('/loyalty/v2/members').reply(400, {
    code: 37105,
    title: 'Server success',
    detail: 'Success.',
    status: 400,
    message: 'update not completed',
  });

  mockVff.onPost('/loyalty/v2/cards/reissue').reply(400, {
    code: 37623,
    title: 'Server success',
    detail: 'Success.',
    status: 400,
    message: 'card request not placed',
  });

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <RequestCard {...requestCardMock} />
    </Provider>
  );
};

CardReissueFormSubmissionFailed.storyName = 'Card - Form Submission Failed';

export const CardReissueNotAllowed = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVff.onGet('/loyalty/v2/cards/reissue').reply(200, {
    data: {
      reissue: false,
      reason: ['TOO_CLOSE_TO_LAST_ORDER', 'NO_EFFECTIVE_CARD_PRESENT'],
    },
  });
  mockVff.onGet('/loyalty/v2/digital-cards').reply(200, {
    data: {
      membershipId: '1234567890',
      title: 'Mr',
      firstName: 'Donald',
      lastName: 'Duck',
      nameOnCard: 'Mr Donald Duck',
      tierLevel: 'P',
      tierType: 'S',
      tierLabel: 'Standard Platinum',
      pointsBalance: 55,
      cardExpiryDate: '2021-03-03',
      reviewDate: '2021-03-03',
      loungeMembershipExpiryDate: '2021-03-03',
      qrCode: 'L1DUCK/Donald MR       VA 1234567890      RED030321LNG0321',
    },
  });
  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <RequestCard {...requestCardMock} />
    </Provider>
  );
};

CardReissueNotAllowed.storyName = 'Card - Reissue not allowed';

export const CardReissueApiError = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVff.onGet('/loyalty/v2/cards/reissue').reply(400, {
    code: 37623,
  });

  mockVff.onGet('/loyalty/v2/digital-cards').reply(200, {
    data: {
      membershipId: '1234567890',
      title: 'Mr',
      firstName: 'Donald',
      lastName: 'Duck',
      nameOnCard: 'Mr Donald Duck',
      tierLevel: 'P',
      tierType: 'S',
      tierLabel: 'Standard Platinum',
      pointsBalance: 55,
      cardExpiryDate: '2021-03-03',
      reviewDate: '2021-03-03',
      loungeMembershipExpiryDate: '2021-03-03',
      qrCode: 'L1DUCK/Donald MR       VA 1234567890      RED030321LNG0321',
    },
  });
  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <RequestCard {...requestCardMock} />
    </Provider>
  );
};

CardReissueApiError.storyName = 'Card - Reissue API Failed';

export const pdfLoadError = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVff.onGet('/loyalty/v2/cards/reissue').reply(200, {
    data: {
      reissue: false,
      reason: ['TOO_CLOSE_TO_LAST_ORDER', 'NO_EFFECTIVE_CARD_PRESENT'],
    },
  });

  mockVff.onGet('/loyalty/v2/digital-cards').reply(400, {
    data: {
      code: 37549,
    },
  });
  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <RequestCard {...requestCardMock} />
    </Provider>
  );
};

CardReissueApiError.storyName = 'Pdf Load Error ';

export const NoPhysicalCardAllowed = () => (
  <Provider
    store={configureStore({
      user: {
        memberDataLoaded: true,
        memberDataLoading: false,
        authenticated: true,
        tiers: {
          mainTierInfo: {
            tierLevel: 'R',
            tierType: 'S',
          },
        },
      },
    })}
  >
    <RequestCard {...requestCardMock} />
  </Provider>
);

NoPhysicalCardAllowed.storyName = 'No Physical Card';
