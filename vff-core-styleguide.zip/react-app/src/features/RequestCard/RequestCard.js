import React, { useState, useEffect, useCallback } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import isEmpty from 'lodash/isEmpty';
import toLower from 'lodash/toLower';
import reduce from 'lodash/reduce';
import find from 'lodash/find';
import get from 'lodash/get';
import { PDFViewer, PDFDownloadLink } from '@react-pdf/renderer';
import { isMobile, isBrowser } from 'react-device-detect';
import Button from '@/components/Button/Button';
import InformationAlert from '../../components/InformationAlert/InformationAlert';
import Modal, { modalTheme } from '../../components/Modal/Modal';
import useModal from '../../hooks/useModal';

import Loading from '../../components/Loading/Loading';
import * as userData from '../../stores/utilities';
import { COMPONENT_NAME } from '../../utils/common';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import api from '../../utils/api';
import RichTextContent from '../../components/RichTextContent/RichTextContent';

import RequestCardForm from './RequestCardForm/RequestCardForm';
import BasicDocument from './components/PDF/PdfDoc';
import PrintDetail from './components/PrintDetail/PrintDetail';
import styles from './RequestCard.css';

const RequestCard = ({
  user,
  restrictedMemberTiers,
  formDetails,
  reviewPage,
  confirmationPage,
  reasonMessages,
  errorMessages,
  title,
  description,
  ctaContainer,
  printableMembershipCard,
}) => {
  const hasLoggedIn = userData.getHasLoggedIn(user);
  const memberDataLoadError = userData.getMemberDataLoadError(user);
  const membershipID = userData.getLoyaltyMembershipID(user);
  const mainTier = userData.getTierLevel(user);
  const subTier = userData.getSubTierLevel(user);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [reIssue, setReIssue] = useState(false);
  const [addressDetails, setAddressDetails] = useState([]);
  const [whyReissueNotAllowed, setWhyReissueNotAllowed] = useState('');
  const [isFormSubmitted, setIsFormSubmitted] = useState(false);
  const [digitalCardInfo, setDigitalCardInfo] = useState(null);
  const [pdfLoadError, setPdfLoadError] = useState('');
  const [pdfLoading, setpdfLoading] = useState(false);
  const { isShowing, toggle } = useModal();

  const physicalCardReissueApiUri = '/loyalty/v2/cards/reissue';
  const addressDetailsApiUri = '/loyalty/v2/members/profile';
  const digitalCardAPiUrl = '/loyalty/v2/digital-cards';

  const fetchDigitalCardInfo = useCallback(async () => {
    try {
      setpdfLoading(true);
      setPdfLoadError(null);
      const digitalCardResponse = await api.vffV2Api.get(digitalCardAPiUrl);
      setDigitalCardInfo(digitalCardResponse.data.data);
      setpdfLoading(false);
      toggle();
    } catch (err) {
      setpdfLoading(false);
      setPdfLoadError(true);
    }
  }, [toggle]);

  const fetchRequestCard = useCallback(async () => {
    try {
      setLoading(true);
      const cardResp = await api.vffV2Api.get(physicalCardReissueApiUri);
      // If card reissue is allowed/true then only get address details
      if (cardResp.data.data.reissue) {
        const addressResponse = await api.vffV2Api.get(addressDetailsApiUri);
        const addressArr = addressResponse.data.data.individual.contact.addresses;
        setAddressDetails(addressArr);
      } else {
        const reasonField = toLower(cardResp.data.data.reason[0]);
        const getReasonSpecificError = find(
          get(reasonMessages, 'apiErrorMessages'),
          (errorMsg) => toLower(errorMsg.errorFieldName) === reasonField,
        );
        const infoMessage =
          getReasonSpecificError?.description || get(reasonMessages, 'defaultErrorMessage.description');
        setWhyReissueNotAllowed(infoMessage);
      }
      setReIssue(cardResp.data.data.reissue);
      setLoading(false);
    } catch (err) {
      setLoading(false);
      const errorCode = get(err, 'response.data.code', '');
      const errorFields = get(err, 'response.data.errorFields', '');
      const authoredApiErrMsg = get(errorMessages, 'apiErrorMessages');
      const getCodeSpecificError = find(
        authoredApiErrMsg,
        (errorMsg) => errorMsg.code === errorCode && !errorMsg.errorFieldName,
      );
      const getFieldSpecificError = reduce(
        errorFields,
        (result, errorField) =>
          result ||
          find(authoredApiErrMsg, {
            code: errorCode,
            errorFieldName: errorField.field,
          }),
        null,
      );

      // `computedErrorMessage` returns the filtered errorMessage accordingly
      const computedErrorMessage =
        getFieldSpecificError || getCodeSpecificError || get(errorMessages, 'defaultErrorMessage');
      setError(computedErrorMessage);
    }
  }, [errorMessages, reasonMessages]);

  // Checking user belongs to restrictedMemberTiers list
  const isUserInNotAllowedList = restrictedMemberTiers.find(
    (list) => !!(list.subTierLevel === subTier && list.tierLevel === mainTier),
  );

  const isUserAllowed = isEmpty(isUserInNotAllowedList);
  const tierSpecificMsg = isUserInNotAllowedList?.message;

  useEffect(() => {
    if (hasLoggedIn && isUserAllowed) {
      fetchRequestCard();
    }

    if (hasLoggedIn && !isUserAllowed) {
      setLoading(false);
    }
  }, [hasLoggedIn, isUserAllowed, fetchRequestCard]);

  const PdfHandler = () => {
    fetchDigitalCardInfo();
  };

  return (
    <ErrorBoundary section={COMPONENT_NAME.requestCard}>
      <div className={styles.container}>
        {!hasLoggedIn && memberDataLoadError && (
          <InformationAlert
            title=""
            content="Sorry, we're having issues with our system."
            className={styles.errorContainer}
          />
        )}

        {!hasLoggedIn && !memberDataLoadError && (
          <div className={styles.loadingContainer}>
            <Loading />
          </div>
        )}

        {hasLoggedIn && (
          <div className={styles.componentContainer}>
            {!loading && !error && !isFormSubmitted && (
              <PrintDetail
                title={title}
                description={description}
                ctaContainer={ctaContainer}
                PdfHandler={PdfHandler}
                pdfLoading={pdfLoading}
                pdfLoadError={pdfLoadError}
                errorMessages={printableMembershipCard?.errorMessages}
              />
            )}
            {/* show list specific msg to user as per there tier & subtier */}
            {!loading && !isUserAllowed && (
              <RichTextContent className={styles.sectionContainer} content={tierSpecificMsg} />
            )}

            {!loading && isUserAllowed && (
              <section className={styles.sectionContainer}>
                <div className={styles.formContainer}>
                  {isBrowser && isShowing && (
                    <Modal onDismiss={toggle} withCloseButton theme={modalTheme.v2}>
                      <PDFViewer style={{ width: '720px', height: window.innerHeight }}>
                        <BasicDocument
                          printableMembershipCard={printableMembershipCard}
                          digitalCardInfo={digitalCardInfo}
                        />
                      </PDFViewer>
                    </Modal>
                  )}

                  {isMobile && isShowing && (
                    <Modal onDismiss={toggle} withCloseButton theme={modalTheme.v2}>
                      <div className={styles.mobileContainer}>
                        <RichTextContent
                          className={styles.mobileDescription}
                          content={printableMembershipCard.mobileInfo.description}
                        />
                        <PDFDownloadLink
                          document={
                            <BasicDocument
                              printableMembershipCard={printableMembershipCard}
                              digitalCardInfo={digitalCardInfo}
                            />
                          }
                          fileName="membershipcard.pdf"
                        >
                          <Button
                            label={printableMembershipCard.mobileInfo?.ctaContainer.ctaTitle}
                            buttonType={printableMembershipCard.mobileInfo?.ctaContainer.ctaType}
                          >
                            {printableMembershipCard.mobileInfo?.ctaContainer.ctaLabel}
                          </Button>
                        </PDFDownloadLink>
                      </div>
                    </Modal>
                  )}

                  {/* Reissue api failed error */}
                  {!!error && (
                    <InformationAlert
                      title={error.title}
                      content={error.description}
                      className={styles.errorContainer}
                    />
                  )}
                  {/* Reissue is not allowed */}
                  {!reIssue && <RichTextContent className={styles.formDescription} content={whyReissueNotAllowed} />}
                  {/* Show form and address */}

                  {!error && reIssue && (
                    <RequestCardForm
                      setIsFormSubmitted={setIsFormSubmitted}
                      isformSubmitted={isFormSubmitted}
                      authorableContent={formDetails}
                      reviewPage={reviewPage}
                      confirmationPage={confirmationPage}
                      authorableErrMsg={errorMessages}
                      addressDetails={addressDetails}
                      membershipID={membershipID}
                    />
                  )}
                </div>
              </section>
            )}

            {loading && (
              <div className={styles.loadingContainer}>
                <Loading />
              </div>
            )}
          </div>
        )}
      </div>
    </ErrorBoundary>
  );
};

RequestCard.propTypes = {
  user: PropTypes.shape({}),
  restrictedMemberTiers: PropTypes.arrayOf(
    PropTypes.shape({
      subTier: PropTypes.string,
      mainTier: PropTypes.string,
      main: PropTypes.string,
    }),
  ).isRequired,
  ctaContainer: PropTypes.shape({
    ctaTitle: PropTypes.string.isRequired,
    ctaType: PropTypes.string.isRequired,
    ctaStyle: PropTypes.string.isRequired,
    ctaLabel: PropTypes.string.isRequired,
  }).isRequired,
  title: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
  formDetails: PropTypes.shape({}).isRequired,
  reviewPage: PropTypes.shape({}).isRequired,
  confirmationPage: PropTypes.shape({}).isRequired,
  reasonMessages: PropTypes.shape().isRequired,
  errorMessages: PropTypes.shape({}).isRequired,
  printableMembershipCard: PropTypes.shape({
    mobileInfo: PropTypes.shape({
      description: PropTypes.string.isRequired,
      ctaContainer: PropTypes.shape({
        ctaTitle: PropTypes.string.isRequired,
        ctaType: PropTypes.string.isRequired,
        ctaStyle: PropTypes.string.isRequired,
        ctaLabel: PropTypes.string.isRequired,
      }).isRequired,
    }),
    errorMessages: PropTypes.shape({
      defaultErrorMessage: PropTypes.shape({}).isRequired,
    }),
  }).isRequired,
};

RequestCard.defaultProps = {
  user: null,
};

export default connect((state) => ({
  user: state.user,
}))(RequestCard);
