import React from 'react';

/* eslint-disable camelcase */
import imageTilesMock from './mocks/ImageTiles.mock.json';
import image_tiles_item_BwmzGQYa from './mocks/image_tiles_item_BwmzGQYa.mock.json';
import image_tiles_item_EtsMDhR3 from './mocks/image_tiles_item_EtsMDhR3.mock.json';
/* eslint-enable camelcase */

import ImageTiles from './ImageTiles';
import { getPropsDataFromJsObjectKeyArray } from '../../utils/common';

const simulatedWindowObject = {
  uniqueImageTileKey: imageTilesMock,
  image_tiles_item_BwmzGQYa,
  image_tiles_item_EtsMDhR3,
};

const props = getPropsDataFromJsObjectKeyArray(imageTilesMock, simulatedWindowObject, 'tiles');

export default {
  title: 'Image Tiles',
};

export const Default = () => <ImageTiles {...props} />;
