import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import cx from 'classnames';

import A from '../../components/Button/A';
import ImageTile from './ImageTile/ImageTile';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME } from '../../utils/common';
import Header, { headerTitleTag } from '../../components/Header/Header';

import styles from './ImageTiles.css';

const ImageTiles = ({ titleTag, title, description, numberOfTilesPerRow, ctaContainer, tiles, analyticsMetadata }) => {
  const analyticsMetadataKey = analyticsMetadata['analytics-metadata'];
  const [analyticsData, setAnalyticsData] = useState(analyticsMetadataKey);

  useEffect(() => {
    const commonAnalyticsData = window.vffCoreWebsite[analyticsMetadataKey] || {};

    setAnalyticsData({
      ...commonAnalyticsData,
      eventCategory: 'cta-links',
      eventLocation: 'imageTileComponents',
    });
  }, [analyticsMetadataKey]);

  return (
    <ErrorBoundary section={COMPONENT_NAME.imageTiles}>
      <div className={styles.container}>
        {title && <Header tagTitle={titleTag} classNames={styles.mainTitle} title={title} />}

        {description ? (
          <RichTextContent
            className={styles.description}
            content={description}
            analytics-metadata={typeof analyticsData === 'string' ? analyticsData : JSON.stringify(analyticsData)}
          />
        ) : null}

        {!_.isEmpty(tiles) ? (
          <ul
            className={cx(styles.tiles, {
              [styles.twoPerRow]: numberOfTilesPerRow === 'two',
              [styles.threePerRow]: numberOfTilesPerRow === 'three',
              [styles.fourPerRow]: numberOfTilesPerRow === 'four',
            })}
          >
            {_.map(tiles, (tile, index) => (
              <li key={tile.title} className={styles.listItem}>
                <ImageTile
                  {...tile}
                  analyticsMetadataFromParent={{
                    ...analyticsData,
                    tilePosition: index,
                  }}
                />
              </li>
            ))}
          </ul>
        ) : null}

        {!_.isEmpty(ctaContainer) ? (
          <A
            href={ctaContainer.ctaUrl}
            className={styles.mainCta}
            title={ctaContainer.ctaTitle}
            target={ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
            buttonType={ctaContainer.ctaStyle}
            ctaAsLink={ctaContainer.ctaAsLink}
            analytics-metadata={
              typeof analyticsData === 'string'
                ? analyticsData
                : JSON.stringify({
                    ...analyticsData,
                    eventName: 'cta-interaction',
                  })
            }
          >
            {ctaContainer.ctaLabel}
          </A>
        ) : null}
      </div>
    </ErrorBoundary>
  );
};

ImageTiles.propTypes = {
  titleTag: PropTypes.oneOf([
    headerTitleTag.h1,
    headerTitleTag.h2,
    headerTitleTag.h3,
    headerTitleTag.h4,
    headerTitleTag.h5,
    headerTitleTag.h6,
  ]),
  title: PropTypes.string,
  numberOfTilesPerRow: PropTypes.string,
  description: PropTypes.string,
  ctaContainer: PropTypes.shape({
    ctaUrl: PropTypes.string,
    ctaTitle: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaStyle: PropTypes.string,
    ctaAsLink: PropTypes.bool,
    ctaLabel: PropTypes.string,
  }),
  tiles: PropTypes.arrayOf(PropTypes.shape({})),
  analyticsMetadata: PropTypes.shape({
    'analytics-metadata': PropTypes.string,
  }),
};

ImageTiles.defaultProps = {
  titleTag: headerTitleTag.h6,
  title: '',
  numberOfTilesPerRow: 'two',
  description: '',
  ctaContainer: {},
  tiles: [],
  analyticsMetadata: {},
};

export default ImageTiles;
