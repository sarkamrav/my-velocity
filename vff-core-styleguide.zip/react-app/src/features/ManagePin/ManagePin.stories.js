import React from 'react';
import MockAdapter from 'axios-mock-adapter';
import { Provider } from 'react-redux';
import ManagePin from './ManagePin';
import api from '../../utils/api';
import mangePinMockData from './mocks/managePin.json';
import { configureStore } from '../../stores';
import userData from '../Navigation/mocks/user.mock.json';

export default {
  title: 'Manage Pin',
};

export const CreatePinPageSuccess = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });
  mockVff.onGet('/loyalty/v2/pin').reply(200, {
    data: {
      statuses: [],
    },
  });
  mockVff.onPost('/loyalty/v2/pin').reply(200, {
    data: {
      membershipId: '1200867830',
      pin: '1576',
    },
  });

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <ManagePin {...mangePinMockData} />
      </Provider>
    </div>
  );
};

export const CreatePinPageError = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });
  mockVff.onGet('/loyalty/v2/pin').reply(200, {
    data: {
      statuses: [],
    },
  });
  mockVff.onPost('/loyalty/v2/pin').reply(500, {
    status: 500,
    title: 'Server Error',
    code: 4117,
    detail: 'An error occured while handling the request.',
  });

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <ManagePin {...mangePinMockData} />
      </Provider>
    </div>
  );
};

export const UserLocked = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });
  mockVff.onGet('/loyalty/v2/pin').reply(200, {
    data: {
      statuses: [
        {
          function: 'PIN_IDENTIFY',
          statusCode: 'ENABLED',
          statusDate: '2021-01-01T00:00:00Z',
          authenticationFailures: 0,
        },
        {
          function: 'PIN_CHANGE',
          statusCode: 'LOCKED',
          statusDate: '2023-01-01T20:10:00Z',
          authenticationFailures: 0,
        },
      ],
    },
  });

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <ManagePin {...mangePinMockData} />
      </Provider>
    </div>
  );
};
export const CreatePinAPIError = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });
  mockVff.onGet('/loyalty/v2/pin').reply(500, {
    status: 400,
    title: 'Server Error',
    code: 4001,
    detail: 'An error occured while handling the request.',
    errorFields: [
      {
        field: 'data.currentPIN',
        message: 'size must be 4',
      },
    ],
  });
  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <ManagePin {...mangePinMockData} />
      </Provider>
    </div>
  );
};

export const ResetPinError = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });
  mockVff.onGet('/loyalty/v2/pin').reply(200, {
    data: {
      statuses: [
        {
          function: 'PIN_CHANGE',
          statusCode: 'ENABLED',
          statusDate: '2021-01-01T00:00:00Z',
          authenticationFailures: 0,
        },
      ],
    },
  });
  mockVff.onPatch('/loyalty/v2/pin').reply(500, {
    code: 4118,
    title: 'The member has not setup a Velocity PIN',
    detail: 'The member has not setup a Velocity PIN',
    status: 400,
  });

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <ManagePin {...mangePinMockData} />
      </Provider>
    </div>
  );
};

export const ResetPinSuccess = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });
  mockVff.onGet('/loyalty/v2/pin').reply(200, {
    data: {
      statuses: [
        {
          function: 'PIN_CHANGE',
          statusCode: 'ENABLED',
          statusDate: '2021-01-01T00:00:00Z',
          authenticationFailures: 0,
        },
      ],
    },
  });

  mockVff.onPatch('/loyalty/v2/pin').reply(200, {});

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <ManagePin {...mangePinMockData} />
      </Provider>
    </div>
  );
};

export const ChangePinSuccessPage = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });
  mockVff.onGet('/loyalty/v2/pin').reply(200, {
    data: {
      statuses: [
        {
          function: 'PIN_CHANGE',
          statusCode: 'ENABLED',
          statusDate: '2021-01-01T00:00:00Z',
          authenticationFailures: 0,
        },
      ],
    },
  });
  mockVff.onPost('/loyalty/v2/pin').reply(200, {
    data: {
      membershipId: '1200867830',
      status: {
        authentication: {
          response: 'VALID',
          failures: 0,
        },
      },
    },
  });
  mockVff.onPatch('/loyalty/v2/pin').reply(200, {
    data: {
      membershipId: '1200867830',
      pin: '1576',
    },
  });
  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <ManagePin {...mangePinMockData} />
      </Provider>
    </div>
  );
};
export const FinalInvalidAttempt = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });
  mockVff.onGet('/loyalty/v2/pin').reply(200, {
    data: {
      statuses: [
        {
          function: 'PIN_CHANGE',
          statusCode: 'ENABLED',
          statusDate: '2021-01-01T00:00:00Z',
          authenticationFailures: 0,
        },
      ],
    },
  });
  mockVff.onPost('/loyalty/v2/pin').reply(500, {
    status: 400,
    title: 'Server Error',
    code: 4120,
    detail: 'An error occured while handling the request.',
  });
  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <ManagePin {...mangePinMockData} />
      </Provider>
    </div>
  );
};

export const invalidAttemptMessage = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });
  mockVff.onGet('/loyalty/v2/pin').reply(200, {
    data: {
      statuses: [
        {
          function: 'PIN_CHANGE',
          statusCode: 'ENABLED',
          statusDate: '2021-01-01T00:00:00Z',
          authenticationFailures: 0,
        },
      ],
    },
  });
  mockVff.onPost('/loyalty/v2/pin').reply(200, {
    data: {
      membershipId: '1200867830',
      status: {
        authentication: {
          response: 'INVALID',
          failures: 2,
        },
      },
    },
  });
  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <ManagePin {...mangePinMockData} />
      </Provider>
    </div>
  );
};

export const ChangeErrorPage = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });
  mockVff.onGet('/loyalty/v2/pin').reply(200, {
    data: {
      statuses: [
        {
          function: 'PIN_CHANGE',
          statusCode: 'ENABLED',
          statusDate: '2021-01-01T00:00:00Z',
          authenticationFailures: 0,
        },
      ],
    },
  });
  mockVff.onPost('/loyalty/v2/pin').reply(500, {
    status: 400,
    title: 'Server Error',
    errorFields: [
      {
        field: 'enrolmentSource',
        message: 'must not contain | character',
      },
    ],
    code: 4121,
    detail: 'An error occured while handling the request.',
  });
  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <ManagePin {...mangePinMockData} />
      </Provider>
    </div>
  );
};
