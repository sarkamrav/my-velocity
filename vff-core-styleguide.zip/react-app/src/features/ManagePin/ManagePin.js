/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import PropTypes from 'prop-types';
import includes from 'lodash/includes';
import get from 'lodash/get';
import size from 'lodash/size';
import noop from 'lodash/noop';
import omit from 'lodash/omit';
import { connect } from 'react-redux';
import { DateTime } from 'luxon';
import styles from './ManagePin.css';
import * as normalize from '../../components/Form/normalizers';
import { normalizeFormField, validateFormField } from '../../components/Form/utils';
import * as validate from '../../components/Form/validators';
import Loading from '../../components/Loading/Loading';
import api from '../../utils/api';
import * as userData from '../../stores/utilities';
import CreatePinForm from './ManagePinForm/CreatePinForm';
import ChangePinForm from './ManagePinForm/ChangePinForm';
import ResetPinTile from './ManagePinForm/ResetPinTile';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import SuccessMessageTile from '../../components/SuccessMessageTile/SuccessMessageTile';
import { COMPONENT_NAME, scrollToRef, serverTimeZone, getAuthorableErrorMsg } from '../../utils/common';
import TopContentContainer from '../../components/Form/containers/TopContentContainer/TopContentContainer';
import MessageTile from '../../components/MessageTile/MessageTile';
import FormContainer from '../../components/Form/containers/FormContainer/FormContainer';

import Modal, { modalTheme } from '../../components/Modal/Modal';
import useModal from '../../hooks/useModal';

const formFieldNames = {
  pinNumber: 'pinNumber',
  pinNumberConfirm: 'pinNumberConfirm',
  currentPinNumber: 'currentPinNumber',
};
const initialValues = {
  [formFieldNames.pinNumber]: '',
  [formFieldNames.pinNumberConfirm]: '',
  [formFieldNames.currentPinNumber]: '',
};

const fieldNormalizers = {
  currentPinNumber: [normalize.onlyNumbers, normalize.maxLength(4)],
  pinNumber: [normalize.onlyNumbers, normalize.maxLength(4)],
  pinNumberConfirm: [normalize.onlyNumbers, normalize.maxLength(4)],
};

const ManagePinPage = ({ user, createVelocityPin, changeVelocityPin, resetVelocityPin, errorMessages }) => {
  const { lockedVelocityPin } = changeVelocityPin;
  const [values, setValues] = useState(initialValues);
  const [loading, setLoading] = useState(false);

  const [createPinLoading, setCreatePinLoading] = useState(false);
  const [createPinLoaded, setCreatePinLoaded] = useState(false);
  const [isCreatePin, setIsCreatePin] = useState(false);
  const [newUserPin, setNewUserPin] = useState(false);

  const [changePinLoading, setChangePinLoading] = useState(false);
  const [changePinLoaded, setChangePinLoaded] = useState(false);
  const [isChangePin, setIsChangePin] = useState(false);
  const [existingUserPin, setExistingUserPin] = useState(false);

  const [touchedFields, setTouchedFields] = useState([]);
  const [errors, setErrors] = useState({});

  const [pageError, setPageError] = useState(false);
  const [postError, setPostError] = useState(null);
  const [systemError, setSystemError] = useState(false);

  const [hasPinChangedLocked, setHasPinChangedLocked] = useState(false);
  const [invalidAttemptMessage, setInvalidAttemptMessage] = useState('');

  const { isShowing: showModal, toggle: showModalInfo } = useModal();
  const [resetPinLoading, setResetPinLoading] = useState(false);
  const [resetPinLoaded, setResetPinLoaded] = useState(false);
  const [resetPinError, setResetPinError] = useState('');

  const errorMessageRef = useRef({});

  const fieldValidators = useMemo(
    () => ({
      [formFieldNames.currentPinNumber]: [validate.required('A PIN number is required')],
      [formFieldNames.pinNumber]: [
        validate.required('A PIN number is required'),
        validate.pin,
        ...(includes(touchedFields, 'pinNumberConfirm')
          ? [validate.matchesField('pinNumberConfirm', 'PIN numbers must match')]
          : []),
      ],
      [formFieldNames.pinNumberConfirm]: [
        validate.required('A confirmation PIN number is required'),
        validate.pin,
        ...(includes(touchedFields, 'pinNumber') ? [validate.matchesField('pinNumber', 'PIN numbers must match')] : []),
      ],
    }),
    [touchedFields],
  );

  const membershipId = userData.getLoyaltyMembershipID(user);
  const memberDataLoading = userData.getMemberDataLoading(user);
  const hasLoggedIn = userData.getHasLoggedIn(user);
  const memberDataLoadError = userData.getMemberDataLoadError(user);

  async function getStatus() {
    try {
      setLoading(true);
      const response = await api.vffV2Api.get('/loyalty/v2/pin');

      let getUserStatus;
      if (response?.data?.data?.statuses?.length === 0) {
        setLoading(false);
        setIsCreatePin(true);
      } else {
        getUserStatus = response?.data?.data?.statuses?.find((post) => post.function === 'PIN_CHANGE');

        if (getUserStatus?.statusCode === 'LOCKED') {
          const currentTime = DateTime.fromObject({}, serverTimeZone);
          const lockInPeriod = DateTime.fromISO(getUserStatus?.statusDate, serverTimeZone).plus({ days: 1 });
          if (currentTime < lockInPeriod) {
            setLoading(false);
            setHasPinChangedLocked(true);
          }
          setLoading(false);
          setIsChangePin(true);
        } else {
          setLoading(false);
          setIsChangePin(true);
        }
      }
    } catch (error) {
      setLoading(false);
      setSystemError(true);
      const customError = getAuthorableErrorMsg(error, errorMessages);
      setPostError(customError);
    }
  }

  useEffect(() => {
    if (hasLoggedIn) {
      getStatus();
    }
  }, [hasLoggedIn]);

  useEffect(() => {
    if (pageError && errorMessageRef.current) {
      scrollToRef(errorMessageRef);
    }
  }, [pageError]);

  // Validates field and returns an error message if it is invalid
  // eslint-disable-next-line arrow-body-style
  const validateField = useCallback(
    (fieldName, fieldValue) =>
      // Exit early if we aren't even showing this field
      // if (!shouldShowField(fieldName, values)) return '';
      validateFormField(fieldValue, fieldValidators[fieldName], values),
    [fieldValidators, values],
  );

  // Runs and applies field validation
  const runFieldValidation = useCallback(
    (fieldName, fieldValue) => {
      const error = validateField(fieldName, fieldValue);

      if (error) {
        setErrors((currentErrors) => ({
          ...currentErrors,
          [fieldName]: error,
          ...(fieldName === 'pinNumber' ? { pinNumberConfirm: '' } : {}),
          ...(fieldName === 'pinNumberConfirm' ? { pinNumber: '' } : {}),
        }));
      } else {
        setErrors((currentErrors) =>
          omit(currentErrors, [
            fieldName,
            ...(fieldName === 'pinNumber' ? ['pinNumberConfirm'] : ''),
            ...(fieldName === 'pinNumberConfirm' ? ['pinNumber'] : []),
          ]),
        );
      }
    },
    [validateField],
  );

  // -- Handlers
  const handleFieldChange = useCallback(
    (fieldName) => (newValue) => {
      const normalizedValue = normalizeFormField(newValue, fieldNormalizers[fieldName]);

      // Set value
      setValues((previousValues) => ({
        ...previousValues,
        [fieldName]: normalizedValue,
      }));

      // Give immediate error feedback for fields that are already touched
      const isTouched = includes(touchedFields, fieldName);
      if (isTouched) {
        runFieldValidation(fieldName, normalizedValue);
      }
    },
    [runFieldValidation, touchedFields],
  );

  const handleFieldChangeEvent = useCallback(
    (event) => {
      handleFieldChange(event.target.name)(event.target.value);
    },
    [handleFieldChange],
  );

  const handleFieldBlur = useCallback(
    (fieldName) => () => {
      // Add to list of touched fields if required
      if (!includes(touchedFields, fieldName)) {
        setTouchedFields([...touchedFields, fieldName]);
      }

      // Set any errors
      runFieldValidation(fieldName, values[fieldName]);
    },
    [runFieldValidation, touchedFields, values],
  );

  const handleFieldBlurEvent = useCallback(
    (event) => {
      handleFieldBlur(event.target.name)();
    },
    [handleFieldBlur],
  );

  function checkSubmit() {
    if (isChangePin) {
      if (values?.currentPinNumber?.length > 0 && size(errors) === 0) return false;
      return true;
    }
    if (isCreatePin) {
      if (
        values?.pinNumber?.length > 0 &&
        values?.pinNumberConfirm?.length > 0 &&
        values?.pinNumber === values?.pinNumberConfirm &&
        size(errors) === 0
      )
        return false;
      return true;
    }
    return true;
  }

  const onChangePinFormSubmit = useCallback(
    async (event) => {
      event.preventDefault();
      const changePinMemberApi = '/loyalty/v2/pin';

      const requestBodyChange = {
        data: {
          membershipId,
          action: 'VALIDATE',
          pin: values.currentPinNumber,
          channel: 'INET',
          channelIdentifier: 'INET',
          status: {
            function: 'PIN_CHANGE',
          },
        },
      };

      try {
        setChangePinLoading(true);
        setChangePinLoaded(false);
        setPageError('');
        const response = await api.vffV2Api.post(changePinMemberApi, requestBodyChange);
        setChangePinLoading(false);
        setChangePinLoaded(true);
        const userRecord = response && response.data;
        const userResponse = userRecord?.data?.status?.authentication?.response;
        const userInvalidAttempt = userRecord?.data?.status?.authentication?.failures;
        if (userResponse === 'INVALID') {
          setPageError(true);
          if (userInvalidAttempt === 1) {
            setInvalidAttemptMessage(lockedVelocityPin?.firstIncorrectAttemptMessage);
          } else {
            setInvalidAttemptMessage(lockedVelocityPin?.secondIncorrectAttemptMessage);
          }
        } else {
          setInvalidAttemptMessage('');
          setPageError(false);
          setIsCreatePin(true);
          setIsChangePin(false);
          setExistingUserPin(true);
        }
      } catch (error) {
        setChangePinLoading(false);
        const errorCode = get(error, 'response.data.code', '');
        const errorStatus = get(error, 'response.data.status', '');
        if (errorStatus === 400 && errorCode === 4120) {
          setInvalidAttemptMessage('');
          setChangePinLoading(false);
          setHasPinChangedLocked(true);
        } else {
          setPageError(true);
        }
        const customError = getAuthorableErrorMsg(error, changeVelocityPin?.errorMessages);
        setPostError(customError);
      }
    },
    [
      lockedVelocityPin?.firstIncorrectAttemptMessage,
      changeVelocityPin?.errorMessages,
      lockedVelocityPin?.secondIncorrectAttemptMessage,
      membershipId,
      values.currentPinNumber,
    ],
  );

  const onCreatePinFormSubmit = useCallback(
    async (event) => {
      event.preventDefault();
      const createPinMemberApi = '/loyalty/v2/pin';
      const requestBodyCreate = {
        data: {
          membershipId,
          sendPinSetupNotification: true,
          ...(existingUserPin
            ? { newPIN: values.pinNumber, pin: values.currentPinNumber, action: 'UPDATE' }
            : { pin: values.pinNumber, action: 'CREATE' }),
          channel: 'INET',
          channelIdentifier: 'INET',
        },
      };

      try {
        setPageError('');
        setCreatePinLoading(true);
        setCreatePinLoaded(false);
        // if user is creating first time Pin than post
        // if updating than patch
        if (existingUserPin) {
          await api.vffV2Api.patch(createPinMemberApi, requestBodyCreate);
        } else {
          await api.vffV2Api.post(createPinMemberApi, requestBodyCreate);
        }
        setCreatePinLoading(false);
        setCreatePinLoaded(true);
        setNewUserPin(true);
      } catch (error) {
        setCreatePinLoading(false);
        setPageError(true);
        const customError = getAuthorableErrorMsg(error, createVelocityPin?.errorMessages);
        setPostError(customError);
      }
    },
    [membershipId, existingUserPin, values.currentPinNumber, createVelocityPin?.errorMessages, values.pinNumber],
  );

  const onResetPinModelSubmit = useCallback(
    async (event) => {
      event.preventDefault();
      const forgetPinMemberApi = '/loyalty/v2/pin';

      const requestBodyAnswer = {
        data: {
          membershipId,
          action: 'RESET',
          channel: 'INET',
          channelIdentifier: 'INET',
        },
      };
      try {
        setResetPinLoaded(false);
        setResetPinLoading(true);
        setResetPinError('');
        await api.vffV2Api.patch(forgetPinMemberApi, requestBodyAnswer);
        setResetPinLoading(false);
        setResetPinLoaded(true);
      } catch (error) {
        setResetPinLoading(false);
        setResetPinLoaded(false);
        setResetPinError(resetVelocityPin?.errorMessages?.defaultErrorMessage?.description);
      }
    },
    [membershipId, resetVelocityPin?.errorMessages?.defaultErrorMessage?.description],
  );

  const modalInfo = (event) => {
    event.preventDefault();
    setResetPinError('');
    setResetPinLoaded(false);
    showModalInfo();
  };

  return (
    <ErrorBoundary section={COMPONENT_NAME.managePin}>
      <div className={styles.container}>
        {!hasLoggedIn && memberDataLoadError && (
          <div className={styles.errorMessage}>
            <MessageTile theme="error" description="Sorry, we're having issues with our system." />
          </div>
        )}

        {((!hasLoggedIn && !memberDataLoadError && memberDataLoading) || (hasLoggedIn && loading)) && (
          <Loading containerClassName={styles.loading} />
        )}

        {hasLoggedIn && !loading && (
          <>
            <TopContentContainer theme="typeB">
              {pageError && !hasPinChangedLocked && !invalidAttemptMessage && (
                <MessageTile theme="error" ref={errorMessageRef} description={postError?.description} />
              )}
              {systemError && !hasPinChangedLocked && (
                <MessageTile theme="error" ref={errorMessageRef} description={postError?.description} />
              )}
              {pageError && !hasPinChangedLocked && invalidAttemptMessage && (
                <MessageTile theme="error" ref={errorMessageRef} description={invalidAttemptMessage} />
              )}

              {hasPinChangedLocked && (
                <SuccessMessageTile
                  className={styles.successMessageTileWrapper}
                  iconPath={lockedVelocityPin?.confirmation?.iconUrl}
                  title={lockedVelocityPin?.confirmation?.title}
                  content={lockedVelocityPin?.confirmation?.description}
                  ctaContainer={lockedVelocityPin?.confirmation?.ctaContainer}
                />
              )}

              {newUserPin && !existingUserPin && (
                <SuccessMessageTile
                  className={styles.successMessageTileWrapper}
                  title={createVelocityPin?.confirmation?.title}
                  content={createVelocityPin?.confirmation?.description}
                  ctaContainer={createVelocityPin?.confirmation?.ctaContainer}
                />
              )}

              {existingUserPin && createPinLoaded && (
                <SuccessMessageTile
                  className={styles.successMessageTileWrapper}
                  title={changeVelocityPin?.confirmation?.title}
                  content={changeVelocityPin?.confirmation?.description}
                  ctaContainer={changeVelocityPin?.confirmation?.ctaContainer}
                />
              )}
            </TopContentContainer>

            {!hasPinChangedLocked && !systemError && !newUserPin && (
              <div className={styles.formWrapper} aria-live="polite">
                <FormContainer type="typeB">
                  {((isChangePin && !changePinLoaded) || (isChangePin && pageError)) && (
                    <ChangePinForm
                      changeVelocityPin={changeVelocityPin}
                      handleFieldChangeEvent={handleFieldChangeEvent}
                      handleFieldBlurEvent={handleFieldBlurEvent}
                      values={values}
                      errors={errors}
                      changePinLoading={changePinLoading}
                      toggle={modalInfo}
                      checkSubmit={checkSubmit() || changePinLoading}
                      formFieldNames={formFieldNames}
                      onChangePinFormSubmit={onChangePinFormSubmit}
                    />
                  )}

                  {isCreatePin && !createPinLoaded && (
                    <CreatePinForm
                      createVelocityPin={createVelocityPin}
                      handleFieldChangeEvent={handleFieldChangeEvent}
                      handleFieldBlurEvent={handleFieldBlurEvent}
                      values={values}
                      errors={errors}
                      createPinLoading={createPinLoading}
                      pageError={pageError}
                      checkSubmit={checkSubmit() || createPinLoading}
                      formFieldNames={formFieldNames}
                      onCreatePinFormSubmit={onCreatePinFormSubmit}
                    />
                  )}

                  {showModal && (
                    <Modal
                      onDismiss={resetPinLoading ? noop : showModalInfo}
                      aria-label="confirm your choice"
                      withCloseButton
                      closeButtonText={
                        resetPinLoaded
                          ? `close the ${resetVelocityPin?.confirmation?.title} modal`
                          : `close the ${resetVelocityPin?.title} modal`
                      }
                      theme={modalTheme.v2}
                    >
                      {!resetPinLoaded && (
                        <ResetPinTile
                          title={resetVelocityPin?.title}
                          iconPath={resetVelocityPin?.iconUrl}
                          content={resetVelocityPin?.description}
                          ctaContainer={resetVelocityPin.ctaContainer}
                          onResetPinModelSubmit={(e) => onResetPinModelSubmit(e)}
                          resetPinError={resetPinError}
                          resetPinLoading={resetPinLoading}
                        />
                      )}

                      {resetPinLoaded && (
                        <ResetPinTile
                          iconPath={resetVelocityPin?.confirmation?.iconUrl}
                          title={resetVelocityPin?.confirmation?.title}
                          content={resetVelocityPin?.confirmation?.description}
                        />
                      )}
                    </Modal>
                  )}
                </FormContainer>
              </div>
            )}
          </>
        )}
      </div>
    </ErrorBoundary>
  );
};

const mapStateToProps = (state) => ({
  user: state.user,
});

ManagePinPage.propTypes = {
  user: PropTypes.shape({}).isRequired,
  createVelocityPin: PropTypes.shape({
    errorMessages: PropTypes.shape({
      defaultErrorMessage: PropTypes.shape({}).isRequired,
      apiErrorMessages: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
    }).isRequired,
    confirmation: PropTypes.shape({
      description: PropTypes.string.isRequired,
      title: PropTypes.string.isRequired,
      ctaContainer: PropTypes.shape({}).isRequired,
    }).isRequired,
  }).isRequired,

  changeVelocityPin: PropTypes.shape({
    lockedVelocityPin: PropTypes.shape({
      firstIncorrectAttemptMessage: PropTypes.string.isRequired,
      secondIncorrectAttemptMessage: PropTypes.string.isRequired,
      confirmation: PropTypes.shape({
        iconUrl: PropTypes.string.isRequired,
        description: PropTypes.string.isRequired,
        title: PropTypes.string.isRequired,
        ctaContainer: PropTypes.shape({}).isRequired,
      }).isRequired,
    }).isRequired,
    errorMessages: PropTypes.shape({
      defaultErrorMessage: PropTypes.shape({}).isRequired,
      apiErrorMessages: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
    }).isRequired,
    confirmation: PropTypes.shape({
      description: PropTypes.string.isRequired,
      title: PropTypes.string.isRequired,
      ctaContainer: PropTypes.shape({}).isRequired,
    }).isRequired,
  }).isRequired,

  resetVelocityPin: PropTypes.shape({
    iconUrl: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
    ctaContainer: PropTypes.shape({}).isRequired,
    confirmation: PropTypes.shape({
      iconUrl: PropTypes.string.isRequired,
      title: PropTypes.string.isRequired,
      description: PropTypes.string.isRequired,
    }).isRequired,
    errorMessages: PropTypes.shape({
      defaultErrorMessage: PropTypes.shape({
        description: PropTypes.string.isRequired,
      }).isRequired,
    }).isRequired,
  }).isRequired,
  errorMessages: PropTypes.shape({
    defaultErrorMessage: PropTypes.shape({
      description: PropTypes.string.isRequired,
    }).isRequired,
  }).isRequired,
};

export default connect(mapStateToProps)(ManagePinPage);
