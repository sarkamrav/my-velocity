import React from 'react';
import ReactDOM from 'react-dom';
import map from 'lodash/map';
import size from 'lodash/size';
import { Provider } from 'react-redux';
import ManagePinPage from './ManagePin';
import store from '../../stores';
import { COMPONENT_NAME } from '../../utils/common';

const ELEMENT_NAME = COMPONENT_NAME.managePin;

function renderComponent(elements) {
  map(elements, (element) => {
    const props = window.vffCoreWebsite[element.getAttribute(ELEMENT_NAME)];

    if (props) {
      const component = (
        <Provider store={store}>
          <ManagePinPage {...props} />
        </Provider>
      );
      ReactDOM.render(component, element);
    }
  });
}

export default {
  elementName: ELEMENT_NAME,
  bootstrap: (id = null) => {
    const elements = document.querySelectorAll(`[${ELEMENT_NAME}${id ? `=${id}` : ''}]`);

    if (size(elements) > 0) {
      renderComponent(elements);
    }
  },
};
