import React from 'react';
import _ from 'lodash';

/* eslint-disable camelcase */
import contentTilesMock from './mocks/ContentTiles.mock.json';
import image_tiles_item_ir_JYMKTzcY from './mocks/image-tiles_item_ir_JYMKTzcY.mock.json';
import image_tiles_item_ir_QPUDqQXH from './mocks/image-tiles_item_ir_QPUDqQXH.mock.json';
import image_tiles_item_ir_RzvnQVcd from './mocks/image-tiles_item_ir_RzvnQVcd.mock.json';
import image_tiles_item_JYMKTzcY from './mocks/image-tiles_item_JYMKTzcY.mock.json';
import image_tiles_item_QPUDqQXH from './mocks/image-tiles_item_QPUDqQXH.mock.json';
import image_tiles_item_RzvnQVcd from './mocks/image-tiles_item_RzvnQVcd.mock.json';
/* eslint-enable camelcase */
import ContentTiles from './ContentTiles';

export function getPropsDataFromJsObjectKeyArrayLevel2(componentData, windowObject, objectKey1, objectKey2) {
  return {
    ...componentData,
    [objectKey1]: _.map(componentData[objectKey1], (item) => ({
      ...item,
      [objectKey2]: _.map(item[objectKey2], (item2) => ({
        ...item2,
        ..._.get(windowObject, `[${item2.jsObjectKey}]`),
      })),
    })),
  };
}

const simulatedWindowObject = {
  uniqueImageTileKey: contentTilesMock,
  'image-tiles_item_ir_JYMKTzcY': image_tiles_item_ir_JYMKTzcY,
  'image-tiles_item_ir_QPUDqQXH': image_tiles_item_ir_QPUDqQXH,
  'image-tiles_item_ir_RzvnQVcd': image_tiles_item_ir_RzvnQVcd,
  'image-tiles_item_JYMKTzcY': image_tiles_item_JYMKTzcY,
  'image-tiles_item_QPUDqQXH': image_tiles_item_QPUDqQXH,
  'image-tiles_item_RzvnQVcd': image_tiles_item_RzvnQVcd,
};

const props = getPropsDataFromJsObjectKeyArrayLevel2(
  contentTilesMock,
  simulatedWindowObject,
  'contentTileCategories',
  'tiles',
);

export default {
  title: 'Content Tiles Filter',
  excludeStories: ['getPropsDataFromJsObjectKeyArrayLevel2'],
};

export const StackMode = () => <ContentTiles {...props} />;
export const ScrollMode = () => <ContentTiles {...props} displayOption="scroll" />;
