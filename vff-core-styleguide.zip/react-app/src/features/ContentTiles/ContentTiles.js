import React, { useState, useCallback, useEffect } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import cx from 'classnames';

import ContentTilesFilter from './ContentTilesFilter/ContentTilesFilter';
import ContentTile from './ContentTile/ContentTile';
import A from '../../components/Button/A';
import analyticsSend from '../../utils/analytics';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME } from '../../utils/common';

import styles from './ContentTiles.css';

const ContentTiles = ({
  contentTileCategories,
  title,
  description,
  ctaContainer,
  displayOption,
  analyticsMetadata,
  backgroundColor,
}) => {
  const analyticsMetadataKey = analyticsMetadata['analytics-metadata'];
  const [activeCategoryIndex, setActiveCategoryIndex] = useState(0);
  const [analyticsData, setAnalyticsData] = useState(analyticsMetadataKey);

  useEffect(() => {
    const commonAnalyticsData = window.vffCoreWebsite[analyticsMetadataKey] || {};

    setAnalyticsData({
      ...commonAnalyticsData,
      eventLocation: 'contentTileContainer',
    });
  }, [analyticsMetadataKey]);

  const getActiveCategoryName = useCallback(
    (index) => _.get(contentTileCategories, `[${index}].category.categoryName`),
    [contentTileCategories],
  );

  const onCategoryButtonClicked = useCallback(
    (index) => {
      setActiveCategoryIndex(index);

      analyticsSend({
        ...analyticsData,
        eventCategory: 'contentFilter',
        eventName: 'content-filter-category',
        contentCategory: getActiveCategoryName(index),
      });
    },
    [analyticsData, getActiveCategoryName],
  );

  return (
    <ErrorBoundary section={COMPONENT_NAME.contentTiles}>
      <div
        className={cx(styles.contentTilesWrapper, {
          [styles.purple]: backgroundColor === 'purple',
          [styles.darkPurple]: backgroundColor === 'dark-purple',
          [styles.palePurple]: backgroundColor === 'pale-purple',
        })}
      >
        <div className={styles.container}>
          {title ? <h1 className={styles.title}>{title}</h1> : null}

          {description ? (
            <RichTextContent
              className={styles.description}
              content={description}
              analytics-metadata={typeof analyticsData === 'string' ? analyticsData : JSON.stringify(analyticsData)}
            />
          ) : null}

          {contentTileCategories.length > 1 ? (
            <ContentTilesFilter
              className={styles.filter}
              categories={contentTileCategories}
              activeCategoryIndex={activeCategoryIndex}
              onCategoryButtonClicked={onCategoryButtonClicked}
            />
          ) : null}

          {_.map(contentTileCategories, (contentTileCategory, index) => (
            <ul
              key={_.get(contentTileCategory, 'category.categoryName')}
              className={cx(styles.cardList, {
                [styles.activeList]: activeCategoryIndex === index,
                [styles.scrollMode]: displayOption === 'scroll',
                [styles.totalOne]: contentTileCategory.tiles.length === 1,
                [styles.totalTwo]: contentTileCategory.tiles.length === 2,
              })}
            >
              {_.map(contentTileCategory.tiles, (tile) => (
                <li key={tile.jsObjectKey} className={styles.listItem}>
                  <ContentTile
                    {...tile}
                    analyticsMetadataFromParent={
                      typeof analyticsData === 'string'
                        ? {}
                        : {
                            ...analyticsData,
                            contentCategory: getActiveCategoryName(activeCategoryIndex),
                          }
                    }
                  />
                </li>
              ))}
            </ul>
          ))}

          {!_.isEmpty(ctaContainer) ? (
            <div className={styles.wrapper}>
              <A
                href={ctaContainer.ctaUrl}
                className={styles.mainCta}
                title={ctaContainer.ctaTitle}
                target={ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
                buttonType={ctaContainer.ctaStyle}
                ctaAsLink={ctaContainer.ctaAsLink}
                analytics-metadata={
                  typeof analyticsData === 'string'
                    ? analyticsData
                    : JSON.stringify({
                        ...analyticsData,
                        eventCategory: 'cta-links',
                        eventName: 'cta-interaction',
                      })
                }
              >
                {ctaContainer.ctaLabel}
              </A>
            </div>
          ) : null}
        </div>
      </div>
    </ErrorBoundary>
  );
};

ContentTiles.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
  backgroundColor: PropTypes.string,
  contentTileCategories: PropTypes.arrayOf(PropTypes.shape({})),
  ctaContainer: PropTypes.shape({
    ctaUrl: PropTypes.string,
    ctaTitle: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaStyle: PropTypes.string,
    ctaAsLink: PropTypes.bool,
    ctaLabel: PropTypes.string,
  }),
  analyticsMetadata: PropTypes.shape({
    'analytics-metadata': PropTypes.string,
  }),
  displayOption: PropTypes.string,
};

ContentTiles.defaultProps = {
  title: '',
  description: '',
  backgroundColor: '',
  contentTileCategories: [],
  ctaContainer: {},
  analyticsMetadata: {},
  displayOption: 'stack',
};

export default ContentTiles;
