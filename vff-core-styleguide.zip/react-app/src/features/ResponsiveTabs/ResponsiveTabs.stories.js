import React from 'react';
import ResponsiveTabs from './ResponsiveTabs';

import ResponsiveTabsMock from './mocks/responsive-tabs.mock.json';

export default {
  title: 'Responsive Tabs',
};

export const Default = () => (
  <>
    <ResponsiveTabs {...ResponsiveTabsMock} />

    {ResponsiveTabsMock.tabs.map((tab) => (
      <div
        key={tab.id}
        id={tab.id}
        className="tabs__content"
        aria-labelledby={`tab-${tab.id}`}
        role="tabpanel"
        tabIndex="0"
      >
        {tab.id}
      </div>
    ))}
  </>
);
