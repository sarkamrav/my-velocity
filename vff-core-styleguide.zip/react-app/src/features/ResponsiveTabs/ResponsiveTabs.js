import React, { useEffect, useState, useRef, useCallback } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import some from 'lodash/some';
import get from 'lodash/get';
import each from 'lodash/each';
import map from 'lodash/map';
import findIndex from 'lodash/findIndex';

import analyticsSend from '../../utils/analytics';
import { COMPONENT_NAME, getHashId, scrollToElement } from '../../utils/common';
import { isElementInTab } from './utils';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';

import styles from './ResponsiveTabs.css';

const ResponsiveTabs = ({ tabs, analyticsMetadata, tabSummary }) => {
  const [selectedTab, setSelectedTab] = useState('');

  const tabsRef = useRef();

  useEffect(() => {
    // If hash exists in tabs, use that as default selectedTab, otherwise fallback to first tab
    const hashId = getHashId();
    const defaultTabId = some(tabs, { id: hashId }) ? hashId : get(tabs, '[0].id');
    setSelectedTab(defaultTabId);
  }, [tabs]);

  useEffect(() => {
    // Because the actual content for the tabs is not actually nested in this
    // component, find it in the DOM and make sure the correct tab content is
    // showing
    each(tabs, (tab) => {
      const element = document.getElementById(tab.id);

      if (element) {
        if (selectedTab === tab.id) {
          element.classList.add('tabs__content--active');
        } else {
          element.classList.remove('tabs__content--active');
        }
      }
    });
  }, [selectedTab, tabs]);

  const handleChangeTab = useCallback(
    (tab) => {
      setSelectedTab(tab.id);
      window.location.hash = `#${tab.id}`;

      scrollToElement(document.getElementById(`tab-${tab.id}`));

      const analyticsData = window.vffCoreWebsite[get(analyticsMetadata, 'analytics-metadata', '')] || {};
      analyticsSend({
        ...analyticsData,
        eventName: 'tab-selection',
        eventCategory: 'tabs',
        moduleSelected: tab.id,
        moduleSelectedText: tab.title,
      });
    },
    [analyticsMetadata],
  );

  useEffect(() => {
    function handleEnsureElementIsVisible(event) {
      const targetElement = event.target;
      const hashId = getHashId();
      const isHashIdTabItem = findIndex(tabs, (tab) => tab.id === hashId) !== -1;

      if (isHashIdTabItem) {
        setSelectedTab(hashId);
        return;
      }

      const tabContainingTargetElement = tabs.find((tab) => isElementInTab(targetElement, tab));

      if (tabContainingTargetElement) {
        setSelectedTab(tabContainingTargetElement.id);
      }
    }

    // Attach event listeners
    each(tabs, (tab) => {
      const element = document.getElementById(tab.id);

      if (element) {
        element.addEventListener('ensureElementIsVisible', handleEnsureElementIsVisible);
      }
    });

    return () => {
      // Remove event listeners
      each(tabs, (tab) => {
        const element = document.getElementById(tab.id);

        if (element) {
          element.removeEventListener('ensureElementIsVisible', handleEnsureElementIsVisible);
        }
      });
    };
  }, [tabs]);

  useEffect(() => {
    function handleHashChange() {
      const hashId = getHashId();
      const isTabFound = findIndex(tabs, (tab) => tab.id === hashId) !== -1;

      if (isTabFound) {
        setSelectedTab(hashId);
      }
    }

    window.addEventListener('hashchange', handleHashChange, false);

    return () => window.removeEventListener('hashchange', handleHashChange, false);
  }, [tabs]);

  useEffect(() => {
    function handOnKeyUp(event) {
      const hasArrowRightClicked = event.key === 'ArrowRight';
      const hasArrowLeftClicked = event.key === 'ArrowLeft';

      if (hasArrowRightClicked || hasArrowLeftClicked) {
        const currentIndex = findIndex(tabs, { id: selectedTab });
        const total = tabs.length;
        const maxIndex = total - 1;

        if (hasArrowRightClicked) {
          const nextIndex = currentIndex + 1;
          const newIndex = nextIndex > maxIndex ? 0 : nextIndex;
          handleChangeTab(tabs[newIndex]);
        }

        if (hasArrowLeftClicked) {
          const nextIndex = currentIndex - 1;
          const newIndex = nextIndex < 0 ? maxIndex : nextIndex;
          handleChangeTab(tabs[newIndex]);
        }
      }
    }

    const tabsRefCurrent = tabsRef.current;
    tabsRefCurrent.addEventListener('keyup', handOnKeyUp);

    return () => {
      tabsRefCurrent.removeEventListener('keyup', handOnKeyUp);
    };
  }, [tabs, selectedTab, handleChangeTab]);

  return (
    <ErrorBoundary section={COMPONENT_NAME.responsiveTabs}>
      <div ref={tabsRef} className={styles.tabs}>
        <div
          className={cx(styles.tabList, {
            [styles.totalTwo]: tabs.length === 2,
          })}
          role="tablist"
          aria-label={tabSummary}
        >
          {map(tabs, (tab) => {
            const isSelected = selectedTab === tab.id;

            return (
              <button
                role="tab"
                key={tab.id}
                id={`tab-${tab.id}`}
                className={cx(styles.tab, 'heading heading--5', {
                  [styles.selected]: isSelected,
                })}
                onClick={() => handleChangeTab(tab)}
                aria-selected={isSelected}
                aria-controls={tab.id}
                tabIndex={isSelected ? null : '-1'}
              >
                {tab.title}
              </button>
            );
          })}
        </div>
      </div>
    </ErrorBoundary>
  );
};

ResponsiveTabs.propTypes = {
  tabs: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      title: PropTypes.string.isRequired,
    }),
  ),
  analyticsMetadata: PropTypes.shape({}),
  tabSummary: PropTypes.string,
};

ResponsiveTabs.defaultProps = {
  tabs: [],
  analyticsMetadata: {},
  tabSummary: null,
};

export default ResponsiveTabs;
