import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import map from 'lodash/map';
import size from 'lodash/size';

import ResponsiveTabs from './ResponsiveTabs';
import store from '../../stores';
import { COMPONENT_NAME } from '../../utils/common';

const ELEMENT_NAME = COMPONENT_NAME.responsiveTabs;

function renderComponent(elements, hydrate) {
  map(elements, (element) => {
    const props = window.vffCoreWebsite[element.getAttribute(ELEMENT_NAME)];
    if (props) {
      const component = (
        <Provider store={store}>
          <ResponsiveTabs {...props} />
        </Provider>
      );

      if (hydrate) {
        ReactDOM.hydrate(component, element);
      } else {
        ReactDOM.render(component, element);
      }
    }
  });
}

export default {
  elementName: ELEMENT_NAME,
  bootstrap: (id = null, hydrate = true) => {
    const elements = document.querySelectorAll(`[${ELEMENT_NAME}${id ? `=${id}` : ''}]`);

    if (size(elements) > 0) {
      renderComponent(elements, hydrate);
    }
  },
};
