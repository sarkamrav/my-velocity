export function isElementInTab(element, tab) {
  const tabContentElement = document.getElementById(tab.id);

  return tabContentElement.contains(element);
}
