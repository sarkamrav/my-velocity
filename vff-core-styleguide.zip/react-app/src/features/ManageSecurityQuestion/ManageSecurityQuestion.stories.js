import React from 'react';
import MockAdapter from 'axios-mock-adapter';
import { Provider } from 'react-redux';
import ManageSecurityQuestion from './ManageSecurityQuestion';
import api from '../../utils/api';
import ManageSecurityQuestionData from './mocks/ManageSecurityQuestion.json';
import { configureStore } from '../../stores';
import userData from '../Navigation/mocks/user.mock.json';

export default {
  title: 'Manage Security Question ',
};

export const CreateSecurityQuestionForm = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });
  mockVff.onGet('/loyalty/v2/security-question').reply(200, {
    data: {},
  });
  mockVff.onPost('/loyalty/v2/security-question').reply(200, {
    data: {
      membershipId: '1200867830',
      questionId: 8,
      answer: 'ABC',
      question: 'What was your first pet name?',
    },
  });

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <ManageSecurityQuestion {...ManageSecurityQuestionData} />
      </Provider>
    </div>
  );
};

export const ChangeSecurityQuestionFormSuccess = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });
  mockVff.onGet('/loyalty/v2/security-question').reply(200, {
    data: {
      membershipId: '1200867830',
      questionId: 8,
      question: 'What was your first pet name?',
    },
  });
  mockVff.onPost('/loyalty/v2/security-question').reply(200, {
    data: {
      membershipId: '1200867830',
      questionId: 8,
      answer: 'ABC',
      question: 'What was your first pet name?',
    },
  });
  mockVff.onPut('/loyalty/v2/security-question').reply(200, {
    data: {
      membershipId: '0000053082',
      questionId: 8,
      question: 'What was your first pet name?',
      answer: 'DEP',
    },
  });
  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <ManageSecurityQuestion {...ManageSecurityQuestionData} />
      </Provider>
    </div>
  );
};

export const ChangeSecurityQuestionFormError = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });
  mockVff.onGet('/loyalty/v2/security-question').reply(200, {
    data: {
      membershipId: '1200867830',
      questionId: 8,
      answer: 'ABC',
      question: 'What was your first pet name?',
    },
  });
  mockVff.onPost('/loyalty/v2/security-question').reply(200, {
    data: {
      membershipId: '1200867830',
      questionId: 8,
      answer: 'ABC',
      question: 'What was your first pet name?',
    },
  });
  mockVff.onPut('/loyalty/v2/security-question').reply(500, {
    status: 500,
    title: 'Server Error',
    code: '37157',
    detail: 'An error occured while handling the request.',
  });
  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <ManageSecurityQuestion {...ManageSecurityQuestionData} />
      </Provider>
    </div>
  );
};
