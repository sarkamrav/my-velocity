import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import PropTypes from 'prop-types';
import includes from 'lodash/includes';
import get from 'lodash/get';
import size from 'lodash/size';
import find from 'lodash/find';
import reduce from 'lodash/reduce';
import omit from 'lodash/omit';
import { connect } from 'react-redux';
import styles from './ManageSecurityQuestion.css';
import * as normalize from '../../components/Form/normalizers';
import { normalizeFormField, validateFormField } from '../../components/Form/utils';
import * as validate from '../../components/Form/validators';
import Loading from '../../components/Loading/Loading';
import api from '../../utils/api';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME, scrollToRef } from '../../utils/common';
import SuccessMessageTile from '../../components/SuccessMessageTile/SuccessMessageTile';
import TopContentContainer, {
  contentContainerType,
} from '../../components/Form/containers/TopContentContainer/TopContentContainer';
import * as userData from '../../stores/utilities';
import ChangeSecurityQuestionForm from './ManageSecurityQuestionForm/ChangeSecurityQuestionForm';
import CreateSecurityQuestionForm from './ManageSecurityQuestionForm/CreateSecurityQuestionForm';
import UpdateSecurityQuestionForm from './ManageSecurityQuestionForm/UpdateSecurityQuestionForm';
import MessageTile, { messageTileTheme } from '../../components/MessageTile/MessageTile';
import FormContainer, { formContainerType } from '../../components/Form/containers/FormContainer/FormContainer';
import { securityQuestionOptions } from '../JoinPage/referenceData';

const formFieldNames = {
  newSecurityQuestion: 'newSecurityQuestion',
  currentSecurityAnswer: 'currentSecurityAnswer',
  newSecurityAnswer: 'newSecurityAnswer',
  createSecurityQuestion: 'createSecurityQuestion',
  createSecurityAnswer: 'createSecurityAnswer',
};
const initialValues = {
  [formFieldNames.newSecurityQuestion]: null,
  [formFieldNames.currentSecurityAnswer]: '',
  [formFieldNames.newSecurityAnswer]: '',
  [formFieldNames.createSecurityQuestion]: null,
  [formFieldNames.createSecurityAnswer]: '',
};

const fieldNormalizers = {
  currentSecurityAnswer: [normalize.maxLength(50)],
  newSecurityAnswer: [normalize.maxLength(50)],
  createSecurityAnswer: [normalize.maxLength(50)],
};

const ManageSecurityQuestionPage = ({
  user,
  currentSecurityQuestionDetails,
  newSecurityQuestionDetails,
  createSecurityQuestionDetails,
  errorMessages,
}) => {
  const [values, setValues] = useState(initialValues);
  const [currentstep, setcurrentstep] = useState(0);
  const [currentSecurityQuestion, setCurrentSecurityQuestion] = useState('');
  const [currentSecurityQuestionId, setCurrentSecurityQuestionId] = useState(null);
  const [changeSecurityQuestionPage, setChangeSecurityQuestionPage] = useState(false);
  const [createSecurityQuestionPage, setCreateSecurityQuestionPage] = useState(false);
  const [loading, setLoading] = useState(true);
  const [touchedFields, setTouchedFields] = useState([]);
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [confirmationMessage, setConfirmationMessage] = useState(null);

  const [systemError, setSystemError] = useState(false);

  const [pageError, setPageError] = useState(false);

  const [postError, setPostError] = useState(null);
  const errorMessageRef = useRef({});

  const fieldValidators = useMemo(
    () => ({
      [formFieldNames.newSecurityQuestion]: [validate.required('Please select a security question')],
      [formFieldNames.createSecurityQuestion]: [validate.required('Please select a security question')],
      [formFieldNames.currentSecurityAnswer]: [
        validate.required('Please provide an answer to your selected security question'),
        validate.securityAnswer(
          validate.acceptSingleCharacterSecurityAnswer({
            label: currentSecurityQuestion,
            value: currentSecurityQuestionId,
          }),
        ),
        validate.validSecurityAnswerCharacterCheck('Security answer contains invalid characters'),
      ],
      [formFieldNames.newSecurityAnswer]: [
        validate.required('Please provide an answer to your selected security question'),
        validate.securityAnswer(validate.acceptSingleCharacterSecurityAnswer(values.newSecurityQuestion)),
        validate.validSecurityAnswerCharacterCheck('Security answer contains invalid characters'),
      ],
      [formFieldNames.createSecurityAnswer]: [
        validate.required('Please provide an answer to your selected security question'),
        validate.securityAnswer(validate.acceptSingleCharacterSecurityAnswer(values.createSecurityQuestion)),
        validate.validSecurityAnswerCharacterCheck('Security answer contains invalid characters'),
      ],
    }),
    [values.createSecurityQuestion, values.newSecurityQuestion, currentSecurityQuestion, currentSecurityQuestionId],
  );

  const membershipId = userData.getLoyaltyMembershipID(user);
  const memberDataLoading = userData.getMemberDataLoading(user);
  const hasLoggedIn = userData.getHasLoggedIn(user);
  const memberDataLoadError = userData.getMemberDataLoadError(user);
  const memberDataLoaded = userData.getMemberDataLoaded(user);

  const getError = useCallback(
    (errorCode, errorFields, errorStatus) => {
      const lockedUserError = find(
        errorMessages.apiErrorMessages,
        (errorMessage) => errorMessage?.code === errorCode && errorCode === 4120 && errorStatus === 400,
      );
      const getCodeSpecificError = find(
        errorMessages.apiErrorMessages,
        (errorMessage) => errorMessage?.code === errorCode,
      );
      const getFieldSpecificError = reduce(
        errorFields,
        (result, errorField) =>
          result ||
          find(errorMessages.apiErrorMessages, {
            code: errorCode,
            errorFieldName: errorField.field,
          }),
        null,
      );

      // `modalErrorMessage` returns the filtered errorMessage accordingly
      const modalErrorMessage =
        lockedUserError || getFieldSpecificError || getCodeSpecificError || errorMessages?.defaultErrorMessage;
      setPostError(modalErrorMessage);
    },
    [errorMessages.apiErrorMessages, errorMessages?.defaultErrorMessage],
  );

  const getSecurityQuestion = useCallback(async () => {
    try {
      const response = await api.vffV2Api.get('/loyalty/v2/security-question');

      if (Object.keys(response?.data?.data).length === 0) {
        setLoading(false);
        setcurrentstep(2);
        setCreateSecurityQuestionPage(true);
        setConfirmationMessage(createSecurityQuestionDetails?.confirmationPage);
      } else {
        setCurrentSecurityQuestion(response?.data?.data?.question);
        setCurrentSecurityQuestionId(response?.data?.data?.questionId);
        setConfirmationMessage(newSecurityQuestionDetails?.confirmationPage);
        setLoading(false);
      }
    } catch (error) {
      const errorCode = get(error, 'response.data.code', '');
      const errorFields = get(error, 'response.data.errorFields', '');
      setSystemError(true);
      setLoading(false);
      setPageError(true);
      getError(errorCode, errorFields);
    }
  }, [getError, createSecurityQuestionDetails?.confirmationPage, newSecurityQuestionDetails?.confirmationPage]);

  useEffect(() => {
    if (memberDataLoaded && hasLoggedIn) {
      getSecurityQuestion();
    }
  }, [hasLoggedIn, memberDataLoaded, getSecurityQuestion]);

  // Validates field and returns an error message if it is invalid
  // eslint-disable-next-line arrow-body-style
  const validateField = useCallback(
    (fieldName, fieldValue) =>
      // Exit early if we aren't even showing this field
      // if (!shouldShowField(fieldName, values)) return '';
      validateFormField(fieldValue, fieldValidators[fieldName], values),
    [fieldValidators, values],
  );

  // Runs and applies field validation
  const runFieldValidation = useCallback(
    (fieldName, fieldValue) => {
      const error = validateField(fieldName, fieldValue);

      if (error) {
        setErrors((currentErrors) => ({
          ...currentErrors,
          [fieldName]: error,
        }));
      } else {
        setErrors((currentErrors) => omit(currentErrors, [fieldName]));
      }
    },
    [validateField],
  );

  // -- Handlers
  const handleFieldChange = useCallback(
    (fieldName) => (newValue) => {
      const normalizedValue = normalizeFormField(newValue, fieldNormalizers[fieldName]);

      // Set value
      setValues((previousValues) => ({
        ...previousValues,
        [fieldName]: normalizedValue,
      }));

      // Give immediate error feedback for fields that are already touched
      const isTouched = includes(touchedFields, fieldName);
      if (isTouched) {
        runFieldValidation(fieldName, normalizedValue);
      }
    },
    [runFieldValidation, touchedFields],
  );

  const handleFieldChangeEvent = useCallback(
    (event) => {
      handleFieldChange(event.target.name)(event.target.value);
    },
    [handleFieldChange],
  );

  const handleFieldBlur = useCallback(
    (fieldName) => () => {
      // Add to list of touched fields if required
      if (!includes(touchedFields, fieldName)) {
        setTouchedFields([...touchedFields, fieldName]);
      }

      // Set any errors
      runFieldValidation(fieldName, values[fieldName]);
    },
    [runFieldValidation, touchedFields, values],
  );

  const handleFieldBlurEvent = useCallback(
    (event) => {
      handleFieldBlur(event.target.name)();
    },
    [handleFieldBlur],
  );

  function checkSubmit() {
    if (currentstep === 0) {
      const validAnswerLength = validate.acceptSingleCharacterSecurityAnswer({
        label: currentSecurityQuestion,
        value: currentSecurityQuestionId,
      })
        ? 0
        : 2;

      if (values?.currentSecurityAnswer?.length > validAnswerLength && size(errors) === 0) return false;
      return true;
    }
    if (currentstep === 1) {
      const validAnswerLength = validate.acceptSingleCharacterSecurityAnswer(values.newSecurityQuestion) ? 0 : 2;

      if (values?.newSecurityAnswer?.length > validAnswerLength && values?.newSecurityQuestion && size(errors) === 0)
        return false;
      return true;
    }
    if (currentstep === 2) {
      const validAnswerLength = validate.acceptSingleCharacterSecurityAnswer(values.createSecurityQuestion) ? 0 : 2;
      if (
        values?.createSecurityAnswer?.length > validAnswerLength &&
        values?.createSecurityQuestion &&
        size(errors) === 0
      )
        return false;
      return true;
    }
    return true;
  }

  useEffect(() => {
    if (pageError && errorMessageRef.current) {
      scrollToRef(errorMessageRef);
    }
  }, [pageError]);

  const onSecurityQuestionFormSubmit = useCallback(
    async (event) => {
      event.preventDefault();
      const securityQuestionMemberApi = '/loyalty/v2/security-question';

      const requestBodyAnswer = {
        data: {
          membershipId,
          action: 'VALIDATE',
          questionId: currentSecurityQuestionId,
          answer: values.currentSecurityAnswer,
          question: currentSecurityQuestion,
        },
      };
      try {
        setSubmitting(true);
        setSubmitted(false);
        setPageError(false);
        const response = await api.vffV2Api.post(securityQuestionMemberApi, requestBodyAnswer);
        const savedAnswer = response?.data?.data?.answer;
        setSubmitting(false);
        setSubmitted(true);
        if (savedAnswer === values.currentSecurityAnswer) {
          setChangeSecurityQuestionPage(true);
          setcurrentstep(1);
          setPageError(false);
        } else {
          setPageError(true);
          getError();
        }
      } catch (error) {
        const errorCode = get(error, 'response.data.code', '');
        const errorFields = get(error, 'response.data.errorFields', '');
        setSubmitting(false);
        setPageError(true);
        getError(errorCode, errorFields);
      }
    },
    [currentSecurityQuestion, currentSecurityQuestionId, getError, membershipId, values],
  );

  const onUpdatesecurityQuestionFormSubmit = useCallback(
    async (event) => {
      event.preventDefault();
      const updateSecurityQuestionMemberApi = '/loyalty/v2/security-question';

      const requestBodyAnswer = {
        data: {
          membershipId,
          ...(createSecurityQuestionPage
            ? {
                action: 'CREATE',
                question: values.createSecurityQuestion?.label,
                questionId: values.createSecurityQuestion?.value,
                answer: values.createSecurityAnswer,
              }
            : {
                question: values.newSecurityQuestion?.label,
                questionId: values.newSecurityQuestion?.value,
                answer: values.newSecurityAnswer,
              }),
        },
      };
      try {
        setSubmitting(true);
        setSubmitted(false);
        setPageError(false);
        if (createSecurityQuestionPage) {
          await api.vffV2Api.post(updateSecurityQuestionMemberApi, requestBodyAnswer);
        } else {
          await api.vffV2Api.put(updateSecurityQuestionMemberApi, requestBodyAnswer);
        }
        setSubmitting(false);
        setSubmitted(true);
        setIsSuccess(true);
      } catch (error) {
        const errorCode = get(error, 'response.data.code', '');
        const errorFields = get(error, 'response.data.errorFields', '');
        setSubmitting(false);
        setPageError(true);
        getError(errorCode, errorFields);
      }
    },
    [getError, membershipId, values, createSecurityQuestionPage],
  );
  return (
    <ErrorBoundary section={COMPONENT_NAME.changeSecurityQuestion}>
      <div className={styles.container}>
        {!hasLoggedIn && memberDataLoadError && (
          <div className={styles.errorMessage}>
            <MessageTile theme="error" description="Sorry, we're having issues with our system." />
          </div>
        )}

        {((!hasLoggedIn && !memberDataLoadError && memberDataLoading) || (hasLoggedIn && loading)) && (
          <Loading containerClassName={styles.loading} />
        )}

        {memberDataLoaded && !loading && (
          <>
            <TopContentContainer theme={contentContainerType.typeB}>
              {pageError && (
                <MessageTile
                  theme={messageTileTheme.error}
                  ref={errorMessageRef}
                  description={postError?.description}
                />
              )}
              {isSuccess && submitted && (
                <SuccessMessageTile
                  className={styles.successMessageTileWrapper}
                  iconPath={confirmationMessage?.iconUrl}
                  title={confirmationMessage.title}
                  content={confirmationMessage.description}
                  ctaContainer={confirmationMessage.ctaContainer}
                />
              )}
            </TopContentContainer>

            {hasLoggedIn && !systemError && !loading && !isSuccess && (
              <div className={styles.formWrapper} aria-live="polite">
                <FormContainer type={formContainerType.typeB}>
                  {!changeSecurityQuestionPage &&
                    !createSecurityQuestionPage &&
                    !loading &&
                    !isSuccess &&
                    !systemError && (
                      <ChangeSecurityQuestionForm
                        currentSecurityQuestionDetails={currentSecurityQuestionDetails}
                        handleFieldChangeEvent={handleFieldChangeEvent}
                        handleFieldBlurEvent={handleFieldBlurEvent}
                        values={values}
                        errors={errors}
                        submitting={submitting}
                        securityQuestion={currentSecurityQuestion}
                        checkSubmit={checkSubmit() || submitting}
                        formFieldNames={formFieldNames}
                        onSecurityQuestionFormSubmit={onSecurityQuestionFormSubmit}
                      />
                    )}

                  {changeSecurityQuestionPage &&
                    !createSecurityQuestionPage &&
                    !loading &&
                    !isSuccess &&
                    !systemError && (
                      <UpdateSecurityQuestionForm
                        newSecurityQuestionDetails={newSecurityQuestionDetails}
                        handleFieldChangeEvent={handleFieldChangeEvent}
                        handleFieldBlurEvent={handleFieldBlurEvent}
                        handleFieldChange={(data) => handleFieldChange(data)}
                        handleFieldBlur={(data) => handleFieldBlur(data)}
                        values={values}
                        errors={errors}
                        securityQuestionOptions={securityQuestionOptions}
                        submitting={submitting}
                        checkSubmit={checkSubmit() || submitting}
                        formFieldNames={formFieldNames}
                        onSecurityQuestionFormSubmit={onUpdatesecurityQuestionFormSubmit}
                      />
                    )}

                  {createSecurityQuestionPage &&
                    !changeSecurityQuestionPage &&
                    !loading &&
                    !isSuccess &&
                    !systemError && (
                      <CreateSecurityQuestionForm
                        createSecurityQuestionDetails={createSecurityQuestionDetails}
                        handleFieldChangeEvent={handleFieldChangeEvent}
                        handleFieldBlurEvent={handleFieldBlurEvent}
                        handleFieldChange={(data) => handleFieldChange(data)}
                        handleFieldBlur={(data) => handleFieldBlur(data)}
                        values={values}
                        errors={errors}
                        securityQuestionOptions={securityQuestionOptions}
                        submitting={submitting}
                        checkSubmit={checkSubmit() || submitting}
                        formFieldNames={formFieldNames}
                        onSecurityQuestionFormSubmit={onUpdatesecurityQuestionFormSubmit}
                      />
                    )}
                </FormContainer>
              </div>
            )}
          </>
        )}
      </div>
    </ErrorBoundary>
  );
};

ManageSecurityQuestionPage.propTypes = {
  user: PropTypes.shape({}).isRequired,
  errorMessages: PropTypes.shape({
    defaultErrorMessage: PropTypes.shape({}).isRequired,
    apiErrorMessages: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
  }).isRequired,
  newSecurityQuestionDetails: PropTypes.shape({
    title: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
    ctaContainer: PropTypes.shape({
      ctaTitle: PropTypes.string,
      ctaOpenInNewTab: PropTypes.bool,
      ctaStyle: PropTypes.string,
      ctaType: PropTypes.string,
      ctaAsLink: PropTypes.bool,
      ctaLabel: PropTypes.string,
    }),
    confirmationPage: PropTypes.shape({
      title: PropTypes.string.isRequired,
      description: PropTypes.string.isRequired,
      ctaContainer: PropTypes.shape({
        ctaUrl: PropTypes.string,
        ctaTitle: PropTypes.string,
        ctaOpenInNewTab: PropTypes.bool,
        ctaStyle: PropTypes.string,
        ctaAsLink: PropTypes.bool,
        ctaLabel: PropTypes.string,
        ctaImage: PropTypes.string,
      }),
    }),
  }),
  currentSecurityQuestionDetails: PropTypes.shape({
    title: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
    ctaContainer: PropTypes.shape({
      ctaTitle: PropTypes.string,
      ctaOpenInNewTab: PropTypes.bool,
      ctaStyle: PropTypes.string,
      ctaType: PropTypes.string,
      ctaAsLink: PropTypes.bool,
      ctaLabel: PropTypes.string,
    }),
  }),
  createSecurityQuestionDetails: PropTypes.shape({
    title: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
    ctaContainer: PropTypes.shape({
      ctaTitle: PropTypes.string,
      ctaOpenInNewTab: PropTypes.bool,
      ctaStyle: PropTypes.string,
      ctaType: PropTypes.string,
      ctaAsLink: PropTypes.bool,
      ctaLabel: PropTypes.string,
    }),
    confirmationPage: PropTypes.shape({
      title: PropTypes.string.isRequired,
      description: PropTypes.string.isRequired,
      ctaContainer: PropTypes.shape({
        ctaUrl: PropTypes.string,
        ctaTitle: PropTypes.string,
        ctaOpenInNewTab: PropTypes.bool,
        ctaStyle: PropTypes.string,
        ctaAsLink: PropTypes.bool,
        ctaLabel: PropTypes.string,
        ctaImage: PropTypes.string,
      }),
    }),
  }),
};

ManageSecurityQuestionPage.defaultProps = {
  newSecurityQuestionDetails: {
    ctaContainer: {},
    confirmationPage: {
      ctaContainer: {},
    },
  },
  currentSecurityQuestionDetails: {
    ctaContainer: {},
    confirmationPage: {
      ctaContainer: {},
    },
  },
  createSecurityQuestionDetails: {
    ctaContainer: {},
    confirmationPage: {
      ctaContainer: {},
    },
  },
};

export default connect((state) => ({
  user: state.user,
}))(ManageSecurityQuestionPage);
