import styles from '@sambego/storybook-styles';
import React from 'react';
import { Provider } from 'react-redux';
import store from '../../stores';
import Notification from './Notification';
import notificationMock from './mocks/notification.mock';
import { NOTIFICATION_TYPE } from './constants';

export default {
  title: 'Notification',

  decorators: [
    styles({
      position: 'fixed',
      bottom: 0,
      left: 0,
      right: 0,
    }),
  ],
};

export const MarketingAlert = () => (
  <Provider store={store}>
    <Notification {...notificationMock} />
  </Provider>
);

export const ImportantMessage = () => (
  <Provider store={store}>
    <Notification
      {...notificationMock}
      notificationType={NOTIFICATION_TYPE.importantMessage}
      ctaContainer={{
        ...notificationMock.ctaContainer,
        ctaStyle: 'tertiary-amber',
      }}
    />
  </Provider>
);

export const ImportantMessageLight = () => (
  <Provider store={store}>
    <Notification
      {...notificationMock}
      notificationType={NOTIFICATION_TYPE.importantMessageLight}
      ctaContainer={{
        ...notificationMock.ctaContainer,
        ctaStyle: 'tertiary-amber',
      }}
    />
  </Provider>
);

export const SystemAlert = () => (
  <Provider store={store}>
    <Notification
      {...notificationMock}
      notificationType={NOTIFICATION_TYPE.systemAlert}
      ctaContainer={{
        ...notificationMock.ctaContainer,
        ctaStyle: 'tertiary-red',
      }}
    />
  </Provider>
);

export const SystemAlertLight = () => (
  <Provider store={store}>
    <Notification
      {...notificationMock}
      notificationType={NOTIFICATION_TYPE.systemAlertLight}
      ctaContainer={{
        ...notificationMock.ctaContainer,
        ctaStyle: 'tertiary-black',
      }}
    />
  </Provider>
);

export const NoCta = () => (
  <Provider store={store}>
    <Notification {...notificationMock} notificationType={NOTIFICATION_TYPE.systemAlertLight} ctaContainer={null} />
  </Provider>
);

export const NoReadMore = () => (
  <Provider store={store}>
    <Notification
      {...notificationMock}
      notificationType={NOTIFICATION_TYPE.systemAlertLight}
      description={null}
      ctaContainer={{
        ...notificationMock.ctaContainer,
        ctaStyle: 'primary',
      }}
    />
  </Provider>
);
