import styles from '@sambego/storybook-styles';
import React from 'react';
import { Provider } from 'react-redux';
import store from '../../stores';
import Notification from './Notification';
import notificationMock from './mocks/notification.mock';

function renderStyle(ctaStyle) {
  const ctaContainer = {
    ...notificationMock.ctaContainer,
    ctaStyle,
  };

  return (
    <Provider store={store}>
      <Notification {...notificationMock} ctaContainer={ctaContainer} />
    </Provider>
  );
}

export default {
  title: 'Notification/CTA Styles',

  decorators: [
    styles({
      position: 'fixed',
      bottom: 0,
      left: 0,
      right: 0,
    }),
  ],
};

export const Primary = () => renderStyle('primary');

Primary.storyName = 'primary';

export const PrimaryTransparent = () => renderStyle('primary-transparent');

PrimaryTransparent.storyName = 'primary-transparent';

export const Secondary = () => renderStyle('secondary');

Secondary.storyName = 'secondary';

export const SecondaryTransparent = () => renderStyle('secondary-transparent');

SecondaryTransparent.storyName = 'secondary-transparent';

export const Tertiary = () => renderStyle('tertiary');

Tertiary.storyName = 'tertiary';

export const TertiaryTransparent = () => renderStyle('tertiary-transparent');

export const TertiaryRed = () => renderStyle('tertiary-red');

export const TertiaryAmber = () => renderStyle('tertiary-amber');

export const TertiaryBlack = () => renderStyle('tertiary-black');

TertiaryTransparent.storyName = 'tertiary-transparent';

export const RedLink = () => renderStyle('red-link');

RedLink.storyName = 'red-link';

export const BlackLink = () => renderStyle('black-link');

BlackLink.storyName = 'black-link';

export const PurpleLink = () => renderStyle('purple-link');

PurpleLink.storyName = 'purple-link';
