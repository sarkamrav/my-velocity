import React, { useEffect, useState, useCallback, useMemo } from 'react';
import PropTypes from 'prop-types';
import join from 'lodash/join';
import noop from 'lodash/noop';
import cx from 'classnames';

import Collapse from '../../components/Collapse/Collapse';
import analyticsSend from '../../utils/analytics';
import { getCookie, setCookie } from '../../utils/cookies';
import { NOTIFICATION_TYPE } from './constants';
import CTAButton from './components/CTAButton/CTAButton';
import HideButton, { HIDE_BUTTON_DISPLAY_MODE } from './components/HideButton/HideButton';
import MoreContent, { MORE_CONTENT_DISPLAY_MODE } from './components/MoreContent/MoreContent';
import MoreContentToggleButton, {
  TOGGLE_BUTTON_DISPLAY_MODE,
} from '../../components/MoreContentToggleButton/MoreContentToggleButton';
import NotificationActions, {
  NOTIFICATION_ACTIONS_DISPLAY_MODE,
} from './components/NotificationActions/NotificationActions';
import NotificationIcon from './components/NotificationIcon/NotificationIcon';
import Title, { TITLE_DISPLAY_MODE } from './components/Title/Title';
import { positionWebChatButton } from '../Navigation/WebChat/utils';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME } from '../../utils/common';

import styles from './Notification.css';

const Notification = ({
  notificationId,
  iconPath,
  title,
  description,
  hideLabel,
  readLessLabel,
  readMoreLabel,
  ctaContainer,
  analyticsMetadata,
  onHide,
  notificationType,
}) => {
  const hasBeenClosed = getCookie(notificationId) === 'true';
  const [isShowingNotification, setIsShowingNotification] = useState(!hasBeenClosed);
  const [isShowingMoreContent, setIsShowingMoreContent] = useState(false);

  const hasCTA = ctaContainer && ctaContainer.ctaLabel;
  const commonAnalyticsData = useMemo(
    () => ({
      alertNotificationType: notificationType,
      alertNotificationMessage: title,
      eventCategory: 'alert-notification',
      eventLocation: 'notification',
    }),
    [notificationType, title],
  );

  const analyticsData = {
    ...commonAnalyticsData,
    ...(window.vffCoreWebsite[analyticsMetadata] || {}),
  };

  const moreContentSectionId = `${notificationId}_more_content`;

  const handleShowMoreButtonClick = useCallback(() => {
    setIsShowingMoreContent((currentVal) => !currentVal);

    analyticsSend({
      ...commonAnalyticsData,
      eventName: isShowingMoreContent ? 'alert-notification-info-collapse' : 'alert-notification-info-expand',
    });
  }, [commonAnalyticsData, isShowingMoreContent]);

  useEffect(() => {
    positionWebChatButton();
  }, [isShowingMoreContent, isShowingNotification]);

  const handleCTAButtonClick = useCallback(
    (event) => {
      const analyticsElementName = event.target.getAttribute('title');

      analyticsSend({
        ...commonAnalyticsData,
        eventName: 'alert-notification-link',
        hyperlinkElementClass: join(event.target.classList, ' '),
        hyperlinkElementDestination: ctaContainer.ctaUrl,
        hyperlinkElementName: analyticsElementName,
        eventElementName: analyticsElementName,
        hyperlinkElementText: ctaContainer.ctaLabel,
        eventElementText: ctaContainer.ctaLabel,
      });
    },
    [commonAnalyticsData, ctaContainer.ctaLabel, ctaContainer.ctaUrl],
  );

  const handleHideClick = useCallback(() => {
    setIsShowingNotification(false);

    onHide();

    analyticsSend({
      ...commonAnalyticsData,
      eventName: 'alert-notification-dismiss',
    });

    setCookie(notificationId, true, null, true);
  }, [commonAnalyticsData, notificationId, onHide]);

  const isLightMode =
    notificationType === NOTIFICATION_TYPE.systemAlertLight ||
    notificationType === NOTIFICATION_TYPE.importantMessageLight;

  return (
    <ErrorBoundary section={COMPONENT_NAME.notification}>
      {isShowingNotification && (
        <div
          className={cx(styles.container, {
            [styles.systemAlert]: notificationType === NOTIFICATION_TYPE.systemAlert,
            [styles.systemAlertLight]: notificationType === NOTIFICATION_TYPE.systemAlertLight,
            [styles.importantMessage]: notificationType === NOTIFICATION_TYPE.importantMessage,
            [styles.importantMessageLight]: notificationType === NOTIFICATION_TYPE.importantMessageLight,
          })}
          role="region"
          aria-label="Notification banner"
        >
          <div className={styles.inner}>
            <div className={styles.headline}>
              <NotificationIcon className={styles.notificationIcon} iconPath={iconPath} />

              <Title
                displayMode={isLightMode ? TITLE_DISPLAY_MODE.dark : null}
                title={title}
                analyticsData={analyticsData}
              />
            </div>

            <NotificationActions displayMode={isLightMode ? NOTIFICATION_ACTIONS_DISPLAY_MODE.dark : null}>
              {description && (
                <MoreContentToggleButton
                  displayMode={isLightMode ? TOGGLE_BUTTON_DISPLAY_MODE.dark : null}
                  isShowingMore={isShowingMoreContent}
                  readLessLabel={readLessLabel}
                  readMoreLabel={readMoreLabel}
                  aria-controls={moreContentSectionId}
                  onClick={handleShowMoreButtonClick}
                />
              )}

              {hasCTA && <CTAButton ctaContainer={ctaContainer} onClick={handleCTAButtonClick} />}
            </NotificationActions>

            <HideButton
              displayMode={isLightMode ? HIDE_BUTTON_DISPLAY_MODE.dark : null}
              label={hideLabel}
              onClick={handleHideClick}
            />

            {description && (
              <Collapse
                isOpen={isShowingMoreContent}
                id={moreContentSectionId}
                role="region"
                aria-live="polite"
                aria-label={readMoreLabel}
              >
                <MoreContent
                  content={description}
                  analyticsData={analyticsData}
                  displayMode={isLightMode ? MORE_CONTENT_DISPLAY_MODE.dark : null}
                />
              </Collapse>
            )}
          </div>
        </div>
      )}
    </ErrorBoundary>
  );
};

Notification.propTypes = {
  notificationId: PropTypes.string.isRequired,
  iconPath: PropTypes.string,
  title: PropTypes.string,
  description: PropTypes.string,
  readLessLabel: PropTypes.string.isRequired,
  readMoreLabel: PropTypes.string.isRequired,
  hideLabel: PropTypes.string.isRequired,
  ctaContainer: PropTypes.shape({
    ctaUrl: PropTypes.string,
    ctaLabel: PropTypes.string,
  }),
  analyticsMetadata: PropTypes.shape({}),
  onHide: PropTypes.func,
  notificationType: PropTypes.oneOf([
    NOTIFICATION_TYPE.marketingAlert,
    NOTIFICATION_TYPE.systemAlert,
    NOTIFICATION_TYPE.importantMessage,
    NOTIFICATION_TYPE.systemAlertLight,
    NOTIFICATION_TYPE.importantMessageLight,
  ]),
};

Notification.defaultProps = {
  iconPath: null,
  title: null,
  description: null,
  ctaContainer: null,
  analyticsMetadata: {},
  onHide: noop,
  notificationType: NOTIFICATION_TYPE.marketingAlert,
};

export default Notification;
