export const NOTIFICATION_TYPE = {
  marketingAlert: 'marketing-alert',
  importantMessage: 'important-message',
  importantMessageLight: 'important-message-light',
  systemAlert: 'system-alert',
  systemAlertLight: 'system-alert-light',
};
