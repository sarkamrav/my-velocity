import React, { useState, useEffect, useRef, useCallback } from 'react';
import PropTypes from 'prop-types';
import find from 'lodash/find';
import reduce from 'lodash/reduce';
import map from 'lodash/map';
import size from 'lodash/size';
import cx from 'classnames';
import Icon from '../../components/Icon/Icon';
import analyticsSend from '../../utils/analytics';
import { getUniqueKey, isPassiveEventListenerSupported } from '../../utils/common';
import styles from './SubNavigation.css';
import A from '../../components/Button/A';

const commonAnalyticsData = {
  eventCategory: 'navigation',
  eventLocation: 'sub-nav',
};
const SubNavigation = ({ navigationItems, subNavQuickLinks, className }) => {
  const [navOpen, setNavOpen] = useState(false);
  const [openSubNav, setOpenSubNav] = useState('');
  const [isPassiveListenerSupported] = useState(isPassiveEventListenerSupported());
  const navTimeoutRef = useRef();

  function getActiveMenuItem() {
    function getPagePath(aemPagePath) {
      const [, pathPath] = aemPagePath.split('home');

      return pathPath;
    }

    const navItem = find(
      navigationItems,
      (navigationItem) => getPagePath(navigationItem.pagePath) === `/my-velocity${window.location.pathname}`, // /my-velocity is added to match AEM pagePath
    );

    if (navItem) {
      return navItem;
    }

    return reduce(
      navigationItems,
      (result, navigationItem) => {
        if (navigationItem && navigationItem.childPages) {
          const subNavItem = find(
            navigationItem.childPages,
            (childPage) => getPagePath(childPage.pagePath) === window.location.pathname,
          );

          return subNavItem ? navigationItem : result;
        }

        return result;
      },
      {},
    );
  }

  const activeMenuItem = getActiveMenuItem();

  function toggleNav() {
    setOpenSubNav('');
    setNavOpen((prevState) => !prevState);
  }

  function toggleSubNav(e, pagePath) {
    setOpenSubNav((prevState) => {
      const navItemUniqueKey = getUniqueKey(pagePath);
      return prevState === navItemUniqueKey ? '' : navItemUniqueKey;
    });
  }

  function closeNav() {
    setOpenSubNav('');
    setNavOpen(false);
  }

  const handScrollOnMobileView = useCallback(() => {
    closeNav();
  }, []);

  function handleScrollOnDesktopView() {
    setOpenSubNav('');
  }

  function onNavBlurHandler() {
    navTimeoutRef.current = setTimeout(() => {
      closeNav();
    }, 100);
  }

  function onNavFocusHandler() {
    clearTimeout(navTimeoutRef.current);
  }

  useEffect(() => () => clearTimeout(navTimeoutRef.current), []);

  useEffect(() => {
    if (navOpen) {
      analyticsSend({
        ...commonAnalyticsData,
        eventName: 'sub-nav-expand',
      });

      window.addEventListener('scroll', handScrollOnMobileView, isPassiveListenerSupported ? { passive: true } : false);
    } else {
      window.removeEventListener(
        'scroll',
        handScrollOnMobileView,
        isPassiveListenerSupported ? { passive: true } : false,
      );
    }

    return () => {
      window.removeEventListener(
        'scroll',
        handScrollOnMobileView,
        isPassiveListenerSupported ? { passive: true } : false,
      );
    };
  }, [handScrollOnMobileView, isPassiveListenerSupported, navOpen]);

  useEffect(() => {
    if (openSubNav) {
      analyticsSend({
        ...commonAnalyticsData,
        eventName: 'sub-nav-header',
        navigationLevel: 1,
        navigationParentElement: '',
        navigationElementName: openSubNav,
      });

      window.addEventListener(
        'scroll',
        handleScrollOnDesktopView,
        isPassiveListenerSupported ? { passive: true } : false,
      );
    } else {
      window.removeEventListener(
        'scroll',
        handleScrollOnDesktopView,
        isPassiveListenerSupported ? { passive: true } : false,
      );
    }

    return () => {
      window.removeEventListener(
        'scroll',
        handleScrollOnDesktopView,
        isPassiveListenerSupported ? { passive: true } : false,
      );
    };
  }, [isPassiveListenerSupported, openSubNav]);

  return (
    <nav
      className={cx(styles.container, className, {
        [styles.navActive]: navOpen,
      })}
      onBlur={onNavBlurHandler}
      onFocus={onNavFocusHandler}
    >
      <button className={styles.openNavButton} onClick={toggleNav}>
        {navOpen ? 'Please select' : activeMenuItem.title || 'My Velocity'}
        <Icon className={styles.openNavButtonIcon} name="ChevronNew" size="extra-small" />
      </button>
      <div
        className={cx(styles.navContainer, {
          [styles.noCta]: !subNavQuickLinks || !subNavQuickLinks.length,
        })}
      >
        <div className={styles.innerNavContainer}>
          <ul className={styles.nav}>
            {map(navigationItems, (item) => (
              <li
                className={cx(styles.navItem, {
                  [styles.navItemActive]: openSubNav === getUniqueKey(item.pagePath),
                  [styles.currentPage]: activeMenuItem.pagePath === item.pagePath && !openSubNav,
                })}
                key={item.pagePath}
              >
                {size(item.childPages) > 0 ? (
                  <>
                    <button onClick={(e) => toggleSubNav(e, item.pagePath)} className={styles.navItemButton}>
                      <span className={styles.navItemButtonTitle}>
                        {item.iconUrl ? <img src={item.iconUrl} className={styles.navItemIcon} alt="" /> : null}
                        {item.title}
                      </span>
                      <Icon className={styles.navItemButtonIcon} name="ChevronNew" size="extra-small" />
                    </button>

                    <div className={styles.subNavContainer}>
                      <ul className={styles.subNav}>
                        {map(item.childPages, (childItem) => (
                          <li className={styles.subNavItem} key={childItem.pagePath}>
                            <a
                              href={childItem.href}
                              className={styles.subNavItemLink}
                              analytics-metadata={JSON.stringify({
                                ...commonAnalyticsData,
                                eventName: 'sub-navigation-interaction',
                                navigationElementDestination: childItem.href,
                                navigationLevel: 2,
                                navigationElementName: getUniqueKey(childItem.pagePath),
                                navigationParentElement: getUniqueKey(item.pagePath),
                              })}
                            >
                              {childItem.title}
                            </a>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </>
                ) : (
                  <a
                    className={styles.navItemLink}
                    href={item.href}
                    analytics-metadata={JSON.stringify({
                      ...commonAnalyticsData,
                      eventName: 'sub-navigation-interaction',
                      navigationElementDestination: item.href,
                      navigationLevel: 1,
                      navigationParentElement: '',
                      navigationElementName: getUniqueKey(item.pagePath),
                    })}
                  >
                    <span className={styles.navItemButtonTitle}>
                      {item.iconUrl ? <img src={item.iconUrl} className={styles.navItemIcon} alt="" /> : null}
                      {item.title}
                    </span>
                  </a>
                )}
              </li>
            ))}
          </ul>

          {subNavQuickLinks && subNavQuickLinks.length > 0 ? (
            <div className={styles.subNavQuickLinksContainer}>
              {map(subNavQuickLinks, (subNavQuickLink) => (
                <A
                  key={subNavQuickLink.ctaLabel}
                  href={subNavQuickLink.ctaUrl}
                  className={styles.subNavQuickLink}
                  title={`${subNavQuickLink.ctaTitle} link`}
                  target={subNavQuickLink.ctaOpenInNewTab ? '_blank' : '_self'}
                  buttonType={subNavQuickLink.ctaStyle}
                  ctaAsLink={subNavQuickLink.ctaAsLink}
                >
                  {subNavQuickLink.ctaLabel}
                </A>
              ))}
            </div>
          ) : null}
        </div>
      </div>
    </nav>
  );
};

SubNavigation.propTypes = {
  navigationItems: PropTypes.arrayOf(PropTypes.shape({})),
  subNavQuickLinks: PropTypes.arrayOf(PropTypes.shape({})),
  className: PropTypes.string,
};

SubNavigation.defaultProps = {
  navigationItems: [],
  subNavQuickLinks: [],
  className: '',
};

export default SubNavigation;
