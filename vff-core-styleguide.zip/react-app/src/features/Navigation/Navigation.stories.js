import React from 'react';
import { Provider } from 'react-redux';
import { configureStore } from '../../stores';
import { COOKIE_NOTICE_LOCAL_STORAGE_KEY } from '../CookieNotice/constants';
import cookieNoticeMock from '../CookieNotice/mocks/cookieNotice.mock.json';
import notificationMock from './mocks/notification.mock.json';
import NavigationMock from './mocks/Navigation.mock.json';
import userData from './mocks/user.mock.json';
import Navigation from './Navigation';

export default {
  title: 'Navigation',
};

export const Loading = () => (
  <Provider
    store={configureStore({
      user: {
        memberDataLoaded: false,
        memberDataLoading: true,
        authenticated: false,
      },
    })}
  >
    <Navigation {...NavigationMock} />
  </Provider>
);

export const NonAuthenticated = () => (
  <Provider
    store={configureStore({
      user: {
        memberDataLoaded: true,
        memberDataLoading: false,
        authenticated: false,
      },
    })}
  >
    <Navigation {...NavigationMock} />
  </Provider>
);

NonAuthenticated.storyName = 'Non-authenticated';

export const Authenticated = () => {
  localStorage.removeItem(COOKIE_NOTICE_LOCAL_STORAGE_KEY);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <Navigation {...NavigationMock} notification={notificationMock} cookieNotice={cookieNoticeMock} />
    </Provider>
  );
};

export const ApiFailed = () => (
  <Provider
    store={configureStore({
      user: {
        memberDataLoaded: false,
        memberDataLoading: false,
        memberDataLoadError: true,
        authenticated: false,
      },
    })}
  >
    <Navigation {...NavigationMock} />
  </Provider>
);

ApiFailed.storyName = 'API Failed';

const UpdatedNavigationMock = {
  ...NavigationMock,
  loginButton: {
    ...NavigationMock.loginButton,
    ctaUrl: 'https://google.com',
  },
};

export const VaBf = () => (
  <Provider
    store={configureStore({
      user: {
        memberDataLoaded: true,
        memberDataLoading: false,
        authenticated: false,
      },
    })}
  >
    <Navigation {...UpdatedNavigationMock} />
  </Provider>
);

VaBf.storyName = 'VABF';
