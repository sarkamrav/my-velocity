/* eslint-disable react-hooks/exhaustive-deps */
import cx from 'classnames';
import get from 'lodash/get';
import isEmpty from 'lodash/isEmpty';
import map from 'lodash/map';
import debounce from 'lodash/debounce';
import PropTypes from 'prop-types';
import React, { useEffect, useRef, useState } from 'react';
import { connect } from 'react-redux';

import Icon from '../../components/Icon/Icon';
import useServerRendering from '../../hooks/useServerRendering';
import Logo from '../../images/vff-logo.svg';
import analyticsSend from '../../utils/analytics';
import { COMPONENT_NAME, getNavigationHeight, getUniqueKey } from '../../utils/common';
import CookieNotice from '../CookieNotice/CookieNotice';
import Notification from '../Notification/Notification';
import SearchBar from '../Search/SearchBar/SearchBar';
import JoinNowLink from './LoginModule/JoinNowLink/JoinNowLink';
import LoginModule from './LoginModule/LoginModule';
import MyVelocityLink from './LoginModule/MyVelocityLink/MyVelocityLink';
import SubNavigation from './SubNavigation';
import WebChat from './WebChat/WebChat';
import * as userData from '../../stores/utilities';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import HintLabel from '../../components/HintLabel/HintLabel';
import VisuallyHidden from '../../components/VisuallyHidden/VisuallyHidden';
import syncText from '../../utils/syncText';

import styles from './Navigation.css';

const Navigation = ({
  user,
  logo,
  logoUrl,
  navigationItems,
  subNavigation,
  subNavQuickLinks,
  search,
  loginModule,
  analyticsMetadata,
  defaultErrorMessage,
  joinButton,
  loginButton,
  notification,
  cookieNotice,
}) => {
  const analyticsMetadataKey = analyticsMetadata['analytics-metadata'];
  const [analyticsData, setAnalyticsData] = useState(analyticsMetadataKey);
  const containerRef = useRef(null);
  const topNavContainerRef = useRef(null);
  const headerRef = useRef(null);
  const hamburgerButtonRef = useRef(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [openTierOneNav, setOpenTierOneNav] = useState('');
  const [openTierOneNavDesktop, setOpenTierOneNavDesktop] = useState('');
  const [openTierTwoNav, setOpenTierTwoNav] = useState('');
  const [showSearchOnMobile, setShowSearchOnMobile] = useState(false);
  const [desktopDropdownLeftPosition, setDesktopDropdownLeftPosition] = useState(0);
  const [dropdownContainerHeight, setDropdownContainerHeight] = useState({});
  const [hideError, setHideError] = useState(false);
  const { rendered } = useServerRendering();
  const subNavigationItems = get(subNavigation, 'subNavigationItems', []);
  const hasLoggedIn = userData.getHasLoggedIn(user);
  const isLoginModuleVisible = !loginModule.hidden;

  const refIndex = {};
  const refs = [];

  map(navigationItems, (tierOneNavItem) => {
    if (tierOneNavItem.childPages && tierOneNavItem.childPages.length > 0) {
      const length = refs.push(React.createRef());
      refIndex[getUniqueKey(tierOneNavItem.pagePath)] = length - 1;
    }

    if (tierOneNavItem.resources && tierOneNavItem.resources.length > 0) {
      const length = refs.push(React.createRef());
      refIndex[getUniqueKey(`${tierOneNavItem.pagePath}-resources`)] = length - 1;
    }

    map(tierOneNavItem.childPages, (tierTwoNavItem) => {
      if (tierTwoNavItem.childPages && tierTwoNavItem.childPages.length > 0) {
        const length = refs.push(React.createRef());
        refIndex[getUniqueKey(tierTwoNavItem.pagePath)] = length - 1;
      }
    });
  });

  const allRefs = useRef(refs);

  function isDesktopView() {
    return window.matchMedia('(min-width: 1200px)').matches;
  }

  function alignDropdownHeightOnDesktop() {
    let allContainerHeights = {};

    map(navigationItems, (tierOneNavItem) => {
      let height = 0;

      if (tierOneNavItem.childPages && tierOneNavItem.childPages.length > 0) {
        height = Math.max(
          allRefs.current[refIndex[getUniqueKey(tierOneNavItem.pagePath)]].current.offsetHeight,
          height,
        );
      }

      if (tierOneNavItem.resources && tierOneNavItem.resources.length > 0) {
        height = Math.max(
          allRefs.current[refIndex[getUniqueKey(`${tierOneNavItem.pagePath}-resources`)]].current.offsetHeight,
          height,
        );
      }

      map(tierOneNavItem.childPages, (tierTwoNavItem) => {
        if (tierTwoNavItem.childPages && tierTwoNavItem.childPages.length > 0) {
          height = Math.max(
            allRefs.current[refIndex[getUniqueKey(tierTwoNavItem.pagePath)]].current.offsetHeight,
            height,
          );
        }
      });

      allContainerHeights = {
        ...allContainerHeights,
        [getUniqueKey(tierOneNavItem.pagePath)]: height,
      };
    });

    setDropdownContainerHeight(allContainerHeights);
  }

  useEffect(() => {
    alignDropdownHeightOnDesktop();
  }, []);

  function openHamburgerMenu(e) {
    e.preventDefault();
    analyticsSend({
      ...analyticsData,
      eventCategory: 'navigation',
      eventName: 'primary-nav-expand',
    });
    setIsMobileMenuOpen(true);
  }

  function closeHamburgerMenu(e) {
    e.preventDefault();
    setIsMobileMenuOpen(false);
    setOpenTierOneNav('');
    setOpenTierTwoNav('');
  }

  function toggleTierOneDropdownForDesktop(e, id) {
    if (e.target && e.target.offsetLeft) {
      setDesktopDropdownLeftPosition(e.target.offsetLeft - 24);
    }

    setOpenTierTwoNav('');
    setOpenTierOneNavDesktop((prevState) => (prevState === id ? '' : id));
  }

  function onTierOneMenuItemClick(e, id) {
    e.preventDefault();

    if (isDesktopView()) {
      toggleTierOneDropdownForDesktop(e, id);
    } else {
      setOpenTierOneNav(id);
    }
  }

  function showTierThreeNav(id) {
    setOpenTierTwoNav(id);
  }

  function onTierTwoMenuItemClick(e, id) {
    e.preventDefault();
    showTierThreeNav(id);
  }

  function onTierOneMenuBack() {
    setOpenTierOneNav('');
  }

  function onTierTwoMenuBack() {
    setOpenTierTwoNav('');
  }

  function handleClickOutsideOnMobile(e) {
    if (
      containerRef.current &&
      !containerRef.current.contains(e.target) &&
      !hamburgerButtonRef.current.contains(e.target) &&
      !isDesktopView()
    ) {
      closeHamburgerMenu(e);
    }
  }

  function handleClickOutsideOnDesktop(e) {
    if (containerRef.current && !containerRef.current.contains(e.target) && isDesktopView()) {
      toggleTierOneDropdownForDesktop(e, '');
    }
  }

  function toggleSearchOnMobile() {
    setShowSearchOnMobile((prevState) => !prevState);
  }

  function getDesktopDropdownPosition(id) {
    if (!isDesktopView()) {
      return {};
    }

    if (id === openTierOneNavDesktop) {
      return {
        height: dropdownContainerHeight[id],
        top: topNavContainerRef.current.offsetHeight,
        left: desktopDropdownLeftPosition,
      };
    }

    return {
      top: topNavContainerRef.current ? topNavContainerRef.current.offsetHeight : 0,
      left: desktopDropdownLeftPosition,
    };
  }

  function handleWindowResize() {
    alignDropdownHeightOnDesktop();
  }

  const debouncedHandleWindowResize = debounce(handleWindowResize, 200, { trailing: true });

  useEffect(() => {
    window.addEventListener('resize', debouncedHandleWindowResize, false);

    return () => {
      document.removeEventListener('resize', debouncedHandleWindowResize, false);
    };
  }, []);

  useEffect(() => {
    if (isMobileMenuOpen) {
      document.addEventListener('click', handleClickOutsideOnMobile, false);
    } else {
      document.removeEventListener('click', handleClickOutsideOnMobile, false);
    }

    return () => {
      document.removeEventListener('click', handleClickOutsideOnMobile, false);
    };
  }, [isMobileMenuOpen]);

  useEffect(() => {
    if (openTierOneNavDesktop) {
      document.addEventListener('click', handleClickOutsideOnDesktop, false);
      analyticsSend({
        ...analyticsData,
        eventCategory: 'navigation',
        eventName: 'primary-nav-header',
        navigationLevel: '1',
        navigationParentElement: '',
        navigationElementName: openTierOneNavDesktop,
      });
    } else {
      document.removeEventListener('click', handleClickOutsideOnDesktop, false);
    }

    return () => {
      document.removeEventListener('click', handleClickOutsideOnDesktop, false);
    };
  }, [openTierOneNavDesktop]);

  useEffect(() => {
    if (rendered) {
      if (showSearchOnMobile) {
        analyticsSend({
          ...analyticsData,
          eventCategory: 'search',
          eventName: 'search-icon',
          interactionType: 'expand',
        });
      } else {
        analyticsSend({
          ...analyticsData,
          eventCategory: 'search',
          eventName: 'search-icon',
          interactionType: 'collapse',
        });
      }
    }
  }, [showSearchOnMobile]);

  useEffect(() => {
    if (openTierTwoNav) {
      analyticsSend({
        ...analyticsData,
        eventCategory: 'navigation',
        eventName: 'primary-nav-header',
        navigationLevel: '2',
        navigationParentElement: '',
        navigationElementName: openTierTwoNav,
      });
    }
  }, [openTierTwoNav]);

  useEffect(() => {
    if (openTierOneNav) {
      analyticsSend({
        ...analyticsData,
        eventCategory: 'navigation',
        eventName: 'primary-nav-header',
        navigationLevel: '1',
        navigationParentElement: '',
        navigationElementName: openTierOneNav,
      });
    }
  }, [openTierOneNav]);

  useEffect(() => {
    const commonAnalyticsData = window.vffCoreWebsite[analyticsMetadataKey] || {};

    setAnalyticsData(commonAnalyticsData);
  }, [analyticsMetadataKey]);

  const isNavigationAvailable = navigationItems && navigationItems.length;
  const commonAnalyticsData = {
    eventLocation: 'navigation',
  };

  const isSubNavVisible = rendered && !subNavigation.hidden && subNavigationItems.length > 0;

  return (
    <ErrorBoundary section={COMPONENT_NAME.navigation}>
      <header className={styles.header} ref={headerRef}>
        <div className={styles.container} ref={topNavContainerRef}>
          {isNavigationAvailable ? (
            <button ref={hamburgerButtonRef} className={styles.hamburgerButton} onClick={openHamburgerMenu}>
              <Icon name="Hamburger" size="extra-small" />
              <VisuallyHidden>Hamburger menu</VisuallyHidden>
            </button>
          ) : null}

          <a
            analytics-metadata={JSON.stringify({
              ...analyticsData,
              ...commonAnalyticsData,
            })}
            className={styles.logoLink}
            href={logoUrl || '/'}
          >
            {logo ? <img className={styles.logo} src={logo} alt="Velocity logo" /> : <Logo className={styles.logo} />}
            <VisuallyHidden>Velocity logo</VisuallyHidden>
          </a>

          {isNavigationAvailable ? (
            <div
              className={cx(styles.overlay, {
                [styles.overlayVisible]: isMobileMenuOpen,
              })}
            >
              <div className={styles.navigationContainer}>
                <nav className={styles.navigation} ref={containerRef}>
                  {rendered ? (
                    <>
                      <div className={styles.navigationToolbar}>
                        <button
                          className={cx(styles.searchButton, {
                            [styles.searchDisabled]: search.hidden,
                          })}
                          onClick={toggleSearchOnMobile}
                        >
                          <Icon className={styles.searchButtonIcon} name="Magnifier" size="extra-small" />
                          <VisuallyHidden>Search button</VisuallyHidden>
                        </button>
                        <button className={styles.closeButton} onClick={closeHamburgerMenu}>
                          <Icon className={styles.closeButtonIcon} name="Cross" size="extra-small" />
                          <VisuallyHidden>Close hamburger menu</VisuallyHidden>
                        </button>
                      </div>

                      {!search.hidden ? (
                        <div
                          className={cx(styles.tierTwoNavContainer, {
                            [styles.tierTwoNavContainerVisibleForMobile]: showSearchOnMobile,
                          })}
                        >
                          <div className={styles.navigationToolbar}>
                            <button className={styles.searchButton} onClick={toggleSearchOnMobile}>
                              <Icon className={styles.backIcon} name="ChevronNew" size="extra-small" />
                              <VisuallyHidden>Toggle search</VisuallyHidden>
                            </button>

                            <button className={styles.closeButton} onClick={closeHamburgerMenu}>
                              <Icon className={styles.closeButtonIcon} name="Cross" size="extra-small" />
                              <VisuallyHidden>Close hamburger menu</VisuallyHidden>
                            </button>
                          </div>

                          <div className={styles.searchBarOnMobile}>
                            <SearchBar
                              analyticsDataFromParent={commonAnalyticsData}
                              formId="mobile"
                              search={search}
                              defaultExpanded
                              defaultVisibleForResultList
                            />
                          </div>
                        </div>
                      ) : null}
                    </>
                  ) : null}

                  <ul className={styles.tierOnelist}>
                    {map(navigationItems, (item) => (
                      <li key={item.title} className={styles.tierOneListItem}>
                        {item.childPages && item.childPages.length > 0 ? (
                          <>
                            <button
                              onClick={(event) => onTierOneMenuItemClick(event, getUniqueKey(item.pagePath))}
                              className={cx(styles.tierOneMenuItemButton, {
                                [styles.tierOneMenuItemButtonSelected]:
                                  openTierOneNavDesktop === getUniqueKey(item.pagePath),
                              })}
                            >
                              <span className={styles.tierOneMenuItemButtonContent}>
                                <span>
                                  <VisuallyHidden>Open</VisuallyHidden>
                                  {item.title}
                                  <VisuallyHidden>menu</VisuallyHidden>
                                  <HintLabel className={styles.topRight} label={item.label} />
                                </span>
                                <Icon
                                  className={styles.tierOneMenuItemButtonIcon}
                                  name="ChevronNew"
                                  size="extra-small"
                                />
                              </span>
                            </button>

                            <div
                              className={cx(styles.tierTwoNavContainer, {
                                [styles.tierTwoNavContainerVisibleForMobile]:
                                  openTierOneNav === getUniqueKey(item.pagePath),
                                [styles.tierTwoNavContainerVisibleForDesktop]:
                                  openTierOneNavDesktop === getUniqueKey(item.pagePath),
                                [styles.tierTwoNavContainerNoResources]: isEmpty(item.resources),
                                [styles.tierTwoNavContainerHasResources]: !isEmpty(item.resources),
                                [styles.tierTwoNavContainerChildNavOpen]: openTierTwoNav,
                              })}
                              aria-hidden={!(openTierOneNav === getUniqueKey(item.pagePath))}
                              style={getDesktopDropdownPosition(getUniqueKey(item.pagePath))}
                            >
                              <div className={styles.navigationToolbar}>
                                <button className={styles.backButton} onClick={onTierOneMenuBack}>
                                  <Icon className={styles.backIcon} name="ChevronNew" size="extra-small" />
                                  <span className={styles.backButtonText}>{item.title}</span>
                                  <VisuallyHidden>back to previous menu</VisuallyHidden>
                                </button>

                                <button className={styles.closeButton} onClick={closeHamburgerMenu}>
                                  <Icon className={styles.closeButtonIcon} name="Cross" size="extra-small" />
                                  <VisuallyHidden>Close hamburger menu</VisuallyHidden>
                                </button>
                              </div>

                              <div className={styles.layoutContainer}>
                                <div className={cx(styles.tierTwoLayoutContainer, styles.tierTwoLayoutContainerWhite)}>
                                  <ul
                                    className={styles.tierTwoList}
                                    ref={allRefs.current[refIndex[getUniqueKey(item.pagePath)]]}
                                  >
                                    {map(item.childPages, (tierTwoItem) => (
                                      <li key={getUniqueKey(tierTwoItem.pagePath)}>
                                        {tierTwoItem.childPages && tierTwoItem.childPages.length > 0 ? (
                                          <>
                                            <button
                                              onClick={(e) =>
                                                onTierTwoMenuItemClick(e, getUniqueKey(tierTwoItem.pagePath))
                                              }
                                              className={cx(styles.tierTwoMenuItemButton, {
                                                [styles.tierTwoMenuItemButtonSelected]:
                                                  openTierTwoNav === getUniqueKey(tierTwoItem.pagePath),
                                              })}
                                              style={
                                                openTierTwoNav === getUniqueKey(tierTwoItem.pagePath)
                                                  ? {}
                                                  : { backgroundColor: tierTwoItem.backgroundColor }
                                              }
                                            >
                                              <span className={styles.tierTwoMenuItemButtonContent}>
                                                <span className={styles.tierTwoMenuItemButtonContentTitle}>
                                                  <span>
                                                    <VisuallyHidden>Open</VisuallyHidden>
                                                    {tierTwoItem.title}
                                                    <VisuallyHidden>Menu</VisuallyHidden>
                                                    <HintLabel label={tierTwoItem.label} />
                                                  </span>
                                                  <Icon
                                                    className={styles.tierTwoMenuItemButtonIcon}
                                                    name="ChevronNew"
                                                    size="extra-small"
                                                  />
                                                </span>
                                                {tierTwoItem.subTitle ? (
                                                  <span className={styles.subTitle}>{tierTwoItem.subTitle}</span>
                                                ) : null}
                                              </span>
                                            </button>

                                            <div
                                              className={cx(styles.tierThreeNavContainer, {
                                                [styles.tierThreeNavContainerVisible]:
                                                  openTierTwoNav === getUniqueKey(tierTwoItem.pagePath),
                                              })}
                                            >
                                              <div className={styles.navigationToolbar}>
                                                <button className={styles.backButton} onClick={onTierTwoMenuBack}>
                                                  <Icon
                                                    className={styles.backIcon}
                                                    name="ChevronNew"
                                                    size="extra-small"
                                                  />
                                                  <span className={styles.backButtonText}>{tierTwoItem.title}</span>
                                                  <VisuallyHidden>back to previous menu</VisuallyHidden>
                                                </button>

                                                <button className={styles.closeButton} onClick={closeHamburgerMenu}>
                                                  <Icon
                                                    className={styles.closeButtonIcon}
                                                    name="Cross"
                                                    size="extra-small"
                                                  />
                                                  <VisuallyHidden>Close hamburger menu</VisuallyHidden>
                                                </button>
                                              </div>

                                              <ul
                                                className={styles.tierThreeList}
                                                ref={allRefs.current[refIndex[getUniqueKey(tierTwoItem.pagePath)]]}
                                              >
                                                {map(tierTwoItem.childPages, (tierThreeItem) => (
                                                  <li key={getUniqueKey(tierThreeItem.pagePath)}>
                                                    <a
                                                      analytics-metadata={JSON.stringify({
                                                        ...analyticsData,
                                                        eventCategory: 'navigation',
                                                        eventName: 'primary-nav-interaction',
                                                        navigationLevel: '3',
                                                        navigationParentElement: getUniqueKey(tierTwoItem.pagePath),
                                                        navigationElementName: getUniqueKey(tierThreeItem.pagePath),
                                                      })}
                                                      className={styles.tierThreeListLink}
                                                      href={tierThreeItem.href}
                                                    >
                                                      <span className={styles.tierThreeListLinkContent}>
                                                        {tierThreeItem.title}
                                                        <HintLabel label={tierThreeItem.label} />
                                                      </span>
                                                    </a>
                                                  </li>
                                                ))}
                                              </ul>
                                            </div>
                                          </>
                                        ) : (
                                          <a
                                            analytics-metadata={JSON.stringify({
                                              ...analyticsData,
                                              eventCategory: 'navigation',
                                              eventName: 'primary-nav-interaction',
                                              navigationLevel: '2',
                                              navigationParentElement: getUniqueKey(item.pagePath),
                                              navigationElementName: getUniqueKey(tierTwoItem.pagePath),
                                            })}
                                            className={styles.tierTwoListLink}
                                            href={tierTwoItem.href}
                                            style={
                                              tierTwoItem.backgroundColor
                                                ? { backgroundColor: tierTwoItem.backgroundColor }
                                                : {}
                                            }
                                          >
                                            <span className={styles.tierTwoListLinkContent}>
                                              <span>
                                                <span>{tierTwoItem.title}</span>
                                                <HintLabel label={tierTwoItem.label} />
                                              </span>
                                              {tierTwoItem.subTitle ? (
                                                <span className={styles.subTitle}>{tierTwoItem.subTitle}</span>
                                              ) : null}
                                            </span>
                                          </a>
                                        )}
                                      </li>
                                    ))}
                                  </ul>
                                </div>

                                <div
                                  className={cx(
                                    styles.tierTwoLayoutContainer,
                                    styles.tierTwoLayoutContainerPlaceholder,
                                  )}
                                  aria-hidden="true"
                                />

                                {item.resources && item.resources.length > 0 ? (
                                  <div
                                    className={cx(
                                      styles.tierTwoLayoutContainer,
                                      styles.tierTwoLayoutContainerResources,
                                    )}
                                    ref={allRefs.current[refIndex[getUniqueKey(`${item.pagePath}-resources`)]]}
                                    analytics-metadata={JSON.stringify({
                                      ...analyticsData,
                                      eventCategory: 'navigation',
                                      eventName: 'primary-nav-links',
                                      navigationLevel: '',
                                      navigationParentElement: getUniqueKey(item.pagePath),
                                    })}
                                  >
                                    <h3 className={styles.resourceTitle}>resources</h3>
                                    <ul className={styles.resourceList}>
                                      {map(item.resources, (resource) => (
                                        <li className={styles.resourceListItem} key={resource.title}>
                                          <a
                                            className={styles.resourceListItemLink}
                                            href={resource.href}
                                            title={`${resource.title} link`}
                                          >
                                            {resource.iconUrl ? (
                                              <img
                                                className={styles.resourceListItemLinkIcon}
                                                alt=""
                                                src={resource.iconUrl}
                                              />
                                            ) : null}
                                            {resource.title}
                                          </a>
                                        </li>
                                      ))}
                                    </ul>
                                  </div>
                                ) : null}
                              </div>
                            </div>
                          </>
                        ) : (
                          <a
                            analytics-metadata={JSON.stringify({
                              ...analyticsData,
                              eventCategory: 'navigation',
                              eventName: 'primary-nav-interaction',
                              navigationLevel: '1',
                              navigationParentElement: '',
                              navigationElementName: getUniqueKey(item.pagePath),
                            })}
                            className={styles.tierOneListLink}
                            href={item.href}
                          >
                            <span className={styles.tierOneListLinkContent}>
                              {item.title}
                              <HintLabel className={styles.topRight} label={item.label} />
                            </span>
                          </a>
                        )}
                      </li>
                    ))}
                  </ul>

                  {rendered && !hasLoggedIn && isLoginModuleVisible ? (
                    <ul className={styles.buttonList}>
                      <li className={styles.buttonListItem}>
                        <MyVelocityLink
                          loginButton={loginButton}
                          className={styles.myVelocityLink}
                          analyticsDataFromParent={commonAnalyticsData}
                        />
                      </li>
                      <li className={styles.buttonListItem}>
                        <JoinNowLink
                          joinButton={joinButton}
                          className={styles.joinNowLink}
                          analyticsDataFromParent={commonAnalyticsData}
                        />
                      </li>
                    </ul>
                  ) : null}
                </nav>
              </div>
            </div>
          ) : null}

          <div className={styles.rightContainer}>
            {rendered ? (
              <>
                {!search.hidden ? (
                  <div className={styles.searchBarOnDesktop}>
                    <SearchBar
                      analyticsDataFromParent={commonAnalyticsData}
                      formId="desktop"
                      search={search}
                      autofocus
                    />
                  </div>
                ) : null}
                {isLoginModuleVisible ? (
                  <LoginModule loginModule={loginModule} joinButton={joinButton} loginButton={loginButton} />
                ) : null}
              </>
            ) : null}
          </div>
        </div>

        {isSubNavVisible ? (
          <SubNavigation navigationItems={subNavigationItems} subNavQuickLinks={subNavQuickLinks} />
        ) : null}

        {rendered && userData.getMemberDataLoadError(user) && isLoginModuleVisible ? (
          <div
            className={styles.apiErrorContainer}
            style={
              hideError
                ? {
                    top: '-2rem',
                    opacity: 0,
                  }
                : {
                    top: getNavigationHeight() + 8,
                    opacity: 1,
                  }
            }
            onClick={() => setHideError(true)}
            role="presentation"
          >
            <Icon name="Important" size="small" className={styles.icon} />
            <RichTextContent
              className={styles.message}
              content={syncText(defaultErrorMessage, {
                refreshThePage:
                  '<a title="refresh current page" onClick="window.location.reload();">refresh the page</a>',
              })}
            />
          </div>
        ) : null}
      </header>

      <div
        className={cx(styles.headerHeightMirror, {
          [styles.withSubNav]: isSubNavVisible,
        })}
        aria-hidden
        id="vff-header-mirror"
      />

      {hasLoggedIn && <WebChat />}

      {notification || cookieNotice ? (
        <div className={styles.stickyFooterContainer}>
          {cookieNotice && <CookieNotice {...cookieNotice} />}
          {notification && <Notification {...notification} />}
        </div>
      ) : null}
    </ErrorBoundary>
  );
};

Navigation.propTypes = {
  user: PropTypes.shape({}),
  logo: PropTypes.string,
  logoUrl: PropTypes.string,
  search: PropTypes.shape({
    popularSearchList: PropTypes.arrayOf(PropTypes.shape({})),
    phone: PropTypes.string,
    memberSupportText: PropTypes.string,
    memberSupportUrl: PropTypes.string,
    hidden: PropTypes.bool,
  }),
  analyticsMetadata: PropTypes.shape({
    'analytics-metadata': PropTypes.string,
  }),
  loginModule: PropTypes.shape({
    hidden: PropTypes.bool,
  }),
  navigationItems: PropTypes.arrayOf(PropTypes.shape({})),
  subNavigation: PropTypes.shape({
    hidden: PropTypes.bool,
  }),
  defaultErrorMessage: PropTypes.string,
  joinButton: PropTypes.shape({}),
  loginButton: PropTypes.shape({}),
  notification: PropTypes.shape({}),
  cookieNotice: PropTypes.shape({}),
  subNavQuickLinks: PropTypes.arrayOf(PropTypes.shape({})),
};

Navigation.defaultProps = {
  user: null,
  logo: null,
  logoUrl: null,
  search: {
    popularSearchList: [],
    phone: '',
    memberSupportText: '',
    memberSupportUrl: '',
    hidden: false,
  },
  analyticsMetadata: {},
  loginModule: {},
  navigationItems: [],
  subNavigation: {},
  defaultErrorMessage: '',
  joinButton: {
    ctaUrl: 'https://join.velocityfrequentflyer.com/?source=WEBSITE',
    ctaTitle: 'Join',
    ctaLabel: 'Join',
  },
  loginButton: {
    ctaLabel: 'Log in',
    ctaUrl: '',
  },
  notification: null,
  cookieNotice: null,
  subNavQuickLinks: [],
};

export default connect((state) => ({
  user: state.user,
}))(Navigation);
