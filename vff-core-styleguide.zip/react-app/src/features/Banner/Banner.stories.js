import React from 'react';
import { Provider } from 'react-redux';
import { configureStore } from '../../stores';
import Banner from './Banner';
import userData from '../Navigation/mocks/user.mock.json';

const bannerMock = {
  title: 'Claim missing points',
};

export default {
  title: 'Banners',
};

export const _Banner = () => (
  <Provider
    store={configureStore({
      user: {
        authenticated: true,
        ...userData,
      },
    })}
  >
    <div className="vffutils__container-width vffutils__container-width--full">
      <Banner {...bannerMock} />
    </div>
  </Provider>
);
_Banner.storyName = 'Default';

export const _BeyondMemberBanner = () => (
  <Provider
    store={configureStore({
      user: {
        authenticated: true,
        tiers: {
          mainTierInfo: {
            tierLevel: 'V',
          },
        },
      },
    })}
  >
    <div className="vffutils__container-width vffutils__container-width--full">
      <Banner {...bannerMock} enableBeyondBanner />
    </div>
  </Provider>
);
_BeyondMemberBanner.storyName = 'Beyond Member';
