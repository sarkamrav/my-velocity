import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import { connect } from 'react-redux';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import AirplaneWithTrail from './AirplaneWithTrail.svg';
import { COMPONENT_NAME } from '../../utils/common';
import * as userData from '../../stores/utilities';

import styles from './Banner.css';

const Banner = (props) => {
  const { user, title, enableBeyondBanner } = props;
  const hasLoggedIn = userData.getHasLoggedIn(user);
  const mainTier = userData.getTierLevel(user);

  const [isBeyondMember, setIsBeyondMember] = useState(false);

  useEffect(() => {
    if (hasLoggedIn && mainTier === 'V' && enableBeyondBanner) {
      setIsBeyondMember(true);
    }
  }, [hasLoggedIn, mainTier, enableBeyondBanner]);

  return (
    <ErrorBoundary section={COMPONENT_NAME.banner}>
      <div
        className={cx(styles.bannerContainer, {
          [styles.beyondMember]: isBeyondMember,
        })}
      >
        {isBeyondMember && <div className={styles.gradientOverlay} />}
        <h1 className={cx(styles.title, 'heading heading--1 color color--white')}>{title}</h1>
        <AirplaneWithTrail />
      </div>
    </ErrorBoundary>
  );
};

Banner.propTypes = {
  user: PropTypes.shape({}),
  title: PropTypes.string,
  enableBeyondBanner: PropTypes.bool,
};

Banner.defaultProps = {
  user: null,
  title: null,
  enableBeyondBanner: false,
};

export default connect((state) => ({
  user: state.user,
}))(Banner);
