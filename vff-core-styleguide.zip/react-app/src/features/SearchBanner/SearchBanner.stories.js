import React from 'react';
import MockAdapter from 'axios-mock-adapter';
import SearchBannerGifMock from './mocks/SearchBannerGif.mock.json';
import SearchBannerImageMock from './mocks/SearchBannerImage.mock.json';
import SearchBannerVideoMock from './mocks/SearchBannerVideo.mock.json';
import SearchBanner from './SearchBanner';
import api from '../../utils/api';
import searchResult from '../Search/SearchResult/mocks/SearchResult.json';
import searchSuggestions from '../Search/SearchResult/mocks/SearchSuggestions.mock.json';

export default {
  title: 'Search Banner',
};

export const GifBackground = () => {
  const mockFunnelback = new MockAdapter(api.funnelback, { delayResponse: 500 });

  mockFunnelback.onGet('/s/search.html').reply(200, searchResult);
  mockFunnelback.onGet('/s/suggest.json').reply(200, searchSuggestions);

  return <SearchBanner {...SearchBannerGifMock} />;
};

GifBackground.storyName = 'Gif background';

export const VideoBackground = () => {
  const mockFunnelback = new MockAdapter(api.funnelback, { delayResponse: 500 });

  mockFunnelback.onGet('/s/search.html').reply(200, searchResult);
  mockFunnelback.onGet('/s/suggest.json').reply(200, searchSuggestions);

  return <SearchBanner {...SearchBannerVideoMock} />;
};

VideoBackground.storyName = 'Video background';

export const ImageBackground = () => {
  const mockFunnelback = new MockAdapter(api.funnelback, { delayResponse: 500 });

  mockFunnelback.onGet('/s/search.html').reply(200, searchResult);
  mockFunnelback.onGet('/s/suggest.json').reply(200, searchSuggestions);

  return <SearchBanner {...SearchBannerImageMock} />;
};

ImageBackground.storyName = 'Image background';
