import React, { useEffect, useState } from 'react';
import cx from 'classnames';
import PropTypes from 'prop-types';
import _ from 'lodash';

import RichTextContent from '../../components/RichTextContent/RichTextContent';
import SearchAutocomplete from './SearchAutocomplete/SearchAutocomplete';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME } from '../../utils/common';

import styles from './SearchBanner.css';

const SearchBanner = ({
  title,
  description,
  videoRef,
  heroBannerType,
  imageRef,
  renditions,
  searchBarHidden,
  renditionImageKey,
}) => {
  const [hasAnimated, setHasAnimated] = useState(false);
  const backgroundImage = _.get(renditions, 'imageDefault');

  function getBackgroundProperties(imageType, imagePath) {
    const type = imageType.toUpperCase();

    if (type === 'IMAGE') {
      return { backgroundImage: `url(${imagePath})` };
    }

    if (type === 'GIF') {
      return { backgroundImage: `url(${imageRef})` };
    }

    return null;
  }

  useEffect(() => {
    setHasAnimated(true);
  }, []);

  return (
    <ErrorBoundary section={COMPONENT_NAME.searchBanner}>
      <section
        className={cx(styles.container, {
          'text-highlight-animation': hasAnimated,
        })}
      >
        <div
          className={styles.backgroundContainer}
          style={getBackgroundProperties(heroBannerType, backgroundImage)}
          rendition-image={heroBannerType.toUpperCase() === 'IMAGE' ? renditionImageKey : null}
        >
          {heroBannerType.toUpperCase() === 'VIDEO' ? (
            <div className={styles.videoContainer}>
              <video preload="auto" autoPlay loop muted playsInline>
                <source src={videoRef} type="video/mp4" />
                {imageRef ? (
                  <img
                    src={backgroundImage}
                    className={styles.videoFallbackImage}
                    alt="Your browser does not support the <video> tag"
                  />
                ) : (
                  'Your browser does not support the <video> tag'
                )}
              </video>
            </div>
          ) : null}

          <div className={styles.content}>
            {title ? (
              <h1
                className={cx(styles.title, 'heading heading--1 color color--white')}
                dangerouslySetInnerHTML={{ __html: title }}
              />
            ) : null}

            {!searchBarHidden && <SearchAutocomplete className={styles.searchInput} />}

            {description ? <RichTextContent content={description} className={styles.description} /> : null}
          </div>
        </div>
      </section>
    </ErrorBoundary>
  );
};

SearchBanner.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
  heroBannerType: PropTypes.string,
  videoRef: PropTypes.string,
  imageRef: PropTypes.string,
  searchBarHidden: PropTypes.bool,
  renditionImageKey: PropTypes.string,
  renditions: PropTypes.shape({}),
};

SearchBanner.defaultProps = {
  title: '',
  description: '',
  videoRef: '',
  heroBannerType: '',
  imageRef: '',
  searchBarHidden: false,
  renditionImageKey: '',
  renditions: {},
};

export default SearchBanner;
