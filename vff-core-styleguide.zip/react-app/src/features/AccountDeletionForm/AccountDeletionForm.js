import React, { useCallback, useEffect, useRef, useState } from 'react';
import PropTypes from 'prop-types';
import get from 'lodash/get';
import isEmpty from 'lodash/isEmpty';
import reduce from 'lodash/reduce';
import cx from 'classnames';
import { connect } from 'react-redux';
import { isBrowser, isMobile } from 'react-device-detect';

import Checkbox from '../../components/Form/Checkbox/Checkbox';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import Button from '../../components/Button/Button';
import {
  COMPONENT_NAME,
  contactDeviceType,
  findPhoneByType,
  getLandlineDisplay,
  getMobileDisplay,
  isCtaAvailable,
  scrollToRef,
} from '../../utils/common';
import api from '../../utils/api';
import * as validators from '../../components/Form/validators';

import { validateFormField } from '../../components/Form/utils';
import Loading from '../../components/Loading/Loading';
import InformationAlert from '../../components/InformationAlert/InformationAlert';
import ErrorModal from '../../components/ErrorModal/ErrorModal';
import H2 from '../JoinPage/components/H2/H2';
import A from '../../components/Button/A';
import { getApiActionName, getApiError, sendToNewRelic } from '../../utils/newRelic';

import {
  getCurrentPointsBalance,
  getEmailAddress,
  getFirstName,
  getLastName,
  getLoyaltyMembershipID,
  getPhones,
} from '../../stores/utilities';

import styles from './AccountDeletionForm.css';

const formFieldNames = {
  accountDeletionTnc: 'accountDeletionTnc',
  accountDeletionSecondaryTnc: 'accountDeletionSecondaryTnc',
};

const initialValues = {
  [formFieldNames.accountDeletionTnc]: false,
  [formFieldNames.accountDeletionSecondaryTnc]: false,
};

const fieldValidators = {
  [formFieldNames.accountDeletionTnc]: [validators.required()],
  [formFieldNames.accountDeletionSecondaryTnc]: [validators.required()],
};

const updateDocumentTitle = (title) => {
  document.title = title;
};

const onKeepMyMembershipClick = () => updateDocumentTitle('keepMyMembership'); // Do not change the string keepMyMembership unless confirmed with App team

const AccountDeletionForm = ({
  user,
  defaultAlertInfo,
  title,
  description,
  tncCheckbox,
  secondaryTncCheckbox,
  beforeYouGoMessage,
  ctaContainer,
  secondaryCtaContainer,
  successMessage,
  errorTitle,
  errorMessage: apiSubmissionErrorMessage,
  range,
  redirectionDelay,
}) => {
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [touchedFields, setTouchedFields] = useState({});

  const [apiLoading, setApiLoading] = useState(false);
  const [apiError, setApiError] = useState(false);
  const [apiResponse, setApiResponse] = useState(null);

  const [phoneLoading, setPhoneLoading] = useState(true);
  const [phone, setPhone] = useState(null);

  const memberDataLoading = get(user, 'memberDataLoading', true);
  const memberDataLoadError = get(user, 'memberDataLoadError', false);
  const hasLoggedIn = get(user, 'authenticated', false);
  const myPoints = getCurrentPointsBalance(user);

  const checkboxContainerRef = useRef({});
  const successContainerRef = useRef({});

  const infoAlert = reduce(
    range,
    (result, current) =>
      myPoints >= current.min && myPoints < current.max
        ? {
            isInRange: true,
            content: current.alertInfo,
          }
        : result,
    { isInRange: false, content: null },
  );

  const submitForm = async () => {
    const accountDeletionApiUri = '/loyalty/v2/members';

    try {
      setApiLoading(true);
      setApiError(false);

      const response = await api.vffV2Api.delete(accountDeletionApiUri);

      setApiLoading(false);
      setApiResponse(response.data);
    } catch (error) {
      setApiLoading(false);
      setApiError(true);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const tncErrorMessage = validateFormField(
      values[formFieldNames.accountDeletionTnc],
      fieldValidators[formFieldNames.accountDeletionTnc],
    );

    const secondaryTncErrorMessage = validateFormField(
      values[formFieldNames.accountDeletionSecondaryTnc],
      fieldValidators[formFieldNames.accountDeletionSecondaryTnc],
    );

    if (tncErrorMessage || secondaryTncErrorMessage) {
      setErrors((prev) => ({
        ...prev,
        [formFieldNames.accountDeletionTnc]: tncErrorMessage,
        [formFieldNames.accountDeletionSecondaryTnc]: secondaryTncErrorMessage,
      }));

      setTouchedFields((prevState) => ({
        ...prevState,
        [formFieldNames.accountDeletionTnc]: true,
        [formFieldNames.accountDeletionSecondaryTnc]: true,
      }));

      scrollToRef(checkboxContainerRef);
    } else {
      submitForm();
    }
  };

  const setTouchField = (fieldName) => {
    setTouchedFields((prevState) => ({
      ...prevState,
      [fieldName]: true,
    }));
  };

  const setFieldValue = (fieldName, fieldValue) => {
    setValues((prevState) => ({
      ...prevState,
      [fieldName]: fieldValue,
    }));
  };

  const setFieldError = (fieldName, errorMessage) => {
    setErrors((prevState) => ({
      ...prevState,
      [fieldName]: errorMessage,
    }));
  };

  const getFieldValue = (e, stateValue) => {
    switch (get(e, 'target.type', '')) {
      case 'checkbox':
        return get(e, 'target.checked', '');
      case 'radio':
        return stateValue;
      default:
        return get(e, 'target.value', '');
    }
  };

  const updateFieldErrorMessage = useCallback((fieldName, fieldValue) => {
    const errorMessage = validateFormField(fieldValue, fieldValidators[fieldName]);

    if (errorMessage) {
      setFieldError(fieldName, errorMessage);
    } else {
      setFieldError(fieldName, '');
    }
  }, []);

  const handleFieldChange = useCallback(
    (e) => {
      const fieldName = get(e, 'target.name', '');
      const fieldType = get(e, 'target.type', '');
      const fieldValue = fieldType === 'checkbox' ? get(e, 'target.checked', '') : get(e, 'target.value', '');

      setFieldValue(fieldName, fieldValue);

      if (touchedFields[fieldName]) {
        updateFieldErrorMessage(fieldName, fieldValue);
      }
    },
    [touchedFields, updateFieldErrorMessage],
  );

  const handleBlur = useCallback(
    (e) => {
      const fieldName = get(e, 'target.name', '');
      const fieldValue = getFieldValue(e, values[fieldName]);

      updateFieldErrorMessage(fieldName, fieldValue);

      if (!touchedFields[fieldName]) {
        setTouchField(fieldName);
      }
    },
    [values, updateFieldErrorMessage, touchedFields],
  );

  const getInfoAlert = (infoContent) => (
    <div className={styles.contentWrapper}>
      <div className="vffutils__info-alert">
        <RichTextContent content={infoContent} />
      </div>
    </div>
  );

  useEffect(() => {
    const getPhoneNumber = async () => {
      const experienceMemberApiUri = '/loyalty/v2/experience/members/me?include=contact';

      try {
        setPhoneLoading(true);
        const response = await api.vffV2Api.get(experienceMemberApiUri);
        const phones = getPhones(response);
        const phoneDetail =
          findPhoneByType(phones, contactDeviceType.mobile) || findPhoneByType(phones, contactDeviceType.landline);

        setPhone(phoneDetail);
        setPhoneLoading(false);
      } catch (error) {
        setPhoneLoading(false);

        sendToNewRelic(
          getApiActionName(api.vffV2Api.defaults.baseURL, experienceMemberApiUri),
          getApiError(COMPONENT_NAME.accountDeletionForm, error),
        );
      }
    };

    if (hasLoggedIn) {
      getPhoneNumber();
    }
  }, [hasLoggedIn]);

  useEffect(() => {
    let timeout;

    if (apiResponse) {
      updateDocumentTitle('deleteMyMembership'); // Do not change the string deleteMyMembership unless confirmed with App team
      const logoutUri = get(window, 'vffCoreWebsite.websiteData.logoutRedirectUri');

      if (successContainerRef && successContainerRef.current) {
        scrollToRef(successContainerRef);
      }

      timeout = setTimeout(() => {
        window.location.href = logoutUri;
      }, redirectionDelay * 1000);
    }

    return () => {
      if (apiResponse) {
        clearTimeout(timeout);
      }
    };
  }, [apiResponse, redirectionDelay]);

  return (
    <div className={styles.container}>
      {!hasLoggedIn && memberDataLoadError && (
        <div className={styles.contentWrapper}>
          <InformationAlert
            title=""
            content="Sorry, we're having issues with our system."
            className={styles.errorContainer}
          />
        </div>
      )}

      {((!hasLoggedIn && !memberDataLoadError && memberDataLoading) || (hasLoggedIn && phoneLoading)) && (
        <Loading containerClassName={styles.loading} />
      )}

      {hasLoggedIn && !phoneLoading && (
        <>
          {apiError && (
            <ErrorModal
              header={<H2>{errorTitle}</H2>}
              errorMessage={apiSubmissionErrorMessage}
              onDismiss={() => setApiError(false)}
              ariaLabel="Account deletion error"
            />
          )}

          {apiResponse && (
            <div className={styles.contentWrapper} ref={successContainerRef}>
              <RichTextContent className={styles.successMessageContainer} content={successMessage} />
            </div>
          )}

          {!apiResponse && (
            <form className={styles.form} onSubmit={handleSubmit}>
              {infoAlert.isInRange && infoAlert.content && getInfoAlert(infoAlert.content)}

              {!infoAlert.isInRange && defaultAlertInfo && getInfoAlert(defaultAlertInfo)}

              <div className={styles.contentWrapper}>
                {title && <RichTextContent content={title} />}

                <div className="vffutils__container-width">
                  <hr className="vff__divider" />
                </div>

                <RichTextContent className={styles.description} content={description} />

                <div className={styles.contentRow}>
                  <span className={styles.contentRowText}>Membership Number: </span>
                  <span className={styles.contentRowText}>{getLoyaltyMembershipID(user)}</span>
                </div>

                <div className={styles.contentRow}>
                  <span className={styles.contentRowText}>Full Name: </span>
                  <span className={styles.contentRowText}>
                    {getFirstName(user)} {getLastName(user)}
                  </span>
                </div>

                {!isEmpty(phone) && (
                  <div className={styles.contentRow}>
                    <span className={styles.contentRowText}>
                      {phone.deviceType === contactDeviceType.mobile && 'Mobile Number:'}
                      {phone.deviceType === contactDeviceType.landline && 'Phone Number:'}
                    </span>
                    <span className={styles.contentRowText}>
                      {phone.deviceType === contactDeviceType.mobile && getMobileDisplay(phone)}
                      {phone.deviceType === contactDeviceType.landline && getLandlineDisplay(phone)}
                    </span>
                  </div>
                )}

                <div className={styles.contentRow}>
                  <span className={styles.contentRowText}>Email Address: </span>
                  <span className={styles.contentRowText}>{getEmailAddress(user)}</span>
                </div>

                <div className={styles.checkboxContainer} ref={checkboxContainerRef}>
                  <Checkbox
                    id={formFieldNames.accountDeletionTnc}
                    name={formFieldNames.accountDeletionTnc}
                    containerClassName={styles.checkbox}
                    label={<RichTextContent className={styles.checkboxLabel} content={tncCheckbox} />}
                    checked={values[formFieldNames.accountDeletionTnc]}
                    onChange={handleFieldChange}
                    size="large"
                    onBlur={handleBlur}
                    error={errors[formFieldNames.accountDeletionTnc]}
                  />

                  <Checkbox
                    id={formFieldNames.accountDeletionSecondaryTnc}
                    name={formFieldNames.accountDeletionSecondaryTnc}
                    containerClassName={styles.checkbox}
                    label={<RichTextContent className={styles.checkboxLabel} content={secondaryTncCheckbox} />}
                    checked={values[formFieldNames.accountDeletionSecondaryTnc]}
                    onChange={handleFieldChange}
                    size="large"
                    onBlur={handleBlur}
                    error={errors[formFieldNames.accountDeletionSecondaryTnc]}
                  />
                </div>
              </div>

              {beforeYouGoMessage && (
                <div className="vffutils__padding-top vffutils__padding-bottom vffutils__background-color vffutils__background-color--pale-purple vffutils__unordered-list vffutils__unordered-list--tick">
                  <div className={styles.contentWrapper}>
                    <RichTextContent content={beforeYouGoMessage} />
                  </div>
                </div>
              )}

              <div className={cx(styles.contentWrapper, styles.ctaWrapper)}>
                {isCtaAvailable(ctaContainer) && isMobile && (
                  <Button
                    buttonType={ctaContainer.ctaStyle}
                    disabled={false}
                    type="button"
                    title={ctaContainer.ctaTitle}
                    onClick={onKeepMyMembershipClick}
                  >
                    {ctaContainer.ctaLabel}
                  </Button>
                )}

                {isCtaAvailable(ctaContainer) && isBrowser && (
                  <A
                    key={ctaContainer.ctaLabel}
                    href={ctaContainer.ctaUrl}
                    title={ctaContainer.ctaTitle}
                    target={ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
                    buttonType={ctaContainer.ctaStyle}
                    ctaAsLink={ctaContainer.ctaAsLink}
                    ctaImage={ctaContainer.ctaImage}
                  >
                    {ctaContainer.ctaLabel}
                  </A>
                )}

                {isCtaAvailable(secondaryCtaContainer) && (
                  <Button
                    type="submit"
                    buttonType={secondaryCtaContainer.ctaStyle}
                    disabled={false}
                    title={ctaContainer.ctaTitle}
                    loading={apiLoading}
                  >
                    {secondaryCtaContainer.ctaLabel}
                  </Button>
                )}
              </div>
            </form>
          )}
        </>
      )}
    </div>
  );
};

AccountDeletionForm.propTypes = {
  user: PropTypes.shape({
    phoneNumbers: PropTypes.arrayOf(
      PropTypes.shape({
        phoneNumber: PropTypes.string,
        type: PropTypes.string,
      }),
    ),
    emailAddresses: PropTypes.arrayOf(
      PropTypes.shape({
        value: PropTypes.string,
        type: PropTypes.string,
      }),
    ),
  }),
  defaultAlertInfo: PropTypes.string,
  title: PropTypes.string,
  description: PropTypes.string,
  tncCheckbox: PropTypes.string,
  successMessage: PropTypes.string,
  errorMessage: PropTypes.string,
  secondaryTncCheckbox: PropTypes.string,
  beforeYouGoMessage: PropTypes.string,
  ctaContainer: PropTypes.shape({
    ctaStyle: PropTypes.string,
    ctaTitle: PropTypes.string,
    ctaLabel: PropTypes.string,
    ctaUrl: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaAsLink: PropTypes.bool,
    ctaImage: PropTypes.string,
  }),
  secondaryCtaContainer: PropTypes.shape({
    ctaStyle: PropTypes.string,
    ctaLabel: PropTypes.string,
  }),
  range: PropTypes.arrayOf(PropTypes.shape({})),
  redirectionDelay: PropTypes.number,
  errorTitle: PropTypes.string,
};

AccountDeletionForm.defaultProps = {
  user: null,
  defaultAlertInfo: null,
  title: null,
  description: null,
  tncCheckbox: null,
  secondaryTncCheckbox: null,
  beforeYouGoMessage: null,
  ctaContainer: null,
  secondaryCtaContainer: null,
  successMessage: null,
  errorMessage: null,
  range: null,
  redirectionDelay: 2,
  errorTitle: null,
};

export default connect((state) => ({
  user: state.user,
}))(AccountDeletionForm);
