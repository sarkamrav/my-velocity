import React from 'react';
import { Provider } from 'react-redux';
import MockAdapter from 'axios-mock-adapter';

import AccountDeletionForm from './AccountDeletionForm';
import { configureStore } from '../../stores';
import accountDeletionMock from './mocks/account-deletion-form.mock.json';
import userApiResponse from './mocks/user.mock.json';
import api from '../../utils/api';

export default {
  title: 'Account Deletion Form',
};

const userData = userApiResponse.data;

export const ApiSuccess = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api, { delayResponse: 1000 });

  mockVffV2.onDelete('/loyalty/v2/members').reply(200, {
    profileUpdated: true,
  });

  mockVffV2.onGet('/loyalty/v2/experience/members/me?include=contact').reply(200, userApiResponse);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <AccountDeletionForm {...accountDeletionMock} />
    </Provider>
  );
};

export const Points0To1500 = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api);

  mockVffV2.onDelete('/loyalty/v2/members').reply(200);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
          account: { currentPointsBalance: 1499 },
        },
      })}
    >
      <AccountDeletionForm {...accountDeletionMock} />
    </Provider>
  );
};

export const Points1500To2000 = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api);

  mockVffV2.onDelete('/loyalty/v2/members').reply(200);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
          account: { currentPointsBalance: 1500 },
        },
      })}
    >
      <AccountDeletionForm {...accountDeletionMock} />
    </Provider>
  );
};

export const Points2000AndPlus = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api);

  mockVffV2.onDelete('/loyalty/v2/members').reply(200);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
          account: { currentPointsBalance: 2000 },
        },
      })}
    >
      <AccountDeletionForm {...accountDeletionMock} />
    </Provider>
  );
};

export const ApiError = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api);

  mockVffV2.onDelete('/loyalty/v2/members').reply(400);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <AccountDeletionForm {...accountDeletionMock} />
    </Provider>
  );
};

export const UserProfileLoading = () => (
  <Provider
    store={configureStore({
      user: {
        memberDataLoaded: false,
        memberDataLoading: true,
        authenticated: false,
        ...userData,
      },
    })}
  >
    <AccountDeletionForm {...accountDeletionMock} />
  </Provider>
);

export const UserProfileError = () => (
  <Provider
    store={configureStore({
      user: {
        memberDataLoaded: true,
        memberDataLoading: false,
        authenticated: false,
        memberDataLoadError: true,
        ...userData,
      },
    })}
  >
    <AccountDeletionForm {...accountDeletionMock} />
  </Provider>
);
