import React from 'react';
import MockAdapter from 'axios-mock-adapter';
import { Provider } from 'react-redux';
import heroBannerCenterAlignmentMultipleCtasMock from './mocks/hero-banner--center-alignment-multiple-ctas.mock.json';
import heroBannerCenterAlignmentMultipleCtasLongLinkMock from './mocks/hero-banner--center-alignment-multiple-ctas-long-link.mock.json';
import heroBannerCenterAlignmentSingleCtaMock from './mocks/hero-banner--center-alignment-single-cta.mock.json';
import heroBannerLeftAlignmentSingleCtaMock from './mocks/hero-banner--left-alignment-single-cta.mock.json';
import heroBannerLeftAlignmentMultipleCtasMock from './mocks/hero-banner--left-alignment-multiple-ctas.mock.json';
import heroBannerLeftAlignmentMultipleCtasLongCtaLinkMock from './mocks/hero-banner--left-alignment-multiple-ctas-long-cta-link.mock.json';
import heroBannerLeftAlignmentMultipleCtasLongCtaButtonMock from './mocks/hero-banner--left-alignment-multiple-ctas-long-cta-button.mock.json';
import heroBannerOverridingTitleDescriptionMock from './mocks/hero-banner--overriding-title-description.mock.json';
import heroBannerCenterAlignmentMultipleImageCtasMock from './mocks/hero-banner-center-alignment-multiple-image-ctas.mock.json';
import heroBannerVideoMock from './mocks/hero-banner--video.mock.json';
import HeroBanner from './HeroBanner';
import api from '../../utils/api';
import apiResponseMock from '../../components/BuyPointsCallToAction/mocks/api-response.mock.json';
import heroBannerBuyPointsMock from './mocks/hero-banner--buy-points.mock.json';
import heroBannerCenterAlignmentBuyPointsMock from './mocks/hero-banner--center-alignment-buy-points.mock.json';
import { configureStore } from '../../stores';

export default {
  title: 'Hero Banner',
};

const Template = (args) => {
  const { authenticated = false, memberDataLoading = false, apiError, currentPointsBalance = 1, ...rest } = args;
  const mockVffPointsBoosterApi = new MockAdapter(api.vffPointsBoosterApi, {
    delayResponse: 1000,
  });

  if (apiError) {
    mockVffPointsBoosterApi.onPost('/loyalty/v2/pointsbooster/mvdelegate').reply(500, {
      code: 40084,
      title: 'Unknown Error',
      status: 500,
      detail: "An unknown error has occurred in one of Virgin Australia's systems.",
    });
  } else {
    mockVffPointsBoosterApi.onPost('/loyalty/v2/pointsbooster/mvdelegate').reply(200, {
      ...apiResponseMock,
    });
  }

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoading,
          authenticated,
          account: {
            joinDate: '2019-06-01',
            currentPointsBalance,
          },
          test: {
            store: 'working',
          },
        },
      })}
    >
      <HeroBanner {...rest} />
    </Provider>
  );
};

export const CenterAlignContent = Template.bind({});
CenterAlignContent.args = {
  ...heroBannerCenterAlignmentMultipleCtasMock,
  jsObjectKey: 'hero-banner_flying_virgin_australia_flex-flying0_master1',
};

export const CenterAlignContentLongLink = Template.bind({});
CenterAlignContentLongLink.args = {
  ...heroBannerCenterAlignmentMultipleCtasLongLinkMock,
  jsObjectKey: 'hero-banner_flying_virgin_australia_flex-flying0_master1',
};

export const CenterAlignContentWithSingleCta = Template.bind({});
CenterAlignContentWithSingleCta.args = {
  ...heroBannerCenterAlignmentSingleCtaMock,
  jsObjectKey: 'hero-banner_flying_virgin_australia_flex-flying0_master2',
};

export const LeftAlignContentWithSingleCta = Template.bind({});
LeftAlignContentWithSingleCta.args = {
  ...heroBannerLeftAlignmentSingleCtaMock,
  jsObjectKey: 'hero-banner_flying_virgin_australia_flex-flying0_master3',
};

export const LeftAlignContentWithMultipleCtas = Template.bind({});
LeftAlignContentWithMultipleCtas.args = {
  ...heroBannerLeftAlignmentMultipleCtasMock,
  jsObjectKey: 'hero-banner_flying_virgin_australia_flex-flying0_master4',
};

export const LeftAlignContentWithMultipleCtasLongCtaLink = Template.bind({});
LeftAlignContentWithMultipleCtasLongCtaLink.args = {
  ...heroBannerLeftAlignmentMultipleCtasLongCtaLinkMock,
  jsObjectKey: 'hero-banner_flying_virgin_australia_flex-flying0_master4',
};

export const LeftAlignContentWithMultipleCtasLongCtaButton = Template.bind({});
LeftAlignContentWithMultipleCtasLongCtaButton.args = {
  ...heroBannerLeftAlignmentMultipleCtasLongCtaButtonMock,
  jsObjectKey: 'hero-banner_flying_virgin_australia_flex-flying0_master4',
};

export const OverridingContentInMobile = Template.bind({});
OverridingContentInMobile.args = {
  ...heroBannerOverridingTitleDescriptionMock,
  jsObjectKey: 'hero-banner_flying_virgin_australia_flex-flying0_master5',
};

export const CenterAlignmentMultipleImageCtasMock = Template.bind({});
CenterAlignmentMultipleImageCtasMock.args = {
  ...heroBannerCenterAlignmentMultipleImageCtasMock,
  jsObjectKey: 'hero-banner_flying_virgin_australia_flex-flying0_master6',
};

export const Video = Template.bind({});
Video.args = {
  ...heroBannerVideoMock,
  jsObjectKey: 'hero-banner_ir_flying_virgin_australia_flex-flying0_master',
};

export const buyPointsUnauthenticated = Template.bind({});
buyPointsUnauthenticated.args = {
  ...heroBannerBuyPointsMock,
  jsObjectKey: 'hero-banner_flying_virgin_australia_flex-flying0_master7',
  buyPoints: true,
};

export const buyPointsSuccess = Template.bind({});
buyPointsSuccess.args = {
  ...heroBannerBuyPointsMock,
  jsObjectKey: 'hero-banner_flying_virgin_australia_flex-flying0_master7',
  authenticated: true,
  buyPoints: true,
};

export const buyPointsError = Template.bind({});
buyPointsError.args = {
  ...heroBannerBuyPointsMock,
  jsObjectKey: 'hero-banner_flying_virgin_australia_flex-flying0_master7',
  buyPoints: true,
  authenticated: true,
  apiError: true,
};

export const buyPointsErrorCenterAligned = Template.bind({});
buyPointsErrorCenterAligned.args = {
  ...heroBannerCenterAlignmentBuyPointsMock,
  jsObjectKey: 'hero-banner_flying_virgin_australia_flex-flying0_master7',
  buyPoints: true,
  authenticated: true,
  apiError: true,
};

export const buyPointsIneligibleMember = Template.bind({});
buyPointsIneligibleMember.args = {
  ...heroBannerBuyPointsMock,
  jsObjectKey: 'hero-banner_flying_virgin_australia_flex-flying0_master7',
  buyPoints: true,
  currentPointsBalance: 0,
};

export const buyPointsIneligibleMemberCenterAligned = Template.bind({});
buyPointsIneligibleMemberCenterAligned.args = {
  ...heroBannerCenterAlignmentBuyPointsMock,
  jsObjectKey: 'hero-banner_flying_virgin_australia_flex-flying0_master7',
  buyPoints: true,
  currentPointsBalance: 0,
};
