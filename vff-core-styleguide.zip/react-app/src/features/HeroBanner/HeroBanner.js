import React, { useState, useEffect, useCallback, useRef } from 'react';
import PropTypes from 'prop-types';
import get from 'lodash/get';
import noop from 'lodash/noop';
import map from 'lodash/map';
import isEmpty from 'lodash/isEmpty';
import cx from 'classnames';

import A from '../../components/Button/A';
import { COMPONENT_NAME, isCtaAvailable, isInternalLink } from '../../utils/common';
import useMobileFullInnerHeight from '../../hooks/useMobileFullInnerHeight';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import useModal from '../../hooks/useModal';
import TermsModal from '../../components/TermsModal/TermsModal';
import useServerRendering from '../../hooks/useServerRendering';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import useMediaQuery from '../../hooks/useMediaQuery';
import Header from '../../components/Header/Header';

import styles from './HeroBanner.css';
import BuyPointsCallToAction from '../../components/BuyPointsCallToAction/BuyPointsCallToAction';

const HeroBanner = ({
  imageRef,
  videoRef,
  mobileVideoRef,
  logoMobile,
  gifBackground,
  renditions,
  promoLabelTitle,
  partner,
  hideTintDesktop,
  hideTintMobile,
  title,
  titleTag,
  mobileTitle,
  description,
  mobileDescription,
  ctaContainer,
  secondaryCtaContainer,
  terms,
  renditionImageKey,
  keyCallOuts,
  className,
  heroBannerType,
  animateHighlightedText,
  analyticsMetadata,
  analyticsMetadataFromParent,
  isMobileFullInnerHeightRequired,
  centerAlignContent,
  jsObjectKey,
  tintColor,
  onTermsModalOpen,
  onTermsModalClose,
  enableBuyPointsCta,
  buyPointsCallToAction,
}) => {
  const [hasAnimated, setHasAnimated] = useState(false);
  const [analyticsData, setAnalyticsData] = useState(analyticsMetadata['analytics-metadata']);
  const [containerInlineStyle] = useMobileFullInnerHeight(56, isMobileFullInnerHeightRequired);
  const { rendered } = useServerRendering();
  const { isShowing: isTermsShowing, toggle: toggleTerms } = useModal();
  const videoReference = useRef();

  useEffect(() => {
    const commonAnalyticsData = window.vffCoreWebsite[analyticsMetadata['analytics-metadata']] || {};

    setAnalyticsData({
      ...analyticsMetadataFromParent,
      ...commonAnalyticsData,
      eventLocation: get(analyticsMetadataFromParent, 'eventLocation')
        ? analyticsMetadataFromParent.eventLocation
        : 'hero-banner',
      bannerType: heroBannerType,
      partner: get(partner, 'name', ''),
      partnerCategory: get(partner, 'category', ''),
      promoLabel: promoLabelTitle,
      eventCategory: 'banners',
      eventName: 'banner-cta',
    });
  }, [analyticsMetadataFromParent, analyticsMetadata, heroBannerType, partner, promoLabelTitle]);

  useEffect(() => {
    if (animateHighlightedText) {
      setHasAnimated(true);
    }
  }, [animateHighlightedText]);

  const defaultBackgroundForVideoOrImage = get(renditions, 'imageDefault');

  function getBackgroundProperties(bannerType) {
    const type = bannerType.toUpperCase();

    if (type === 'VIDEO' || type === 'IMAGE') {
      return { backgroundImage: `url(${defaultBackgroundForVideoOrImage})` };
    }

    if (type === 'GIF') {
      return { backgroundImage: `url(${imageRef})`, backgroundColor: gifBackground };
    }

    return null;
  }

  useEffect(() => {
    if (tintColor) {
      const head = document.getElementsByTagName('head')[0];

      if (head) {
        const styleSheet = document.createElement('style');
        const tintStyles = `.${jsObjectKey} {background-image: linear-gradient(to top, ${tintColor}, transparent);}   @media (min-width: 48em) {.${jsObjectKey} {background-image: linear-gradient(to right, ${tintColor}, transparent);}}`;
        styleSheet.setAttribute('type', 'text/css');
        styleSheet.appendChild(document.createTextNode(tintStyles));
        head.appendChild(styleSheet);
      }
    }
  }, [tintColor, jsObjectKey]);

  function openTermsModal() {
    toggleTerms();
    onTermsModalOpen();
  }

  const closeTermsModal = useCallback(() => {
    toggleTerms();
    onTermsModalClose();
  }, [onTermsModalClose, toggleTerms]);

  function getCta(cta) {
    return (
      <A
        key={cta.ctaLabel}
        href={cta.ctaUrl}
        linkClassName={styles.ctaLink}
        title={cta.ctaTitle}
        target={cta.ctaOpenInNewTab ? '_blank' : '_self'}
        buttonType={cta.ctaStyle}
        ctaAsLink={cta.ctaAsLink}
        ctaImage={cta.ctaImage}
        analytics-metadata={JSON.stringify({
          ...analyticsData,
          externalLink: !isInternalLink(cta.ctaUrl),
        })}
      >
        {cta.ctaLabel}
      </A>
    );
  }

  const isImageBanner = heroBannerType.toUpperCase() === 'IMAGE';
  const isVideo = heroBannerType.toUpperCase() === 'VIDEO';
  const partnerName = get(partner, 'name');
  const isFirstCtaAvailable = isCtaAvailable(ctaContainer);
  const isSecondCtaAvailable = isCtaAvailable(secondaryCtaContainer);
  const isMediaMobile = useMediaQuery('(max-width: 767px)');

  useEffect(() => {
    if (isVideo && mobileVideoRef) {
      videoReference.current.load();
    }
  }, [isVideo, isMediaMobile, mobileVideoRef]);

  return (
    <ErrorBoundary section={COMPONENT_NAME.heroBanner}>
      <section
        className={cx(styles.heroBanner, className, {
          'slick-active': hasAnimated,
        })}
        style={containerInlineStyle}
        {...analyticsMetadata}
      >
        <div
          className={cx(styles.background, {
            [styles.gifBackground]: heroBannerType.toUpperCase() === 'GIF',
            [styles.imageBackground]: isImageBanner,
          })}
          rendition-image={isImageBanner ? renditionImageKey : null}
          style={getBackgroundProperties(heroBannerType)}
        >
          {isVideo ? (
            <div className={styles.videoContainer}>
              <video ref={videoReference} preload="auto" autoPlay loop muted playsInline>
                {rendered && (
                  <source src={isMediaMobile && mobileVideoRef ? mobileVideoRef : videoRef} type="video/mp4" />
                )}

                {imageRef ? (
                  <img
                    src={defaultBackgroundForVideoOrImage}
                    className={styles.videoFallbackImage}
                    alt="Your browser does not support the <video> tag"
                  />
                ) : (
                  'Your browser does not support the <video> tag'
                )}
              </video>
            </div>
          ) : null}

          <div
            className={cx(styles.tint, {
              [jsObjectKey]: jsObjectKey && tintColor && rendered,
              [styles.hideFromTablet]: hideTintDesktop,
              [styles.hideOnMobile]: hideTintMobile,
            })}
          />
        </div>

        <div className={styles.contentWrapper}>
          <div className={cx(styles.content, 'hero-banner-content__applied-in-carousel')}>
            <div
              className={cx(styles.innerContentWrapper, {
                [styles.center]: centerAlignContent,
              })}
            >
              {!isEmpty(partner) ? (
                <div className={styles.logoContainer}>
                  <img
                    className={cx(styles.partnerLogo, {
                      [styles.tabletAndDesktop]: !!logoMobile,
                    })}
                    src={partner.logo}
                    alt={partner.name}
                  />
                  {logoMobile && (
                    <img className={cx(styles.partnerLogo, styles.mobileOnly)} src={logoMobile} alt={partner.name} />
                  )}
                </div>
              ) : null}

              {promoLabelTitle ? <span className={styles.badge}>{promoLabelTitle}</span> : null}

              {title && (
                <Header
                  tagTitle={titleTag}
                  classNames={cx(styles.title, 'heading heading--1 color color--white', {
                    [styles.hideOnMobile]: mobileTitle,
                  })}
                  title={title}
                />
              )}

              {mobileTitle && (
                <Header
                  tagTitle={titleTag}
                  classNames={cx(styles.title, styles.hideFromTablet, 'heading heading--1 color color--white')}
                  title={mobileTitle}
                />
              )}

              {!isEmpty(keyCallOuts) ? (
                <ul className={styles.keyCallouts}>
                  {map(keyCallOuts, (keyCallOut) => (
                    <li key={keyCallOut.title} className={styles.keyCallout}>
                      {keyCallOut.iconUrl ? (
                        <img className={styles.keyCalloutIcon} src={keyCallOut.iconUrl} alt="" />
                      ) : null}

                      <RichTextContent
                        className={cx(styles.keyCalloutText, {
                          [styles.hideOnMobile]: keyCallOut.mobileTitle,
                        })}
                        content={keyCallOut.title}
                      />

                      {keyCallOut.mobileTitle && (
                        <RichTextContent
                          className={cx(styles.keyCalloutText, styles.hideFromTablet)}
                          content={keyCallOut.mobileTitle}
                        />
                      )}
                    </li>
                  ))}
                </ul>
              ) : null}

              {description ? (
                <RichTextContent
                  content={description}
                  className={cx(styles.description, {
                    [styles.hideOnMobile]: mobileDescription,
                    [styles.noMargin]: enableBuyPointsCta,
                  })}
                />
              ) : null}

              {mobileDescription ? (
                <RichTextContent
                  content={mobileDescription}
                  className={cx(styles.description, styles.hideFromTablet, {
                    [styles.noMargin]: enableBuyPointsCta,
                  })}
                />
              ) : null}

              {enableBuyPointsCta && (
                <BuyPointsCallToAction
                  {...{
                    ...buyPointsCallToAction,
                    centreAligned: centerAlignContent,
                  }}
                />
              )}

              {!enableBuyPointsCta && (
                <>
                  {(isFirstCtaAvailable || isSecondCtaAvailable) && (
                    <div className={styles.ctaContainer}>
                      {isFirstCtaAvailable && getCta(ctaContainer)}
                      {isSecondCtaAvailable && getCta(secondaryCtaContainer)}
                    </div>
                  )}
                </>
              )}

              {terms && terms.text ? (
                <RichTextContent
                  content={terms.text}
                  className={cx(styles.disclaimer, {
                    [styles.hideOnMobile]: terms && terms.mobileText,
                  })}
                />
              ) : null}

              {terms && terms.mobileText ? (
                <RichTextContent content={terms.mobileText} className={cx(styles.disclaimer, styles.hideFromTablet)} />
              ) : null}

              {terms && terms.modalLabel ? (
                <>
                  <button
                    className={cx(styles.termsButton, {
                      [styles.hideOnMobile]: terms && terms.mobileModalLabel,
                    })}
                    onClick={openTermsModal}
                  >
                    <RichTextContent content={terms.modalLabel} />
                  </button>

                  {terms && terms.mobileModalLabel && (
                    <button className={cx(styles.termsButton, styles.hideFromTablet)} onClick={toggleTerms}>
                      <RichTextContent content={terms.mobileModalLabel} />
                    </button>
                  )}

                  <TermsModal
                    isShowing={isTermsShowing}
                    hide={closeTermsModal}
                    header={
                      <div className={styles.brandAndTitleContainer}>
                        {partnerName && <span className={styles.brandName}>{partnerName}</span>}
                        <RichTextContent className={styles.modalTitle} content={terms.modalTitle} />
                      </div>
                    }
                    aria-label={terms.modalTitle}
                  >
                    <RichTextContent className={styles.termsModalContent} content={terms.modalText} />
                  </TermsModal>
                </>
              ) : null}
            </div>
          </div>
        </div>
      </section>
    </ErrorBoundary>
  );
};

HeroBanner.propTypes = {
  imageRef: PropTypes.string,
  videoRef: PropTypes.string,
  mobileVideoRef: PropTypes.string,
  logoMobile: PropTypes.string,
  gifBackground: PropTypes.string,
  promoLabelTitle: PropTypes.string,
  className: PropTypes.string,
  heroBannerType: PropTypes.string,
  renditions: PropTypes.shape({}),
  partner: PropTypes.shape({
    logo: PropTypes.string,
    name: PropTypes.string,
  }),
  title: PropTypes.string,
  titleTag: PropTypes.string,
  mobileTitle: PropTypes.string,
  description: PropTypes.string,
  mobileDescription: PropTypes.string,
  hideTintDesktop: PropTypes.bool,
  hideTintMobile: PropTypes.bool,
  centerAlignContent: PropTypes.bool,
  ctaContainer: PropTypes.shape({
    ctaUrl: PropTypes.string,
    ctaTitle: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaStyle: PropTypes.string,
    ctaAsLink: PropTypes.bool,
    ctaLabel: PropTypes.string,
  }),
  secondaryCtaContainer: PropTypes.shape({
    ctaUrl: PropTypes.string,
    ctaTitle: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaStyle: PropTypes.string,
    ctaAsLink: PropTypes.bool,
    ctaLabel: PropTypes.string,
  }),
  terms: PropTypes.shape({
    modalTitle: PropTypes.string,
    modalText: PropTypes.string,
    text: PropTypes.string,
    mobileText: PropTypes.string,
    modalLabel: PropTypes.string,
    mobileModalLabel: PropTypes.string,
  }),
  renditionImageKey: PropTypes.string,
  analyticsMetadata: PropTypes.shape({
    'analytics-metadata': PropTypes.string,
  }),
  analyticsMetadataFromParent: PropTypes.shape({
    eventLocation: PropTypes.string,
  }),
  keyCallOuts: PropTypes.arrayOf(PropTypes.shape({})),
  animateHighlightedText: PropTypes.bool,
  isMobileFullInnerHeightRequired: PropTypes.bool,
  jsObjectKey: PropTypes.string,
  tintColor: PropTypes.string,
  onTermsModalOpen: PropTypes.func,
  onTermsModalClose: PropTypes.func,
  enableBuyPointsCta: PropTypes.bool,
  buyPointsCallToAction: PropTypes.shape({}),
};

HeroBanner.defaultProps = {
  imageRef: '',
  videoRef: '',
  mobileVideoRef: '',
  logoMobile: null,
  gifBackground: '',
  promoLabelTitle: '',
  className: '',
  renditions: {},
  heroBannerType: '',
  partner: {},
  title: '',
  titleTag: '',
  mobileTitle: '',
  description: '',
  mobileDescription: '',
  ctaContainer: null,
  secondaryCtaContainer: null,
  terms: {},
  renditionImageKey: '',
  analyticsMetadata: {},
  analyticsMetadataFromParent: {},
  keyCallOuts: [],
  hideTintDesktop: false,
  hideTintMobile: false,
  centerAlignContent: false,
  animateHighlightedText: true,
  isMobileFullInnerHeightRequired: true,
  jsObjectKey: '',
  tintColor: '',
  onTermsModalOpen: noop,
  onTermsModalClose: noop,
  enableBuyPointsCta: false,
  buyPointsCallToAction: {},
};

export default HeroBanner;
