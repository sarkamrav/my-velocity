import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import _ from 'lodash';

import Logo from './Logo';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME } from '../../utils/common';

import styles from './LogoList.css';

const LogoList = ({ numberOfTilesPerRow, logos, analyticsMetadata }) => {
  const analyticsMetadataKey = analyticsMetadata['analytics-metadata'];
  const [analyticsData, setAnalyticsData] = useState(analyticsMetadataKey);

  useEffect(() => {
    const commonAnalyticsData = window.vffCoreWebsite[analyticsMetadataKey] || {};

    setAnalyticsData(commonAnalyticsData);
  }, [analyticsMetadataKey]);

  return (
    <ErrorBoundary section={COMPONENT_NAME.logoList}>
      <ul
        className={cx(styles.container, {
          [styles.three]: numberOfTilesPerRow === 'three',
          [styles.four]: numberOfTilesPerRow === 'four',
          [styles.five]: numberOfTilesPerRow === 'five',
          [styles.six]: numberOfTilesPerRow === 'six',
        })}
        analytics-metadata={typeof analyticsData === 'string' ? analyticsData : JSON.stringify(analyticsData)}
      >
        {_.map(logos, (logo) => (
          <li key={logo.renditionImageKey} className={styles.logoContainer}>
            <Logo {...logo} analyticsMetadataFromParent={typeof analyticsData === 'string' ? {} : analyticsData} />
          </li>
        ))}
      </ul>
    </ErrorBoundary>
  );
};

LogoList.propTypes = {
  numberOfTilesPerRow: PropTypes.string,
  logos: PropTypes.arrayOf(PropTypes.shape({})),
  analyticsMetadata: PropTypes.shape({
    'analytics-metadata': PropTypes.string,
  }),
};

LogoList.defaultProps = {
  numberOfTilesPerRow: '',
  logos: [],
  analyticsMetadata: {},
};

export default LogoList;
