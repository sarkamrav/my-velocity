import React from 'react';
import LogoList from './LogoList';

/* eslint-disable camelcase */
import logoListMock from './mocks/LogoList.mock.json';
import logo_n22zhvzC from './mocks/logo_n22zhvzC.mock.json';
import logo_n22zhvzD from './mocks/logo_n22zhvzD.mock.json';
import logo_n22zhvzE from './mocks/logo_n22zhvzE.mock.json';
import logo_n22zhvzF from './mocks/logo_n22zhvzF.mock.json';
import logo_n22zhvzG from './mocks/logo_n22zhvzG.mock.json';
import logo_n22zhvzH from './mocks/logo_n22zhvzH.mock.json';
import logo_n22zhvzI from './mocks/logo_n22zhvzI.mock.json';
import { getPropsDataFromJsObjectKeyArray } from '../../utils/common';
/* eslint-enable camelcase */

const simulatedWindowObject = {
  uniqueImageTileKey: logoListMock,
  logo_n22zhvzC,
  logo_n22zhvzD,
  logo_n22zhvzE,
  logo_n22zhvzF,
  logo_n22zhvzG,
  logo_n22zhvzH,
  logo_n22zhvzI,
};

const props = getPropsDataFromJsObjectKeyArray(logoListMock, simulatedWindowObject, 'logos');

export default {
  title: 'Logo list',
};

export const AllTypes = () => <LogoList {...props} />;
