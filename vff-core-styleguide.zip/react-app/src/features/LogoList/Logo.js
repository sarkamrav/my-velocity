import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import styles from './Logo.css';

const Logo = ({
  imageRef,
  alt,
  linkUrl,
  openLinkInNewTab,
  renditionImageKey,
  analyticsMetadata,
  analyticsMetadataFromParent,
}) => {
  const image = <img src={imageRef} alt={alt} rendition-image={renditionImageKey} />;
  const [analyticsData, setAnalyticsData] = useState(analyticsMetadata['analytics-metadata']);

  useEffect(() => {
    const commonAnalyticsData = window.vffCoreWebsite[analyticsMetadata['analytics-metadata']] || {};

    setAnalyticsData({
      ...analyticsMetadataFromParent,
      ...commonAnalyticsData,
    });
  }, [analyticsMetadata, analyticsMetadataFromParent]);

  return linkUrl ? (
    <>
      {/* eslint-disable-next-line react/jsx-no-target-blank */}
      <a
        className={styles.container}
        href={linkUrl}
        title={alt}
        target={openLinkInNewTab ? '_blank' : '_self'}
        rel={openLinkInNewTab ? 'noopener noreferrer' : null}
        analytics-metadata={typeof analyticsData === 'string' ? analyticsData : JSON.stringify(analyticsData)}
      >
        {image}
      </a>
    </>
  ) : (
    <div className={styles.container}>{image}</div>
  );
};

Logo.propTypes = {
  imageRef: PropTypes.string,
  alt: PropTypes.string,
  linkUrl: PropTypes.string,
  openLinkInNewTab: PropTypes.bool,
  renditionImageKey: PropTypes.string,
  analyticsMetadata: PropTypes.shape({
    'analytics-metadata': PropTypes.string,
  }),
  analyticsMetadataFromParent: PropTypes.shape({}),
};

Logo.defaultProps = {
  imageRef: '',
  alt: '',
  linkUrl: '',
  openLinkInNewTab: false,
  renditionImageKey: '',
  analyticsMetadata: {},
  analyticsMetadataFromParent: {},
};

export default Logo;
