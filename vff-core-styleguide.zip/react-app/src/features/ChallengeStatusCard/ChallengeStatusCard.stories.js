import React from 'react';
import MockAdapter from 'axios-mock-adapter';

import { Provider } from 'react-redux';
import { configureStore } from '../../stores';
import { CHALLENGE_STATUSES } from '../../utils/common';

import ChallengeStatusCard from './ChallengeStatusCard';
import challengeStatusMock from './mocks/challenge-status.mock.json';
import apiResponseMock from './mocks/api-response.mock.json';
import api from '../../utils/api';

export default {
  title: 'ChallengeStatusCard',
};

const Template = (args) => {
  const { status, error, activationError, ...rest } = args;
  const mockVffV2Api = new MockAdapter(api.vffV2Api, { delayResponse: 1000 });

  if (error) {
    mockVffV2Api.onGet('/loyalty/v2/promotions/registrations?excludeBAUOffers=true').reply(500, {
      code: 40084,
      title: 'Unknown Error',
      status: 500,
      detail: "An unknown error has occurred in one of Virgin Australia's systems.",
    });
  } else {
    mockVffV2Api.onGet('/loyalty/v2/promotions/registrations?excludeBAUOffers=true').reply(200, {
      data: apiResponseMock[status] || [],
    });
  }

  if (activationError) {
    mockVffV2Api.onPost('/loyalty/v2/promotions/registrations').reply(500, {
      code: 40084,
      title: 'Unknown Error',
      status: 500,
      detail: "An unknown error has occurred in one of Virgin Australia's systems.",
    });
  } else {
    mockVffV2Api.onPost('/loyalty/v2/promotions/registrations').reply(200, {
      data: {
        type: 'REGISTRATION',
        id: '65407f4ca0942f5d3eb7d62b',
        promotionCode: 'UAT2023B1',
        promotionProvider: 'ADOBE',
        registrationDate: '2023-10-31T04:15:08.263Z',
        channel: 'WEB',
      },
    });
  }

  return (
    <Provider
      store={configureStore({
        user: {
          authenticated: true,
          member: {
            firstName: 'Srinath',
            lastName: 'Parthasarathy',
            loyaltyMembershipID: '1200867830',
            title: 'MR',
            preferredFirstName: 'Gourav',
            initials: 'GG',
            emailAddress: 'gourav.goyal@virginaustralia.com',
            dateOfBirth: '1992-09-11',
          },
        },
      })}
    >
      <ChallengeStatusCard {...rest} />
    </Provider>
  );
};

export const NotAcceptedChallenge = Template.bind({});
NotAcceptedChallenge.args = {
  ...challengeStatusMock,
  status: CHALLENGE_STATUSES.NOT_ACCEPTED,
};

export const AcceptedChallenge = Template.bind({});
AcceptedChallenge.args = {
  ...challengeStatusMock,
  status: CHALLENGE_STATUSES.ACCEPTED,
};

export const PreviouslyAcceptedChallenge = Template.bind({});
PreviouslyAcceptedChallenge.args = {
  ...challengeStatusMock,
  status: CHALLENGE_STATUSES.ACTIVITY_STARTED,
};

export const NotAcceptedChallengeBefore = Template.bind({});
NotAcceptedChallengeBefore.args = {
  ...challengeStatusMock,
  status: CHALLENGE_STATUSES.REGISTRATION_ENDED,
};

export const ChallengeEndedAcceptedChallenge = Template.bind({});
ChallengeEndedAcceptedChallenge.args = {
  ...challengeStatusMock,
  status: CHALLENGE_STATUSES.ACTIVITY_ENDED,
};

export const Ineligible = Template.bind({});
Ineligible.args = {
  ...challengeStatusMock,
  status: CHALLENGE_STATUSES.INELIGIBLE,
};

export const GetPromotionsError = Template.bind({});
GetPromotionsError.args = {
  ...challengeStatusMock,
  error: true,
};

export const ActivateChallengeError = Template.bind({});
ActivateChallengeError.args = {
  ...challengeStatusMock,
  status: CHALLENGE_STATUSES.NOT_ACCEPTED,
  activationError: true,
};
