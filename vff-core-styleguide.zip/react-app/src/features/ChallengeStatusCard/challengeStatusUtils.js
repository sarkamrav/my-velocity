import isEmpty from 'lodash/isEmpty';
import { DateTime } from 'luxon';
import { ACTIVATION_STATUSES, CHALLENGE_STATUSES, serverTimeZone } from '../../utils/common';

/**
 * filter out promotions based on promo codes and remove duplicated if any
 */
const getEligibleList = (promotionList = [], promoCodes = [], conditionStr = '') =>
  promotionList.reduce((acc, val) => {
    const duplicate = acc.find(({ promotionCode }) => promotionCode === val?.promotionCode);
    const isActive = val?.registrationStatus === conditionStr;
    const isChallengePromotion = promoCodes.includes(val.promotionCode);

    if (!duplicate && isActive && isChallengePromotion) {
      acc.push(val);
    }

    return acc;
  }, []);

/**
 * Eligibility check (for all 4 promo codes)
 */
const checkForPromoCodes = (eligiblePromotionList, promoCodes) =>
  promoCodes?.every((el) => eligiblePromotionList.includes(el));

/**
 * Date from server timezone
 */
const getServerDateTime = (targetDate) => DateTime.fromISO(targetDate, serverTimeZone);

/**
 * status check based on condition
 */
export const getStatus = ({ promotionListData: promotionList = [], promoCode = '', childPromoCodes = [] }) => {
  if (!isEmpty(promotionList) && !isEmpty(childPromoCodes) && promoCode) {
    const promoCodes = [...childPromoCodes, promoCode];
    const currentDate = DateTime.fromObject({}, serverTimeZone);

    // Challenge Not Accepted
    const registrablePromotions = getEligibleList(promotionList, promoCodes, ACTIVATION_STATUSES.ACTIVE);
    const hasAllRegistrablePromoCodes = checkForPromoCodes(
      registrablePromotions.map((el) => el.promotionCode),
      promoCodes,
    );

    if (!isEmpty(registrablePromotions) && hasAllRegistrablePromoCodes) {
      const mainPromotion = registrablePromotions.find((el) => el.promotionCode === promoCode) || {};
      const registrationEndDate = getServerDateTime(mainPromotion?.registrationEndDate).endOf('day');
      const promotionDetails = {
        promotion: mainPromotion,
        promotions: registrablePromotions,
      };

      if (hasAllRegistrablePromoCodes && currentDate <= registrationEndDate) {
        return {
          ...promotionDetails,
          status: CHALLENGE_STATUSES.NOT_ACCEPTED,
        };
      }

      if (hasAllRegistrablePromoCodes && currentDate > registrationEndDate) {
        return {
          ...promotionDetails,
          status: CHALLENGE_STATUSES.REGISTRATION_ENDED,
        };
      }
    }

    // Challenge Accepted
    const registeredPromotions = getEligibleList(promotionList, promoCodes, ACTIVATION_STATUSES.REGISTERED);
    const hasAllRegisteredPromoCodes = checkForPromoCodes(
      registeredPromotions.map((el) => el.promotionCode),
      promoCodes,
    );

    if (!isEmpty(registeredPromotions) && hasAllRegisteredPromoCodes) {
      const mainPromotion = registeredPromotions.find((el) => el.promotionCode === promoCode) || {};
      const registrationEndDate = getServerDateTime(mainPromotion?.registrationEndDate).endOf('day');
      const activityEndDate = getServerDateTime(mainPromotion?.activityEndDate).endOf('day');
      const activityStartDate = getServerDateTime(mainPromotion?.activityStartDate).startOf('day');
      const promotionDetails = {
        promotion: mainPromotion,
        promotions: registeredPromotions,
      };

      if (hasAllRegisteredPromoCodes && currentDate <= registrationEndDate) {
        return {
          ...promotionDetails,
          status: CHALLENGE_STATUSES.ACCEPTED,
        };
      }

      if (hasAllRegisteredPromoCodes && currentDate > activityEndDate) {
        return {
          ...promotionDetails,
          status: CHALLENGE_STATUSES.ACTIVITY_ENDED,
        };
      }

      if (hasAllRegisteredPromoCodes && currentDate > activityStartDate) {
        return {
          ...promotionDetails,
          status: CHALLENGE_STATUSES.ACTIVITY_STARTED,
        };
      }
    }
  }

  return { status: CHALLENGE_STATUSES.INELIGIBLE };
};
