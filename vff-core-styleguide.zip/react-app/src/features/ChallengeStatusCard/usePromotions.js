import { useCallback, useEffect, useState } from 'react';

import * as userData from '../../stores/utilities';
import api from '../../utils/api';

import { getStatus } from './challengeStatusUtils';

const usePromotions = ({ user, promoCode, childPromoCodes, setChallengeStatus }) => {
  const hasLoggedIn = userData.getHasLoggedIn(user);

  const [promotionList, setPromotionList] = useState([]);
  const [currentPromotion, setCurrentPromotion] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const getPromotionStatus = useCallback(async () => {
    const getPromotions = '/loyalty/v2/promotions/registrations';
    const excludeBauOffers = '?excludeBAUOffers=true';
    const url = `${getPromotions}${excludeBauOffers}`;

    try {
      const response = await api.vffV2Api.get(url);
      const promotionListData = response?.data?.data;
      const {
        status,
        promotion = {},
        promotions = [],
      } = getStatus({
        promotionListData,
        promoCode,
        childPromoCodes,
      });

      setPromotionList(promotions);
      setCurrentPromotion(promotion);
      setChallengeStatus(status);
      setLoading(false);
    } catch (err) {
      setLoading(false);
      setError(err);
    }
  }, [promoCode, childPromoCodes, setChallengeStatus]);

  useEffect(() => {
    if (hasLoggedIn) {
      getPromotionStatus();
    }
  }, [hasLoggedIn, getPromotionStatus]);

  return { loading, promotionList, currentPromotion, error };
};

export default usePromotions;
