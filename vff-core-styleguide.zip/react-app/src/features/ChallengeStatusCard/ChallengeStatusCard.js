import React, { useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';

import Button from '../../components/Button/Button';
import CountDownTimer from '../../components/CountDownTimer/CountDownTimer';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import Loading from '../../components/Loading/Loading';
import MessageTile, { messageTileTheme } from '../../components/MessageTile/MessageTile';
import * as userData from '../../stores/utilities';
import syncText from '../../utils/syncText';
import usePromotions from './usePromotions';
import api from '../../utils/api';
import { CHALLENGE_STATUSES } from '../../utils/common';

import styles from './ChallengeStatusCard.css';

const ChallengeStatusCard = (props) => {
  const { imageRef, terms, user, errorMessages, promoCode, childPromoCodes } = props;

  const [activateChallengeLoader, setActivateChallengeLoader] = useState(false);
  const [activateChallengeError, setActivateChallengeError] = useState(null);
  const [challengeStatus, setChallengeStatus] = useState('');

  const { [challengeStatus]: { title, description, timerDetails, ctaContainer } = {} } = props;
  const { ctaTitle, ctaLabel, ctaType, ctaUrl, ctaOpenInNewTab } = ctaContainer || {};
  const { loading, currentPromotion, promotionList, error } = usePromotions({
    user,
    promoCode,
    childPromoCodes,
    setChallengeStatus,
  });

  const textSync = useCallback(
    (text) => {
      const firstName = userData.getFirstName(user);
      const lastName = userData.getLastName(user);
      const { registrationEndDate, activityStartDate, activityEndDate } = currentPromotion;

      return syncText(
        text,
        {
          firstName,
          lastName,
          registrationEndDate,
          activityStartDate,
          activityEndDate,
        },
        'dd MMMM',
      );
    },
    [user, currentPromotion],
  );

  const onTimerZero = useCallback(() => {
    setChallengeStatus(CHALLENGE_STATUSES?.ACTIVITY_STARTED);
  }, []);

  const activateOffer = useCallback(async () => {
    const promotionApiUrl = '/loyalty/v2/promotions/registrations';
    const membershipId = userData.getLoyaltyMembershipID(user);

    setActivateChallengeError(null);
    setActivateChallengeLoader(true);
    try {
      await Promise.all(
        promotionList?.map(({ promotionCode, promotionProvider }) =>
          api.vffV2Api.post(promotionApiUrl, {
            data: {
              promotionCode,
              promotionProvider,
              memberId: membershipId,
            },
          }),
        ),
      );

      setActivateChallengeLoader(false);
      setChallengeStatus(CHALLENGE_STATUSES?.ACCEPTED);
    } catch (err) {
      setActivateChallengeError(true);
      setActivateChallengeLoader(false);
    }
  }, [user, promotionList]);

  const onButtonClick = useCallback(() => {
    if (challengeStatus === CHALLENGE_STATUSES?.NOT_ACCEPTED) {
      activateOffer();
    } else {
      window.open(ctaUrl, ctaOpenInNewTab ? '_blank' : '_self');
    }
  }, [challengeStatus, ctaUrl, ctaOpenInNewTab, activateOffer]);

  const termsTarget = terms?.ctaOpenInNewTab ? '_blank' : '_self';

  return (
    <section className={styles.container}>
      <div className={styles.challengeStatusBanner} style={{ backgroundImage: `url(${imageRef})` }} />
      <div className={styles.challengeStatusContainer}>
        {loading && <Loading />}

        {!loading && error && (
          <MessageTile theme={messageTileTheme.error} description={errorMessages?.defaultErrorMessage?.description} />
        )}

        {!loading && !error && challengeStatus && currentPromotion && (
          <>
            <h2 className={styles.challengeTitle}>{textSync(title)}</h2>
            <RichTextContent className={styles.challengeDescription} content={textSync(description)} />

            {timerDetails && (
              <div className={styles.counterContainer}>
                <CountDownTimer targetDate={currentPromotion?.registrationEndDate} callback={onTimerZero} />
                <RichTextContent
                  className={styles.challengeTimerDescription}
                  content={textSync(timerDetails.description)}
                />
              </div>
            )}

            <Button
              className={styles.challengeButton}
              buttonType={ctaType}
              ariaLabelText={ctaTitle}
              onClick={onButtonClick}
              loading={activateChallengeLoader}
              disabled={activateChallengeLoader}
            >
              {ctaLabel}
            </Button>
            {activateChallengeError && (
              <RichTextContent
                className={styles.activateChallengeError}
                content={errorMessages?.defaultErrorMessage?.description}
              />
            )}

            <a
              href={terms?.ctaUrl}
              title={terms?.ctaTitle}
              target={termsTarget}
              rel={termsTarget === '_blank' ? 'noopener noreferrer' : null}
            >
              {terms?.ctaLabel}
            </a>
          </>
        )}
      </div>
    </section>
  );
};

ChallengeStatusCard.propTypes = {
  imageRef: PropTypes.string,
  terms: PropTypes.shape({
    ctaTitle: PropTypes.string,
    ctaUrl: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaLabel: PropTypes.string,
  }),
  user: PropTypes.shape({
    firstName: PropTypes.string,
    lastName: PropTypes.string,
  }),
  status: PropTypes.string,
  errorMessages: PropTypes.shape({
    defaultErrorMessage: PropTypes.shape({
      description: PropTypes.string,
    }),
  }),
  promoCode: PropTypes.string,
  childPromoCodes: PropTypes.arrayOf(PropTypes.string),
};

ChallengeStatusCard.defaultProps = {
  imageRef: '',
  terms: {
    ctaTitle: '',
    ctaUrl: '',
    ctaOpenInNewTab: false,
    ctaLabel: '',
  },
  user: null,
  status: '',
  errorMessages: {
    defaultErrorMessage: {
      description: 'Sorry, we&apos;re having issues with our system.',
    },
  },
  promoCode: '',
  childPromoCodes: [],
};

export default connect(({ user }) => ({ user }))(ChallengeStatusCard);
