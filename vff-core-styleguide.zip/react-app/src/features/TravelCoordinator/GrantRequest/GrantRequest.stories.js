import React from 'react';
import MockAdapter from 'axios-mock-adapter';

import api from '../../../utils/api';
import GrantRequest from './GrantRequest';
import GrantRequestMock from '../mocks/GrantRequest.mock.json';

export default {
  title: 'Grant Request',
};

const GrantRequestUri = '/loyalty/v2/grants/travel-coordinator';

export const Success = () => {
  const vffV2ApiNoToken = new MockAdapter(api.vffV2ApiNoToken, { delayResponse: 500 });

  vffV2ApiNoToken.onPatch(GrantRequestUri).reply(200, {
    data: {
      id: '6232b6a3b1c9b0e45f0a2f1b',
      createdDateTime: '2022-04-21T02:49:23.909Z',
      lastModifiedDateTime: '2022-04-21T02:53:03.045Z',
      from: {
        membershipId: '0000389440',
        firstName: 'PONSAK',
        lastName: 'SEPTEMBER',
      },
      to: {
        membershipId: '0000427776',
        firstName: 'ANDREW',
        lastName: 'MARKRAM',
      },
      status: 'PENDING_FOR_TC',
      accessLevel: 'FULL_ACCESS',
      validity: {
        startingAt: '2022-03-17T00:00:00.000Z',
        endingAt: '2024-03-17T03:48:00.000Z',
      },
    },
  });
  return <GrantRequest {...GrantRequestMock} />;
};

Success.storyName = 'Successful - pending for Travel Coordinator';

export const SuccessScenrioTwo = () => {
  const vffV2ApiNoToken = new MockAdapter(api.vffV2ApiNoToken, { delayResponse: 500 });

  vffV2ApiNoToken.onPatch(GrantRequestUri).reply(200, {
    data: {
      id: '6232b6a3b1c9b0e45f0a2f1b',
      createdDateTime: '2022-04-21T02:49:23.909Z',
      lastModifiedDateTime: '2022-04-21T02:53:03.045Z',
      from: {
        membershipId: '0000389440',
        firstName: 'PONSAK',
        lastName: 'SEPTEMBER',
      },
      to: {
        membershipId: '0000427776',
        firstName: 'ANDREW',
        lastName: 'MARKRAM',
      },
      status: 'PENDING_FOR_MEMBER',
      accessLevel: 'FULL_ACCESS',
      validity: {
        startingAt: '2022-03-17T00:00:00.000Z',
        endingAt: '2024-03-17T03:48:00.000Z',
      },
    },
  });
  return <GrantRequest {...GrantRequestMock} />;
};

SuccessScenrioTwo.storyName = 'Successful - pending for Member';

export const SuccessScenrioThree = () => {
  const vffV2ApiNoToken = new MockAdapter(api.vffV2ApiNoToken, { delayResponse: 500 });

  vffV2ApiNoToken.onPatch(GrantRequestUri).reply(200, {
    data: {
      id: '6232b6a3b1c9b0e45f0a2f1b',
      createdDateTime: '2022-04-21T02:49:23.909Z',
      lastModifiedDateTime: '2022-04-21T02:53:03.045Z',
      from: {
        membershipId: '0000389440',
        firstName: 'PONSAK',
        lastName: 'SEPTEMBER',
      },
      to: {
        membershipId: '0000427776',
        firstName: 'ANDREW',
        lastName: 'MARKRAM',
      },
      status: 'ACTIVE',
      accessLevel: 'FULL_ACCESS',
      validity: {
        startingAt: '2022-03-17T00:00:00.000Z',
        endingAt: '2024-03-17T03:48:00.000Z',
      },
    },
  });
  return <GrantRequest {...GrantRequestMock} />;
};

SuccessScenrioThree.storyName = 'Successful - ACTIVE';

export const Error = () => {
  const vffV2ApiNoToken = new MockAdapter(api.vffV2ApiNoToken, { delayResponse: 500 });

  vffV2ApiNoToken.onPatch(GrantRequestUri).reply(500, {
    code: 4154,
    title: 'Bad Request',
    detail: 'The token has expired.',
    status: 400,
  });

  return <GrantRequest {...GrantRequestMock} />;
};

Error.storyName = 'Generic Error - Bad Request';

export const ErrorScenarioOne = () => {
  const vffV2ApiNoToken = new MockAdapter(api.vffV2ApiNoToken, { delayResponse: 500 });

  vffV2ApiNoToken.onPatch(GrantRequestUri).reply(500, {
    code: 4155,
    title: 'Link Expired',
    detail: 'Your link has expired',
    status: 400,
  });

  return <GrantRequest {...GrantRequestMock} />;
};

ErrorScenarioOne.storyName = 'Error - Link Expired';
