import React, { useEffect, useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import qs from 'qs';
import _ from 'lodash';

import ErrorBoundary from '../../../components/ErrorBoundary/ErrorBoundary';
import RichTextContent from '../../../components/RichTextContent/RichTextContent';
import { COMPONENT_NAME } from '../../../utils/common';
import api from '../../../utils/api';
import Loading from '../../../components/Loading/Loading';
import styles from './GrantRequest.css';

/**
 * Grant Request page allows member to grant the access to travel coordinators by
 * approving the grant and accepting T&Cs and to accept the member grant by approving the grant and accepting T&Cs
 * @param {Object} successMessages
 * @param {Object} errorMessages
 * @returns GrantRequest
 */
const GrantRequest = ({ successMessages, errorMessages }) => {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState({
    title: '',
    description: '',
  });

  const travelCoordinatorUri = '/loyalty/v2/grants/travel-coordinator';

  const querystring = qs.parse(window.location.search, { ignoreQueryPrefix: true });
  const tokenInUrl = querystring.token;

  // `fetchGrantRequestData` used to make a PATCH request and fetch the API response to display description based on status attribute
  const fetchGrantRequestData = useCallback(async () => {
    try {
      setLoading(true);
      const response = await api.vffV2ApiNoToken.patch(travelCoordinatorUri, {
        data: {
          termsAndConditionsAccepted: true,
          token: tokenInUrl,
        },
      });
      const status = _.get(response, 'data.data.status');
      const _data = _.find(successMessages.apiSuccessMessages, (successData) => successData?.status === status);
      setData({
        title: _data?.title || successMessages.defaultSuccessMessage?.title,
        description: _data?.description || successMessages.defaultSuccessMessage?.description,
      });
      setLoading(false);
    } catch (error) {
      const code = _.get(error, 'response.data.code', '');
      const errorMessage = _.find(errorMessages.apiErrorMessages, (_errorMessages) => _errorMessages?.code === code);
      setData({
        title: errorMessage?.title || errorMessages.defaultErrorMessage?.title,
        description: errorMessage?.description || errorMessages.defaultErrorMessage?.description,
      });
      setLoading(false);
    }
  }, [errorMessages, successMessages, tokenInUrl]);

  useEffect(() => {
    fetchGrantRequestData();
  }, [fetchGrantRequestData]);

  return loading ? (
    <div className={styles.loadingContainer}>
      <Loading />
    </div>
  ) : (
    <ErrorBoundary section={COMPONENT_NAME.grantRequest}>
      <div className={styles.container}>
        {data?.title && <h4 className={styles.heading}>{data?.title}</h4>}
        {data?.description && <RichTextContent className={styles.richText} content={data?.description} />}
      </div>
    </ErrorBoundary>
  );
};

GrantRequest.propTypes = {
  errorMessages: PropTypes.shape({
    defaultErrorMessage: PropTypes.shape({
      title: PropTypes.string,
      description: PropTypes.string,
    }).isRequired,
    apiErrorMessages: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
  }).isRequired,
  successMessages: PropTypes.shape({
    defaultSuccessMessage: PropTypes.shape({
      title: PropTypes.string,
      description: PropTypes.string,
    }).isRequired,
    apiSuccessMessages: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
  }).isRequired,
};

export default GrantRequest;
