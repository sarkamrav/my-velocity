import React from 'react';
import cx from 'classnames';
import get from 'lodash/get';
import PropTypes from 'prop-types';
import { DateTime } from 'luxon';

import { serverTimeZone } from '../../../utils/common';
import * as STRINGS from './flow_constants';
import TravelCoordinatorIcon from '../../../images/travel-coordinator-icon.png';
import styles from './TravelCoordinatorList.css';

const TravelCoordinatorListTile = ({ data, iconUrl }) => {
  const { to, validity, status } = data;

  return (
    <div className={styles.travelCoordinatorTile}>
      <div className={styles.imageWrapper}>
        <img src={iconUrl} alt="travel-coordinator-icon" />
        <div>
          <p className={styles.detail}>{STRINGS.NAME}</p>
          <p className={styles.value}>{`${to.firstName} ${to.lastName}`}</p>
        </div>
      </div>
      <div>
        <p className={styles.detail}>{STRINGS.TRAVEL_COORDINATOR_ID}</p>
        <p className={styles.value}>{to.membershipId}</p>
      </div>
      <div>
        <p className={styles.detail}>{STRINGS.VALID_UNTIL}</p>
        <p className={styles.value}>{DateTime.fromISO(validity.endingAt, serverTimeZone).toFormat('dd LLL yyyy')}</p>
      </div>
      <div className={styles.statusWrapper}>
        <p className={styles.detail}>{STRINGS.STATUS}</p>
        <p
          className={cx(styles.value, styles.status)}
          style={{
            backgroundColor: get(STRINGS.STATUS_BG_COLOR, status),
            color: get(STRINGS.STATUS_TEXT_COLOR, status),
          }}
        >
          {status}
        </p>
      </div>
    </div>
  );
};

export default TravelCoordinatorListTile;

TravelCoordinatorListTile.propTypes = {
  data: PropTypes.shape({
    status: PropTypes.string,
    to: PropTypes.shape({
      membershipId: PropTypes.string,
      firstName: PropTypes.string,
      lastName: PropTypes.string,
    }),
    validity: PropTypes.shape({
      endingAt: PropTypes.string,
    }),
  }),
  iconUrl: PropTypes.string,
};

TravelCoordinatorListTile.defaultProps = {
  data: {
    status: '',
    to: {
      membershipId: '',
      firstName: '',
      lastName: '',
    },
    validity: {
      endingAt: '',
    },
  },
  iconUrl: TravelCoordinatorIcon,
};
