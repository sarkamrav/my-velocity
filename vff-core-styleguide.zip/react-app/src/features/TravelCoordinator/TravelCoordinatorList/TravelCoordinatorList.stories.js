import React from 'react';
import MockAdapter from 'axios-mock-adapter';
import { Provider } from 'react-redux';

import TravelCoordinatorListMock from '../mocks/TravelCoordinatorList.mock.json';
import api from '../../../utils/api';
import { configureStore } from '../../../stores';
import { STATUS_DETAIL } from './flow_constants';
import TravelCoordinatorList from './TravelCoordinatorList';

export default {
  title: 'Velocity Travel Coordinator',
};

const travelCoordinatorListUri = `/loyalty/v2/grants/travel-coordinator?status=${STATUS_DETAIL.toString()}`;

export const TravelCoordinatorApiError = () => {
  const mockVffV2Api = new MockAdapter(api.vffV2Api, { delayResponse: 2000 });
  mockVffV2Api.onGet(travelCoordinatorListUri).reply(400, {
    code: 38663,
    title: 'No matching grant found.',
    status: 404,
  });

  return (
    <Provider
      store={configureStore({
        user: {
          authenticated: true,
          memberDataLoaded: true,
          memberDataLoading: false,
        },
      })}
    >
      <TravelCoordinatorList {...TravelCoordinatorListMock} />
    </Provider>
  );
};

TravelCoordinatorApiError.storyName = 'Travel Coordinator - API Generic error';

export const TravelCoordinatorNoData = () => {
  const mockVffV2Api = new MockAdapter(api.vffV2Api, { delayResponse: 2000 });
  mockVffV2Api.onGet(travelCoordinatorListUri).reply(200, {
    data: [],
  });

  return (
    <Provider
      store={configureStore({
        user: {
          authenticated: true,
          memberDataLoaded: true,
          memberDataLoading: false,
        },
      })}
    >
      <TravelCoordinatorList {...TravelCoordinatorListMock} />
    </Provider>
  );
};

TravelCoordinatorNoData.storyName = 'Travel Coordinator - No Data';

export const TravelCoordinatorData = () => {
  const mockVffV2Api = new MockAdapter(api.vffV2Api, { delayResponse: 2000 });
  mockVffV2Api.onGet(travelCoordinatorListUri).reply(200, {
    data: [
      {
        id: '6260c633a1ceb0e41f6614b2',
        createdDateTime: '2022-04-21T02:49:23.909Z',
        lastModifiedDateTime: '2022-04-21T02:53:03.045Z',
        from: {
          membershipId: '0000389440',
          firstName: 'PONSAK',
          lastName: 'SEPTEMBER',
        },
        to: {
          membershipId: '0000361703',
          firstName: 'TESTTRAVELCOORDINATOR',
          lastName: 'HJKHJYUVGVBBHN',
        },
        status: 'ACTIVE',
        accessLevel: 'FULL_ACCESS',
        validity: {
          startingAt: '2022-04-23T14:00:00.000Z',
          endingAt: '2024-04-23T03:48:00.000Z',
        },
      },
      {
        id: '6260c633a1ceb0e41f6614c2',
        createdDateTime: '2022-04-21T02:49:23.909Z',
        lastModifiedDateTime: '2022-04-21T02:53:03.045Z',
        from: {
          membershipId: '0000389440',
          firstName: 'PONSAK',
          lastName: 'SEPTEMBER',
        },
        to: {
          membershipId: '0000361703',
          firstName: 'TESTTRAVELCOORDINATOR',
          lastName: 'HJKHJYUVGVBBHN',
        },
        status: 'DEACTIVATED',
        accessLevel: 'FULL_ACCESS',
        validity: {
          startingAt: '2022-04-23T14:00:00.000Z',
          endingAt: '2024-04-23T03:48:00.000Z',
        },
      },
    ],
  });

  return (
    <Provider
      store={configureStore({
        user: {
          authenticated: true,
          memberDataLoaded: true,
          memberDataLoading: false,
        },
      })}
    >
      <TravelCoordinatorList {...TravelCoordinatorListMock} />
    </Provider>
  );
};

TravelCoordinatorData.storyName = 'Travel Coordinator - With Data';

export const MemberProfileApiLoading = () => (
  <Provider
    store={configureStore({
      user: {
        memberDataLoaded: false,
        memberDataLoading: true,
        authenticated: false,
      },
    })}
  >
    <TravelCoordinatorList {...TravelCoordinatorListMock} />
  </Provider>
);

export const MemberProfileApiFailed = () => (
  <Provider
    store={configureStore({
      user: {
        memberDataLoaded: false,
        memberDataLoading: false,
        memberDataLoadError: true,
        authenticated: false,
      },
    })}
  >
    <TravelCoordinatorList {...TravelCoordinatorListMock} />
  </Provider>
);
