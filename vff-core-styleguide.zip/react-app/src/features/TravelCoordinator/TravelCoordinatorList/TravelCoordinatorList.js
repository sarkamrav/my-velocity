import React, { useState, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import _ from 'lodash';

import api from '../../../utils/api';
import * as STRINGS from './flow_constants';
import ErrorBoundary from '../../../components/ErrorBoundary/ErrorBoundary';
import RichTextContent from '../../../components/RichTextContent/RichTextContent';
import { COMPONENT_NAME } from '../../../utils/common';
import Loading from '../../../components/Loading/Loading';
import VelocityTravelCoordinatorTile from './TravelCoordinatorListTile';
import MessageTile, { messageTileTheme } from '../../../components/MessageTile/MessageTile';
import { getHasLoggedIn, getMemberDataLoadError, getMemberDataLoading } from '../../../stores/utilities';

import styles from './TravelCoordinatorList.css';

/**
 * TravelCoordinator List page shows the information about the travel coodinator
 * that the member link in their account and their status
 * @param {Object} emptyState
 * @param {Object} nonEmptyState
 * @param {Object} errorMessages
 * @returns TravelCoordinatorList
 */

const TravelCoordinatorList = ({ emptyState, nonEmptyState, errorMessages, user }) => {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [error, setError] = useState(null);

  const travelCoordinatorListUri = `/loyalty/v2/grants/travel-coordinator?status=${STRINGS.STATUS_DETAIL.toString()}`;

  const fetchTravelCoordinatorData = useCallback(async () => {
    try {
      setLoading(true);
      const response = await api.vffV2Api.get(travelCoordinatorListUri);
      const responseData = _.get(response, 'data.data');
      const sortedData = _.orderBy(responseData, ['status', 'validity.endingAt']);
      setData([...sortedData]);
      setLoading(false);
    } catch (err) {
      const errorCode = _.get(err, 'response.data.code');
      const getApiError =
        _.find(errorMessages.apiErrorMessages, (_errorData) => _errorData.code === errorCode) ||
        errorMessages?.defaultErrorMessage;
      setError(getApiError);
      setLoading(false);
    }
  }, [errorMessages, travelCoordinatorListUri]);

  const hasLoggedIn = getHasLoggedIn(user);
  const memberDataLoading = getMemberDataLoading(user);
  const memberDataLoadError = getMemberDataLoadError(user);

  useEffect(() => {
    if (hasLoggedIn) {
      fetchTravelCoordinatorData();
    }
  }, [fetchTravelCoordinatorData, hasLoggedIn]);

  useEffect(() => {
    if (memberDataLoadError) {
      setLoading(false);
    }
  }, [memberDataLoadError]);

  const memberDataError = !memberDataLoading && memberDataLoadError;

  return (
    <ErrorBoundary section={COMPONENT_NAME.travelCoordinatorList}>
      {((loading && !error) || (memberDataLoading && !memberDataLoadError)) && (
        <div className={styles.loadingContainer}>
          <Loading />
        </div>
      )}

      {memberDataError && (
        <div className={styles.wrapper}>
          <MessageTile theme={messageTileTheme.error} description="Sorry, we're having issues with our system." />
        </div>
      )}

      {!loading && error && !memberDataError && (
        <div className={styles.errorContainer}>
          <h4 className={styles.heading}>{error?.title}</h4>
          <RichTextContent className={styles.richText} content={error?.description} />
        </div>
      )}

      {!loading && !error && !memberDataError && (
        <div className={styles.container}>
          <div className={styles.topWrapper}>
            <div className={styles.topImage}>
              <img src={data?.length ? nonEmptyState?.iconUrl : emptyState?.iconUrl} alt="travel-coordinator-icon" />
            </div>
            <h4 className={styles.heading}>{data?.length ? nonEmptyState?.title : emptyState?.title}</h4>
            <RichTextContent
              className={styles.richText}
              content={data?.length ? nonEmptyState?.description : emptyState?.description}
            />
          </div>

          {!!data?.length && (
            <div className={styles.travelCoordinators}>
              {_.map(data, (item) => (
                <VelocityTravelCoordinatorTile key={item.id} data={item} iconUrl={nonEmptyState?.iconUrl} />
              ))}
            </div>
          )}
        </div>
      )}
    </ErrorBoundary>
  );
};

TravelCoordinatorList.propTypes = {
  errorMessages: PropTypes.shape({
    defaultErrorMessage: PropTypes.shape({
      title: PropTypes.string,
      description: PropTypes.string,
    }).isRequired,
    apiErrorMessages: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
  }).isRequired,
  emptyState: PropTypes.shape({
    title: PropTypes.string,
    description: PropTypes.string,
    iconUrl: PropTypes.string,
  }),
  nonEmptyState: PropTypes.shape({
    title: PropTypes.string,
    description: PropTypes.string,
    iconUrl: PropTypes.string,
  }),
  user: PropTypes.shape({
    authenticated: PropTypes.bool,
  }),
};

TravelCoordinatorList.defaultProps = {
  emptyState: {
    title: '',
    description: '',
    iconUrl: '',
  },
  nonEmptyState: {
    title: '',
    description: '',
    iconUrl: '',
  },
  user: null,
};

export default connect((state) => ({
  user: state.user,
}))(TravelCoordinatorList);
