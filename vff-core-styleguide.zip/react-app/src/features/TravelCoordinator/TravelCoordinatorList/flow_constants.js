// All the constants declared through out TravelCoordinatorList component can be declared and imported from flow_constants

export const NAME = 'Name';
export const TRAVEL_COORDINATOR_ID = 'Travel Coordinator ID';
export const VALID_UNTIL = 'Valid until';
export const STATUS = 'Status';

export const STATUS_DETAIL = ['ACTIVE', 'DEACTIVATED'];

export const STATUS_TEXT_COLOR = {
  ACTIVE: '#198050',
  DEACTIVATED: '#C77B00',
};

export const STATUS_BG_COLOR = {
  ACTIVE: '#D6EBE2',
  DEACTIVATED: '#F7F2EB',
};
