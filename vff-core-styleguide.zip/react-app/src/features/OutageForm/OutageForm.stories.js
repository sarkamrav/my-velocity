import React from 'react';
import MockAdapter from 'axios-mock-adapter';
import styles from '@sambego/storybook-styles';

import OutageForm from './OutageForm';
import api from '../../utils/api';
import mock from './mocks/outageForm.mock.json';

export default {
  title: 'Outage Form',
  decorators: [
    styles({
      backgroundColor: '#f9f9f9',
    }),
  ],
};

export const FormSubmissionSuccess = () => {
  const mockVFFApiNoKeycloak = new MockAdapter(api.vffApiNoKeycloak, { delayResponse: 1000 });

  mockVFFApiNoKeycloak.onPost('/loyalty/v2/members/prospects').reply(200);

  return <OutageForm {...mock} />;
};

FormSubmissionSuccess.storyName = 'submission success';

export const FormSubmissionError = () => {
  const mockVFFApiNoKeycloak = new MockAdapter(api.vffApiNoKeycloak, { delayResponse: 1000 });

  mockVFFApiNoKeycloak.onPost('/loyalty/v2/members/prospects').reply(400);

  return <OutageForm {...mock} />;
};

FormSubmissionError.storyName = 'submission error';
