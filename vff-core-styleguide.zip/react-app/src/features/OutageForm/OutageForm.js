import React, { useCallback, useEffect, useRef, useState } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import difference from 'lodash/difference';
import isUndefined from 'lodash/isUndefined';
import every from 'lodash/every';
import omit from 'lodash/omit';
import includes from 'lodash/includes';
import Input from '@components/Form/Input/Input';
import Select from '@components/Form/Select/Select';
import Button from '@components/Button/Button';
import MessageTile, { messageTileTheme } from '@components/MessageTile/MessageTile';
import { validateFormField } from '@components/Form/utils';
import * as validate from '@components/Form/validators';
import { COMPONENT_NAME, scrollToRef } from '@utils/common';
import ErrorBoundary from '@components/ErrorBoundary/ErrorBoundary';
import TopContentContainer, {
  contentContainerType,
} from '@components/Form/containers/TopContentContainer/TopContentContainer';
import RichTextContent from '@components/RichTextContent/RichTextContent';
import FormContainer, {
  formContainerColor,
  formContainerType,
} from '@components/Form/containers/FormContainer/FormContainer';
import FormContentContainer from '@components/Form/containers/FormContentContainer/FormContentContainer';
import FormFieldContainer from '@components/Form/containers/FormFieldContainer/FormFieldContainer';
import FormRow from '@components/Form/containers/FormRow/FormRow';
import Checkbox from '@components/Form/Checkbox/Checkbox';
import InfoTile from '@components/InfoTile/InfoTile';
import api from '@utils/api';
import useEmailApiValidation from '@hooks/useEmailApiValidation';
import { personTitleOptions } from '../JoinPage/referenceData';
import ConditionsText from '../JoinPage/components/ConditionsText/ConditionsText';
import styles from './OutageForm.css';

const formFieldNames = {
  title: 'title',
  firstName: 'firstName',
  lastName: 'lastName',
  email: 'email',
  termsAndConditions: 'termsAndConditions',
};

const fieldValidators = {
  [formFieldNames.title]: [validate.required('Title is required')],
  [formFieldNames.firstName]: [validate.required('First name is required'), validate.name('Invalid first name')],
  [formFieldNames.lastName]: [validate.required('Last name is required'), validate.name('Invalid last name')],
  [formFieldNames.email]: [
    validate.required('Email is required'),
    validate.email('The email address you have entered is incomplete or invalid'),
  ],
  [formFieldNames.termsAndConditions]: [validate.required('Terms and conditions is required')],
};

const initialValues = {
  [formFieldNames.title]: null,
  [formFieldNames.firstName]: '',
  [formFieldNames.lastName]: '',
  [formFieldNames.email]: '',
  [formFieldNames.termsAndConditions]: false,
};

const mandatoryFields = [
  formFieldNames.title,
  formFieldNames.firstName,
  formFieldNames.lastName,
  formFieldNames.email,
  formFieldNames.termsAndConditions,
];

const OutageForm = ({
  defaultErrorMessage,
  successMessage,
  infoBox,
  title,
  termsAndConditions,
  privacyInformation,
  checkboxTnc,
  ctaContainer,
}) => {
  const [values, setValues] = useState(initialValues);
  const [touchedFields, setTouchedFields] = useState([]);
  const [errors, setErrors] = useState({});

  const [apiPosting, setApiPosting] = useState(false);
  const [apiError, setApiError] = useState(false);
  const [apiSuccess, setApiSuccess] = useState(false);

  const successMessageRef = useRef({});
  const errorMessageRef = useRef({});

  const { error: emailApiError, loading: emailApiLoading } = useEmailApiValidation(values);

  const setFieldValue = (fieldName, fieldValue) => {
    setValues((prevState) => ({
      ...prevState,
      [fieldName]: fieldValue,
    }));
  };

  // Validates field and returns an error message if it is invalid
  const validateField = useCallback(
    (fieldName, fieldValue) => validateFormField(fieldValue, fieldValidators[fieldName], values),
    [values],
  );

  // Runs and applies field validation
  const runFieldValidation = useCallback(
    (fieldName, fieldValue) => {
      const error = validateField(fieldName, fieldValue);

      if (error) {
        setErrors((currentErrors) => ({
          ...currentErrors,
          [fieldName]: error,
        }));
      } else {
        setErrors((currentErrors) => omit(currentErrors, [fieldName]));
      }
    },
    [validateField],
  );

  const handleFieldChange = useCallback(
    (fieldName) => (newValue) => {
      // Set value
      setFieldValue(fieldName, newValue);

      // Give immediate error feedback for fields that are already touched
      const isTouched = includes(touchedFields, fieldName);

      const isLastMandatoryFieldNotTouched = difference(mandatoryFields, touchedFields).length === 1;

      if (isTouched || isLastMandatoryFieldNotTouched) {
        runFieldValidation(fieldName, newValue);
      }
    },
    [runFieldValidation, touchedFields],
  );

  const handleFieldChangeEvent = useCallback(
    (event) => handleFieldChange(event.target.name)(event.target.value),
    [handleFieldChange],
  );

  const handleFieldBlur = useCallback(
    (fieldName) => (newValue) => {
      const fieldValue = isUndefined(newValue) ? values[fieldName] : newValue;
      // Add to list of touched fields if required
      if (!includes(touchedFields, fieldName)) {
        setTouchedFields((currentTouchedFields) => [...currentTouchedFields, fieldName]);
      }

      // Set any errors
      runFieldValidation(fieldName, fieldValue);
    },
    [runFieldValidation, touchedFields, values],
  );

  const handleFieldBlurEvent = useCallback(
    (event) => {
      handleFieldBlur(event.target.name)();
    },
    [handleFieldBlur],
  );

  const handleSubmit = useCallback(
    async (e) => {
      e.preventDefault();

      const apiUrl = '/loyalty/v2/members/prospects';

      const payload = {
        data: {
          enrolmentSource: 'WEBSITE',
          individual: {
            identity: {
              firstName: values[formFieldNames.firstName],
              lastName: values[formFieldNames.lastName],
              title: values[formFieldNames.title]?.value,
            },
            contact: {
              emails: [
                {
                  category: 'PERSONAL',
                  address: values[formFieldNames.email],
                },
              ],
            },
          },
        },
      };

      try {
        setApiPosting(true);
        setApiError(false);
        setApiSuccess(false);

        await api.vffApiNoKeycloak.post(apiUrl, payload);

        setApiPosting(false);
        setApiSuccess(true);
      } catch (error) {
        setApiPosting(false);
        setApiError(true);
      }
    },
    [values],
  );

  const canSubmit =
    every(mandatoryFields, (mandatoryFieldName) => values[mandatoryFieldName] && !errors[mandatoryFieldName]) &&
    !emailApiError &&
    !emailApiLoading;

  useEffect(() => {
    if (apiSuccess && successMessageRef.current) {
      setValues(initialValues);
      scrollToRef(successMessageRef);
    }
  }, [apiSuccess]);

  useEffect(() => {
    if (apiError && errorMessageRef.current) {
      scrollToRef(errorMessageRef);
    }
  }, [apiError]);

  return (
    <ErrorBoundary section={COMPONENT_NAME.outageForm}>
      <div className={styles.container}>
        <TopContentContainer theme={contentContainerType.typeB}>
          {apiError && (
            <MessageTile
              className={styles.message}
              ref={errorMessageRef}
              theme={messageTileTheme.error}
              description={defaultErrorMessage}
            />
          )}

          {apiSuccess && (
            <MessageTile
              className={styles.message}
              ref={successMessageRef}
              theme={messageTileTheme.success}
              description={successMessage}
            />
          )}

          {infoBox && (
            <InfoTile
              className={styles.infoMessage}
              title={infoBox?.infoBoxTitle}
              description={infoBox?.infoBoxDescription}
            />
          )}
        </TopContentContainer>

        <FormContainer theme={formContainerColor.white} type={formContainerType.typeB}>
          <form onSubmit={handleSubmit}>
            <FormContentContainer>
              <h2 className={cx('vaHeading vaHeading--5 color color--purple', styles.title)}>{title}</h2>
            </FormContentContainer>

            <FormRow>
              <FormFieldContainer className={styles.titleField}>
                <Select
                  label="title"
                  name={formFieldNames.title}
                  items={personTitleOptions}
                  onChange={handleFieldChange(formFieldNames.title)}
                  onBlur={handleFieldBlur(formFieldNames.title)}
                  isMandatory
                  selectedItem={values[formFieldNames.title]}
                  error={errors[formFieldNames.title]}
                  autoComplete="honorific-prefix"
                  isSearchable={false}
                  placeholder="Select"
                />
              </FormFieldContainer>
            </FormRow>

            <FormRow>
              <FormFieldContainer>
                <Input
                  label="First name"
                  name={formFieldNames.firstName}
                  onChange={handleFieldChangeEvent}
                  onBlur={handleFieldBlurEvent}
                  isMandatory
                  value={values[formFieldNames.firstName]}
                  error={errors[formFieldNames.firstName]}
                  autoComplete="given-name"
                />
              </FormFieldContainer>

              <FormFieldContainer>
                <Input
                  label="last name"
                  name={formFieldNames.lastName}
                  onChange={handleFieldChangeEvent}
                  onBlur={handleFieldBlurEvent}
                  isMandatory
                  value={values[formFieldNames.lastName]}
                  error={errors[formFieldNames.lastName]}
                  autoComplete="family-name"
                />
              </FormFieldContainer>
            </FormRow>

            <FormRow>
              <FormFieldContainer>
                <Input
                  label="email"
                  type="email"
                  name={formFieldNames.email}
                  onChange={handleFieldChangeEvent}
                  onBlur={handleFieldBlurEvent}
                  isMandatory
                  value={values[formFieldNames.email]}
                  error={errors[formFieldNames.email] || emailApiError}
                  isLoading={emailApiLoading}
                  autoComplete="home email"
                />
              </FormFieldContainer>
            </FormRow>

            {termsAndConditions && (
              <FormContentContainer>
                <h3 className={styles.tncTitle} id="terms_and_conditions_header">
                  Terms and conditions
                </h3>
                <ConditionsText aria-labelledby="terms_and_conditions_header">
                  <RichTextContent content={termsAndConditions} />
                </ConditionsText>
              </FormContentContainer>
            )}

            {privacyInformation && (
              <FormContentContainer>
                <h3 className={styles.tncTitle} id="privacy_statement_header">
                  Privacy Statement
                </h3>
                <ConditionsText aria-labelledby="privacy_statement_header">
                  <RichTextContent content={privacyInformation} />
                </ConditionsText>
              </FormContentContainer>
            )}

            <FormContentContainer>
              <Checkbox
                size="small"
                name={formFieldNames.termsAndConditions}
                checked={values[formFieldNames.termsAndConditions]}
                label={<RichTextContent content={checkboxTnc} />}
                onChange={(event) => {
                  handleFieldChange(formFieldNames.termsAndConditions)(event.target.checked);
                }}
                onBlur={handleFieldBlurEvent}
                error={errors[formFieldNames.termsAndConditions]}
              />
            </FormContentContainer>

            <div className={styles.ctaWrapper}>
              <Button
                className={styles.submitButton}
                type="submit"
                buttonType={ctaContainer.ctaStyle}
                title={ctaContainer.ctaTitle}
                disabled={!canSubmit || apiPosting}
                loading={apiPosting}
                onClick={handleSubmit}
              >
                {ctaContainer.ctaLabel}
              </Button>
            </div>
          </form>
        </FormContainer>
      </div>
    </ErrorBoundary>
  );
};

OutageForm.propTypes = {
  defaultErrorMessage: PropTypes.string,
  successMessage: PropTypes.string,
  infoBox: PropTypes.shape({
    infoBoxTitle: PropTypes.string,
    infoBoxDescription: PropTypes.string,
  }),
  title: PropTypes.string,
  termsAndConditions: PropTypes.string,
  privacyInformation: PropTypes.string,
  checkboxTnc: PropTypes.string,
  ctaContainer: PropTypes.shape({
    ctaStyle: PropTypes.string,
    ctaTitle: PropTypes.string,
    ctaLabel: PropTypes.string,
  }),
};

OutageForm.defaultProps = {
  defaultErrorMessage: null,
  successMessage: null,
  infoBox: null,
  title: null,
  termsAndConditions: null,
  privacyInformation: null,
  checkboxTnc: null,
  ctaContainer: null,
};

export default OutageForm;
