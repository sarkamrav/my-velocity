import React, { useEffect, useRef, useState } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import cx from 'classnames';
import { connect } from 'react-redux';

import RichTextContent from '../../components/RichTextContent/RichTextContent';
import A from '../../components/Button/A';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME, isCtaAvailable } from '../../utils/common';
import useOnScreen from '../../hooks/useOnScreen';

import styles from './SingleFeaturedContent.css';
import * as userData from '../../stores/utilities';
import useMediaQuery from '../../hooks/useMediaQuery';

const SingleFeaturedContent = ({
  title,
  layout,
  imageRef,
  imageAlt,
  description,
  ctaContainer,
  secondaryCtaContainer,
  renditions,
  renditionImageKey,
  alignImageToRight,
  analyticsMetadata,
  videoRef,
  contentType,
  className,
  visibilityMode,
  background,
  user,
  renderMode,
  compomentID,
}) => {
  const contentRef = useRef();
  const isInView = useOnScreen(contentRef);
  const analyticsMetadataKey = analyticsMetadata['analytics-metadata'];
  const [analyticsData, setAnalyticsData] = useState(analyticsMetadataKey);
  const hasLoggedIn = userData.getHasLoggedIn(user);
  const isComponentVisible =
    renderMode?.toLowerCase() === 'both' ||
    (renderMode?.toLowerCase() === 'authenticated' && hasLoggedIn) ||
    (renderMode?.toLowerCase() === 'unauthenticated' && !hasLoggedIn) ||
    _.get(window.vffCoreWebsite, 'websiteData.authoringMode');
  const isMediaMobile = useMediaQuery('(max-width: 767px)');

  // remove AEM padding when not rendered
  useEffect(() => {
    const element = document.getElementById(compomentID);
    const aemElement = element?.parentNode?.parentNode;

    if (isComponentVisible) {
      if (aemElement?.classList.contains(styles.removeAemPadding)) {
        aemElement.classList.remove(styles.removeAemPadding);
      }

      if ((visibilityMode === 'desktop' && isMediaMobile) || (visibilityMode === 'mobile' && !isMediaMobile)) {
        aemElement?.classList.add(styles.removeAemPadding);
      }
    } else {
      aemElement?.classList.add(styles.removeAemPadding);
    }
  }, [compomentID, isComponentVisible, isMediaMobile, visibilityMode]);

  useEffect(() => {
    const commonAnalyticsData = window.vffCoreWebsite[analyticsMetadataKey] || {};

    setAnalyticsData({
      ...commonAnalyticsData,
      eventCategory: 'page-cta',
      eventLocation: 'contentTile',
    });
  }, [analyticsMetadataKey]);

  const isFirstCtaAvailable = isCtaAvailable(ctaContainer);
  const isSecondCtaAvailable = isCtaAvailable(secondaryCtaContainer);

  function getCta(cta) {
    return (
      <A
        href={cta.ctaUrl}
        title={cta.ctaTitle}
        target={cta.ctaOpenInNewTab ? '_blank' : '_self'}
        buttonType={cta.ctaStyle}
        ctaAsLink={cta.ctaAsLink}
        ctaImage={cta.ctaImage}
        analytics-metadata={
          typeof analyticsData === 'string'
            ? analyticsData
            : JSON.stringify({
                ...analyticsData,
                eventName: 'cta-interaction',
              })
        }
      >
        {cta.ctaLabel}
      </A>
    );
  }

  const defaultImage = _.get(renditions, 'imageDefault');
  const flexWidth = ['VIDEO', 'YOUTUBE'].includes(contentType.toUpperCase());
  const backgroundImage = _.get(background, 'renditions.imageDefault', null);

  return (
    <ErrorBoundary section={COMPONENT_NAME.singleFeaturedContent}>
      <div
        id={compomentID}
        className={cx({ [styles.desktop]: visibilityMode === 'desktop', [styles.mobile]: visibilityMode === 'mobile' })}
      >
        {isComponentVisible ? (
          <div
            rendition-image={background?.backgroundType === 'IMAGE' ? background?.renditionImageKey : null}
            className={styles.backgroundContainer}
            style={
              backgroundImage
                ? {
                    backgroundImage: `url(${backgroundImage})`,
                  }
                : null
            }
          >
            <div
              className={cx(styles.container, className, {
                [styles.imageRightAlign]: alignImageToRight,
              })}
            >
              <div
                className={cx(styles.assetContainer, {
                  [styles.oneThirdWidth]: layout === 'assetOneThirdScreenWidth',
                  [styles.flexWidth]: flexWidth,
                })}
              >
                {['GIF', 'IMAGE'].includes(contentType.toUpperCase()) ? (
                  <img
                    className={styles.image}
                    src={contentType.toUpperCase() === 'GIF' ? imageRef : defaultImage}
                    rendition-image={contentType.toUpperCase() === 'IMAGE' ? renditionImageKey : null}
                    alt={imageAlt}
                  />
                ) : null}

                {contentType.toUpperCase() === 'VIDEO' ? (
                  <video preload="auto" autoPlay loop muted playsInline>
                    <source src={videoRef} type="video/mp4" />
                    {defaultImage ? (
                      <img src={defaultImage} alt="Your browser does not support the <video> tag" />
                    ) : (
                      'Your browser does not support the <video> tag'
                    )}
                  </video>
                ) : null}

                {contentType.toUpperCase() === 'YOUTUBE' ? (
                  <div className={styles.youtubeContainer}>
                    <iframe
                      title={title}
                      src={videoRef}
                      frameBorder="0"
                      allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  </div>
                ) : null}
              </div>

              <div
                ref={contentRef}
                className={cx(styles.content, {
                  'text-highlight-animation': isInView,
                })}
              >
                {title ? (
                  <h2 className={styles.title}>
                    <RichTextContent content={title} className={styles.titleText} />
                  </h2>
                ) : null}

                {description ? (
                  <RichTextContent
                    className={styles.description}
                    content={description}
                    analytics-metadata={
                      typeof analyticsData === 'string' ? analyticsData : JSON.stringify({ ...analyticsData })
                    }
                  />
                ) : null}

                {(isFirstCtaAvailable || isSecondCtaAvailable) && (
                  <div className={styles.ctaContainer}>
                    {isFirstCtaAvailable && getCta(ctaContainer)}

                    {isSecondCtaAvailable && getCta(secondaryCtaContainer)}
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : null}
      </div>
    </ErrorBoundary>
  );
};

SingleFeaturedContent.propTypes = {
  title: PropTypes.string,
  className: PropTypes.string,
  videoRef: PropTypes.string,
  imageAlt: PropTypes.string,
  imageRef: PropTypes.string,
  contentType: PropTypes.string,
  description: PropTypes.string,
  layout: PropTypes.string,
  visibilityMode: PropTypes.string,
  ctaContainer: PropTypes.shape({
    ctaUrl: PropTypes.string,
    ctaTitle: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaStyle: PropTypes.string,
    ctaAsLink: PropTypes.bool,
    ctaLabel: PropTypes.string,
  }),
  secondaryCtaContainer: PropTypes.shape({
    ctaUrl: PropTypes.string,
    ctaTitle: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaStyle: PropTypes.string,
    ctaAsLink: PropTypes.bool,
    ctaLabel: PropTypes.string,
  }),
  renditions: PropTypes.shape({}),
  renditionImageKey: PropTypes.string,
  background: PropTypes.shape({
    renditionImageKey: PropTypes.string,
    backgroundType: PropTypes.string,
  }),
  alignImageToRight: PropTypes.bool,
  analyticsMetadata: PropTypes.shape({
    'analytics-metadata': PropTypes.string,
  }),
  user: PropTypes.shape({
    authenticated: PropTypes.bool,
  }),
  renderMode: PropTypes.string,
  compomentID: PropTypes.string,
};

SingleFeaturedContent.defaultProps = {
  title: '',
  className: '',
  videoRef: '',
  contentType: '',
  imageAlt: '',
  imageRef: '',
  description: '',
  layout: '',
  ctaContainer: {},
  secondaryCtaContainer: {},
  renditions: {},
  renditionImageKey: '',
  background: null,
  alignImageToRight: false,
  analyticsMetadata: {},
  visibilityMode: 'both',
  user: {
    authenticated: false,
  },
  renderMode: 'both',
  compomentID: 'singleFeatureComponent',
};

export default connect(({ user }) => ({ user }))(SingleFeaturedContent);
