import React from 'react';
import { Provider } from 'react-redux';

import singleFeaturedContentMock from './mocks/SingleFeaturedContent.mock.json';
import SingleFeaturedContentWithTwoCta from './mocks/SingleFeaturedContentWithTwoCta.mock.json';
import SingleFeaturedContentOnlyMobile from './mocks/SingleFeaturedContentOnlyMobile.mock.json';
import SingleFeaturedContentOnlyDesktop from './mocks/SingleFeaturedContentOnlyDesktop.mock.json';
import SingleFeaturedContentCtaButton from './mocks/SingleFeaturedContentCtaButton.mock.json';
import SingleFeaturedContentWithTwoLink from './mocks/SingleFeaturedContentWithTwoLink.mock.json';

import SingleFeaturedContent from './SingleFeaturedContent';
import { configureStore } from '../../stores';

export default {
  title: 'Single Featured Content',
};

const Template = (args) => {
  const { authenticated = false, ...rest } = args;
  return (
    <Provider
      store={configureStore({
        user: {
          authenticated,
        },
      })}
    >
      <SingleFeaturedContent {...rest} />;
    </Provider>
  );
};

export const AssetLeftAlign = Template.bind({});
AssetLeftAlign.args = { ...singleFeaturedContentMock };
AssetLeftAlign.storyName = 'asset left align';

export const SmallAssetLeftAlign = Template.bind({});
SmallAssetLeftAlign.args = {
  ...AssetLeftAlign.args,
  contentType: 'IMAGE',
};
SmallAssetLeftAlign.storyName = 'small asset left align';

export const Video = Template.bind({});
Video.args = { ...AssetLeftAlign.args, contentType: 'VIDEO' };

export const Youtube = Template.bind({});
Youtube.args = { ...AssetLeftAlign.args, contentType: 'YOUTUBE' };

export const YoutubeOneThirdWidthOfScreen = Template.bind({});
YoutubeOneThirdWidthOfScreen.args = {
  ...Youtube.args,
  layout: 'assetOneThirdScreenWidth',
};
YoutubeOneThirdWidthOfScreen.storyName = 'Youtube - one third width of screen';

export const AssetRightAlign = Template.bind({});
AssetRightAlign.args = {
  ...AssetLeftAlign.args,
  alignImageToRight: true,
};
AssetRightAlign.storyName = 'asset right align';

export const onlyMobile = Template.bind({});
onlyMobile.args = {
  ...SingleFeaturedContentOnlyMobile,
};

export const onlyDesktop = Template.bind({});
onlyDesktop.args = {
  ...SingleFeaturedContentOnlyDesktop,
};

export const singleCTALink = Template.bind({});
singleCTALink.args = {
  ...AssetLeftAlign.args,
};

export const twoCTALink = Template.bind({});
twoCTALink.args = {
  ...SingleFeaturedContentWithTwoLink,
};

export const singleCTAButton = Template.bind({});
singleCTAButton.args = {
  ...SingleFeaturedContentCtaButton,
};

export const twoCTA = Template.bind({});
twoCTA.args = {
  ...SingleFeaturedContentWithTwoCta,
};

export const onlyAuthenticated = Template.bind({});
onlyAuthenticated.args = {
  ...singleFeaturedContentMock,
  renderMode: 'authenticated',
  authenticated: true,
};

export const onlyUnauthenticated = Template.bind({});
onlyUnauthenticated.args = {
  ...singleFeaturedContentMock,
  renderMode: 'unauthenticated',
};

const AemTemplate = (args) => {
  const { authenticated = false, ...rest } = args;
  return (
    <Provider
      store={configureStore({
        user: {
          authenticated,
        },
      })}
    >
      <div className="vffutils__padding-top vffutils__padding-bottom vffutils__background-color aem-GridColumn aem-GridColumn--default--12">
        <div
          analytics-metadata="amd_single-featured-content_yNbUFvwB"
          aem-single-featured-content="single-featured-content_yNbUFvwB"
        >
          <SingleFeaturedContent {...rest} />
        </div>
      </div>
    </Provider>
  );
};

export const removeAemPadddingWhenNotRendered = AemTemplate.bind({});
removeAemPadddingWhenNotRendered.args = {
  ...singleFeaturedContentMock,
  renderMode: 'authenticated',
};

export const removeAemPadddingWhenNotRenderedOnMobile = AemTemplate.bind({});
removeAemPadddingWhenNotRenderedOnMobile.args = {
  ...singleFeaturedContentMock,
  renderMode: 'authenticated',
  authenticated: true,
  visibilityMode: 'desktop',
};
