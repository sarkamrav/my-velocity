import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import PropTypes from 'prop-types';
import get from 'lodash/get';
import includes from 'lodash/includes';
import isUndefined from 'lodash/isUndefined';
import omit from 'lodash/omit';

import {
  COMPONENT_NAME,
  getAuthorableErrorMsg,
  getNavigationHeight,
  getParameterFromUrl,
  smoothScrollToElement,
} from '../../utils/common';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import api from '../../utils/api';
import * as validate from '../../components/Form/validators';
import { validateFormField } from '../../components/Form/utils';

import Button from '../../components/Button/Button';
import MessageTile, { messageTileTheme } from '../../components/MessageTile/MessageTile';
import SuccessMessageTile, { successMessageTheme } from '../../components/SuccessMessageTile/SuccessMessageTile';
import FormRow from '../../components/Form/containers/FormRow/FormRow';
import FormFieldContainer, {
  FormFieldType,
} from '../../components/Form/containers/FormFieldContainer/FormFieldContainer';
import FormContainer, {
  formContainerColor,
  formContainerType,
} from '../../components/Form/containers/FormContainer/FormContainer';
import TopContentContainer, {
  contentContainerType,
} from '../../components/Form/containers/TopContentContainer/TopContentContainer';
import SecretInput from '../JoinPage/components/SecretInput/SecretInput';
import PasswordValidator from '../JoinPage/components/PasswordValidator/PasswordValidator';
import Loading from '../../components/Loading/Loading';
import styles from './CreatePassword.css';

const CreatePassword = ({ ctaContainer, confirmation, expiredLink, errorMessages }) => {
  const submitErrorAlertId = useRef();
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [postError, setPostError] = useState('');

  const [errors, setErrors] = useState({});
  const [touchedFields, setTouchedFields] = useState([]);
  const isNewPasswordConfirmTouched = includes(touchedFields, 'newPasswordConfirm');

  const [values, setValues] = useState({});

  const fieldValidators = useMemo(
    () => ({
      newPassword: [
        validate.required('Password is required'),
        validate.password(
          "The password contains invalid characters, only the following special characters are accepted: '* ! ~ @ # $ % ^ & ( ) _ - + ='",
        ),
        ...(isNewPasswordConfirmTouched
          ? [validate.matchesField('newPasswordConfirm', 'The password you have entered does not match')]
          : []),
      ],
      newPasswordConfirm: [
        validate.required('A password confirmation is required'),
        validate.password(
          "The password contains invalid characters, only the following special characters are accepted: '* ! ~ @ # $ % ^ & ( ) _ - + ='",
        ),
        validate.matchesField('newPassword', 'The password you have entered does not match'),
      ],
    }),
    [isNewPasswordConfirmTouched],
  );

  // Validates field and returns an error message if it is invalid
  const validateField = useCallback(
    (fieldName, fieldValue) => validateFormField(fieldValue, fieldValidators[fieldName], values),
    [fieldValidators, values],
  );

  // Runs and applies field validation
  const runFieldValidation = useCallback(
    (fieldName, fieldValue) => {
      const error = validateField(fieldName, fieldValue);
      if (error) {
        setErrors((currentErrors) => ({
          ...currentErrors,
          [fieldName]: error,
          ...(fieldName === 'newPassword' ? { newPasswordConfirm: '' } : {}),
          ...(fieldName === 'newPasswordConfirm' ? { newPassword: '' } : {}),
        }));
      } else {
        setErrors((currentErrors) =>
          omit(currentErrors, [
            fieldName,
            ...(fieldName === 'newPassword' ? ['newPasswordConfirm'] : ''),
            ...(fieldName === 'newPasswordConfirm' ? ['newPassword'] : []),
          ]),
        );
      }
    },
    [validateField],
  );

  const handleFieldChange = useCallback(
    (fieldName) => (newValue) => {
      setValues((previousValues) => ({
        ...previousValues,
        [fieldName]: newValue,
      }));

      // Give immediate error feedback for fields that are already touched
      const isTouched = includes(touchedFields, fieldName);
      if (isTouched) {
        runFieldValidation(fieldName, newValue);
      }
    },
    [runFieldValidation, touchedFields],
  );

  const handleFieldChangeEvent = useCallback(
    (event) => {
      handleFieldChange(event.target.name)(event.target.value);
    },
    [handleFieldChange],
  );

  const handleFieldBlur = useCallback(
    (fieldName) => (newValue) => {
      const fieldValue = isUndefined(newValue) ? values[fieldName] : newValue;

      // Add to list of touched fields if required
      if (!includes(touchedFields, fieldName)) {
        setTouchedFields((currentTouchedFields) => [...currentTouchedFields, fieldName]);
      }

      // Set any errors
      runFieldValidation(fieldName, fieldValue);
    },
    [runFieldValidation, touchedFields, values],
  );

  const handleFieldBlurEvent = useCallback(
    (event) => {
      handleFieldBlur(event.target.name)();
    },
    [handleFieldBlur],
  );

  function checkFormValidity() {
    return (
      !!values.newPassword &&
      !errors.newPassword &&
      !!values.newPasswordConfirm &&
      !errors.newPasswordConfirm &&
      values.newPassword === values.newPasswordConfirm
    );
  }

  const [isPasswordResetAllowed, setIsPasswordResetAllowed] = useState(false);
  const [error, setError] = useState('');

  const token = getParameterFromUrl('token', true);
  const passwordTokenUrl = `/loyalty/v2/password/reset-link-status/${token}`;

  const checkTokenValidity = useCallback(async () => {
    try {
      setLoading(true);
      const apiResp = await api.vffV2ApiNoToken.get(passwordTokenUrl);
      setIsPasswordResetAllowed(apiResp.data.data.status === 'valid');
      setLoading(false);
    } catch (err) {
      setError(get(errorMessages, 'defaultErrorMessage'));
      setLoading(false);
    }
  }, [errorMessages, passwordTokenUrl]);

  useEffect(() => {
    checkTokenValidity();
  }, [checkTokenValidity]);

  const createPasswordApiUrl = '/loyalty/v2/password';
  const onFormSubmit = async (e) => {
    e.preventDefault();
    try {
      setSubmitting(true);
      setSubmitted(false);
      setPostError('');
      const createPasswordApiBody = {
        data: {
          action: 'RESET-PROCESS',
          token,
          newPassword: values.newPassword,
        },
      };
      await api.vffV2ApiNoToken.patch(createPasswordApiUrl, createPasswordApiBody);
      setSubmitting(false);
      setSubmitted(true);
    } catch (err) {
      setSubmitting(false);
      const customError = getAuthorableErrorMsg(err, errorMessages);
      setPostError(customError);
    }
  };

  useEffect(() => {
    if (postError) {
      smoothScrollToElement(submitErrorAlertId.current, getNavigationHeight());
    }
  }, [postError]);

  const isContentReady = !loading && !error;

  return (
    <ErrorBoundary section={COMPONENT_NAME.createPassword}>
      {loading && (
        <div className={styles.loadingContainer}>
          <Loading />
        </div>
      )}

      {!loading && error && (
        <div className={styles.errorContainer}>
          <MessageTile theme={messageTileTheme.error} description={error.description} />
        </div>
      )}

      <div className={styles.container}>
        {isContentReady && (
          <TopContentContainer theme={contentContainerType.typeB} className={styles.paddingBottomZero}>
            {!isPasswordResetAllowed && (
              <SuccessMessageTile
                theme={successMessageTheme.shadow}
                title={get(expiredLink, 'title') || ''}
                content={get(expiredLink, 'description') || ''}
                ctaContainer={get(expiredLink, 'ctaContainer') || ''}
                iconPath={get(expiredLink, 'iconUrl') || ''}
              />
            )}

            {isPasswordResetAllowed && (
              <>
                {submitted && (
                  <SuccessMessageTile
                    theme={successMessageTheme.shadow}
                    title={get(confirmation, 'title') || ''}
                    content={get(confirmation, 'description') || ''}
                    ctaContainer={get(confirmation, 'ctaContainer') || ''}
                    iconPath={get(confirmation, 'iconUrl') || ''}
                  />
                )}

                {!submitted && postError && (
                  <MessageTile
                    className={styles.erroMsg}
                    ref={submitErrorAlertId}
                    theme={messageTileTheme.error}
                    description={postError.description}
                  />
                )}
              </>
            )}
          </TopContentContainer>
        )}

        {isContentReady && isPasswordResetAllowed && !submitted && (
          <form onSubmit={onFormSubmit}>
            <FormContainer theme={formContainerColor.white} type={formContainerType.typeB}>
              <FormRow>
                <div className={styles.passwordContainer}>
                  <FormFieldContainer type={FormFieldType.largeRow}>
                    <SecretInput
                      name="newPassword"
                      label="New password"
                      placeholder="Enter password"
                      aria-describedby="password_validator_sr_description"
                      size={10}
                      onChange={handleFieldChangeEvent}
                      onBlur={handleFieldBlurEvent}
                      value={values.newPassword}
                      error={errors.newPassword}
                      autoComplete="new-password"
                    />
                  </FormFieldContainer>
                  <FormFieldContainer type={FormFieldType.largeRow}>
                    <SecretInput
                      name="newPasswordConfirm"
                      label="Confirm New password"
                      placeholder="Re-enter password"
                      size={10}
                      onChange={handleFieldChangeEvent}
                      onBlur={handleFieldBlurEvent}
                      value={values.newPasswordConfirm}
                      error={errors.newPasswordConfirm}
                      autoComplete="new-password"
                    />
                  </FormFieldContainer>
                </div>
                <div className={styles.passwordValidatorCont}>
                  <PasswordValidator
                    className={styles.passwordValidator}
                    currentPassword={values.newPassword || ''}
                    screenReaderDescriptionContainerId="password_validator_sr_description"
                    arePasswordsMatchErrorMessage={
                      includes(touchedFields, 'newPassword') && isNewPasswordConfirmTouched
                        ? validateFormField(
                            values.newPassword,
                            [
                              validate.matchesField(
                                'newPasswordConfirm',
                                'The passwords you have entered does not match',
                              ),
                            ],
                            values,
                          )
                        : ''
                    }
                  />
                </div>
              </FormRow>
              <Button
                className={styles.passwordCtaButton}
                title={get(ctaContainer, 'ctaTitle')}
                target={get(ctaContainer, 'ctaOpenInNewTab') ? '_blank' : '_self'}
                buttonType={get(ctaContainer, 'ctaStyle')}
                type="submit"
                disabled={!checkFormValidity() || submitting}
                loading={submitting}
              >
                {get(ctaContainer, 'ctaLabel')}
              </Button>
            </FormContainer>
          </form>
        )}
      </div>
    </ErrorBoundary>
  );
};

CreatePassword.propTypes = {
  ctaContainer: PropTypes.shape({}).isRequired,
  confirmation: PropTypes.shape({}).isRequired,
  expiredLink: PropTypes.shape({}).isRequired,
  errorMessages: PropTypes.shape({}).isRequired,
};

export default CreatePassword;
