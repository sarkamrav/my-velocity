import React from 'react';
import { Provider } from 'react-redux';
import MockAdapter from 'axios-mock-adapter';
import { configureStore } from '../../stores';
import api from '../../utils/api';

import createPasswordMock from './mocks/CreatePassword.mock.json';
import CreatePassword from './CreatePassword';

export default {
  title: 'CreatePassword',
};

export const CreatePasswordSubmissionSuccess = () => {
  const mockVff = new MockAdapter(api.vffV2ApiNoToken, { delayResponse: 800 });

  mockVff.onGet('/loyalty/v2/password/reset-link-status/FF5dbe49b106bafc1a7674754afc43ab4').reply(200, {
    data: {
      status: 'valid',
    },
  });

  mockVff.onPatch('/loyalty/v2/password').reply(200, {});

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: false,
            memberDataLoading: false,
            memberDataLoadError: true,
            authenticated: false,
          },
        })}
      >
        <CreatePassword {...createPasswordMock} />
      </Provider>
    </div>
  );
};

CreatePasswordSubmissionSuccess.parameters = {
  query: {
    token: 'FF5dbe49b106bafc1a7674754afc43ab4',
  },
};

CreatePasswordSubmissionSuccess.storyName = 'Submission Success';

export const CreatePasswordFormSubmissionFailed = () => {
  const mockVff = new MockAdapter(api.vffV2ApiNoToken, { delayResponse: 800 });

  mockVff.onGet('/loyalty/v2/password/reset-link-status/FF5dbe49b106bafc1a7674754afc43ab4').reply(200, {
    data: {
      status: 'valid',
    },
  });

  mockVff.onPatch('/loyalty/v2/password').reply(400, {
    code: 4176,
    title: 'Validation Error',
    detail: 'Validation failed for below fields',
    status: 400,
  });

  CreatePasswordFormSubmissionFailed.parameters = {
    query: {
      token: 'FF5dbe49b106bafc1a7674754afc43ab4',
    },
  };

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: false,
            memberDataLoading: false,
            memberDataLoadError: true,
            authenticated: false,
          },
        })}
      >
        <CreatePassword {...createPasswordMock} />
      </Provider>
    </div>
  );
};

CreatePasswordFormSubmissionFailed.storyName = 'Submission Failed';

export const CreatePasswordLinkExpired = () => {
  const mockVff = new MockAdapter(api.vffV2ApiNoToken, { delayResponse: 800 });

  mockVff.onGet('/loyalty/v2/password/reset-link-status/FF5dbe49b106bafc1a7674754afc43ab4').reply(200, {
    data: {
      status: 'invalid',
    },
  });

  CreatePasswordLinkExpired.parameters = {
    query: {
      token: 'FF5dbe49b106bafc1a7674754afc43ab4',
    },
  };

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: false,
            memberDataLoading: false,
            memberDataLoadError: true,
            authenticated: false,
          },
        })}
      >
        <CreatePassword {...createPasswordMock} />
      </Provider>
    </div>
  );
};

CreatePasswordLinkExpired.storyName = 'Link Expired';

export const CreatePasswordFormApiError = () => {
  const mockVff = new MockAdapter(api.vffV2ApiNoToken, { delayResponse: 800 });

  mockVff.onGet('/loyalty/v2/password/reset-link-status/FF5dbe49b106bafc1a7674754afc43ab4').reply(400, {
    code: 4001,
    title: 'Validation Error',
    detail: 'Validation failed for below fields',
    status: 400,
  });

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
          },
        })}
      >
        <CreatePassword {...createPasswordMock} />
      </Provider>
    </div>
  );
};

CreatePasswordFormApiError.storyName = 'API Failed';
