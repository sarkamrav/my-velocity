import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';

import RichTextContent from '../../components/RichTextContent/RichTextContent';
import A from '../../components/Button/A';
import Grid from '../../components/Grid/Grid';
import OfferCard from '../OfferCard/OfferCard';
import useServerRendering from '../../hooks/useServerRendering';
import ActivatedOfferCard from '../OfferCard/ActivatedOfferList/ActivatedOfferCard';
import usePartnerActivatedOffers from '../../hooks/usePartnerApiOffers';
import CallOut from '../CallOut/CallOut';
import Loading from '../../components/Loading/Loading';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME } from '../../utils/common';

import styles from './PartnerOfferList.css';

const PartnerOfferList = ({
  title,
  description,
  offers,
  ctaContainer,
  partnerKey,
  noResultTitle,
  noResultDescription,
  noResultIconPath,
  analyticsMetadata,
}) => {
  const { rendered } = useServerRendering();
  const { partnerApiOffers, partnerApiOffersLoading } = usePartnerActivatedOffers(partnerKey);

  const ctaButton =
    ctaContainer && ctaContainer.ctaUrl && ctaContainer.ctaLabel ? (
      <div className={styles.callToActionContainer}>
        <A
          href={ctaContainer.ctaUrl}
          title={ctaContainer.ctaTitle}
          buttonType={ctaContainer.ctaStyle}
          target={ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
          ctaAsLink={ctaContainer.ctaAsLink}
        >
          {ctaContainer.ctaLabel}
        </A>
      </div>
    ) : null;

  const allOffersCount = _.size([...partnerApiOffers, ...offers]);

  return (
    <ErrorBoundary section={COMPONENT_NAME.partnerOfferList}>
      <div className={styles.container}>
        <div className={styles.header}>
          {title ? <h3 className="heading heading--3 color color--purple">{title}</h3> : null}
          {description ? <RichTextContent content={description} {...analyticsMetadata} /> : null}
        </div>

        {allOffersCount > 0 ? (
          <Grid>
            {_.map(partnerApiOffers, (offer) => (
              <ActivatedOfferCard key={offer.promotionCode} {...offer} />
            ))}
            {_.map(offers, (offer) => (
              <div aem-offer-card={offer.jsObjectKey} key={offer.jsObjectKey}>
                <OfferCard {...offer} />
              </div>
            ))}
            {
              rendered && allOffersCount % 2 === 1 ? <div className={styles.filler} /> : null // If odd count, pad it with one empty div
            }
          </Grid>
        ) : null}

        {
          // Show empty state if no BAU offers and no longer loading activated offers
          rendered && !partnerApiOffersLoading && allOffersCount === 0 ? (
            <div className="vffutils__margin-top vffutils__margin-top--half">
              <CallOut
                title={noResultTitle}
                description={noResultDescription}
                icon={noResultIconPath}
                ctaContainer={ctaContainer}
              />
            </div>
          ) : null
        }

        {
          // Show loading indicator if no BAU offers are available and activated offers are loading
          rendered && partnerApiOffersLoading && allOffersCount === 0 ? (
            <Loading containerClassName={styles.loadingContainer} />
          ) : null
        }

        {allOffersCount !== 0 ? ctaButton : null}
      </div>
    </ErrorBoundary>
  );
};

PartnerOfferList.propTypes = {
  title: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
  offers: PropTypes.arrayOf(PropTypes.shape({})),
  ctaContainer: PropTypes.shape({
    ctaUrl: PropTypes.string,
    ctaTitle: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaStyle: PropTypes.string,
    ctaAsLink: PropTypes.bool,
    ctaLabel: PropTypes.string,
  }),
  partnerKey: PropTypes.string.isRequired,
  noResultTitle: PropTypes.string,
  noResultDescription: PropTypes.string,
  noResultIconPath: PropTypes.string,
  user: PropTypes.shape(),
  analyticsMetadata: PropTypes.shape(),
};

PartnerOfferList.defaultProps = {
  offers: [],
  ctaContainer: {},
  noResultTitle: null,
  noResultDescription: null,
  noResultIconPath: null,
  user: null,
  analyticsMetadata: {},
};

export default PartnerOfferList;
