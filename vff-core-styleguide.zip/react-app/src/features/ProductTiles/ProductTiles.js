import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import cx from 'classnames';

import ProductTile from './ProductTile/ProductTile';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import A from '../../components/Button/A';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME } from '../../utils/common';

import styles from './ProductTiles.css';

const ProductTiles = ({
  title,
  description,
  ctaContainer,
  numberOfTilesPerRow,
  displayOption,
  tiles,
  analyticsMetadata,
}) => {
  const analyticsMetadataKey = analyticsMetadata['analytics-metadata'];
  const [analyticsData, setAnalyticsData] = useState(analyticsMetadataKey);

  useEffect(() => {
    const commonAnalyticsData = window.vffCoreWebsite[analyticsMetadataKey] || {};

    setAnalyticsData({
      ...commonAnalyticsData,
      eventLocation: 'productTileContainer',
    });
  }, [analyticsMetadataKey]);

  return (
    <ErrorBoundary section={COMPONENT_NAME.productTiles}>
      <div className={styles.container}>
        {title ? <h2 className={styles.mainTitle}>{title}</h2> : null}

        {description ? (
          <RichTextContent
            className={styles.description}
            content={description}
            analytics-metadata={typeof analyticsData === 'string' ? analyticsData : JSON.stringify(analyticsData)}
          />
        ) : null}

        <ul
          className={cx(styles.productList, {
            [styles.scrollMode]: displayOption === 'scroll',
            [styles.twoPerRow]: numberOfTilesPerRow === 'two',
            [styles.threePerRow]: numberOfTilesPerRow === 'three',
            [styles.totalTwo]: tiles.length === 2,
            [styles.totalOne]: tiles.length === 1,
          })}
        >
          {_.map(tiles, (tile) => (
            <li key={tile.jsObjectKey} className={styles.productListItem}>
              <ProductTile
                {...tile}
                analyticsMetadataFromParent={typeof analyticsData === 'string' ? {} : analyticsData}
              />
            </li>
          ))}
        </ul>

        {!_.isEmpty(ctaContainer) ? (
          <A
            href={ctaContainer.ctaUrl}
            className={styles.mainCta}
            title={ctaContainer.ctaTitle}
            target={ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
            buttonType={ctaContainer.ctaStyle}
            ctaAsLink={ctaContainer.ctaAsLink}
            analytics-metadata={
              typeof analyticsData === 'string'
                ? analyticsData
                : JSON.stringify({
                    ...analyticsData,
                    eventCategory: 'cta-links',
                    eventName: 'cta-interaction',
                  })
            }
          >
            {ctaContainer.ctaLabel}
          </A>
        ) : null}
      </div>
    </ErrorBoundary>
  );
};

ProductTiles.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
  ctaContainer: PropTypes.shape({
    ctaUrl: PropTypes.string,
    ctaTitle: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaStyle: PropTypes.string,
    ctaAsLink: PropTypes.bool,
    ctaLabel: PropTypes.string,
  }),
  numberOfTilesPerRow: PropTypes.string,
  tiles: PropTypes.arrayOf(PropTypes.shape({})),
  analyticsMetadata: PropTypes.shape({
    'analytics-metadata': PropTypes.string,
  }),
  displayOption: PropTypes.string,
};

ProductTiles.defaultProps = {
  title: '',
  description: '',
  ctaContainer: {},
  numberOfTilesPerRow: 'three',
  tiles: [],
  analyticsMetadata: {},
  displayOption: 'stack',
};

export default ProductTiles;
