import React from 'react';

/* eslint-disable camelcase */
import contentTilesMock from './mocks/ProductTiles.mock.json';
import product_tiles_item_eYZWnysv from './mocks/product-tiles_item_eYZWnysv.mock.json';
import product_tiles_item_Bbh8UabS from './mocks/product-tiles_item_Bbh8UabS.mock.json';
import product_tiles_item_Abh8UabB from './mocks/product-tiles_item_Abh8UabB.mock.json';
import product_tiles_item_three from './mocks/product-tiles_item_velocity_decc_credit_cards_westpac_altitude-black-card_master_product_tile_copy.mock.json';
/* eslint-enable camelcase */
import ProductTiles from './ProductTiles';
import { getPropsDataFromJsObjectKeyArray } from '../../utils/common';

const simulatedWindowObject = {
  uniqueImageTileKey: contentTilesMock,
  'product-tiles_item_eYZWnysv': product_tiles_item_eYZWnysv,
  'product-tiles_item_Bbh8UabS': product_tiles_item_Bbh8UabS,
  'product-tiles_item_Abh8UabB': product_tiles_item_Abh8UabB,
  'product-tiles_item_velocity_decc_credit_cards_westpac_altitude-black-card_master_product_tile_copy':
    product_tiles_item_three,
};

const props = getPropsDataFromJsObjectKeyArray(contentTilesMock, simulatedWindowObject, 'tiles');

export default {
  title: 'Product Tiles',
};

export const StackMode = () => <ProductTiles {...props} />;
StackMode.storyName = 'Mobile - Stack';

export const ScrollMode = () => <ProductTiles {...props} displayOption="scroll" />;
ScrollMode.storyName = 'Mobile - Scroll';

export const TwoPerRow = () => <ProductTiles {...props} displayOption="scroll" numberOfTilesPerRow="two" />;
TwoPerRow.storyName = 'Desktop - 2 tiles per row';

export const ThreePerRow = () => <ProductTiles {...props} displayOption="scroll" />;
ThreePerRow.storyName = 'Desktop - 3 tiles per row';
