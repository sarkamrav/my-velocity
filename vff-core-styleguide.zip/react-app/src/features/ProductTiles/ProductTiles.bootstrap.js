import React from 'react';
import ReactDOM from 'react-dom';
import { map, size } from 'lodash';
import { Provider } from 'react-redux';
import store from '../../stores';
import ProductTiles from './ProductTiles';
import { COMPONENT_NAME, getPropsDataFromJsObjectKeyArray } from '../../utils/common';

const ELEMENT_NAME = COMPONENT_NAME.productTiles;

function renderComponent(elements, hydrate) {
  map(elements, (element) => {
    const componentData = window.vffCoreWebsite[element.getAttribute(ELEMENT_NAME)];
    const props = getPropsDataFromJsObjectKeyArray(componentData, window.vffCoreWebsite, 'tiles');

    if (props) {
      const component = (
        <Provider store={store}>
          <ProductTiles {...props} />
        </Provider>
      );

      if (hydrate) {
        ReactDOM.hydrate(component, element);
      } else {
        ReactDOM.render(component, element);
      }
    }
  });
}

export default {
  elementName: ELEMENT_NAME,
  bootstrap: (id = null, hydrate = true) => {
    const elements = document.querySelectorAll(`[${ELEMENT_NAME}${id ? `=${id}` : ''}]`);

    if (size(elements) > 0) {
      renderComponent(elements, hydrate);
    }
  },
};
