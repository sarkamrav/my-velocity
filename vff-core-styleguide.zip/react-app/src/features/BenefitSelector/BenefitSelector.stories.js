import React from 'react';
import MockAdapter from 'axios-mock-adapter';
import { Provider } from 'react-redux';
import BenefitSelector from './BenefitSelector';
import benefitSelectorMock from './mocks/benefitSelector.mock.json';
import api from '../../utils/api';
import { configureStore } from '../../stores';
import userData from '../Navigation/mocks/user.mock.json';

export default {
  title: 'Benefit Selector',
};

export const BenefitAvailableOptInSuccess = () => {
  const vffBauV2Api = new MockAdapter(api.vffBauV2Api, { delayResponse: 500 });

  vffBauV2Api.onGet('/loyalty/v2/benefits/additional-reward-preferences/opted').reply(200, {
    data: {
      benefits: [],
    },
  });

  vffBauV2Api.onPost('/loyalty/v2/benefits/additional-reward-preferences').reply(200, {
    data: {
      benefit: {
        action: 'opt-in',
        code: 'deck',
        selectedOption: 'FS-GOLD',
        optInDate: '2022-03-07T23:30:39.457Z',
        isRedeemed: false,
      },
    },
  });

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData.account,
          ...userData.profile,
        },
      })}
    >
      <BenefitSelector {...benefitSelectorMock} />
    </Provider>
  );
};

export const BenefitAvailableOptInFailure = () => {
  const vffBauV2Api = new MockAdapter(api.vffBauV2Api, { delayResponse: 500 });

  vffBauV2Api.onGet('/loyalty/v2/benefits/additional-reward-preferences/opted').reply(200, {
    data: {
      benefits: [],
    },
  });

  vffBauV2Api.onPost('/loyalty/v2/benefits/additional-reward-preferences').reply(500, {});

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData.account,
          ...userData.profile,
        },
      })}
    >
      <BenefitSelector {...benefitSelectorMock} />
    </Provider>
  );
};

export const BenefitOptedInState = () => {
  const vffBauV2Api = new MockAdapter(api.vffBauV2Api, { delayResponse: 500 });

  vffBauV2Api.onGet('/loyalty/v2/benefits/additional-reward-preferences/opted').reply(200, {
    data: {
      benefits: [
        {
          code: 'decc',
          selectedOption: 'FS-GOLD',
          optInDate: '2022-03-07T23:30:39.457Z',
          isRedeemed: false,
        },
      ],
    },
  });

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData.account,
          ...userData.profile,
        },
      })}
    >
      <BenefitSelector {...benefitSelectorMock} />
    </Provider>
  );
};
