import React, { useState, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import get from 'lodash/get';
import find from 'lodash/find';
import filter from 'lodash/filter';
import isEmpty from 'lodash/isEmpty';
import BenefitSelectorForm from './BenefitSelectorForm/BenefitSelectorForm';
import api from '../../utils/api';
import Loading from '../../components/Loading/Loading';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import InformationAlert from '../../components/InformationAlert/InformationAlert';

import styles from './BenefitSelector.css';

const BenefitSelector = ({
  user,
  title,
  description,
  optedInDescription,
  selectedOptionDescription,
  errorMessage,
  tiles,
  ctaContainer,
  terms,
  confirmation,
  review,
}) => {
  const [apiBenefits, setApiBenefits] = useState(null);
  const [isGettingBenefits, setIsGettingBenefits] = useState(false);
  const [hasGetBenefitsLoaded, setHasGetBenefitsLoaded] = useState(false);
  const [hasGetBenefitsFailed, setHasGetBenefitsFailed] = useState(false);

  const [isOptingIn, setIsOptingIn] = useState(false);
  const [hasOpted, setHasOpted] = useState(false);
  const [hasOptedFailed, setHasOptedFailed] = useState(false);
  const [optInApiResponse, setOptInApiResponse] = useState(null);

  const hasLoggedIn = get(user, 'authenticated', false);
  const memberDataLoading = get(user, 'memberDataLoading', true);
  const memberDataLoadError = get(user, 'memberDataLoadError', false);

  const benefitFormCode = get(tiles, '0.code', '');
  const selectedBenefit =
    find(apiBenefits?.benefits, { code: benefitFormCode }) || get(optInApiResponse, 'benefit', {});
  const optionsForForm = filter(tiles, { code: benefitFormCode });

  const optInBenefit = useCallback(
    async (formValues) => {
      try {
        setIsOptingIn(true);
        setHasOpted(false);
        setHasOptedFailed(false);

        const response = await api.vffBauV2Api.post('/loyalty/v2/benefits/additional-reward-preferences', {
          data: {
            benefit: {
              action: 'opt-in',
              code: benefitFormCode,
              selectedOption: formValues[benefitFormCode],
            },
          },
        });

        setOptInApiResponse(get(response, 'data.data', null));
        setIsOptingIn(false);
        setHasOpted(true);
      } catch (e) {
        setIsOptingIn(false);
        setHasOptedFailed(true);
      }
    },
    [benefitFormCode],
  );

  useEffect(() => {
    async function getBenefits() {
      try {
        setIsGettingBenefits(true);
        setHasGetBenefitsFailed(false);
        setHasGetBenefitsLoaded(false);
        const response = await api.vffBauV2Api.get('/loyalty/v2/benefits/additional-reward-preferences/opted');

        setApiBenefits(get(response, 'data.data', null));
        setIsGettingBenefits(false);
        setHasGetBenefitsLoaded(true);
      } catch (e) {
        setIsGettingBenefits(false);
        setHasGetBenefitsFailed(true);
      }
    }

    if (hasLoggedIn) {
      getBenefits();
    }
  }, [hasLoggedIn]);

  return (
    <div className={styles.container}>
      {((!hasLoggedIn && memberDataLoading) || (hasLoggedIn && isGettingBenefits)) && (
        <Loading className={styles.loading} />
      )}

      {((!hasLoggedIn && memberDataLoadError) || (hasLoggedIn && hasGetBenefitsFailed)) && (
        <InformationAlert title="Sorry, we're having issues with our system." />
      )}

      {hasLoggedIn && hasGetBenefitsLoaded && (
        <>
          {title && <h2 className={styles.mainTitle}>{title}</h2>}

          {description && <RichTextContent className={styles.description} content={description} />}

          {!isEmpty(optionsForForm) && (
            <BenefitSelectorForm
              benefitFormCode={benefitFormCode}
              selectedBenefit={selectedBenefit}
              selectedOptionDescription={selectedOptionDescription}
              options={optionsForForm}
              optedInDescription={optedInDescription}
              terms={terms}
              memberFirstName={get(user, 'givenName', '')}
              ctaContainer={ctaContainer}
              review={review}
              onConfirm={optInBenefit}
              isOptingIn={isOptingIn}
              hasOpted={hasOpted}
              hasOptedFailed={hasOptedFailed}
              confirmation={confirmation}
              apiErrorMessage={errorMessage}
            />
          )}
        </>
      )}
    </div>
  );
};

BenefitSelector.propTypes = {
  user: PropTypes.shape({}),
  title: PropTypes.string,
  description: PropTypes.string,
  optedInDescription: PropTypes.string,
  selectedOptionDescription: PropTypes.string,
  errorMessage: PropTypes.string,
  tiles: PropTypes.arrayOf(PropTypes.shape({})),
  ctaContainer: PropTypes.shape({}),
  terms: PropTypes.shape({}),
  confirmation: PropTypes.shape({}),
  review: PropTypes.shape({}),
};

BenefitSelector.defaultProps = {
  user: null,
  title: null,
  description: null,
  optedInDescription: null,
  selectedOptionDescription: null,
  errorMessage: null,
  tiles: null,
  ctaContainer: null,
  terms: null,
  confirmation: null,
  review: null,
};

export default connect((state) => ({
  user: state.user,
}))(BenefitSelector);
