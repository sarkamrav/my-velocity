import React from 'react';
import DeepLinking from './DeepLinking';
import deepLinkingMock from './mocks/deep-linking--estore-sample.mock.json';
import homePageMock from './mocks/deep-linking--home-page-fallback.mock.json';
import appDownloadMock from './mocks/deep-linking--promote-app-download.mock.json';

export default {
  title: 'Deep Linking',
};

export const eStoreFallback = () => <DeepLinking {...deepLinkingMock} />;
export const homePageFallback = () => <DeepLinking {...homePageMock} />;
export const promoteAppDownloadFallback = () => <DeepLinking {...appDownloadMock} />;
