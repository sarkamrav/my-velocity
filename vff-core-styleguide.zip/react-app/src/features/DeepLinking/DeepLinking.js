import React, { useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import qs from 'qs';
import { isBrowser, isIOS, isAndroid } from 'react-device-detect';

import { setCookie } from '../../utils/cookies';
import { COMPONENT_NAME, isAbsoluteUrl, parseUrl } from '../../utils/common';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';

const DeepLinking = ({ item }) => {
  const inputRef = useRef();

  useEffect(() => {
    const { iosFallbackUrl, androidFallbackUrl, desktopFallbackUrl } = item;
    function displayContent(cssClass) {
      const container = document.querySelector(`.${cssClass}`);

      if (container) {
        container.classList.remove('vffutils__display--none');
      }
    }

    function parseQueryParameters(queryString) {
      return qs.parse(queryString, { ignoreQueryPrefix: true });
    }

    function getRedirectUrl(fallbackUrl) {
      const urlObject =
        parseUrl(`${isAbsoluteUrl(fallbackUrl) ? fallbackUrl : `${window.location.origin}${fallbackUrl}`}`) || {};
      const parametersInBrowserUrl = parseQueryParameters(window.location.search);
      const parametersInFallbackUrl = parseQueryParameters(urlObject.search);

      return `${urlObject.protocol ? `${urlObject.protocol}//` : ''}${urlObject.hostname ? urlObject.hostname : ''}${urlObject.port ? `:${urlObject.port}` : ''}${urlObject.pathname ? urlObject.pathname : ''}${qs.stringify(
        { ...parametersInBrowserUrl, ...parametersInFallbackUrl },
        { addQueryPrefix: true },
      )}${urlObject.hash ? urlObject.hash : ''}`;
    }

    if (isBrowser && desktopFallbackUrl) {
      window.location.href = getRedirectUrl(desktopFallbackUrl);
    }

    if (isIOS) {
      if (iosFallbackUrl) {
        window.location.href = getRedirectUrl(iosFallbackUrl);
      } else {
        displayContent('vff__ios_fragment_container');
      }
    }

    if (isAndroid) {
      if (androidFallbackUrl) {
        window.location.href = getRedirectUrl(androidFallbackUrl);
      } else {
        displayContent('vff__android_fragment_container');
      }
    }
  }, [item]);

  useEffect(() => {
    if (inputRef && inputRef.current) {
      inputRef.current.select();
      inputRef.current.setSelectionRange(0, 99999);
      document.execCommand('copy');
    }
  }, []);

  useEffect(() => {
    setCookie('deeplinkForNewAppInstallation', window.location.href, 1);
  }, []);

  return (
    <ErrorBoundary section={COMPONENT_NAME.deepLinking}>
      <input style={{ opacity: 0 }} ref={inputRef} type="text" value={window.location.href} readOnly />
    </ErrorBoundary>
  );
};

DeepLinking.propTypes = {
  item: PropTypes.shape({
    iosFallbackUrl: PropTypes.string,
    androidFallbackUrl: PropTypes.string,
    desktopFallbackUrl: PropTypes.string,
  }),
};

DeepLinking.defaultProps = {
  item: {},
};

export default DeepLinking;
