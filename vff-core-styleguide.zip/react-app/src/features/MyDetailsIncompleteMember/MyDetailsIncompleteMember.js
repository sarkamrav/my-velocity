import React, { useState, useEffect, useCallback } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { DateTime } from 'luxon';

import find from 'lodash/find';
import get from 'lodash/get';
import isEmpty from 'lodash/isEmpty';
import reduce from 'lodash/reduce';
import Loading from '../../components/Loading/Loading';
import * as userData from '../../stores/utilities';
import api from '../../utils/api';
import { COMPONENT_NAME, analyticsEventAction, analyticsEventName, serverTimeZone } from '../../utils/common';
import analyticsSend from '../../utils/analytics';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import MessageTile, { messageTileTheme } from '../../components/MessageTile/MessageTile';
import IncompleteMemberForm from './IncompleteMemberForm/IncompleteMemberForm';
import styles from './MyDetailsIncompleteMember.css';

const MyDetailsIncompleteMember = ({
  user,
  title,
  description,
  gamificationMessage,
  gamificationImageUrl,
  completeMemberPagePath,
  passwordDetails,
  securityQuestionDetails,
  myDetailsForm,
  confirmationPage,
  interstitialErrorPage,
  successPage,
  campaignStartDate,
  consentGrantBeforeDate,
}) => {
  const { impression } = analyticsEventAction;
  const { formStart, formStep } = analyticsEventName;

  const hasLoggedIn = userData.getHasLoggedIn(user);
  const memberDataLoadError = userData.getMemberDataLoadError(user);
  const membershipID = userData.getLoyaltyMembershipID(user);
  const userStatus = userData.getAccountStatusCode(user);

  // newFlow for full join check
  const memberJoinDate = userData.getJoinDate(user);
  const memberJoinServerDate = DateTime.fromISO(memberJoinDate, serverTimeZone).startOf('day');

  const liteJoinConsentServerDate = DateTime.fromMillis(consentGrantBeforeDate, serverTimeZone).startOf('day');
  const isProfileCompletedBeforeDate = memberJoinServerDate < liteJoinConsentServerDate;

  let isFullJoinCampaign = false;

  if (campaignStartDate && memberJoinDate) {
    if (memberJoinServerDate >= DateTime.fromMillis(campaignStartDate, serverTimeZone).startOf('day')) {
      isFullJoinCampaign = true;
    }
  }

  // Check and then redirect user to My Detail page
  if (userStatus === 'ACTIVE') window.location.href = completeMemberPagePath;

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const [hasSecurityQuestion, setHasSecurityQuestion] = useState(false);
  const [userDetails, setUserDetails] = useState({});

  const securityQuestionApiUrl = '/loyalty/v2/security-question';
  const userDetailsApiUrl = '/loyalty/v2/members/profile';
  const fetchSecurityQuestion = useCallback(async () => {
    try {
      setLoading(true);
      const response = await Promise.all([
        await api.vffV2Api.get(securityQuestionApiUrl),
        await api.vffV2Api.get(userDetailsApiUrl),
      ]);

      setHasSecurityQuestion(!isEmpty(response[0].data.data.question));
      setUserDetails(response[1].data.data);
      setLoading(false);
    } catch (e) {
      const errorCode = get(e, 'response.data.code', '');
      const errorFields = get(e, 'response.data.errorFields', '');
      const authoredApiErrMsg = get(securityQuestionDetails, 'errorMessages.apiErrorMessages');
      const getCodeSpecificError = find(
        authoredApiErrMsg,
        (errorMsg) => errorMsg.code === errorCode && !errorMsg.errorFieldName,
      );
      const getFieldSpecificError = reduce(
        errorFields,
        (result, errorField) =>
          result ||
          find(authoredApiErrMsg, {
            code: errorCode,
            errorFieldName: errorField.field,
          }),
        null,
      );

      // `computedErrorMessage` returns the filtered errorMessage accordingly
      const computedErrorMessage =
        getFieldSpecificError ||
        getCodeSpecificError ||
        get(securityQuestionDetails, 'errorMessages.defaultErrorMessage');
      setError(computedErrorMessage);
      setLoading(false);
    }
  }, [securityQuestionDetails]);

  useEffect(() => {
    if (hasLoggedIn) {
      fetchSecurityQuestion();
    }
  }, [hasLoggedIn, fetchSecurityQuestion]);

  const isContentReady = !loading && !error && !isEmpty(userDetails);

  if (isContentReady) {
    analyticsSend({
      eventAction: impression,
      eventName: hasSecurityQuestion ? formStep : formStart,
      eventCategory: 'forms',
      eventElementName: 'velocityLiteJoin',
      eventElementText: hasSecurityQuestion ? 'My Details' : 'Password',
    });
  }

  return (
    <ErrorBoundary section={COMPONENT_NAME.myDetailsIncompleteMember}>
      <div className={styles.container}>
        {!hasLoggedIn && memberDataLoadError ? (
          <div className={styles.errorContainer}>
            <MessageTile theme={messageTileTheme.error} description="Sorry, we're having issues with our system." />
          </div>
        ) : (
          <>
            {loading ? (
              <div className={styles.loadingContainer}>
                <Loading />
              </div>
            ) : (
              <>
                {error && (
                  <div className={styles.errorContainer}>
                    <MessageTile theme={messageTileTheme.error} description={error.description} />
                  </div>
                )}
                {isContentReady && (
                  <IncompleteMemberForm
                    userDetails={userDetails}
                    title={title}
                    description={description}
                    gamificationMessage={gamificationMessage}
                    gamificationImageUrl={gamificationImageUrl}
                    passwordDetails={passwordDetails}
                    securityQuestionDetails={securityQuestionDetails}
                    myDetailsForm={myDetailsForm}
                    confirmationPage={confirmationPage}
                    membershipID={membershipID}
                    successPage={successPage}
                    interstitialErrorPage={interstitialErrorPage}
                    hasSecurityQuestion={hasSecurityQuestion}
                    isFullJoinCampaign={isFullJoinCampaign}
                    isProfileCompletedBeforeDate={isProfileCompletedBeforeDate}
                  />
                )}
              </>
            )}
          </>
        )}
      </div>
    </ErrorBoundary>
  );
};

MyDetailsIncompleteMember.propTypes = {
  user: PropTypes.shape({}),
  title: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
  gamificationMessage: PropTypes.string,
  gamificationImageUrl: PropTypes.string,
  completeMemberPagePath: PropTypes.string.isRequired,
  passwordDetails: PropTypes.shape({}).isRequired,
  securityQuestionDetails: PropTypes.shape({}).isRequired,
  myDetailsForm: PropTypes.shape({}).isRequired,
  confirmationPage: PropTypes.shape({}).isRequired,
  campaignStartDate: PropTypes.number,
  consentGrantBeforeDate: PropTypes.number,
  successPage: PropTypes.shape({}),
  interstitialErrorPage: PropTypes.shape({}),
};

MyDetailsIncompleteMember.defaultProps = {
  user: null,
  successPage: null,
  interstitialErrorPage: null,
  gamificationMessage: null,
  gamificationImageUrl: null,
  consentGrantBeforeDate: 0,
  campaignStartDate: 0,
};

export default connect((state) => ({
  user: state.user,
}))(MyDetailsIncompleteMember);
