import React from 'react';
import { Provider } from 'react-redux';
import MockAdapter from 'axios-mock-adapter';
import { configureStore } from '../../stores';
import api from '../../utils/api';

import myDetailsIncompleteMemberMock from './mocks/MyDetailsIncompleteMember.mock.json';
import MyDetailsIncompleteMember from './MyDetailsIncompleteMember';
import userData from '../Navigation/mocks/user.mock.json';

export default {
  title: 'My Details - Incomplete Member',
};

export const DefaultFormViewCreateSuccess = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVff.onGet('/loyalty/v2/security-question').reply(200, {
    data: {
      question: '',
    },
  });

  mockVff.onGet('/loyalty/v2/members/profile').reply(200, {
    data: {
      individual: {
        identity: {
          firstName: 'Garry',
          lastName: 'Webtest-ac',
          title: 'MR',
        },
        contact: {
          emails: [
            {
              category: 'PERSONAL',
              address: 'garry.webtest-dummy@virginaustralia.com',
              contactValidity: {
                isMain: true,
              },
            },
          ],
          phones: [
            {
              category: 'PERSONAL',
              deviceType: 'MOBILE',
              countryCallingCode: '61',
              number: '91234567',
              contactValidity: {
                isMain: true,
              },
            },
          ],
        },
      },
    },
  });

  mockVff.onPatch('/loyalty/v2/password').reply(200, {
    data: {
      membershipId: '1234567890',
      locked: 'N',
      authentication: {
        failures: '0',
      },
    },
  });

  mockVff.onPost('/loyalty/v2/security-question').reply(200, {
    data: {
      membershipId: '1234567890',
      questionId: '8',
      answer: 'ABC',
      question: "What was your first pet's name?",
    },
  });

  mockVff.onPatch('/loyalty/v2/members').reply(200, {});

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
          account: {
            accountStatusCode: 'INCOMPLETE',
          },
        },
      })}
    >
      <MyDetailsIncompleteMember {...myDetailsIncompleteMemberMock} />
    </Provider>
  );
};

DefaultFormViewCreateSuccess.storyName = 'Form view - Create Success';

export const DefaultFormViewCreateFail = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVff.onGet('/loyalty/v2/security-question').reply(200, {
    data: {
      question: '',
    },
  });

  mockVff.onGet('/loyalty/v2/members/profile').reply(200, {
    data: {
      individual: {
        identity: {
          firstName: 'Garry',
          lastName: 'Webtest-ac',
          title: 'MR',
        },
        contact: {
          emails: [
            {
              category: 'PERSONAL',
              address: 'garry.webtest-dummy@virginaustralia.com',
              contactValidity: {
                isMain: true,
              },
            },
          ],
          phones: [
            {
              category: 'PERSONAL',
              deviceType: 'MOBILE',
              countryCallingCode: '61',
              number: '91234567',
              contactValidity: {
                isMain: true,
              },
            },
          ],
        },
      },
    },
  });

  mockVff.onPatch('/loyalty/v2/password').reply(200, {
    data: {
      membershipId: '1234567890',
      locked: 'N',
      authentication: {
        failures: '0',
      },
    },
  });

  mockVff.onPost('/loyalty/v2/security-question').reply(200, {
    data: {
      membershipId: '0000053082',
      questionId: '8',
      answer: 'ABC',
      question: "What was your first pet's name?",
    },
  });

  mockVff.onPatch('/loyalty/v2/members').reply(400, {
    code: 4001,
    title: 'Validation Error',
    detail: 'Validation failed for below fields',
    status: 400,
    errorFields: [
      {
        field: 'data.membershipId',
        message: 'must not be null',
      },
    ],
  });

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
          account: {
            accountStatusCode: 'INCOMPLETE',
          },
        },
      })}
    >
      <MyDetailsIncompleteMember {...myDetailsIncompleteMemberMock} />
    </Provider>
  );
};

DefaultFormViewCreateFail.storyName = 'Form view - Create Fail';

export const DuplicateMembershipError = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVff.onGet('/loyalty/v2/security-question').reply(200, {
    data: {
      question: '',
    },
  });

  mockVff.onGet('/loyalty/v2/members/profile').reply(200, {
    data: {
      individual: {
        identity: {
          firstName: 'Garry',
          lastName: 'Webtest-ac',
          title: 'MR',
        },
        contact: {
          emails: [
            {
              category: 'PERSONAL',
              address: 'garry.webtest-dummy@virginaustralia.com',
              contactValidity: {
                isMain: true,
              },
            },
          ],
          phones: [
            {
              category: 'PERSONAL',
              deviceType: 'MOBILE',
              countryCallingCode: '61',
              number: '91234567',
              contactValidity: {
                isMain: true,
              },
            },
          ],
        },
      },
    },
  });

  mockVff.onPatch('/loyalty/v2/password').reply(200, {
    data: {
      membershipId: '1234567890',
      locked: 'N',
      authentication: {
        failures: '0',
      },
    },
  });

  mockVff.onPost('/loyalty/v2/security-question').reply(200, {
    data: {
      membershipId: '0000053082',
      questionId: '8',
      answer: 'ABC',
      question: "What was your first pet's name?",
    },
  });

  mockVff.onPatch('/loyalty/v2/members').reply(400, {
    code: 37014,
    title: 'Conflict',
    detail: 'duplicate Membership is found',
    status: 409,
  });

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
          account: {
            accountStatusCode: 'INCOMPLETE',
          },
        },
      })}
    >
      <MyDetailsIncompleteMember {...myDetailsIncompleteMemberMock} />
    </Provider>
  );
};

DuplicateMembershipError.storyName = 'Form view - Duplicate Membership Error';

export const HasSecurityQuestion = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVff.onGet('/loyalty/v2/security-question').reply(200, {
    data: {
      membershipId: '1234567890',
      questionId: '8',
      question: "What was your first pet's name?",
    },
  });

  mockVff.onGet('/loyalty/v2/members/profile').reply(200, {
    data: {
      individual: {
        identity: {
          firstName: 'Garry',
          lastName: 'Webtest-ac',
          title: 'MR',
        },
        contact: {
          emails: [
            {
              category: 'PERSONAL',
              address: 'garry.webtest-dummy@virginaustralia.com',
              contactValidity: {
                isMain: false,
              },
            },
            {
              category: 'PERSONAL',
              address: 'webtest-dummy@virginaustralia.com',
              contactValidity: {
                isMain: true,
              },
            },
          ],
          phones: [
            {
              category: 'PERSONAL',
              deviceType: 'MOBILE',
              countryCallingCode: '64',
              number: '91234567',
              contactValidity: {
                isMain: true,
              },
            },
          ],
        },
      },
    },
  });

  mockVff.onPatch('/loyalty/v2/members').reply(200, {});

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
          account: {
            accountStatusCode: 'INCOMPLETE',
          },
        },
      })}
    >
      <MyDetailsIncompleteMember {...myDetailsIncompleteMemberMock} />
    </Provider>
  );
};

HasSecurityQuestion.storyName = 'Form View: Has Security Question';

export const SecurityQuestionApiError = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVff.onGet('/loyalty/v2/members/profile').reply(200, {});
  mockVff.onGet('/loyalty/v2/security-question').reply(400, {
    code: 39556,
    title: 'Bad Request',
  });

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
          account: {
            accountStatusCode: 'INCOMPLETE',
          },
        },
      })}
    >
      <MyDetailsIncompleteMember {...myDetailsIncompleteMemberMock} />
    </Provider>
  );
};

SecurityQuestionApiError.storyName = 'Error view - Security Question';

export const AlreadyActiveUser = () => (
  <Provider
    store={configureStore({
      user: {
        memberDataLoaded: true,
        memberDataLoading: false,
        authenticated: true,
        ...userData,
        account: {
          accountStatusCode: 'ACTIVE',
        },
      },
    })}
  >
    <MyDetailsIncompleteMember {...myDetailsIncompleteMemberMock} />
  </Provider>
);

AlreadyActiveUser.storyName = 'Redirect: Already Submitted Incomplete Member Form';

export const SystemError = () => (
  <div style={{ backgroundColor: '#f9f9f9' }}>
    <Provider
      store={configureStore({
        user: {
          memberDataLoadError: true,
          authenticated: false,
        },
      })}
    >
      <MyDetailsIncompleteMember {...myDetailsIncompleteMemberMock} />
    </Provider>
  </div>
);
SystemError.storyName = 'Error View - System Error';

const Template = (args) => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVff.onGet('/loyalty/v2/security-question').reply(200, {
    data: {
      question: '',
    },
  });

  mockVff.onGet('/loyalty/v2/members/profile').reply(200, {
    data: {
      individual: {
        identity: {
          firstName: 'Garry',
          lastName: 'Webtest-ac',
          title: 'MR',
        },
        contact: {
          emails: [
            {
              category: 'PERSONAL',
              address: 'garry.webtest-dummy@virginaustralia.com',
              contactValidity: {
                isMain: true,
              },
            },
          ],
          phones: [
            {
              category: 'PERSONAL',
              deviceType: 'MOBILE',
              countryCallingCode: '61',
              number: '91234567',
              contactValidity: {
                isMain: true,
              },
            },
          ],
        },
      },
    },
  });

  mockVff.onPatch('/loyalty/v2/password').reply(200, {
    data: {
      membershipId: '1234567890',
      locked: 'N',
      authentication: {
        failures: '0',
      },
    },
  });

  mockVff.onPost('/loyalty/v2/security-question').reply(200, {
    data: {
      membershipId: '1234567890',
      questionId: '8',
      answer: 'ABC',
      question: "What was your first pet's name?",
    },
  });

  mockVff.onPatch('/loyalty/v2/members').reply(200, {});
  const { accuralBPError } = args;
  if (accuralBPError) {
    mockVff.onPost('/loyalty/v2/digital-accrual').reply(400, {
      code: 4193,
      title: 'ACC code is not correct',
      detail: 'The provided ACC code is not correct',
      status: 400,
    });
  } else {
    mockVff.onPost('/loyalty/v2/digital-accrual').reply(200, {});
  }

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
          account: {
            accountStatusCode: 'INCOMPLETE',
            joinDate: '2024-05-01',
          },
        },
      })}
    >
      <MyDetailsIncompleteMember {...myDetailsIncompleteMemberMock} />
    </Provider>
  );
};

export const AccuredBPRewardsSuccess = Template.bind({});
AccuredBPRewardsSuccess.storyName = 'Accrued BP - Full Join Rewards Success';

export const AccuredBPRewardsFail = Template.bind({});
AccuredBPRewardsFail.storyName = 'Accrued BP - Full Join Rewards Fail';
AccuredBPRewardsFail.args = {
  accuralBPError: true,
};
