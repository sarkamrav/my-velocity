import React, { forwardRef } from 'react';
import isEmpty from 'lodash/isEmpty';
import PropTypes from 'prop-types';
import styles from './IncompleteMemberSuccessPage.css';
import RichTextContent from '../../../components/RichTextContent/RichTextContent';
import syncText from '../../../utils/syncText';

import TopContentContainer, {
  contentContainerType,
} from '../../../components/Form/containers/TopContentContainer/TopContentContainer';
import Button from '../../../components/Button/Button';
import A from '../../../components/Button/A';

const IncompleteMemberSuccessPage = ({
  containerRef,
  successPage,
  interstitialErrorPage,
  userIdentity,
  loading,
  accuralBPError: hasError,
  accuredBonusPointApiCall,
}) => {
  const { firstName, lastName } = userIdentity;

  const getCta = (cta, className) => (
    <A
      href={cta.ctaUrl}
      title={cta.ctaTitle}
      target={cta.ctaOpenInNewTab ? '_blank' : '_self'}
      buttonType={cta.ctaStyle}
      ctaAsLink={cta.ctaAsLink}
      ctaImage={cta.ctaImage}
      className={className}
    >
      {cta.ctaLabel}
    </A>
  );

  const getScannerContainerInfo = (scannerInfo, className) => (
    <div className={styles.scannerInfoContainer}>
      <div className={styles.titleContainer}>
        <span className={styles.scannerTitle}>{scannerInfo.title}</span>
        <img className={styles.scannerImg} src={scannerInfo?.iconUrl} alt={scannerInfo?.title} />
      </div>
      {!isEmpty(scannerInfo?.ctaContainer) && getCta(scannerInfo?.ctaContainer, className)}
    </div>
  );

  const getContentInfo = (contentInfo) => (
    <div className={styles.contentContainer}>
      <RichTextContent className={styles.title} content={syncText(contentInfo?.title, { firstName, lastName })} />
      <RichTextContent className={styles.description} content={contentInfo?.description || ''} />
      {!hasError && <RichTextContent className={styles.bonusPointsMessage} content={contentInfo?.bonusPointsMessage} />}
    </div>
  );
  return (
    <TopContentContainer theme={contentContainerType.typeB}>
      <div ref={containerRef} className={styles.incompleteMemberContainer}>
        <div className={styles.imageWrapper}>
          {!hasError && <img src={successPage?.iconUrl} alt={successPage?.title} />}
          {hasError && <img src={interstitialErrorPage?.iconUrl} alt={interstitialErrorPage?.title} />}
        </div>

        {hasError ? getContentInfo(interstitialErrorPage) : getContentInfo(successPage)}

        {hasError && (
          <div className={styles.errorContainerWrapper}>
            <div className={styles.errorContainer}>
              <div className={styles.errorTitle}>{interstitialErrorPage?.errorMessage?.title}</div>
              <RichTextContent
                className={styles.errorDescription}
                content={interstitialErrorPage?.errorMessage?.description}
              />
              <Button
                type="submit"
                className={styles.errorCta}
                buttonType={interstitialErrorPage?.errorMessage?.ctaContainer.ctaType}
                loading={loading}
                disabled={loading}
                onClick={accuredBonusPointApiCall}
              >
                {interstitialErrorPage?.errorMessage?.ctaContainer?.ctaLabel}
              </Button>
            </div>
          </div>
        )}

        {!hasError && (
          <div className={styles.infoContainer}>
            <div className={styles.bonusinfo}>
              <img src={successPage?.downloadApps?.iconUrl} alt={successPage?.downloadApps?.title} />
              <div className={styles.bonusInfoTitle}>{successPage?.downloadApps?.title}</div>
            </div>
            <div className={styles.scannerContainer}>
              {getScannerContainerInfo(successPage?.downloadApps?.ios, styles.scannerCta)}
              {getScannerContainerInfo(successPage?.downloadApps?.android, styles.scannerCta)}
            </div>
          </div>
        )}
        {hasError
          ? getCta(interstitialErrorPage?.ctaContainer, styles.linkCta)
          : getCta(successPage?.ctaContainer, styles.linkCta)}
      </div>
    </TopContentContainer>
  );
};

IncompleteMemberSuccessPage.propTypes = {
  containerRef: PropTypes.shape({}),
  successPage: PropTypes.shape({
    iconUrl: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    downloadApps: PropTypes.shape({
      iconUrl: PropTypes.string,
      title: PropTypes.string,
      ios: PropTypes.shape({}),
      android: PropTypes.shape({}),
      ctaContainer: PropTypes.shape({}),
    }),
    ctaContainer: PropTypes.shape({
      ctaLabel: PropTypes.string,
      ctaType: PropTypes.string,
    }),
  }),
  interstitialErrorPage: PropTypes.shape({
    iconUrl: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    errorMessage: PropTypes.shape({
      title: PropTypes.string,
      description: PropTypes.string,
      ctaContainer: PropTypes.shape({
        ctaLabel: PropTypes.string,
        ctaType: PropTypes.string,
      }),
    }),
    ctaContainer: PropTypes.shape({
      ctaLabel: PropTypes.string,
      ctaType: PropTypes.string,
    }),
  }),
  loading: PropTypes.bool,
  accuralBPError: PropTypes.bool,
  accuredBonusPointApiCall: PropTypes.func,
  userIdentity: PropTypes.shape({
    firstName: PropTypes.string,
    lastName: PropTypes.string,
  }),
};

IncompleteMemberSuccessPage.defaultProps = {
  containerRef: null,
  successPage: {
    downloadApps: {
      iconUrl: '',
      title: '',
      ios: null,
      android: null,
      ctaContainer: PropTypes.shape({}),
    },
    ctaContainer: PropTypes.shape({}),
  },
  interstitialErrorPage: {
    errorMessage: {
      title: '',
      description: '',
      ctaContainer: {
        ctaLabel: '',
        ctaType: '',
      },
    },
    ctaContainer: PropTypes.shape({}),
  },
  loading: false,
  accuralBPError: false,
  userIdentity: {
    firstName: '',
    lastName: '',
  },
  accuredBonusPointApiCall: () => {},
};

export default forwardRef((props, ref) => <IncompleteMemberSuccessPage {...props} containerRef={ref} />);
