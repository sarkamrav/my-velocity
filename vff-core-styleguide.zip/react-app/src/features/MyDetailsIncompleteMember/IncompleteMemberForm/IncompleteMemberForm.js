import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import omit from 'lodash/omit';
import includes from 'lodash/includes';
import { DateTime } from 'luxon';
import get from 'lodash/get';
import isUndefined from 'lodash/isUndefined';
import find from 'lodash/find';
import flatten from 'lodash/flatten';
import isEmpty from 'lodash/isEmpty';
import toUpper from 'lodash/toUpper';
import reduce from 'lodash/reduce';
import api from '@utils/api';
import Button from '@components/Button/Button';
import CollapsibleCard from '@components/CollapsibleCardV2/CollapsibleCardV2';
import Input from '@components/Form/Input/Input';
import Select from '@components/Form/Select/Select';
import * as normalize from '@components/Form/normalizers';
import { normalizeFormField, validateFormField } from '@components/Form/utils';
import * as validate from '@components/Form/validators';
import RichTextContent from '@components/RichTextContent/RichTextContent';
import useEmailApiValidation from '@hooks/useEmailApiValidation';
import analyticsSend from '@utils/analytics';
import FormFieldContainer, { FormFieldType } from '@components/Form/containers/FormFieldContainer/FormFieldContainer';
import {
  getNavigationHeight,
  smoothScrollToElement,
  getCountryCode,
  analyticsEventAction,
  analyticsEventName,
} from '@utils/common';
import syncText from '@utils/syncText';
import FormContainer, {
  formContainerColor,
  formContainerType,
} from '@components/Form/containers/FormContainer/FormContainer';
import FormRow from '@components/Form/containers/FormRow/FormRow';
import TopContentContainer, {
  contentContainerType,
} from '@components/Form/containers/TopContentContainer/TopContentContainer';
import Checkbox from '@components/Form/Checkbox/Checkbox';
import ErrorSummary from '@components/Form/ErrorSummary/ErrorSummary';
import SuccessMessageTile, { successMessageTheme } from '@components/SuccessMessageTile/SuccessMessageTile';
import { countryCodeOptions, countriesByCode } from '@utils/referenceData';
import FormFieldSet, { formFieldGroupLabelStyle } from '@components/Form/FormFieldSet/FormFieldSet';
import MessageTile, { messageTileTheme } from '@components/MessageTile/MessageTile';
import FormContentContainer from '@components/Form/containers/FormContentContainer/FormContentContainer';
import RadioButton from '@components/Form/RadioButton/RadioButton';
import { COUNTRY_CODE, PERSON_TITLE } from '../../JoinPage/constants';
import {
  stateOptions,
  defaultCountryOptions,
  personTitleOptions,
  securityQuestionOptions,
  genderOptions,
} from '../../JoinPage/referenceData';
import SecretInput from '../../JoinPage/components/SecretInput/SecretInput';
import PasswordValidator from '../../JoinPage/components/PasswordValidator/PasswordValidator';
import { getGender, getTelephoneNumber } from '../../JoinPage/utils';
import AddressAutocomplete from '../../JoinPage/components/AddressAutocomplete/AddressAutocomplete';
import IncompleteMemberSuccessPage from '../Page/IncompleteMemberSuccessPage';

import styles from './IncompleteMemberForm.css';

import { fieldLabels } from './constants';

const IncompleteMemberForm = ({
  title,
  description,
  gamificationMessage,
  gamificationImageUrl,
  hasSecurityQuestion,
  passwordDetails,
  securityQuestionDetails,
  myDetailsForm,
  confirmationPage,
  membershipID,
  userDetails,
  isFullJoinCampaign,
  successPage,
  isProfileCompletedBeforeDate,
  interstitialErrorPage,
}) => {
  const formStates = {
    STEP_1: 'set_password',
    STEP_2: 'set_securityQuestion',
    STEP_3: 'set_details',
  };
  const submitErrorAlertId = useRef();
  const successPageRef = useRef();
  const successInfoBoxId = 'my-detail-success-info-box';

  const [currentStep, setCurrentStep] = useState(hasSecurityQuestion ? formStates.STEP_3 : formStates.STEP_1);

  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [postError, setPostError] = useState('');
  const [isStepOneSubmitted, setIsStepOneSubmitted] = useState(hasSecurityQuestion);
  const [isStepTwoSubmitted, setIsStepTwoSubmitted] = useState(hasSecurityQuestion);
  const [fullJoinRewardPoints, setFullJoinRewardPoints] = useState(false);
  const [accuralBPError, setAccuralBPError] = useState(false);
  const [showErrorSummary, setShowErrorSummary] = useState(false);
  const [shakeButton, setShakeButton] = useState(false);

  // event actions and event name for Analytics
  const { impression } = analyticsEventAction;
  const { formFailure, formStep, formSuccess } = analyticsEventName;

  const userIdentity = get(userDetails, 'individual.identity');
  const gender = userIdentity?.gender?.toUpperCase();
  const userContact = get(userDetails, 'individual.contact') ?? {};
  const { firstName, lastName, title: salutatation } = userIdentity;
  const { emails, phones } = userContact;
  const flattenCountryCodeOptions = flatten(countryCodeOptions.map((i) => i.options));

  const findCountryCodeByCountryLabel = (selectedCountryCode) => {
    let countryCode = '';
    if (!isUndefined(selectedCountryCode)) {
      countryCode = find(countriesByCode, (country) => country.phoneCode === selectedCountryCode).code;
    }
    return find(flattenCountryCodeOptions, (code) => code.value === countryCode)?.value ?? '';
  };

  const findCountryLabelByCountryCode = (countryCode) =>
    find(flattenCountryCodeOptions, (code) => code.value === countryCode) ?? { placeholder: 'Code', value: '' };

  const userEmail = emails?.find((item) => item.contactValidity.isMain);
  const userMobileDetails = isUndefined(phones) ? '' : phones[0];
  const userLandlineDetails = isUndefined(phones) ? '' : phones[1];

  const initialMobileCountryCode = findCountryCodeByCountryLabel(userMobileDetails?.countryCallingCode);
  const initialLandlineCountryCode = findCountryCodeByCountryLabel(userLandlineDetails?.countryCallingCode);

  const initialValues = {
    firstName,
    lastName,
    email: isUndefined(userEmail) ? '' : userEmail.address,
    title: find(personTitleOptions, (item) => item.value === salutatation),
    gender: find(genderOptions, { value: gender }) ? gender : '',
    hasBusinessAddress: false,
    preferred_AddressType: 'PERSONAL',
    mobile_number: userMobileDetails.number ?? '',
    mobile_countryCallingCode: findCountryLabelByCountryCode(initialMobileCountryCode),
    landline_number: userLandlineDetails?.number ?? '',
    landline_areaCode: userLandlineDetails?.areaCode ?? '',
    landline_countryCallingCode: findCountryLabelByCountryCode(initialLandlineCountryCode),
  };

  // form data
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [touchedFields, setTouchedFields] = useState([]);
  const isNewPasswordConfirmTouched = includes(touchedFields, 'newPasswordConfirm');
  const isTitleDr = values?.title?.value === PERSON_TITLE.DOCTOR;

  const { error: emailApiError, loading: emailApiLoading } = useEmailApiValidation(values);

  function shouldShowField(fieldName, currentFormValues) {
    if (currentFormValues === undefined) {
      return true;
    }
    switch (fieldName) {
      case 'personal_state':
      case 'business_state':
        return currentFormValues.value === COUNTRY_CODE.AUSTRALIA;

      case 'personal_postalCode':
      case 'business_postalCode':
        return (
          currentFormValues.value === COUNTRY_CODE.AUSTRALIA || currentFormValues.value === COUNTRY_CODE.NEW_ZEALAND
        );

      default:
        return true;
    }
  }

  // List of Mandatory Fields
  const fieldValidators = useMemo(
    () => ({
      newPassword: [
        validate.required('Password is required'),
        validate.password(
          'The password contains invalid characters, only the following special characters are accepted: ‘* ! ~ @ # $ % ^ & ( ) _ - + =',
        ),
        ...(isNewPasswordConfirmTouched
          ? [validate.matchesField('newPasswordConfirm', 'The password you have entered does not match')]
          : []),
      ],
      newPasswordConfirm: [
        validate.required('A password confirmation is required'),
        validate.password(
          'The password contains invalid characters, only the following special characters are accepted: ‘* ! ~ @ # $ % ^ & ( ) _ - + =',
        ),
        validate.matchesField('newPassword', 'The password you have entered does not match'),
      ],
      securityQuestion: [validate.required('Please select a security question')],
      securityAnswer: [
        validate.required('Please provide an answer to your selected security question'),
        validate.securityAnswer(validate.acceptSingleCharacterSecurityAnswer(values.securityQuestion)),
        validate.validSecurityAnswerCharacterCheck('Security answer contains invalid characters'),
      ],
      title: [validate.required('Title is required')],
      ...(isTitleDr ? { gender: [validate.required('Gender is required')] } : {}),
      birthDate: [validate.required('Date of birth is required'), validate.dateOfBirth('Invalid date of birth')],
      preferredFirstName: [validate.optionalName('Invalid name')],
      email: [
        validate.required('Email is required'),
        validate.email('The email address you have entered is incomplete or invalid'),
      ],
      preferred_AddressType: [validate.required('Address type is required')],
      personal_country: [validate.required('Country is required')],
      personal_addressLine1: [validate.required('You must enter your home address (starting on the first line)')],
      personal_postalCode: [validate.required('Postcode is required'), validate.postCode],
      personal_cityName: [validate.required('Suburb is required')],
      personal_state: [validate.required('State is required')],
      business_country: [validate.required('Country is required')],
      business_addressLine1: [validate.required('You must enter your business address (starting on the first line)')],
      business_postalCode: [validate.required('Postcode is required'), validate.postCode],
      business_cityName: [validate.required('Suburb is required')],
      business_state: [validate.required('State is required')],
      mobile_countryCallingCode: [validate.required('Please select a Country Code')],
      mobile_number: [validate.required('Mobile number is required')],
      ...(isEmpty(values.landline_number) ? { mobile_number: [validate.required('Mobile number is required')] } : {}),
    }),
    [isNewPasswordConfirmTouched, isTitleDr, values.landline_number, values.securityQuestion],
  );

  // Validation Rules
  const fieldNormalizers = useMemo(
    () => ({
      securityAnswer: [normalize.maxLength(50)],
      personal_addressLine1: [normalize.maxLength(52)],
      personal_addressLine2: [normalize.maxLength(52)],
      business_addressLine1: [normalize.maxLength(52)],
      business_addressLine2: [normalize.maxLength(52)],
      personal_postalCode: [normalize.onlyNumbers],
      business_postalCode: [normalize.onlyNumbers],
      mobile_number: [normalize.phoneNumber, normalize.maxLength(15)],
      landline_number: [normalize.phoneNumber, normalize.maxLength(15)],
      landline_areaCode: [normalize.onlyNumbers, normalize.maxLength(3)],
    }),
    [],
  );

  const errorList = useMemo(
    () =>
      Object.keys(errors).map((errorKey) => ({
        label: fieldLabels[errorKey],
        value: errorKey,
      })),
    [errors],
  );

  // Validates field and returns an error message if it is invalid
  const validateField = useCallback(
    (fieldName, fieldValue) => validateFormField(fieldValue, fieldValidators[fieldName], values),
    [fieldValidators, values],
  );

  // Runs and applies field validation
  const runFieldValidation = useCallback(
    (fieldName, fieldValue) => {
      const error = validateField(fieldName, fieldValue);
      if (error) {
        setErrors((currentErrors) => ({
          ...currentErrors,
          [fieldName]: error,
          ...(fieldName === 'newPassword' ? { newPasswordConfirm: '' } : {}),
          ...(fieldName === 'newPasswordConfirm' ? { newPassword: '' } : {}),
        }));
      } else {
        setErrors((currentErrors) =>
          omit(currentErrors, [
            fieldName,
            ...(fieldName === 'newPassword' ? ['newPasswordConfirm'] : ''),
            ...(fieldName === 'newPasswordConfirm' ? ['newPassword'] : []),
          ]),
        );
      }
    },
    [validateField],
  );

  const handleFieldChange = useCallback(
    (fieldName) => (newValue) => {
      const normalizedValue = normalizeFormField(newValue, fieldNormalizers[fieldName]);

      // Set value
      setValues((previousValues) => ({
        ...previousValues,
        [fieldName]: normalizedValue,
      }));

      // Give immediate error feedback for fields that are already touched
      const isTouched = includes(touchedFields, fieldName);
      if (isTouched) {
        runFieldValidation(fieldName, normalizedValue);
      }
    },
    [runFieldValidation, fieldNormalizers, touchedFields],
  );

  const handleFieldChangeEvent = useCallback(
    (event) => {
      handleFieldChange(event.target.name)(event.target.value);
    },
    [handleFieldChange],
  );

  const handleFieldBlur = useCallback(
    (fieldName) => (newValue) => {
      const fieldValue = isUndefined(newValue) ? values[fieldName] : newValue;

      // Add to list of touched fields if required
      if (!includes(touchedFields, fieldName)) {
        setTouchedFields((currentTouchedFields) => [...currentTouchedFields, fieldName]);
      }

      // Set any errors
      runFieldValidation(fieldName, fieldValue);
    },
    [runFieldValidation, touchedFields, values],
  );

  const handleFieldBlurEvent = useCallback(
    (event) => {
      handleFieldBlur(event.target.name)();
    },
    [handleFieldBlur],
  );

  const handlePersonalAddressSelection = useCallback(
    (address) => {
      const addressLine = get(find(address, 'addressLine1'), 'addressLine1');
      const suburb = get(find(address, 'locality'), 'locality') || get(find(address, 'province'), 'province');
      const state = find(
        stateOptions,
        (option) => toUpper(option.value) === get(find(address, 'province'), 'province'),
      );
      const postCode = get(find(address, 'postalCode'), 'postalCode');

      handleFieldChange('personal_addressLine1')(addressLine);
      handleFieldBlur('personal_addressLine1')(addressLine);

      handleFieldChange('personal_cityName')(suburb);
      handleFieldBlur('personal_cityName')(suburb);

      handleFieldChange('personal_state')(state);
      handleFieldBlur('personal_state')(state);

      handleFieldChange('personal_postalCode')(postCode);
      handleFieldBlur('personal_postalCode')(postCode);
    },
    [handleFieldBlur, handleFieldChange],
  );

  const handleBusinessAddressSelection = useCallback(
    (address) => {
      const addressLine = get(find(address, 'addressLine1'), 'addressLine1');
      const suburb = get(find(address, 'locality'), 'locality') || get(find(address, 'province'), 'province');
      const state = find(
        stateOptions,
        (option) => toUpper(option.value) === get(find(address, 'province'), 'province'),
      );
      const postCode = get(find(address, 'postalCode'), 'postalCode');

      handleFieldChange('business_addressLine1')(addressLine);
      handleFieldBlur('business_addressLine1')(addressLine);

      handleFieldChange('business_cityName')(suburb);
      handleFieldBlur('business_cityName')(suburb);

      handleFieldChange('business_state')(state);
      handleFieldBlur('business_state')(state);

      handleFieldChange('business_postalCode')(postCode);
      handleFieldBlur('business_postalCode')(postCode);
    },
    [handleFieldBlur, handleFieldChange],
  );

  function checkStepOneValidity() {
    return (
      !!values.newPassword &&
      !errors.newPassword &&
      !!values.newPasswordConfirm &&
      !errors.newPasswordConfirm &&
      values.newPassword === values.newPasswordConfirm
    );
  }

  function checkStepTwoValidity() {
    const validAnswerLength = validate.acceptSingleCharacterSecurityAnswer(values.securityQuestion) ? 0 : 2;
    return (
      !!values.securityQuestion &&
      !errors.securityQuestion &&
      values.securityAnswer?.length > validAnswerLength &&
      !errors.securityAnswer
    );
  }

  const getAuthoredApiErrorMsg = (error, authoredApiMsg) => {
    const errorCode = get(error, 'response.data.code', '');
    const errorFields = get(error, 'response.data.errorFields', '');
    const apiErrorMsgObj = get(authoredApiMsg, 'errorMessages.apiErrorMessages');
    const getCodeSpecificError = find(
      apiErrorMsgObj,
      (errorMsg) => errorMsg.code === errorCode && !errorMsg.errorFieldName,
    );
    const getFieldSpecificError = reduce(
      errorFields,
      (result, errorField) =>
        result ||
        find(apiErrorMsgObj, {
          code: errorCode,
          errorFieldName: errorField.field,
        }),
      null,
    );

    // `computedErrorMessage` returns the filtered errorMessage accordingly
    return getFieldSpecificError || getCodeSpecificError || get(authoredApiMsg, 'errorMessages.defaultErrorMessage');
  };

  const passwordApiUrl = '/loyalty/v2/password';
  async function onStepOneContinue(e) {
    e.preventDefault();
    try {
      setSubmitting(true);
      setPostError('');
      const passwordApiBody = {
        data: {
          action: 'UPDATE',
          newPassword: values.newPassword,
        },
      };
      await api.vffV2Api.patch(passwordApiUrl, passwordApiBody);
      setIsStepOneSubmitted(true);
      setSubmitting(false);
      analyticsSend({
        eventAction: impression,
        eventName: formStep,
        eventCategory: 'forms',
        eventElementName: 'velocityLiteJoin',
        eventElementText: 'Security Question',
      });
      setCurrentStep(formStates.STEP_2);
    } catch (error) {
      setSubmitting(false);
      setPostError(getAuthoredApiErrorMsg(error, passwordDetails));
      analyticsSend({
        eventAction: impression,
        eventName: formFailure,
        eventCategory: 'forms',
        eventElementName: 'velocityLiteJoin',
        eventElementText: 'Password',
        eventElementValue: getAuthoredApiErrorMsg(error, passwordDetails).description,
      });
    }
  }

  const securityQuestionApiUrl = '/loyalty/v2/security-question';
  async function onStepTwoContinue(e) {
    e.preventDefault();
    try {
      setSubmitting(true);
      setPostError('');
      const securityQuestionApiBody = {
        data: {
          membershipId: membershipID,
          action: 'CREATE',
          questionId: parseInt(values.securityQuestion.value, 10),
          answer: values.securityAnswer,
          question: values.securityQuestion.label,
        },
      };
      await api.vffV2Api.post(securityQuestionApiUrl, securityQuestionApiBody);
      setIsStepTwoSubmitted(true);
      setSubmitting(false);
      analyticsSend({
        eventAction: impression,
        eventName: formStep,
        eventCategory: 'forms',
        eventElementName: 'velocityLiteJoin',
        eventElementText: 'My Details',
      });
      setCurrentStep(formStates.STEP_3);
    } catch (error) {
      setSubmitting(false);
      setPostError(getAuthoredApiErrorMsg(error, securityQuestionDetails));
      analyticsSend({
        eventAction: impression,
        eventName: formFailure,
        eventCategory: 'forms',
        eventElementName: 'velocityLiteJoin',
        eventElementText: 'Security Question',
        eventElementValue: getAuthoredApiErrorMsg(error, securityQuestionDetails).description,
      });
    }
  }

  // Accrued BP API
  const accuredBPUrl = '/loyalty/v2/digital-accrual';
  const accuredBonusPointApiCall = async () => {
    setSubmitting(true);
    setFullJoinRewardPoints(false);

    try {
      const response = await api.vffV2Api.post(accuredBPUrl, {
        data: {
          accCode: 'FULLJOINB',
        },
      });

      setSubmitting(false);
      setFullJoinRewardPoints(response?.status === 200);
      if (accuralBPError) setAccuralBPError(false); // try again scenario
    } catch (error) {
      setSubmitting(false);
      setAccuralBPError(true);
    }
  };

  const myDetailsApiUri = '/loyalty/v2/members';
  async function onFormSubmit(e) {
    e.preventDefault();

    const mandatoryFields = [
      'title',
      'birthDate',
      'preferred_AddressType',
      'email',
      'mobile_number',
      'personal_country',
      'personal_addressLine1',
      'personal_cityName',
      ...(isTitleDr ? ['gender'] : []),
      ...(shouldShowField('personal_postalCode', values.personal_country) ? ['personal_postalCode'] : []),
      ...(shouldShowField('personal_state', values.personal_country) ? ['personal_state'] : []),
      ...(!isEmpty(values.preferredFirstName) ? ['preferredFirstName'] : []),
    ];

    const additionalMandatoryFields = [
      'business_country',
      'business_addressLine1',
      'business_cityName',
      ...(shouldShowField('business_postalCode', values.business_country) ? ['business_postalCode'] : []),
      ...(shouldShowField('business_state', values.business_country) ? ['business_state'] : []),
    ];

    const fieldsToValidate = values.hasBusinessAddress
      ? flatten([mandatoryFields, additionalMandatoryFields])
      : mandatoryFields;

    const newErrors = {};
    fieldsToValidate.forEach((fieldName) => {
      const fieldValue = values[fieldName];
      const error = validateField(fieldName, fieldValue);
      if (error) {
        newErrors[fieldName] = error;
      }
    });

    setErrors(newErrors);

    if (!isEmpty(newErrors)) {
      setShowErrorSummary(true);
      setShakeButton(true);
      setTimeout(() => setShakeButton(false), 300);
      return;
    }

    try {
      setSubmitting(true);
      setSubmitted(false);
      setPostError('');

      const checkIsMainEmail = emails?.find((i) => i.contactValidity.isMain);
      // If there is no email entry with isMain = true, then the current value from Email field will becomes isMain
      const newEmailEntry = checkIsMainEmail
        ? []
        : [
            {
              category: 'PERSONAL',
              address: values.email,
              contactValidity: {
                isMain: true,
                isValid: true,
                isConfirmed: true,
              },
            },
          ];
      let updatedEmailList = [];
      if (checkIsMainEmail) {
        updatedEmailList = emails.map((item) => {
          if (item.contactValidity.isMain) {
            return { ...item, address: values.email };
          }
          return item;
        });
      } else {
        updatedEmailList = isEmpty(emails) ? [...newEmailEntry] : [...emails, ...newEmailEntry];
      }

      const myDetailsApiBody = {
        data: {
          membershipId: membershipID,
          individual: {
            identity: {
              firstName: values.firstName,
              lastName: values.lastName,
              title: values?.title?.value,
              gender: getGender(values?.title?.value, values?.gender),
              birthDate: DateTime.fromFormat(values.birthDate, 'dd/MM/yyyy').toFormat('yyyy-MM-dd'),
              preferredFirstName: values.preferredFirstName || values.firstName,
              ...(values.hasBusinessAddress && (values.jobTitle || values.company) // employments object should only appear if either jobTitle or company is present
                ? {
                    employments: [
                      {
                        ...(values.jobTitle ? { title: values.jobTitle } : {}),
                        ...(values.company ? { company: values.company } : {}),
                      },
                    ],
                  }
                : {}),
            },
            ...(isProfileCompletedBeforeDate
              ? {
                  consents: [
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'EMAIL',
                      for: 'STATEMENT',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'SMS',
                      for: 'STATEMENT',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'PHONE',
                      for: 'STATEMENT',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'TARGETED_ONLINE_ADVERTISING',
                      for: 'STATEMENT',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'POST',
                      for: 'STATEMENT',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'EMAIL',
                      for: 'MEMBER UPDATES',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'SMS',
                      for: 'MEMBER UPDATES',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'PHONE',
                      for: 'MEMBER UPDATES',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'TARGETED_ONLINE_ADVERTISING',
                      for: 'MEMBER UPDATES',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'POST',
                      for: 'MEMBER UPDATES',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'EMAIL',
                      for: 'VELOCITY EXCLUSIVES',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'SMS',
                      for: 'VELOCITY EXCLUSIVES',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'PHONE',
                      for: 'VELOCITY EXCLUSIVES',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'TARGETED_ONLINE_ADVERTISING',
                      for: 'VELOCITY EXCLUSIVES',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'POST',
                      for: 'VELOCITY EXCLUSIVES',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'EMAIL',
                      for: 'VIRGIN AUSTRALIA UPDATES',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'SMS',
                      for: 'VIRGIN AUSTRALIA UPDATES',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'PHONE',
                      for: 'VIRGIN AUSTRALIA UPDATES',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'TARGETED_ONLINE_ADVERTISING',
                      for: 'VIRGIN AUSTRALIA UPDATES',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'POST',
                      for: 'VIRGIN AUSTRALIA UPDATES',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'EMAIL',
                      for: 'TRAVEL PARTNER OFFERS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'SMS',
                      for: 'TRAVEL PARTNER OFFERS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'PHONE',
                      for: 'TRAVEL PARTNER OFFERS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'TARGETED_ONLINE_ADVERTISING',
                      for: 'TRAVEL PARTNER OFFERS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'POST',
                      for: 'TRAVEL PARTNER OFFERS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'EMAIL',
                      for: 'OTHER PARTNER OFFERS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'SMS',
                      for: 'OTHER PARTNER OFFERS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'PHONE',
                      for: 'OTHER PARTNER OFFERS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'TARGETED_ONLINE_ADVERTISING',
                      for: 'OTHER PARTNER OFFERS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'POST',
                      for: 'OTHER PARTNER OFFERS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'EMAIL',
                      for: 'MARKET RESEARCH',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'SMS',
                      for: 'MARKET RESEARCH',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'PHONE',
                      for: 'MARKET RESEARCH',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'TARGETED_ONLINE_ADVERTISING',
                      for: 'MARKET RESEARCH',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'POST',
                      for: 'MARKET RESEARCH',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'EMAIL',
                      for: 'FUEL PARTNER OFFERS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'SMS',
                      for: 'FUEL PARTNER OFFERS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'PHONE',
                      for: 'FUEL PARTNER OFFERS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'TARGETED_ONLINE_ADVERTISING',
                      for: 'FUEL PARTNER OFFERS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'POST',
                      for: 'FUEL PARTNER OFFERS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'EMAIL',
                      for: 'VA FLIGHT SPECIALS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'SMS',
                      for: 'VA FLIGHT SPECIALS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'PHONE',
                      for: 'VA FLIGHT SPECIALS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'TARGETED_ONLINE_ADVERTISING',
                      for: 'VA FLIGHT SPECIALS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'POST',
                      for: 'VA FLIGHT SPECIALS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'EMAIL',
                      for: 'FINANCIAL SERVICES OFFERS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'SMS',
                      for: 'FINANCIAL SERVICES OFFERS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'PHONE',
                      for: 'FINANCIAL SERVICES OFFERS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'TARGETED_ONLINE_ADVERTISING',
                      for: 'FINANCIAL SERVICES OFFERS',
                    },
                    {
                      frequency: 'DAILY',
                      status: 'GRANTED',
                      to: 'VELOCITY',
                      via: 'POST',
                      for: 'FINANCIAL SERVICES OFFERS',
                    },
                  ],
                }
              : {}),

            contact: {
              emails: updatedEmailList,
              phones: [
                {
                  category: 'PERSONAL',
                  deviceType: 'MOBILE',
                  ...(!isEmpty(values.mobile_countryCallingCode.value)
                    ? {
                        countryCallingCode: find(
                          countriesByCode,
                          (country) => country.code === values.mobile_countryCallingCode.value,
                        ).phoneCode,
                      }
                    : {}),
                  number: getTelephoneNumber(values.mobile_number),
                  contactValidity: {
                    isMain: true,
                    isValid: true,
                    isConfirmed: true,
                  },
                },
                {
                  category: 'PERSONAL',
                  deviceType: 'LANDLINE',
                  ...(!isEmpty(values.landline_countryCallingCode.value)
                    ? {
                        countryCallingCode: find(
                          countriesByCode,
                          (country) => country.code === values.landline_countryCallingCode.value,
                        ).phoneCode,
                      }
                    : {}),
                  ...(!isEmpty(values.landline_areaCode) ? { areaCode: values.landline_areaCode } : {}),
                  number: getTelephoneNumber(values.landline_number),
                  contactValidity: {
                    isMain: false,
                    isValid: true,
                    isConfirmed: true,
                  },
                },
              ],
              addresses: [
                ...(values.hasBusinessAddress
                  ? [
                      {
                        category: 'BUSINESS',
                        lines: [
                          values.business_addressLine1,
                          ...(isEmpty(values.business_addressLine2) ? [] : [values.business_addressLine2]),
                        ],
                        countryCode: values.business_country.value,
                        cityName: values.business_cityName,
                        ...(shouldShowField('business_postalCode', values.business_country)
                          ? { postalCode: values.business_postalCode }
                          : {}),
                        ...(shouldShowField('business_state', values.business_country)
                          ? { stateCode: values.business_state.value }
                          : {}),
                        contactValidity: {
                          isMain: values.preferred_AddressType === 'BUSINESS',
                          isValid: true,
                          isConfirmed: true,
                        },
                      },
                    ]
                  : []),
                {
                  category: 'PERSONAL',
                  lines: [
                    values.personal_addressLine1,
                    ...(isEmpty(values.personal_addressLine2) ? [] : [values.personal_addressLine2]),
                  ],
                  countryCode: values.personal_country.value,
                  cityName: values.personal_cityName,
                  ...(shouldShowField('personal_postalCode', values.personal_country)
                    ? { postalCode: values.personal_postalCode }
                    : {}),
                  ...(shouldShowField('personal_state', values.personal_country)
                    ? { stateCode: values.personal_state.value }
                    : {}),
                  contactValidity: {
                    isMain: values.preferred_AddressType === 'PERSONAL',
                    isValid: true,
                    isConfirmed: true,
                  },
                },
              ],
            },
          },
        },
      };

      await api.vffV2Api.patch(myDetailsApiUri, myDetailsApiBody);
      if (isFullJoinCampaign) await accuredBonusPointApiCall();
      setSubmitting(false);
      setSubmitted(true);
      analyticsSend({
        eventAction: impression,
        eventName: formSuccess,
        eventCategory: 'forms',
        eventElementName: 'velocityLiteJoin',
        eventElementText: "You're all set!",
        memberDOB: myDetailsApiBody.data.individual.identity.birthDate,
      });
    } catch (error) {
      setSubmitting(false);
      setPostError(getAuthoredApiErrorMsg(error, myDetailsForm));
      analyticsSend({
        eventAction: impression,
        eventName: formFailure,
        eventCategory: 'forms',
        eventElementName: 'velocityLiteJoin',
        eventElementText: 'submit-failed',
        eventElementValue: get(myDetailsForm, 'errorMessages.defaultErrorMessage').description,
      });
    }
  }

  useEffect(() => {
    if (submitted) {
      smoothScrollToElement(document.getElementById(successInfoBoxId), getNavigationHeight());

      if (successPageRef.current) {
        smoothScrollToElement(successPageRef.current, getNavigationHeight());
      }
    }
  }, [submitted]);

  useEffect(() => {
    if (postError) {
      smoothScrollToElement(submitErrorAlertId.current, getNavigationHeight());
    }
  }, [postError]);

  return (
    <div className={styles.formContainer}>
      {submitted && !isFullJoinCampaign && (
        <SuccessMessageTile
          id={successInfoBoxId}
          theme={successMessageTheme.shadow}
          title={get(confirmationPage, 'title') || ''}
          content={get(confirmationPage, 'description') || ''}
          ctaContainer={get(confirmationPage, 'ctaContainer') || ''}
        />
      )}

      {submitted && isFullJoinCampaign && (fullJoinRewardPoints || accuralBPError) && (
        <IncompleteMemberSuccessPage
          ref={successPageRef}
          interstitialErrorPage={interstitialErrorPage}
          successPage={successPage}
          userIdentity={userIdentity}
          accuralBPError={accuralBPError}
          accuredBonusPointApiCall={accuredBonusPointApiCall}
          loading={submitting}
        />
      )}

      {!submitted && (
        <>
          <TopContentContainer theme={contentContainerType.typeB}>
            {postError && (
              <MessageTile
                ref={submitErrorAlertId}
                theme={messageTileTheme.error}
                description={postError.description}
                className={styles.messageCont}
              />
            )}
            <div className={styles.welcomeMsg}>
              <RichTextContent className={styles.title} content={syncText(title || '', { firstName, lastName })} />
              <RichTextContent className={styles.description} content={description || ''} />
              {isFullJoinCampaign && (
                <>
                  {gamificationMessage && <p className={styles.gamificationMessage}>{gamificationMessage}</p>}
                  {gamificationImageUrl && (
                    <div className={styles.gamificationImage}>
                      <img className={styles.gamificationImageUrl} src={gamificationImageUrl} alt="" />
                    </div>
                  )}
                </>
              )}
            </div>
          </TopContentContainer>
          <div className={styles.cardContainer}>
            <CollapsibleCard
              title={get(passwordDetails, 'title')}
              className={styles.card}
              count={1}
              collapsed={isStepOneSubmitted}
              completed={isStepOneSubmitted}
            >
              <form className={styles.transferTypeDetail} onSubmit={onStepOneContinue}>
                <FormContainer theme={formContainerColor.white} type={formContainerType.typeB}>
                  <FormRow>
                    <div className={styles.passwordContainer}>
                      <FormFieldContainer type={FormFieldType.largeRow}>
                        <SecretInput
                          name="newPassword"
                          label="New password"
                          placeholder="Enter password"
                          aria-describedby="password_validator_sr_description"
                          size={10}
                          onChange={handleFieldChangeEvent}
                          onBlur={handleFieldBlurEvent}
                          value={values.newPassword}
                          error={errors.newPassword}
                          autoComplete="new-password"
                        />
                      </FormFieldContainer>
                      <FormFieldContainer type={FormFieldType.largeRow}>
                        <SecretInput
                          name="newPasswordConfirm"
                          label="Confirm New password"
                          placeholder="Re-enter password"
                          size={10}
                          onChange={handleFieldChangeEvent}
                          onBlur={handleFieldBlurEvent}
                          value={values.newPasswordConfirm}
                          error={errors.newPasswordConfirm}
                          autoComplete="new-password"
                        />
                      </FormFieldContainer>
                    </div>
                    <div className={styles.passwordValidatorCont}>
                      <PasswordValidator
                        className={styles.passwordValidator}
                        currentPassword={values.newPassword || ''}
                        screenReaderDescriptionContainerId="password_validator_sr_description"
                        arePasswordsMatchErrorMessage={
                          includes(touchedFields, 'newPassword') && isNewPasswordConfirmTouched
                            ? validateFormField(
                                values.newPassword,
                                [
                                  validate.matchesField(
                                    'newPasswordConfirm',
                                    'The passwords you have entered does not match',
                                  ),
                                ],
                                values,
                              )
                            : ''
                        }
                      />
                    </div>
                  </FormRow>
                  <Button
                    className={styles.passwordCtaButton}
                    title={get(passwordDetails, 'ctaContainer.ctaTitle')}
                    target={get(passwordDetails, 'ctaContainer.ctaOpenInNewTab') ? '_blank' : '_self'}
                    buttonType={get(passwordDetails, 'ctaContainer.ctaStyle')}
                    type="submit"
                    disabled={!checkStepOneValidity() || submitting}
                    loading={submitting}
                  >
                    {get(passwordDetails, 'ctaContainer.ctaLabel')}
                  </Button>
                </FormContainer>
              </form>
            </CollapsibleCard>
          </div>
          <div className={styles.cardContainer}>
            <CollapsibleCard
              title={get(securityQuestionDetails, 'title')}
              className={styles.card}
              count={2}
              collapsed={!isStepOneSubmitted || isStepTwoSubmitted}
              transparent={!isStepOneSubmitted}
              completed={isStepTwoSubmitted}
            >
              <form className={styles.familyTransferDetail} onSubmit={onStepTwoContinue}>
                <FormContainer>
                  <FormRow>
                    <FormFieldContainer>
                      <Select
                        name="securityQuestion"
                        label="New Security question"
                        placeholder="New Security Question"
                        items={securityQuestionOptions}
                        error={errors.securityQuestion}
                        onChange={handleFieldChange('securityQuestion')}
                        onBlur={handleFieldBlur('securityQuestion')}
                        selectedItem={values.securityQuestion}
                        isSearchable={false}
                        autoComplete="off"
                      />
                    </FormFieldContainer>
                  </FormRow>
                  <FormRow>
                    <FormFieldContainer>
                      <Input
                        label="New SECURITY ANSWER"
                        name="securityAnswer"
                        value={values.securityAnswer}
                        error={errors.securityAnswer}
                        onChange={handleFieldChangeEvent}
                        onBlur={handleFieldBlurEvent}
                      />
                    </FormFieldContainer>
                  </FormRow>
                  <Button
                    className={styles.securityQuestionCtaButton}
                    title={get(securityQuestionDetails, 'ctaContainer.ctaTitle')}
                    target={get(securityQuestionDetails, 'ctaContainer.ctaOpenInNewTab') ? '_blank' : '_self'}
                    buttonType={get(securityQuestionDetails, 'ctaContainer.ctaStyle')}
                    type="submit"
                    disabled={!checkStepTwoValidity() || submitting}
                    loading={submitting}
                  >
                    {get(securityQuestionDetails, 'ctaContainer.ctaLabel')}
                  </Button>
                </FormContainer>
              </form>
            </CollapsibleCard>
          </div>
          <div className={styles.cardContainer}>
            <CollapsibleCard
              title="My Details"
              count={3}
              collapsed={currentStep !== formStates.STEP_3}
              transparent={!isStepTwoSubmitted}
            >
              <form onSubmit={onFormSubmit}>
                <FormContainer
                  className={styles.boxContainer}
                  theme={formContainerColor.white}
                  type={formContainerType.typeB}
                >
                  <FormContentContainer>
                    <h2
                      className={cx(
                        'vaHeading vaHeading--5 color color--purple',
                        styles.sectionTitle,
                        styles.marginTopZero,
                      )}
                    >
                      {get(myDetailsForm, 'personalDetails.title')}
                    </h2>
                  </FormContentContainer>
                  <FormRow>
                    <FormFieldContainer className={styles.colWidthFour}>
                      <Select
                        id="title"
                        name="title"
                        label="Title"
                        items={personTitleOptions}
                        error={errors.title}
                        onChange={handleFieldChange('title')}
                        onBlur={handleFieldBlur('title')}
                        selectedItem={values.title}
                        autoComplete="honorific-prefix"
                        isSearchable={false}
                        placeholder="Select"
                        disabled
                      />
                    </FormFieldContainer>
                  </FormRow>

                  {isTitleDr && (
                    <FormRow>
                      <FormFieldContainer noPaddingTop>
                        <FormFieldSet
                          label="Please specify your gender"
                          error={errors?.gender}
                          labelStyle={formFieldGroupLabelStyle.darkPurpleSmallSize}
                        >
                          {genderOptions.map(({ label, value }) => (
                            <RadioButton
                              key={value}
                              name="gender"
                              label={label}
                              value={value}
                              onChange={handleFieldChangeEvent}
                              onBlur={handleFieldBlurEvent}
                              checked={values?.gender === value}
                            />
                          ))}
                        </FormFieldSet>
                      </FormFieldContainer>
                    </FormRow>
                  )}

                  <FormRow>
                    <FormFieldContainer>
                      <Input
                        label="First name"
                        name="firstName"
                        onChange={handleFieldChangeEvent}
                        onBlur={handleFieldBlurEvent}
                        value={values.firstName}
                        error={errors.firstName}
                        autoComplete="given-name"
                        readOnly
                        tooltip={get(myDetailsForm, 'personalDetails.firstNameTooltip')}
                      />
                    </FormFieldContainer>
                    <FormFieldContainer>
                      <Input
                        label="Preferred First name (Optional)"
                        name="preferredFirstName"
                        onChange={handleFieldChangeEvent}
                        onBlur={handleFieldBlurEvent}
                        value={values.preferredFirstName}
                        error={errors.preferredFirstName}
                      />
                    </FormFieldContainer>
                  </FormRow>

                  <FormRow>
                    <FormFieldContainer className={styles.colWidthTwo}>
                      <Input
                        label="Last name"
                        name="lastName"
                        value={values.lastName}
                        error={errors.lastName}
                        onChange={handleFieldChangeEvent}
                        onBlur={handleFieldBlurEvent}
                        autoComplete="family-name"
                        readOnly
                      />
                    </FormFieldContainer>
                  </FormRow>

                  <FormRow>
                    <FormFieldContainer className={styles.colWidthTwo}>
                      <Input
                        name="birthDate"
                        label="Date of birth"
                        mask="99/99/9999"
                        placeholder="DD/MM/YYYY"
                        value={values.birthDate}
                        error={errors.birthDate}
                        onChange={handleFieldChangeEvent}
                        onBlur={handleFieldBlurEvent}
                        autoComplete="bday"
                        inputMode="numeric"
                      />
                    </FormFieldContainer>
                  </FormRow>

                  <FormContentContainer>
                    <h2 className={cx('vaHeading vaHeading--5 color color--purple', styles.sectionTitle)}>
                      {get(myDetailsForm, 'homeAddressDetails.title')}
                    </h2>
                  </FormContentContainer>

                  <FormRow>
                    <FormFieldContainer className={styles.paddingTopZero}>
                      <RadioButton
                        id="address_type_personal"
                        name="preferred_AddressType"
                        label="Preferred postal address"
                        value="PERSONAL"
                        onChange={handleFieldChangeEvent}
                        checked={
                          (!values.hasBusinessAddress && values.preferred_AddressType === 'BUSINESS') ||
                          values.preferred_AddressType === 'PERSONAL'
                        }
                        onBlur={handleFieldBlurEvent}
                        isButton={false}
                      />
                    </FormFieldContainer>
                  </FormRow>

                  <FormRow>
                    <FormFieldContainer className={styles.colWidthTwo}>
                      <Select
                        name="personal_country"
                        label="Country"
                        items={defaultCountryOptions}
                        selectedItem={values.personal_country}
                        error={errors.personal_country}
                        onChange={handleFieldChange('personal_country')}
                        onBlur={handleFieldBlur('personal_country')}
                        autoComplete="country-name"
                        isSearchable={false}
                      />
                    </FormFieldContainer>
                  </FormRow>

                  <FormRow>
                    <FormFieldContainer className={styles.addressField}>
                      <AddressAutocomplete
                        id="personal_addressLine1"
                        name="personal_addressLine1"
                        autoComplete="address-line1"
                        label="Home Address Line 1"
                        error={errors.personal_addressLine1}
                        value={values.personal_addressLine1 || ''}
                        country={values.personal_country ? values.personal_country.value : ''}
                        onChange={handleFieldChangeEvent}
                        onBlur={handleFieldBlurEvent}
                        onAddressSelect={handlePersonalAddressSelection}
                      />
                    </FormFieldContainer>
                  </FormRow>

                  <FormRow>
                    <FormFieldContainer>
                      <Input
                        name="personal_addressLine2"
                        label="Home Address Line 2 (Optional)"
                        error={errors.personal_addressLine2}
                        value={values.personal_addressLine2}
                        onChange={handleFieldChangeEvent}
                        onBlur={handleFieldBlurEvent}
                      />
                    </FormFieldContainer>
                  </FormRow>
                  <FormRow>
                    <FormFieldContainer>
                      <Input
                        name="personal_cityName"
                        label="Suburb or town"
                        value={values.personal_cityName}
                        error={errors.personal_cityName}
                        onChange={handleFieldChangeEvent}
                        onBlur={handleFieldBlurEvent}
                        autoComplete="lines-level2"
                      />
                    </FormFieldContainer>

                    {shouldShowField('personal_postalCode', values.personal_country) && (
                      <FormFieldContainer>
                        <Input
                          name="personal_postalCode"
                          label="postCode"
                          value={values.personal_postalCode}
                          error={errors.personal_postalCode}
                          onChange={handleFieldChangeEvent}
                          onBlur={handleFieldBlurEvent}
                          autoComplete="postal-code"
                          pattern="[0-9]*"
                          inputMode="numeric"
                        />
                      </FormFieldContainer>
                    )}
                  </FormRow>

                  {shouldShowField('personal_state', values.personal_country) && (
                    <FormRow>
                      <FormFieldContainer className={styles.colWidthTwo}>
                        <Select
                          name="personal_state"
                          label="State"
                          items={stateOptions}
                          selectedItem={values.personal_state}
                          placeholder="Select State"
                          error={errors.personal_state}
                          onChange={handleFieldChange('personal_state')}
                          onBlur={handleFieldBlur('personal_state')}
                          isSearchable={false}
                        />
                      </FormFieldContainer>
                    </FormRow>
                  )}

                  <FormRow>
                    <FormFieldContainer className={styles.paddingTopZero}>
                      <Checkbox
                        className={styles.addressCheckbox}
                        id="hasBusinessAddress"
                        name="hasBusinessAddress"
                        containerClassName={styles.checkbox}
                        label={<RichTextContent content={get(myDetailsForm, 'homeAddressDetails.checkboxText')} />}
                        size="small"
                        checked={values.hasBusinessAddress}
                        onChange={(event) => {
                          handleFieldChange('hasBusinessAddress')(event.target.checked);
                        }}
                      />
                    </FormFieldContainer>
                  </FormRow>

                  {values.hasBusinessAddress && (
                    <>
                      <FormContentContainer>
                        <h2
                          className={cx(
                            'vaHeading vaHeading--5 color color--purple',
                            styles.sectionTitle,
                            styles.businessTitle,
                          )}
                        >
                          {get(myDetailsForm, 'businessAddressDetails.title')}
                        </h2>
                      </FormContentContainer>

                      <FormRow>
                        <FormFieldContainer className={styles.paddingTopZero}>
                          <RadioButton
                            id="address_type_business"
                            name="preferred_AddressType"
                            label="Preferred postal address"
                            value="BUSINESS"
                            size="large"
                            onChange={handleFieldChangeEvent}
                            checked={values.preferred_AddressType === 'BUSINESS'}
                            onBlur={handleFieldBlurEvent}
                            isButton={false}
                          />
                        </FormFieldContainer>
                      </FormRow>

                      <FormRow>
                        <FormFieldContainer>
                          <Input
                            name="company"
                            label="Company Name (Optional)"
                            value={values.company}
                            error={errors.company}
                            onChange={handleFieldChangeEvent}
                            onBlur={handleFieldBlurEvent}
                            autoComplete="organization"
                          />
                        </FormFieldContainer>
                      </FormRow>
                      <FormRow>
                        <FormFieldContainer>
                          <Input
                            name="jobTitle"
                            label="Job Title (Optional)"
                            value={values.jobTitle}
                            error={errors.jobTitle}
                            onChange={handleFieldChangeEvent}
                            onBlur={handleFieldBlurEvent}
                            autoComplete="organization-title"
                          />
                        </FormFieldContainer>
                      </FormRow>
                      <FormRow>
                        <FormFieldContainer className={styles.colWidthTwo}>
                          <Select
                            name="business_country"
                            label="Country"
                            items={defaultCountryOptions}
                            selectedItem={values.business_country}
                            error={errors.business_country}
                            onChange={handleFieldChange('business_country')}
                            onBlur={handleFieldBlur('business_country')}
                            autoComplete="country-name"
                            isSearchable={false}
                            isMandatory
                          />
                        </FormFieldContainer>
                      </FormRow>
                      <FormRow>
                        <FormFieldContainer className={styles.addressField}>
                          <AddressAutocomplete
                            id="business_addressLine1"
                            name="business_addressLine1"
                            autoComplete="address-line1"
                            label="Business Address Line 1"
                            error={errors.business_addressLine1}
                            value={values.business_addressLine1 || ''}
                            country={values.business_country ? values.business_country.value : ''}
                            onChange={handleFieldChangeEvent}
                            onBlur={handleFieldBlurEvent}
                            onAddressSelect={handleBusinessAddressSelection}
                          />
                        </FormFieldContainer>
                      </FormRow>
                      <FormRow>
                        <FormFieldContainer>
                          <Input
                            id="business_addressLine2"
                            name="business_addressLine2"
                            label="Business Address Line 2 (Optional)"
                            error={errors.business_addressLine2}
                            value={values.business_addressLine2}
                            onChange={handleFieldChangeEvent}
                            onBlur={handleFieldBlurEvent}
                          />
                        </FormFieldContainer>
                      </FormRow>
                      <FormRow>
                        <FormFieldContainer>
                          <Input
                            name="business_cityName"
                            label="Suburb or town"
                            value={values.business_cityName || ''}
                            error={errors.business_cityName}
                            onChange={handleFieldChangeEvent}
                            onBlur={handleFieldBlurEvent}
                            autoComplete="lines-level2"
                          />
                        </FormFieldContainer>
                        {shouldShowField('business_postalCode', values.business_country) && (
                          <FormFieldContainer>
                            <Input
                              name="business_postalCode"
                              label="postCode"
                              value={values.business_postalCode}
                              error={errors.business_postalCode}
                              onChange={handleFieldChangeEvent}
                              onBlur={handleFieldBlurEvent}
                              autoComplete="postal-code"
                              pattern="[0-9]*"
                              inputMode="numeric"
                            />
                          </FormFieldContainer>
                        )}
                      </FormRow>
                      {shouldShowField('business_state', values.business_country) && (
                        <FormRow>
                          <FormFieldContainer className={styles.colWidthTwo}>
                            <Select
                              name="business_state"
                              label="State"
                              items={stateOptions}
                              selectedItem={values.business_state}
                              placeholder="Select State"
                              error={errors.business_state}
                              onChange={handleFieldChange('business_state')}
                              onBlur={handleFieldBlur('business_state')}
                              isSearchable={false}
                            />
                          </FormFieldContainer>
                        </FormRow>
                      )}
                    </>
                  )}

                  <FormContentContainer>
                    <h2 className={cx('vaHeading vaHeading--5 color color--purple', styles.sectionTitle)}>
                      {get(myDetailsForm, 'contactNumberDetails.title')}
                    </h2>
                    <div className={styles.mandatoryTitle}>
                      <p>PHONE NUMBER</p>
                    </div>
                    <p className={styles.subtitle}>Mobile</p>
                  </FormContentContainer>

                  <FormRow>
                    <FormFieldContainer className={cx(styles.colWidthFour, styles.dropDownCustomWidth)}>
                      <Select
                        name="mobile_countryCallingCode"
                        label="Country Code"
                        aria-label="Mobile country code"
                        placeholder=""
                        items={countryCodeOptions}
                        onChange={handleFieldChange('mobile_countryCallingCode')}
                        onBlur={handleFieldBlur('mobile_countryCallingCode')}
                        selectedItem={getCountryCode(values.mobile_countryCallingCode)}
                        autoComplete="off"
                        error={errors.mobile_countryCallingCode}
                        isSearchable={false}
                      />
                    </FormFieldContainer>
                    <FormFieldContainer className={styles.colWidthTwo}>
                      <Input
                        type="tel"
                        name="mobile_number"
                        label="Mobile number"
                        aria-label="Mobile number"
                        placeholder="Mobile number"
                        value={values.mobile_number}
                        error={errors.mobile_number}
                        onChange={handleFieldChangeEvent}
                        onBlur={handleFieldBlurEvent}
                        autoComplete="home tel"
                      />
                    </FormFieldContainer>
                  </FormRow>

                  <FormContentContainer>
                    <p className={styles.subtitle}>Landline (Optional)</p>
                  </FormContentContainer>

                  <FormRow>
                    <div className={styles.landlineCountryAndAreaCode}>
                      <FormFieldContainer className={styles.dropDownCustomWidth}>
                        <Select
                          name="landline_countryCallingCode"
                          label="Country Code"
                          aria-label="Landline country code"
                          placeholder=""
                          items={countryCodeOptions}
                          onChange={handleFieldChange('landline_countryCallingCode')}
                          onBlur={handleFieldBlur('landline_countryCallingCode')}
                          selectedItem={getCountryCode(values.landline_countryCallingCode)}
                          autoComplete="off"
                          isSearchable={false}
                        />
                      </FormFieldContainer>

                      <FormFieldContainer>
                        <Input
                          type="text"
                          name="landline_areaCode"
                          label="Area Code"
                          aria-label="Landline area code"
                          placeholder="Area Code"
                          value={values.landline_areaCode}
                          error={errors.landline_areaCode}
                          onChange={handleFieldChangeEvent}
                          onBlur={handleFieldBlurEvent}
                          autoComplete="off"
                        />
                      </FormFieldContainer>
                    </div>

                    <FormFieldContainer className={styles.colWidthTwo}>
                      <Input
                        type="tel"
                        name="landline_number"
                        label="Landline number"
                        aria-label="Landline number"
                        placeholder="Landline number"
                        value={values.landline_number}
                        error={errors.landline_number}
                        onChange={handleFieldChangeEvent}
                        onBlur={handleFieldBlurEvent}
                        autoComplete="home tel"
                      />
                    </FormFieldContainer>
                  </FormRow>
                  <FormRow>
                    <FormFieldContainer>
                      <Input
                        type="email"
                        name="email"
                        label="Email"
                        value={values.email}
                        error={errors.email || emailApiError}
                        onChange={handleFieldChangeEvent}
                        onBlur={handleFieldBlurEvent}
                        isLoading={emailApiLoading}
                        autoComplete="home email"
                      />
                    </FormFieldContainer>
                  </FormRow>
                  <div className={styles.ctaContainer}>
                    <Button
                      title={get(myDetailsForm, 'ctaContainer.ctaTitle')}
                      target={get(myDetailsForm, 'ctaContainer.ctaOpenInNewTab') ? '_blank' : '_self'}
                      buttonType={get(myDetailsForm, 'ctaContainer.ctaStyle')}
                      disabled={submitting || emailApiError || emailApiLoading}
                      loading={submitting}
                      shakeButton={shakeButton}
                    >
                      {get(myDetailsForm, 'ctaContainer.ctaLabel')}
                    </Button>
                  </div>
                  <ErrorSummary
                    errors={errorList}
                    showErrorSummary={showErrorSummary}
                    className={styles.errorSummary}
                  />
                </FormContainer>
              </form>
            </CollapsibleCard>
          </div>
        </>
      )}
    </div>
  );
};

IncompleteMemberForm.propTypes = {
  title: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
  gamificationMessage: PropTypes.string,
  gamificationImageUrl: PropTypes.string,
  hasSecurityQuestion: PropTypes.bool.isRequired,
  passwordDetails: PropTypes.shape({}).isRequired,
  securityQuestionDetails: PropTypes.shape({}).isRequired,
  myDetailsForm: PropTypes.shape({}).isRequired,
  confirmationPage: PropTypes.shape({}).isRequired,
  membershipID: PropTypes.string.isRequired,
  userDetails: PropTypes.shape({}).isRequired,
  isFullJoinCampaign: PropTypes.bool,
  successPage: PropTypes.shape({}),
  interstitialErrorPage: PropTypes.shape({}),
  isProfileCompletedBeforeDate: PropTypes.bool,
};

IncompleteMemberForm.defaultProps = {
  isFullJoinCampaign: false,
  gamificationMessage: '',
  gamificationImageUrl: '',
  successPage: null,
  isProfileCompletedBeforeDate: false,
  interstitialErrorPage: null,
};

export default IncompleteMemberForm;
