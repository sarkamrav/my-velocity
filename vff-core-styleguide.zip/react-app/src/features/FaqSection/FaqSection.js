import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import styles from './FaqSection.css';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME } from '../../utils/common';
import IconTiles from '../IconTiles/IconTiles';
import RichTextContent from '../../components/RichTextContent/RichTextContent';

const FaqSection = ({ title, description, tiles, fullWidth, backgroundColor }) => (
  <ErrorBoundary section={COMPONENT_NAME.faqSection}>
    <div className={cx(styles.container, { [styles.limitWidth]: !fullWidth }, styles[`bg--${backgroundColor || ''}`])}>
      {title && <h2 className={styles.mainHeading}>{title}</h2>}
      <div className={styles.content}>
        <div className={styles.description}>
          <RichTextContent content={description} />
          {tiles && (
            <div className={styles.imageTile}>
              <IconTiles tiles={tiles} />
            </div>
          )}
        </div>
      </div>
    </div>
  </ErrorBoundary>
);

FaqSection.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string.isRequired,
  tiles: PropTypes.arrayOf(PropTypes.shape({})),
  fullWidth: PropTypes.bool,
  backgroundColor: PropTypes.string,
};

FaqSection.defaultProps = {
  title: '',
  tiles: [],
  fullWidth: false,
  backgroundColor: '',
};
export default FaqSection;
