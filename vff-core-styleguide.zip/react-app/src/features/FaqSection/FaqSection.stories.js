import React from 'react';
import mocks from './FaqSection.mock.json';
import FaqSection from './FaqSection';

export default {
  title: 'FAQ Section',
};

export const List = () => <FaqSection {...mocks[2]} />;
export const WithIconTiles = () => <FaqSection {...mocks[0]} />;
export const Default = () => <FaqSection {...mocks[1]} />;

export const FullPage = () => (
  <div>
    <br />
    <List />
    <br />
    <br />
    <WithIconTiles />
    <br />
    <br />
    <Default />
    <br />
  </div>
);
