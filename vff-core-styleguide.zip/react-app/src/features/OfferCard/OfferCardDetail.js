import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import cx from 'classnames';
import syncText from '../../utils/syncText';
import styles from './OfferCardDetail.css';

const OfferCardDetail = (props) => {
  const { redemption, terms, promotion } = props;
  const hasIcon = !_.isEmpty(redemption) && redemption.steps && redemption.steps.some((step) => step.iconUrl);

  return (
    <div className={styles.container}>
      {!_.isEmpty(redemption) && (
        <div className={styles.redeemContainer}>
          <div className={styles.redeemContent}>
            {redemption.title && <h3 className={cx(styles.title)}>{redemption.title}</h3>}

            {_.size(redemption.steps) > 0 ? (
              <ol className={styles.steps}>
                {_.map(redemption.steps, (step, i) => (
                  <li key={i} className={cx(styles.step, { [styles.auto]: !hasIcon })}>
                    {hasIcon && (
                      <div className={styles.icon}>{step.iconUrl && <img src={step.iconUrl} alt="step icon" />}</div>
                    )}
                    <div dangerouslySetInnerHTML={{ __html: syncText(step.text, promotion) }} />
                  </li>
                ))}
              </ol>
            ) : null}
          </div>
        </div>
      )}

      {terms && (
        <div className={styles.termsContainer}>
          <h3 className={styles.title}>{terms.title}</h3>
          <div className={styles.termsContent} dangerouslySetInnerHTML={{ __html: syncText(terms.text, promotion) }} />
        </div>
      )}
    </div>
  );
};

OfferCardDetail.propTypes = {
  redemption: PropTypes.shape({
    steps: PropTypes.arrayOf(PropTypes.shape({})),
    title: PropTypes.string,
  }),
  terms: PropTypes.shape({
    text: PropTypes.string,
    title: PropTypes.string,
  }),
  styles: PropTypes.shape({}),
  promotion: PropTypes.shape({}),
};

OfferCardDetail.defaultProps = {
  redemption: {},
  terms: {},
  styles: {},
  promotion: {},
};

export default OfferCardDetail;
