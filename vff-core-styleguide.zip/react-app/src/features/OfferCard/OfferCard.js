import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import cx from 'classnames';

import { DateTime } from 'luxon';
import Icon from '../../components/Icon/Icon';
import Button from '../../components/Button/Button';
import CallToAction from './CallToAction';
import useModal from '../../hooks/useModal';
import OfferTimer from '../../components/OfferTimer/OfferTimer';
import TermsModal from '../../components/TermsModal/TermsModal';
import OfferCardDetail from './OfferCardDetail';
import analyticsSend from '../../utils/analytics';
import { ACTIVATION_STATUSES, analyticsEventCategory, renderImage, serverTimeZone } from '../../utils/common';
import { getDurationBetween } from '../../utils/duration';
import { capType } from '../ActivatedOffer/constants';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import syncText from '../../utils/syncText';

import styles from './OfferCard.css';

const OfferCard = (props) => {
  const {
    promoLabel,
    promoCode,
    handleActivate,
    partner,
    title,
    description,
    terms,
    redemption,
    bgAttr,
    analyticsMetadata,
    analyticsMetadataMap,
    success,
    error,
    showCapType,
    capOfferLabel,
    expirationDateLabel,
    renditions,
    keyCallOuts,
    pagePath,
    selectedCardForAnimation,
    registrationEndDate,
    registrationStartDate,
    promotionCode,
    promotionShortDescription,
    promotionEndDate,
    promotionStartDate,
    activationCapMax,
    activationCapAvail,
    dateTimeCapReached,
    registrationStatus,
    isRecurringPromotion,
    promotionStatus,
    promotionName,
    promotionLongDescription,
    activityStartDate,
    activityEndDate,
  } = props;
  const [analyticsData, setAnalyticsData] = useState(analyticsMetadata['analytics-metadata']); // starts as text
  const { isShowing: isTncShowing, toggle: toggleTnc } = useModal();
  const { isShowing: isStepsShowing, toggle: toggleSteps } = useModal();
  const alreadyRegistered = registrationStatus === ACTIVATION_STATUSES.REGISTERED;
  const imageRef = useRef(null);

  useEffect(() => {
    let remainingDays;

    if (registrationEndDate) {
      const convertedTime = DateTime.fromObject({}, serverTimeZone); // All promotions run on AEST, and should be compared as such
      const inclusiveRegistrationEndDate = DateTime.fromISO(registrationEndDate, serverTimeZone).plus({ days: 1 }); // All promotions are inclusive of the date
      const { days } = getDurationBetween(convertedTime, inclusiveRegistrationEndDate);
      remainingDays = days;
    }

    setAnalyticsData({
      eventLocation: 'offer-item',
      ...analyticsMetadataMap,
      eventName: 'offer-lead-cta',
      eventCategory: analyticsEventCategory.offerListing,
      hyperlinkElementLocation: 'offer-item',
      offerTile: promoCode,
      promoCode,
      offerPartner: _.get(partner, 'name'),
      offerCategory: _.get(partner, 'category'),
      offerRemainingDays: remainingDays,
      offerMaxCap: activationCapMax,
      offerType: handleActivate ? 'activated' : 'bau',
      offerLabel: _.get(promoLabel, 'title', ''),
    });
  }, [
    activationCapMax,
    analyticsMetadata,
    analyticsMetadataMap,
    handleActivate,
    partner,
    promoCode,
    promoLabel,
    registrationEndDate,
  ]);

  // Rerender image rendition every update such as on mount, filtering, etc.
  useEffect(() => {
    if (!_.isEmpty(bgAttr) && !_.isEmpty(renditions) && imageRef) {
      const element = imageRef.current;
      renderImage(element, renditions);
    }
  });

  useEffect(() => {
    if (isStepsShowing) {
      analyticsSend({
        ...analyticsData,
        eventName: 'more-info',
        eventCategory: 'more-info',
        interactionType: 'expand',
        title,
      });
    }
  }, [analyticsData, isStepsShowing, title]);

  useEffect(() => {
    if (isTncShowing) {
      analyticsSend({
        ...analyticsData,
        eventName: 'details-term-interaction',
        interactionType: 'expand',
      });
    }
  }, [analyticsData, isTncShowing]);

  const isTimerVisible =
    ((showCapType && showCapType !== capType.none) || registrationEndDate) && !success && !error && !alreadyRegistered;

  const promotion = {
    promotionShortDescription,
    registrationEndDate,
    registrationStatus,
    promotionCode,
    isRecurringPromotion,
    registrationStartDate,
    promotionEndDate,
    promotionStartDate,
    promotionStatus,
    activationCapMax,
    activationCapAvail,
    dateTimeCapReached,
    promotionName,
    promotionLongDescription,
    activityStartDate,
    activityEndDate,
  };

  return (
    <div
      id={pagePath}
      className={cx(styles.card, {
        [styles.highlight]: selectedCardForAnimation === pagePath,
      })}
    >
      <div className={styles.imageContainer}>
        {_.isEmpty(bgAttr) ? (
          <div className={styles.noImage}>
            <Icon name="AirplaneWithTrail" />
          </div>
        ) : (
          <div className={styles.image} {...bgAttr} ref={imageRef} />
        )}
      </div>

      <div className={styles.content}>
        {partner ? (
          <div className={styles.header}>
            {promoLabel && promoLabel.title ? (
              <div className={styles.promoContainer}>
                {promoLabel.iconUrl && (
                  <div className={styles.promoIconContainer}>
                    <img alt="" src={promoLabel.iconUrl} />
                  </div>
                )}
                <span className={styles.promoLabel}>{promoLabel.title}</span>
              </div>
            ) : null}
            <div className={styles.logoPositionContainer}>
              <div className={styles.logoContainer}>
                <img className={styles.logo} src={_.get(partner, 'logo')} alt={_.get(partner, 'name')} />
              </div>
            </div>
          </div>
        ) : null}

        <div className={cx(styles.brandAndTitleContainer, styles.calloutContainer)}>
          <span className={styles.title}>{title || promoCode}</span>

          {!_.isEmpty(keyCallOuts) ? (
            <ul className={styles.callOutList}>
              {_.map(keyCallOuts, (item) => (
                <li key={item.title} className={styles.callOutListItem}>
                  {item.iconUrl ? <img className={styles.callOutListIcon} src={item.iconUrl} alt="" /> : null}

                  <RichTextContent content={syncText(item.title, promotion)} />
                </li>
              ))}
            </ul>
          ) : null}
        </div>
      </div>

      <div
        className={cx(styles.description, {
          [styles.noTimer]: !isTimerVisible,
        })}
        dangerouslySetInnerHTML={{ __html: syncText(description || promotionShortDescription, promotion) }}
        analytics-metadata={JSON.stringify(analyticsData)}
      />

      <div className={styles.footer}>
        {isTimerVisible ? (
          <div className={styles.timerContainer}>
            <OfferTimer
              className={styles.timer}
              showCapType={showCapType}
              activationCapMax={activationCapMax}
              activationCapAvail={activationCapAvail}
              capOfferLabel={capOfferLabel}
              registrationEndDate={registrationEndDate}
              expirationDateLabel={expirationDateLabel}
            />
          </div>
        ) : null}

        {!_.isEmpty(redemption) && (
          <>
            <div className={styles.stepsContainer}>
              <Button onClick={toggleSteps} buttonType="primary-transparent" className={styles.stepsButton} hideBorder>
                <Icon name="PlusCircleOpen" size="extra-small" />
                <span>{redemption.buttonLabel}</span>
              </Button>
            </div>

            <TermsModal
              isShowing={isStepsShowing}
              hide={() => {
                analyticsSend({
                  ...analyticsData,
                  eventName: 'more-info',
                  eventCategory: 'more-info',
                  interactionType: 'collapse',
                });
                toggleSteps();
              }}
              header={
                <div className={styles.brandAndTitleContainer}>
                  <span className={styles.brandName}>{_.get(partner, 'name')}</span>
                  <span className={styles.modalTitle}>{title}</span>
                </div>
              }
              aria-label={title}
            >
              <OfferCardDetail redemption={redemption} promotion={promotion} />
            </TermsModal>
          </>
        )}

        <CallToAction {...props} analyticsData={analyticsData} />

        {!_.isEmpty(terms) && (
          <>
            <button className={styles.tncButton} onClick={toggleTnc}>
              {terms.buttonLabel}
            </button>

            <TermsModal
              isShowing={isTncShowing}
              hide={() => {
                analyticsSend({
                  ...analyticsData,
                  eventName: 'details-term-interaction',
                  interactionType: 'collapse',
                });
                toggleTnc();
              }}
              header={
                <div className={styles.brandAndTitleContainer}>
                  <span className={styles.brandName}>{_.get(partner, 'name')}</span>
                  <span className={styles.modalTitle}>{title}</span>
                </div>
              }
              aria-label={title}
            >
              <OfferCardDetail terms={terms} promotion={promotion} />
            </TermsModal>
          </>
        )}
      </div>
    </div>
  );
};

OfferCard.propTypes = {
  handleActivate: PropTypes.func,
  promoLabel: PropTypes.shape({
    iconUrl: PropTypes.string,
    title: PropTypes.string,
  }),
  promoCode: PropTypes.string,
  promotionShortDescription: PropTypes.string,
  partner: PropTypes.shape({}),
  title: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
  terms: PropTypes.shape({
    buttonLabel: PropTypes.string,
  }),
  bgAttr: PropTypes.shape({}),
  success: PropTypes.shape({}),
  error: PropTypes.shape({}),
  keyCallOuts: PropTypes.arrayOf(PropTypes.shape({})),
  redemption: PropTypes.shape({
    buttonLabel: PropTypes.string,
  }),
  registrationEndDate: PropTypes.string,
  showCapType: PropTypes.oneOf([capType.none, capType.showMaxCap, capType.showMaxAvail]),
  capOfferLabel: PropTypes.string,
  expirationDateLabel: PropTypes.string,
  analyticsMetadata: PropTypes.shape({
    'analytics-metadata': PropTypes.string,
  }),
  loading: PropTypes.bool,
  registrationStatus: PropTypes.string,
  renditions: PropTypes.shape({}),
  analyticsMetadataMap: PropTypes.shape({}),
  pagePath: PropTypes.string,
  selectedCardForAnimation: PropTypes.string,
  promotionCode: PropTypes.string,
  isRecurringPromotion: PropTypes.string,
  registrationStartDate: PropTypes.string,
  promotionEndDate: PropTypes.string,
  promotionStartDate: PropTypes.string,
  promotionStatus: PropTypes.string,
  activationCapMax: PropTypes.string,
  activationCapAvail: PropTypes.string,
  dateTimeCapReached: PropTypes.string,
  promotionName: PropTypes.string,
  promotionLongDescription: PropTypes.string,
  activityStartDate: PropTypes.string,
  activityEndDate: PropTypes.string,
};

OfferCard.defaultProps = {
  handleActivate: null,
  promoLabel: null,
  promoCode: '',
  promotionShortDescription: null,
  partner: null,
  terms: null,
  bgAttr: {},
  success: null,
  error: null,
  redemption: {},
  registrationEndDate: null,
  showCapType: null,
  capOfferLabel: '',
  expirationDateLabel: '',
  analyticsMetadata: {},
  loading: false,
  registrationStatus: '',
  renditions: {},
  analyticsMetadataMap: {},
  keyCallOuts: [],
  pagePath: '',
  selectedCardForAnimation: '',
  promotionCode: '',
  activationCapMax: '',
  activationCapAvail: '',
  isRecurringPromotion: '',
  registrationStartDate: '',
  promotionEndDate: '',
  promotionStartDate: '',
  promotionStatus: '',
  dateTimeCapReached: '',
  promotionName: '',
  promotionLongDescription: '',
  activityStartDate: '',
  activityEndDate: '',
};

export default OfferCard;
