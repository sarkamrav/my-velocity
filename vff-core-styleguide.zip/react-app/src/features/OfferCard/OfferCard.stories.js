import React from 'react';
import { Provider } from 'react-redux';
import styles from '@sambego/storybook-styles';
import store from '../../stores';
import OfferCard from './OfferCard';
import mock from './mocks/OfferCard.mock.json';

export default {
  title: 'Offer Card',

  decorators: [
    styles({
      display: 'flex',
      justifyContent: 'center',
      padding: '2.4rem',
    }),
  ],
};

export const SingleCard = () => (
  <Provider store={store}>
    <OfferCard {...mock} />
  </Provider>
);
