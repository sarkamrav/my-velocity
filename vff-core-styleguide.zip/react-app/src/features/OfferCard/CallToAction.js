import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { find, get, isEmpty } from 'lodash';
import cx from 'classnames';
import { DateTime } from 'luxon';
import Icon from '../../components/Icon/Icon';
import Button from '../../components/Button/Button';
import A from '../../components/Button/A';
import styles from './CallToAction.css';
import syncText from '../../utils/syncText';
import { ACTIVATION_STATUSES, API_RESPONSE_CODES, serverTimeZone } from '../../utils/common';

const ActivateButtonComponent = (props) => {
  const { analyticsData, loading, handleActivate, ctaContainer, promotionCode, partner } = props;

  return (
    <>
      {handleActivate && !isEmpty(ctaContainer) ? (
        <div className={styles.callToActionContainer}>
          <Button className={styles.ctaButton} disabled={loading} loading={loading} onClick={handleActivate}>
            {ctaContainer.ctaLabel || 'Activate offer'}
          </Button>
        </div>
      ) : null}

      {!handleActivate && !isEmpty(ctaContainer) ? (
        <div
          className={styles.callToActionContainer}
          analytics-metadata={JSON.stringify({
            offerId: promotionCode,
            promoCode: promotionCode,
            offerPartner: get(partner, 'name'),
            offerCategory: get(partner, 'category'),
            ...analyticsData,
          })}
        >
          <A
            className={styles.ctaButton}
            title={ctaContainer.ctaTitle}
            href={ctaContainer.ctaUrl}
            target={ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
            ctaAsLink={ctaContainer.ctaAsLink}
          >
            {ctaContainer.ctaLabel}
          </A>
        </div>
      ) : null}
    </>
  );
};

ActivateButtonComponent.propTypes = {
  ctaContainer: PropTypes.shape({
    ctaUrl: PropTypes.string,
    ctaTitle: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaStyle: PropTypes.string,
    ctaAsLink: PropTypes.bool,
    ctaLabel: PropTypes.string,
  }),
  handleActivate: PropTypes.func,
  analyticsData: PropTypes.shape({}),
  loading: PropTypes.bool,
  promotionCode: PropTypes.string,
  partner: PropTypes.shape({}),
};

ActivateButtonComponent.defaultProps = {
  ctaContainer: null,
  handleActivate: null,
  analyticsData: null,
  loading: false,
  promotionCode: '',
  partner: null,
};

const ActivatedOfferComponent = (props) => {
  const {
    disableSecondaryActionPostActivationEndDate,
    partner,
    analyticsData,
    success,
    apiResponses,
    additionalSuccessText,
    promotionCode,
    registrationStatus,
    registrationEndDate,
    promotionStartDate,
    promotionEndDate,
  } = props;
  const promotion = {
    registrationEndDate,
    promotionStartDate,
    promotionEndDate,
  };

  let foundSuccess = success;
  if (registrationStatus === ACTIVATION_STATUSES.REGISTERED) {
    foundSuccess = find(apiResponses, { value: API_RESPONSE_CODES.ALREADY_ACTIVATED }) || success;
  }
  const showSuccessCtaLink = get(foundSuccess, 'ctaLink') && get(foundSuccess, 'ctaLabel');

  const convertedTime = DateTime.fromObject({}, serverTimeZone); // All promotions run on AEST, and should be compared as such
  const inclusiveRegistrationEndDate = DateTime.fromISO(registrationEndDate, serverTimeZone).plus({ days: 1 }); // All promotions are inclusive of the date
  const offerHasEnded = convertedTime > inclusiveRegistrationEndDate;

  const hideSecondaryCta = disableSecondaryActionPostActivationEndDate && offerHasEnded;

  return (
    <div
      className={styles.messages}
      analytics-metadata={JSON.stringify({
        offerId: promotionCode,
        promoCode: promotionCode,
        offerPartner: get(partner, 'name'),
        offerCategory: get(partner, 'category'),
        ...analyticsData,
      })}
    >
      <div className={styles.message}>
        <div className={cx(styles.iconMessage, styles.success)}>
          <Icon name="TickCircleOpen" />
          <span>Activated</span>
        </div>
        {!hideSecondaryCta && additionalSuccessText ? (
          <div
            dangerouslySetInnerHTML={{ __html: syncText(additionalSuccessText, promotion) }}
            className={styles.additionalSuccessText}
          />
        ) : null}
      </div>
      {!hideSecondaryCta && showSuccessCtaLink ? (
        <div className={styles.secondaryCtaContainer}>
          <A
            className={styles.secondaryCta}
            href={foundSuccess.ctaLink}
            target={foundSuccess.newTab ? '_blank' : '_self'}
            buttonType={foundSuccess.ctaStyle}
            data-offer-id={promotionCode}
            ctaAsLink={foundSuccess.ctaAsLink}
          >
            {foundSuccess.ctaLabel}
          </A>
        </div>
      ) : null}
    </div>
  );
};

ActivatedOfferComponent.propTypes = {
  disableSecondaryActionPostActivationEndDate: PropTypes.bool,
  success: PropTypes.shape({}),
  apiResponses: PropTypes.arrayOf(PropTypes.shape({})),
  additionalSuccessText: PropTypes.string,
  promotionCode: PropTypes.string,
  registrationStatus: PropTypes.string,
  registrationEndDate: PropTypes.string,
  promotionStartDate: PropTypes.string,
  promotionEndDate: PropTypes.string,
  analyticsData: PropTypes.shape({}),
  partner: PropTypes.shape({}),
};

ActivatedOfferComponent.defaultProps = {
  disableSecondaryActionPostActivationEndDate: false,
  success: null,
  apiResponses: [],
  additionalSuccessText: '',
  promotionCode: '',
  registrationStatus: '',
  registrationEndDate: '',
  promotionStartDate: '',
  promotionEndDate: '',
  analyticsData: null,
  partner: null,
};

const CallToAction = (props) => {
  const { registrationStatus, success, error } = props;

  function renderError(syncedTitle) {
    const showErrorCta = get(error, 'ctaLink') && get(error, 'ctaLabel');
    return (
      <div className={styles.messages}>
        <div className={styles.message}>
          <div className={cx(styles.iconMessage, styles.error)}>
            <Icon name="ExclamationPoint" />
            <span>{syncedTitle}</span>
          </div>
        </div>
        {showErrorCta ? (
          <div className={styles.secondaryCtaContainer}>
            <A
              className={styles.secondaryCta}
              href={error.ctaLink}
              target={error.newTab ? '_blank' : '_self'}
              buttonType={error.ctaStyle}
              ctaAsLink={error.ctaAsLink}
            >
              {error.ctaLabel}
            </A>
          </div>
        ) : null}
      </div>
    );
  }

  if (error) {
    return renderError(error.title || 'Something went wrong');
  }

  return (
    <>
      {!success && registrationStatus !== ACTIVATION_STATUSES.REGISTERED ? (
        <ActivateButtonComponent {...props} />
      ) : (
        <ActivatedOfferComponent {...props} />
      )}
    </>
  );
};

CallToAction.propTypes = {
  registrationStatus: PropTypes.string.isRequired,
  handleActivate: PropTypes.func,
  promotionCode: PropTypes.string,
  partner: PropTypes.shape({}),
  terms: PropTypes.shape({}),
  bgAttr: PropTypes.shape({}),
  redemption: PropTypes.shape({}),
  loading: PropTypes.bool,
  analyticsData: PropTypes.shape({}),
  additionalSuccessText: PropTypes.string,
  success: PropTypes.shape({}),
  error: PropTypes.shape({
    ctaLink: PropTypes.string,
    newTab: PropTypes.bool,
    ctaAsLink: PropTypes.bool,
    ctaStyle: PropTypes.string,
    ctaLabel: PropTypes.string,
    title: PropTypes.string,
  }),
  apiResponses: PropTypes.arrayOf(PropTypes.shape({})),
  ctaContainer: PropTypes.shape({
    ctaUrl: PropTypes.string,
    ctaTitle: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaStyle: PropTypes.string,
    ctaAsLink: PropTypes.bool,
    ctaLabel: PropTypes.string,
  }),
};

CallToAction.defaultProps = {
  handleActivate: null,
  promotionCode: '',
  additionalSuccessText: '',
  partner: {},
  terms: {},
  bgAttr: {},
  redemption: {},
  loading: false,
  analyticsData: {},
  success: null,
  error: null,
  apiResponses: null,
  ctaContainer: null,
};

export default connect((state) => ({
  user: state.user,
}))(CallToAction);
