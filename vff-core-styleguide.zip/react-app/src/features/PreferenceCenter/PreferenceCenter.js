import React, { useCallback, useEffect, useRef, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import get from 'lodash/get';
import map from 'lodash/map';
import toUpper from 'lodash/toUpper';
import reduce from 'lodash/reduce';
import find from 'lodash/find';
import isEmpty from 'lodash/isEmpty';

import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME, scrollToRef, getAuthorableErrorMsg } from '../../utils/common';
import TopContentContainer, {
  contentContainerType,
} from '../../components/Form/containers/TopContentContainer/TopContentContainer';
import PreferenceForm from './PreferenceForm/PreferenceForm';
import {
  getHasLoggedIn,
  getLoyaltyMembershipID,
  getMemberDataLoadError,
  getMemberDataLoading,
} from '../../stores/utilities';
import {
  consentFrequency,
  consentStatus,
  consentTo,
  consentVia,
  emptySpace,
  seatPreferenceFormFieldName,
} from './constants';
import Loading from '../../components/Loading/Loading';
import MessageTile, { messageTileTheme } from '../../components/MessageTile/MessageTile';
import api from '../../utils/api';
import { getApiActionName, getApiError, sendToNewRelic } from '../../utils/newRelic';

import styles from './PreferenceCenter.css';

const getEmailPayload = (formData, marketingPreference) => {
  const marketingOptions = get(marketingPreference, 'preferenceItems[0].options', []);

  return reduce(
    marketingOptions,
    (result, option) => [
      ...result,
      {
        frequency: consentFrequency.daily,
        status: formData[option.value] ? consentStatus.granted : consentStatus.notGranted,
        to: consentTo.velocity,
        for: option.value,
        via: consentVia.email,
      },
    ],
    [],
  );
};

const getChannelPayload = (formData, channelPreference, marketingPreference) => {
  const channelOptions = get(channelPreference, 'preferenceItems[0].options', []);
  const marketingOptions = get(marketingPreference, 'preferenceItems[0].options', []);
  const consentItems = map(marketingOptions, (option) => option.value);

  return reduce(
    channelOptions,
    (result, option) => {
      const channelPayload = map(consentItems, (consentItem) => ({
        frequency: consentFrequency.daily,
        status: formData[option.value] ? consentStatus.granted : consentStatus.notGranted,
        to: consentTo.velocity,
        for: consentItem,
        via: toUpper(option.value),
      }));

      return [...result, ...channelPayload];
    },
    [],
  );
};

const getSeatPayload = (formData, onboardPreference) => {
  const onboardCategory = get(onboardPreference, 'category', '');
  const onboardSubCategory = get(onboardPreference, 'preferenceItems[0].subCategory', '');
  const onboardOptions = get(onboardPreference, 'preferenceItems[0].options', []);
  const noPreferenceOption = find(onboardOptions, { isNoPreference: true });

  const seatSelectedOption = formData[seatPreferenceFormFieldName.seatPreference];

  return seatSelectedOption === noPreferenceOption.value
    ? [
        {
          category: onboardCategory,
          subCategory: onboardSubCategory,
          value: emptySpace,
        },
      ]
    : [
        {
          category: onboardCategory,
          subCategory: onboardSubCategory,
          value: seatSelectedOption,
        },
      ];
};

const getInterestPayload = (formData, interest) => {
  const category = get(interest, 'category', '');

  return reduce(
    interest.preferenceItems,
    (allSelectedInterest, preferenceItem) => {
      const subCategory = get(preferenceItem, 'subCategory', '');
      const selectedInterestPerCategory = reduce(
        preferenceItem.options,
        (optionResult, option) => [
          ...optionResult,
          ...(formData[`${category}${subCategory}${option.value}`]
            ? [
                {
                  category,
                  subCategory,
                  value: option.value,
                },
              ]
            : []),
        ],
        [],
      );

      return [
        ...allSelectedInterest,
        ...(!isEmpty(selectedInterestPerCategory)
          ? selectedInterestPerCategory
          : [
              {
                category,
                subCategory,
                value: emptySpace,
              },
            ]),
      ];
    },
    [],
  );
};

const PreferenceCenter = ({
  ctaContainer,
  channelPreference,
  marketingPreference,
  contactPreference,
  onboardPreference,
  interest,
  otherPreference,
  user,
  successMessage,
  errorMessages,
}) => {
  const memberDataLoading = getMemberDataLoading(user);
  const memberDataLoadError = getMemberDataLoadError(user);
  const hasLoggedIn = getHasLoggedIn(user);

  const [preferenceGetLoading, setPreferenceGetLoading] = useState(false);
  const [preferenceGetError, setPreferenceGetError] = useState(false);
  const [preferenceGetLoaded, setPreferenceGetLoaded] = useState(false);
  const [preferences, setPreferences] = useState(null);

  const [preferencePatching, setPreferencePatching] = useState(false);
  const [preferencePatchError, setPreferencePatchError] = useState('');
  const [preferencePatchSuccess, setPreferencePatchSuccess] = useState(false);

  const patchSuccessMessageRef = useRef({});
  const patchErrorMessageRef = useRef({});

  useEffect(() => {
    const getPreferences = async () => {
      const preferencesGetApiUri = '/loyalty/v2/members/profile';

      try {
        setPreferenceGetLoading(true);
        setPreferenceGetError(false);
        const response = await api.vffV2Api.get(preferencesGetApiUri);
        setPreferences(get(response, 'data.data'));
        setPreferenceGetLoading(false);
        setPreferenceGetLoaded(true);
      } catch (err) {
        setPreferenceGetLoading(false);
        setPreferenceGetError(true);
        setPreferenceGetLoaded(false);

        sendToNewRelic(
          getApiActionName(api.vffV2Api.defaults.baseURL, preferencesGetApiUri),
          getApiError(COMPONENT_NAME.preferenceCenter, err),
        );
      }
    };

    if (hasLoggedIn) {
      getPreferences();
    }
  }, [hasLoggedIn]);

  const handleSubmit = useCallback(
    async (e, data) => {
      e.preventDefault();
      const preferencePatchApiUri = '/loyalty/v2/members';

      const emailPayload = getEmailPayload(data, marketingPreference);
      const channelPayload = getChannelPayload(data, channelPreference, marketingPreference);
      const seatPayload = getSeatPayload(data, onboardPreference, preferences);
      const interestPayload = getInterestPayload(data, interest);

      const requestPayload = {
        data: {
          membershipId: getLoyaltyMembershipID(user),
          individual: {
            preferences: [...seatPayload, ...interestPayload],
            consents: [...emailPayload, ...channelPayload],
          },
        },
      };

      try {
        setPreferencePatching(true);
        setPreferencePatchSuccess(false);
        setPreferencePatchError(null);

        await api.vffV2Api.patch(preferencePatchApiUri, requestPayload);
        setPreferencePatching(false);
        setPreferencePatchSuccess(true);
      } catch (err) {
        setPreferencePatching(false);
        setPreferencePatchSuccess(false);
        setPreferencePatchError(true);

        sendToNewRelic(
          getApiActionName(api.vffV2Api.defaults.baseURL, preferencePatchApiUri),
          getApiError(COMPONENT_NAME.preferenceCenter, err),
        );
      }
    },
    [channelPreference, interest, marketingPreference, onboardPreference, preferences, user],
  );

  useEffect(() => {
    if (preferencePatchSuccess && patchSuccessMessageRef.current) {
      scrollToRef(patchSuccessMessageRef);
    }
  }, [preferencePatchSuccess]);

  useEffect(() => {
    if (preferencePatchError && patchErrorMessageRef.current) {
      scrollToRef(patchErrorMessageRef);
    }
  }, [preferencePatchError]);

  return (
    <ErrorBoundary section={COMPONENT_NAME.preferenceCenter}>
      {((!hasLoggedIn && !memberDataLoadError && memberDataLoading) || preferenceGetLoading) && (
        <Loading containerClassName={styles.loading} />
      )}

      {((!hasLoggedIn && memberDataLoadError) || preferenceGetError) && (
        <div className={styles.errorContainer}>
          <MessageTile theme={messageTileTheme.error} description="Sorry, we're having issues with our system." />
        </div>
      )}

      {hasLoggedIn && preferenceGetLoaded && (
        <>
          <TopContentContainer theme={contentContainerType.typeB}>
            {preferencePatchSuccess && (
              <MessageTile ref={patchSuccessMessageRef} theme={messageTileTheme.success} description={successMessage} />
            )}

            {preferencePatchError && (
              <MessageTile
                ref={patchErrorMessageRef}
                theme={messageTileTheme.error}
                description={errorMessages?.defaultErrorMessage?.description}
              />
            )}
          </TopContentContainer>

          <PreferenceForm
            preferences={preferences}
            ctaContainer={ctaContainer}
            channelPreference={channelPreference}
            marketingPreference={marketingPreference}
            contactPreference={contactPreference}
            onboardPreference={onboardPreference}
            interest={interest}
            otherPreference={otherPreference}
            onSubmit={handleSubmit}
            preferencePatching={preferencePatching}
          />
        </>
      )}
    </ErrorBoundary>
  );
};

PreferenceCenter.propTypes = {
  user: PropTypes.shape({}),
  ctaContainer: PropTypes.shape({}),
  channelPreference: PropTypes.shape({}),
  marketingPreference: PropTypes.shape({}),
  contactPreference: PropTypes.shape({}),
  onboardPreference: PropTypes.shape({}),
  interest: PropTypes.shape({}),
  otherPreference: PropTypes.shape({}),
  successMessage: PropTypes.string,
  errorMessages: PropTypes.shape({
    defaultErrorMessage: PropTypes.shape({
      description: PropTypes.string,
    }),
  }),
};

PreferenceCenter.defaultProps = {
  user: null,
  ctaContainer: null,
  channelPreference: null,
  marketingPreference: null,
  contactPreference: null,
  onboardPreference: null,
  interest: null,
  otherPreference: null,
  successMessage: null,
  errorMessages: null,
};

export default connect((state) => ({
  user: state.user,
}))(PreferenceCenter);
