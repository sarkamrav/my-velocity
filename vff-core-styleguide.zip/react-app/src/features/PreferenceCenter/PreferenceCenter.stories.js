import React from 'react';
import MockAdapter from 'axios-mock-adapter';
import { Provider } from 'react-redux';
import styles from '@sambego/storybook-styles';

import api from '../../utils/api';
import preferenceFormMock from './mocks/preference-form.mock.json';
import apiMembersPreferenceMock from './mocks/api-get-members-profile.mock.json';
import userData from '../Navigation/mocks/user.mock.json';
import { configureStore } from '../../stores';
import PreferenceForm from './PreferenceCenter';

export default {
  title: 'Preference Center',
  decorators: [
    styles({
      backgroundColor: '#f9f9f9',
    }),
  ],
};

export const MemberProfileApiFailed = () => (
  <Provider
    store={configureStore({
      user: {
        memberDataLoaded: false,
        memberDataLoading: false,
        memberDataLoadError: true,
        authenticated: false,
      },
    })}
  >
    <PreferenceForm {...preferenceFormMock} />
  </Provider>
);

export const MemberProfileApiLoading = () => (
  <Provider
    store={configureStore({
      user: {
        memberDataLoaded: false,
        memberDataLoading: true,
        authenticated: false,
      },
    })}
  >
    <PreferenceForm {...preferenceFormMock} />
  </Provider>
);

export const Authenticated = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api, { delayResponse: 1000 });
  mockVffV2.onGet('/loyalty/v2/members/profile').reply(200, apiMembersPreferenceMock);
  mockVffV2.onPatch('/loyalty/v2/members').reply(200, apiMembersPreferenceMock);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <PreferenceForm {...preferenceFormMock} />
    </Provider>
  );
};

Authenticated.storyName = 'Authenticated - submit success';

export const AuthenticatedFail = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api, { delayResponse: 1000 });
  mockVffV2.onGet('/loyalty/v2/members/profile').reply(200, apiMembersPreferenceMock);
  mockVffV2.onPost('/loyalty/v2/members').reply(500);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <PreferenceForm {...preferenceFormMock} />
    </Provider>
  );
};

AuthenticatedFail.storyName = 'Authenticated - submit fail';

export const DuplicateMembershipError = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api, { delayResponse: 1000 });
  mockVffV2.onGet('/loyalty/v2/members/profile').reply(200, apiMembersPreferenceMock);
  mockVffV2.onPatch('/loyalty/v2/members').reply(409, {
    code: 37014,
    title: 'Conflict',
    detail: 'duplicate Membership is found',
    status: 409,
  });

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <PreferenceForm {...preferenceFormMock} />
    </Provider>
  );
};

DuplicateMembershipError.storyName = 'Authenticated - Duplicate Membership Error';
