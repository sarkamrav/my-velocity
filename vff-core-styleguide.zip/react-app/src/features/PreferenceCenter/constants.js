export const consentStatus = {
  granted: 'GRANTED',
  notGranted: 'NOT_GRANTED',
};

export const consentTo = {
  velocity: 'VELOCITY',
};

export const consentVia = {
  email: 'EMAIL',
  post: 'POST',
  sms: 'SMS',
  phone: 'PHONE',
  targetedOnlineAdvertising: 'TARGETED ONLINE ADVERTISING',
};

export const consentFrequency = {
  daily: 'DAILY',
};

export const seatPreferenceFormFieldName = {
  seatPreference: 'seatPreference',
};

export const emptySpace = ' ';
