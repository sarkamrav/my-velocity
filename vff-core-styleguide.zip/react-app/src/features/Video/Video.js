import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME } from '../../utils/common';

import styles from './Video.css';

const Video = ({ title, videoRef, youtubeType, autoPlay, controls, defaultImageRef }) => (
  <ErrorBoundary section={COMPONENT_NAME.video}>
    {!!videoRef && (
      <div
        className={cx(styles.container, {
          [styles.youtube]: youtubeType,
          [styles.damVideo]: !youtubeType,
        })}
      >
        {youtubeType ? (
          <iframe
            title={title}
            src={videoRef}
            frameBorder="0"
            allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        ) : (
          <video preload="auto" {...{ autoPlay, controls }} loop muted playsInline>
            <source src={videoRef} type="video/mp4" />
            {defaultImageRef ? (
              <img src={defaultImageRef} alt="Your browser does not support the <video> tag" />
            ) : (
              'Your browser does not support the <video> tag'
            )}
          </video>
        )}
      </div>
    )}
  </ErrorBoundary>
);

Video.propTypes = {
  title: PropTypes.string,
  videoRef: PropTypes.string,
  defaultImageRef: PropTypes.string,
  youtubeType: PropTypes.bool,
  autoPlay: PropTypes.bool,
  controls: PropTypes.bool,
};

Video.defaultProps = {
  title: null,
  videoRef: null,
  youtubeType: false,
  defaultImageRef: null,
  autoPlay: false,
  controls: false,
};

export default Video;
