import React from 'react';

import videoMock from './mocks/youtube.mock.json';
import damVideoMock from './mocks/damVideo.mock.json';
import Video from './Video';

export default {
  title: 'Video',
};

export const YoutubeVideo = () => (
  <div style={{ width: 350 }}>
    <Video {...videoMock} />
  </div>
);

YoutubeVideo.storyName = 'Youtube video';

export const DamVideo = () => (
  <div style={{ width: 350 }}>
    <Video {...damVideoMock} />
  </div>
);

DamVideo.storyName = 'DAM video';
