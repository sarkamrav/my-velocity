import React from 'react';
import { Provider } from 'react-redux';
import MockAdapter from 'axios-mock-adapter';
import RetroClaims from './RetroClaims';
import { configureStore } from '../../stores';
import api from '../../utils/api';
import RetroClaimsMock from './mocks/RetroClaims.mock.json';

export default {
  title: 'Retro Claims',
};

export const Success = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api, { delayResponse: 1000 });

  mockVffV2.onGet('/loyalty/v2/refd-airports').reply(200, {
    data: [
      {
        code: 'YOW',
        name: 'Ottawa International Airport',
        country: 'Canada',
        city: 'Ottawa',
        latitude: 45.3208,
        longitude: -75.6728,
        image:
          'https://experience.velocityfrequentflyer.com/content/dam/vff/velocity/390x210/YOW.jpg/_jcr_content/renditions/original',
      },
      {
        code: 'HNL',
        name: 'Honolulu Airport',
        country: 'United States',
        city: 'Honolulu',
        latitude: 21.318681,
        longitude: -157.922428,
        image:
          'https://experience.velocityfrequentflyer.com/content/dam/vff/velocity/390x210/HNL.jpg/_jcr_content/renditions/original',
      },
    ],
  });

  mockVffV2.onPost('/loyalty/v2/retro-claims').reply(200, {
    data: {
      membershipId: '0000427791',
      firstName: 'TestName',
      lastName: 'TestAccount',
      ticketNumber: '12345556566',
      accrualStatusCode: 'R',
      accrualStatusDetail: 'Retro claim has been received',
      clientTransctionId: 'testing2222',
      resourceId: '61b824145ea0b0e463dc278a',
      flightSegment: {
        origin: 'BNE',
        destination: 'LAX',
        flightDate: '2021-11-10T00:00:00Z',
        airlineCode: 'HX',
        flightNumber: '1236',
      },
    },
  });

  return (
    <Provider
      store={configureStore({
        user: {
          member: {
            firstName: 'Sophie',
            lastName: 'Foster',
            loyaltyMembershipID: '1234567890',
          },
          account: {
            joinDate: '2021-12-21',
          },
        },
      })}
    >
      <RetroClaims {...RetroClaimsMock} />
    </Provider>
  );
};

export const Failed = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api);

  mockVffV2.onGet('/loyalty/v2/refd-airports').reply(200, {
    data: [
      {
        code: 'YOW',
        name: 'Ottawa International Airport',
        country: 'Canada',
        city: 'Ottawa',
        latitude: 45.3208,
        longitude: -75.6728,
        image:
          'https://experience.velocityfrequentflyer.com/content/dam/vff/velocity/390x210/YOW.jpg/_jcr_content/renditions/original',
      },
      {
        code: 'HNL',
        name: 'Honolulu Airport',
        country: 'United States',
        city: 'Honolulu',
        latitude: 21.318681,
        longitude: -157.922428,
        image:
          'https://experience.velocityfrequentflyer.com/content/dam/vff/velocity/390x210/HNL.jpg/_jcr_content/renditions/original',
      },
    ],
  });

  mockVffV2.onPost('/loyalty/v2/retro-claims').reply(400, {
    code: 37622,
    title: 'Retro Claim rejected',
    detail: 'The received request is a duplicate of a previous request.',
    status: 400,
  });

  return (
    <Provider
      store={configureStore({
        user: {
          member: {
            firstName: 'Sophie',
            lastName: 'Foster',
            loyaltyMembershipID: '1234567890',
          },
          account: {
            joinDate: '2019-06-01',
          },
        },
      })}
    >
      <RetroClaims {...RetroClaimsMock} />
    </Provider>
  );
};

export const FailedAirportsApi = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api);

  mockVffV2.onGet('/loyalty/v2/refd-airports').reply(500);

  return (
    <Provider
      store={configureStore({
        user: {
          member: {
            firstName: 'Sophie',
            lastName: 'Foster',
            loyaltyMembershipID: '1234567890',
          },
          account: {
            joinDate: '2019-06-01',
          },
        },
      })}
    >
      <RetroClaims {...RetroClaimsMock} />
    </Provider>
  );
};

FailedAirportsApi.storyName = 'Failed - Airports API';
