import React from 'react';
import ReactDOM from 'react-dom';
import _ from 'lodash';
import { Provider } from 'react-redux';
import store from '../../stores';
import RetroClaims from './RetroClaims';
import InformationAlert from '../../components/InformationAlert/InformationAlert';
import { COMPONENT_NAME } from '../../utils/common';

const ELEMENT_NAME = COMPONENT_NAME.retroClaims;

function renderComponent(elements) {
  _.map(elements, (element) => {
    const props = window.vffCoreWebsite[element.getAttribute(ELEMENT_NAME)];

    if (props) {
      const { contactInformation, ...rest } = props;

      const component = (
        <Provider store={store}>
          <RetroClaims
            {...rest}
            contactInformation={_.get(window.vffCoreWebsite, `[${contactInformation.jsObjectKey}]`)}
          />
        </Provider>
      );

      ReactDOM.render(component, element);
    }
  });
}

function renderError(elements) {
  _.map(elements, (element) => {
    const component = (
      <Provider store={store}>
        <InformationAlert title="Something went wrong" content="" />
      </Provider>
    );

    ReactDOM.render(component, element);
  });
}

export default {
  elementName: ELEMENT_NAME,
  bootstrap: (id = null) => {
    const elements = document.querySelectorAll(`[${ELEMENT_NAME}${id ? `=${id}` : ''}]`);

    if (_.size(elements) > 0) {
      document.addEventListener('myProfile', (e) => {
        const { authenticated } = e.data;
        if (authenticated) {
          renderComponent(elements);
        } else {
          renderError(elements);
        }
      });

      if (_.get(window.vffCoreWebsite, 'websiteData.authoringMode')) {
        renderComponent(elements);
      }
    }
  },
};
