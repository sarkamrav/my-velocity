// The constants used for Retro Claims and Claim History Table components can be declared and used from here
export const SUCCESSFUL = 'Successful';
export const PENDING = 'Pending';
export const UNSUCCESSFUL = 'Unsuccessful';
export const VA = 'VA';

export const RETRO_CLAIM_ACTIVITY_STATUS = {
  ACCEPTED_WITH_CHANGES: 'ACCEPTED_WITH_CHANGES',
  ACCEPTED: 'ACCEPTED',
  NEW: 'NEW',
};

// `validProcessStatus` helps to check for the valid processStatus
export const VALID_PROCESS_STATUS = ['PROCESSING', 'WAITING_EXPORT', 'WAITING_HANDBACK'];
