import React, { useRef, useEffect, useMemo, useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import isEmpty from 'lodash/isEmpty';
import findIndex from 'lodash/findIndex';
import includes from 'lodash/includes';
import get from 'lodash/get';
import map from 'lodash/map';
import isUndefined from 'lodash/isUndefined';
import find from 'lodash/find';
import omit from 'lodash/omit';
import difference from 'lodash/difference';
import _ from 'lodash';
import { format, subDays, subMonths, isAfter, compareDesc } from 'date-fns';
import cx from 'classnames';

import CollapsibleCard from '../../components/CollapsibleCard/CollapsibleCard';
import Button from '../../components/Button/Button';
import ContactInformation from '../../components/ContactInformation/ContactInformation';
import Select from '../../components/Form/Select/Select';
import Input from '../../components/Form/Input/Input';
import FormRow from '../../components/Form/FormRow/FormRow';
import FormGroup from '../../components/Form/FormGroup/FormGroup';
import Checkbox from '../../components/Form/Checkbox/Checkbox';
import DatePicker from '../../components/Form/DatePicker/DatePicker';
import api from '../../utils/api';
import InformationAlert from '../../components/InformationAlert/InformationAlert';
import analyticsSend from '../../utils/analytics';
import { COMPONENT_NAME, formatMembershipNumber, scrollToRef } from '../../utils/common';
import { validateFormField } from '../../components/Form/utils';
import * as validate from '../../components/Form/validators';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import * as userData from '../../stores/utilities';

import { getApiActionName, getApiError, sendToNewRelic } from '../../utils/newRelic';
import SuccessMessage from '../../components/SuccessMessage/SuccessMessage';

import styles from './RetroClaims.css';

const initialValues = {
  selectedAirline: null,
  selectedFlightNumber: '',
  selectedDepartureDate: '',
  selectedEticketNumber: '',
  selectedOrigin: null,
  selectedDestination: null,
};

const RetroClaims = ({
  user,
  nameConfirmDescription,
  contactInformation,
  submitButtonLabel,
  airline,
  flightNumber,
  departureDate,
  eticketNumber,
  origin,
  destination,
  successMessage,
  analyticsMetadata,
  rejected,
  errorMessages,
}) => {
  const passengerDetailsRef = useRef();
  const flightDetailsRef = useRef();
  const contactInformationRef = useRef();
  const successContainerRef = useRef();
  const errorContainerRef = useRef();

  const loyaltyMembershipID = userData.getLoyaltyMembershipID(user);
  const firstName = userData.getFirstName(user);
  const lastName = userData.getLastName(user);

  const analyticsMetadataKey = analyticsMetadata['analytics-metadata'];
  const [analyticsData, setAnalyticsData] = useState(analyticsMetadataKey);

  const [originAirports, setOriginAirports] = useState([]);
  const [postSuccess, setPostSuccess] = useState(null);
  const [hasError, setHasError] = useState(false);
  const [postError, setPostError] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [confirmation, setConfirmation] = useState(false);

  const [showContactInformation, setShowContactInformation] = useState(false);
  const [showFlightDetails, setShowFlightDetails] = useState(false);

  const [values, setValues] = useState(initialValues);
  const [touchedFields, setTouchedFields] = useState([]);
  const [errors, setErrors] = useState({});

  const getIsEticketFieldMandatory = useCallback(
    (selectedFlightNumber, selectedAirline) => {
      const parsedSelectedFlightNumber = parseInt(selectedFlightNumber, 10);
      const flightNumberRanges = get(selectedAirline, 'flightNumberRanges', []);

      return (
        !!get(values.selectedAirline, 'eticketNumberMandatory') ||
        (!isEmpty(flightNumberRanges) &&
          findIndex(
            flightNumberRanges,
            (range) =>
              parsedSelectedFlightNumber >= range?.flightNumberRangeFrom &&
              parsedSelectedFlightNumber <= range?.flightNumberRangeTo,
          ) >= 0)
      );
    },
    [values.selectedAirline],
  );

  const isEticketFieldMandatory = getIsEticketFieldMandatory(values.selectedFlightNumber, values.selectedAirline);

  const fieldValidators = useMemo(
    () => ({
      selectedAirline: [validate.required('Airline is required')],
      selectedFlightNumber: [validate.required('Flight number is required')],
      selectedDepartureDate: [validate.required('Departure date is required')],
      selectedOrigin: [validate.required('Origin is required')],
      selectedEticketNumber: [
        ...(isEticketFieldMandatory
          ? [
              validate.required('Ticket number is required'),
              validate.eTicketNumber('Ticket number should be 13 digits'),
            ]
          : [validate.eTicketNumber('Ticket number should be 13 digits')]),
      ],
      selectedDestination: [validate.required('Destination is required')],
    }),
    [isEticketFieldMandatory],
  );

  useEffect(() => {
    const commonAnalyticsData = window.vffCoreWebsite[analyticsMetadataKey] || {};

    setAnalyticsData({
      ...commonAnalyticsData,
      eventCategory: 'retro-claim',
    });
  }, [analyticsMetadataKey]);

  function setFieldValue(fieldName, value) {
    setValues((prevState) => ({
      ...prevState,
      [fieldName]: value,
    }));
  }

  function setFieldError(filedName, value) {
    setErrors((prevState) => ({
      ...prevState,
      [filedName]: value,
    }));
  }

  // Validates field and returns an error message if it is invalid
  const validateField = useCallback(
    (fieldName, fieldValue) => validateFormField(fieldValue, fieldValidators[fieldName], values),
    [values, fieldValidators],
  );

  const runFieldValidation = useCallback(
    (fieldName, fieldValue) => {
      const error = validateField(fieldName, fieldValue);

      if (error) {
        setErrors((currentErrors) => ({
          ...currentErrors,
          [fieldName]: error,
        }));
      } else {
        setErrors((currentErrors) => omit(currentErrors, fieldName));
      }
    },
    [validateField],
  );

  const handleFieldBlur = useCallback(
    (fieldName) => (newValue) => {
      const fieldValue = isUndefined(newValue) ? values[fieldName] : newValue;

      // Add to list of touched fields if required
      if (!includes(touchedFields, fieldName)) {
        setTouchedFields((currentTouchedFields) => [...currentTouchedFields, fieldName]);
      }

      // Set any errors
      runFieldValidation(fieldName, fieldValue);
    },
    [runFieldValidation, touchedFields, values],
  );

  const handleFieldBlurEvent = useCallback(
    (event) => {
      handleFieldBlur(event.target.name)();
    },
    [handleFieldBlur],
  );

  const handleEticketNumberBlurEvent = useCallback(
    (event) => {
      const fieldName = event.target.name;
      const newValue = event.target.value;

      const fieldValue = isUndefined(newValue) ? values[fieldName] : newValue;

      // Add to list of touched fields if required
      if (!includes(touchedFields, fieldName)) {
        setTouchedFields((currentTouchedFields) => [...currentTouchedFields, fieldName]);
      }

      // Set any errors
      runFieldValidation(fieldName, fieldValue);
    },
    [runFieldValidation, touchedFields, values],
  );

  async function fetchOriginAirports() {
    const airportApiUri = '/loyalty/v2/refd-airports';

    try {
      const response = await api.vffV2Api.get(airportApiUri);
      setOriginAirports(
        _(response.data.data)
          .map((foundAirport) => ({
            label: `${foundAirport.name}, ${foundAirport.city} (${foundAirport.code})`,
            value: foundAirport.code,
          }))
          .orderBy(['label'], ['asc'])
          .value(),
      );
    } catch (error) {
      setHasError(true);
      sendToNewRelic(
        getApiActionName(api.vffApi.defaults.baseURL, airportApiUri),
        getApiError(COMPONENT_NAME.retroClaims, error),
      );
    }
  }
  useEffect(() => {
    fetchOriginAirports();
  }, []);
  useEffect(() => {
    if (touchedFields.includes('selectedEticketNumber')) {
      runFieldValidation('selectedEticketNumber', values.selectedEticketNumber);
    }
  }, [runFieldValidation, touchedFields, values.selectedEticketNumber]);

  // When showFlightDetails changes, toggle off the contact information
  useEffect(() => {
    if (showFlightDetails) {
      setShowContactInformation(false);
    }
    setPostError(null);
  }, [showFlightDetails]);

  async function handleSubmit(e) {
    const retroClaimApiUri = '/loyalty/v2/retro-claims';
    const commonAnalyticsDataForSubmit = {
      ...analyticsData,
      interactionType: 'click',
      partnerName: values.selectedAirline.text,
      partnerInitials: values.selectedAirline.value,
      partnerCategory: 'airlines',
      flightDetails: values.selectedAirline.flightNumberPrefix
        ? `${values.selectedAirline.flightNumberPrefix}${values.selectedFlightNumber}`
        : values.selectedFlightNumber,
      origin: values.selectedOrigin.label,
      destination: values.selectedDestination.label,
    };

    try {
      e.preventDefault();

      analyticsSend({
        ...commonAnalyticsDataForSubmit,
        eventName: 'retro-claim-submit',
      });

      setPostError(null);
      setSubmitting(true);

      const response = await api.vffV2Api.post(retroClaimApiUri, {
        data: {
          membershipId: loyaltyMembershipID,
          lastName,
          firstName,
          ...(values.selectedEticketNumber ? { ticketNumber: values.selectedEticketNumber } : {}),
          flightSegment: {
            origin: values.selectedOrigin.value,
            destination: values.selectedDestination.value,
            flightDate: format(values.selectedDepartureDate, 'YYYY-MM-DD'),
            airlineCode: values.selectedAirline.flightNumberPrefix,
            flightNumber: values.selectedFlightNumber,
          },
        },
      });

      setSubmitting(false);

      const accrualStatusCode = get(response, 'data.data.accrualStatusCode');

      let accrualStatus;
      switch (accrualStatusCode) {
        case 'R':
          accrualStatus = 'Retro claim has been received.';
          break;
        case 'W':
          accrualStatus = 'Received with changes';
          break;
        default:
          break;
      }

      analyticsSend({
        ...commonAnalyticsDataForSubmit,
        eventName: 'retro-claim-submit-success',
      });

      setPostSuccess({
        ...response.data,
        accrualStatus,
      });

      setTimeout(() => scrollToRef(successContainerRef), 200);
    } catch (error) {
      const { response } = error;

      const errorCode = get(response, 'data.code');
      const errorMsg = find(rejected.apiSuccessMessages, (data) => data.code === errorCode);
      const title = errorMsg?.title || errorMessages?.defaultErrorMessage?.title;
      const description = errorMsg?.description || errorMessages?.defaultErrorMessage?.description;

      analyticsSend({
        ...commonAnalyticsDataForSubmit,
        eventName: 'retro-claim-submit-fail',
        errorMessage: description,
      });

      setSubmitting(false);
      setPostError({
        title,
        description,
      });

      sendToNewRelic(
        getApiActionName(api.vffV2Api.defaults.baseURL, retroClaimApiUri),
        getApiError(COMPONENT_NAME.retroClaims, error),
      );

      setTimeout(() => scrollToRef(errorContainerRef), 200);
    }
  }

  const handleReset = useCallback(async () => {
    setPostSuccess(null);
    setValues(initialValues);

    setTimeout(() => scrollToRef(flightDetailsRef), 200);
  }, []);

  const handleChangeFlightNumber = useCallback(
    (e) => {
      const newValue = e.target.value.replace(new RegExp(/[^0-9]/, 'g'), '').substring(0, 4);
      const isEticketMandatory = getIsEticketFieldMandatory(newValue, values.selectedAirline);

      setFieldValue('selectedFlightNumber', newValue);

      if (isEticketMandatory) {
        const isTouched = touchedFields.includes('selectedEticketNumber');

        if (isTouched) {
          runFieldValidation('selectedEticketNumber', values.selectedEticketNumber);
        }
      } else {
        setFieldError('selectedEticketNumber', '');
      }

      const isTouched = touchedFields.includes('selectedFlightNumber');

      if (isTouched) {
        runFieldValidation('selectedFlightNumber', newValue);
      }
    },
    [
      getIsEticketFieldMandatory,
      runFieldValidation,
      touchedFields,
      values.selectedAirline,
      values.selectedEticketNumber,
    ],
  );

  const getMandatoryFileds = useCallback(() => {
    const mandatoryFieldList = [
      'selectedAirline',
      'selectedFlightNumber',
      'selectedDepartureDate',
      'selectedOrigin',
      'selectedDestination',
    ];

    if (isEticketFieldMandatory && !mandatoryFieldList.includes('selectedEticketNumber')) {
      mandatoryFieldList.push('selectedEticketNumber');
    }
    return mandatoryFieldList;
  }, [isEticketFieldMandatory]);

  const mandatoryFields = useMemo(() => getMandatoryFileds(), [getMandatoryFileds]);

  const isLastMandatoryFieldNotTouched = useCallback(
    () => difference(mandatoryFields, touchedFields).length === 1,
    [mandatoryFields, touchedFields],
  );

  const handleChangeEticketNumber = useCallback(
    (e) => {
      const newValue = e.target.value.replace(new RegExp(/[^0-9]/, 'g'), '').substring(0, 13);
      setFieldValue('selectedEticketNumber', newValue);
      const isTouched = touchedFields.includes('selectedEticketNumber');
      if (isTouched || isLastMandatoryFieldNotTouched()) {
        runFieldValidation('selectedEticketNumber', newValue);
      }
    },
    [runFieldValidation, touchedFields, isLastMandatoryFieldNotTouched],
  );

  const handleShowPassengerDetails = useCallback(() => {
    setShowFlightDetails(false);

    setTimeout(() => scrollToRef(passengerDetailsRef), 600);
  }, []);

  const handleShowFlightDetails = useCallback(() => {
    analyticsSend({
      ...analyticsData,
      eventName: 'retro-claim-passenger-details-confirm',
      interactionType: 'click',
    });
    setShowFlightDetails(true);

    setTimeout(() => scrollToRef(flightDetailsRef), 600);
  }, [analyticsData]);

  const handleUnmatchedName = useCallback(() => {
    analyticsSend({
      ...analyticsData,
      eventName: 'retro-claim-passenger-details-cancel',
      interactionType: 'click',
    });
    setShowContactInformation(true);

    setTimeout(() => scrollToRef(contactInformationRef), 200);
  }, [analyticsData]);

  function removeOptionalLabel(text) {
    return text ? text.replace(/\s\(optional\)/gi, '') : text;
  }

  if (postSuccess) {
    const successTitle =
      values?.selectedAirline.flightNumberPrefix === 'VA' ? successMessage.title : successMessage.airlinePartnerTitle;
    const successDesc =
      values?.selectedAirline.flightNumberPrefix === 'VA'
        ? successMessage.description
        : successMessage.airlinePartnerDescription;
    return (
      <div ref={successContainerRef}>
        <div className={styles.section}>
          <div className={styles.successContainer}>
            <div className={styles.header}>
              <SuccessMessage className={styles.smallContainer} title={successTitle} description={successDesc} />
            </div>
            <div className={styles.body}>
              <div className={styles.smallContainer}>
                <div className={styles.title}>Your claim details</div>
                <div className={styles.formRow}>
                  <div className={styles.formBlock}>
                    <span>Passenger Name:</span>
                    <span>
                      {firstName} {lastName}
                    </span>
                  </div>
                  <div className={styles.formBlock}>
                    <span>Departure Date:</span>
                    <span>{format(values.selectedDepartureDate, 'DD/MM/YYYY')}</span>
                  </div>
                </div>
                <div className={styles.formRow}>
                  <div className={styles.formBlock}>
                    <span>Airline:</span>
                    <span>{values.selectedAirline.label}</span>
                  </div>
                  <div className={styles.formBlock}>
                    <span>Origin:</span>
                    <span>{values.selectedOrigin.label}</span>
                  </div>
                </div>
                <div className={styles.formRow}>
                  <div className={styles.formBlock}>
                    <span>Flight Number:</span>
                    <span>
                      {values.selectedAirline.flightNumberPrefix}
                      {values.selectedFlightNumber}
                    </span>
                  </div>
                  <div className={styles.formBlock}>
                    <span>Destination:</span>
                    <span>{values.selectedDestination.label}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className={styles.ctaContainer}>
          <Button type="submit" className={styles.ctaButton} onClick={handleReset}>
            Submit Another Claim
          </Button>
        </div>
      </div>
    );
  }

  const disabled = hasError || (values.selectedAirline && values.selectedAirline.disabled);
  let mailto;

  switch (get(values, 'selectedAirline.value')) {
    case 'DL':
      mailto = {
        email: '',
        extendedContent: '',
        message:
          'You will need to submit your Velocity membership number, boarding pass and e-ticket to us by attaching them to this <a href="https://www.velocityfrequentflyer.com/member-support/feedback" target="_blank">feedback form</a> and submitting it.',
      };
      break;
    case 'AZ':
      mailto = {
        email: 'AZRetro@velocityfrequentflyer.com',
        extendedContent: `<p>Please note that claims with ${values.selectedAirline.label} will take between 4 to 6 weeks to process.</p>`,
      };
      break;
    case 'CG':
      mailto = {
        email: '',
        extendedContent: '',
        message:
          'You will need to submit your Velocity membership number, boarding pass and e-ticket to us by attaching them to this <a href="https://www.velocityfrequentflyer.com/member-support/feedback" target="_blank">feedback form</a> and submitting it.',
      };
      break;
    case 'HA':
      mailto = {
        email: '',
        extendedContent: '',
        message:
          'You will need to submit your Velocity membership number, boarding pass and e-ticket to us by attaching them to this <a href="https://www.velocityfrequentflyer.com/member-support/feedback" target="_blank">feedback form</a> and submitting it.',
      };
      break;
    default:
      break;
  }

  const body = encodeURIComponent(`Velocity membership number: ${loyaltyMembershipID}\n
    Flight number: ${get(values, 'selectedAirline.flightNumberPrefix', '')}${values.selectedFlightNumber}\n
    Departure date: ${format(values.selectedDepartureDate, 'DD/MM/YYYY')}\n
    Origin: ${get(values, 'selectedOrigin.value', '')}\n
    Destination: ${get(values, 'selectedDestination.value', '')}\n
    \n
    Don't forget to attach your electronic ticket and boarding pass.`);

  const selectedClaimFromDate = get(values, 'selectedAirline.claimFromDate');

  // `getStartDate` returns the start date to be displayed in the departure date picker
  function getStartDate() {
    const enrolmentDate = subDays(userData.getJoinDate(user), 30);
    const claimFromDate = new Date(selectedClaimFromDate);
    const currentDateSubSixMonths = subMonths(new Date(), 6);
    const latestDate = selectedClaimFromDate
      ? [enrolmentDate, claimFromDate, currentDateSubSixMonths].sort(compareDesc)
      : [enrolmentDate, currentDateSubSixMonths].sort(compareDesc);
    return latestDate[0];
  }

  return (
    <ErrorBoundary section={COMPONENT_NAME.retroClaims}>
      <div>
        <div className={styles.section} ref={passengerDetailsRef}>
          <CollapsibleCard
            title="Passenger details"
            count={1}
            className={cx(styles.card, styles.passengerCard)}
            collapsed={showFlightDetails}
            completed={showFlightDetails}
            onClick={handleShowPassengerDetails}
          >
            <div className={styles.passengerDetails}>
              <div className={styles.passengerBlock}>
                <div>Your name:</div>
                <div className={styles.emphasis}>
                  {firstName} {lastName}
                </div>
              </div>

              <div className={styles.passengerBlock}>
                <div>Your Membership No:</div>
                <div className={styles.emphasis}>{formatMembershipNumber(loyaltyMembershipID)}</div>
              </div>
            </div>

            <div className={styles.actionsContainer}>
              <p>{nameConfirmDescription}</p>
              <div className={styles.actions}>
                <Button
                  buttonType={showFlightDetails ? 'primary' : 'primary-transparent'}
                  onClick={handleShowFlightDetails}
                >
                  Yes
                </Button>
                <Button
                  buttonType={showContactInformation ? 'primary' : 'primary-transparent'}
                  onClick={handleUnmatchedName}
                >
                  No
                </Button>
              </div>
            </div>
          </CollapsibleCard>

          {showContactInformation && contactInformation ? (
            <div className={styles.contactInformation} ref={contactInformationRef}>
              <ContactInformation
                {...contactInformation}
                analyticsDataFromParent={typeof analyticsData === 'string' ? {} : analyticsData}
              />
            </div>
          ) : null}
        </div>

        <div className={styles.section} ref={flightDetailsRef}>
          <CollapsibleCard
            title="Flight details"
            count={2}
            className={styles.card}
            collapsed={!showFlightDetails}
            transparent={!showFlightDetails}
          >
            <form className={styles.flightDetailsForm} onSubmit={handleSubmit}>
              <FormRow>
                <FormGroup>
                  <Select
                    label={airline.label.toUpperCase()}
                    items={map(airline.options, (option) => ({
                      ...option,
                      label: option.text,
                    }))}
                    onChange={(item) => {
                      analyticsSend({
                        ...analyticsData,
                        eventName: 'retro-claim-partner-select',
                        interactionType: 'click',
                        partnerName: item.text,
                        partnerInitials: item.value,
                        partnerCategory: 'airlines',
                      });
                      setConfirmation(false);
                      setFieldValue('selectedAirline', item);

                      setErrors((prevState) => ({
                        ...prevState,
                        selectedEticketNumber: '',
                      }));

                      if (
                        item.claimFromDate &&
                        isAfter(new Date(item.claimFromDate), new Date(values.selectedDepartureDate))
                      ) {
                        setFieldValue('selectedDepartureDate', '');
                      } else {
                        const isTouched = touchedFields.includes('selectedAirline');

                        if (isTouched) {
                          runFieldValidation('selectedAirline', item);
                        }
                      }
                    }}
                    error={errors.selectedAirline}
                    onBlur={handleFieldBlur('selectedAirline')}
                    selectedItem={values.selectedAirline}
                    tooltip={airline.tooltip}
                    disabled={hasError}
                    analyticsDataFromParent={typeof analyticsData === 'string' ? {} : analyticsData}
                  />
                </FormGroup>

                <FormGroup>
                  <Input
                    label={flightNumber.label.toUpperCase()}
                    name="selectedFlightNumber"
                    prefix={values.selectedAirline ? values.selectedAirline.flightNumberPrefix : null}
                    value={values.selectedFlightNumber}
                    error={errors.selectedFlightNumber}
                    onChange={handleChangeFlightNumber}
                    maxLength={4}
                    onBlur={handleFieldBlurEvent}
                    tooltip={flightNumber.tooltip}
                    disabled={disabled}
                    analyticsDataFromParent={typeof analyticsData === 'string' ? {} : analyticsData}
                  />
                </FormGroup>
              </FormRow>

              {values.selectedAirline && values.selectedAirline.tooltip ? (
                <InformationAlert title="" content={values.selectedAirline.tooltip} status="info" />
              ) : null}
              {hasError ? (
                <InformationAlert
                  title="Something went wrong"
                  content="<p>We weren't able to retrieve the airlines available. Please try again.</p>"
                />
              ) : null}
              {!disabled ? (
                <>
                  <FormRow>
                    <FormGroup>
                      <DatePicker
                        inputProps={{
                          label: departureDate.label,
                          placeholder: 'Select date',
                          readOnly: true,
                          tooltip: departureDate.tooltip,
                          disabled,
                          analyticsDataFromParent: typeof analyticsData === 'string' ? {} : analyticsData,
                        }}
                        dayPickerProps={{
                          initialMonth: subDays(new Date(), 14),
                          disabledDays: {
                            before: getStartDate(),
                            after: subDays(new Date(), 14),
                          },
                          toMonth: subDays(new Date(), 14),
                        }}
                        value={values.selectedDepartureDate}
                        onDayChange={(day) => setFieldValue('selectedDepartureDate', day)}
                        datePickerOverlayMessage="Please allow 14 days post-flight to submit a claim."
                      />
                    </FormGroup>

                    <FormGroup>
                      <Input
                        label={isEticketFieldMandatory ? removeOptionalLabel(eticketNumber.label) : eticketNumber.label}
                        value={values.selectedEticketNumber}
                        name="selectedEticketNumber"
                        onChange={handleChangeEticketNumber}
                        error={errors.selectedEticketNumber}
                        onBlur={handleEticketNumberBlurEvent}
                        tooltip={eticketNumber.tooltip}
                        disabled={disabled}
                        analyticsDataFromParent={typeof analyticsData === 'string' ? {} : analyticsData}
                      />
                    </FormGroup>
                  </FormRow>
                  <FormRow>
                    <FormGroup>
                      <Select
                        label={origin.label}
                        items={originAirports}
                        selectedItem={values.selectedOrigin}
                        onChange={(value) => {
                          setFieldValue('selectedOrigin', value);
                          const isTouched = touchedFields.includes('selectedOrigin');

                          if (isTouched) {
                            runFieldValidation('selectedOrigin', value);
                          }
                        }}
                        error={errors.selectedOrigin}
                        onBlur={handleFieldBlur('selectedOrigin')}
                        tooltip={origin.tooltip}
                        disabled={disabled}
                        analyticsDataFromParent={typeof analyticsData === 'string' ? {} : analyticsData}
                      />
                    </FormGroup>

                    <FormGroup>
                      <Select
                        label={destination.label}
                        items={originAirports}
                        selectedItem={values.selectedDestination}
                        onChange={(value) => {
                          setFieldValue('selectedDestination', value);

                          const isTouched = touchedFields.includes('selectedDestination');

                          if (isTouched) {
                            runFieldValidation('selectedDestination', value);
                          }
                        }}
                        error={errors.selectedDestination}
                        onBlur={handleFieldBlur('selectedDestination')}
                        tooltip={destination.tooltip}
                        disabled={disabled}
                        analyticsDataFromParent={typeof analyticsData === 'string' ? {} : analyticsData}
                      />
                    </FormGroup>
                  </FormRow>

                  {mailto ? (
                    <>
                      <div
                        className={styles.airlineTooltip}
                        analytics-metadata={JSON.stringify({
                          ...analyticsData,
                          eventCategory: 'hyperlink',
                        })}
                      >
                        <InformationAlert
                          title=""
                          content={
                            mailto.message ??
                            `
                                <p>You will need to send an email to <a href="mailto: ${mailto.email}?subject=${encodeURIComponent(`${values.selectedAirline.label} retro claim`)}&body=${body}">${mailto.email}</a> with your Velocity membership number and a copy of your electronic ticket and boarding pass before clicking the Submit button below.</p>
                                &nbsp;
                                ${mailto.extendedContent}
                              `
                          }
                          status="info"
                        />
                      </div>
                      <div className={styles.checkboxContainer}>
                        <Checkbox
                          label="I have emailed a copy of my electronic ticket and boarding pass"
                          checked={confirmation}
                          onChange={(e) => setConfirmation(e.target.checked)}
                          size="large"
                        />
                      </div>
                    </>
                  ) : null}
                </>
              ) : null}

              <div className={styles.ctaContainer}>
                <Button
                  type="submit"
                  className={styles.ctaButton}
                  disabled={
                    submitting ||
                    disabled ||
                    !values.selectedAirline ||
                    !values.selectedFlightNumber ||
                    !values.selectedDepartureDate ||
                    !values.selectedOrigin ||
                    !values.selectedDestination ||
                    errors.selectedEticketNumber ||
                    (mailto && !confirmation) ||
                    (isEticketFieldMandatory && !values.selectedEticketNumber)
                  }
                  loading={submitting}
                >
                  {submitButtonLabel}
                </Button>
              </div>
            </form>
          </CollapsibleCard>
          {postError ? (
            <div ref={errorContainerRef}>
              <InformationAlert
                className={styles.errorContainer}
                title={postError.title}
                content={`
                    ${postError && postError.description ? `<p>${postError.description}</p>` : ''}
                  `}
              />
            </div>
          ) : null}
        </div>
      </div>
    </ErrorBoundary>
  );
};

RetroClaims.propTypes = {
  user: PropTypes.shape().isRequired,
  nameConfirmDescription: PropTypes.string.isRequired,
  contactInformation: PropTypes.shape({}),
  airline: PropTypes.shape({
    label: PropTypes.string,
    tooltip: PropTypes.shape({}),
    options: PropTypes.arrayOf(PropTypes.shape({})),
  }),
  flightNumber: PropTypes.shape({
    label: PropTypes.string,
    tooltip: PropTypes.shape({}),
  }),
  departureDate: PropTypes.shape({
    label: PropTypes.string,
    tooltip: PropTypes.shape({}),
  }),
  eticketNumber: PropTypes.shape({
    label: PropTypes.string,
    tooltip: PropTypes.shape({}),
  }),
  origin: PropTypes.shape({
    label: PropTypes.string,
    tooltip: PropTypes.shape({}),
  }),
  destination: PropTypes.shape({
    label: PropTypes.string,
    tooltip: PropTypes.shape({}),
  }),
  successMessage: PropTypes.shape({
    title: PropTypes.string,
    description: PropTypes.string,
    airlinePartnerTitle: PropTypes.string,
    airlinePartnerDescription: PropTypes.string,
  }),
  submitButtonLabel: PropTypes.string,
  analyticsMetadata: PropTypes.shape({
    'analytics-metadata': PropTypes.string,
  }),
  errorMessages: PropTypes.shape({
    defaultErrorMessage: PropTypes.shape({
      title: PropTypes.string,
      description: PropTypes.string,
    }),
  }),
  rejected: PropTypes.shape({
    apiSuccessMessages: PropTypes.arrayOf(
      PropTypes.shape({
        code: PropTypes.number,
        title: PropTypes.string,
        description: PropTypes.string,
      }),
    ),
  }),
};

RetroClaims.defaultProps = {
  contactInformation: null,
  airline: {
    label: 'Airline',
  },
  flightNumber: {
    label: 'Flight number',
  },
  departureDate: {
    label: 'Departure date',
  },
  eticketNumber: {
    label: 'Eticket number (optional)',
  },
  origin: {
    label: 'Origin',
  },
  destination: {
    label: 'Destination',
  },
  successMessage: {
    title: 'Thank you for submitting your claim for Virgin Australia flight.',
    airlinePartnerTitle: 'Thank you, your claim is successfully submitted',
  },
  submitButtonLabel: 'Submit Claim',
  analyticsMetadata: {},
  errorMessages: {},
  rejected: {},
};

export default connect((state) => ({ user: state.user }))(RetroClaims);
