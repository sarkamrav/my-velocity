import React, { useState, useCallback, useMemo, useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import includes from 'lodash/includes';
import get from 'lodash/get';
import size from 'lodash/size';
import find from 'lodash/find';
import reduce from 'lodash/reduce';
import omit from 'lodash/omit';
import { connect } from 'react-redux';
import Button from '../../components/Button/Button';
import { COMPONENT_NAME, scrollToRef } from '../../utils/common';
import SecretInput from '../JoinPage/components/SecretInput/SecretInput';
import { validateFormField } from '../../components/Form/utils';
import * as validate from '../../components/Form/validators';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import FormContainer, { formContainerType } from '../../components/Form/containers/FormContainer/FormContainer';
import FormFieldContainer from '../../components/Form/containers/FormFieldContainer/FormFieldContainer';
import FormRow from '../../components/Form/containers/FormRow/FormRow';
import PasswordValidator from '../JoinPage/components/PasswordValidator/PasswordValidator';
import SuccessMessageTile from '../../components/SuccessMessageTile/SuccessMessageTile';
import api from '../../utils/api';
import TopContentContainer, {
  contentContainerType,
} from '../../components/Form/containers/TopContentContainer/TopContentContainer';
import MessageTile, { messageTileTheme } from '../../components/MessageTile/MessageTile';
import * as userData from '../../stores/utilities';
import Loading from '../../components/Loading/Loading';
import styles from './ChangePassword.css';

const formFieldNames = {
  newPassword: 'newPassword',
  newPasswordConfirm: 'newPasswordConfirm',
  currentPassword: 'currentPassword',
};
const initialValues = {
  [formFieldNames.newPassword]: '',
  [formFieldNames.newPasswordConfirm]: '',
  [formFieldNames.currentPassword]: '',
};

const ChangePassword = ({ user, confirmationPage, errorMessages, ctaContainer }) => {
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [touchedFields, setTouchedFields] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [postError, setPostError] = useState(null);
  const [pageError, setPageError] = useState(false);

  const errorMessageRef = useRef({});
  const isNewPasswordConfirmTouched = includes(touchedFields, 'newPasswordConfirm');

  const hasLoggedIn = userData.getHasLoggedIn(user);
  const memberDataLoadError = userData.getMemberDataLoadError(user);
  const memberDataLoading = userData.getMemberDataLoading(user);

  const fieldValidators = useMemo(
    () => ({
      [formFieldNames.currentPassword]: [validate.required('Current password is required ')],
      [formFieldNames.newPassword]: [
        validate.required('Password is required'),
        validate.password(
          'The password contains invalid characters, only the following special characters are accepted: ‘* ! ~ @ # $ % ^ & ( ) _ - + =',
        ),
        ...(includes(touchedFields, 'newPasswordConfirm')
          ? [validate.matchesField('newPasswordConfirm', 'The password you have entered does not match')]
          : []),
      ],
      [formFieldNames.newPasswordConfirm]: [
        validate.required('A password confirmation is required'),
        validate.password(
          'The password contains invalid characters, only the following special characters are accepted: ‘* ! ~ @ # $ % ^ & ( ) _ - + =',
        ),
        ...(includes(touchedFields, 'newPassword')
          ? [validate.matchesField('newPassword', 'The password you have entered does not match')]
          : []),
      ],
    }),
    [touchedFields],
  );

  // Validates field and returns an error message if it is invalid
  const validateField = useCallback(
    (fieldName, fieldValue) => validateFormField(fieldValue, fieldValidators[fieldName], values),
    [fieldValidators, values],
  );

  // Runs and applies field validation
  const runFieldValidation = useCallback(
    (fieldName, fieldValue) => {
      const error = validateField(fieldName, fieldValue);

      if (error) {
        setErrors((currentErrors) => ({
          ...currentErrors,
          [fieldName]: error,
          ...(fieldName === 'newPassword' ? { newPasswordConfirm: '' } : {}),
          ...(fieldName === 'newPasswordConfirm' ? { newPassword: '' } : {}),
        }));
      } else {
        setErrors((currentErrors) =>
          omit(currentErrors, [
            fieldName,
            ...(fieldName === 'newPassword' ? ['newPasswordConfirm'] : ''),
            ...(fieldName === 'newPasswordConfirm' ? ['newPassword'] : []),
          ]),
        );
      }
    },
    [validateField],
  );

  // -- Handlers
  const handleFieldChange = useCallback(
    (fieldName) => (newValue) => {
      // Set value
      setValues((previousValues) => ({
        ...previousValues,
        [fieldName]: newValue,
      }));

      // Give immediate error feedback for fields that are already touched
      const isTouched = includes(touchedFields, fieldName);
      if (isTouched) {
        runFieldValidation(fieldName, newValue);
      }
    },
    [runFieldValidation, touchedFields],
  );

  const handleFieldChangeEvent = useCallback(
    (event) => {
      handleFieldChange(event.target.name)(event.target.value);
    },
    [handleFieldChange],
  );

  const handleFieldBlur = useCallback(
    (fieldName) => () => {
      // Add to list of touched fields if required
      if (!includes(touchedFields, fieldName)) {
        setTouchedFields([...touchedFields, fieldName]);
      }
      runFieldValidation(fieldName, values[fieldName]);
    },
    [runFieldValidation, touchedFields, values],
  );

  const handleFieldBlurEvent = useCallback(
    (event) => {
      handleFieldBlur(event.target.name)();
    },
    [handleFieldBlur],
  );

  function checkSubmit() {
    if (
      values?.currentPassword &&
      values?.newPassword &&
      values?.newPassword === values?.newPasswordConfirm &&
      size(errors) === 0
    )
      return false;
    return true;
  }

  useEffect(() => {
    if (pageError && errorMessageRef.current) {
      scrollToRef(errorMessageRef);
    }
  }, [pageError]);

  const getError = useCallback(
    (errorCode, errorFields) => {
      const getCodeSpecificError = find(
        errorMessages.apiErrorMessages,
        (errorMessage) => errorMessage?.code === errorCode,
      );
      const getFieldSpecificError = reduce(
        errorFields,
        (result, errorField) =>
          result ||
          find(errorMessages.apiErrorMessages, {
            code: errorCode,
            errorFieldName: errorField.field,
          }),
        null,
      );

      // `modalErrorMessage` returns the filtered errorMessage accordingly
      const modalErrorMessage = getFieldSpecificError || getCodeSpecificError || errorMessages.defaultErrorMessage;
      setPostError(modalErrorMessage);
    },
    [errorMessages.apiErrorMessages, errorMessages.defaultErrorMessage],
  );

  const handleSubmit = useCallback(
    async (event) => {
      event.preventDefault();
      const changePasswordMemberApi = '/loyalty/v2/password';
      const requestBodyChange = {
        data: {
          action: 'UPDATE',
          newPassword: values.newPassword,
          currentPassword: values.currentPassword,
        },
      };
      try {
        setSubmitting(true);
        setSubmitted(false);
        setPageError(false);
        await api.vffV2Api.patch(changePasswordMemberApi, requestBodyChange);
        setSubmitting(false);
        setSubmitted(true);
        setPageError(false);
      } catch (error) {
        const errorCode = get(error, 'response.data.code', '');
        const errorFields = get(error, 'response.data.errorFields', '');
        setSubmitting(false);
        setPageError(true);
        getError(errorCode, errorFields);
      }
    },
    [getError, values.newPassword, values.currentPassword],
  );

  return (
    <ErrorBoundary section={COMPONENT_NAME.changePassword}>
      <div className={styles.container}>
        {!hasLoggedIn && memberDataLoadError && (
          <div className={styles.errorMessage}>
            <MessageTile theme="error" description="Sorry, we're having issues with our system." />
          </div>
        )}

        {!hasLoggedIn && !memberDataLoadError && memberDataLoading && (
          <div className={styles.loadingContainer}>
            <Loading />
          </div>
        )}

        {hasLoggedIn && (
          <>
            <TopContentContainer theme={contentContainerType.typeB}>
              {pageError && (
                <MessageTile
                  theme={messageTileTheme.error}
                  ref={errorMessageRef}
                  description={postError?.description}
                />
              )}
              {submitted && (
                <SuccessMessageTile
                  className={styles.successMessageTileWrapper}
                  title={confirmationPage && confirmationPage.title}
                  content={confirmationPage && confirmationPage.description}
                  ctaContainer={confirmationPage && confirmationPage.ctaContainer}
                />
              )}
            </TopContentContainer>

            {!submitted && (
              <div className={styles.formWrapper}>
                <FormContainer type={formContainerType.typeB}>
                  <form>
                    <FormRow>
                      <FormFieldContainer className={styles.currentField}>
                        <SecretInput
                          name={formFieldNames.currentPassword}
                          label="Current password"
                          placeholder="Enter password"
                          onChange={handleFieldChangeEvent}
                          onBlur={handleFieldBlurEvent}
                          value={values[formFieldNames.currentPassword]}
                          error={errors[formFieldNames.currentPassword]}
                          autoComplete="current-password"
                        />
                      </FormFieldContainer>
                    </FormRow>

                    <FormRow>
                      <div className={styles.FormFieldContainerWrapper}>
                        <FormFieldContainer type="largeRow">
                          <SecretInput
                            name={formFieldNames.newPassword}
                            label="New password"
                            placeholder="Enter password"
                            aria-describedby="password_validator_sr_description"
                            onChange={handleFieldChangeEvent}
                            onBlur={handleFieldBlurEvent}
                            value={values[formFieldNames.newPassword]}
                            error={errors[formFieldNames.newPassword]}
                            autoComplete="new-password"
                          />
                        </FormFieldContainer>
                        <FormFieldContainer type="largeRow">
                          <SecretInput
                            name={formFieldNames.newPasswordConfirm}
                            label="confirm new password"
                            placeholder="Re-enter password"
                            onChange={handleFieldChangeEvent}
                            onBlur={handleFieldBlurEvent}
                            value={values[formFieldNames.newPasswordConfirm]}
                            error={errors[formFieldNames.newPasswordConfirm]}
                            autoComplete="confirm-password"
                          />
                        </FormFieldContainer>
                      </div>

                      <PasswordValidator
                        className={styles.passwordValidator}
                        currentPassword={values.newPassword}
                        newPasswordConfirm={values.newPasswordConfirm}
                        screenReaderDescriptionContainerId="password_validator_sr_description"
                        arePasswordsMatchErrorMessage={
                          includes(touchedFields, 'newPassword') && isNewPasswordConfirmTouched
                            ? validateFormField(
                                values.newPasswordConfirm,
                                [
                                  validate.matchesField(
                                    'newPasswordConfirm',
                                    'The passwords you have entered does not match',
                                  ),
                                ],
                                values,
                              )
                            : ''
                        }
                      />
                    </FormRow>
                    <div className={styles.submitWrapper}>
                      <Button
                        ariaLabelText="form is submitting"
                        type={ctaContainer.ctaTitle}
                        className={styles.submitButton}
                        buttonType={ctaContainer.ctaType}
                        loading={submitting}
                        disabled={checkSubmit() || submitting}
                        onClick={handleSubmit}
                      >
                        <span>{ctaContainer.ctaLabel}</span>
                      </Button>
                    </div>
                  </form>
                </FormContainer>
              </div>
            )}
          </>
        )}
      </div>
    </ErrorBoundary>
  );
};

ChangePassword.propTypes = {
  user: PropTypes.shape({}).isRequired,
  ctaContainer: PropTypes.shape({
    ctaTitle: PropTypes.string.isRequired,
    ctaType: PropTypes.string.isRequired,
    ctaLabel: PropTypes.string.isRequired,
  }).isRequired,
  confirmationPage: PropTypes.shape({
    title: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
    ctaContainer: PropTypes.shape({
      ctaTitle: PropTypes.string.isRequired,
      ctaUrl: PropTypes.string.isRequired,
      ctaOpenInNewTab: PropTypes.bool.isRequired,
      ctaStyle: PropTypes.string.isRequired,
      ctaAsLink: PropTypes.bool.isRequired,
      ctaLabel: PropTypes.string.isRequired,
    }).isRequired,
  }).isRequired,
  errorMessages: PropTypes.shape({
    defaultErrorMessage: PropTypes.shape({}).isRequired,
    apiErrorMessages: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
  }).isRequired,
};

export default connect((state) => ({
  user: state.user,
}))(ChangePassword);
