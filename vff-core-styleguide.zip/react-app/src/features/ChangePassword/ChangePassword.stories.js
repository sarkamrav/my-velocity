import React from 'react';
import MockAdapter from 'axios-mock-adapter';
import { Provider } from 'react-redux';
import ChangePassword from './ChangePassword';
import api from '../../utils/api';
import ChangePasswordData from './mocks/ChangePassword.json';
import { configureStore } from '../../stores';
import userData from '../Navigation/mocks/user.mock.json';

export default {
  title: 'Change Password',
};

export const ChangePasswordPageSuccess = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });
  mockVff.onPatch('/loyalty/v2/password').reply(201, {
    data: {
      membershipId: '1234567890',
      locked: 'N',
      authentication: {
        failures: '0',
      },
    },
  });
  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <ChangePassword {...ChangePasswordData} />
      </Provider>
    </div>
  );
};

export const ChangePasswordPageError = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });
  mockVff.onPatch('/loyalty/v2/password').reply(500, {
    code: '4109',
    title: 'Bad Request',
    detail: 'Velocity Membership number not found',
    status: 400,
    errorFields: [
      {
        field: 'data',
        message: 'size must be 4',
      },
    ],
  });
  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <ChangePassword {...ChangePasswordData} />
      </Provider>
    </div>
  );
};

export const ChangePasswordLoading = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });
  mockVff.onPatch('/loyalty/v2/password').reply(201, {
    data: {
      membershipId: '1234567890',
      locked: 'N',
      authentication: {
        failures: '0',
      },
    },
  });
  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoadError: false,
            memberDataLoading: true,
            authenticated: false,
            ...userData,
          },
        })}
      >
        <ChangePassword {...ChangePasswordData} />
      </Provider>
    </div>
  );
};

export const MemberProfileApiError = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });
  mockVff.onPatch('/loyalty/v2/password').reply(201, {
    data: {
      membershipId: '1234567890',
      locked: 'N',
      authentication: {
        failures: '0',
      },
    },
  });
  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: false,
            memberDataLoading: false,
            memberDataLoadError: true,
            authenticated: false,
          },
        })}
      >
        <ChangePassword {...ChangePasswordData} />
      </Provider>
    </div>
  );
};
