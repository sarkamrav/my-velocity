export const COOKIE_NOTICE_LOCAL_STORAGE_KEY = 'cookie_notice_viewed';
