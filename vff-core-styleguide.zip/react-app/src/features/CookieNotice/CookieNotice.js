import PropTypes from 'prop-types';
import React, { useEffect, useState, useCallback } from 'react';

import RichTextContent from '../../components/RichTextContent/RichTextContent';
import HideButton from './components/HideButton/HideButton';
import { COOKIE_NOTICE_LOCAL_STORAGE_KEY } from './constants';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { positionWebChatButton } from '../Navigation/WebChat/utils';
import { COMPONENT_NAME } from '../../utils/common';

import styles from './CookieNotice.css';

const CookieNotice = ({ description, hideLabel }) => {
  const [hasCookieNoticeBeenViewed, setHasCookieNoticeBeenViewed] = useState(
    () => localStorage.getItem(COOKIE_NOTICE_LOCAL_STORAGE_KEY) === 'true',
  );

  const handleCloseClick = useCallback(() => {
    setHasCookieNoticeBeenViewed(true);
  }, []);

  useEffect(() => {
    positionWebChatButton();
  }, [hasCookieNoticeBeenViewed]);

  // Persist cookie notice viewed state when it changes
  useEffect(() => {
    localStorage.setItem(COOKIE_NOTICE_LOCAL_STORAGE_KEY, String(hasCookieNoticeBeenViewed));
  }, [hasCookieNoticeBeenViewed]);

  if (hasCookieNoticeBeenViewed) return null;

  return (
    <ErrorBoundary section={COMPONENT_NAME.cookieNotice}>
      <div className={styles.container} role="region" aria-label="Cookie notice">
        <div className={styles.inner}>
          <RichTextContent className={styles.description} content={description} />
          <HideButton label={hideLabel} onClick={handleCloseClick} />
        </div>
      </div>
    </ErrorBoundary>
  );
};

CookieNotice.propTypes = {
  description: PropTypes.string.isRequired,
  hideLabel: PropTypes.string.isRequired,
};

export default CookieNotice;
