import React from 'react';
import styles from '@sambego/storybook-styles';
import { COOKIE_NOTICE_LOCAL_STORAGE_KEY } from './constants';
import CookieNotice from './CookieNotice';
import cookieNoticeMock from './mocks/cookieNotice.mock.json';

export default {
  title: 'Cookie Notice',

  decorators: [
    styles({
      position: 'fixed',
      bottom: 0,
      left: 0,
      right: 0,
      display: 'flex',
    }),
  ],
};

export const Default = () => {
  localStorage.removeItem(COOKIE_NOTICE_LOCAL_STORAGE_KEY);

  return <CookieNotice {...cookieNoticeMock} />;
};
