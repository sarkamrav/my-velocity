import React from 'react';
import { Provider } from 'react-redux';
import MockAdapter from 'axios-mock-adapter';
import { configureStore } from '../../stores';
import api from '../../utils/api';

import forgotMemberMock from './mocks/ForgotMember.mock.json';
import ForgotMember from './ForgotMember';

export default {
  title: 'ForgotMember',
};

export const ForgotMemberSubmissionSuccess = () => {
  const mockVff = new MockAdapter(api.vffV2ApiNoToken, { delayResponse: 800 });

  mockVff.onPost('/loyalty/v2/notifications').reply(200, {});

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: false,
            memberDataLoading: false,
            memberDataLoadError: true,
            authenticated: false,
          },
        })}
      >
        <ForgotMember {...forgotMemberMock} />
      </Provider>
    </div>
  );
};

ForgotMemberSubmissionSuccess.storyName = 'ForgotMember - Submission Success';

export const ForgotMemberFormSubmissionFailed = () => {
  const mockVff = new MockAdapter(api.vffV2ApiNoToken, { delayResponse: 800 });

  mockVff.onPost('/loyalty/v2/notifications').reply(400, {
    code: 4176,
    title: 'Validation Error',
    detail: 'Validation failed for below fields',
    status: 400,
  });

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: false,
            memberDataLoading: false,
            memberDataLoadError: true,
            authenticated: false,
          },
        })}
      >
        <ForgotMember {...forgotMemberMock} />
      </Provider>
    </div>
  );
};

ForgotMemberFormSubmissionFailed.storyName = 'ForgotMember - Submission Failed';
