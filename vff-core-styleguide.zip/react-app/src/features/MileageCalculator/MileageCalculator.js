import React, { useState } from 'react';
import PropTypes from 'prop-types';
import omit from 'lodash/omit';
import isUndefined from 'lodash/isUndefined';
import includes from 'lodash/includes';
import map from 'lodash/map';
import find from 'lodash/find';
import get from 'lodash/get';
import cx from 'classnames';

import Button from '../../components/Button/Button';
import A from '../../components/Button/A';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import Select from '../../components/Form/Select/Select';
import { COMPONENT_NAME, isCtaAvailable } from '../../utils/common';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import TopContentContainer from '../../components/Form/containers/TopContentContainer/TopContentContainer';
import FormContainer, { formContainerColor } from '../../components/Form/containers/FormContainer/FormContainer';
import FormRow from '../../components/Form/containers/FormRow/FormRow';
import FormFieldContainer from '../../components/Form/containers/FormFieldContainer/FormFieldContainer';
import { validateFormField } from '../../components/Form/utils';
import * as validate from '../../components/Form/validators';
import FormContentContainer from '../../components/Form/containers/FormContentContainer/FormContentContainer';
import Icon from '../../components/Icon/Icon';

import styles from './MileageCalculator.css';

const formFieldNames = {
  origin: 'origin',
  destination: 'destination',
};

const initialValues = {
  [formFieldNames.origin]: null,
  [formFieldNames.destination]: null,
};

const fieldValidators = {
  [formFieldNames.origin]: [validate.required('Fly from is required')],
  [formFieldNames.destination]: [validate.required('Fly to is required')],
};

const optionFormat = (item) => ({
  label: `${item.name}, ${item.city} (${item.code})`,
  value: item.code,
});

const getOriginInfoByCode = (origins, selectedOrigin) => find(origins, { code: get(selectedOrigin, 'value') });

const getDestinationByCode = (origins, selectedOrigin, selectedDestination) =>
  find(get(getOriginInfoByCode(origins, selectedOrigin), 'destinations'), { code: get(selectedDestination, 'value') });

const getOriginOptions = (origins) => map(origins, optionFormat);

const getDestinationOptions = (selectedOrigin, origins) =>
  map(get(getOriginInfoByCode(origins, selectedOrigin), 'destinations'), optionFormat);

const MileageCalculator = ({
  title,
  description,
  formTitle,
  disclaimerText,
  ctaContainer,
  secondaryCtaContainer,
  tertiaryCtaContainer,
  origins,
}) => {
  const [values, setValues] = useState(initialValues);
  const [touchedFields, setTouchedFields] = useState([]);
  const [errors, setErrors] = useState({});

  const [isMilesInfoVisible, setIsMilesInfoVisible] = useState(false);
  const [animateFlightIcon, setAnimateFlightIcon] = useState(false);

  // Validates field and returns an error message if it is invalid
  function validateField(fieldName, fieldValue) {
    return validateFormField(fieldValue, fieldValidators[fieldName], values);
  }

  function runFieldValidation(fieldName, fieldValue) {
    const error = validateField(fieldName, fieldValue);

    if (error) {
      setErrors((currentErrors) => ({
        ...currentErrors,
        [fieldName]: error,
      }));
    } else {
      setErrors((currentErrors) => omit(currentErrors, fieldName));
    }
  }

  function handleFieldBlur(fieldName) {
    return (newValue) => {
      const fieldValue = isUndefined(newValue) ? values[fieldName] : newValue;

      // Add to list of touched fields if required
      if (!includes(touchedFields, fieldName)) {
        setTouchedFields((currentTouchedFields) => [...currentTouchedFields, fieldName]);
      }

      // Set any errors
      runFieldValidation(fieldName, fieldValue);
    };
  }

  const handleChange = (fieldName, value) => {
    setValues((prevState) => ({
      ...prevState,
      [fieldName]: value,
      ...(fieldName === formFieldNames.origin
        ? {
            [formFieldNames.destination]: null,
          }
        : {}),
    }));

    setIsMilesInfoVisible(false);

    const isTouched = touchedFields.includes(fieldName);

    if (isTouched) {
      runFieldValidation(fieldName, value);
    }
  };

  const onCalculateClicked = (event) => {
    event.preventDefault();
    setIsMilesInfoVisible(true);
    setAnimateFlightIcon(false);
    setTimeout(() => setAnimateFlightIcon(true), 300);
  };

  const originInfo = getOriginInfoByCode(origins, values[formFieldNames.origin]);
  const destinationInfo = getDestinationByCode(
    origins,
    values[formFieldNames.origin],
    values[formFieldNames.destination],
  );

  return (
    <ErrorBoundary section={COMPONENT_NAME.mileageCalculator}>
      <div className={styles.container}>
        <TopContentContainer>
          {title && <h2 className={styles.title}>{title}</h2>}
          {description && <RichTextContent className={styles.description} content={description} />}
        </TopContentContainer>

        <FormContainer theme={formContainerColor.grey}>
          <FormContentContainer>
            <h3 className={cx('vaHeading vaHeading--5 color color--purple', styles.formTitle)}>{formTitle}</h3>
          </FormContentContainer>

          <form onSubmit={onCalculateClicked}>
            <FormRow>
              <FormFieldContainer>
                <Select
                  label="FLY FROM"
                  placeholder="Airport/City"
                  name={formFieldNames.origin}
                  selectedItem={values[formFieldNames.origin]}
                  isSearchable
                  onChange={(value) => handleChange('origin', value)}
                  items={getOriginOptions(origins)}
                  error={errors[formFieldNames.origin]}
                  onBlur={handleFieldBlur(formFieldNames.origin)}
                />
              </FormFieldContainer>

              <FormFieldContainer>
                <Select
                  label="FLY TO"
                  placeholder="Destination"
                  name={formFieldNames.destination}
                  selectedItem={values[formFieldNames.destination]}
                  onChange={(value) => handleChange('destination', value)}
                  items={getDestinationOptions(values[formFieldNames.origin], origins)}
                  isSearchable
                  error={errors[formFieldNames.destination]}
                  disabled={!values[formFieldNames.origin]}
                  onBlur={handleFieldBlur(formFieldNames.destination)}
                />
              </FormFieldContainer>
            </FormRow>

            <div className={styles.buttonContainer}>
              <Button
                className={styles.calculateButton}
                label={ctaContainer.ctaLabel}
                buttonType={ctaContainer.ctaType}
                onClick={onCalculateClicked}
                disabled={!values[formFieldNames.origin] || !values[formFieldNames.destination]}
              >
                {ctaContainer.ctaTitle}
              </Button>
            </div>
          </form>
        </FormContainer>

        {isMilesInfoVisible && originInfo && destinationInfo && (
          <div className={styles.resultWrapper}>
            <div className={styles.locationWrapper}>
              <div className={styles.location}>
                {originInfo?.city} <span className={styles.subTitleLocation}>({originInfo?.code})</span>
              </div>
              <Icon
                name="AirplaneRight"
                className={cx(styles.flightImg, {
                  'vffutils__slide-right': animateFlightIcon,
                })}
              />
              <div className={styles.location}>
                {destinationInfo?.city} <span className={styles.subTitleLocation}>({destinationInfo?.code})</span>
              </div>
            </div>
            <div className={styles.distanceWrapper}>
              <div className={styles.distance}>{destinationInfo?.miles} miles</div>
              <div className={styles.distance}>({Math.floor((destinationInfo?.miles ?? 0) * 1.6)} kms)</div>
            </div>

            {disclaimerText && <RichTextContent className={styles.content} content={disclaimerText} />}

            {isCtaAvailable(secondaryCtaContainer) && (
              <A
                linkClassName={styles.secondaryLink}
                className={styles.secondaryLink}
                buttonType={secondaryCtaContainer.ctaStyle}
                ctaAsLink={secondaryCtaContainer.ctaAsLink}
                href={secondaryCtaContainer.ctaUrl}
                title={secondaryCtaContainer.ctaTitle}
                target={secondaryCtaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
              >
                {secondaryCtaContainer.ctaLabel}
              </A>
            )}

            {isCtaAvailable(tertiaryCtaContainer) && (
              <A
                buttonType={tertiaryCtaContainer.ctaStyle}
                ctaAsLink={tertiaryCtaContainer.ctaAsLink}
                href={tertiaryCtaContainer.ctaUrl}
                title={tertiaryCtaContainer.ctaTitle}
                target={tertiaryCtaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
              >
                {tertiaryCtaContainer.ctaLabel}
              </A>
            )}
          </div>
        )}
      </div>
    </ErrorBoundary>
  );
};

MileageCalculator.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
  formTitle: PropTypes.string,
  disclaimerText: PropTypes.string,
  ctaContainer: PropTypes.shape({
    ctaLabel: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaTitle: PropTypes.string,
    ctaAsLink: PropTypes.bool,
    ctaStyle: PropTypes.string,
    ctaType: PropTypes.string,
  }),
  secondaryCtaContainer: PropTypes.shape({
    ctaLabel: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaTitle: PropTypes.string,
    ctaAsLink: PropTypes.bool,
    ctaStyle: PropTypes.string,
    ctaUrl: PropTypes.string,
    ctaType: PropTypes.string,
  }),
  tertiaryCtaContainer: PropTypes.shape({
    ctaLabel: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaTitle: PropTypes.string,
    ctaAsLink: PropTypes.bool,
    ctaStyle: PropTypes.string,
    ctaUrl: PropTypes.string,
    ctaType: PropTypes.string,
  }),
  origins: PropTypes.arrayOf(
    PropTypes.shape({
      code: PropTypes.string,
      name: PropTypes.string,
      city: PropTypes.string,
      destinations: PropTypes.arrayOf(
        PropTypes.shape({
          code: PropTypes.string,
          name: PropTypes.string,
          city: PropTypes.string,
          miles: PropTypes.string,
          zone: PropTypes.string,
        }),
      ),
    }),
  ),
};

MileageCalculator.defaultProps = {
  title: null,
  description: null,
  formTitle: '',
  disclaimerText: '',
  ctaContainer: null,
  tertiaryCtaContainer: null,
  secondaryCtaContainer: null,
  origins: null,
};

export default MileageCalculator;
