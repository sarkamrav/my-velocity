import React from 'react';

import MileageCalculator from './MileageCalculator';
import mileageCalculatorMock from './MileageCalculator.mock.json';

export default {
  title: 'Mileage Calculator',
};

export const Default = () => <MileageCalculator {...mileageCalculatorMock} />;
