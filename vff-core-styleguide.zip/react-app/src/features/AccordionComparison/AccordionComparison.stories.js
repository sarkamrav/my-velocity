import React from 'react';
import AccordionComparison from './AccordionComparison';
import benefitsAtAGlanceMock from './mocks/AccordionComparison.mock.json';

export default {
  title: 'Accordion Comparison',
};

export const AllTypes = () => <AccordionComparison {...benefitsAtAGlanceMock} />;
