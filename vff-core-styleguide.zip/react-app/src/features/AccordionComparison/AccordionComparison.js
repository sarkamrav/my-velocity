import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';

import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import Disclosure from './Disclosure/Disclosure';
import { COMPONENT_NAME } from '../../utils/common';

import styles from './AccordionComparison.css';

const AccordionComparison = ({ title, header, description, items }) => (
  <ErrorBoundary section={COMPONENT_NAME.accordionComparison}>
    <div className={styles.container}>
      {!!title && <h3 className={styles.mainTitle}>{title}</h3>}

      {!!description && <RichTextContent className={styles.description} content={description} />}

      <div className={styles.contentContainer}>
        {!_.isEmpty(header) && (
          <div className={styles.contentHeader}>
            <RichTextContent className={styles.contentHeaderText} content={header.title} />

            {_.map(header.items, (item) => (
              <div key={item.title} className={styles.contentHeaderIconContainer}>
                <img className={styles.contentHeaderIcon} src={item.iconUrl} alt="" />
                <RichTextContent className={styles.contentHeaderIconText} content={item.title} />
              </div>
            ))}
          </div>
        )}

        {!_.isEmpty(items) && (
          <ul className={styles.parentList}>
            {_.map(items, (item) => {
              const content = !_.isEmpty(item.items) && (
                <ul className={styles.childList}>
                  {_.map(item.items, (subItem) => (
                    <li key={subItem.pathId}>
                      <Disclosure
                        openByDefault={subItem.openByDefault}
                        header={
                          <div className={styles.childListHeader}>
                            <h5 className={styles.childListTitle}>{subItem.title}</h5>

                            {_.map(subItem.features, (feature) => (
                              <span key={feature.title} className={styles.tickIconContainer}>
                                {feature.iconUrl ? <img src={feature.iconUrl} alt={feature.title} /> : null}
                              </span>
                            ))}
                          </div>
                        }
                        content={
                          <RichTextContent className={styles.childListContainer} content={subItem.description} />
                        }
                        contentId={subItem.id}
                      />
                    </li>
                  ))}
                </ul>
              );

              return (
                <li key={item.pathId}>
                  <Disclosure
                    header={<h4 className={styles.parentListHeader}>{item.title}</h4>}
                    content={content}
                    contentId={item.id}
                    isArrowOnRight
                    openByDefault={item.openByDefault}
                    childItems={item.items}
                  />
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  </ErrorBoundary>
);

AccordionComparison.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
  header: PropTypes.shape({
    title: PropTypes.string,
    items: PropTypes.arrayOf(PropTypes.shape({})),
  }),
  items: PropTypes.arrayOf(PropTypes.shape({})),
};

AccordionComparison.defaultProps = {
  title: '',
  description: '',
  header: null,
  items: [],
};

export default AccordionComparison;
