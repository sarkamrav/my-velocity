import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import PropTypes from 'prop-types';
import get from 'lodash/get';
import has from 'lodash/has';
import includes from 'lodash/includes';
import isEmpty from 'lodash/isEmpty';
import isUndefined from 'lodash/isUndefined';
import omit from 'lodash/omit';
import difference from 'lodash/difference';

import { COMPONENT_NAME, getAuthorableErrorMsg, getNavigationHeight, smoothScrollToElement } from '../../utils/common';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import api from '../../utils/api';
import * as validate from '../../components/Form/validators';
import { normalizeFormField, validateFormField } from '../../components/Form/utils';
import * as normalize from '../../components/Form/normalizers';

import RichTextContent from '../../components/RichTextContent/RichTextContent';
import Button from '../../components/Button/Button';
import MessageTile, { messageTileTheme } from '../../components/MessageTile/MessageTile';
import SuccessMessageTile, { successMessageTheme } from '../../components/SuccessMessageTile/SuccessMessageTile';
import FormRow from '../../components/Form/containers/FormRow/FormRow';
import FormFieldContainer from '../../components/Form/containers/FormFieldContainer/FormFieldContainer';
import Input from '../../components/Form/Input/Input';
import FormContainer, {
  formContainerColor,
  formContainerType,
} from '../../components/Form/containers/FormContainer/FormContainer';
import TopContentContainer, {
  contentContainerType,
} from '../../components/Form/containers/TopContentContainer/TopContentContainer';
import styles from './ResetPassword.css';

const ResetPassword = ({ description, forgotMember, ctaContainer, confirmation, errorMessages }) => {
  const submitErrorAlertId = useRef();
  const successInfoBoxId = 'success-info-box';

  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [postError, setPostError] = useState('');

  const [errors, setErrors] = useState({});
  const [touchedFields, setTouchedFields] = useState([]);

  const initialValues = {
    firstName: '',
    lastName: '',
    membershipId: '',
  };

  const [values, setValues] = useState(initialValues);

  const mandatoryFields = useMemo(() => ['firstName', 'lastName', 'membershipId'], []);
  const isLastMandatoryFieldNotTouched = useCallback(
    () => difference(mandatoryFields, touchedFields).length === 1,
    [mandatoryFields, touchedFields],
  );

  const fieldValidators = useMemo(
    () => ({
      firstName: [validate.required('First name is required'), validate.name('Invalid first name')],
      lastName: [validate.required('Last name is required'), validate.name('Invalid last name')],
      membershipId: [
        validate.required('Please enter your Velocity Number'),
        validate.velocityNumber('Please enter a valid membership No.'),
      ],
    }),
    [],
  );

  const fieldNormalizers = useMemo(
    () => ({
      firstName: [normalize.maxLength(32)],
      lastName: [normalize.maxLength(32)],
      membershipId: [normalize.onlyNumbers, normalize.maxLength(10)],
    }),
    [],
  );

  // Validates field and returns an error message if it is invalid
  const validateField = useCallback(
    (fieldName, fieldValue) => validateFormField(fieldValue, fieldValidators[fieldName], values),
    [fieldValidators, values],
  );

  // Runs and applies field validation
  const runFieldValidation = useCallback(
    (fieldName, fieldValue) => {
      const error = validateField(fieldName, fieldValue);
      if (error) {
        setErrors({
          ...errors,
          [fieldName]: error,
        });
      } else {
        setErrors(omit(errors, fieldName));
      }
    },
    [validateField, errors],
  );

  const handleFieldChange = useCallback(
    (fieldName) => (newValue) => {
      const normalizedValue = normalizeFormField(newValue, fieldNormalizers[fieldName]);

      // Set value
      setValues((previousValues) => ({
        ...previousValues,
        [fieldName]: normalizedValue,
      }));

      // Give immediate error feedback for fields that are already touched
      const isTouched = includes(touchedFields, fieldName);
      if (isTouched || isLastMandatoryFieldNotTouched()) {
        runFieldValidation(fieldName, normalizedValue);
      }
    },
    [runFieldValidation, fieldNormalizers, touchedFields, isLastMandatoryFieldNotTouched],
  );

  const handleFieldChangeEvent = useCallback(
    (event) => {
      handleFieldChange(event.target.name)(event.target.value);
    },
    [handleFieldChange],
  );

  const handleFieldBlur = useCallback(
    (fieldName) => (newValue) => {
      const fieldValue = isUndefined(newValue) ? values[fieldName] : newValue;

      // Add to list of touched fields if required
      if (!includes(touchedFields, fieldName)) {
        setTouchedFields((currentTouchedFields) => [...currentTouchedFields, fieldName]);
      }

      // Set any errors
      runFieldValidation(fieldName, fieldValue);
    },
    [runFieldValidation, touchedFields, values],
  );

  const handleFieldBlurEvent = useCallback(
    (event) => {
      handleFieldBlur(event.target.name)();
    },
    [handleFieldBlur],
  );

  function checkFormValidity() {
    return !mandatoryFields.every((field) => !isEmpty(values[field]) && !has(errors, field));
  }

  const resetPasswordApiUrl = '/loyalty/v2/password';
  const onFormSubmit = async (e) => {
    e.preventDefault();
    try {
      setSubmitting(true);
      setSubmitted(false);
      setPostError('');
      const resetPasswordApiBody = {
        data: {
          membershipId: values?.membershipId,
          action: 'RESET-REQUEST',
          individual: {
            identity: {
              firstName: values?.firstName,
              lastName: values?.lastName,
            },
          },
        },
      };

      await api.vffV2ApiNoToken.patch(resetPasswordApiUrl, resetPasswordApiBody);
      setSubmitting(false);
      setSubmitted(true);
    } catch (err) {
      setSubmitting(false);
      const customError = getAuthorableErrorMsg(err, errorMessages);
      setPostError(customError);
    }
  };

  useEffect(() => {
    if (submitted) {
      smoothScrollToElement(document.getElementById(successInfoBoxId), getNavigationHeight());
    }
  }, [submitted]);

  useEffect(() => {
    if (postError) {
      smoothScrollToElement(submitErrorAlertId.current, getNavigationHeight());
    }
  }, [postError]);

  return (
    <ErrorBoundary section={COMPONENT_NAME.resetPassword}>
      <div className={styles.container}>
        {submitted && (
          <TopContentContainer theme={contentContainerType.typeB} className={styles.paddingBottomZero}>
            <SuccessMessageTile
              id={successInfoBoxId}
              className={styles.resetPasswordSuccess}
              theme={successMessageTheme.shadow}
              title={get(confirmation, 'title') || ''}
              content={get(confirmation, 'description') || ''}
              ctaContainer={get(confirmation, 'ctaContainer') || ''}
              iconPath={get(confirmation, 'iconUrl') || ''}
            />
          </TopContentContainer>
        )}

        {!submitted && (
          <>
            <TopContentContainer theme={contentContainerType.typeB}>
              {postError && (
                <MessageTile
                  ref={submitErrorAlertId}
                  theme={messageTileTheme.error}
                  description={postError.description}
                />
              )}
            </TopContentContainer>

            <form onSubmit={onFormSubmit}>
              <FormContainer theme={formContainerColor.white} type={formContainerType.typeB}>
                <RichTextContent className={styles.descriptionText} content={description} />
                <FormRow>
                  <FormFieldContainer>
                    <Input
                      label="First name"
                      name="firstName"
                      onChange={handleFieldChangeEvent}
                      onBlur={handleFieldBlurEvent}
                      value={values.firstName}
                      error={errors.firstName}
                      autoComplete="given-name"
                    />
                  </FormFieldContainer>
                </FormRow>

                <FormRow>
                  <FormFieldContainer className={styles.colWidthTwo}>
                    <Input
                      label="Last name"
                      name="lastName"
                      value={values.lastName}
                      error={errors.lastName}
                      onChange={handleFieldChangeEvent}
                      onBlur={handleFieldBlurEvent}
                      autoComplete="family-name"
                    />
                  </FormFieldContainer>
                </FormRow>

                <FormRow>
                  <FormFieldContainer>
                    <Input
                      type="text"
                      name="membershipId"
                      label="Velocity number"
                      value={values.membershipId}
                      error={errors.membershipId}
                      onChange={handleFieldChangeEvent}
                      onBlur={handleFieldBlurEvent}
                      autoComplete="off"
                    />
                  </FormFieldContainer>
                </FormRow>
                {
                  // eslint-disable-next-line react/jsx-no-target-blank
                  <a
                    className={styles.forgotMember}
                    href={get(forgotMember, 'ctaUrl')}
                    title={get(forgotMember, 'ctaTitle')}
                    target={get(forgotMember, 'ctaOpenInNewTab') ? '_blank' : '_self'}
                    rel={get(forgotMember, 'ctaOpenInNewTab') ? 'noopener noreferrer' : null}
                  >
                    {get(forgotMember, 'ctaLabel')}
                  </a>
                }

                <div className={styles.ctaContainer}>
                  <Button
                    type="submit"
                    title={get(ctaContainer, 'ctaTitle')}
                    target={get(ctaContainer, 'ctaOpenInNewTab') ? '_blank' : '_self'}
                    buttonType={get(ctaContainer, 'ctaStyle')}
                    disabled={checkFormValidity() || submitting}
                    loading={submitting}
                  >
                    {get(ctaContainer, 'ctaLabel')}
                  </Button>
                </div>
              </FormContainer>
            </form>
          </>
        )}
      </div>
    </ErrorBoundary>
  );
};

ResetPassword.propTypes = {
  description: PropTypes.string.isRequired,
  forgotMember: PropTypes.string.isRequired,
  ctaContainer: PropTypes.shape({}).isRequired,
  confirmation: PropTypes.shape({}).isRequired,
  errorMessages: PropTypes.shape({}).isRequired,
};

export default ResetPassword;
