import React from 'react';
import { Provider } from 'react-redux';
import MockAdapter from 'axios-mock-adapter';
import { configureStore } from '../../stores';
import api from '../../utils/api';

import resetPasswordMock from './mocks/ResetPassword.mock.json';
import ResetPassword from './ResetPassword';

export default {
  title: 'ResetPassword',
};

export const ResetPasswordSubmissionSuccess = () => {
  const mockVff = new MockAdapter(api.vffV2ApiNoToken, { delayResponse: 800 });

  mockVff.onPatch('/loyalty/v2/password').reply(204);

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: false,
            memberDataLoading: false,
            memberDataLoadError: true,
            authenticated: false,
          },
        })}
      >
        <ResetPassword {...resetPasswordMock} />
      </Provider>
    </div>
  );
};

ResetPasswordSubmissionSuccess.storyName = 'ResetPassword - Submission Success';

export const ResetPasswordFormSubmissionFailed = () => {
  const mockVff = new MockAdapter(api.vffV2ApiNoToken, { delayResponse: 800 });

  mockVff.onPatch('/loyalty/v2/password').reply(400, {
    code: 4176,
    title: 'Bad Request',
    detail: 'Velocity Membership number not found',
    status: 400,
  });

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: false,
            memberDataLoading: false,
            memberDataLoadError: true,
            authenticated: false,
          },
        })}
      >
        <ResetPassword {...resetPasswordMock} />
      </Provider>
    </div>
  );
};

ResetPasswordFormSubmissionFailed.storyName = 'ResetPassword - Submission Failed';
