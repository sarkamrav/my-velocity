import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';

import A from '../../components/Button/A';
import Container from '../../components/Container/Container';
import Icon from '../../components/Icon/Icon';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME } from '../../utils/common';

import styles from './CallOut.css';

const CallOut = ({ iconUrl, title, description, ctaContainer, analyticsMetadata, className }) => (
  <ErrorBoundary section={COMPONENT_NAME.callOut}>
    <Container className={cx(styles.container, className)} {...analyticsMetadata}>
      <div className={styles.leftSide}>
        {iconUrl ? (
          <img className={styles.icon} src={iconUrl} alt={title} />
        ) : (
          <Icon name="Binoculars" className={styles.icon} />
        )}

        <div className={styles.descriptionContainer}>
          <span className={styles.title}>{title}</span>
          <span className={styles.description} dangerouslySetInnerHTML={{ __html: description }} />
        </div>
      </div>

      {ctaContainer && ctaContainer.ctaLabel ? (
        <div className={styles.callToActionContainer}>
          <A
            href={ctaContainer.ctaUrl}
            title={ctaContainer.ctaTitle}
            className={styles.callToAction}
            target={ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
            buttonType={ctaContainer.ctaStyle}
            ctaAsLink={ctaContainer.ctaAsLink}
          >
            {ctaContainer.ctaLabel}
          </A>
        </div>
      ) : null}
    </Container>
  </ErrorBoundary>
);

CallOut.propTypes = {
  title: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
  iconUrl: PropTypes.string,
  ctaContainer: PropTypes.shape({
    ctaUrl: PropTypes.string,
    ctaTitle: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaStyle: PropTypes.string,
    ctaAsLink: PropTypes.bool,
    ctaLabel: PropTypes.string,
  }),
  analyticsMetadata: PropTypes.shape({
    'analytics-metadata': PropTypes.string,
  }),
  renderMode: PropTypes.oneOf(['both', 'authenticated', 'unauthenticated']),
  className: PropTypes.string,
};

CallOut.defaultProps = {
  iconUrl: null,
  ctaContainer: null,
  renderMode: 'both',
  analyticsMetadata: {},
  className: '',
};

export default CallOut;
