import React from 'react';
import { Provider } from 'react-redux';
import store from '../../stores';
import CallOut from './CallOut';
import callOutMock from './mocks/call-out.mock.json';

export default {
  title: 'Call Out',
};

export const Default = () => (
  <Provider store={store}>
    <div className="vffutils__container-width vffutils__container-width--full">
      <CallOut {...callOutMock} />
    </div>
  </Provider>
);
