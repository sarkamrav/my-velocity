export const serverTimeZone = { timeZone: 'Australia/Brisbane' };

export const POINTS_TRANSFER_FORM = {
  STEP_1: 'step_1',
  STEP_2: 'step_2',
  STEP_3: 'step_3',
};

export const transferRelationshipOptions = [
  {
    label: 'Aunt',
    value: 'Aunt',
  },
  {
    label: 'Brother',
    value: 'Brother',
  },
  {
    label: 'Brother-in-law',
    value: 'Brother-in-law',
  },
  {
    label: 'Daughter',
    value: 'Daughter',
  },
  {
    label: 'Daughter-in-law',
    value: 'Daughter-in-law',
  },
  {
    label: 'De Facto',
    value: 'De Facto',
  },
  {
    label: 'Domestic Partner',
    value: 'Domestic Partner',
  },
  {
    label: 'Father',
    value: 'Father',
  },
  {
    label: 'Father-in-law',
    value: 'Father-in-law',
  },
  {
    label: 'First Cousin',
    value: 'First Cousin',
  },
  {
    label: 'Foster Daughter',
    value: 'Foster Daughter',
  },
  {
    label: 'Foster Son',
    value: 'Foster Son',
  },
  {
    label: 'Granddaughter',
    value: 'Granddaughter',
  },
  {
    label: 'Grandfather',
    value: 'Grandfather',
  },
  {
    label: 'Grandmother',
    value: 'Grandmother',
  },
  {
    label: 'Grandson',
    value: 'Grandson',
  },
  {
    label: 'Great-Grandfather',
    value: 'Great-Grandfather',
  },
  {
    label: 'Great-Grandmother',
    value: 'Great-Grandmother',
  },
  {
    label: 'Half Brother',
    value: 'Half Brother',
  },
  {
    label: 'Half Sister',
    value: 'Half Sister',
  },
  {
    label: 'Husband',
    value: 'Husband',
  },
  {
    label: 'Mother',
    value: 'Mother',
  },
  {
    label: 'Mother-in-law',
    value: 'Mother-in-law',
  },
  {
    label: 'Nephew',
    value: 'Nephew',
  },
  {
    label: 'Niece',
    value: 'Niece',
  },
  {
    label: 'Sister',
    value: 'Sister',
  },
  {
    label: 'Sister-in-law',
    value: 'Sister-in-law',
  },
  {
    label: 'Son',
    value: 'Son',
  },
  {
    label: 'Uncle',
    value: 'Uncle',
  },
  {
    label: 'Wife',
    value: 'Wife',
  },
];
