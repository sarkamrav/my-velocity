import React, { useState, useEffect, useCallback } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';

import { DateTime } from 'luxon';
import PointsTransferForm from './PointsTransferForm/PointsTransferForm';
import InformationAlert from '../../components/InformationAlert/InformationAlert';
import Loading from '../../components/Loading/Loading';
import * as userData from '../../stores/utilities';
import api from '../../utils/api';
import { COMPONENT_NAME, getCurrentUrl } from '../../utils/common';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { getApiActionName, getApiError, sendToNewRelic } from '../../utils/newRelic';

import styles from './FamilyPointsTransfer.css';

const startDate = DateTime.now().startOf('year').toFormat('yyyy-MM-dd');
const endDate = DateTime.now().endOf('year').toFormat('yyyy-MM-dd');
const transactioCountApiUri = `/loyalty/v2/activities?startDate=${startDate}&endDate=${endDate}&pageOffset=0&pageLimit=100&activitySubType=TRANSFER_FROM&activityType=TRANSFER&awardCategory=STANDARD`;

const FamilyPointsTransfer = ({ user, title, description, familyPointsTransferForm, errorMessages }) => {
  const hasLoggedIn = userData.getHasLoggedIn(user);
  const memberDataLoadError = userData.getMemberDataLoadError(user);
  const currentPointsbalance = userData.getCurrentPointsBalance(user);
  const loyaltyMembershipID = userData.getLoyaltyMembershipID(user);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [transactionCount, setTransactionCount] = useState(null);

  const defaultErrorMessage = `Sorry we&apos;re having issues with our system. Please <a href="${getCurrentUrl()}" title="refresh the page">refresh the page</a> or try again later.`;

  const fetchTransactionCount = useCallback(async () => {
    try {
      setLoading(true);
      const response = await api.vffV2Api.get(transactioCountApiUri);
      setTransactionCount(response.data.metaData.count);
      setLoading(false);
    } catch (e) {
      setLoading(false);
      setError(defaultErrorMessage);

      sendToNewRelic(
        getApiActionName(api.vffV2Api.defaults.baseURL, transactioCountApiUri),
        getApiError(COMPONENT_NAME.familyPointsTransfer, e),
      );
    }
  }, [defaultErrorMessage]);

  useEffect(() => {
    if (hasLoggedIn) {
      fetchTransactionCount();
    }
  }, [hasLoggedIn, fetchTransactionCount]);

  const isContentReadyForDisplay = !error && !loading;

  return (
    <ErrorBoundary section={COMPONENT_NAME.familyPointsTransfer}>
      <div className={styles.container}>
        {!hasLoggedIn && memberDataLoadError && (
          <InformationAlert
            title=""
            content="Sorry, we're having issues with our system."
            className={styles.errorContainer}
          />
        )}

        {!hasLoggedIn && !memberDataLoadError && (
          <div className={styles.loadingContainer}>
            <Loading />
          </div>
        )}

        {hasLoggedIn && (
          <>
            {!!error && <InformationAlert title="" content={error} className={styles.errorContainer} />}

            {isContentReadyForDisplay && (
              <section className={styles.formSection}>
                <PointsTransferForm
                  formTitle={title}
                  formDescription={description}
                  authorableContent={familyPointsTransferForm}
                  authorableErrMsg={errorMessages}
                  currentPointsbalance={currentPointsbalance}
                  loyaltyMembershipID={loyaltyMembershipID}
                  transactionCount={transactionCount}
                  updateTranscationCount={() => setTransactionCount(transactionCount + 1)}
                />
              </section>
            )}

            {loading && (
              <div className={styles.loadingContainer}>
                <Loading />
              </div>
            )}
          </>
        )}
      </div>
    </ErrorBoundary>
  );
};

FamilyPointsTransfer.propTypes = {
  user: PropTypes.shape({}),
  title: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
  familyPointsTransferForm: PropTypes.shape({}).isRequired,
  errorMessages: PropTypes.shape({}).isRequired,
};

FamilyPointsTransfer.defaultProps = {
  user: null,
};

export default connect((state) => ({
  user: state.user,
}))(FamilyPointsTransfer);
