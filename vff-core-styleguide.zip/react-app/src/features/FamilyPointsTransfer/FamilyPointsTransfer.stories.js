import React from 'react';
import { Provider } from 'react-redux';
import MockAdapter from 'axios-mock-adapter';
import { configureStore } from '../../stores';
import api from '../../utils/api';

import familyPointsTransferMock from './mocks/FamilyPointsTransfer.mock.json';
import FamilyPointsTransfer from './FamilyPointsTransfer';
import userData from '../Navigation/mocks/user.mock.json';

export default {
  title: 'Family Points Transfer',
};

export const DefaultFormViewCreateSuccess = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVff
    .onGet(
      '/loyalty/v2/activities?startDate=2023-01-01&endDate=2023-12-31&pageOffset=0&pageLimit=100&activitySubType=TRANSFER_FROM&activityType=TRANSFER&awardCategory=STANDARD',
    )
    .reply(200, {
      metaData: {
        count: 0,
      },
    });
  mockVff.onPost('/loyalty/v2/points/transfer').reply(200, {
    code: 200,
    title: 'Server success',
    detail: 'Success.',
    status: 200,
  });

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <FamilyPointsTransfer {...familyPointsTransferMock} />
    </Provider>
  );
};

DefaultFormViewCreateSuccess.storyName = 'Form view - Create Success';

export const DefaultFormViewCreateFail = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVff
    .onGet(
      '/loyalty/v2/activities?startDate=2023-01-01&endDate=2023-12-31&pageOffset=0&pageLimit=100&activitySubType=TRANSFER_FROM&activityType=TRANSFER&awardCategory=STANDARD',
    )
    .reply(200, {
      metaData: {
        count: 3,
      },
    });
  mockVff.onPost('/loyalty/v2/points/transfer').reply(400, {
    code: 37156,
    title: 'Member has reached the maximum number of allowed transfers',
    detail:
      "Transfer donor's already reached the maximum number of allowed transactions '4' (At least 5 transactions already performed)",
    status: 400,
    errorFields: [
      {
        field: 'enrolmentSource',
        message: 'must not contain | character',
      },
    ],
  });

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <FamilyPointsTransfer {...familyPointsTransferMock} />
    </Provider>
  );
};

DefaultFormViewCreateFail.storyName = 'Form view - Create Fail';

export const NoSufficientPoints = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVff
    .onGet(
      '/loyalty/v2/activities?startDate=2023-01-01&endDate=2023-12-31&pageOffset=0&pageLimit=100&activitySubType=TRANSFER_FROM&activityType=TRANSFER&awardCategory=STANDARD',
    )
    .reply(200, {
      metaData: {
        count: 4,
      },
    });

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
          account: {
            currentPointsBalance: 4999,
          },
        },
      })}
    >
      <FamilyPointsTransfer {...familyPointsTransferMock} />
    </Provider>
  );
};

NoSufficientPoints.storyName = 'Error view - No sufficient points';

export const TranscationLimitExhausted = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVff
    .onGet(
      '/loyalty/v2/activities?startDate=2023-01-01&endDate=2023-12-31&pageOffset=0&pageLimit=100&activitySubType=TRANSFER_FROM&activityType=TRANSFER&awardCategory=STANDARD',
    )
    .reply(200, {
      metaData: {
        count: 4,
      },
    });

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <FamilyPointsTransfer {...familyPointsTransferMock} />
    </Provider>
  );
};

TranscationLimitExhausted.storyName = 'Error view - Transcation Not Allowed';
