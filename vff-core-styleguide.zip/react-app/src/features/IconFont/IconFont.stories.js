import React from 'react';
import IconFont from '../../components/IconFont/IconFont';

export default {
  title: 'Icon fonts',
};

export const AllTypes = () => (
  <div style={{ maxWidth: 1110, margin: '0 auto', padding: '20px' }}>
    <IconFont name="info-with-circle" />
    <IconFont name="tick" ariaLabel="tick" />
    <IconFont name="cross" />
    <IconFont name="home" />
    <IconFont name="chevron-up-with-circle" />
    <IconFont name="chevron-down-with-circle" />
  </div>
);
