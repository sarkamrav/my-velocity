import React from 'react';
import { Provider } from 'react-redux';
import { configureStore } from '../../stores';
import HeroBannerCarousel from './HeroBannerCarousel';
import { getPropsDataFromJsObjectKeyArray } from '../../utils/common';

import heroBannerCarouselMock from './mocks/hero-banner-carousel_hp_carousel.mock.json';
import heroBannerFlyingVirginAustraliaMock from './mocks/hero-banner_flying_virgin_australia_flex-flying0_master.mock.json';
import heroBannerAmexMock from './mocks/hero-banner_cards_banking_insura_amex_amex-10-years-campaign_master.mock.json';

const simulatedWindowObject = {
  'hero-banner-carousel_hp_carousel': heroBannerCarouselMock,
  'hero-banner_cards_banking_insura_amex_amex-10-years-campaign_master': heroBannerAmexMock,
  'hero-banner_flying_virgin_australia_flex-flying0_master': heroBannerFlyingVirginAustraliaMock,
};

const props = getPropsDataFromJsObjectKeyArray(
  heroBannerCarouselMock,
  simulatedWindowObject,
  'heroBannerCarouselItems',
  'heroBanner',
);

export default {
  title: 'Hero Banner Carousel',
};

export const Default = () => (
  <Provider
    store={configureStore({
      user: {},
    })}
  >
    <HeroBannerCarousel {...props} />
  </Provider>
);
