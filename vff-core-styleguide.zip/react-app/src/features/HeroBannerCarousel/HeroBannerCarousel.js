import React, { useEffect, useRef, useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import Slider from 'react-slick';
import cx from 'classnames';

import Icon from '../../components/Icon/Icon';
import HeroBanner from '../HeroBanner/HeroBanner';
import analyticsSend from '../../utils/analytics';
import useMobileFullInnerHeight from '../../hooks/useMobileFullInnerHeight';
import useServerRendering from '../../hooks/useServerRendering';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME } from '../../utils/common';

import styles from './HeroBannerCarousel.css';

const HeroBannerCarousel = ({ speed, heroBannerCarouselItems, analyticsMetadata }) => {
  const sliderRef = useRef();
  const [currentSlideIndex, setCurrentSlideIndex] = useState(-1);
  const analyticsMetadataKey = analyticsMetadata['analytics-metadata'];
  const [analyticsData, setAnalyticsData] = useState(analyticsMetadataKey);
  const [autoplay, setAutoplay] = useState(false);
  const [infinite, setInfinite] = useState(false);
  const [nonMobileView, setNonMobileView] = useState(false);
  const [containerInlineStyle] = useMobileFullInnerHeight(56, true);
  const { rendered } = useServerRendering();

  useEffect(() => {
    const commonAnalyticsData = window.vffCoreWebsite[analyticsMetadataKey] || {};

    setAnalyticsData(commonAnalyticsData);
  }, [analyticsMetadataKey]);

  function isNonMobileView() {
    return window.matchMedia('(min-width: 768px)').matches;
  }

  useEffect(() => {
    setCurrentSlideIndex(0);
    sliderRef.current.slickGoTo(0);
    setAutoplay(true);
  }, []);

  const getAnalyticsDataByIndex = useCallback(
    (index) => {
      const banner = heroBannerCarouselItems[index].heroBanner;

      return {
        ...analyticsData,
        eventLocation: 'hero-banner-carousel',
        bannerType: _.get(banner, 'heroBannerType', ''),
        partner: _.get(banner, 'partner.name', ''),
        partnerCategory: _.get(banner, 'partner.category', ''),
        promoLabel: _.get(banner, 'promoLabelTitle', ''),
        eventCategory: 'banners',
        eventName: 'carousel-scroll',
        carouselPosition: index,
      };
    },
    [analyticsData, heroBannerCarouselItems],
  );

  const pauseAutoplay = useCallback(() => {
    setAutoplay(false);
    sliderRef.current.slickPause();
  }, []);

  function resumeAutoplay() {
    setAutoplay(true);
    sliderRef.current.slickNext();
    sliderRef.current.slickPlay();

    analyticsSend({
      ...getAnalyticsDataByIndex(currentSlideIndex),
      eventName: 'carousel-play',
    });
  }

  function pauseAutoplayWithAnalytics() {
    pauseAutoplay();

    analyticsSend({
      ...getAnalyticsDataByIndex(currentSlideIndex),
      eventName: 'carousel-pause',
    });
  }

  function goToSlide(index) {
    sliderRef.current.slickGoTo(index);

    analyticsSend({
      ...getAnalyticsDataByIndex(index),
      scrollType: 'slides',
    });
    pauseAutoplay();
  }

  const getNextIndex = useCallback(() => {
    const increaseCurrentIndexByOne = currentSlideIndex + 1;
    return increaseCurrentIndexByOne > heroBannerCarouselItems.length - 1 ? 0 : increaseCurrentIndexByOne;
  }, [currentSlideIndex, heroBannerCarouselItems.length]);

  const getPrevIndex = useCallback(() => {
    const reduceCurrentIndexByOne = currentSlideIndex - 1;
    return reduceCurrentIndexByOne < 0 ? heroBannerCarouselItems.length - 1 : reduceCurrentIndexByOne;
  }, [currentSlideIndex, heroBannerCarouselItems.length]);

  function prevSlide() {
    sliderRef.current.slickPrev();
    analyticsSend({
      ...getAnalyticsDataByIndex(getPrevIndex()),
      scrollType: 'chevron',
    });
    pauseAutoplay();
  }

  function nextSlide() {
    sliderRef.current.slickNext();
    analyticsSend({
      ...getAnalyticsDataByIndex(getNextIndex()),
      scrollType: 'chevron',
    });
    pauseAutoplay();
  }

  const handleBeforeChange = useCallback((currentIndex, nextIndex) => {
    setCurrentSlideIndex(nextIndex);
  }, []);

  const handleOnSwipe = useCallback(
    (swipeDirection) => {
      const index = swipeDirection === 'left' ? getNextIndex() : getPrevIndex();
      analyticsSend({
        ...getAnalyticsDataByIndex(index),
        scrollType: 'slides',
      });
      pauseAutoplay();
    },
    [getAnalyticsDataByIndex, getNextIndex, getPrevIndex, pauseAutoplay],
  );

  const recordCurrentViewPort = useCallback(() => {
    setNonMobileView(isNonMobileView());
  }, []);

  function handleWindowResize() {
    recordCurrentViewPort();
  }

  const debouncedHandleWindowResize = _.debounce(handleWindowResize, 200, { trailing: true });

  useEffect(() => {
    window.addEventListener('resize', debouncedHandleWindowResize, false);

    return () => {
      document.removeEventListener('resize', debouncedHandleWindowResize, false);
    };
  }, [debouncedHandleWindowResize]);

  useEffect(() => {
    recordCurrentViewPort();
    setInfinite(true);
  }, [recordCurrentViewPort]);

  return (
    <ErrorBoundary section={COMPONENT_NAME.heroBannerCarousel}>
      <div className={styles.container} style={containerInlineStyle}>
        <Slider
          ref={sliderRef}
          autoplay
          autoplaySpeed={speed * 1000}
          infinite={infinite}
          arrows={false}
          fade={nonMobileView}
          pauseOnHover={false}
          draggable={false}
          beforeChange={handleBeforeChange}
          onSwipe={handleOnSwipe}
        >
          {_.map(heroBannerCarouselItems, (carouselItem, i) => (
            <HeroBanner
              key={carouselItem.title}
              {...carouselItem.heroBanner}
              jsObjectKey={carouselItem.jsObjectKey}
              animateHighlightedText={false}
              onTermsModalOpen={pauseAutoplay}
              analyticsMetadataFromParent={{
                ...analyticsData,
                eventLocation: 'hero-banner-carousel',
                carouselPosition: i,
              }}
              isMobileFullInnerHeightRequired={false}
            />
          ))}
        </Slider>

        <div className={styles.tilesBar}>
          <ul className={styles.tilesList}>
            {_.map(heroBannerCarouselItems, (carouselItem, i) => {
              const active = currentSlideIndex === i;
              return (
                <li
                  key={carouselItem.title}
                  className={cx(styles.tilesListItem, {
                    [styles.tilesListItemActive]: active,
                  })}
                >
                  <button onClick={() => goToSlide(i)} className={styles.tileButton}>
                    <span className={styles.tileButtonText}>{carouselItem.title}</span>
                    <div
                      className={cx(styles.activeIndicator, {
                        [styles.timerTransactionDuration1Sec]: autoplay && speed === 1,
                        [styles.timerTransactionDuration2Sec]: autoplay && speed === 2,
                        [styles.timerTransactionDuration3Sec]: autoplay && speed === 3,
                        [styles.timerTransactionDuration4Sec]: autoplay && speed === 4,
                        [styles.timerTransactionDuration5Sec]: autoplay && speed === 5,
                        [styles.timerTransactionDuration6Sec]: autoplay && speed === 6,
                        [styles.timerTransactionDuration7Sec]: autoplay && speed === 7,
                        [styles.timerTransactionDuration8Sec]: autoplay && speed === 8,
                        [styles.timerTransactionDuration9Sec]: autoplay && speed === 9,
                        [styles.timerTransactionDuration10Sec]: autoplay && speed === 10,
                      })}
                    />
                  </button>
                </li>
              );
            })}
          </ul>
          <div className={styles.arrows}>
            <button className={styles.arrowButton} onClick={prevSlide}>
              <Icon name="Chevron" size="extra-small" className={styles.previousIcon} />
              {rendered && <span className="sr-only">Previous slide</span>}
            </button>
            <button className={styles.arrowButton} onClick={nextSlide}>
              <Icon name="Chevron" size="extra-small" />
              {rendered && <span className="sr-only">Next slide</span>}
            </button>

            {rendered && autoplay ? (
              <button className={styles.pauseButton} onClick={pauseAutoplayWithAnalytics}>
                <Icon name="Pause" size="extra-small" />
                <span className="sr-only">Pause carousel</span>
              </button>
            ) : null}

            {rendered && !autoplay ? (
              <button className={styles.playButton} onClick={resumeAutoplay}>
                <Icon name="Play" size="extra-small" />
                <span className="sr-only">Play carousel</span>
              </button>
            ) : null}
          </div>
        </div>
      </div>
    </ErrorBoundary>
  );
};

HeroBannerCarousel.propTypes = {
  speed: PropTypes.number,
  heroBannerCarouselItems: PropTypes.arrayOf(
    PropTypes.shape({
      heroBanner: PropTypes.shape({}),
    }),
  ),
  analyticsMetadata: PropTypes.shape({
    'analytics-metadata': PropTypes.string,
  }),
};

HeroBannerCarousel.defaultProps = {
  speed: 7,
  heroBannerCarouselItems: [],
  analyticsMetadata: {},
};

export default HeroBannerCarousel;
