import React from 'react';
import { Provider } from 'react-redux';
import MockAdapter from 'axios-mock-adapter';
import { configureStore } from '../../stores';
import api from '../../utils/api';

import familyPointsPoolingMock from './mocks/FamilyPointsPooling.mock.json';
import FamilyPointsPooling from './FamilyPointsPooling';
import userData from '../Navigation/mocks/user.mock.json';
import contributorViewOneActivePoolOneActiveContributor from './mocks/contributor-view--one-active-pool-one-active-contributor.mock';
import contributorViewPendingContributorInActive from './mocks/contributor-view--one-pool-pending-contributor-inactive.mock';
import contributorViewTwoMembershipsStoppedAndJoinedSamePool from './mocks/contributor-view--one-pool-two-memberships-stopped-and-joined-same-pool.mock';
import contributorViewTwoActivePoolsTwoMemberships from './mocks/contributor-view--two-active-pool-two-memberships-stopped-and-joined-different-pool.mock';
import beneficiaryViewActivePoolOneOrMoreContributor from './mocks/beneficiary-view--active-pool-and-one-or-more-contributor.mock';
import beneficiaryViewActivePoolAndOneContributorActiveOneFutureStartDateMock from './mocks/beneficiary-view--active-pool-and-one-contributor-active-one-future-startdate.mock';
import beneficiaryViewActivePoolAndOneActiveContributorAndOneEndingMock from './mocks/beneficiary-view--active-pool-and-one-active-contributor-and-one-ending.mock';
import beneficiaryViewOneActiveContributorOneEndingOneFutureStartDateMock from './mocks/beneficiary-view--one-active-contributor-one-ending-one-future-startdate.mock';
import beneficiaryViewOneContributorPendingInactive from './mocks/beneficiary-view--one-contributor-pending-inactive.mock';

const relationshipApiUri = '/loyalty/v2/family-pool';
export default {
  title: 'Family Points Pooling',
};

export const DefaultFormViewCreateSuccess = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVffV2.onGet(relationshipApiUri).reply(200, { data: [] });
  mockVffV2.onPost(relationshipApiUri).reply(200);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <FamilyPointsPooling {...familyPointsPoolingMock} />
    </Provider>
  );
};

DefaultFormViewCreateSuccess.storyName = 'Default - Form view - create success';

export const DefaultFormViewCreateFail = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVffV2.onGet(relationshipApiUri).reply(200, []);
  mockVffV2.onPost(relationshipApiUri).reply(400, {
    code: 4175,
    title: 'Not Found',
    detail: 'Invalid Request',
    status: 404,
    errorFields: [
      {
        message: 'No matching member with id 00005170541 found.',
        code: 37105,
      },
      {
        message:
          'Max Unique Beneficiary Count that a Contributor can be linked to in a calendar is not eligible for Pool Member 0000517043',
        code: 41264,
      },
      {
        message: 'The Contributor 0000517043 does not reside in the same post code with Beneficiary',
        code: 41261,
      },
      {
        message: 'The member 0000517043 has already an active pool.',
        code: 41259,
      },
    ],
  });

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <FamilyPointsPooling {...familyPointsPoolingMock} />
    </Provider>
  );
};

DefaultFormViewCreateFail.storyName = 'Default - Form view - create fail';

export const ContributorView = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVffV2.onPost(relationshipApiUri).reply(200);
  mockVffV2.onGet(relationshipApiUri).reply(200, contributorViewOneActivePoolOneActiveContributor);
  mockVffV2.onDelete(relationshipApiUri).reply(200);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <FamilyPointsPooling {...familyPointsPoolingMock} />
    </Provider>
  );
};

ContributorView.storyName = 'Contributor view - 1 active pool and 1 active contributor';

export const ContributorViewVariant2 = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVffV2.onPost(relationshipApiUri).reply(200);
  mockVffV2.onGet(relationshipApiUri).reply(200, contributorViewPendingContributorInActive);
  mockVffV2.onDelete(relationshipApiUri).reply(200);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <FamilyPointsPooling {...familyPointsPoolingMock} />
    </Provider>
  );
};

ContributorViewVariant2.storyName = 'Contributor view - 1 contributor ending';

export const ContributorViewVariant3 = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVffV2.onPost(relationshipApiUri).reply(200);
  mockVffV2.onGet(relationshipApiUri).reply(200, contributorViewTwoMembershipsStoppedAndJoinedSamePool);
  mockVffV2.onDelete(relationshipApiUri).reply(200);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <FamilyPointsPooling {...familyPointsPoolingMock} />
    </Provider>
  );
};

ContributorViewVariant3.storyName = 'Contributor view - 2 memberships (stopped and joined same pool)';

export const ContributorViewVariant4 = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVffV2.onPost(relationshipApiUri).reply(200);
  mockVffV2.onGet(relationshipApiUri).reply(200, contributorViewTwoActivePoolsTwoMemberships);
  mockVffV2.onDelete(relationshipApiUri).reply(200);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <FamilyPointsPooling {...familyPointsPoolingMock} />
    </Provider>
  );
};

ContributorViewVariant4.storyName =
  'Contributor view - 2 active pool 2 memberships (stopped and joined different pool)';

export const BeneficiaryView = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVffV2.onGet(relationshipApiUri).reply(200, beneficiaryViewActivePoolOneOrMoreContributor);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <FamilyPointsPooling {...familyPointsPoolingMock} />
    </Provider>
  );
};

BeneficiaryView.storyName = 'Beneficiary view - 1 or more contributor';

export const BeneficiaryViewVariant2 = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVffV2
    .onGet(relationshipApiUri)
    .reply(200, beneficiaryViewActivePoolAndOneContributorActiveOneFutureStartDateMock);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <FamilyPointsPooling {...familyPointsPoolingMock} />
    </Provider>
  );
};

BeneficiaryViewVariant2.storyName = 'Beneficiary view - 1 contributor active, 1 contributor future start date';

export const BeneficiaryViewVariant3 = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVffV2.onGet(relationshipApiUri).reply(200, beneficiaryViewActivePoolAndOneActiveContributorAndOneEndingMock);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <FamilyPointsPooling {...familyPointsPoolingMock} />
    </Provider>
  );
};

BeneficiaryViewVariant3.storyName = 'Beneficiary view - 1 contributor active, 1 contributor ending';

export const BeneficiaryViewVariant4 = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVffV2.onGet(relationshipApiUri).reply(200, beneficiaryViewOneActiveContributorOneEndingOneFutureStartDateMock);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <FamilyPointsPooling {...familyPointsPoolingMock} />
    </Provider>
  );
};

BeneficiaryViewVariant4.storyName =
  'Beneficiary view - 1 contributor active, 1 contributor ending, 1 contributor starting';

export const BeneficiaryViewVariant5 = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVffV2.onGet(relationshipApiUri).reply(200, beneficiaryViewOneContributorPendingInactive);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <FamilyPointsPooling {...familyPointsPoolingMock} />
    </Provider>
  );
};

BeneficiaryViewVariant5.storyName = 'Beneficiary view - 1 contributor pending inactive';
