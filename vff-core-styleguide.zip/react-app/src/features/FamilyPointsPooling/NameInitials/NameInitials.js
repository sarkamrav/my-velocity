import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';

import { getNameInitials, isEnableVipTier } from '../../../utils/common';

import styles from './NameInitials.css';

const NameInitials = ({ firstName, lastName, userInitial, tier, className }) => {
  const vipFlag = isEnableVipTier();

  return (
    (userInitial || (firstName && lastName)) && (
      <div
        className={cx(styles.container, className, {
          [styles.redTier]: tier === 'R',
          [styles.silverTier]: tier === 'S',
          [styles.goldTier]: tier === 'G',
          [styles.platinumTier]: tier === 'P',
          [styles.enableVipTier]: tier === 'V' && vipFlag,
          [styles.vipTier]: tier === 'V' && !vipFlag,
        })}
      >
        {userInitial || getNameInitials(firstName, lastName)}
      </div>
    )
  );
};

NameInitials.propTypes = {
  firstName: PropTypes.string,
  lastName: PropTypes.string,
  userInitial: PropTypes.string,
  className: PropTypes.string,
  tier: PropTypes.string,
};

NameInitials.defaultProps = {
  firstName: '',
  lastName: '',
  userInitial: '',
  className: '',
  tier: '',
};

export default NameInitials;
