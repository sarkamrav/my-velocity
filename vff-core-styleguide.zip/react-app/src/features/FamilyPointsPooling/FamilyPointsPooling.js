import React, { useState, useEffect, useRef, useCallback } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { DateTime } from 'luxon';

import PointsPoolingForm from './PointsPoolingForm/PointsPoolingForm';
import InformationAlert from '../../components/InformationAlert/InformationAlert';
import Loading from '../../components/Loading/Loading';
import api from '../../utils/api';
import BeneficiaryView from './BeneficiaryView/BeneficiaryView';
import ContributorView from './ContributorView/ContributorView';

import IconTiles from '../IconTiles/IconTiles';
import StripBanner from '../StripBanner/StripBanner';
import SingleFeaturedContent from '../SingleFeaturedContent/SingleFeaturedContent';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import * as userData from '../../stores/utilities';
import {
  COMPONENT_NAME,
  getCurrentUrl,
  getNavigationHeight,
  smoothScrollToElement,
  serverTimeZone,
} from '../../utils/common';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { getApiActionName, getApiError, sendToNewRelic } from '../../utils/newRelic';

import styles from './FamilyPointsPooling.css';

const relationshipApiUri = '/loyalty/v2/family-pool';
const FamilyPointsPooling = ({ user, noFamilyPooling, beneficiary, contributor, familyPoolingForm, errorMessages }) => {
  const hasLoggedIn = userData.getHasLoggedIn(user);
  const memberDataLoadError = userData.getMemberDataLoadError(user);
  const topSectionRef = useRef({});

  const [loading, setLoading] = useState(true);
  const [relationships, setRelationships] = useState([]);
  const [error, setError] = useState('');

  const [relationshipStopping, setRelationshipStopping] = useState(false);
  const [relationshipStopped, setRelationshipStopped] = useState(false);
  const [isStopConfirmationDialogVisible, setIsStopConfirmationDialogVisible] = useState(false);
  const [relationshipStopError, setRelationshipStopError] = useState('');

  const defaultErrorMessage = `Sorry we&apos;re having issues with our system. Please <a href="${getCurrentUrl()}" title="refresh the page">refresh the page</a> or try again later.`;

  const currentDate = DateTime.fromObject({}, serverTimeZone).startOf('day');

  useEffect(() => {
    if (relationshipStopped || relationshipStopError) {
      smoothScrollToElement(topSectionRef.current, getNavigationHeight());
    }
  }, [relationshipStopped, relationshipStopError]);

  const fetchRelationshipsData = useCallback(async () => {
    try {
      setLoading(true);
      const response = await api.vffV2Api.get(relationshipApiUri);
      if (response.data?.data && response.data.data?.length > 1) {
        // Contributor view - 2 ACTIVE pool, 2 memberships (stopped pooling and joined different pool or same pool)
        const contributorArr = _.map(
          response.data.data,
          (responseData) =>
            responseData.members[_.findIndex(responseData.members, (data) => data.memberType === 'CONTRIBUTOR')],
        );
        // find active beneficiary
        const activeContributorIdx = _.findIndex(
          contributorArr,
          (data) => DateTime.fromISO(data.endDate, serverTimeZone) > currentDate,
        );
        const contributorsArray = [];
        if (activeContributorIdx !== -1) {
          const activeBeneficiary = _.find(response.data.data[activeContributorIdx].members, {
            memberType: 'BENEFICIARY',
          });
          const activeContributor = _.find(response.data.data[activeContributorIdx].members, {
            memberType: 'CONTRIBUTOR',
          });
          contributorsArray.push(activeBeneficiary, activeContributor);
        }
        // find beneficiary where the contributor stopped pooling - pending inactive
        const inActiveContributorIdx = _.findIndex(contributorArr, (data) =>
          DateTime.fromISO(data.endDate, serverTimeZone).hasSame(currentDate, 'day'),
        );
        if (inActiveContributorIdx !== -1) {
          const inactiveContributor = _.find(response.data.data[inActiveContributorIdx].members, {
            memberType: 'CONTRIBUTOR',
          });
          const inactiveBeneficiary = _.find(response.data.data[inActiveContributorIdx].members, {
            memberType: 'BENEFICIARY',
          });
          const newInactiveContributor = {
            ...inactiveContributor,
            beneficiary: {
              memberInformation: {
                givenName: inactiveBeneficiary.memberInformation.givenName,
                surname: inactiveBeneficiary.memberInformation.surname,
              },
            },
          };
          contributorsArray.push(newInactiveContributor);
        }
        setRelationships(contributorsArray);
      } else {
        setRelationships(response.data.data ? response.data.data[0]?.members : []);
      }
      setLoading(false);
    } catch (e) {
      setLoading(false);
      setError(defaultErrorMessage);

      sendToNewRelic(
        getApiActionName(api.vffV2Api.defaults.baseURL, relationshipApiUri),
        getApiError(COMPONENT_NAME.familyPointsPooling, e),
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [defaultErrorMessage]);

  useEffect(() => {
    if (hasLoggedIn) {
      fetchRelationshipsData();
    }
  }, [fetchRelationshipsData, hasLoggedIn]);

  useEffect(() => {
    if (relationshipStopped) {
      fetchRelationshipsData();
    }
  }, [fetchRelationshipsData, relationshipStopped]);

  const stopPooling = useCallback(async () => {
    try {
      setRelationshipStopping(true);
      setRelationshipStopped(false);
      setRelationshipStopError('');
      await api.vffV2Api.delete(relationshipApiUri);

      setIsStopConfirmationDialogVisible(false);
      setRelationshipStopping(false);
      setRelationshipStopped(true);
    } catch (e) {
      setRelationshipStopping(false);
      setIsStopConfirmationDialogVisible(false);
      setRelationshipStopError(defaultErrorMessage);

      sendToNewRelic(
        getApiActionName(api.vffV2Api.defaults.baseURL, relationshipApiUri),
        getApiError(COMPONENT_NAME.familyPointsPooling, e),
      );
    }
  }, [defaultErrorMessage]);

  const closeStopConfirmationDialog = useCallback(() => {
    setIsStopConfirmationDialogVisible(false);
  }, []);

  const openStopConfirmationDialog = useCallback(() => {
    setIsStopConfirmationDialogVisible(true);
  }, []);

  const tierLevel = userData.getTierLevel(user);
  const firstName = userData.getFirstName(user);
  const lastName = userData.getLastName(user);
  const userInitial = userData.getUserInitial(user);
  const dateOfBirth = userData.getDateOfBirth(user);
  const membershipId = userData.getLoyaltyMembershipID(user);

  function sortRelationshipsToCategories(accumulator, relationship) {
    let pendingInActive;
    let active;
    let inActive;
    let pendingActive;

    const poolingStartDate = DateTime.fromISO(relationship.startDate, serverTimeZone);
    const poolingEndDate = DateTime.fromISO(relationship.endDate, serverTimeZone);

    if (poolingStartDate <= currentDate && poolingEndDate.hasSame(currentDate, 'day')) {
      // Pending InActive
      pendingInActive = relationship;
    } else if (poolingStartDate <= currentDate && currentDate < poolingEndDate) {
      // Active
      active = relationship;
    } else if (poolingStartDate <= currentDate && poolingEndDate < currentDate) {
      // InActive
      inActive = relationship;
    } else if (currentDate < poolingStartDate && currentDate < poolingEndDate) {
      // Pending Active
      pendingActive = relationship;
    }

    return {
      pendingInActive: pendingInActive
        ? [...(accumulator.pendingInActive || []), pendingInActive]
        : accumulator.pendingInActive || [],
      active: active ? [...(accumulator.active || []), active] : accumulator.active || [],
      inActive: inActive ? [...(accumulator.inActive || []), inActive] : accumulator.inActive || [],
      pendingActive: pendingActive
        ? [...(accumulator.pendingActive || []), pendingActive]
        : accumulator.pendingActive || [],
    };
  }

  // I am contributor to
  const myBeneficiaries = _(relationships)
    .filter((relationship) => _.isEqual(_(relationship).get('memberType'), 'BENEFICIARY'))
    .reduce(sortRelationshipsToCategories, {});

  // I am beneficiary for
  const myContributors = _(relationships)
    .filter((relationship) => _.isEqual(_(relationship).get('memberType'), 'CONTRIBUTOR'))
    .reduce(sortRelationshipsToCategories, {});

  const currentMemberData = _.filter(relationships, (relation) => relation.relatedMembershipId === membershipId);
  const currentBeneficiary = _.filter(relationships, (relation) => relation.memberType === 'BENEFICIARY');

  function getMyRelationshipStatus() {
    if (
      currentMemberData[0]?.memberType === 'BENEFICIARY' &&
      (myContributors.active.length || myContributors.pendingActive.length)
    )
      return 'BeneficiaryView';
    if (
      currentMemberData[0]?.memberType === 'CONTRIBUTOR' &&
      (myContributors.active.length || myContributors.pendingActive.length) &&
      myBeneficiaries.active.length
    )
      return 'ContributorView';
    return 'FormView';
  }

  const myStatusView = getMyRelationshipStatus();
  function showRelationshipNotification(relationshipsForNotification, content) {
    return _.map(relationshipsForNotification || [], (relationship) => {
      let name = '';
      // name should be beneficiary name when current member is a contributor
      if (relationship?.memberType === 'CONTRIBUTOR' && currentMemberData[0].memberType !== 'BENEFICIARY') {
        name =
          `${_.get(relationship.beneficiary ? relationship.beneficiary : currentBeneficiary[0], 'memberInformation.givenName') || ''} ${_.get(relationship.beneficiary ? relationship.beneficiary : currentBeneficiary[0], 'memberInformation.surname') || ''}`.trim();
      } else {
        name =
          `${_.get(relationship, 'memberInformation.givenName') || ''} ${_.get(relationship, 'memberInformation.surname') || ''}`.trim();
      }
      return (
        <InformationAlert
          key={relationship.relatedMembershipId}
          title=""
          className={styles.alertContainer}
          content={_.replace(
            content,
            '{name}',
            `<span class="font-weight font-weight--bold text-transform text-transform--capitalize">${_.toLower(name)}</span>`,
          )}
          status="info"
        />
      );
    });
  }

  function showAemConfiguredContent(contentArray) {
    return _.map(contentArray, (content) => {
      const componentProps = window.vffCoreWebsite[content.jsObjectKey] || {};

      switch (componentProps.componentKey) {
        case COMPONENT_NAME.iconTiles:
          return (
            <IconTiles key={content.jsObjectKey} containerClassName={styles.iconTilesContainer} {...componentProps} />
          );

        case COMPONENT_NAME.stripBanner:
          return <StripBanner key={content.jsObjectKey} className={styles.stripBannerContainer} {...componentProps} />;

        case COMPONENT_NAME.singleFeaturedContent:
          return (
            <SingleFeaturedContent
              key={content.jsObjectKey}
              className={styles.componentContainer}
              {...componentProps}
            />
          );

        case COMPONENT_NAME.richTextContent:
          return (
            <RichTextContent key={content.jsObjectKey} className={styles.componentContainer} {...componentProps} />
          );

        default:
          return null;
      }
    });
  }

  const isContentReadyForDisplay = !error && !loading;

  return (
    <ErrorBoundary section={COMPONENT_NAME.familyPointsPooling}>
      <div className={styles.container}>
        {!hasLoggedIn && memberDataLoadError && (
          <InformationAlert
            title=""
            content="Sorry, we're having issues with our system."
            className={styles.errorContainer}
          />
        )}

        {!hasLoggedIn && !memberDataLoadError && (
          <div className={styles.loadingContainer}>
            <Loading />
          </div>
        )}

        {hasLoggedIn && (
          <>
            <section ref={topSectionRef} className={styles.topSection}>
              {!!error && <InformationAlert title="" content={error} className={styles.errorContainer} />}

              {!!relationshipStopError && (
                <InformationAlert title="" content={relationshipStopError} className={styles.errorContainer} />
              )}

              {isContentReadyForDisplay && relationships?.length && (
                <>
                  {showRelationshipNotification(
                    [...(myBeneficiaries.pendingInActive || []), ...(myContributors.pendingInActive || [])],
                    currentMemberData[0]?.memberType === 'BENEFICIARY'
                      ? '<p>Pending removal of {name} from your pool. Changes will take effect from 12:01 AM (AEST) tomorrow.</p>'
                      : '<p>You have successfully stopped pooling Points with {name}. Changes will take effect from 12:01 AM (AEST) tomorrow.</p>',
                  )}
                  {showRelationshipNotification(
                    [...(myBeneficiaries.pendingActive || []), ...myContributors.pendingActive] || [],
                    currentMemberData[0]?.memberType === 'BENEFICIARY'
                      ? '<p>Family pool relationship with {name} is pending. Changes will take effect from 12:01 AM (AEST) tomorrow.</p>'
                      : '<p>Family pooling to beneficiary is pending. Changes will take effect from 12:01 AM (AEST) tomorrow.</p>',
                  )}
                  {myStatusView === 'ContributorView' && showAemConfiguredContent(contributor.topSection)}

                  {myStatusView === 'BeneficiaryView' && showAemConfiguredContent(beneficiary.topSection)}

                  {myStatusView === 'FormView' && showAemConfiguredContent(noFamilyPooling.topSection)}
                </>
              )}
            </section>

            {isContentReadyForDisplay && (
              <>
                <section className={styles.formSection}>
                  {myStatusView === 'ContributorView' && (
                    <ContributorView
                      firstName={firstName}
                      lastName={lastName}
                      userInitial={userInitial}
                      tierLevel={tierLevel}
                      stopConfirmationAuthorableContent={contributor.popupMessage}
                      myBeneficiaries={myBeneficiaries}
                      relationshipStopping={relationshipStopping}
                      onStopPoolingClicked={stopPooling}
                      isStopConfirmationDialogVisible={isStopConfirmationDialogVisible}
                      closeStopConfirmationDialog={closeStopConfirmationDialog}
                      openStopConfirmationDialog={openStopConfirmationDialog}
                      currentMember={myContributors.active[0] || myContributors.pendingActive[0]}
                      membershipId={membershipId}
                    />
                  )}

                  {myStatusView === 'BeneficiaryView' && (
                    <BeneficiaryView
                      firstName={firstName}
                      lastName={lastName}
                      userInitial={userInitial}
                      tierLevel={tierLevel}
                      dateOfBirth={dateOfBirth}
                      myContributors={myContributors}
                      removeOrAddAuthorableContent={beneficiary.popupMessage}
                    />
                  )}

                  {myStatusView === 'FormView' && (
                    <PointsPoolingForm
                      authorableContent={familyPoolingForm}
                      membershipId={membershipId}
                      errorMessages={errorMessages}
                    />
                  )}
                </section>

                <section className={styles.bottomSection}>
                  {myStatusView === 'ContributorView' && showAemConfiguredContent(contributor.bottomSection)}

                  {myStatusView === 'BeneficiaryView' && showAemConfiguredContent(beneficiary.bottomSection)}

                  {myStatusView === 'FormView' && showAemConfiguredContent(noFamilyPooling.bottomSection)}
                </section>
              </>
            )}

            {!error && loading && (
              <div className={styles.loadingContainer}>
                <Loading />
              </div>
            )}
          </>
        )}
      </div>
    </ErrorBoundary>
  );
};

FamilyPointsPooling.propTypes = {
  user: PropTypes.shape({}),
  noFamilyPooling: PropTypes.shape({
    topSection: PropTypes.arrayOf(PropTypes.shape({})),
    bottomSection: PropTypes.arrayOf(PropTypes.shape({})),
  }),
  beneficiary: PropTypes.shape({
    topSection: PropTypes.arrayOf(PropTypes.shape({})),
    bottomSection: PropTypes.arrayOf(PropTypes.shape({})),
    popupMessage: PropTypes.shape({}),
  }),
  contributor: PropTypes.shape({
    topSection: PropTypes.arrayOf(PropTypes.shape({})),
    bottomSection: PropTypes.arrayOf(PropTypes.shape({})),
    popupMessage: PropTypes.shape({}),
  }),
  familyPoolingForm: PropTypes.shape({}),
  analyticsMetadata: PropTypes.shape({}),
  errorMessages: PropTypes.shape(PropTypes.arrayOf([])),
};

FamilyPointsPooling.defaultProps = {
  user: null,
  noFamilyPooling: {},
  beneficiary: {},
  contributor: {},
  familyPoolingForm: {},
  analyticsMetadata: {},
  errorMessages: {},
};

export default connect((state) => ({
  user: state.user,
}))(FamilyPointsPooling);
