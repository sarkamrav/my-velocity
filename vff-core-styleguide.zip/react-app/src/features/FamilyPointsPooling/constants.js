export const POINTS_POOLING_FORM = {
  STEP_1: 'step_1',
  STEP_2: 'step_2',
  STEP_3: 'step_3',
};

export const POOLING_TYPE = {
  POINTS_ONLY: 'CHILD_POINTS_ONLY',
  POINTS_AND_STATUS: 'CHILD_POINTS_AND_SC',
};

export const POOLING_TYPE_CONSTANTS = {
  POINTS_ONLY: 'AP',
  STATUS_CREDITS: 'SC',
  POINTS_AND_STATUS: ['AP', 'SC'],
};

export const poolingTypeOptions = [
  {
    label: 'Points Only',
    value: POOLING_TYPE.POINTS_ONLY,
  },
  {
    label: 'Points & Status Credits',
    value: POOLING_TYPE.POINTS_AND_STATUS,
  },
];

export const poolingRelationshipOptions = [
  {
    label: 'Husband',
    value: 'Husband',
  },
  {
    label: 'Wife',
    value: 'Wife',
  },
  {
    label: 'Domestic Partner',
    value: 'Domestic Partner',
  },
  {
    label: 'De Facto',
    value: 'De Facto',
  },
  {
    label: 'Parent',
    value: 'Parent',
  },
  {
    label: 'Child',
    value: 'Child',
  },
  {
    label: 'Brother',
    value: 'Brother',
  },
  {
    label: 'Sister',
    value: 'Sister',
  },
  {
    label: 'Grandparent',
    value: 'Grandparent',
  },
  {
    label: 'Grandchild',
    value: 'Grandchild',
  },
  {
    label: 'Son-in-law',
    value: 'Son-in-law',
  },
  {
    label: 'Daughter-in-law',
    value: 'Daughter-in-law',
  },
  {
    label: 'Brother-in-law',
    value: 'Brother-in-law',
  },
  {
    label: 'Sister-in-law',
    value: 'Sister-in-law',
  },
  {
    label: 'Father-in-law',
    value: 'Father-in-law',
  },
  {
    label: 'Mother-in-law',
    value: 'Mother-in-law',
  },
  {
    label: 'Uncle',
    value: 'Uncle',
  },
  {
    label: 'Aunt',
    value: 'Aunt',
  },
  {
    label: 'Nephew',
    value: 'Nephew',
  },
  {
    label: 'Niece',
    value: 'Niece',
  },
  {
    label: 'First Cousin',
    value: 'First Cousin',
  },
];
