import _ from 'lodash';
import { POOLING_TYPE_CONSTANTS } from './constants';

export function getPoolingTypeLabel(poolingType) {
  let poolingTypeLabel = '';

  if (poolingType) {
    poolingTypeLabel = _.includes(poolingType, POOLING_TYPE_CONSTANTS.STATUS_CREDITS)
      ? 'Velocity Points and Status Credits'
      : 'Velocity Points';
  }

  return poolingTypeLabel;
}

export function getCommonAuthorableContentReplacements({ poolingType = '', firstName = '', lastName = '' } = {}) {
  return {
    poolingType: getPoolingTypeLabel(poolingType),
    firstName: `<span class="font-weight font-weight--bold text-transform text-transform--capitalize">${_.toLower(firstName)}</span>`,
    lastName: `<span class="font-weight font-weight--bold text-transform text-transform--capitalize">${_.toLower(lastName)}</span>`,
  };
}
