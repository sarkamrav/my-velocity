import { DateTime } from 'luxon';
import userData from '../../Navigation/mocks/user.mock.json';
import { serverTimeZone } from '../../../utils/common';

const today = DateTime.fromISO(DateTime.now(), serverTimeZone).toFormat('yyyy-MM-dd');

const mock = {
  data: [
    {
      members: [
        {
          relatedMembershipId: '0000509913',
          memberInformation: {
            givenName: 'Tom',
            surname: 'red-contr A',
            title: 'MR',
            gender: 'MALE',
            dateOfBirth: '2010-10-09',
          },
          familyRelationship: 'Parent',
          relationshipStatus: 'ACTIVE',
          memberType: 'CONTRIBUTOR',
          startDate: '2022-06-17',
          endDate: today,
          currencyCodes: ['AP'],
        },
        {
          relatedMembershipId: userData.member.loyaltyMembershipID,
          memberInformation: {
            givenName: 'Tom',
            surname: 'pool A',
            title: 'MR',
            gender: 'MALE',
            dateOfBirth: '2010-10-09',
          },
          relationshipStatus: 'ACTIVE',
          memberType: 'BENEFICIARY',
          startDate: '2022-06-17',
          endDate: '2022-08-11',
        },
      ],
    },
  ],
};

export default mock;
