import { DateTime } from 'luxon';

import userData from '../../Navigation/mocks/user.mock.json';

const lessThan18YearsOld = DateTime.now().minus({ years: 10 }).toFormat('yyyy-MM-dd');

const mock = {
  data: [
    {
      members: [
        {
          relatedMembershipId: '0000516970',
          memberInformation: {
            givenName: 'Fiona',
            surname: 'Test cont AB',
            title: 'MR',
            gender: 'MALE',
            dateOfBirth: lessThan18YearsOld,
          },
          familyRelationship: 'Sister',
          relationshipStatus: 'ACTIVE',
          memberType: 'CONTRIBUTOR',
          startDate: '2022-06-13',
          endDate: '2100-01-01',
          currencyCodes: ['AP'],
        },
        {
          relatedMembershipId: '0000517043',
          memberInformation: {
            givenName: 'Kate',
            surname: 'Test contb AC',
            title: 'MR',
            gender: 'MALE',
            dateOfBirth: lessThan18YearsOld,
          },
          familyRelationship: 'Sister',
          relationshipStatus: 'ACTIVE',
          memberType: 'CONTRIBUTOR',
          startDate: '2022-06-13',
          endDate: '2122-06-20',
          currencyCodes: ['AP', 'SC'],
        },
        {
          relatedMembershipId: userData.member.loyaltyMembershipID,
          memberInformation: {
            givenName: 'Heidi',
            surname: 'Test benf K',
            title: 'MR',
            gender: 'MALE',
            dateOfBirth: '2000-10-09',
          },
          relationshipStatus: 'ACTIVE',
          memberType: 'BENEFICIARY',
          startDate: '2022-06-13',
          endDate: '2100-01-01',
        },
      ],
    },
  ],
};

export default mock;
