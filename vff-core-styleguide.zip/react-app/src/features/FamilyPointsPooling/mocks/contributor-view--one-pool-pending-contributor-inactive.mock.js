import { DateTime } from 'luxon';
import userData from '../../Navigation/mocks/user.mock.json';

const today = DateTime.now().toFormat('yyyy-MM-dd');

const mock = {
  data: [
    {
      members: [
        {
          relatedMembershipId: '0000516981',
          memberInformation: {
            givenName: 'Kate',
            surname: 'Test benf AB',
            title: 'MR',
            gender: 'MALE',
            dateOfBirth: '2000-10-09',
          },
          relationshipStatus: 'ACTIVE',
          memberType: 'BENEFICIARY',
          startDate: '2022-06-13',
          endDate: '2100-01-01',
        },
        {
          relatedMembershipId: userData.member.loyaltyMembershipID,
          memberInformation: {
            givenName: 'Fiona',
            surname: 'Test cont AB',
            title: 'MR',
            gender: 'MALE',
            dateOfBirth: '2000-10-09',
          },
          familyRelationship: 'Grandchild',
          relationshipStatus: 'ACTIVE',
          memberType: 'CONTRIBUTOR',
          startDate: today,
          endDate: today,
          currencyCodes: ['AP', 'SC'],
        },
      ],
    },
  ],
};

export default mock;
