import { DateTime } from 'luxon';
import userData from '../../Navigation/mocks/user.mock.json';

const today = DateTime.now().toFormat('yyyy-MM-dd');
const tomorrow = DateTime.now().plus({ days: 1 }).toFormat('yyyy-MM-dd');
const lessThan18YearsOld = DateTime.now().minus({ years: 10 }).toFormat('yyyy-MM-dd');

const mock = {
  data: [
    {
      members: [
        {
          relatedMembershipId: '0000516970',
          memberInformation: {
            givenName: 'Fiona',
            surname: 'Test cont AB',
            title: 'MS',
            gender: 'FEMALE',
            dateOfBirth: lessThan18YearsOld,
          },
          familyRelationship: 'Sister',
          relationshipStatus: 'ACTIVE',
          memberType: 'CONTRIBUTOR',
          startDate: '2022-06-11',
          endDate: '2100-01-01',
          currencyCodes: ['AP'],
        },
        {
          relatedMembershipId: '0000517043',
          memberInformation: {
            givenName: 'Kate',
            surname: 'Test contb AC',
            title: 'MS',
            gender: 'FEMALE',
            dateOfBirth: '2010-10-09',
          },
          familyRelationship: 'Sister',
          relationshipStatus: 'ACTIVE',
          memberType: 'CONTRIBUTOR',
          startDate: today,
          endDate: today,
          currencyCodes: ['AP', 'SC'],
        },
        {
          relatedMembershipId: '0000516150',
          memberInformation: {
            givenName: 'Cindy',
            surname: 'Test cont AD',
            title: 'MS',
            gender: 'FEMALE',
            dateOfBirth: '2000-10-09',
          },
          familyRelationship: 'Wife',
          relationshipStatus: 'ACTIVE',
          memberType: 'CONTRIBUTOR',
          startDate: tomorrow,
          endDate: '2100-01-01',
          currencyCodes: ['AP'],
        },
        {
          relatedMembershipId: userData.member.loyaltyMembershipID,
          memberInformation: {
            givenName: 'Jason',
            surname: 'Test benf K',
            title: 'MR',
            gender: 'MALE',
            dateOfBirth: '1990-10-09',
          },
          relationshipStatus: 'ACTIVE',
          memberType: 'BENEFICIARY',
          startDate: today,
          endDate: '2100-01-01',
        },
      ],
    },
  ],
};

export default mock;
