import React, { useState } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import qs from 'qs';
import cx from 'classnames';
import { DateTime } from 'luxon';

import Input from '../../components/Form/Input/Input';
import Button from '../../components/Button/Button';
import api from '../../utils/api';
import { stateOptions } from '../JoinPage/referenceData';
import Select from '../../components/Form/Select/Select';
import ConsentCheckbox from '../../components/Form/ConsentCheckbox/ConsentCheckbox';
import InformationAlert from '../../components/InformationAlert/InformationAlert';
import Icon from '../../components/Icon/Icon';
import { COUNTRY_CODE } from '../JoinPage/constants';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import analyticsSend from '../../utils/analytics';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME } from '../../utils/common';
import { getApiActionName, getApiError, sendToNewRelic } from '../../utils/newRelic';

import styles from './CancellationForm.css';

const CancellationForm = ({
  title,
  bookingReferenceTooltip,
  errorMessages,
  successMessage,
  privacyLabel,
  termsLabel,
}) => {
  const [error, setError] = useState();
  const [eligible, setEligibility] = useState(false);
  const [lastName, setLastName] = useState('');
  const [recordLocator, setRecordLocator] = useState('');
  const [firstName, setFirstName] = useState('');
  const [displayDate, setDisplayDate] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [address, setAddress] = useState('');
  const [suburb, setSuburb] = useState('');
  const [postcode, setPostcode] = useState('');
  const [state, setState] = useState(null);
  const [country, setCountry] = useState(null);
  const [privacyConsent, setPrivacyConsent] = useState(false);
  const [termsConsent, setTermsConsent] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const commonAnalyticsData = {
    eventCategory: 'flight-details',
  };

  async function handleSubmit(e) {
    e.preventDefault();

    setError(null);
    setSubmitting(true);

    if (!eligible) {
      const cancellationCheckApiUri = '/trip/v1/cancellation-check';

      try {
        analyticsSend({
          ...commonAnalyticsData,
          eventName: 'cancel-booking-check-submit',
          pnr: recordLocator,
        });

        const response = await api.vaCloudApi.get(
          `${cancellationCheckApiUri}${qs.stringify(
            {
              lastName: _.toUpper(lastName),
              recordLocator: _.toUpper(recordLocator),
            },
            { addQueryPrefix: true },
          )}`,
        );

        if (response.data.eligible) {
          setFirstName(response.data.firstName);
          setDisplayDate(DateTime.fromISO(response.data.displayDate).toFormat('dd/MM/yyyy'));
          setEligibility(true);

          analyticsSend({
            ...commonAnalyticsData,
            eventName: 'cancel-booking-check-submit-success',
            pnr: recordLocator,
          });
        } else {
          const errorMessage = _.get(
            _.find(errorMessages.apiErrorMessages, { value: response.data.tag }),
            'title',
            response.data.message,
          );
          setError(errorMessage);
          setEligibility(false);

          analyticsSend({
            ...commonAnalyticsData,
            eventName: 'cancel-booking-check-submit-fail',
            pnr: recordLocator,
            errorMessage: response.data.tag,
          });
        }
      } catch (err) {
        const errorMessage = _.get(err, 'response.data.detail', 'Something went wrong.');
        setError(errorMessage);
        setEligibility(false);

        analyticsSend({
          ...commonAnalyticsData,
          eventName: 'cancel-booking-check-submit-fail',
          pnr: recordLocator,
          errorMessage,
        });

        sendToNewRelic(
          getApiActionName(api.vaCloudApi.defaults.baseURL, cancellationCheckApiUri),
          getApiError(COMPONENT_NAME.cancellationForm, err),
        );
      }
    } else {
      // User is eligible for cancellation
      analyticsSend({
        ...commonAnalyticsData,
        eventName: 'cancel-booking-submit',
        pnr: recordLocator,
      });

      const cancellationApiUri = '/trip/v1/cancellation';

      try {
        await api.vaCloudApi.post(
          cancellationApiUri,
          qs.stringify({
            recordLocator: _.toUpper(recordLocator),
            firstName: _.toUpper(firstName),
            lastName: _.toUpper(lastName),
            privacyPolicyConsent: privacyConsent,
            travelBankRefundConsent: termsConsent,
            addressLine1: address,
            city: suburb,
            postcode,
            state: state.value,
            dateOfBirth: DateTime.fromFormat(dateOfBirth, 'dd/MM/yyyy').toFormat('yyyy-MM-dd'),
            country: country.value,
          }),
          {
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
            },
          },
        );

        setSuccess(true);
      } catch (err) {
        const errorMessage = _.get(err, 'response.data.detail', 'Something went wrong.');
        setError(errorMessage);
        sendToNewRelic(
          getApiActionName(api.vaCloudApi.defaults.baseURL, cancellationApiUri),
          getApiError(COMPONENT_NAME.cancellationForm, err),
        );
      }
    }

    setSubmitting(false);
  }

  const validEligibility = recordLocator && recordLocator.length === 6 && lastName;
  const validForm =
    validEligibility &&
    firstName &&
    displayDate &&
    address &&
    postcode &&
    suburb &&
    state &&
    country &&
    privacyConsent &&
    termsConsent;
  const submitDisabled = submitting || !(eligible ? validForm : validEligibility);

  return (
    <ErrorBoundary section={COMPONENT_NAME.cancellationForm}>
      <div className={styles.container}>
        {title ? (
          <h2
            className={cx(
              styles.title,
              'heading heading--2 font-weight font-weight--extra-bold color color--purple text-align text-align--center',
            )}
          >
            Your booking details
          </h2>
        ) : null}

        {success ? (
          <div className={styles.successContainer}>
            <Icon name="TickCircleOpen" className={styles.icon} />
            <div className={cx(styles.successTitle, 'heading heading--3 font-weight font-weight--bold')}>
              {successMessage.title}
            </div>
            {successMessage.description ? (
              <RichTextContent className={styles.successDescription} content={successMessage.description} />
            ) : null}
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            {error ? (
              <InformationAlert title="" status="error" content={error} className={styles.errorContainer} />
            ) : null}
            <div className={styles.formRow}>
              <Input
                label="Booking reference"
                tooltip={bookingReferenceTooltip ? { text: bookingReferenceTooltip } : null}
                disabled={eligible}
                value={recordLocator}
                onChange={(e) => setRecordLocator(e.target.value)}
                maxLength="6"
                placeholder="Enter your booking reference"
              />
              <Input
                label="Last name"
                disabled={eligible}
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                placeholder="Enter your last name"
                autoComplete="family-name"
              />
            </div>

            {eligible ? (
              <>
                <div className={styles.formRow}>
                  <Input label="Flight date" disabled value={displayDate} />
                  <Input label="First name" disabled value={firstName} />
                </div>

                <div className={styles.formRow}>
                  <Input
                    name="dateOfBirth"
                    label="Date of birth"
                    mask="99/99/9999"
                    placeholder="DD/MM/YYYY"
                    value={dateOfBirth}
                    onChange={(e) => setDateOfBirth(e.target.value)}
                    autoComplete="bday"
                    inputMode="numeric"
                    pattern="\d{2}/\d{2}/\d{4}"
                  />
                </div>

                <div className={styles.formRow}>
                  <Select
                    name="country"
                    label="Country"
                    items={[
                      {
                        bottomSeparator: true,
                        options: [
                          {
                            label: 'Australia',
                            value: COUNTRY_CODE.AUSTRALIA,
                          },
                          {
                            label: 'New Zealand',
                            value: COUNTRY_CODE.NEW_ZEALAND,
                          },
                        ],
                      },
                      {
                        options: [
                          {
                            label: 'Austria',
                            value: 'AT',
                          },
                          {
                            label: 'Belgium',
                            value: 'BE',
                          },
                          {
                            label: 'Canada',
                            value: 'CA',
                          },
                          {
                            label: 'China',
                            value: 'CN',
                          },
                          {
                            label: 'Denmark',
                            value: 'DK',
                          },
                          {
                            label: 'Fiji',
                            value: 'FJ',
                          },
                          {
                            label: 'Finland',
                            value: 'FI',
                          },
                          {
                            label: 'France',
                            value: 'FR',
                          },
                          {
                            label: 'Germany',
                            value: 'DE',
                          },
                          {
                            label: 'Greece',
                            value: 'GR',
                          },
                          {
                            label: 'Hong Kong',
                            value: 'HK',
                          },
                          {
                            label: 'Indonesia',
                            value: 'ID',
                          },
                          {
                            label: 'Ireland',
                            value: 'IE',
                          },
                          {
                            label: 'Italy',
                            value: 'IT',
                          },
                          {
                            label: 'Japan',
                            value: 'JP',
                          },
                          {
                            label: 'Korea',
                            value: 'KR',
                          },
                          {
                            label: 'Lebanon',
                            value: 'LB',
                          },
                          {
                            label: 'Malaysia',
                            value: 'MY',
                          },
                          {
                            label: 'Netherlands',
                            value: 'NL',
                          },
                          {
                            label: 'Norway',
                            value: 'NO',
                          },
                          {
                            label: 'Papua New Guinea',
                            value: 'PG',
                          },
                          {
                            label: 'Saudi Arabia',
                            value: 'SA',
                          },
                          {
                            label: 'Serbia',
                            value: 'RS',
                          },
                          {
                            label: 'Singapore',
                            value: 'SG',
                          },
                          {
                            label: 'South Africa',
                            value: 'ZA',
                          },
                          {
                            label: 'Spain',
                            value: 'ES',
                          },
                          {
                            label: 'Sweden',
                            value: 'SE',
                          },
                          {
                            label: 'Switzerland',
                            value: 'CH',
                          },
                          {
                            label: 'Thailand',
                            value: 'TH',
                          },
                          {
                            label: 'Tonga (TP not available)',
                            value: 'TO',
                          },
                          {
                            label: 'United Arab Emirates',
                            value: 'AE',
                          },
                          {
                            label: 'United Kingdom',
                            value: 'GB',
                          },
                          {
                            label: 'United States of America',
                            value: 'US',
                          },
                          {
                            label: 'Western Samoa',
                            value: 'WS',
                          },
                        ],
                      },
                    ]}
                    selectedItem={country}
                    onChange={setCountry}
                    autoComplete="country-name"
                    isSearchable={false}
                  />
                </div>

                <div className={cx(styles.formRow, styles.fullWidth)}>
                  <Input
                    name="address"
                    label="Address"
                    autoComplete="address-line1"
                    placeholder="Enter address"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                  />
                </div>

                <div className={styles.formRow}>
                  <Input
                    label="Suburb"
                    placeholder="Enter suburb"
                    value={suburb}
                    onChange={(e) => setSuburb(e.target.value)}
                    autoComplete="address-level2"
                  />
                  <Input
                    label="Postcode"
                    placeholder="Enter postcode"
                    value={postcode}
                    onChange={(e) => setPostcode(e.target.value)}
                    autoComplete="postal-code"
                    pattern="[0-9]*"
                    inputMode="numeric"
                  />
                </div>

                {_.get(country, 'value') === COUNTRY_CODE.AUSTRALIA ? (
                  <div className={styles.formRow}>
                    <Select
                      name="state"
                      label="State"
                      items={stateOptions}
                      selectedItem={state}
                      placeholder="Select state"
                      onChange={setState}
                      autoComplete="address-level1"
                      isSearchable={false}
                    />
                  </div>
                ) : null}

                <div className={styles.consentContainer}>
                  <ConsentCheckbox
                    id="privacyConsentConfirmed"
                    label={
                      <RichTextContent
                        className="font-size font-size--extra-small font-weight"
                        content={privacyLabel}
                      />
                    }
                    onChange={(e) => setPrivacyConsent(e.target.checked)}
                    checked={privacyConsent}
                  />
                  <ConsentCheckbox
                    id="termsConsentConfirmed"
                    label={
                      <RichTextContent className="font-size font-size--extra-small font-weight" content={termsLabel} />
                    }
                    onChange={(e) => setTermsConsent(e.target.checked)}
                    checked={termsConsent}
                  />
                </div>
              </>
            ) : null}

            <div className={styles.callToActionContainer}>
              <Button type="submit" disabled={submitDisabled} loading={submitting}>
                {!eligible ? 'Continue' : 'Confirm cancellation'}
              </Button>
            </div>
          </form>
        )}
      </div>
    </ErrorBoundary>
  );
};

CancellationForm.propTypes = {
  title: PropTypes.string,
  bookingReferenceTooltip: PropTypes.string,
  privacyLabel: PropTypes.string.isRequired,
  termsLabel: PropTypes.string.isRequired,
  errorMessages: PropTypes.shape({
    apiErrorMessages: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
  }).isRequired,
  successMessage: PropTypes.shape(),
};

CancellationForm.defaultProps = {
  title: null,
  bookingReferenceTooltip: null,
  successMessage: {
    title: 'Cancellation submitted',
  },
};

export default CancellationForm;
