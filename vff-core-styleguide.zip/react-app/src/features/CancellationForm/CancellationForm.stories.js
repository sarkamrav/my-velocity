import React from 'react';
import MockAdapter from 'axios-mock-adapter';
import CancellationForm from './CancellationForm';
import api from '../../utils/api';

const props = {
  title: 'Your booking details',
  privacyLabel:
    'I consent to Virgin Australia Airlines Pty Ltd collecting my personal information to process my request.',
  termsLabel:
    'By submitting this form you are agreeing to the Terms and Conditions of this request. Once form is completed, an email will be automatically generated confirming cancellation of booking and a deposit of funds as a credit into Travelbank account.',
  successMessage: {
    title: 'Cancellation submitted',
    description: 'The team will get back to you as soon as they can! We apologise for inconvenience caused.',
  },
  errorMessages: {
    apiErrorMessages: [
      {
        value: 'Generic',
        title: '<p>Genaric error</p>\r\n',
      },
      {
        value: 'BookingClass',
        title: '<p>Booking class error</p>\r\n',
      },
      {
        value: 'NotTicketed',
        title: '<p>Not ticketed error</p>\r\n',
      },
      {
        value: 'TimeAfterCutOff',
        title: '<p>Time after cut off error.</p>\r\n',
      },
    ],
  },
};

export default {
  title: 'Cancellation form',
};

export const Default = () => {
  const mockVaCloud = new MockAdapter(api.vaCloudApi, { delayResponse: 1000 });

  mockVaCloud.onGet('/trip/v1/cancellation-check?lastName=LO&recordLocator=111111').reply(200, {
    eligible: true,
    uSADisclaimer: false,
    firstName: 'Vincent',
    lastName: 'Lo',
    displayDate: '2020-03-20T07:55:00',
    createdDate: '2020-03-16T04:55:00',
  });

  mockVaCloud.onGet('/trip/v1/cancellation-check?lastName=LO&recordLocator=222222').reply(200, {
    eligible: false,
    uSADisclaimer: false,
    tag: 'NoAirSegments',
    message: 'Your booking cannot be cancelled online, please call the guest contact centre for further assistance',
  });

  mockVaCloud.onGet('/trip/v1/cancellation-check?lastName=LO&recordLocator=333333').reply(200, {
    eligible: false,
    uSADisclaimer: false,
    tag: 'BadPNRLastName',
    message: 'Your booking cannot be cancelled online, please call the guest contact centre for further assistance',
  });

  mockVaCloud.onGet('/trip/v1/cancellation-check?lastName=LO&recordLocator=444444').reply(200, {
    eligible: false,
    uSADisclaimer: false,
    tag: 'NotTicketed',
    message: 'Your booking has not been ticketed and cannot be changed online, please call the guest contact centre.',
  });

  mockVaCloud.onGet('/trip/v1/cancellation-check?lastName=LO&recordLocator=555555').reply(200, {
    eligible: false,
    uSADisclaimer: false,
    tag: 'Indirect',
    message:
      'Your booking has been made through a travel agency or third party.  Please contact the company the booking was made through to modify your booking.',
  });

  mockVaCloud.onGet('/trip/v1/cancellation-check?lastName=LO&recordLocator=666666').reply(200, {
    eligible: false,
    uSADisclaimer: false,
    tag: 'BookingClass',
    message: 'Your booking cannot be cancelled online, please call the guest contact centre for further assistance',
  });

  mockVaCloud.onGet('/trip/v1/cancellation-check?lastName=LO&recordLocator=777777').reply(200, {
    eligible: false,
    uSADisclaimer: false,
    tag: 'TimeAfterCutOff',
    message:
      'Your booking is after the cutoff date and cannot be changed online, please call the guest contact centre.',
  });

  mockVaCloud.onGet('/trip/v1/cancellation-check?lastName=LO&recordLocator=888888').reply(200, {
    eligible: false,
    uSADisclaimer: false,
    tag: 'Generic',
    message:
      'Your booking is after the cutoff date and cannot be changed online, please call the guest contact centre.',
  });

  mockVaCloud.onPost('/trip/v1/cancellation').reply(200);

  return <CancellationForm {...props} />;
};

export const Error = () => {
  const mockVaCloud = new MockAdapter(api.vaCloudApi);

  mockVaCloud.onGet('/trip/v1/cancellation-check?lastName=LO&recordLocator=111111').reply(200, {
    eligible: true,
    uSADisclaimer: false,
    firstName: 'Vincent',
    lastName: 'Lo',
    displayDate: '2020-03-20T07:55:00',
    createdDate: '2020-03-16T04:55:00',
  });

  mockVaCloud.onGet('/trip/v1/cancellation-check?lastName=LO&recordLocator=222222').reply(500, {
    type: 'client:BadRequestError',
    title: 'Bad Request',
    status: 400,
    detail: 'DFZWQMsdv is invalid, a reservation number must be 6 or 7 uppercase alphanumeric characters',
  });

  mockVaCloud.onPost('/trip/v1/cancellation').reply(500, {
    type: 'client:BadRequestError',
    title: 'Bad Request',
    status: 400,
    detail: 'Something went wrong within our systems.',
  });

  return <CancellationForm {...props} />;
};
