import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';

import IconFont from '../../components/IconFont/IconFont';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME } from '../../utils/common';

import styles from './Breadcrumb.css';

const Breadcrumb = ({ breadcrumbs }) => {
  const lastIndex = breadcrumbs.length - 1;

  return (
    <ErrorBoundary section={COMPONENT_NAME.breadCrumb}>
      {!_.isEmpty(breadcrumbs) && (
        <nav className={styles.container}>
          <ol className={styles.list} aria-label="Breadcrumb">
            {_.map(breadcrumbs, ({ href, title, pagePath, siteRootPage }, index) => (
              <li className={styles.listItem} key={pagePath}>
                <a
                  className={styles.listLink}
                  href={href}
                  title={title}
                  aria-current={index === lastIndex ? 'page' : null}
                >
                  {!index && !!siteRootPage && <IconFont className={styles.homeIcon} name="home" ariaLabel={title} />}

                  {!index && !siteRootPage && title}

                  {!!index && title}
                </a>

                {index !== lastIndex && <IconFont className={styles.chevron} name="chevron-right" />}
              </li>
            ))}
          </ol>
        </nav>
      )}
    </ErrorBoundary>
  );
};

Breadcrumb.propTypes = {
  breadcrumbs: PropTypes.arrayOf(PropTypes.shape({})),
};

Breadcrumb.defaultProps = {
  breadcrumbs: null,
};

export default Breadcrumb;
