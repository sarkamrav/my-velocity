import React from 'react';

import BreadcrumbMock from './mocks/breadcrumbs.mock.json';
import Breadcrumb from './Breadcrumb';

export default {
  title: 'Breadcrumbs',
};

export const AllTypes = () => <Breadcrumb {...BreadcrumbMock} />;
