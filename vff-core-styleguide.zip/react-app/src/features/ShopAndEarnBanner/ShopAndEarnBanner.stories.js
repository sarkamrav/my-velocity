import React from 'react';

import ShopAndEarnBannerMock from './mocks/ShopAndEarnBanner.mock.json';

import ShopAndEarnBanner from './ShopAndEarnBanner';

export default {
  title: 'ShopAndEarnBanner',
};

export const ExtensionInstalled = () => <ShopAndEarnBanner {...ShopAndEarnBannerMock} />;
