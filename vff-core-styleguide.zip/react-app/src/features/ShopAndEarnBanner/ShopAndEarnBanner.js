import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';

import { browserName, isMobile } from 'react-device-detect';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import A from '../../components/Button/A';
import useMobileFullInnerHeight from '../../hooks/useMobileFullInnerHeight';

import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME, analyticsEventAction, analyticsEventName } from '../../utils/common';

import useExtensionDetection from '../../hooks/useExtensionDetection';
import Icon from '../../components/Icon/Icon';
import analyticsSend from '../../utils/analytics';

import styles from './ShopAndEarnBanner.css';

const ShopAndEarnBanner = ({
  title,
  imageAlt,
  description,
  isSafariEnabled,
  isMobileFullInnerHeightRequired,
  renditions,
  extensionNotInstalled,
  extensionInstalled,
  extensionUnsupported,
  renditionImageKey,
  extensionId,
  analyticsMetadata,
}) => {
  const analyticsMetadataKey = analyticsMetadata['analytics-metadata'];
  const assestImage = _.get(renditions, 'imageDefault', null);

  const [isExtensionExist, setExtensionExist] = useState(false);
  const { shopAndEarnExtensionId } = useExtensionDetection();
  const [analyticsData, setAnalyticsData] = useState(analyticsMetadataKey);

  const { click, impression } = analyticsEventAction;
  const { ctaInteraction, extensionImpression } = analyticsEventName;

  let offSetheight = 56;

  const breadcrumb = document.getElementsByClassName('src-features-Breadcrumb-Breadcrumb_container')[0];

  if (breadcrumb) {
    offSetheight += breadcrumb.getBoundingClientRect().height;
  }

  const [containerInlineStyle] = useMobileFullInnerHeight(offSetheight, isMobileFullInnerHeightRequired);

  const isChrome = browserName === 'Chrome';
  const isSafari = browserName === 'Safari';

  const isBrowserCompatible = isChrome || isSafari;

  useEffect(() => {
    const commonAnalyticsData = window.vffCoreWebsite[analyticsMetadataKey] || {};
    setAnalyticsData({
      ...commonAnalyticsData,
    });
  }, [analyticsMetadataKey]);

  function getCta(cta, icon) {
    if (icon === 'Safari' && !isSafariEnabled) return null;

    return (
      <A
        linkClassName={styles.browserCta}
        className={styles.browserCta}
        href={cta.ctaUrl}
        title={cta.ctaTitle}
        target={cta.ctaOpenInNewTab ? '_blank' : '_self'}
        buttonType={cta.ctaStyle}
        ctaAsLink={cta.ctaAsLink}
        ctaImage={cta.ctaImage}
        analytics-metadata={
          typeof analyticsData === 'string'
            ? analyticsData
            : JSON.stringify({
                ...(isBrowserCompatible
                  ? {
                      ...analyticsData,
                      eventAction: click,
                      eventName: ctaInteraction,
                      eventCategory: 'page-cta',
                      eventElementName: cta?.ctaTitle,
                      eventElementText: cta?.ctaLabel,
                      hyperlinkElementDestination: cta?.ctaUrl,
                    }
                  : {}),
              })
        }
      >
        {!!icon && cta.ctaType !== 'image' && <Icon name={icon} size="small" />}
        <span>{cta.ctaLabel}</span>
      </A>
    );
  }

  function renderMobileCta() {
    if (!isMobile) return null;

    if (isSafari) {
      return (
        <div className={styles.ctaContainer}>
          {getCta(extensionNotInstalled?.mobilePrimarySafariCtaContainer, 'Safari')}
          {getCta(extensionNotInstalled?.mobileSecondarySafariCtaContainer, 'Chrome')}
        </div>
      );
    }
    return (
      <>
        <div className={styles.unsupportedMessage}>Available for</div>
        <div className={styles.unsupportedCtaContainer}>
          {getCta(extensionNotInstalled?.mobilePrimaryChromeCtaContainer, 'Chrome')}
          {getCta(extensionNotInstalled?.mobileSecondaryChromeCtaContainer, 'Safari')}
        </div>
      </>
    );
  }

  function renderDesktopCta() {
    if (isMobile) return null;

    if (isBrowserCompatible) {
      return (
        <div className={styles.ctaContainer}>
          {isSafari ? (
            <>
              {getCta(extensionNotInstalled?.primarySafariCtaContainer, 'Safari')}
              {getCta(extensionNotInstalled?.secondarySafariCtaContainer, 'Chrome')}
            </>
          ) : null}
          {isChrome ? (
            <>
              {getCta(extensionNotInstalled?.primaryChromeCtaContainer, 'chrome')}
              {getCta(extensionNotInstalled?.secondaryChromeCtaContainer, 'Safari')}
            </>
          ) : null}
        </div>
      );
    }
    return (
      <>
        <div className={styles.unsupportedMessage}>Available for</div>
        <div className={styles.unsupportedCtaContainer}>
          {getCta(extensionUnsupported?.ctaContainer, 'Chrome')}
          {getCta(extensionUnsupported?.safariCtaContainer, 'Safari')}
        </div>
      </>
    );
  }

  useEffect(() => {
    if (shopAndEarnExtensionId && shopAndEarnExtensionId === extensionId) {
      setExtensionExist(true);
    }
  }, [shopAndEarnExtensionId, extensionId]);

  useEffect(() => {
    const getImpressionAnalytics = {
      ...analyticsData,
      eventAction: impression,
      eventName: extensionImpression,
      eventCategory: 'page-cta',
    };

    const timeoutID = setTimeout(() => {
      if (isBrowserCompatible) {
        if (isExtensionExist) {
          analyticsSend({
            ...getImpressionAnalytics,
            eventElementName: title,
            eventElementText: extensionInstalled?.ctaContainer?.ctaLabel,
          });
        } else {
          analyticsSend({
            ...getImpressionAnalytics,
            eventElementName: title,
            eventElementText: extensionNotInstalled?.primaryChromeCtaContainer?.ctaLabel,
          });
        }
      } else {
        analyticsSend({
          ...getImpressionAnalytics,
          eventElementName: title,
          eventElementText: extensionUnsupported?.ctaContainer?.ctaLabel,
        });
      }
    }, 500);
    return () => clearTimeout(timeoutID);
  }, [
    isExtensionExist,
    title,
    analyticsData,
    isBrowserCompatible,
    extensionImpression,
    impression,
    extensionInstalled?.ctaContainer?.ctaLabel,
    extensionNotInstalled?.primaryChromeCtaContainer?.ctaLabel,
    extensionUnsupported?.ctaContainer?.ctaLabel,
  ]);

  return (
    <ErrorBoundary section={COMPONENT_NAME.ShopAndEarnBanner}>
      <div className={styles.container} style={containerInlineStyle}>
        <div className={styles.shopWrapper}>
          <div className={styles.content}>
            {title ? (
              <h2 className={styles.title}>
                <RichTextContent content={title} className={styles.titleText} />
              </h2>
            ) : null}

            {description && <RichTextContent className={styles.description} content={description} />}

            {isExtensionExist ? (
              <>
                <span className={styles.allSet}>
                  <Icon className={styles.icon} name="Tick" size="extra-small" />
                  <RichTextContent content={extensionInstalled?.message} />
                </span>
                <div className={styles.ctaContainer}>
                  {getCta(extensionInstalled.ctaContainer, styles.extensionCta)}
                </div>
              </>
            ) : (
              <>
                {renderMobileCta()}
                {renderDesktopCta()}
              </>
            )}
          </div>
          <div className={styles.assetContainer}>
            <img className={styles.image} src={assestImage} rendition-image={renditionImageKey} alt={imageAlt} />
          </div>
        </div>
      </div>
    </ErrorBoundary>
  );
};

ShopAndEarnBanner.propTypes = {
  title: PropTypes.string,
  imageAlt: PropTypes.string,
  description: PropTypes.string,
  isSafariEnabled: PropTypes.bool,
  extensionNotInstalled: PropTypes.shape({
    mobilePrimaryChromeCtaContainer: PropTypes.shape({}),
    mobileSecondaryChromeCtaContainer: PropTypes.shape({}),
    mobilePrimarySafariCtaContainer: PropTypes.shape({}),
    mobileSecondarySafariCtaContainer: PropTypes.shape({}),
    primarySafariCtaContainer: PropTypes.shape({}),
    secondarySafariCtaContainer: PropTypes.shape({}),
    safariCtaContainer: PropTypes.shape({}),
    primaryChromeCtaContainer: PropTypes.shape({
      ctaLabel: PropTypes.string,
    }),
    secondaryChromeCtaContainer: PropTypes.shape({}),
    chromeCtaContainer: PropTypes.shape({
      ctaUrl: PropTypes.string,
      ctaTitle: PropTypes.string,
      ctaOpenInNewTab: PropTypes.bool,
      ctaStyle: PropTypes.string,
      ctaAsLink: PropTypes.bool,
      ctaLabel: PropTypes.string,
    }),
  }),
  extensionInstalled: PropTypes.shape({
    message: PropTypes.string,
    ctaContainer: PropTypes.shape({
      ctaUrl: PropTypes.string,
      ctaTitle: PropTypes.string,
      ctaOpenInNewTab: PropTypes.bool,
      ctaStyle: PropTypes.string,
      ctaAsLink: PropTypes.bool,
      ctaLabel: PropTypes.string,
    }),
  }),

  extensionUnsupported: PropTypes.shape({
    message: PropTypes.string,
    safariCtaContainer: PropTypes.shape({}),
    ctaContainer: PropTypes.shape({
      ctaUrl: PropTypes.string,
      ctaTitle: PropTypes.string,
      ctaOpenInNewTab: PropTypes.bool,
      ctaStyle: PropTypes.string,
      ctaAsLink: PropTypes.bool,
      ctaLabel: PropTypes.string,
    }),
  }),

  renditions: PropTypes.shape({}),
  renditionImageKey: PropTypes.string,
  extensionId: PropTypes.string.isRequired,
  isMobileFullInnerHeightRequired: PropTypes.bool,
  analyticsMetadata: PropTypes.shape({
    'analytics-metadata': PropTypes.string,
  }),
};

ShopAndEarnBanner.defaultProps = {
  title: '',
  description: '',
  isSafariEnabled: false,
  renditions: {},
  renditionImageKey: '',
  analyticsMetadata: {},
  extensionNotInstalled: {
    chromeCtaContainer: {},
  },
  extensionInstalled: {
    message: '',
    ctaContainer: {},
  },
  extensionUnsupported: {
    message: '',
    ctaContainer: {},
  },
  isMobileFullInnerHeightRequired: true,
  imageAlt: '',
};

export default ShopAndEarnBanner;
