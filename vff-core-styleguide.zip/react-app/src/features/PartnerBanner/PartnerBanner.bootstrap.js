import React from 'react';
import ReactDOM from 'react-dom';
import _ from 'lodash';
import { Provider } from 'react-redux';
import store from '../../stores';
import PartnerBanner from './PartnerBanner';
import { COMPONENT_NAME } from '../../utils/common';

const ELEMENT_NAME = COMPONENT_NAME.partnerBanner;

function renderComponent(elements, hydrate) {
  _.map(elements, (element) => {
    const props = window.vffCoreWebsite[element.getAttribute(ELEMENT_NAME)];

    if (props) {
      const component = (
        <Provider store={store}>
          <PartnerBanner {...props} />
        </Provider>
      );

      if (hydrate) {
        ReactDOM.hydrate(component, element);
      } else {
        ReactDOM.render(component, element);
      }
    }
  });
}

export default {
  elementName: ELEMENT_NAME,
  bootstrap: (id = null, hydrate = true) => {
    const elements = document.querySelectorAll(`[${ELEMENT_NAME}${id ? `=${id}` : ''}]`);

    if (_.size(elements) > 0) {
      renderComponent(elements, hydrate);
    }
  },
};
