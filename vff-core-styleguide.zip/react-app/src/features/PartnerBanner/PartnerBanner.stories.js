import React from 'react';
import { Provider } from 'react-redux';
import MockAdapter from 'axios-mock-adapter';
import store, { configureStore } from '../../stores';
import partnerBannerMock from './PartnerBanner.mock.json';
import PartnerBanner from './PartnerBanner';
import api from '../../utils/api';
import { addDaysToToday } from '../../utils/common';

export default {
  title: 'Partner Banner',
};

export const Default = () => (
  <Provider store={store}>
    <PartnerBanner {...partnerBannerMock} />
  </Provider>
);

export const WithActivatedOffers = () => {
  const mockVffV2Api = new MockAdapter(api.vffV2Api, { delayResponse: 1000 });
  const mockAem = new MockAdapter(api.aemApi, { delayResponse: 2000 });

  mockVffV2Api.onGet('/loyalty/v2/promotions/registrations?excludeBAUOffers=true').reply(200, {
    data: [
      {
        registrationEndDate: addDaysToToday(0),
        registrationStartDate: '2019-03-14',
        registrationStatus: 'REGISTRABLE',
        isRecurringPromotion: 'Y',
        promotionCode: 'TPLPOINTS',
        promotionShortDescription: 'Easter Triple Points Offer',
        promotionEndDate: '2020-02-12',
        promotionStartDate: '2019-03-19',
        mustRegister: true,
        promotionStatus: 'RUNNING',
      },
      {
        registrationStartDate: '2019-03-14',
        registrationStatus: 'REGISTRABLE',
        activationCapMax: '10000',
        isRecurringPromotion: 'Y',
        promotionCode: 'TPLPOINTS2',
        promotionShortDescription: 'Easter Triple Points Offer',
        promotionEndDate: '2020-02-12',
        promotionStartDate: '2019-03-19',
        mustRegister: true,
        promotionStatus: 'RUNNING',
      },
      {
        registrationEndDate: addDaysToToday(0),
        registrationStartDate: '2019-03-14',
        registrationStatus: 'REGISTRABLE',
        activationCapMax: '10000',
        isRecurringPromotion: 'Y',
        promotionCode: 'TPLPOINTS3',
        promotionShortDescription: 'Easter Triple Points Offer',
        promotionEndDate: '2020-02-12',
        promotionStartDate: '2019-03-19',
        promotionStatus: 'RUNNING',
        mustRegister: true,
      },
      {
        registrationEndDate: addDaysToToday(2),
        registrationStartDate: '2019-03-14',
        registrationStatus: 'REGISTRABLE',
        activationCapMax: '48',
        isRecurringPromotion: 'Y',
        promotionCode: 'TPLPOINTS4',
        promotionShortDescription: 'Easter Triple Points Offer',
        promotionEndDate: '2020-02-12',
        promotionStartDate: '2019-03-19',
        mustRegister: true,
        promotionStatus: 'RUNNING',
      },
      {
        registrationEndDate: addDaysToToday(1),
        registrationStartDate: '2019-03-14',
        registrationStatus: 'REGISTRABLE',
        activationCapMax: '10000',
        isRecurringPromotion: 'Y',
        promotionCode: 'DBLPOINTS',
        promotionShortDescription: 'Easter Triple Points Offer',
        promotionEndDate: '2020-02-12',
        promotionStartDate: '2019-03-19',
        mustRegister: true,
        promotionStatus: 'RUNNING',
      },
    ],
  });

  mockAem
    .onGet(
      '/api/v1/activated-offers/_jcr_content.promoCode-TPLPOINTS_TPLPOINTS2_TPLPOINTS3_TPLPOINTS4_DBLPOINTS.webmodel.json',
    )
    .reply(200, {
      activatedoffers: [
        {
          partner: {
            category: 'Everyday essentials',
            categoryColor: '#198050',
            logo: 'https://via.placeholder.com/120x120',
            name: 'BP',
          },
          promoLabel: 'Bonus points',
          promoCode: 'TPLPOINTS',
          ctaLabel: 'Activate offer',
          title: 'limited time',
          description:
            'Earn 2 Points per litre and 2 Points per $1 spent in-store at participating BP service stations.',
          expirationDateLabel: 'Ends in',
          additionalSuccessText: '<p>Additional text for CTA</p>',
          ctaUrl: '',
          ctaTitle: '',
          terms: {
            buttonLabel: 'Offer terms',
            title: 'Offer terms',
            text: `{{registrationStartDate}} {{test}} <a href="#">Test link</a> {{registrationStartDate}} - {{registrationEndDate}} Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer elementum sem erat, a lacinia urna fringilla quis. Pellentesque placerat tincidunt felis, quis tristique nulla. Aenean placerat consectetur fringilla. Phasellus ultrices vitae orci a tristique. Curabitur iaculis lacus non eleifend cursus. Nullam tempor placerat metus sed suscipit. Duis ultricies tincidunt dolor, id blandit nunc. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aliquam lobortis libero vitae augue sollicitudin, sed ultricies sapien dictum. Nulla bibendum vulputate arcu vel facilisis. Fusce pellentesque neque nec fermentum placerat.

      Quisque faucibus erat et turpis tincidunt aliquet. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla nisl magna, vestibulum sed ex et, mattis posuere ipsum. Sed venenatis cursus eros tempor tempus. Nulla facilisi. Phasellus enim dui, congue in molestie vitae, scelerisque eget lorem. Nulla quis ante auctor, congue neque id, dictum sem. Nam arcu ligula, convallis in felis sit amet, ultricies vestibulum massa. Suspendisse ornare dolor ac augue molestie, vitae venenatis quam dignissim. Nunc dapibus dolor eu ex faucibus finibus. Morbi vel diam gravida, pellentesque nibh et, mollis sem.

      Suspendisse ac lobortis ipsum. Etiam sit amet libero quam. Nunc faucibus, quam in faucibus eleifend, massa lorem lacinia augue, at suscipit sem ipsum sed urna. Sed fringilla felis ex, vel dapibus diam ornare ac. Nam auctor, turpis eget rhoncus rutrum, erat enim pharetra enim, vel iaculis leo urna ac sapien. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nunc dolor nibh, semper eu pharetra quis, blandit vel sapien. Maecenas ullamcorper nunc ipsum, a finibus orci condimentum ut. Nunc maximus purus vitae dui pharetra, et tincidunt urna accumsan. Aenean commodo, mi a semper commodo, nibh purus vestibulum neque, ultricies placerat urna risus quis augue. Vestibulum nec erat mi.

      Donec venenatis, tellus quis aliquam tempus, urna nulla rhoncus sapien, at faucibus odio purus nec leo. Fusce vel velit finibus, finibus nisi sed, interdum nibh. Morbi augue velit, blandit ut orci nec, consequat auctor elit. Proin vel nisi eu felis volutpat vulputate sit amet vel erat. Aliquam congue, augue et fermentum euismod, tortor felis viverra dui, nec hendrerit tellus ligula ut sem. Praesent non nunc in sapien sagittis placerat. Mauris facilisis nulla ut interdum fringilla. Donec volutpat ipsum sed eros placerat, sit amet consequat dolor sollicitudin. Maecenas vulputate pharetra mauris, ac commodo orci iaculis auctor. Donec eget egestas velit, et convallis purus.

      Etiam laoreet molestie pharetra. Proin consequat erat ac nibh rutrum convallis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In pulvinar tortor vel metus accumsan lobortis. Phasellus at felis a nisl aliquam pulvinar. Phasellus feugiat dolor quam, eget semper elit consequat ut. Vestibulum aliquam elit quam, eu commodo sem tempus aliquet. Suspendisse eros enim, pellentesque sed ornare ut, posuere id urna. Aliquam vulputate nulla id nibh tincidunt tincidunt. Morbi nisl risus, dapibus vel convallis eget, commodo vel turpis. Vestibulum gravida malesuada neque a condimentum. Vivamus in commodo massa. Vivamus ut est in odio dictum venenatis.`,
          },
        },
        {
          partner: {
            value: 'VMONEY',
            category: 'Everyday essentials',
            logo: 'https://via.placeholder.com/120x120',
            name: 'BP',
          },
          promoLabel: 'Bonus points',
          promoCode: 'TPLPOINTS2',
          ctaLabel: 'Activate offer',
          title: 'limited offers',
          description:
            'Earn 2 Points per litre and 2 Points per $1 spent in-store at participating BP service stations.',
          showMaxCap: true,
          capOfferLabel: 'offers available',
          expirationDateLabel: 'Ends in',
          ctaUrl: '',
          ctaTitle: '',
          terms: {
            buttonLabel: 'See details and offer terms',
            title: 'Offer terms',
            text: `{{registrationStartDate}} {{test}} <a href="#">Test link</a> {{registrationStartDate}} - {{registrationEndDate}} Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer elementum sem erat, a lacinia urna fringilla quis. Pellentesque placerat tincidunt felis, quis tristique nulla. Aenean placerat consectetur fringilla. Phasellus ultrices vitae orci a tristique. Curabitur iaculis lacus non eleifend cursus. Nullam tempor placerat metus sed suscipit. Duis ultricies tincidunt dolor, id blandit nunc. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aliquam lobortis libero vitae augue sollicitudin, sed ultricies sapien dictum. Nulla bibendum vulputate arcu vel facilisis. Fusce pellentesque neque nec fermentum placerat.

      Quisque faucibus erat et turpis tincidunt aliquet. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla nisl magna, vestibulum sed ex et, mattis posuere ipsum. Sed venenatis cursus eros tempor tempus. Nulla facilisi. Phasellus enim dui, congue in molestie vitae, scelerisque eget lorem. Nulla quis ante auctor, congue neque id, dictum sem. Nam arcu ligula, convallis in felis sit amet, ultricies vestibulum massa. Suspendisse ornare dolor ac augue molestie, vitae venenatis quam dignissim. Nunc dapibus dolor eu ex faucibus finibus. Morbi vel diam gravida, pellentesque nibh et, mollis sem.

      Suspendisse ac lobortis ipsum. Etiam sit amet libero quam. Nunc faucibus, quam in faucibus eleifend, massa lorem lacinia augue, at suscipit sem ipsum sed urna. Sed fringilla felis ex, vel dapibus diam ornare ac. Nam auctor, turpis eget rhoncus rutrum, erat enim pharetra enim, vel iaculis leo urna ac sapien. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nunc dolor nibh, semper eu pharetra quis, blandit vel sapien. Maecenas ullamcorper nunc ipsum, a finibus orci condimentum ut. Nunc maximus purus vitae dui pharetra, et tincidunt urna accumsan. Aenean commodo, mi a semper commodo, nibh purus vestibulum neque, ultricies placerat urna risus quis augue. Vestibulum nec erat mi.

      Donec venenatis, tellus quis aliquam tempus, urna nulla rhoncus sapien, at faucibus odio purus nec leo. Fusce vel velit finibus, finibus nisi sed, interdum nibh. Morbi augue velit, blandit ut orci nec, consequat auctor elit. Proin vel nisi eu felis volutpat vulputate sit amet vel erat. Aliquam congue, augue et fermentum euismod, tortor felis viverra dui, nec hendrerit tellus ligula ut sem. Praesent non nunc in sapien sagittis placerat. Mauris facilisis nulla ut interdum fringilla. Donec volutpat ipsum sed eros placerat, sit amet consequat dolor sollicitudin. Maecenas vulputate pharetra mauris, ac commodo orci iaculis auctor. Donec eget egestas velit, et convallis purus.

      Etiam laoreet molestie pharetra. Proin consequat erat ac nibh rutrum convallis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In pulvinar tortor vel metus accumsan lobortis. Phasellus at felis a nisl aliquam pulvinar. Phasellus feugiat dolor quam, eget semper elit consequat ut. Vestibulum aliquam elit quam, eu commodo sem tempus aliquet. Suspendisse eros enim, pellentesque sed ornare ut, posuere id urna. Aliquam vulputate nulla id nibh tincidunt tincidunt. Morbi nisl risus, dapibus vel convallis eget, commodo vel turpis. Vestibulum gravida malesuada neque a condimentum. Vivamus in commodo massa. Vivamus ut est in odio dictum venenatis.`,
          },
        },
        {
          partner: {
            category: 'Everyday essentials',
            logo: 'https://via.placeholder.com/120x120',
            name: 'BP',
          },
          promoLabel: 'Bonus points',
          promoCode: 'TPLPOINTS3',
          ctaLabel: 'Activate offer',
          title: 'limited time and offers',
          description:
            'Earn 2 Points per litre and 2 Points per $1 spent in-store at participating BP service stations.',
          showMaxCap: true,
          capOfferLabel: 'offers available',
          expirationDateLabel: 'Ends in',
          ctaUrl: '',
          ctaTitle: '',
          terms: {
            buttonLabel: 'Offer terms',
            title: 'Offer terms',
            text: `{{registrationStartDate}} {{test}} <a href="#">Test link</a> {{registrationStartDate}} - {{registrationEndDate}} Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer elementum sem erat, a lacinia urna fringilla quis. Pellentesque placerat tincidunt felis, quis tristique nulla. Aenean placerat consectetur fringilla. Phasellus ultrices vitae orci a tristique. Curabitur iaculis lacus non eleifend cursus. Nullam tempor placerat metus sed suscipit. Duis ultricies tincidunt dolor, id blandit nunc. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aliquam lobortis libero vitae augue sollicitudin, sed ultricies sapien dictum. Nulla bibendum vulputate arcu vel facilisis. Fusce pellentesque neque nec fermentum placerat.

      Quisque faucibus erat et turpis tincidunt aliquet. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla nisl magna, vestibulum sed ex et, mattis posuere ipsum. Sed venenatis cursus eros tempor tempus. Nulla facilisi. Phasellus enim dui, congue in molestie vitae, scelerisque eget lorem. Nulla quis ante auctor, congue neque id, dictum sem. Nam arcu ligula, convallis in felis sit amet, ultricies vestibulum massa. Suspendisse ornare dolor ac augue molestie, vitae venenatis quam dignissim. Nunc dapibus dolor eu ex faucibus finibus. Morbi vel diam gravida, pellentesque nibh et, mollis sem.

      Suspendisse ac lobortis ipsum. Etiam sit amet libero quam. Nunc faucibus, quam in faucibus eleifend, massa lorem lacinia augue, at suscipit sem ipsum sed urna. Sed fringilla felis ex, vel dapibus diam ornare ac. Nam auctor, turpis eget rhoncus rutrum, erat enim pharetra enim, vel iaculis leo urna ac sapien. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nunc dolor nibh, semper eu pharetra quis, blandit vel sapien. Maecenas ullamcorper nunc ipsum, a finibus orci condimentum ut. Nunc maximus purus vitae dui pharetra, et tincidunt urna accumsan. Aenean commodo, mi a semper commodo, nibh purus vestibulum neque, ultricies placerat urna risus quis augue. Vestibulum nec erat mi.

      Donec venenatis, tellus quis aliquam tempus, urna nulla rhoncus sapien, at faucibus odio purus nec leo. Fusce vel velit finibus, finibus nisi sed, interdum nibh. Morbi augue velit, blandit ut orci nec, consequat auctor elit. Proin vel nisi eu felis volutpat vulputate sit amet vel erat. Aliquam congue, augue et fermentum euismod, tortor felis viverra dui, nec hendrerit tellus ligula ut sem. Praesent non nunc in sapien sagittis placerat. Mauris facilisis nulla ut interdum fringilla. Donec volutpat ipsum sed eros placerat, sit amet consequat dolor sollicitudin. Maecenas vulputate pharetra mauris, ac commodo orci iaculis auctor. Donec eget egestas velit, et convallis purus.

      Etiam laoreet molestie pharetra. Proin consequat erat ac nibh rutrum convallis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In pulvinar tortor vel metus accumsan lobortis. Phasellus at felis a nisl aliquam pulvinar. Phasellus feugiat dolor quam, eget semper elit consequat ut. Vestibulum aliquam elit quam, eu commodo sem tempus aliquet. Suspendisse eros enim, pellentesque sed ornare ut, posuere id urna. Aliquam vulputate nulla id nibh tincidunt tincidunt. Morbi nisl risus, dapibus vel convallis eget, commodo vel turpis. Vestibulum gravida malesuada neque a condimentum. Vivamus in commodo massa. Vivamus ut est in odio dictum venenatis.`,
          },
        },
        {
          partner: {
            category: 'Everyday essentials',
            logo: 'https://via.placeholder.com/120x120',
            name: 'BP',
          },
          promoLabel: 'Zz points',
          promoCode: 'TPLPOINTS4',
          ctaLabel: 'Activate offer',
          title: 'limited time and offers',
          description:
            'Earn 2 Points per litre and 2 Points per $1 spent in-store at participating BP service stations.',
          showMaxCap: false,
          capOfferLabel: 'offers available',
          expirationDateLabel: 'Ends in',
          ctaUrl: '',
          ctaTitle: '',
        },
      ],
    });

  return (
    <Provider store={configureStore({ user: { loyaltyMembershipID: '123' } })}>
      <PartnerBanner {...partnerBannerMock} />
    </Provider>
  );
};

WithActivatedOffers.storyName = 'With activated offers';
