import cx from 'classnames';
import _ from 'lodash';
import PropTypes from 'prop-types';
import React, { useEffect, useRef, useState } from 'react';
import Badge from '../../components/Badge/Badge';
import A from '../../components/Button/A';
import HorizontalScroll from '../../components/HorizontalScroll/HorizontalScroll';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import usePartnerActivatedOffers from '../../hooks/usePartnerApiOffers';
import useServerRendering from '../../hooks/useServerRendering';
import {
  COMPONENT_NAME,
  getHashId,
  getNavigationHeight,
  isPassiveEventListenerSupported,
  renderImage,
  smoothScrollToElement,
} from '../../utils/common';
import { isElementInTab } from '../ResponsiveTabs/utils';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';

import styles from './PartnerBanner.css';

/**
 * Creates the partner banner layout.
 * In the event that a tab has "offerCount" available, then it will check the API Activated Offers available for the "partner.value" provided, and calculate them in a badge.
 */
const PartnerBanner = ({ tabs, partner }) => {
  const imageRef = useRef();
  const { rendered } = useServerRendering();
  const { partnerApiOffers, partnerApiOffersLoading } = usePartnerActivatedOffers(
    partner.value,
    _.some(tabs, 'offerCount'),
  );
  const { ctaContainer = {}, keyCallOuts = [] } = partner;
  const [selectedTabId, setSelectedTabId] = useState(
    _.some(tabs, { id: window.location.hash.replace('#', '') })
      ? window.location.hash.replace('#', '')
      : _.get(tabs, '[0].id'),
  );
  const [isPassiveListenerSupported] = useState(isPassiveEventListenerSupported());
  const [isTabSticky, setIsTabSticky] = useState(false);
  const tabsContainerRef = useRef(null);
  const containerRef = useRef(null);

  function scrollTabToView(tabId) {
    const tab = document.getElementById(`partnerTab-${tabId}`);
    if (tab) {
      tab.scrollIntoView({ inline: 'end' });
    }
  }

  useEffect(() => {
    if (window.location.hash && window.matchMedia('(max-width: 767px)').matches) {
      scrollTabToView(selectedTabId);
    }
  }, [selectedTabId]);

  useEffect(() => {
    renderImage(imageRef.current, partner.renditions);
  }, [partner.renditions]);

  useEffect(() => {
    _.each(tabs, (tab) => {
      const tabElement = document.getElementById(`partnerTab-${tab.id}`);
      const tabContentElement = document.getElementById(`${tab.id}`);

      if (tabElement) {
        if (selectedTabId === tab.id) {
          tabElement.classList.add(styles.tabButtonActive);
        } else {
          tabElement.classList.remove(styles.tabButtonActive);
        }
      }

      if (tabContentElement) {
        if (selectedTabId === tab.id) {
          tabContentElement.classList.add('tabs__content--active');
        } else {
          tabContentElement.classList.remove('tabs__content--active');
        }
      }
    });
  }, [selectedTabId, tabs]);

  useEffect(() => {
    function handleEnsureElementIsVisible(event) {
      const targetElement = event.target;
      const hashId = getHashId();
      const isHashIdTabItem = _.findIndex(tabs, (tab) => tab.id === hashId) !== -1;

      if (isHashIdTabItem) {
        setSelectedTabId(hashId);
        return;
      }

      const tabContainingTargetElement = tabs.find((tab) => isElementInTab(targetElement, tab));

      if (tabContainingTargetElement) {
        setSelectedTabId(tabContainingTargetElement.id);
      }
    }

    // Attach event listeners
    _.each(tabs, (tab) => {
      const element = document.getElementById(tab.id);

      if (element) {
        element.addEventListener('ensureElementIsVisible', handleEnsureElementIsVisible);
      }
    });

    return () => {
      // Remove event listeners
      _.each(tabs, (tab) => {
        const element = document.getElementById(tab.id);

        if (element) {
          element.removeEventListener('ensureElementIsVisible', handleEnsureElementIsVisible);
        }
      });
    };
  }, [tabs]);

  useEffect(() => {
    function getStickyHeight() {
      return containerRef.current.offsetHeight - tabsContainerRef.current.offsetHeight;
    }

    function makeTabsSticky() {
      if (window.pageYOffset >= getStickyHeight()) {
        setIsTabSticky(true);
      }
    }

    function makeTabsStatic() {
      if (window.pageYOffset < getStickyHeight()) {
        setIsTabSticky(false);
      }
    }

    const tabsContainerRefCurrent = tabsContainerRef.current;
    // We don't want sticky tabs in authoring mode
    if (tabsContainerRefCurrent && !_.get(window.vffCoreWebsite, 'websiteData.authoringMode')) {
      if (isTabSticky) {
        window.addEventListener('scroll', makeTabsStatic, isPassiveListenerSupported ? { passive: true } : false);
      } else {
        window.addEventListener('scroll', makeTabsSticky, isPassiveListenerSupported ? { passive: true } : false);
      }
    }

    return () => {
      if (tabsContainerRefCurrent) {
        if (isTabSticky) {
          window.removeEventListener('scroll', makeTabsStatic, isPassiveListenerSupported ? { passive: true } : false);
        } else {
          window.removeEventListener('scroll', makeTabsSticky, isPassiveListenerSupported ? { passive: true } : false);
        }
      }
    };
  }, [isPassiveListenerSupported, isTabSticky]);

  function handleChangeTab(tab) {
    if (selectedTabId !== tab.id && containerRef && containerRef.current) {
      setSelectedTabId(tab.id);
      window.location.hash = `#${tab.id}`;
    }
  }

  useEffect(() => {
    if (rendered) {
      smoothScrollToElement(document.getElementById(selectedTabId), getNavigationHeight() * 2);
    }
  }, [rendered, selectedTabId]);

  useEffect(() => {
    function handleHashChange() {
      const hashId = getHashId();
      const isTabFound = _.findIndex(tabs, (tab) => tab.id === hashId) !== -1;

      if (isTabFound) {
        setSelectedTabId(hashId);
      }
    }

    window.addEventListener('hashchange', handleHashChange, false);

    return () => window.removeEventListener('hashchange', handleHashChange, false);
  }, [tabs]);

  return (
    <ErrorBoundary section={COMPONENT_NAME.partnerBanner}>
      <section className={styles.container} ref={containerRef}>
        <div className={styles.background} ref={imageRef} />

        <div
          className={cx(styles.contentContainer, {
            [styles.noTabs]: tabs.length <= 1,
          })}
        >
          <div className={styles.content}>
            {!_.isEmpty(partner) ? (
              <div className={styles.logoContainer}>
                <img className={styles.partnerLogo} src={partner.logo} alt={partner.name} />
              </div>
            ) : null}

            {partner.name ? (
              <h1 className={cx(styles.title, 'heading heading--1 color color--purple')}>{partner.name}</h1>
            ) : null}

            {partner.tagLine ? <RichTextContent content={partner.tagLine} className={styles.description} /> : null}

            {!_.isEmpty(keyCallOuts) ? (
              <ul className={styles.keyCallouts}>
                {_.map(keyCallOuts, (keyCallOut) => (
                  <li key={keyCallOut.title} className={styles.keyCallout}>
                    {keyCallOut.iconUrl ? (
                      <img className={styles.keyCalloutIcon} src={keyCallOut.iconUrl} alt={keyCallOut.title} />
                    ) : null}
                    <span className={styles.keyCalloutText}>{keyCallOut.title}</span>
                  </li>
                ))}
              </ul>
            ) : null}

            {!_.isEmpty(ctaContainer) ? (
              <A
                href={ctaContainer.ctaUrl}
                className={styles.ctaButton}
                title={ctaContainer.ctaTitle}
                target={ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
                buttonType={ctaContainer.ctaStyle}
                ctaAsLink={ctaContainer.ctaAsLink}
              >
                {ctaContainer.ctaLabel}
              </A>
            ) : null}
          </div>
        </div>

        {tabs.length > 1 ? (
          <div
            id="partner-banner-tabs-container"
            ref={tabsContainerRef}
            className={cx(styles.tabsContainer, {
              [styles.sticky]: isTabSticky,
            })}
          >
            <HorizontalScroll className={styles.scrollContainer}>
              <ul
                className={cx(styles.tabs, {
                  [styles.twoTabsOnly]: tabs.length === 2,
                })}
              >
                <li className={styles.tabPlaceholder} />
                {_.map(tabs, (tab) => {
                  const allOffersCount = tab.offerCount + _.size(partnerApiOffers);

                  return (
                    <li key={tab.title} className={styles.tabItem}>
                      <button
                        id={`partnerTab-${tab.id}`}
                        onClick={() => handleChangeTab(tab)}
                        className={styles.tabButton}
                      >
                        <span>{tab.title}</span>
                        {
                          // Only show tab count when offerCount is available
                          rendered && _.has(tab, 'offerCount') && allOffersCount > 0 ? (
                            <Badge number={allOffersCount} loading={partnerApiOffersLoading} />
                          ) : null
                        }
                      </button>
                    </li>
                  );
                })}
                <li className={styles.tabPlaceholder} />
              </ul>
            </HorizontalScroll>
          </div>
        ) : null}
      </section>
    </ErrorBoundary>
  );
};

PartnerBanner.propTypes = {
  tabs: PropTypes.arrayOf(PropTypes.shape({})),
  partner: PropTypes.shape({
    tagLine: PropTypes.string,
    logo: PropTypes.string,
    name: PropTypes.string,
    renditions: PropTypes.shape({}),
    ctaContainer: PropTypes.shape({}),
    keyCallOuts: PropTypes.arrayOf(PropTypes.shape({})),
    value: PropTypes.string,
  }),
};

PartnerBanner.defaultProps = {
  tabs: [],
  partner: {},
};

export default PartnerBanner;
