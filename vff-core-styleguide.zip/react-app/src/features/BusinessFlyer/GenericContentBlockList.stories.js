import React from 'react';
import GenericContentBlockList from './GenericContentBlockList/GenericContentBlockList';
import mock from './mocks/GenericContentBlockList.mock.json';

export default {
  title: 'Generic Content Block',
};

export const ContentBlock = () => <GenericContentBlockList {...mock} />;
