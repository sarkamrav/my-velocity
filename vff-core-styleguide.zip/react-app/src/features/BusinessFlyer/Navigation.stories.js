import React from 'react';
import Navigation from './Navigation/Navigation';
import navigationMock from './mocks/Navigation.mock.json';

export default {
  title: 'Business Flyer Navigation',
};

export const DefaultNavigation = () => <Navigation {...navigationMock} />;
