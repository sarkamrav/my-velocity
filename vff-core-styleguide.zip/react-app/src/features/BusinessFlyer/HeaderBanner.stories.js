import React from 'react';
import HeaderBanner from './HeaderBanner/HeaderBanner';
import bannerMock from './mocks/headerBanner.mock.json';

export default {
  title: 'Business Flyer Banner',
};

export const Banner = () => <HeaderBanner {...bannerMock} />;
