import { ADDRESS_TYPE, COUNTRY_CODE, GENDER, PERSON_TITLE, PERSON_TITLE_ADDITIONAL, PHONE_TYPE } from './constants';
import { COUNTRY_CODE as COUNTRY_CODE_FROM_CONSTANTS } from '../../utils/constants';

export const countriesByCode = {
  [COUNTRY_CODE.AUSTRALIA]: {
    code: COUNTRY_CODE.AUSTRALIA,
    label: 'Australia',
    phoneCode: 61,
  },
  [COUNTRY_CODE.NEW_ZEALAND]: {
    code: COUNTRY_CODE.NEW_ZEALAND,
    label: 'New Zealand',
    phoneCode: 64,
  },
  [COUNTRY_CODE.CHRISTMAS_ISLAND]: {
    code: COUNTRY_CODE.CHRISTMAS_ISLAND,
    label: 'Christmas Island',
    phoneCode: 61,
  },
  [COUNTRY_CODE.COCOS_ISLANDS]: {
    code: COUNTRY_CODE.COCOS_ISLANDS,
    label: 'Cocos Islands',
    phoneCode: 61,
  },
  [COUNTRY_CODE.COOK_ISLANDS]: {
    code: COUNTRY_CODE.COOK_ISLANDS,
    label: 'Cook Islands',
    phoneCode: 682,
  },
  [COUNTRY_CODE.FIJI]: {
    code: COUNTRY_CODE.FIJI,
    label: 'Fiji',
    phoneCode: 679,
  },
  [COUNTRY_CODE.PAPUA_NEW_GUINEA]: {
    code: COUNTRY_CODE.PAPUA_NEW_GUINEA,
    label: 'Papua New Guinea',
    phoneCode: 675,
  },
  [COUNTRY_CODE.SAMOA]: {
    code: COUNTRY_CODE.SAMOA,
    label: 'Samoa',
    phoneCode: 685,
  },
  [COUNTRY_CODE.SOLOMON_ISLANDS]: {
    code: COUNTRY_CODE.SOLOMON_ISLANDS,
    label: 'Solomon Islands',
    phoneCode: 677,
  },
  [COUNTRY_CODE.TONGA]: {
    code: COUNTRY_CODE.TONGA,
    label: 'Tonga',
    phoneCode: 676,
  },
  [COUNTRY_CODE.VANUATU]: {
    code: COUNTRY_CODE.VANUATU,
    label: 'Vanuatu',
    phoneCode: 678,
  },
};

export const countriesByCodeForCountryCalling = {
  [COUNTRY_CODE.AUSTRALIA]: {
    code: COUNTRY_CODE.AUSTRALIA,
    label: 'Australia',
    phoneCode: 61,
  },
  [COUNTRY_CODE.NEW_ZEALAND]: {
    code: COUNTRY_CODE.NEW_ZEALAND,
    label: 'New Zealand',
    phoneCode: 64,
  },
  [COUNTRY_CODE.CHRISTMAS_ISLAND]: {
    code: COUNTRY_CODE.CHRISTMAS_ISLAND,
    label: 'Christmas Island',
    phoneCode: 61,
  },
  [COUNTRY_CODE.COCOS_ISLANDS]: {
    code: COUNTRY_CODE.COCOS_ISLANDS,
    label: 'Cocos Islands',
    phoneCode: 61,
  },
  [COUNTRY_CODE.COOK_ISLANDS]: {
    code: COUNTRY_CODE.COOK_ISLANDS,
    label: 'Cook Islands',
    phoneCode: 682,
  },
  [COUNTRY_CODE.FIJI]: {
    code: COUNTRY_CODE.FIJI,
    label: 'Fiji',
    phoneCode: 679,
  },
  [COUNTRY_CODE.PAPUA_NEW_GUINEA]: {
    code: COUNTRY_CODE.PAPUA_NEW_GUINEA,
    label: 'Papua New Guinea',
    phoneCode: 675,
  },
  [COUNTRY_CODE.SAMOA]: {
    code: COUNTRY_CODE.SAMOA,
    label: 'Samoa',
    phoneCode: 685,
  },
  [COUNTRY_CODE.SOLOMON_ISLANDS]: {
    code: COUNTRY_CODE.SOLOMON_ISLANDS,
    label: 'Solomon Islands',
    phoneCode: 677,
  },
  [COUNTRY_CODE.TONGA]: {
    code: COUNTRY_CODE.TONGA,
    label: 'Tonga',
    phoneCode: 676,
  },
  [COUNTRY_CODE.VANUATU]: {
    code: COUNTRY_CODE.VANUATU,
    label: 'Vanuatu',
    phoneCode: 678,
  },
  // clean up

  [COUNTRY_CODE_FROM_CONSTANTS.AFGHANISTAN]: {
    label: 'Afghanistan (+93)',
    code: COUNTRY_CODE_FROM_CONSTANTS.AFGHANISTAN,
    phoneCode: 93,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ALAND_ISLANDS]: {
    label: 'Aland Islands (+358)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ALAND_ISLANDS,
    phoneCode: 358,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ALBANIA]: {
    label: 'Albania (+355)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ALBANIA,
    phoneCode: 355,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ALGERIA]: {
    label: 'Algeria (+213)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ALGERIA,
    phoneCode: 213,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.AMERICAN_SAMOA]: {
    label: 'American Samoa (+1684)',
    code: COUNTRY_CODE_FROM_CONSTANTS.AMERICAN_SAMOA,
    phoneCode: 1684,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ANDORRA]: {
    label: 'Andorra (+376)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ANDORRA,
    phoneCode: 376,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ANGOLA]: {
    label: 'Angola (+244)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ANGOLA,
    phoneCode: 244,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ANGUILLA]: {
    label: 'Anguilla (+1264)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ANGUILLA,
    phoneCode: 1264,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ANTARCTICA]: {
    label: 'Antarctica (+672)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ANTARCTICA,
    phoneCode: 672,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ANTIGUA_AND_BARBUDA]: {
    label: 'Antigua And Barbuda (+1268)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ANTIGUA_AND_BARBUDA,
    phoneCode: 1268,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ARGENTINA]: {
    label: 'Argentina (+54)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ARGENTINA,
    phoneCode: 54,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ARMENIA]: {
    label: 'Armenia (+374)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ARMENIA,
    phoneCode: 374,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ARUBA]: {
    label: 'Aruba (+297)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ARUBA,
    phoneCode: 297,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.AUSTRIA]: {
    label: 'Austria (+43)',
    code: COUNTRY_CODE_FROM_CONSTANTS.AUSTRIA,
    phoneCode: 43,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.AZERBAIJAN]: {
    label: 'Azerbaijan (+994)',
    code: COUNTRY_CODE_FROM_CONSTANTS.AZERBAIJAN,
    phoneCode: 994,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.BAHAMAS]: {
    label: 'Bahamas (+1242)',
    code: COUNTRY_CODE_FROM_CONSTANTS.BAHAMAS,
    phoneCode: 1242,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.BAHRAIN]: {
    label: 'Bahrain (+973)',
    code: COUNTRY_CODE_FROM_CONSTANTS.BAHRAIN,
    phoneCode: 973,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.BANGLADESH]: {
    label: 'Bangladesh (+880)',
    code: COUNTRY_CODE_FROM_CONSTANTS.BANGLADESH,
    phoneCode: 880,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.BARBADOS]: {
    label: 'Barbados (+1246)',
    code: COUNTRY_CODE_FROM_CONSTANTS.BARBADOS,
    phoneCode: 1246,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.BELARUS]: {
    label: 'Belarus (+375)',
    code: COUNTRY_CODE_FROM_CONSTANTS.BELARUS,
    phoneCode: 375,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.BELGIUM]: {
    label: 'Belgium (+32)',
    code: COUNTRY_CODE_FROM_CONSTANTS.BELGIUM,
    phoneCode: 32,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.BELIZE]: {
    label: 'Belize (+501)',
    code: COUNTRY_CODE_FROM_CONSTANTS.BELIZE,
    phoneCode: 501,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.BENIN]: {
    label: 'Benin (+229)',
    code: COUNTRY_CODE_FROM_CONSTANTS.BENIN,
    phoneCode: 229,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.BERMUDA]: {
    label: 'Bermuda (+1441)',
    code: COUNTRY_CODE_FROM_CONSTANTS.BERMUDA,
    phoneCode: 1441,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.BHUTAN]: {
    label: 'Bhutan (+975)',
    code: COUNTRY_CODE_FROM_CONSTANTS.BHUTAN,
    phoneCode: 975,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.BOLIVIA]: {
    label: 'Bolivia (+591)',
    code: COUNTRY_CODE_FROM_CONSTANTS.BOLIVIA,
    phoneCode: 591,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.BONAIRE_ST_EUSTATIUS_AND_SABA]: {
    label: 'Bonaire St Eustatius And Saba (+599)',
    code: COUNTRY_CODE_FROM_CONSTANTS.BONAIRE_ST_EUSTATIUS_AND_SABA,
    phoneCode: 599,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.BOSNIA_HERZEGOVINA]: {
    label: 'Bosnia-Herzegovina (+387)',
    code: COUNTRY_CODE_FROM_CONSTANTS.BOSNIA_HERZEGOVINA,
    phoneCode: 387,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.BOTSWANA]: {
    label: 'Botswana (+267)',
    code: COUNTRY_CODE_FROM_CONSTANTS.BOTSWANA,
    phoneCode: 267,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.BOUVET_ISLAND]: {
    label: 'Bouvet Island (+47)',
    code: COUNTRY_CODE_FROM_CONSTANTS.BOUVET_ISLAND,
    phoneCode: 47,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.BRAZIL]: {
    label: 'Brazil (+55)',
    code: COUNTRY_CODE_FROM_CONSTANTS.BRAZIL,
    phoneCode: 55,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.BRITISH_INDIAN_OCEAN_TERRITORY]: {
    label: 'British Indian Ocean Territory (+246)',
    code: COUNTRY_CODE_FROM_CONSTANTS.BRITISH_INDIAN_OCEAN_TERRITORY,
    phoneCode: 246,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.BRUNEI_DARUSSALAM]: {
    label: 'Brunei Darussalam (+673)',
    code: COUNTRY_CODE_FROM_CONSTANTS.BRUNEI_DARUSSALAM,
    phoneCode: 673,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.BULGARIA]: {
    label: 'Bulgaria (+359)',
    code: COUNTRY_CODE_FROM_CONSTANTS.BULGARIA,
    phoneCode: 359,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.BURKINA_FASO]: {
    label: 'Burkina Faso (+226)',
    code: COUNTRY_CODE_FROM_CONSTANTS.BURKINA_FASO,
    phoneCode: 226,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.BURUNDI]: {
    label: 'Burundi (+257)',
    code: COUNTRY_CODE_FROM_CONSTANTS.BURUNDI,
    phoneCode: 257,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.CAMBODIA]: {
    label: 'Cambodia (+855)',
    code: COUNTRY_CODE_FROM_CONSTANTS.CAMBODIA,
    phoneCode: 855,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.CAMEROON_REPUBLIC_OF]: {
    label: 'Cameroon-Republic Of (+237)',
    code: COUNTRY_CODE_FROM_CONSTANTS.CAMEROON_REPUBLIC_OF,
    phoneCode: 237,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.CANADA]: {
    label: 'Canada (+1)',
    code: COUNTRY_CODE_FROM_CONSTANTS.CANADA,
    phoneCode: 1,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.CAPE_VERDE_REPUBLIC_OF]: {
    label: 'Cape Verde-Republic Of (+238)',
    code: COUNTRY_CODE_FROM_CONSTANTS.CAPE_VERDE_REPUBLIC_OF,
    phoneCode: 238,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.CAYMAN_ISLANDS]: {
    label: 'Cayman Islands (+1345)',
    code: COUNTRY_CODE_FROM_CONSTANTS.CAYMAN_ISLANDS,
    phoneCode: 1345,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.CENTRAL_AFRICAN_REPUBLIC]: {
    label: 'Central African Republic (+236)',
    code: COUNTRY_CODE_FROM_CONSTANTS.CENTRAL_AFRICAN_REPUBLIC,
    phoneCode: 236,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.CHAD]: {
    label: 'Chad (+235)',
    code: COUNTRY_CODE_FROM_CONSTANTS.CHAD,
    phoneCode: 235,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.CHILE]: {
    label: 'Chile (+56)',
    code: COUNTRY_CODE_FROM_CONSTANTS.CHILE,
    phoneCode: 56,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.CHINA]: {
    label: 'China (+86)',
    code: COUNTRY_CODE_FROM_CONSTANTS.CHINA,
    phoneCode: 86,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.COLOMBIA]: {
    label: 'Colombia (+57)',
    code: COUNTRY_CODE_FROM_CONSTANTS.COLOMBIA,
    phoneCode: 57,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.COMOROS]: {
    label: 'Comoros (+269)',
    code: COUNTRY_CODE_FROM_CONSTANTS.COMOROS,
    phoneCode: 269,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.CONGO_BRAZZAVILLE]: {
    label: 'Congo Brazzaville (+242)',
    code: COUNTRY_CODE_FROM_CONSTANTS.CONGO_BRAZZAVILLE,
    phoneCode: 242,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.CONGO_THE_DEMOCRATIC_REP_OF]: {
    label: 'Congo The Democratic Rep Of (+243)',
    code: COUNTRY_CODE_FROM_CONSTANTS.CONGO_THE_DEMOCRATIC_REP_OF,
    phoneCode: 243,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.COSTA_RICA]: {
    label: 'Costa Rica (+506)',
    code: COUNTRY_CODE_FROM_CONSTANTS.COSTA_RICA,
    phoneCode: 506,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.COTE_D_IVOIRE]: {
    label: 'Cote D Ivoire (+225)',
    code: COUNTRY_CODE_FROM_CONSTANTS.COTE_D_IVOIRE,
    phoneCode: 225,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.CROATIA]: {
    label: 'Croatia (+385)',
    code: COUNTRY_CODE_FROM_CONSTANTS.CROATIA,
    phoneCode: 385,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.CUBA]: {
    label: 'Cuba (+53)',
    code: COUNTRY_CODE_FROM_CONSTANTS.CUBA,
    phoneCode: 53,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.CURACAO]: {
    label: 'Curacao (+599)',
    code: COUNTRY_CODE_FROM_CONSTANTS.CURACAO,
    phoneCode: 599,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.CYPRUS]: {
    label: 'Cyprus (+357)',
    code: COUNTRY_CODE_FROM_CONSTANTS.CYPRUS,
    phoneCode: 357,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.CZECH_REPUBLIC]: {
    label: 'Czech Republic (+420)',
    code: COUNTRY_CODE_FROM_CONSTANTS.CZECH_REPUBLIC,
    phoneCode: 420,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.DENMARK]: {
    label: 'Denmark (+45)',
    code: COUNTRY_CODE_FROM_CONSTANTS.DENMARK,
    phoneCode: 45,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.DJIBOUTI]: {
    label: 'Djibouti (+253)',
    code: COUNTRY_CODE_FROM_CONSTANTS.DJIBOUTI,
    phoneCode: 253,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.DOMINICA]: {
    label: 'Dominica (+1767)',
    code: COUNTRY_CODE_FROM_CONSTANTS.DOMINICA,
    phoneCode: 1767,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.DOMINICAN_REPUBLIC_1]: {
    label: 'Dominican Republic (+1809)',
    code: COUNTRY_CODE_FROM_CONSTANTS.DOMINICAN_REPUBLIC_1,
    phoneCode: 1809,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.DOMINICAN_REPUBLIC_2]: {
    label: 'Dominican Republic (+1829)',
    code: COUNTRY_CODE_FROM_CONSTANTS.DOMINICAN_REPUBLIC_2,
    phoneCode: 1829,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.DOMINICAN_REPUBLIC_3]: {
    label: 'Dominican Republic (+1849)',
    code: COUNTRY_CODE_FROM_CONSTANTS.DOMINICAN_REPUBLIC_3,
    phoneCode: 1849,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ECUADOR]: {
    label: 'Ecuador (+593)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ECUADOR,
    phoneCode: 593,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.EGYPT]: {
    label: 'Egypt (+20)',
    code: COUNTRY_CODE_FROM_CONSTANTS.EGYPT,
    phoneCode: 20,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.EL_SALVADOR]: {
    label: 'El Salvador (+503)',
    code: COUNTRY_CODE_FROM_CONSTANTS.EL_SALVADOR,
    phoneCode: 503,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.EQUATORIAL_GUINEA]: {
    label: 'Equatorial Guinea (+240)',
    code: COUNTRY_CODE_FROM_CONSTANTS.EQUATORIAL_GUINEA,
    phoneCode: 240,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ERITREA]: {
    label: 'Eritrea (+291)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ERITREA,
    phoneCode: 291,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ESTONIA]: {
    label: 'Estonia (+372)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ESTONIA,
    phoneCode: 372,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ESWATINI]: {
    label: 'Eswatini (+268)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ESWATINI,
    phoneCode: 268,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ETHIOPIA]: {
    label: 'Ethiopia (+251)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ETHIOPIA,
    phoneCode: 251,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.FALKLAND_ISLANDS]: {
    label: 'Falkland Islands (+500)',
    code: COUNTRY_CODE_FROM_CONSTANTS.FALKLAND_ISLANDS,
    phoneCode: 500,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.FAROE_ISLANDS]: {
    label: 'Faroe Islands (+298)',
    code: COUNTRY_CODE_FROM_CONSTANTS.FAROE_ISLANDS,
    phoneCode: 298,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.FINLAND]: {
    label: 'Finland (+358)',
    code: COUNTRY_CODE_FROM_CONSTANTS.FINLAND,
    phoneCode: 358,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.FRANCE]: {
    label: 'France (+33)',
    code: COUNTRY_CODE_FROM_CONSTANTS.FRANCE,
    phoneCode: 33,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.FRENCH_GUIANA]: {
    label: 'French Guiana (+594)',
    code: COUNTRY_CODE_FROM_CONSTANTS.FRENCH_GUIANA,
    phoneCode: 594,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.FRENCH_POLYNESIA]: {
    label: 'French Polynesia (+689)',
    code: COUNTRY_CODE_FROM_CONSTANTS.FRENCH_POLYNESIA,
    phoneCode: 689,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.FRENCH_SOUTHERN_TERRITORIES]: {
    label: 'French Southern Territories (+262)',
    code: COUNTRY_CODE_FROM_CONSTANTS.FRENCH_SOUTHERN_TERRITORIES,
    phoneCode: 262,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.GABON]: {
    label: 'Gabon (+241)',
    code: COUNTRY_CODE_FROM_CONSTANTS.GABON,
    phoneCode: 241,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.GAMBIA]: {
    label: 'Gambia (+220)',
    code: COUNTRY_CODE_FROM_CONSTANTS.GAMBIA,
    phoneCode: 220,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.GEORGIA]: {
    label: 'Georgia (+995)',
    code: COUNTRY_CODE_FROM_CONSTANTS.GEORGIA,
    phoneCode: 995,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.GERMANY]: {
    label: 'Germany (+49)',
    code: COUNTRY_CODE_FROM_CONSTANTS.GERMANY,
    phoneCode: 49,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.GHANA]: {
    label: 'Ghana (+233)',
    code: COUNTRY_CODE_FROM_CONSTANTS.GHANA,
    phoneCode: 233,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.GIBRALTAR]: {
    label: 'Gibraltar (+350)',
    code: COUNTRY_CODE_FROM_CONSTANTS.GIBRALTAR,
    phoneCode: 350,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.GREECE]: {
    label: 'Greece (+30)',
    code: COUNTRY_CODE_FROM_CONSTANTS.GREECE,
    phoneCode: 30,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.GREENLAND]: {
    label: 'Greenland (+299)',
    code: COUNTRY_CODE_FROM_CONSTANTS.GREENLAND,
    phoneCode: 299,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.GRENADA]: {
    label: 'Grenada (+1473)',
    code: COUNTRY_CODE_FROM_CONSTANTS.GRENADA,
    phoneCode: 1473,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.GUADELOUPE]: {
    label: 'Guadeloupe (+590)',
    code: COUNTRY_CODE_FROM_CONSTANTS.GUADELOUPE,
    phoneCode: 590,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.GUAM]: {
    label: 'Guam (+1671)',
    code: COUNTRY_CODE_FROM_CONSTANTS.GUAM,
    phoneCode: 1671,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.GUATEMALA]: {
    label: 'Guatemala (+502)',
    code: COUNTRY_CODE_FROM_CONSTANTS.GUATEMALA,
    phoneCode: 502,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.GUERNSEY]: {
    label: 'Guernsey (+441481)',
    code: COUNTRY_CODE_FROM_CONSTANTS.GUERNSEY,
    phoneCode: 441481,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.GUINEA]: {
    label: 'Guinea (+224)',
    code: COUNTRY_CODE_FROM_CONSTANTS.GUINEA,
    phoneCode: 224,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.GUINEA_BISSAU]: {
    label: 'Guinea Bissau (+245)',
    code: COUNTRY_CODE_FROM_CONSTANTS.GUINEA_BISSAU,
    phoneCode: 245,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.GUYANA]: {
    label: 'Guyana (+592)',
    code: COUNTRY_CODE_FROM_CONSTANTS.GUYANA,
    phoneCode: 592,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.HAITI]: {
    label: 'Haiti (+509)',
    code: COUNTRY_CODE_FROM_CONSTANTS.HAITI,
    phoneCode: 509,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.HEARD_AND_MCDONALD_ISLANDS]: {
    label: 'Heard And Mcdonald Islands (+672)',
    code: COUNTRY_CODE_FROM_CONSTANTS.HEARD_AND_MCDONALD_ISLANDS,
    phoneCode: 672,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.HONDURAS]: {
    label: 'Honduras (+504)',
    code: COUNTRY_CODE_FROM_CONSTANTS.HONDURAS,
    phoneCode: 504,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.HONG_KONG_SAR_OF_CHINA]: {
    label: 'Hong Kong -Sar Of China- (+852)',
    code: COUNTRY_CODE_FROM_CONSTANTS.HONG_KONG_SAR_OF_CHINA,
    phoneCode: 852,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.HUNGARY]: {
    label: 'Hungary (+36)',
    code: COUNTRY_CODE_FROM_CONSTANTS.HUNGARY,
    phoneCode: 36,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ICELAND]: {
    label: 'Iceland (+354)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ICELAND,
    phoneCode: 354,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.INDIA]: {
    label: 'India (+91)',
    code: COUNTRY_CODE_FROM_CONSTANTS.INDIA,
    phoneCode: 91,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.INDONESIA]: {
    label: 'Indonesia (+62)',
    code: COUNTRY_CODE_FROM_CONSTANTS.INDONESIA,
    phoneCode: 62,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.IRAN]: {
    label: 'Iran (+98)',
    code: COUNTRY_CODE_FROM_CONSTANTS.IRAN,
    phoneCode: 98,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.IRAQ]: {
    label: 'Iraq (+964)',
    code: COUNTRY_CODE_FROM_CONSTANTS.IRAQ,
    phoneCode: 964,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.IRELAND]: {
    label: 'Ireland (+353)',
    code: COUNTRY_CODE_FROM_CONSTANTS.IRELAND,
    phoneCode: 353,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ISLE_OF_MAN]: {
    label: 'Isle Of Man (+441624)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ISLE_OF_MAN,
    phoneCode: 441624,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ISRAEL]: {
    label: 'Israel (+972)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ISRAEL,
    phoneCode: 972,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ITALY]: {
    label: 'Italy (+39)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ITALY,
    phoneCode: 39,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.JAMAICA]: {
    label: 'Jamaica (+1876)',
    code: COUNTRY_CODE_FROM_CONSTANTS.JAMAICA,
    phoneCode: 1876,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.JAPAN]: {
    label: 'Japan (+81)',
    code: COUNTRY_CODE_FROM_CONSTANTS.JAPAN,
    phoneCode: 81,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.JERSEY]: {
    label: 'Jersey (+441534)',
    code: COUNTRY_CODE_FROM_CONSTANTS.JERSEY,
    phoneCode: 441534,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.JORDAN]: {
    label: 'Jordan (+962)',
    code: COUNTRY_CODE_FROM_CONSTANTS.JORDAN,
    phoneCode: 962,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.KAZAKHSTAN]: {
    label: 'Kazakhstan (+7)',
    code: COUNTRY_CODE_FROM_CONSTANTS.KAZAKHSTAN,
    phoneCode: 7,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.KENYA]: {
    label: 'Kenya (+254)',
    code: COUNTRY_CODE_FROM_CONSTANTS.KENYA,
    phoneCode: 254,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.KIRIBATI]: {
    label: 'Kiribati (+686)',
    code: COUNTRY_CODE_FROM_CONSTANTS.KIRIBATI,
    phoneCode: 686,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.KOREA_DEM_PEOPLES_REP_OF]: {
    label: 'Korea Dem Peoples Rep Of (+850)',
    code: COUNTRY_CODE_FROM_CONSTANTS.KOREA_DEM_PEOPLES_REP_OF,
    phoneCode: 850,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.KOREA_REPUBLIC_OF]: {
    label: 'Korea Republic Of (+82)',
    code: COUNTRY_CODE_FROM_CONSTANTS.KOREA_REPUBLIC_OF,
    phoneCode: 82,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.KUWAIT]: {
    label: 'Kuwait (+965)',
    code: COUNTRY_CODE_FROM_CONSTANTS.KUWAIT,
    phoneCode: 965,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.KYRGYZSTAN]: {
    label: 'Kyrgyzstan (+996)',
    code: COUNTRY_CODE_FROM_CONSTANTS.KYRGYZSTAN,
    phoneCode: 996,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.LAO_PEOPLES_DEM_REPUBLIC]: {
    label: 'Lao Peoples Dem Republic (+856)',
    code: COUNTRY_CODE_FROM_CONSTANTS.LAO_PEOPLES_DEM_REPUBLIC,
    phoneCode: 856,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.LATVIA]: {
    label: 'Latvia (+371)',
    code: COUNTRY_CODE_FROM_CONSTANTS.LATVIA,
    phoneCode: 371,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.LEBANON]: {
    label: 'Lebanon (+961)',
    code: COUNTRY_CODE_FROM_CONSTANTS.LEBANON,
    phoneCode: 961,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.LESOTHO]: {
    label: 'Lesotho (+266)',
    code: COUNTRY_CODE_FROM_CONSTANTS.LESOTHO,
    phoneCode: 266,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.LIBERIA]: {
    label: 'Liberia (+231)',
    code: COUNTRY_CODE_FROM_CONSTANTS.LIBERIA,
    phoneCode: 231,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.LIBYA]: {
    label: 'Libya (+218)',
    code: COUNTRY_CODE_FROM_CONSTANTS.LIBYA,
    phoneCode: 218,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.LIECHTENSTEIN]: {
    label: 'Liechtenstein (+423)',
    code: COUNTRY_CODE_FROM_CONSTANTS.LIECHTENSTEIN,
    phoneCode: 423,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.LITHUANIA]: {
    label: 'Lithuania (+370)',
    code: COUNTRY_CODE_FROM_CONSTANTS.LITHUANIA,
    phoneCode: 370,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.LUXEMBOURG]: {
    label: 'Luxembourg (+352)',
    code: COUNTRY_CODE_FROM_CONSTANTS.LUXEMBOURG,
    phoneCode: 352,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.MACAO_SAR_OF_CHINA]: {
    label: 'Macao -Sar Of China- (+853)',
    code: COUNTRY_CODE_FROM_CONSTANTS.MACAO_SAR_OF_CHINA,
    phoneCode: 853,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.MADAGASCAR]: {
    label: 'Madagascar (+261)',
    code: COUNTRY_CODE_FROM_CONSTANTS.MADAGASCAR,
    phoneCode: 261,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.MALAWI]: {
    label: 'Malawi (+265)',
    code: COUNTRY_CODE_FROM_CONSTANTS.MALAWI,
    phoneCode: 265,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.MALAYSIA]: {
    label: 'Malaysia (+60)',
    code: COUNTRY_CODE_FROM_CONSTANTS.MALAYSIA,
    phoneCode: 60,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.MALDIVES]: {
    label: 'Maldives (+960)',
    code: COUNTRY_CODE_FROM_CONSTANTS.MALDIVES,
    phoneCode: 960,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.MALI]: {
    label: 'Mali (+223)',
    code: COUNTRY_CODE_FROM_CONSTANTS.MALI,
    phoneCode: 223,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.MALTA]: {
    label: 'Malta (+356)',
    code: COUNTRY_CODE_FROM_CONSTANTS.MALTA,
    phoneCode: 356,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.MARSHALL_ISLANDS]: {
    label: 'Marshall Islands (+692)',
    code: COUNTRY_CODE_FROM_CONSTANTS.MARSHALL_ISLANDS,
    phoneCode: 692,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.MARTINIQUE]: {
    label: 'Martinique (+596)',
    code: COUNTRY_CODE_FROM_CONSTANTS.MARTINIQUE,
    phoneCode: 596,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.MAURITANIA]: {
    label: 'Mauritania (+222)',
    code: COUNTRY_CODE_FROM_CONSTANTS.MAURITANIA,
    phoneCode: 222,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.MAURITIUS]: {
    label: 'Mauritius (+230)',
    code: COUNTRY_CODE_FROM_CONSTANTS.MAURITIUS,
    phoneCode: 230,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.MAYOTTE]: {
    label: 'Mayotte (+262)',
    code: COUNTRY_CODE_FROM_CONSTANTS.MAYOTTE,
    phoneCode: 262,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.MEXICO]: {
    label: 'Mexico (+52)',
    code: COUNTRY_CODE_FROM_CONSTANTS.MEXICO,
    phoneCode: 52,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.MICRONESIA]: {
    label: 'Micronesia (+691)',
    code: COUNTRY_CODE_FROM_CONSTANTS.MICRONESIA,
    phoneCode: 691,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.MOLDOVA]: {
    label: 'Moldova (+373)',
    code: COUNTRY_CODE_FROM_CONSTANTS.MOLDOVA,
    phoneCode: 373,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.MONACO]: {
    label: 'Monaco (+377)',
    code: COUNTRY_CODE_FROM_CONSTANTS.MONACO,
    phoneCode: 377,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.MONGOLIA]: {
    label: 'Mongolia (+976)',
    code: COUNTRY_CODE_FROM_CONSTANTS.MONGOLIA,
    phoneCode: 976,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.MONTENEGRO]: {
    label: 'Montenegro (+382)',
    code: COUNTRY_CODE_FROM_CONSTANTS.MONTENEGRO,
    phoneCode: 382,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.MONTSERRAT]: {
    label: 'Montserrat (+1664)',
    code: COUNTRY_CODE_FROM_CONSTANTS.MONTSERRAT,
    phoneCode: 1664,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.MOROCCO]: {
    label: 'Morocco (+212)',
    code: COUNTRY_CODE_FROM_CONSTANTS.MOROCCO,
    phoneCode: 212,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.MOZAMBIQUE]: {
    label: 'Mozambique (+258)',
    code: COUNTRY_CODE_FROM_CONSTANTS.MOZAMBIQUE,
    phoneCode: 258,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.MYANMAR]: {
    label: 'Myanmar (+95)',
    code: COUNTRY_CODE_FROM_CONSTANTS.MYANMAR,
    phoneCode: 95,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.NAMIBIA]: {
    label: 'Namibia (+264)',
    code: COUNTRY_CODE_FROM_CONSTANTS.NAMIBIA,
    phoneCode: 264,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.NAURU]: {
    label: 'Nauru (+674)',
    code: COUNTRY_CODE_FROM_CONSTANTS.NAURU,
    phoneCode: 674,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.NEPAL]: {
    label: 'Nepal (+977)',
    code: COUNTRY_CODE_FROM_CONSTANTS.NEPAL,
    phoneCode: 977,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.NETHERLANDS]: {
    label: 'Netherlands (+31)',
    code: COUNTRY_CODE_FROM_CONSTANTS.NETHERLANDS,
    phoneCode: 31,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.NEW_CALEDONIA]: {
    label: 'New Caledonia (+687)',
    code: COUNTRY_CODE_FROM_CONSTANTS.NEW_CALEDONIA,
    phoneCode: 687,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.NICARAGUA]: {
    label: 'Nicaragua (+505)',
    code: COUNTRY_CODE_FROM_CONSTANTS.NICARAGUA,
    phoneCode: 505,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.NIGER]: {
    label: 'Niger (+227)',
    code: COUNTRY_CODE_FROM_CONSTANTS.NIGER,
    phoneCode: 227,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.NIGERIA]: {
    label: 'Nigeria (+234)',
    code: COUNTRY_CODE_FROM_CONSTANTS.NIGERIA,
    phoneCode: 234,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.NIUE]: {
    label: 'Niue (+683)',
    code: COUNTRY_CODE_FROM_CONSTANTS.NIUE,
    phoneCode: 683,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.NORFOLK_ISLAND]: {
    label: 'Norfolk Island (+672)',
    code: COUNTRY_CODE_FROM_CONSTANTS.NORFOLK_ISLAND,
    phoneCode: 672,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.NORTH_MACEDONIA]: {
    label: 'North Macedonia (+389)',
    code: COUNTRY_CODE_FROM_CONSTANTS.NORTH_MACEDONIA,
    phoneCode: 389,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.NORTHERN_MARIANA_ISLANDS]: {
    label: 'Northern Mariana Islands (+1670)',
    code: COUNTRY_CODE_FROM_CONSTANTS.NORTHERN_MARIANA_ISLANDS,
    phoneCode: 1670,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.NORWAY]: {
    label: 'Norway (+47)',
    code: COUNTRY_CODE_FROM_CONSTANTS.NORWAY,
    phoneCode: 47,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.OMAN]: {
    label: 'Oman (+968)',
    code: COUNTRY_CODE_FROM_CONSTANTS.OMAN,
    phoneCode: 968,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.PAKISTAN]: {
    label: 'Pakistan (+92)',
    code: COUNTRY_CODE_FROM_CONSTANTS.PAKISTAN,
    phoneCode: 92,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.PALAU]: {
    label: 'Palau (+680)',
    code: COUNTRY_CODE_FROM_CONSTANTS.PALAU,
    phoneCode: 680,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.PALESTINE_STATE_OF]: {
    label: 'Palestine - State Of (+970)',
    code: COUNTRY_CODE_FROM_CONSTANTS.PALESTINE_STATE_OF,
    phoneCode: 970,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.PANAMA]: {
    label: 'Panama (+507)',
    code: COUNTRY_CODE_FROM_CONSTANTS.PANAMA,
    phoneCode: 507,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.PARAGUAY]: {
    label: 'Paraguay (+595)',
    code: COUNTRY_CODE_FROM_CONSTANTS.PARAGUAY,
    phoneCode: 595,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.PERU]: {
    label: 'Peru (+51)',
    code: COUNTRY_CODE_FROM_CONSTANTS.PERU,
    phoneCode: 51,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.PHILIPPINES]: {
    label: 'Philippines (+63)',
    code: COUNTRY_CODE_FROM_CONSTANTS.PHILIPPINES,
    phoneCode: 63,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.PITCAIRN]: {
    label: 'Pitcairn (+64)',
    code: COUNTRY_CODE_FROM_CONSTANTS.PITCAIRN,
    phoneCode: 64,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.POLAND]: {
    label: 'Poland (+48)',
    code: COUNTRY_CODE_FROM_CONSTANTS.POLAND,
    phoneCode: 48,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.PORTUGAL]: {
    label: 'Portugal (+351)',
    code: COUNTRY_CODE_FROM_CONSTANTS.PORTUGAL,
    phoneCode: 351,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.PUERTO_RICO]: {
    label: 'Puerto Rico (+1787)',
    code: COUNTRY_CODE_FROM_CONSTANTS.PUERTO_RICO,
    phoneCode: 1787,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.PUERTO_RICO]: {
    label: 'Puerto Rico (+1939)',
    code: COUNTRY_CODE_FROM_CONSTANTS.PUERTO_RICO,
    phoneCode: 1939,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.QATAR]: {
    label: 'Qatar (+974)',
    code: COUNTRY_CODE_FROM_CONSTANTS.QATAR,
    phoneCode: 974,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.REUNION]: {
    label: 'Reunion (+262)',
    code: COUNTRY_CODE_FROM_CONSTANTS.REUNION,
    phoneCode: 262,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ROMANIA]: {
    label: 'Romania (+40)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ROMANIA,
    phoneCode: 40,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.RUSSIA]: {
    label: 'Russia (+7)',
    code: COUNTRY_CODE_FROM_CONSTANTS.RUSSIA,
    phoneCode: 7,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.RWANDA]: {
    label: 'Rwanda (+250)',
    code: COUNTRY_CODE_FROM_CONSTANTS.RWANDA,
    phoneCode: 250,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SAINT_BARTHELEMY]: {
    label: 'Saint Barthelemy (+590)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SAINT_BARTHELEMY,
    phoneCode: 590,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SAINT_KITTS_AND_NEVIS]: {
    label: 'Saint Kitts And Nevis (+1869)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SAINT_KITTS_AND_NEVIS,
    phoneCode: 1869,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SAINT_MARTIN]: {
    label: 'Saint Martin (+590)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SAINT_MARTIN,
    phoneCode: 590,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SAN_MARINO]: {
    label: 'San Marino (+378)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SAN_MARINO,
    phoneCode: 378,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SAO_TOME_AND_PRINCIPE]: {
    label: 'Sao Tome And Principe (+239)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SAO_TOME_AND_PRINCIPE,
    phoneCode: 239,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SAUDI_ARABIA]: {
    label: 'Saudi Arabia (+966)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SAUDI_ARABIA,
    phoneCode: 966,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SENEGAL]: {
    label: 'Senegal (+221)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SENEGAL,
    phoneCode: 221,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SERBIA]: {
    label: 'Serbia (+381)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SERBIA,
    phoneCode: 381,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SEYCHELLES]: {
    label: 'Seychelles (+248)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SEYCHELLES,
    phoneCode: 248,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SIERRA_LEONE]: {
    label: 'Sierra Leone (+232)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SIERRA_LEONE,
    phoneCode: 232,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SINGAPORE]: {
    label: 'Singapore (+65)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SINGAPORE,
    phoneCode: 65,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SINT_MAARTEN]: {
    label: 'Sint Maarten (+1721)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SINT_MAARTEN,
    phoneCode: 1721,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SLOVAKIA]: {
    label: 'Slovakia (+421)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SLOVAKIA,
    phoneCode: 421,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SLOVENIA]: {
    label: 'Slovenia (+386)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SLOVENIA,
    phoneCode: 386,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SOMALIA]: {
    label: 'Somalia (+252)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SOMALIA,
    phoneCode: 252,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SOUTH_AFRICA]: {
    label: 'South Africa (+27)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SOUTH_AFRICA,
    phoneCode: 27,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SOUTH_GEORGIA_AND_SANDWICH_ISL]: {
    label: 'South Georgia And Sandwich Isl (+500)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SOUTH_GEORGIA_AND_SANDWICH_ISL,
    phoneCode: 500,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SOUTH_SUDAN]: {
    label: 'South Sudan (+211)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SOUTH_SUDAN,
    phoneCode: 211,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SPAIN]: {
    label: 'Spain (+34)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SPAIN,
    phoneCode: 34,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SRI_LANKA]: {
    label: 'Sri Lanka (+94)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SRI_LANKA,
    phoneCode: 94,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ST_VINCENT_AND_THE_GRENADINES]: {
    label: 'St Vincent And The Grenadines (+1784)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ST_VINCENT_AND_THE_GRENADINES,
    phoneCode: 1784,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ST_HELENA_ISLAND]: {
    label: 'St. Helena Island (+290)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ST_HELENA_ISLAND,
    phoneCode: 290,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ST_LUCIA]: {
    label: 'St. Lucia (+1758)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ST_LUCIA,
    phoneCode: 1758,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ST_PIERRE_AND_MIQUELON]: {
    label: 'St. Pierre And Miquelon (+508)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ST_PIERRE_AND_MIQUELON,
    phoneCode: 508,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SUDAN]: {
    label: 'Sudan (+249)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SUDAN,
    phoneCode: 249,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SURINAME]: {
    label: 'Suriname (+597)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SURINAME,
    phoneCode: 597,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SVALBARD_AND_JAN_MAYEN]: {
    label: 'Svalbard And Jan Mayen (+47)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SVALBARD_AND_JAN_MAYEN,
    phoneCode: 47,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SWEDEN]: {
    label: 'Sweden (+46)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SWEDEN,
    phoneCode: 46,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SWITZERLAND]: {
    label: 'Switzerland (+41)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SWITZERLAND,
    phoneCode: 41,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.SYRIAN_ARAB_REPUBLIC]: {
    label: 'Syrian Arab Republic (+963)',
    code: COUNTRY_CODE_FROM_CONSTANTS.SYRIAN_ARAB_REPUBLIC,
    phoneCode: 963,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.TAIWAN]: {
    label: 'Taiwan (+886)',
    code: COUNTRY_CODE_FROM_CONSTANTS.TAIWAN,
    phoneCode: 886,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.TAJIKISTAN]: {
    label: 'Tajikistan (+992)',
    code: COUNTRY_CODE_FROM_CONSTANTS.TAJIKISTAN,
    phoneCode: 992,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.TANZANIA_UNITED_REPUBLIC]: {
    label: 'Tanzania-United Republic (+255)',
    code: COUNTRY_CODE_FROM_CONSTANTS.TANZANIA_UNITED_REPUBLIC,
    phoneCode: 255,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.THAILAND]: {
    label: 'Thailand (+66)',
    code: COUNTRY_CODE_FROM_CONSTANTS.THAILAND,
    phoneCode: 66,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.TIMOR_LESTE]: {
    label: 'Timor Leste (+670)',
    code: COUNTRY_CODE_FROM_CONSTANTS.TIMOR_LESTE,
    phoneCode: 670,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.TOGO]: {
    label: 'Togo (+228)',
    code: COUNTRY_CODE_FROM_CONSTANTS.TOGO,
    phoneCode: 228,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.TOKELAU]: {
    label: 'Tokelau (+690)',
    code: COUNTRY_CODE_FROM_CONSTANTS.TOKELAU,
    phoneCode: 690,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.TRINIDAD_AND_TOBAGO]: {
    label: 'Trinidad And Tobago (+1868)',
    code: COUNTRY_CODE_FROM_CONSTANTS.TRINIDAD_AND_TOBAGO,
    phoneCode: 1868,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.TUNISIA]: {
    label: 'Tunisia (+216)',
    code: COUNTRY_CODE_FROM_CONSTANTS.TUNISIA,
    phoneCode: 216,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.TURKIYE]: {
    label: 'Turkiye (+90)',
    code: COUNTRY_CODE_FROM_CONSTANTS.TURKIYE,
    phoneCode: 90,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.TURKMENISTAN]: {
    label: 'Turkmenistan (+993)',
    code: COUNTRY_CODE_FROM_CONSTANTS.TURKMENISTAN,
    phoneCode: 993,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.TURKS_AND_CAICOS_ISLANDS]: {
    label: 'Turks And Caicos Islands (+1649)',
    code: COUNTRY_CODE_FROM_CONSTANTS.TURKS_AND_CAICOS_ISLANDS,
    phoneCode: 1649,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.TUVALU]: {
    label: 'Tuvalu (+688)',
    code: COUNTRY_CODE_FROM_CONSTANTS.TUVALU,
    phoneCode: 688,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.US_MINOR_OUTLYING_ISLANDS]: {
    label: 'U.S. Minor Outlying Islands (+1)',
    code: COUNTRY_CODE_FROM_CONSTANTS.US_MINOR_OUTLYING_ISLANDS,
    phoneCode: 1,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.UGANDA]: {
    label: 'Uganda (+256)',
    code: COUNTRY_CODE_FROM_CONSTANTS.UGANDA,
    phoneCode: 256,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.UKRAINE]: {
    label: 'Ukraine (+380)',
    code: COUNTRY_CODE_FROM_CONSTANTS.UKRAINE,
    phoneCode: 380,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.UNITED_ARAB_EMIRATES]: {
    label: 'United Arab Emirates (+971)',
    code: COUNTRY_CODE_FROM_CONSTANTS.UNITED_ARAB_EMIRATES,
    phoneCode: 971,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.UNITED_KINGDOM]: {
    label: 'United Kingdom (+44)',
    code: COUNTRY_CODE_FROM_CONSTANTS.UNITED_KINGDOM,
    phoneCode: 44,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.UNITED_STATES_OF_AMERICA]: {
    label: 'United States Of America (+1)',
    code: COUNTRY_CODE_FROM_CONSTANTS.UNITED_STATES_OF_AMERICA,
    phoneCode: 1,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.URUGUAY]: {
    label: 'Uruguay (+598)',
    code: COUNTRY_CODE_FROM_CONSTANTS.URUGUAY,
    phoneCode: 598,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.UZBEKISTAN]: {
    label: 'Uzbekistan (+998)',
    code: COUNTRY_CODE_FROM_CONSTANTS.UZBEKISTAN,
    phoneCode: 998,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.VATICAN]: {
    label: 'Vatican (+379)',
    code: COUNTRY_CODE_FROM_CONSTANTS.VATICAN,
    phoneCode: 379,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.VENEZUELA]: {
    label: 'Venezuela (+58)',
    code: COUNTRY_CODE_FROM_CONSTANTS.VENEZUELA,
    phoneCode: 58,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.VIETNAM]: {
    label: 'Vietnam (+84)',
    code: COUNTRY_CODE_FROM_CONSTANTS.VIETNAM,
    phoneCode: 84,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.VIRGIN_ISLANDS_BRITISH]: {
    label: 'Virgin Islands-British (+1284)',
    code: COUNTRY_CODE_FROM_CONSTANTS.VIRGIN_ISLANDS_BRITISH,
    phoneCode: 1284,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.VIRGIN_ISLANDS_UNITED_STATES]: {
    label: 'Virgin Islands-United States (+1340)',
    code: COUNTRY_CODE_FROM_CONSTANTS.VIRGIN_ISLANDS_UNITED_STATES,
    phoneCode: 1340,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.WALLIS_AND_FUTUNA_ISLANDS]: {
    label: 'Wallis And Futuna Islands (+681)',
    code: COUNTRY_CODE_FROM_CONSTANTS.WALLIS_AND_FUTUNA_ISLANDS,
    phoneCode: 681,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.WESTERN_SAHARA]: {
    label: 'Western Sahara (+212)',
    code: COUNTRY_CODE_FROM_CONSTANTS.WESTERN_SAHARA,
    phoneCode: 212,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.YEMEN_REPUBLIC]: {
    label: 'Yemen Republic (+967)',
    code: COUNTRY_CODE_FROM_CONSTANTS.YEMEN_REPUBLIC,
    phoneCode: 967,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ZAMBIA]: {
    label: 'Zambia (+260)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ZAMBIA,
    phoneCode: 260,
  },
  [COUNTRY_CODE_FROM_CONSTANTS.ZIMBABWE]: {
    label: 'Zimbabwe (+263)',
    code: COUNTRY_CODE_FROM_CONSTANTS.ZIMBABWE,
    phoneCode: 263,
  },
};

const firstLevelCountryOption = {
  bottomSeparator: true,
  options: [
    {
      label: 'Australia',
      value: COUNTRY_CODE.AUSTRALIA,
    },
    {
      label: 'New Zealand',
      value: COUNTRY_CODE.NEW_ZEALAND,
    },
  ],
};

const secondLevelCountryOptions = [
  {
    label: 'Christmas Island',
    value: COUNTRY_CODE.CHRISTMAS_ISLAND,
  },
  {
    label: 'Cocos Islands',
    value: COUNTRY_CODE.COCOS_ISLANDS,
  },
  {
    label: 'Cook Islands',
    value: COUNTRY_CODE.COOK_ISLANDS,
  },
  {
    label: 'Fiji',
    value: COUNTRY_CODE.FIJI,
  },
  {
    label: 'Papua New Guinea',
    value: COUNTRY_CODE.PAPUA_NEW_GUINEA,
  },
  {
    label: 'Samoa',
    value: COUNTRY_CODE.SAMOA,
  },
  {
    label: 'Solomon Islands',
    value: COUNTRY_CODE.SOLOMON_ISLANDS,
  },
  {
    label: 'Tonga',
    value: COUNTRY_CODE.TONGA,
  },
  {
    label: 'Vanuatu',
    value: COUNTRY_CODE.VANUATU,
  },
];

export const defaultCountryOptions = [
  firstLevelCountryOption,
  {
    options: [...secondLevelCountryOptions],
  },
];

export const countryOptions = [
  firstLevelCountryOption,
  {
    options: [
      ...secondLevelCountryOptions,
      {
        label: 'My country is not listed',
        value: COUNTRY_CODE.NOT_LISTED,
      },
    ],
  },
];

export const defaultCountryPhoneCodeOptions = [
  {
    label: '+61 AU',
    value: COUNTRY_CODE.AUSTRALIA,
  },
  {
    label: '+64 NZ',
    value: COUNTRY_CODE.NEW_ZEALAND,
  },
  {
    label: '+61 CX',
    value: COUNTRY_CODE.CHRISTMAS_ISLAND,
  },
  {
    label: '+61 CC',
    value: COUNTRY_CODE.COCOS_ISLANDS,
  },
  {
    label: '+682 CK',
    value: COUNTRY_CODE.COOK_ISLANDS,
  },
  {
    label: '+679 FJ',
    value: COUNTRY_CODE.FIJI,
  },
  {
    label: '+675 PG',
    value: COUNTRY_CODE.PAPUA_NEW_GUINEA,
  },
  {
    label: '+685 WS',
    value: COUNTRY_CODE.SAMOA,
  },
  {
    label: '+677 SB',
    value: COUNTRY_CODE.SOLOMON_ISLANDS,
  },
  {
    label: '+676 TO',
    value: COUNTRY_CODE.TONGA,
  },
  {
    label: '+678 VU',
    value: COUNTRY_CODE.VANUATU,
  },
];

export const countryPhoneCodeOptions = [
  ...defaultCountryPhoneCodeOptions,
  {
    label: "Can't find my country code - enter number manually",
    value: '',
  },
];

export const countryPhoneCodeOptionsVariation2 = [
  ...defaultCountryPhoneCodeOptions,
  {
    label: 'Other',
    value: '',
  },
];

export const stateOptions = [
  {
    label: 'New South Wales',
    value: 'NSW',
  },
  {
    label: 'Victoria',
    value: 'VIC',
  },
  {
    label: 'Queensland',
    value: 'QLD',
  },
  {
    label: 'Tasmania',
    value: 'TAS',
  },
  {
    label: 'Western Australia',
    value: 'WA',
  },
  {
    label: 'South Australia',
    value: 'SA',
  },
  {
    label: 'Australian Capital Territory',
    value: 'ACT',
  },
  {
    label: 'Northern Territory',
    value: 'NT',
  },
];

export const phoneTypeOptions = [
  {
    label: 'Mobile',
    value: PHONE_TYPE.MOBILE,
  },
  {
    label: 'Landline',
    value: PHONE_TYPE.LANDLINE,
  },
];

export const addressTypeOptions = [
  {
    label: 'Home',
    value: ADDRESS_TYPE.HOME,
  },
  {
    label: 'Business',
    value: ADDRESS_TYPE.BUSINESS,
  },
];

export const genderOptions = [
  {
    label: 'Male',
    value: GENDER.MALE,
  },
  {
    label: 'Female',
    value: GENDER.FEMALE,
  },
];

export const securityQuestionOptions = [
  {
    label: 'What was the name of the first school you attend?',
    value: '1',
  },
  {
    label: "What is your mother's maiden name?",
    value: '2',
  },
  {
    label: 'What was the make of your first car?',
    value: '3',
  },
  {
    label: "What is your grandmother's first name?",
    value: '4',
  },
  {
    label: 'Who is your favourite sporting team?',
    value: '5',
  },
  {
    label: 'What is the country of your dream holiday?',
    value: '6',
  },
  {
    label: 'What is the name of the first street you lived on?',
    value: '7',
  },
  {
    label: "What was your first pet's name?",
    value: '8',
  },
];

export const personTitleOptions = [
  {
    label: 'Mr',
    value: PERSON_TITLE.MR,
  },
  {
    label: 'Mstr',
    value: PERSON_TITLE.MSTR,
  },
  {
    label: 'Mrs',
    value: PERSON_TITLE.MRS,
  },
  {
    label: 'Ms',
    value: PERSON_TITLE.MS,
  },
  {
    label: 'Miss',
    value: PERSON_TITLE.MISS,
  },
  {
    label: 'Dr',
    value: PERSON_TITLE.DOCTOR,
  },
];

export const personTitleWithAdditionalOptions = [
  ...personTitleOptions,
  {
    label: 'Lady',
    value: PERSON_TITLE_ADDITIONAL.LADY,
  },
  {
    label: 'Lord',
    value: PERSON_TITLE_ADDITIONAL.LORD,
  },
  {
    label: 'Prof',
    value: PERSON_TITLE_ADDITIONAL.PROF,
  },
  {
    label: 'HRH',
    value: PERSON_TITLE_ADDITIONAL.HRH,
  },
  {
    label: 'Capt',
    value: PERSON_TITLE_ADDITIONAL.CAPT,
  },
  {
    label: 'Fr',
    value: PERSON_TITLE_ADDITIONAL.FR,
  },
  {
    label: 'Fr',
    value: PERSON_TITLE_ADDITIONAL.FR,
  },
  {
    label: 'Gen',
    value: PERSON_TITLE_ADDITIONAL.GEN,
  },
];
