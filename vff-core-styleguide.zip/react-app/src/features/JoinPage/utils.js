import _ from 'lodash';
import qs from 'qs';
import { validateFormField, normalizeFormField } from '../../components/Form/utils';
import { personTitleOptions, countryPhoneCodeOptions, countriesByCode } from './referenceData';
import { isElementVisible, smoothScrollToElement } from '../../utils/common';
import {
  ADDRESS_TYPE,
  COUNTRY_CODE,
  ELEMENT_ID,
  GENDER,
  MOBILE_STICKY_HEADER_HEIGHT,
  PERSON_TITLE,
  STEP_FIELDS,
  STEPS,
  STEPS_LIST,
} from './constants';

export function getStepId(stepIndex) {
  return STEPS_LIST[stepIndex].id;
}

export function stepIndexToContainerId(stepIndex) {
  return `step_${stepIndex + 1}`;
}

export function getStepElement(stepIndex) {
  return document.getElementById(stepIndexToContainerId(stepIndex));
}

export function getPercentageOfElementVisible(element) {
  const bounding = element.getBoundingClientRect();
  const viewportHeight = window.innerHeight || document.documentElement.clientHeight;

  const pxInView =
    bounding.top > 0
      ? Math.max(0, viewportHeight - bounding.top)
      : Math.max(0, Math.min(bounding.top + bounding.height, viewportHeight));

  return Math.round((pxInView / viewportHeight) * 100);
}

/**
 * Safely gets the actual value for form fields ie. makes getting dropdown field
 * values easier
 *
 * @example
 *  getFieldValue({ fruit: { label: 'Apples', value: 'apples' }})
 *  > "apples"
 *
 * @param {Object} currentFormValues
 * @returns {function(*): *}
 */
export function getFieldValue(currentFormValues) {
  return (fieldName) => {
    const rawValue = currentFormValues[fieldName];

    return _.hasIn(rawValue, 'value') ? rawValue.value : rawValue;
  };
}

export function shouldShowField(fieldName, currentFormValues) {
  const value = getFieldValue(currentFormValues);

  switch (fieldName) {
    case 'gender':
      return value('title') === PERSON_TITLE.DOCTOR;

    case 'company':
    case 'jobTitle':
      return value('addressType') === ADDRESS_TYPE.BUSINESS;

    case 'state':
      return value('country') === COUNTRY_CODE.AUSTRALIA;

    case 'postCode':
      return value('country') === COUNTRY_CODE.AUSTRALIA || value('country') === COUNTRY_CODE.NEW_ZEALAND;

    case 'phoneCountryCode':
      return value('phoneCountryCode') !== '';

    default:
      return true;
  }
}

/**
 * Builds the telephone number for the API call
 *
 * @param {Object} param
 * @param {string} param.phoneCountryCode - eg. 'AU', 'NZ'
 * @param {string} param.phoneNumber - eg. '0444444444'
 * @returns {string} - eg. +61444444444
 */

export function getTelephoneNumber(phNumber) {
  /**
   *  In case a user adds + in the beginning of the phone number
   *  according to the business rules mentioned in endpoint mapping
   *  the phone number should be passed without the '+' sign in the
   *  request
   *  eg: getTelephoneNumber('+1234567') => returns: '1234567'
   */
  const phoneNumberWithoutLeadingPlus = /^[+]/.test(phNumber) ? phNumber.substr(1) : phNumber;
  return phoneNumberWithoutLeadingPlus;
}

export function getCurrentlyVisibleFields({ currentFormValues, currentStepIndex }) {
  const fields = _.flatten(STEPS_LIST.slice(0, currentStepIndex + 1).map((step) => STEP_FIELDS[step.id]));

  return fields.filter((field) => shouldShowField(field, currentFormValues));
}

export function getInitialTouchedFields(initialValues) {
  // Get the fields that have initial values set
  return _.entries(initialValues)
    .filter((entry) => !!entry[1])
    .map(([fieldName]) => fieldName);
}

/**
 * Checks if the given field is the last remaining unfilled/invalid field in
 * the step
 */
function isFinalFieldBeforeSubmit({ fieldName, values, currentStepIndex, errors }) {
  const currentVisibleFields = getCurrentlyVisibleFields({
    currentFormValues: values,
    currentStepIndex,
  });

  const otherVisibleFields = currentVisibleFields.filter((stepField) => stepField !== fieldName);

  return otherVisibleFields.every((field) => !errors[field]);
}

function stepValidStateGetter({ errors, values, touchedFields, fieldValidators, currentStepIndex }) {
  return (stepId) => {
    const visibleFieldsInStep = STEP_FIELDS[stepId].filter((fieldName) => shouldShowField(fieldName, values));

    function isValid(fieldName) {
      const hasError = !!errors[fieldName];
      const isTouched = touchedFields.includes(fieldName);

      // Field has been filled, and there is no detected error, so must be valid
      if (isTouched && !hasError) {
        return true;
      }

      // Always run validation on the last field in the form before submit, so that
      // we don't have to wait until blurring to flag this step as valid/invalid
      if (
        isFinalFieldBeforeSubmit({
          fieldName,
          touchedFields,
          errors,
          currentStepIndex,
          values,
        })
      ) {
        const fieldErrorMessage = validateFormField(values[fieldName], fieldValidators[fieldName], values);

        return !fieldErrorMessage;
      }

      // Field is not valid
      return false;
    }

    return visibleFieldsInStep.every(isValid);
  };
}

export function getStepValidStates({ errors, values, touchedFields, fieldValidators, currentStepIndex }) {
  const isStepValid = stepValidStateGetter({
    errors,
    values,
    touchedFields,
    fieldValidators,
    currentStepIndex,
  });

  return {
    [STEPS.PERSONAL.id]: isStepValid(STEPS.PERSONAL.id),
    [STEPS.ACCOUNT.id]: isStepValid(STEPS.ACCOUNT.id),
    [STEPS.CONTACT.id]: isStepValid(STEPS.CONTACT.id),
  };
}

export function checkCanSubmit({ currentStepIndex, stepValidStates }) {
  return _.range(0, currentStepIndex + 1).every((stepIndex) => stepValidStates[getStepId(stepIndex)]);
}

export function remToPx(rem) {
  return rem * parseFloat(getComputedStyle(document.documentElement).fontSize);
}

export function getJoinParameters() {
  const query = qs.parse(window.location.search, { ignoreQueryPrefix: true });

  return {
    channelName: _.toLower(query.source),
    promoCode: _.toLower(query.promocode),
  };
}

export function getPartner(partners) {
  const { channelName, promoCode } = getJoinParameters();

  // Try both channelName + promoCode
  if (promoCode) {
    const resultForBothParams = _.find(partners, { channelName, promoCode });

    if (resultForBothParams) {
      return resultForBothParams;
    }
  }

  // Search channelName only
  return _.find(partners, (partner) => partner.channelName === channelName && partner.promoCode === undefined);
}

function getStickyHeaderHeight() {
  const stickyHeaderElement = document.getElementById(ELEMENT_ID.PROGRESS_NAV_MOBILE);

  const isShowingStickyHeader = isElementVisible(stickyHeaderElement);

  return isShowingStickyHeader ? MOBILE_STICKY_HEADER_HEIGHT : 0;
}

export function scrollToElementId(elementId) {
  const element = document.getElementById(elementId);

  // An offset so that the top of the given element isn't at the very edge
  // of the viewport, purely for aesthetics
  const scrollOffset = remToPx('1.8');

  const offset = scrollOffset + getStickyHeaderHeight();

  smoothScrollToElement(element, offset);
}

export function getGender(title, currentGender) {
  switch (title) {
    case PERSON_TITLE.MR:
    case PERSON_TITLE.MSTR:
      return GENDER.MALE;

    case PERSON_TITLE.MISS:
    case PERSON_TITLE.MS:
    case PERSON_TITLE.MRS:
      return GENDER.FEMALE;

    case PERSON_TITLE.DOCTOR:
    default:
      return currentGender;
  }
}

export function getTouchedFields(initialValues) {
  return _.entries(initialValues).map(([fieldName]) => fieldName);
}

export function getTitleValue(param) {
  const isTitleExist = _.find(personTitleOptions, { label: _.capitalize(param), value: _.toUpper(param) });
  if (isTitleExist) {
    return { value: _.toUpper(param), label: _.capitalize(param) };
  }
  return null;
}

export function getCountryCodeValue(param) {
  if (encodeURIComponent(param) === "''" || _.lowerCase(param) === 'none') {
    return { value: '', label: '' };
  }
  const countryName = _.toUpper(param);
  const countryCallingCode = _.get(countriesByCode, `${countryName}.phoneCode`);
  const isCountryCodeExist = _.find(countryPhoneCodeOptions, {
    label: `+${countryCallingCode} ${_.toUpper(param)}`,
    value: _.toUpper(param),
  });
  if (isCountryCodeExist) {
    return { value: _.toUpper(param), label: `+${countryCallingCode} ${_.toUpper(param)} ` };
  }
  return null;
}

export function getInitialNormalizedValue(values, fieldNormalizers) {
  const initialNormalizedValue = {};
  Object.keys(values).forEach((fieldName) => {
    const normalizeValue = normalizeFormField(values[fieldName], fieldNormalizers[fieldName]);
    if (normalizeValue) {
      initialNormalizedValue[fieldName] = normalizeValue;
    }
  });
  return initialNormalizedValue;
}

export function getInitialError(values, fieldValidators) {
  const initialFieldError = {};
  Object.keys(values).forEach((fieldName) => {
    const getError = validateFormField(values[fieldName], fieldValidators[fieldName], values);
    if (getError) {
      initialFieldError[fieldName] = getError;
    } else {
      delete initialFieldError[fieldName];
    }
  });
  return initialFieldError;
}
