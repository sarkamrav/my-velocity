export const STEPS = {
  PERSONAL: {
    id: 'personal',
    label: 'Personal Details',
  },
  ACCOUNT: {
    id: 'account',
    label: 'Account Details',
  },
  CONTACT: {
    id: 'contact',
    label: 'Contact Details',
  },
};

export const STEP_FIELDS = {
  [STEPS.PERSONAL.id]: ['country', 'title', 'gender', 'firstName', 'lastName', 'dateOfBirth', 'email'],
  [STEPS.ACCOUNT.id]: [
    'newPassword',
    'newPasswordConfirm',
    'securityQuestion',
    'securityAnswer',
    'pinNumber',
    'pinNumberConfirm',
  ],
  [STEPS.CONTACT.id]: ['addressType', 'postCode', 'suburb', 'state', 'phoneType', 'phoneNumber', 'consentConfirmed'],
};

// List of steps (Must be in order)
export const STEPS_LIST = [STEPS.PERSONAL, STEPS.ACCOUNT, STEPS.CONTACT];

export const PHONE_TYPE = {
  MOBILE: 'M',
  LANDLINE: 'H',
};

export const ADDRESS_TYPE = {
  HOME: 'HOME',
  BUSINESS: 'BUSINESS',
};

export const GENDER = {
  MALE: 'MALE',
  FEMALE: 'FEMALE',
};

export const PERSON_TITLE = {
  MR: 'MR',
  MSTR: 'MSTR',
  MRS: 'MRS',
  MS: 'MS',
  MISS: 'MISS',
  DOCTOR: 'DR',
};

export const PERSON_TITLE_ADDITIONAL = {
  LADY: 'LADY',
  LORD: 'LORD',
  PROF: 'PROF',
  HRH: 'HRH',
  CAPT: 'CAPT',
  FR: 'FR',
  GEN: 'GEN',
};

export const COUNTRY_CODE = {
  AUSTRALIA: 'AU',
  NEW_ZEALAND: 'NZ',
  CHRISTMAS_ISLAND: 'CX',
  COCOS_ISLANDS: 'CC',
  COOK_ISLANDS: 'CK',
  FIJI: 'FJ',
  PAPUA_NEW_GUINEA: 'PG',
  SAMOA: 'WS',
  SOLOMON_ISLANDS: 'SB',
  TONGA: 'TO',
  VANUATU: 'VU',
  NOT_LISTED: 'not_listed',
};

export const ELEMENT_ID = {
  MAIN_CONTENT: 'main_content',
  PROGRESS_NAV_MOBILE: 'progress_nav_small_device',
  HEADER_SUMMARY: 'header_summary',
};

export const MOBILE_STICKY_HEADER_HEIGHT = 60;
