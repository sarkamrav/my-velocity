import React, { useState, useEffect, useCallback } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import get from 'lodash/get';

import Loading from '../../components/Loading/Loading';
import * as userData from '../../stores/utilities';
import { COMPONENT_NAME } from '../../utils/common';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import api from '../../utils/api';

import MyDetailsForm from './MyDetailsForm/MyDetailsForm';
import MessageTile, { messageTileTheme } from '../../components/MessageTile/MessageTile';
import styles from './MyDetails.css';

const MyDetails = ({
  user,
  ctaContainer,
  personalDetails,
  homeAddressDetails,
  businessAddressDetails,
  contactNumberDetails,
  emailDetails,
  successMessage,
  errorMessages,
}) => {
  const hasLoggedIn = userData.getHasLoggedIn(user);
  const memberDataLoadError = userData.getMemberDataLoadError(user);
  const membershipID = userData.getLoyaltyMembershipID(user);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [userDetails, setUserDetails] = useState({});

  const myDetailsApiUri = '/loyalty/v2/members/profile';

  const fetchMyDetails = useCallback(async () => {
    try {
      setLoading(true);
      const apiResp = await api.vffV2Api.get(myDetailsApiUri);
      setUserDetails(apiResp.data.data);
      setLoading(false);
    } catch (err) {
      setError(get(errorMessages, 'defaultErrorMessage'));
      setLoading(false);
    }
  }, [errorMessages]);

  useEffect(() => {
    if (hasLoggedIn) {
      fetchMyDetails();
    }
  }, [hasLoggedIn, fetchMyDetails]);

  return (
    <ErrorBoundary section={COMPONENT_NAME.myDetails}>
      {!hasLoggedIn && memberDataLoadError ? (
        <div className={styles.errorContainer}>
          <MessageTile theme={messageTileTheme.error} description="Sorry, we're having issues with our system." />
        </div>
      ) : (
        <>
          {loading ? (
            <div className={styles.loadingContainer}>
              <Loading />
            </div>
          ) : (
            <>
              {error ? (
                <div className={styles.errorContainer}>
                  <MessageTile theme={messageTileTheme.error} description={error.description} />
                </div>
              ) : (
                <MyDetailsForm
                  membershipID={membershipID}
                  userDetails={userDetails}
                  ctaContainer={ctaContainer}
                  personalDetails={personalDetails}
                  homeAddressDetails={homeAddressDetails}
                  businessAddressDetails={businessAddressDetails}
                  contactNumberDetails={contactNumberDetails}
                  emailDetails={emailDetails}
                  successMessage={successMessage}
                  errorMessages={errorMessages}
                />
              )}
            </>
          )}
        </>
      )}
    </ErrorBoundary>
  );
};

MyDetails.propTypes = {
  user: PropTypes.shape({}),
  ctaContainer: PropTypes.shape({}).isRequired,
  personalDetails: PropTypes.shape({}).isRequired,
  homeAddressDetails: PropTypes.shape({}).isRequired,
  businessAddressDetails: PropTypes.shape({}).isRequired,
  contactNumberDetails: PropTypes.shape({}).isRequired,
  emailDetails: PropTypes.shape({}).isRequired,
  successMessage: PropTypes.string.isRequired,
  errorMessages: PropTypes.shape({}).isRequired,
};

MyDetails.defaultProps = {
  user: null,
};

export default connect((state) => ({
  user: state.user,
}))(MyDetails);
