import React from 'react';
import { Provider } from 'react-redux';
import MockAdapter from 'axios-mock-adapter';
import { configureStore } from '../../stores';
import api from '../../utils/api';

import myDetailsMock from './mocks/MyDetails.mock.json';
import MyDetails from './MyDetails';
import userData from '../Navigation/mocks/user.mock.json';

export default {
  title: 'My Details',
};

export const MyDetailsSubmissionSuccess = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVff.onGet('/loyalty/v2/members/profile').reply(200, {
    data: {
      status: {
        sub: {
          accountIdentifier: {
            activity: 'ACTIVE',
          },
        },
      },
      individual: {
        identity: {
          firstName: 'NZ',
          lastName: 'test',
          title: 'MR',
          preferredFirstName: 'NZ',
          birthDate: '2011-11-11',
          gender: 'MALE',
          employments: [
            {
              company: 'manager',
              title: 'va',
            },
          ],
        },
        contact: {
          emails: [
            {
              category: 'PERSONAL',
              address: 'bhuvnesh.bhambhani@virginaustralia.com',
              contactValidity: {
                isMain: false,
                isValid: true,
                isConfirmed: false,
              },
            },
            {
              category: 'BUSINESS',
              address: 'bhuvnesh@virginaustralia.com',
              contactValidity: {
                isMain: true,
                isValid: true,
                isConfirmed: false,
              },
            },
          ],
          phones: [
            {
              category: 'PERSONAL',
              deviceType: 'MOBILE',
              number: '1231232131',
              contactValidity: {
                isMain: true,
                isValid: true,
                isConfirmed: false,
              },
            },
            {
              category: 'BUSINESS',
              deviceType: 'LANDLINE',
              number: '1231232131',
              areaCode: '11',
            },
          ],
          addresses: [
            {
              category: 'PERSONAL',
              lines: ['23 Anna Lane'],
              postalCode: '0602',
              countryCode: 'NZ',
              cityName: 'GLEN EDEN',
              contactValidity: {
                isMain: true,
                isValid: true,
                isConfirmed: false,
              },
            },
            {
              category: 'BUSINESS',
              lines: ['23 Anna Lane'],
              postalCode: '0602',
              countryCode: 'NZ',
              cityName: 'GLEN EDEN',
              contactValidity: {
                isMain: false,
                isValid: true,
                isConfirmed: false,
              },
            },
          ],
        },
      },
    },
  });

  mockVff.onPatch('/loyalty/v2/members').reply(200, {});

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <MyDetails {...myDetailsMock} />
      </Provider>
    </div>
  );
};

MyDetailsSubmissionSuccess.storyName = 'My Details - Submission Success';

export const MyDetailsFormSubmissionFailed = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVff.onGet('/loyalty/v2/members/profile').reply(200, {
    data: {
      status: {
        sub: {
          accountIdentifier: {
            activity: 'ACTIVE',
          },
        },
      },
      individual: {
        identity: {
          firstName: 'Garry',
          lastName: 'Webtest-ac',
          title: 'MR',
          preferredFirstName: 'Garry',
          birthDate: '2000-10-09',
          gender: 'MALE',
          employments: [
            {
              title: 'Manager',
            },
          ],
        },
        contact: {
          emails: [
            {
              category: 'BUSINESS',
              address: 'garry.webtest-dummy@virginaustralia.com',
              contactValidity: {
                isMain: true,
                isValid: true,
                isConfirmed: false,
              },
            },
          ],
          phones: [
            {
              category: 'PERSONAL',
              deviceType: 'LANDLINE',
              countryCallingCode: '61',
              areaCode: '02',
              number: '91234567',
            },
            {
              category: 'PERSONAL',
              deviceType: 'MOBILE',
              number: '1231232131',
              contactValidity: {
                isMain: true,
                isValid: true,
                isConfirmed: false,
              },
            },
          ],
          addresses: [
            {
              category: 'PERSONAL',
              lines: ['21/34 Bonython St,dfgda'],
              postalCode: '4000',
              countryCode: 'NZ',
              cityName: 'WINDSOR',
              contactValidity: {
                isMain: true,
              },
            },
            {
              category: 'BUSINESS',
              lines: ['21/34 Bonython St'],
              countryCode: 'AU',
              cityName: 'WINDSOR',
              stateCode: 'QLD',
              contactValidity: {
                isMain: false,
              },
            },
          ],
        },
      },
    },
  });

  mockVff.onPatch('/loyalty/v2/members').reply(400, {
    code: 4001,
    title: 'Validation Error',
    detail: 'Validation failed for below fields',
    status: 400,
    errorFields: [
      {
        field: 'data.membershipId',
        message: 'must not be null',
      },
    ],
  });

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <MyDetails {...myDetailsMock} />
      </Provider>
    </div>
  );
};

MyDetailsFormSubmissionFailed.storyName = 'My Details - Submission Failed';

export const DuplicateMembershipError = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVff.onGet('/loyalty/v2/members/profile').reply(200, {
    data: {
      status: {
        sub: {
          accountIdentifier: {
            activity: 'ACTIVE',
          },
        },
      },
      individual: {
        identity: {
          firstName: 'Garry',
          lastName: 'Webtest-ac',
          title: 'MR',
          preferredFirstName: 'Garry',
          birthDate: '2000-10-09',
          gender: 'MALE',
          employments: [
            {
              title: 'Manager',
            },
          ],
        },
        contact: {
          emails: [
            {
              category: 'BUSINESS',
              address: 'garry.webtest-dummy@virginaustralia.com',
              contactValidity: {
                isMain: true,
                isValid: true,
                isConfirmed: false,
              },
            },
          ],
          phones: [
            {
              category: 'PERSONAL',
              deviceType: 'LANDLINE',
              countryCallingCode: '61',
              areaCode: '02',
              number: '91234567',
            },
            {
              category: 'PERSONAL',
              deviceType: 'MOBILE',
              number: '1231232131',
              contactValidity: {
                isMain: true,
                isValid: true,
                isConfirmed: false,
              },
            },
          ],
          addresses: [
            {
              category: 'PERSONAL',
              lines: ['21/34 Bonython St,dfgda'],
              postalCode: '4000',
              countryCode: 'NZ',
              cityName: 'WINDSOR',
              contactValidity: {
                isMain: true,
              },
            },
            {
              category: 'BUSINESS',
              lines: ['21/34 Bonython St'],
              countryCode: 'AU',
              cityName: 'WINDSOR',
              stateCode: 'QLD',
              contactValidity: {
                isMain: false,
              },
            },
          ],
        },
      },
    },
  });

  mockVff.onPatch('/loyalty/v2/members').reply(400, {
    code: 37014,
    title: 'Conflict',
    detail: 'duplicate Membership is found',
    status: 409,
  });

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <MyDetails {...myDetailsMock} />
      </Provider>
    </div>
  );
};

DuplicateMembershipError.storyName = 'My Details - Duplicate Membership Error';

export const MyDetailsApiError = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVff.onGet('/loyalty/v2/members/profile').reply(400, {
    code: 4001,
    title: 'Validation Error',
    detail: 'Validation failed for below fields',
    status: 400,
    errorFields: [
      {
        field: 'Membership-Id',
        message: 'must not be null into request header',
      },
    ],
  });

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <MyDetails {...myDetailsMock} />
      </Provider>
    </div>
  );
};

MyDetailsApiError.storyName = 'My Details - API Failed';

export const MyDetailsApiLoading = () => (
  <div style={{ backgroundColor: '#f9f9f9' }}>
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: false,
          memberDataLoading: true,
          authenticated: false,
        },
      })}
    >
      <MyDetails {...myDetailsMock} />
    </Provider>
  </div>
);
MyDetailsApiLoading.storyName = 'My Details - API Loading';

export const MyDetailsSystemError = () => (
  <div style={{ backgroundColor: '#f9f9f9' }}>
    <Provider
      store={configureStore({
        user: {
          memberDataLoadError: true,
          authenticated: false,
        },
      })}
    >
      <MyDetails {...myDetailsMock} />
    </Provider>
  </div>
);
MyDetailsSystemError.storyName = 'My Details - System Error';
