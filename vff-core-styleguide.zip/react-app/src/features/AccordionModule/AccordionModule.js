import React from 'react';
import cx from 'classnames';

import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME } from '../../utils/common';

import Accordion from '../../components/Accordion/Accordion';

import styles from './AccordionModule.css';

const AccordionModule = (props) => {
  // eslint-disable-next-line react/prop-types
  const { isFullWidth, ...rest } = props;

  return (
    <ErrorBoundary section={COMPONENT_NAME.accordionModule}>
      <Accordion className={cx(styles.containerWrapper, isFullWidth ? styles.fullWidth : '')} {...rest} />
    </ErrorBoundary>
  );
};

export default AccordionModule;
