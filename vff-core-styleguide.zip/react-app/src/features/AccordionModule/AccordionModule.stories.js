import React from 'react';
import AccordionModule from './AccordionModule';
import accordionModuleMock from './mocks/accordion-module.mock.json';

export default {
  title: 'AccordionModule',
};

export const Default = () => <AccordionModule {...accordionModuleMock} />;
