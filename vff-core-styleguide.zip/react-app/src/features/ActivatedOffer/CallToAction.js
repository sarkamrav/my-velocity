/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { find, get, size } from 'lodash';
import qs from 'qs';
import cx from 'classnames';
import { DateTime } from 'luxon';

import Icon from '../../components/Icon/Icon';
import Input from '../../components/Form/Input/Input';
import Button from '../../components/Button/Button';
import A from '../../components/Button/A';
import api from '../../utils/api';
import OfferTimer from '../../components/OfferTimer/OfferTimer';
import { capType } from './constants';
import syncText from '../../utils/syncText';
import { getDurationBetween } from '../../utils/duration';
import * as userData from '../../stores/utilities';
import {
  API_RESPONSE_CODES,
  ACTIVATION_STATUSES,
  COMPONENT_NAME,
  serverTimeZone,
  POST_API_RESPONSE_CODES,
} from '../../utils/common';
import { getApiActionName, getApiError, sendToNewRelic } from '../../utils/newRelic';

import styles from './CallToAction.css';

const CallToAction = ({
  promotion,
  setPromotion,
  user,
  promoCode,
  time,
  ctaContainer,
  showCapType,
  capOfferLabel,
  expirationDateLabel,
  postApiResponses,
  apiResponses,
  additionalSuccessText,
  disableSecondaryActionPostActivationEndDate,
  hmac,
  sendAnalytics,
}) => {
  const [state, setState] = useState({
    velocityMembershipId: '',
    invalidMembershipId: false,
  });
  const { velocityMembershipId, invalidMembershipId } = state;
  const { loading, activated, error, success, promotionProvider } = promotion;
  const query = qs.parse(window.location.search, { ignoreQueryPrefix: true });
  const autoActivate = query.action === 'activate';
  const loyaltyMembershipID = userData.getLoyaltyMembershipID(user);

  function getApiResponseText(responseText) {
    const response = find(apiResponses, { value: responseText });
    return get(response, 'title', '');
  }

  function renderError(syncedTitle) {
    const showErrorCta = get(error, 'ctaLink') && get(error, 'ctaLabel');

    return (
      <div className={styles.messages}>
        <div className={styles.message}>
          <div className={cx(styles.iconMessage, styles.error)}>
            <Icon name="ExclamationPoint" />
            <span>{syncedTitle}</span>
          </div>
          {query.channel !== 'agent' && showErrorCta ? (
            <A
              className={styles.secondaryCta}
              href={error.ctaLink}
              target={error.newTab ? '_blank' : '_self'}
              buttonType={error.ctaStyle}
              ctaAsLink={error.ctaAsLink}
            >
              {error.ctaLabel}
            </A>
          ) : null}
        </div>
      </div>
    );
  }

  const handleSubmit = useCallback(
    async (e) => {
      const membershipId = loyaltyMembershipID || velocityMembershipId || query.customer_id;
      try {
        if (e) {
          e.preventDefault();
          // if the event is existed, it means its not an auto activation
          sendAnalytics(promotion, {
            eventAction: 'click',
            eventCategory: 'offer-activation',
            eventName: 'activate-offer',
            eventLocation: 'offer-activation',
            memberIDUsed: membershipId,
          });
        }

        setPromotion({ ...promotion, loading: true });

        await api.aemVaProxyApi.post('/va/loyalty/v2/promotions', {
          data: {
            memberId: membershipId,
            promotionCode: promoCode,
            promotionProvider: promotionProvider || '',
          },
        });

        sendAnalytics(promotion, {
          eventName: `${autoActivate ? 'auto-' : ''}activate-offer-success`,
          eventLocation: 'offer-activation',
          featuredPromoActivationResponseCode: 'Ok',
          memberIDUsed: membershipId,
        });

        const successResponse = find(postApiResponses, { value: POST_API_RESPONSE_CODES.SUCCESS });

        setPromotion({
          ...promotion,
          success: successResponse,
          loading: false,
          activated: true,
        });
      } catch (err) {
        const errorCode = get(err, 'response.data.code');
        const foundError =
          find(postApiResponses, { value: errorCode?.toString() }) ||
          find(postApiResponses, { value: 'Unknown Error' });
        const showGenericError = !foundError?.title;

        sendAnalytics(promotion, {
          eventName: `${autoActivate ? 'auto-' : ''}activate-offer-fail`,
          eventLocation: 'offer-activation',
          featuredPromoActivationResponseCode: errorCode,
          memberIDUsed: membershipId,
        });

        setPromotion({
          ...promotion,
          loading: false,
          error: {
            ...foundError,
            title: syncText(foundError?.title, promotion),
          },
          showGenericError,
        });

        sendToNewRelic(getApiActionName(), getApiError(COMPONENT_NAME.activatedOffer, err));
      }
    },
    [
      postApiResponses,
      autoActivate,
      hmac,
      loyaltyMembershipID,
      promoCode,
      promotion,
      promotionProvider,
      query.activationChannel,
      query.customer_id,
      sendAnalytics,
      setPromotion,
      velocityMembershipId,
    ],
  );

  const isLoggedIn = !!loyaltyMembershipID || !!query.customer_id;

  useEffect(() => {
    if (isLoggedIn && !error && promotion.registrationStatus === ACTIVATION_STATUSES.ACTIVE && autoActivate) {
      handleSubmit();
    }
  }, []);

  const handleChangeVelocityNumber = useCallback(
    (e) => {
      const newValue = e.target.value.replace(new RegExp(/[^0-9]/, 'g'), '').substring(0, 10);
      setState({
        ...state,
        velocityMembershipId: newValue,
        invalidMembershipId: size(newValue) !== 10,
      });
    },
    [state],
  );

  if (error) {
    return renderError(error.title);
  }

  const convertedTime = DateTime.fromISO(time, serverTimeZone); // All promotions run on AEST, and should be compared as such
  const activityEnded =
    convertedTime.startOf('day') > DateTime.fromISO(promotion.activityEndDate, serverTimeZone).startOf('day');
  const alreadyRegistered = get(promotion, 'registrationStatus') === ACTIVATION_STATUSES.REGISTERED;

  if (!activityEnded && (activated || alreadyRegistered)) {
    let foundSuccess = success;
    if (alreadyRegistered) {
      foundSuccess = find(apiResponses, { value: POST_API_RESPONSE_CODES.ALREADY_ACTIVATED }) || success;
    }
    const showSuccessCtaLink = get(foundSuccess, 'ctaLink') && get(foundSuccess, 'ctaLabel');
    const showSuccessCta = additionalSuccessText || showSuccessCtaLink;

    const inclusiveRegistrationEndDate = DateTime.fromISO(promotion?.registrationEndDate, serverTimeZone).plus({
      days: 1,
    }); // All promotions are inclusive of the date
    const offerHasEnded = convertedTime > inclusiveRegistrationEndDate;

    const hideSecondaryCta = disableSecondaryActionPostActivationEndDate && offerHasEnded;

    return (
      <div className={styles.messages}>
        <div className={styles.message}>
          <div className={cx(styles.iconMessage, styles.success)}>
            <Icon name="TickCircleOpen" />
            <span>Activated</span>
          </div>
        </div>
        {!hideSecondaryCta && query.channel !== 'agent' && showSuccessCta ? (
          <div
            className={styles.message}
            analytics-metadata={JSON.stringify({
              eventCategory: 'offer-item',
              hyperlinkElementLocation: 'offer-item',
              eventName: 'offer-lead-cta',
            })}
          >
            {additionalSuccessText ? (
              <div
                dangerouslySetInnerHTML={{ __html: syncText(additionalSuccessText, promotion) }}
                className={styles.additionalSuccessText}
              />
            ) : null}
            {showSuccessCtaLink ? (
              <A
                className={styles.secondaryCta}
                href={foundSuccess.ctaLink}
                target={foundSuccess.newTab ? '_blank' : '_self'}
                buttonType={foundSuccess.ctaStyle}
                data-offer-id={promoCode}
                ctaAsLink={foundSuccess.ctaAsLink}
              >
                {foundSuccess.ctaLabel}
              </A>
            ) : null}
          </div>
        ) : null}
      </div>
    );
  }

  const inclusiveRegistrationEndDate = DateTime.fromISO(promotion?.registrationEndDate, serverTimeZone).plus({
    days: 1,
  }); // All promotions are inclusive of the date
  const { duration } = getDurationBetween(convertedTime, inclusiveRegistrationEndDate);

  if (promotion) {
    if (promotion.promotionStatus === 'ENDED' || activityEnded) {
      return renderError(syncText(getApiResponseText(API_RESPONSE_CODES.PROMOTION_CLOSED), promotion));
    }

    //  activation caps are not in scopes for day 1 for LMS API, expected to be in future release commenting out for now

    // if (promotion.registrationStatus === ACTIVATION_STATUSES.CAP_REACHED || promotion.activationCapAvail === 0) {
    //   return renderError(syncText(getApiResponseText(API_RESPONSE_CODES.PROMOTION_CAP_REACHED), promotion));
    // }

    if (promotion.mustRegister && (promotion.registrationStatus === ACTIVATION_STATUSES.INACTIVE || !duration)) {
      return renderError(syncText(getApiResponseText(API_RESPONSE_CODES.PROMOTION_CLOSED), promotion));
    }
  }

  // Disabled CTA if:
  // (1) No user detected and form not valid
  // (2) Loading
  const ctaDisabled = (!isLoggedIn && (!velocityMembershipId || invalidMembershipId)) || loading;

  return (
    <>
      {promotion.loaded && promotion.registrationEndDate && (
        <OfferTimer
          className={styles.timer}
          showCapType={showCapType}
          activationCapMax={promotion.activationCapMax}
          activationCapAvail={promotion.activationCapAvail}
          capOfferLabel={capOfferLabel}
          registrationEndDate={promotion.registrationEndDate}
          expirationDateLabel={expirationDateLabel}
        />
      )}
      <form className={styles.form} onSubmit={handleSubmit}>
        {!isLoggedIn ? (
          <Input
            type="text"
            label="Enter your Membership number to activate"
            placeholder="Membership number"
            value={velocityMembershipId}
            onChange={handleChangeVelocityNumber}
            error={invalidMembershipId ? 'Velocity Membership number is 10 digits' : null}
          />
        ) : null}
        <Button type="submit" className={styles.callToActionButton} disabled={ctaDisabled} loading={loading}>
          {ctaContainer.ctaLabel}
        </Button>
      </form>
    </>
  );
};

CallToAction.propTypes = {
  promoCode: PropTypes.string.isRequired,
  user: PropTypes.shape({
    loyaltyMembershipID: PropTypes.string,
  }).isRequired,
  time: PropTypes.string.isRequired,
  promotion: PropTypes.shape({
    mustRegister: PropTypes.bool,
    promotionStatus: PropTypes.string,
    error: PropTypes.shape({
      title: PropTypes.string,
      ctaLink: PropTypes.string,
      newTab: PropTypes.bool,
      ctaStyle: PropTypes.string,
      ctaAsLink: PropTypes.bool,
      ctaLabel: PropTypes.string,
    }),
    activated: PropTypes.bool,
    loading: PropTypes.bool,
    success: PropTypes.shape({}),
    activationCapAvail: PropTypes.string,
    loaded: PropTypes.bool,
    activationCapMax: PropTypes.string,
    promotionProvider: PropTypes.string,
    registrationEndDate: PropTypes.string,
    registrationStatus: PropTypes.string,
    activityEndDate: PropTypes.string,
  }).isRequired,
  setPromotion: PropTypes.func.isRequired,
  ctaContainer: PropTypes.shape({
    ctaLabel: PropTypes.string,
  }).isRequired,
  showCapType: PropTypes.oneOf([capType.none, capType.showMaxCap, capType.showMaxAvail]),
  capOfferLabel: PropTypes.string.isRequired,
  expirationDateLabel: PropTypes.string.isRequired,
  postApiResponses: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
  apiResponses: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
  additionalSuccessText: PropTypes.string,
  hmac: PropTypes.bool,
  sendAnalytics: PropTypes.func.isRequired,
  disableSecondaryActionPostActivationEndDate: PropTypes.bool,
};

CallToAction.defaultProps = {
  additionalSuccessText: null,
  hmac: false,
  disableSecondaryActionPostActivationEndDate: false,
  showCapType: null,
};

export default connect((state) => ({
  user: state.user,
  time: state.time,
}))(CallToAction);
