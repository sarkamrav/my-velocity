/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import { find, get, first, size, filter, isEmpty, sortBy, last } from 'lodash';
import cx from 'classnames';
import { connect } from 'react-redux';
import qs from 'qs';
import { DateTime } from 'luxon';

import api from '../../utils/api';
import StepsToRedeem from './StepsToRedeem';
import Offer from './Offer';
import syncText from '../../utils/syncText';
import Icon from '../../components/Icon/Icon';
import Button from '../../components/Button/Button';
import { getDurationBetween } from '../../utils/duration';
import analyticsSend from '../../utils/analytics';
import { API_RESPONSE_CODES, ACTIVATION_STATUSES, COMPONENT_NAME, serverTimeZone } from '../../utils/common';
import ssoHandler from '../../utils/ssoHandler';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { getApiActionName, getApiError, sendToNewRelic } from '../../utils/newRelic';
import * as userData from '../../stores/utilities';

import styles from './ActivatedOffer.css';

const query = qs.parse(window.location.search, { ignoreQueryPrefix: true });
const autoActivate = query.action === 'activate';

const ActivatedOffer = (props) => {
  const {
    user,
    promoCode,
    promoSystem,
    apiResponses,
    partner,
    promoLabel,
    redemption,
    terms,
    bgAttr,
    hmac,
    targetOffer,
  } = props;

  const [analyticsData, setAnalyticsData] = useState(`amd_aoffer_${promoCode}`); // hardcoded as we don't have analytics metadata in Activated Offer

  const [promotion, setPromotion] = useState({
    loaded: false,
    loading: false,
    error: null,
  });

  const loyaltyMembershipID = userData.getLoyaltyMembershipID(user);

  const [selectedTab, setSelectedTab] = useState(redemption ? 'Steps' : 'Terms');

  const showTabs = (redemption || terms) && !promotion.showGenericError;

  const promotionsUri = '/va/loyalty/v2/promotions';
  const convertedTime = DateTime.fromObject({}, serverTimeZone); // All promotions run on AEST, and should be compared as such

  const sendAnalytics = useCallback(
    (response = {}, data = {}) => {
      let remainingDays;
      const registrationEndDate = get(response, 'registrationEndDate');

      if (registrationEndDate) {
        const inclusiveRegistrationEndDate = DateTime.fromISO(registrationEndDate, serverTimeZone).plus({ days: 1 }); // All promotions are inclusive of the date
        const { days } = getDurationBetween(convertedTime, inclusiveRegistrationEndDate);
        remainingDays = days;
      }

      const featuredPromoActivated = get(response, 'registrationStatus') === ACTIVATION_STATUSES.REGISTERED ? 'Y' : 'N';

      analyticsSend({
        pageType: 'offer',
        eventLocation: 'offer-activation',
        eventCategory: 'offer-activation',
        featuredPromoCode: promoCode,
        featuredPromoActivated: !data.memberIDUsed ? 'NA' : featuredPromoActivated,
        featuredPromoPartner: get(partner, 'name'),
        featuredPromoCategory: get(partner, 'category'),
        featuredPromoRemainingDays: remainingDays,
        featuredPromoMaxCap: get(response, 'activationCapMax'),
        featuredPromoRemaining: get(response, 'activationCapAvail'),
        ...data,
      });
    },
    [partner, promoCode],
  );

  function updateSelectedTab(tab) {
    sendAnalytics(promotion, {
      eventName: 'offer-activation-tab-selection',
      eventLocation: 'offer-activation',
      moduleSelected: tab,
    });

    setSelectedTab(tab);
  }
  // `getValidPromotions` checks the currentDate with registrationEndDate, and activityEndDate inorder to filter out the expired promotions
  const getValidPromotions = (_data, _vffMembershipId) => {
    if (!_vffMembershipId) {
      return (
        _data.promotionStatus === 'RUNNING' &&
        convertedTime.startOf('day') <= DateTime.fromISO(_data.registrationEndDate, serverTimeZone).startOf('day')
      );
    }
    const isValidRegisteredPromotion =
      _data.registrationStatus === 'REGISTERED' &&
      convertedTime.startOf('day') <= DateTime.fromISO(_data.activityEndDate, serverTimeZone).startOf('day');
    return (
      _data.promotionStatus === 'RUNNING' && (_data.registrationStatus === 'REGISTRABLE' || isValidRegisteredPromotion)
    );
  };

  const fetchPromotion = useCallback(async () => {
    let showGenericError = false;
    try {
      setPromotion({ ...promotion, loading: true });
      let foundPromotion = {};

      const vffMembershipId = loyaltyMembershipID || query.customer_id;
      const response = await api.aemVaProxyApi.get(promotionsUri, {
        headers: {
          ...(vffMembershipId ? { 'Membership-Id': vffMembershipId } : {}),
        },
        params: {
          promotionCode: promoCode,
          promotionProvider: promoSystem,
        },
      });
      const responseData = response?.data?.data;
      if (responseData.length > 0) {
        //  filters out occurrences which are ENDED or "Today date (in Brisbane timezone)" > activityEndDate
        const filteredData = filter(responseData, (data) => getValidPromotions(data, vffMembershipId));
        foundPromotion = first(filteredData);
      }
      if (isEmpty(foundPromotion)) {
        const sortedData = sortBy(responseData, (_responseOffer) => _responseOffer.activityEndDate);
        foundPromotion = last(sortedData);
      }

      sendAnalytics(foundPromotion, {
        eventName: `${autoActivate ? 'auto-' : ''}activate-offer-load`,
        eventLocation: 'offer-activation',
        featuredPromoResponseCode: get(response, 'status'),
        memberIDUsed: vffMembershipId,
      });

      showGenericError = !responseData?.length;
      setPromotion({
        ...foundPromotion,
        loading: false,
        loaded: true,
        showGenericError,
      });
    } catch (error) {
      const errorCode = get(error, 'response.data.code');
      const errorTitle = get(error, 'response.data.title');

      sendAnalytics(
        {
          ...error,
          registrationStatus:
            errorTitle === API_RESPONSE_CODES.ALREADY_ACTIVATED ? ACTIVATION_STATUSES.REGISTERED : null,
        },
        {
          eventName: `${autoActivate ? 'auto-' : ''}activate-offer-load-fail`,
          eventLocation: 'offer-activation',
          eventFailReason: get(error, 'response.data.detail'),
          featuredPromoResponseCode: errorCode,
          memberIDUsed: query.customer_id || loyaltyMembershipID,
        },
      );

      // foundError will only exist when there's an API response matching the error code, and no fault string attached
      const foundError =
        find(apiResponses, { value: errorCode?.toString() }) ||
        find(apiResponses, { value: errorTitle }) ||
        find(apiResponses, { value: 'Unknown Error' });
      // If no foundError or is included in the list of API responses
      showGenericError = !foundError?.title;

      setPromotion({
        ...promotion,
        loading: false,
        loaded: true,
        error: {
          ...foundError,
          title: syncText(foundError?.title, promotion),
        },
        showGenericError,
      });

      sendToNewRelic(getApiActionName(), getApiError(COMPONENT_NAME.activatedOffer, error));
    }
  }, [apiResponses, hmac, loyaltyMembershipID, promoCode, promotion, sendAnalytics]);

  useEffect(() => {
    // Targeted offer must only be shown on logged in
    if (targetOffer && !loyaltyMembershipID && !query.customer_id) {
      ssoHandler.init(true);
    } else {
      fetchPromotion();
    }

    setAnalyticsData({
      offerId: promoCode,
      eventLocation: 'offer-activation',
    });
  }, []);

  return (
    <ErrorBoundary section={COMPONENT_NAME.activatedOffer}>
      <div>
        <div
          className={cx(styles.wrapper, styles.image, {
            [styles.notAvailable]: size(bgAttr) === 0,
          })}
          {...bgAttr}
        >
          {!promotion.showGenericError && !!promoLabel.title && <div className={styles.badge}>{promoLabel.title}</div>}
        </div>

        <div className={styles.wrapper} {...bgAttr}>
          <div className={styles.container}>
            {promotion.showGenericError ? (
              <div className={styles.genericError}>
                <Icon name="ExclamationPoint" className={styles.icon} />
                <div className={styles.title}>Something went wrong</div>
                <div className={styles.content}>
                  We were unable to retrieve the promotion details. Please click the button below to refresh the page
                  and try again.
                </div>
                <Button
                  buttonType="primary-transparent"
                  className={styles.button}
                  onClick={() => window.location.reload()}
                >
                  Refresh page
                </Button>
              </div>
            ) : (
              <>
                <div className={styles.header}>
                  <div className={styles.categoryContainer}>
                    <div className={styles.categoryLine} style={{ backgroundColor: get(partner, 'categoryColor') }} />
                    <div className={styles.category} style={{ color: get(partner, 'categoryColor') }}>
                      {get(partner, 'category')}
                    </div>
                  </div>

                  {!!promoLabel.title && <div className={styles.badge}>{promoLabel.title}</div>}
                </div>
                <Offer {...props} promotion={promotion} setPromotion={setPromotion} sendAnalytics={sendAnalytics} />
              </>
            )}
            {showTabs ? (
              <div className={styles.tabs}>
                {redemption ? (
                  <button
                    className={cx(styles.tab, {
                      [styles.selected]: selectedTab === 'Steps',
                    })}
                    onClick={() => updateSelectedTab('Steps')}
                  >
                    {redemption.buttonLabel}
                  </button>
                ) : null}
                {terms ? (
                  <button
                    className={cx(styles.tab, {
                      [styles.selected]: selectedTab === 'Terms',
                    })}
                    onClick={() => updateSelectedTab('Terms')}
                  >
                    {terms.buttonLabel}
                  </button>
                ) : null}
              </div>
            ) : null}
          </div>
        </div>

        {showTabs ? (
          <div className={styles.tabContent} analytics-metadata={JSON.stringify(analyticsData)}>
            {selectedTab === 'Steps' && redemption && <StepsToRedeem redemption={redemption} promotion={promotion} />}
            {selectedTab === 'Terms' && terms && (
              <div>
                <h3 className={styles.termsTitle}>{terms.title}</h3>
                <div
                  className={styles.termsContent}
                  dangerouslySetInnerHTML={{
                    __html: syncText(
                      qs.channel !== 'agent' || !terms.textAgent ? terms.text : terms.textAgent,
                      promotion,
                    ),
                  }}
                />
              </div>
            )}
          </div>
        ) : null}
      </div>
    </ErrorBoundary>
  );
};

ActivatedOffer.propTypes = {
  promoLabel: PropTypes.shape({
    title: PropTypes.string,
  }),
  description: PropTypes.string.isRequired,
  redemption: PropTypes.shape({
    buttonLabel: PropTypes.string,
  }),
  terms: PropTypes.shape({
    buttonLabel: PropTypes.string,
    title: PropTypes.string,
    textAgent: PropTypes.string,
    text: PropTypes.string,
  }),
  bgAttr: PropTypes.shape({}),
  promoCode: PropTypes.string.isRequired,
  promoSystem: PropTypes.string,
  partner: PropTypes.shape({}).isRequired,
  title: PropTypes.string.isRequired,
  user: PropTypes.shape({
    loyaltyMembershipID: PropTypes.string,
  }).isRequired,
  apiResponses: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
  hmac: PropTypes.bool,
  targetOffer: PropTypes.bool,
};

ActivatedOffer.defaultProps = {
  promoLabel: {},
  redemption: null,
  terms: null,
  bgAttr: {},
  hmac: false,
  targetOffer: false,
  promoSystem: '',
};

export default connect((state) => ({
  user: state.user,
}))(ActivatedOffer);
