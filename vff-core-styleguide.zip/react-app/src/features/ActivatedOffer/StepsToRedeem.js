import React from 'react';
import PropTypes from 'prop-types';
import { map, size } from 'lodash';
import cx from 'classnames';

import syncText from '../../utils/syncText';

import styles from './StepsToRedeem.css';

const StepsToRedeem = (props) => {
  const { redemption, promotion } = props;
  const hasIcon = redemption.steps.some((step) => step.iconUrl);

  return (
    <div className={styles.redeemContainer}>
      <div className={styles.redeemContent}>
        <h3 className={styles.redeemTitle}>{redemption.title}</h3>
        {size(redemption.steps) > 0 ? (
          <ol className={styles.steps}>
            {map(redemption.steps, (step, i) => (
              <li key={i} className={cx(styles.step, { [styles.auto]: !hasIcon })}>
                {hasIcon && (
                  <div className={styles.icon}>{step.iconUrl && <img src={step.iconUrl} alt="step icon" />}</div>
                )}
                <div dangerouslySetInnerHTML={{ __html: syncText(step.text, promotion) }} />
              </li>
            ))}
          </ol>
        ) : null}
      </div>
    </div>
  );
};

StepsToRedeem.propTypes = {
  promotion: PropTypes.shape({}),
  redemption: PropTypes.shape({
    title: PropTypes.string,
    steps: PropTypes.arrayOf(PropTypes.shape({})),
  }).isRequired,
};

StepsToRedeem.defaultProps = {
  promotion: null,
};

export default StepsToRedeem;
