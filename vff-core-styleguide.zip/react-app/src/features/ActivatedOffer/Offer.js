import React from 'react';
import PropTypes from 'prop-types';
import get from 'lodash/get';

import syncText from '../../utils/syncText';
import CallToAction from './CallToAction';
import Button from '../../components/Button/Button';
import useServerRendering from '../../hooks/useServerRendering';

import styles from './Offer.css';

const Offer = (props) => {
  const { partner, title, description, promotion, ctaContainer } = props;
  const { rendered } = useServerRendering();

  function renderCallToAction() {
    return promotion.loaded ? (
      <CallToAction {...props} />
    ) : (
      <div className={styles.loadingContainer}>
        <Button type="submit" className={styles.loadingButton} disabled loading>
          {ctaContainer.ctaLabel}
        </Button>
      </div>
    );
  }

  return (
    <div className={styles.callToAction}>
      <div className={styles.content}>
        {get(partner, 'logo') ? (
          <div className={styles.logoContainer}>
            <img src={partner.logo} alt={partner.name} className={styles.logo} />
          </div>
        ) : null}
        {get(partner, 'name') ? <h2 className={styles.brand}>{partner.name}</h2> : null}
        <h3 className={styles.title}>{title || promotion.promotionShortDescription}</h3>
        {description && (
          <div className={styles.description} dangerouslySetInnerHTML={{ __html: syncText(description, promotion) }} />
        )}
      </div>

      {rendered ? renderCallToAction() : null}
    </div>
  );
};

Offer.propTypes = {
  partner: PropTypes.shape().isRequired,
  title: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
  promotion: PropTypes.shape(),
  ctaContainer: PropTypes.shape({
    ctaLabel: PropTypes.string,
  }).isRequired,
};

Offer.defaultProps = {
  promotion: {},
};

export default Offer;
