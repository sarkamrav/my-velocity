export const capType = {
  none: 'none',
  showMaxCap: 'showMaxCap',
  showMaxAvail: 'showMaxAvail',
};
