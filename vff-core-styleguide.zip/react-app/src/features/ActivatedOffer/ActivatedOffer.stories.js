import React from 'react';
import { Provider } from 'react-redux';
import MockAdapter from 'axios-mock-adapter';
import ActivatedOffer from './ActivatedOffer';
import store, { configureStore } from '../../stores';
import api from '../../utils/api';
import { addDaysToToday } from '../../utils/common';
import activatedOfferMock from './mocks/activate-offer.mock.json';

const promotionsUri = '/va/loyalty/v2/promotions';

const props = {
  promoCode: 'BP',
  promoSystem: 'LCP',
};

export default {
  title: 'Activated Offer',
};

export const AuthenticatedSuccessfulActivation = () => {
  const mockAem = new MockAdapter(api.aemVaProxyApi, { delayResponse: 1000 });

  mockAem.onGet('/va/loyalty/v2/promotions').reply(200, {
    data: [
      {
        registrationEndDate: addDaysToToday(2),
        registrationStartDate: '2019-03-14',
        registrationStatus: 'REGISTRABLE',
        activationCapMax: '48',
        isRecurringPromotion: 'Y',
        promotionCode: 'TPLPOINTS',
        promotionShortDescription: 'Easter Triple Points Offer',
        promotionEndDate: '2020-02-12',
        promotionStartDate: '2019-03-19',
        mustRegister: true,
        promotionStatus: 'RUNNING',
        promotionProvider: 'LCP',
        promotionName: '1A 7-Eleven 1st & 2nd Activity post Activation Bon',
        activityStartDate: '2021-11-16',
        registeredAt: '2021-11-16',
        activityEndDate: addDaysToToday(2),
        achievementMaxCount: 1,
        achievementCount: 0,
        totalPhaseNumber: 2,
        lastAchievedPhaseNumber: 1,
      },
    ],
  });
  mockAem.onPost(promotionsUri).reply(200, {
    data: {
      type: 'REGISTRATION',
      id: '619c471fa5b4b0e4ebffc983',
      promotionCode: 'MDE Campaign',
      promotionProvider: 'MDE System',
      registrationDate: '2021-11-23T01:42:55.951Z',
      channel: 'WEBSITE',
    },
  });

  return (
    <Provider store={configureStore({ user: { member: { loyaltyMembershipID: '123' } } })}>
      <ActivatedOffer {...activatedOfferMock} {...props} />
    </Provider>
  );
};

AuthenticatedSuccessfulActivation.storyName = 'AUTHENTICATED - successful activation';

export const Authenticated3DaysRemaining = () => {
  const mockAem = new MockAdapter(api.aemVaProxyApi, { delayResponse: 1000 });

  mockAem.onGet(promotionsUri).reply(200, {
    data: [
      {
        registrationEndDate: addDaysToToday(2),
        registrationStartDate: '2019-03-14',
        registrationStatus: 'REGISTRABLE',
        activationCapMax: '48',
        isRecurringPromotion: 'Y',
        promotionCode: 'TPLPOINTS',
        promotionShortDescription: 'Easter Triple Points Offer',
        promotionEndDate: '2020-02-12',
        promotionStartDate: '2019-03-19',
        mustRegister: true,
        promotionStatus: 'REGISTERED',
        promotionProvider: 'LCP',
        promotionName: '1A 7-Eleven 1st & 2nd Activity post Activation Bon',
        activityStartDate: '2021-11-16',
        registeredAt: '2021-11-16',
        activityEndDate: addDaysToToday(2),
        achievementMaxCount: 1,
        achievementCount: 0,
        totalPhaseNumber: 2,
        lastAchievedPhaseNumber: 1,
      },
    ],
  });
  mockAem.onPost(promotionsUri).reply(200, {
    data: {
      type: 'REGISTRATION',
      id: '619c471fa5b4b0e4ebffc983',
      promotionCode: 'MDE Campaign',
      promotionProvider: 'MDE System',
      registrationDate: '2021-11-23T01:42:55.951Z',
      channel: 'WEBSITE',
    },
  });

  return (
    <Provider store={configureStore({ user: { member: { loyaltyMembershipID: '123' } } })}>
      <ActivatedOffer {...activatedOfferMock} {...props} />
    </Provider>
  );
};

Authenticated3DaysRemaining.storyName = 'AUTHENTICATED - 3 days remaining';

export const AuthenticatedUnknownError = () => {
  const mockAem = new MockAdapter(api.aemVaProxyApi);

  mockAem.onGet(promotionsUri).reply(200, {
    data: [
      {
        registrationEndDate: addDaysToToday(2),
        registrationStartDate: '2019-03-14',
        registrationStatus: 'REGISTRABLE',
        activationCapMax: '48',
        isRecurringPromotion: 'Y',
        promotionCode: 'TPLPOINTS',
        promotionShortDescription: 'Easter Triple Points Offer',
        promotionEndDate: '2020-02-12',
        promotionStartDate: '2019-03-19',
        mustRegister: true,
        promotionStatus: 'RUNNING',
        promotionProvider: 'LCP',
        promotionName: '1A 7-Eleven 1st & 2nd Activity post Activation Bon',
        activityStartDate: '2021-11-16',
        registeredAt: '2021-11-16',
        activityEndDate: addDaysToToday(2),
        achievementMaxCount: 1,
        achievementCount: 0,
        totalPhaseNumber: 2,
        lastAchievedPhaseNumber: 1,
      },
    ],
  });
  mockAem.onPost(promotionsUri).reply(500, {
    code: 4008477,
    title: 'Unknown Error',
    status: 500,
    detail: "An unknown error has occurred in one of Virgin Australia's systems.",
  });

  return (
    <Provider store={configureStore({ user: { member: { loyaltyMembershipID: '123' } } })}>
      <ActivatedOffer {...activatedOfferMock} {...props} />
    </Provider>
  );
};

AuthenticatedUnknownError.storyName = 'AUTHENTICATED - unknown error';

export const AuthenticatedBadRequest = () => {
  const mockAem = new MockAdapter(api.aemVaProxyApi);

  mockAem.onGet(promotionsUri).reply(200, {
    data: [
      {
        registrationEndDate: addDaysToToday(2),
        registrationStartDate: '2019-03-14',
        registrationStatus: 'REGISTRABLE',
        activationCapMax: '48',
        isRecurringPromotion: 'Y',
        promotionCode: 'TPLPOINTS',
        promotionShortDescription: 'Easter Triple Points Offer',
        promotionEndDate: '2020-02-12',
        promotionStartDate: '2019-03-19',
        mustRegister: true,
        promotionStatus: 'RUNNING',
        promotionProvider: 'LCP',
        promotionName: '1A 7-Eleven 1st & 2nd Activity post Activation Bon',
        activityStartDate: '2021-11-16',
        registeredAt: '2021-11-16',
        activityEndDate: addDaysToToday(2),
        achievementMaxCount: 1,
        achievementCount: 0,
        totalPhaseNumber: 2,
        lastAchievedPhaseNumber: 1,
      },
    ],
  });
  mockAem.onPost(promotionsUri).reply(400, {
    code: 40035,
    title: 'Bad Request',
    status: 400,
    detail: 'Please ensure the required elements have been provided',
  });

  return (
    <Provider store={configureStore({ user: { member: { loyaltyMembershipID: '123' } } })}>
      <ActivatedOffer {...activatedOfferMock} {...props} />
    </Provider>
  );
};

AuthenticatedBadRequest.storyName = 'AUTHENTICATED - bad request';

export const AuthenticatedUnauthorized = () => {
  const mockAem = new MockAdapter(api.aemVaProxyApi);

  mockAem.onGet(promotionsUri).reply(200, {
    data: [
      {
        registrationEndDate: addDaysToToday(2),
        registrationStartDate: '2019-03-14',
        registrationStatus: 'REGISTRABLE',
        activationCapMax: '48',
        isRecurringPromotion: 'Y',
        promotionCode: 'TPLPOINTS',
        promotionShortDescription: 'Easter Triple Points Offer',
        promotionEndDate: '2020-02-12',
        promotionStartDate: '2019-03-19',
        mustRegister: true,
        promotionStatus: 'RUNNING',
        promotionProvider: 'LCP',
        promotionName: '1A 7-Eleven 1st & 2nd Activity post Activation Bon',
        activityStartDate: '2021-11-16',
        registeredAt: '2021-11-16',
        activityEndDate: addDaysToToday(2),
        achievementMaxCount: 1,
        achievementCount: 0,
        totalPhaseNumber: 2,
        lastAchievedPhaseNumber: 1,
      },
    ],
  });
  mockAem.onPost(promotionsUri).reply(401, {
    code: 40084,
    detail: 'The bearer token provided is not valid or no API key was provided.',
    status: 401,
    title: 'Bad Unauthorized',
  });

  return (
    <Provider store={configureStore({ user: { member: { loyaltyMembershipID: '123' } } })}>
      <ActivatedOffer {...activatedOfferMock} {...props} />
    </Provider>
  );
};

AuthenticatedUnauthorized.storyName = 'AUTHENTICATED - unauthorized';

export const AuthenticatedMembershipNotFound = () => {
  const mockAem = new MockAdapter(api.aemVaProxyApi);

  mockAem.onGet(promotionsUri).reply(200, {
    data: [
      {
        registrationEndDate: addDaysToToday(2),
        registrationStartDate: '2019-03-14',
        registrationStatus: 'REGISTRABLE',
        activationCapMax: '48',
        isRecurringPromotion: 'Y',
        promotionCode: 'TPLPOINTS',
        promotionShortDescription: 'Easter Triple Points Offer',
        promotionEndDate: '2020-02-12',
        promotionStartDate: '2019-03-19',
        mustRegister: true,
        promotionStatus: 'RUNNING',
        promotionProvider: 'LCP',
        promotionName: '1A 7-Eleven 1st & 2nd Activity post Activation Bon',
        activityStartDate: '2021-11-16',
        registeredAt: '2021-11-16',
        activityEndDate: addDaysToToday(2),
        achievementMaxCount: 1,
        achievementCount: 0,
        totalPhaseNumber: 2,
        lastAchievedPhaseNumber: 1,
      },
    ],
  });
  mockAem.onPost(promotionsUri).reply(400, {
    code: 40043,
    title: 'Membership Not Found',
    status: 404,
    detail: 'Loyalty Membership ID not Found',
  });

  return (
    <Provider store={configureStore({ user: { member: { loyaltyMembershipID: '123' } } })}>
      <ActivatedOffer {...activatedOfferMock} {...props} />
    </Provider>
  );
};

AuthenticatedMembershipNotFound.storyName = 'AUTHENTICATED - membership not found';

export const AuthenticatedPromotionNotFound = () => {
  const mockAem = new MockAdapter(api.aemVaProxyApi);

  mockAem.onGet(promotionsUri).reply(200, {
    data: [
      {
        registrationEndDate: addDaysToToday(2),
        registrationStartDate: '2019-03-14',
        registrationStatus: 'REGISTRABLE',
        activationCapMax: '48',
        isRecurringPromotion: 'Y',
        promotionCode: 'TPLPOINTS',
        promotionShortDescription: 'Easter Triple Points Offer',
        promotionEndDate: '2020-02-12',
        promotionStartDate: '2019-03-19',
        mustRegister: true,
        promotionStatus: 'RUNNING',
        promotionProvider: 'LCP',
        promotionName: '1A 7-Eleven 1st & 2nd Activity post Activation Bon',
        activityStartDate: '2021-11-16',
        registeredAt: '2021-11-16',
        activityEndDate: addDaysToToday(2),
        achievementMaxCount: 1,
        achievementCount: 0,
        totalPhaseNumber: 2,
        lastAchievedPhaseNumber: 1,
      },
    ],
  });
  mockAem.onPost(promotionsUri).reply(404, {
    code: 40087,
    detail: 'Promotion Not Found',
    status: 404,
    title: 'Promotion Not Found',
  });

  return (
    <Provider store={configureStore({ user: { member: { loyaltyMembershipID: '123' } } })}>
      <ActivatedOffer {...activatedOfferMock} {...props} />
    </Provider>
  );
};

AuthenticatedPromotionNotFound.storyName = 'AUTHENTICATED - promotion not found';

export const AuthenticatedNotEligible = () => {
  const mockAem = new MockAdapter(api.aemVaProxyApi);

  mockAem.onGet(promotionsUri).reply(200, {
    data: [
      {
        registrationEndDate: addDaysToToday(2),
        registrationStartDate: '2019-03-14',
        registrationStatus: 'REGISTRABLE',
        activationCapMax: '48',
        isRecurringPromotion: 'Y',
        promotionCode: 'TPLPOINTS',
        promotionShortDescription: 'Easter Triple Points Offer',
        promotionEndDate: '2020-02-12',
        promotionStartDate: '2019-03-19',
        mustRegister: true,
        promotionStatus: 'RUNNING',
        promotionProvider: 'LCP',
        promotionName: '1A 7-Eleven 1st & 2nd Activity post Activation Bon',
        activityStartDate: '2021-11-16',
        registeredAt: '2021-11-16',
        activityEndDate: addDaysToToday(2),
        achievementMaxCount: 1,
        achievementCount: 0,
        totalPhaseNumber: 2,
        lastAchievedPhaseNumber: 1,
      },
    ],
  });
  mockAem.onPost(promotionsUri).reply(400, {
    code: 40082,
    title: 'Not Eligible',
    status: 400,
    detail: 'Member Not Eligible for Promotion',
  });

  return (
    <Provider store={configureStore({ user: { member: { loyaltyMembershipID: '123' } } })}>
      <ActivatedOffer {...activatedOfferMock} {...props} />
    </Provider>
  );
};

AuthenticatedNotEligible.storyName = 'AUTHENTICATED - not eligible';

export const AuthenticatedAlreadyActivated = () => {
  const mockAem = new MockAdapter(api.aemVaProxyApi);

  mockAem.onGet(promotionsUri).reply(200, {
    data: [
      {
        promotionCode: 'FLYBUYSDBL',
        promotionProvider: 'Adobe',
        promotionStatus: 'RUNNING',
        promotionShortDescription: 'Double Points for FlyBuys Purchases',
        promotionLongDescription: 'When making a purchase using your FlyBuys card you will be awarded Double Points!!!',
        promotionStartDate: '2021-01-01',
        promotionEndDate: '2021-03-31',
        mustRegister: true,
        registrationStartDate: '2021-04-01',
        registrationEndDate: addDaysToToday(1),
        activityStartDate: '2021-04-01',
        activityEndDate: addDaysToToday(2),
        registrationStatus: 'REGISTERED',
        isRecurringPromotion: 'Y',
      },
    ],
  });
  mockAem.onPost(promotionsUri).reply(400, {
    code: 40084,
    detail: 'Member Has Already Activated This Promotion',
    status: 400,
    title: 'Already Activated',
  });

  return (
    <Provider store={configureStore({ user: { member: { loyaltyMembershipID: '123' } } })}>
      <ActivatedOffer {...activatedOfferMock} {...props} />
    </Provider>
  );
};

AuthenticatedAlreadyActivated.storyName = 'AUTHENTICATED - already activated';

export const AuthenticatedAlreadyActivatedDisableCtaPostActivationEndDate = () => {
  const mockAem = new MockAdapter(api.aemVaProxyApi);

  mockAem.onGet(promotionsUri).reply(200, {
    data: [
      {
        registrationEndDate: '2019-01-01',
        registrationStartDate: '2019-03-14',
        registrationStatus: 'REGISTERED',
        activationCapMax: '48',
        isRecurringPromotion: 'Y',
        promotionCode: 'TPLPOINTS',
        promotionShortDescription: 'Easter Triple Points Offer',
        promotionEndDate: '2020-02-12',
        promotionStartDate: '2019-03-19',
        mustRegister: true,
        promotionStatus: 'RUNNING',
        promotionProvider: 'LCP',
        promotionName: '1A 7-Eleven 1st & 2nd Activity post Activation Bon',
        activityStartDate: '2021-11-16',
        registeredAt: '2021-11-16',
        activityEndDate: addDaysToToday(2),
        achievementMaxCount: 1,
        achievementCount: 0,
        totalPhaseNumber: 2,
        lastAchievedPhaseNumber: 1,
      },
    ],
  });
  mockAem.onPost(promotionsUri).reply(400, {
    code: 40084,
    detail: 'Member Has Already Activated This Promotion',
    status: 400,
    title: 'Already Activated',
  });

  return (
    <Provider store={configureStore({ user: { member: { loyaltyMembershipID: '123' } } })}>
      <ActivatedOffer {...activatedOfferMock} {...props} disableSecondaryActionPostActivationEndDate />
    </Provider>
  );
};

AuthenticatedAlreadyActivatedDisableCtaPostActivationEndDate.storyName =
  'AUTHENTICATED - already activated disable CTA post registrationEndDate';

export const AuthenticatedPromotionsClosed = () => {
  const mockAem = new MockAdapter(api.aemVaProxyApi);

  mockAem.onGet(promotionsUri).reply(200, {
    data: [
      {
        registrationEndDate: addDaysToToday(2),
        registrationStartDate: '2019-03-14',
        registrationStatus: 'REGISTRABLE',
        activationCapMax: '48',
        isRecurringPromotion: 'Y',
        promotionCode: 'TPLPOINTS',
        promotionShortDescription: 'Easter Triple Points Offer',
        promotionEndDate: '2020-02-12',
        promotionStartDate: '2019-03-19',
        mustRegister: true,
        promotionStatus: 'RUNNING',
        promotionProvider: 'LCP',
        promotionName: '1A 7-Eleven 1st & 2nd Activity post Activation Bon',
        activityStartDate: '2021-11-16',
        registeredAt: '2021-11-16',
        activityEndDate: addDaysToToday(2),
        achievementMaxCount: 1,
        achievementCount: 0,
        totalPhaseNumber: 2,
        lastAchievedPhaseNumber: 1,
      },
    ],
  });
  mockAem.onPost(promotionsUri).reply(400, {
    code: 40045,
    title: 'Promotion Closed',
    status: 400,
    detail: 'Activation Period for Promotion is Closed',
  });

  return (
    <Provider store={configureStore({ user: { member: { loyaltyMembershipID: '123' } } })}>
      <ActivatedOffer {...activatedOfferMock} {...props} />
    </Provider>
  );
};

AuthenticatedPromotionsClosed.storyName = 'AUTHENTICATED - promotions closed';

export const AuthenticatedNotInList = () => {
  const mockAem = new MockAdapter(api.aemVaProxyApi);

  mockAem.onGet(promotionsUri).reply(200, {
    data: [
      {
        registrationEndDate: addDaysToToday(2),
        registrationStartDate: '2019-03-14',
        registrationStatus: 'REGISTRABLE',
        activationCapMax: '48',
        isRecurringPromotion: 'Y',
        promotionCode: 'TPLPOINTS',
        promotionShortDescription: 'Easter Triple Points Offer',
        promotionEndDate: '2020-02-12',
        promotionStartDate: '2019-03-19',
        mustRegister: true,
        promotionStatus: 'RUNNING',
        promotionProvider: 'LCP',
        promotionName: '1A 7-Eleven 1st & 2nd Activity post Activation Bon',
        activityStartDate: '2021-11-16',
        registeredAt: '2021-11-16',
        activityEndDate: addDaysToToday(2),
        achievementMaxCount: 1,
        achievementCount: 0,
        totalPhaseNumber: 2,
        lastAchievedPhaseNumber: 1,
      },
    ],
  });
  mockAem.onPost(promotionsUri).reply(400, {
    code: 30173,
    detail: 'Member not in Segmentation List',
    status: 400,
    title: 'Not in List',
  });

  return (
    <Provider store={configureStore({ user: { member: { loyaltyMembershipID: '123' } } })}>
      <ActivatedOffer {...activatedOfferMock} {...props} />
    </Provider>
  );
};

AuthenticatedNotInList.storyName = 'AUTHENTICATED - not in list';

export const UnauthenticatedSuccessful = () => {
  const mockAem = new MockAdapter(api.aemVaProxyApi);

  mockAem.onGet(promotionsUri).reply(200, {
    data: [
      {
        registrationEndDate: addDaysToToday(1),
        registrationStartDate: '2019-03-14',
        registrationStatus: 'REGISTRABLE',
        activationCapMax: '48',
        isRecurringPromotion: 'Y',
        promotionCode: 'TPLPOINTS',
        promotionShortDescription: 'Easter Triple Points Offer',
        promotionEndDate: '2020-02-12',
        promotionStartDate: '2019-03-19',
        mustRegister: true,
        promotionStatus: 'RUNNING',
        promotionProvider: 'LCP',
        promotionName: '1A 7-Eleven 1st & 2nd Activity post Activation Bon',
        activityStartDate: '2021-11-16',
        registeredAt: '2021-11-16',
        activityEndDate: addDaysToToday(2),
        achievementMaxCount: 1,
        achievementCount: 0,
        totalPhaseNumber: 2,
        lastAchievedPhaseNumber: 1,
      },
    ],
  });
  mockAem.onPost(promotionsUri).reply(200, {
    data: {
      type: 'REGISTRATION',
      id: '619c471fa5b4b0e4ebffc983',
      promotionCode: 'MDE Campaign',
      promotionProvider: 'MDE System',
      registrationDate: '2021-11-23T01:42:55.951Z',
      channel: 'WEBSITE',
    },
  });

  return (
    <Provider store={store}>
      <ActivatedOffer {...activatedOfferMock} {...props} />
    </Provider>
  );
};

UnauthenticatedSuccessful.storyName = 'UNAUTHENTICATED - successful';

export const UnauthenticatedNotInList = () => {
  const mockAem = new MockAdapter(api.aemVaProxyApi);

  mockAem.onGet(promotionsUri).reply(200, {
    data: [
      {
        registrationEndDate: addDaysToToday(1),
        registrationStartDate: '2019-03-14',
        registrationStatus: 'REGISTRABLE',
        activationCapMax: '48',
        isRecurringPromotion: 'Y',
        promotionCode: 'TPLPOINTS',
        promotionShortDescription: 'Easter Triple Points Offer',
        promotionEndDate: '2020-02-12',
        promotionStartDate: '2019-03-19',
        mustRegister: true,
        promotionStatus: 'RUNNING',
        promotionProvider: 'LCP',
        promotionName: '1A 7-Eleven 1st & 2nd Activity post Activation Bon',
        activityStartDate: '2021-11-16',
        registeredAt: '2021-11-16',
        activityEndDate: addDaysToToday(2),
        achievementMaxCount: 1,
        achievementCount: 0,
        totalPhaseNumber: 2,
        lastAchievedPhaseNumber: 1,
      },
    ],
  });
  mockAem.onPost(promotionsUri).reply(400, {
    code: 30173,
    detail: 'Member not in Segmentation List',
    status: 400,
    title: 'Not in List',
  });

  return (
    <Provider store={store}>
      <ActivatedOffer {...activatedOfferMock} {...props} />
    </Provider>
  );
};

UnauthenticatedNotInList.storyName = 'UNAUTHENTICATED - not in list';

export const GenericErrorGet500 = () => {
  const mockAem = new MockAdapter(api.aemVaProxyApi);

  mockAem.onGet(promotionsUri).reply(500);

  return (
    <Provider store={store}>
      <ActivatedOffer {...activatedOfferMock} {...props} />
    </Provider>
  );
};

GenericErrorGet500.storyName = 'GENERIC ERROR - GET 500';

export const GenericErrorGetUnknownError = () => {
  const mockAem = new MockAdapter(api.aemVaProxyApi);

  mockAem.onGet(promotionsUri).reply(400, {
    code: 40084,
    detail: 'Unknown Error',
    status: 400,
    title: 'Unknown Error',
  });

  return (
    <Provider store={store}>
      <ActivatedOffer {...activatedOfferMock} {...props} />
    </Provider>
  );
};

GenericErrorGetUnknownError.storyName = 'GENERIC ERROR - GET UNKNOWN ERROR';

export const GenericErrorGetNotEligible = () => {
  const mockAem = new MockAdapter(api.aemVaProxyApi);

  mockAem.onGet(promotionsUri).reply(400, {
    code: 40082,
    detail: 'Not Eligible',
    status: 400,
    title: 'Not Eligible',
  });

  return (
    <Provider store={store}>
      <ActivatedOffer {...activatedOfferMock} {...props} />
    </Provider>
  );
};

GenericErrorGetNotEligible.storyName = 'GENERIC ERROR - GET NOT ELIGIBLE';

export const GenericErrorPost = () => {
  const mockAem = new MockAdapter(api.aemVaProxyApi);

  mockAem.onGet(promotionsUri).reply(200, {
    data: [
      {
        registrationEndDate: addDaysToToday(1),
        registrationStartDate: '2019-03-14',
        registrationStatus: 'REGISTRABLE',
        activationCapMax: '48',
        isRecurringPromotion: 'Y',
        promotionCode: 'TPLPOINTS',
        promotionShortDescription: 'Easter Triple Points Offer',
        promotionEndDate: '2020-02-12',
        promotionStartDate: '2019-03-19',
        mustRegister: true,
        promotionStatus: 'RUNNING',
        promotionProvider: 'LCP',
        promotionName: '1A 7-Eleven 1st & 2nd Activity post Activation Bon',
        activityStartDate: '2021-11-16',
        registeredAt: '2021-11-16',
        activityEndDate: addDaysToToday(2),
        achievementMaxCount: 1,
        achievementCount: 0,
        totalPhaseNumber: 2,
        lastAchievedPhaseNumber: 1,
      },
    ],
  });
  mockAem.onPost(promotionsUri).reply(500);

  return (
    <Provider store={store}>
      <ActivatedOffer {...activatedOfferMock} {...props} />
    </Provider>
  );
};

GenericErrorPost.storyName = 'GENERIC ERROR - POST';

export const RecurrentPromotionExpired = () => {
  const mockAem = new MockAdapter(api.aemVaProxyApi);

  mockAem.onGet('/va/loyalty/v2/promotions').reply(200, {
    data: [
      {
        promotionCode: 'SEALP711BP',
        promotionProvider: 'ADOBE',
        promotionStatus: 'RUNNING',
        promotionShortDescription: 'SEALP711BP title',
        promotionStartDate: '2022-07-29',
        promotionEndDate: '2022-08-09',
        registrationStatus: 'NON_REGISTRABLE',
        mustRegister: true,
        registrationStartDate: '2022-07-29',
        registrationEndDate: '2022-07-29',
        activityEndDate: '2022-07-30',
      },
      {
        promotionCode: 'SEALP711BP',
        promotionProvider: 'ADOBE',
        promotionStatus: 'RUNNING',
        promotionShortDescription: 'SEALP711BP title',
        promotionStartDate: '2022-07-29',
        promotionEndDate: '2022-08-09',
        registrationStatus: 'NON_REGISTRABLE',
        mustRegister: true,
        registrationStartDate: '2022-07-29',
        registrationEndDate: '2022-07-29',
        activityEndDate: '2022-07-30',
      },
    ],
  });

  return (
    <Provider store={configureStore({ user: { member: { loyaltyMembershipID: '123' } } })}>
      <ActivatedOffer {...activatedOfferMock} {...props} />
    </Provider>
  );
};

RecurrentPromotionExpired.storyName = 'AUTHENTICATED - Recurrent Promotions - Expired';

export const RecurrentPromotionOneActive = () => {
  const mockAem = new MockAdapter(api.aemVaProxyApi);

  mockAem.onGet('/va/loyalty/v2/promotions').reply(200, {
    data: [
      {
        promotionCode: 'SEALP711BP',
        promotionProvider: 'ADOBE',
        promotionStatus: 'RUNNING',
        promotionShortDescription: 'SEALP711BP title',
        promotionStartDate: '2022-07-29',
        promotionEndDate: '2022-08-09',
        registrationStatus: 'REGISTERED',
        mustRegister: true,
        registrationStartDate: '2022-07-29',
        registrationEndDate: addDaysToToday(2),
        activityEndDate: addDaysToToday(2),
      },
      {
        promotionCode: 'PNTR3099',
        promotionProvider: 'ADOBE',
        promotionStatus: 'RUNNING',
        promotionShortDescription: 'SEALP711BP title',
        promotionStartDate: '2022-07-29',
        promotionEndDate: '2022-08-09',
        registrationStatus: 'REGISTRABLE',
        mustRegister: true,
        registrationStartDate: '2022-07-29',
        registrationEndDate: addDaysToToday(2),
        activityEndDate: addDaysToToday(2),
      },
      {
        promotionCode: 'SEABP100X2',
        promotionProvider: 'ADOBE',
        promotionStatus: 'RUNNING',
        promotionShortDescription: 'SEALP711BP title',
        promotionStartDate: '2022-07-29',
        promotionEndDate: '2022-08-09',
        registrationStatus: 'NON_REGISTRABLE',
        mustRegister: true,
        registrationStartDate: '2022-07-29',
        registrationEndDate: '2022-07-29',
        activityEndDate: '2022-07-30',
      },
    ],
  });

  return (
    <Provider store={configureStore({ user: { member: { loyaltyMembershipID: '123' } } })}>
      <ActivatedOffer {...activatedOfferMock} {...props} />
    </Provider>
  );
};

RecurrentPromotionOneActive.storyName = 'AUTHENTICATED - Recurrent Promotions one active';
