import React from 'react';
import ReactDOM from 'react-dom';
import get from 'lodash/get';
import map from 'lodash/map';
import size from 'lodash/size';
import { Provider } from 'react-redux';
import qs from 'qs';
import store from '../../stores';
import ActivatedOffer from './ActivatedOffer';
import analyticsSend from '../../utils/analytics';
import { COMPONENT_NAME } from '../../utils/common';

const ELEMENT_NAME = COMPONENT_NAME.activatedOffer;

function renderComponent(elements, hydrate) {
  map(elements, (element) => {
    const props = window.vffCoreWebsite[element.getAttribute(ELEMENT_NAME)];

    if (props) {
      const component = (
        <Provider store={store}>
          <ActivatedOffer {...props} />
        </Provider>
      );

      if (hydrate) {
        ReactDOM.hydrate(component, element);
      } else {
        ReactDOM.render(component, element);
      }
    }
  });
}

function sendInvalidOfferAnalytics(memberIDUsed) {
  analyticsSend({
    eventName: 'activate-offer-load-fail',
    eventLocation: 'offer-activation',
    eventFailReason: 'Invalid promo code',
    memberIDUsed: memberIDUsed || '',
  });
}

export default {
  elementName: ELEMENT_NAME,
  bootstrap: (id = null, hydrate = true) => {
    // Check for any invalid offers on the page and send analytics
    const failedElements = document.querySelectorAll('[aem-activated-offer-invalid]');

    if (size(failedElements) > 0) {
      const query = qs.parse(window.location.search, { ignoreQueryPrefix: true });

      document.addEventListener('myProfile', (e) => {
        const { authenticated, member } = e.data;
        if (authenticated) {
          sendInvalidOfferAnalytics(member.loyaltyMembershipID);
        } else {
          sendInvalidOfferAnalytics(query.customer_id);
        }
      });
    } else {
      // Valid offer content available
      const elements = document.querySelectorAll(`[${ELEMENT_NAME}${id ? `=${id}` : ''}]`);

      if (size(elements) > 0) {
        const isAuthorMode = get(window.vffCoreWebsite, 'websiteData.authoringMode');

        if (isAuthorMode) {
          renderComponent(elements, false);
        } else {
          document.addEventListener('myProfile', () => renderComponent(elements, hydrate));

          if (!hydrate) {
            renderComponent(elements, hydrate);
          }
        }
      }
    }
  },
};
