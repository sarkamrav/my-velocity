import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';

import A from '../../components/Button/A';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import { isCtaAvailable, COMPONENT_NAME } from '../../utils/common';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';

import styles from './StripBanner.css';

const StripBanner = ({
  title,
  description,
  ctaContainer,
  secondaryCtaContainer,
  containerColor,
  analyticsMetadata,
  className,
}) => {
  const analyticsMetadataKey = analyticsMetadata['analytics-metadata'];
  const [analyticsData, setAnalyticsData] = useState(analyticsMetadataKey);

  useEffect(() => {
    const commonAnalyticsData = window.vffCoreWebsite[analyticsMetadataKey] || {};

    setAnalyticsData({
      ...commonAnalyticsData,
      eventCategory: 'banner',
      eventLocation: 'stripBanner',
    });
  }, [analyticsMetadataKey]);

  const isFirstCtaAvailable = isCtaAvailable(ctaContainer);
  const isSecondCtaAvailable = isCtaAvailable(secondaryCtaContainer);

  function getCta(cta) {
    return (
      <A
        href={cta.ctaUrl}
        title={cta.ctaTitle}
        target={cta.ctaOpenInNewTab ? '_blank' : '_self'}
        buttonType={cta.ctaStyle}
        ctaAsLink={cta.ctaAsLink}
        ctaImage={cta.ctaImage}
      >
        {cta.ctaLabel}
      </A>
    );
  }

  return (
    <ErrorBoundary section={COMPONENT_NAME.stripBanner}>
      <div
        className={cx(styles.container, className, {
          [styles.darkPurple]: containerColor === 'dark-purple',
          [styles.palePurple]: containerColor === 'pale-purple',
        })}
      >
        <div className={styles.content}>
          <div className={styles.innerContent}>
            {title ? <h2 className={styles.title}>{title}</h2> : null}

            {description ? (
              <div
                analytics-metadata={
                  typeof analyticsData === 'string' ? analyticsData : JSON.stringify({ ...analyticsData })
                }
              >
                <RichTextContent className={styles.description} content={description} />
              </div>
            ) : null}
          </div>

          {(isFirstCtaAvailable || isSecondCtaAvailable) && (
            <div
              className={styles.ctaContainer}
              analytics-metadata={
                typeof analyticsData === 'string'
                  ? analyticsData
                  : JSON.stringify({
                      ...analyticsData,
                      eventName: 'cta-interaction',
                    })
              }
            >
              {isFirstCtaAvailable && getCta(ctaContainer)}

              {isSecondCtaAvailable && getCta(secondaryCtaContainer)}
            </div>
          )}
        </div>
      </div>
    </ErrorBoundary>
  );
};

StripBanner.propTypes = {
  title: PropTypes.string,
  className: PropTypes.string,
  description: PropTypes.string,
  ctaContainer: PropTypes.shape({}),
  secondaryCtaContainer: PropTypes.shape({}),
  containerColor: PropTypes.string,
  analyticsMetadata: PropTypes.shape({
    'analytics-metadata': PropTypes.string,
  }),
};

StripBanner.defaultProps = {
  title: '',
  className: '',
  description: '',
  ctaContainer: null,
  secondaryCtaContainer: null,
  containerColor: '',
  analyticsMetadata: {},
};

export default StripBanner;
