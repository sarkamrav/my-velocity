import React from 'react';

import stripBannerMock from './mocks/strip-banner.mock.json';
import stripBannerTwoCtas from './mocks/strip-banner--two-ctas.mock.json';
import stripBannerLightBackground from './mocks/strip-banner--light-background.mock.json';
import StripBanner from './StripBanner';

export default {
  title: 'Strip Banner',
};

export const SingleCta = () => <StripBanner {...stripBannerMock} />;
export const TwoCtas = () => <StripBanner {...stripBannerTwoCtas} />;
export const lightBackground = () => <StripBanner {...stripBannerLightBackground} />;
