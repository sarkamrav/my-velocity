import React, { useState, useCallback } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { DateTime } from 'luxon';
import noop from 'lodash/noop';
import toLower from 'lodash/toLower';
import cx from 'classnames';
import get from 'lodash/get';

import A from '../../components/Button/A';
import Button from '../../components/Button/Button';
import Icon from '../../components/Icon/Icon';
import Confirm from '../../components/Confirm/Confirm';
import Logo from '../../images/vff-logo.svg';
import api from '../../utils/api';
import Collapse from '../../components/Collapse/Collapse';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import MoreContentToggleButton from '../../components/MoreContentToggleButton/MoreContentToggleButton';
import { getApiActionName, getApiError, sendToNewRelic } from '../../utils/newRelic';
import { COMPONENT_NAME, getAuthorableErrorMsg } from '../../utils/common';
import useModal from '../../hooks/useModal';
import Modal, { modalTheme } from '../../components/Modal/Modal';
import KrisFlyerLinkForm from './components/KrisFlyerLinkForm/KrisFlyerLinkForm';
import ConfirmationTile from '../../components/Modal/components/ConfirmationTile/ConfirmationTile';
import SuccessMessageTile from '../../components/SuccessMessageTile/SuccessMessageTile';
import KrisFlyerPointsTransferForm from './components/KrisFlyerPointsTransferForm/KrisFlyerPointsTransferForm';
import { getCurrentPointsBalance, getLoyaltyMembershipID } from '../../stores/utilities';
import { minimumPointsToTransfer, partnerMembershipIdFormField } from './constants';
import AccountDetail from './components/AccountDetail/AccountDetail';
import InfoTile from '../../components/InfoTile/InfoTile';
import syncText from '../../utils/syncText';
import MessageTile, { messageTileTheme } from '../../components/MessageTile/MessageTile';
import { updateUserPointsBalanceAction } from '../../stores/actions/users';

import styles from './ConnectedPartnerCard.css';

const ConnectedPartnerCard = ({
  updateUserPointsBalance,
  user,
  partner,
  consent,
  refreshPartnerList,
  contentIdPrefix,
  apiPartnerDetail,
  setAnchorElement,
  anchorElement,
}) => {
  const [confirmRemoveConsent, setConfirmRemoveConsent] = useState(false);
  const [isDelinkInfoVisible, setIsDelinkInfoVisible] = useState(false);
  const [isDelinkFromPartnerVisible, setIsDelinkFromPartnerVisible] = useState(false);
  const [removingConsent, setRemovingConsent] = useState(false);
  const [isShowingMoreContent, setIsShowingMoreContent] = useState(
    () => anchorElement === toLower(partner?.partnerCode),
  );
  const contendId = `${contentIdPrefix}-connected-partner-card-${partner.partnerCode}`;
  const {
    ctaContainer: partnerCtaContainer = {},
    isAirlineTransfer = false,
    accountLinkingFormData,
    pointsTransferFormData,
  } = partner;

  const { isShowing: airlineTransferLinkFormShowing, toggle: toggleAirlineTransferLinkFormShowing } = useModal();
  const [isAirlineTransferLinking, setIsAirlineTransferLinking] = useState(false);
  const [isAirlineTransferLinked, setIsAirlineTransferLinked] = useState(false);
  const [isAirlineTransferLinkError, setIsAirlineTransferLinkError] = useState(false);

  const { isShowing: airlineTransferConfirmShowing, toggle: toggleAirlineTransferConfirmShowing } = useModal();
  const [pointsTransferAmount, setPointsTransferAmount] = useState(0);
  const [isAirlineTransferPosting, setIsAirlineTransferPosting] = useState(false);
  const [isAirlineTransferPosted, setIsAirlineTransferPosted] = useState(false);
  const [isAirlineTransferPostError, setIsAirlineTransferPostError] = useState(false);

  const { isShowing: airlineTransferUnlinkShowing, toggle: toggleAirlineTransferUnlinkShowing } = useModal();
  const [isAirlineTransferUnlinking, setIsAirlineTransferUnlinking] = useState(false);
  const [isAirlineTransferUnlinked, setIsAirlineTransferUnlinked] = useState(false);
  const [isAirlineTransferUnlinkError, setIsAirlineTransferUnlinkError] = useState(false);

  const [postError, setPostError] = useState('');

  const velocityPoints = getCurrentPointsBalance(user);
  const velocityMembershipId = getLoyaltyMembershipID(user);
  const partnerMembershipId = get(apiPartnerDetail, 'partner.membershipId', '');

  const handleAirlineTransferUnlink = useCallback(async () => {
    const airlinePartnerUnlinkApiUri = '/loyalty/v2/partner-relationships';

    try {
      setIsAirlineTransferUnlinking(true);
      setIsAirlineTransferUnlinked(false);
      setIsAirlineTransferUnlinkError(false);

      await api.vffV2Api.patch(airlinePartnerUnlinkApiUri, {
        data: {
          delete: {
            velocity: {
              membershipId: velocityMembershipId,
            },
            partner: {
              partnerProgram: consent?.partner?.partnerProgram,
            },
          },
        },
      });

      setIsAirlineTransferUnlinking(false);
      setIsAirlineTransferUnlinked(true);
    } catch (err) {
      setIsAirlineTransferUnlinking(false);
      setIsAirlineTransferUnlinkError(true);

      sendToNewRelic(
        getApiActionName(api.vffV2Api.defaults.baseURL, airlinePartnerUnlinkApiUri),
        getApiError(COMPONENT_NAME.connectedPartners, err),
      );
    }
  }, [consent?.partner?.partnerProgram, velocityMembershipId]);

  const handleRemoveConsent = useCallback(async () => {
    const removePartnerApiUri = '/loyalty/v2/partner-relationships';

    try {
      setRemovingConsent(true);

      await api.vffV2Api.patch(removePartnerApiUri, {
        data: {
          delete: {
            velocity: {
              membershipId: velocityMembershipId,
            },
            partner: {
              partnerProgram: consent?.partner?.partnerProgram,
            },
          },
        },
      });

      if (refreshPartnerList) {
        await refreshPartnerList();
      }

      setConfirmRemoveConsent(false);
      setRemovingConsent(false);
    } catch (err) {
      setRemovingConsent(false);
      sendToNewRelic(
        getApiActionName(api.vffV2Api.defaults.baseURL, removePartnerApiUri),
        getApiError(COMPONENT_NAME.connectedPartners, err),
      );
    }
  }, [consent, refreshPartnerList, velocityMembershipId]);

  const handleShowMoreButtonClick = useCallback(() => {
    setIsShowingMoreContent((prevState) => !prevState);
  }, []);

  const handleAirlineTransferLink = useCallback(
    async (e, formData) => {
      e.preventDefault();
      const partnerApiUri = '/loyalty/v2/partner-relationships';

      try {
        setIsAirlineTransferLinking(true);
        setIsAirlineTransferLinked(false);
        setIsAirlineTransferLinkError(false);

        await api.vffV2Api.post(partnerApiUri, {
          data: {
            partner: {
              partnerProgram: partner?.partnerCode,
              membershipId: formData[partnerMembershipIdFormField],
            },
            velocity: { membershipId: velocityMembershipId },
            termsAndConditionsAccepted: formData.termsAndCondition,
          },
        });

        setIsAirlineTransferLinking(false);
        setIsAirlineTransferLinked(true);
      } catch (err) {
        setIsAirlineTransferLinking(false);
        setIsAirlineTransferLinkError(true);
        setPostError(getAuthorableErrorMsg(err, get(accountLinkingFormData, 'errorMessages')));

        sendToNewRelic(
          getApiActionName(api.vffV2Api.defaults.baseURL, partnerApiUri),
          getApiError(COMPONENT_NAME.connectedPartners, err),
        );
      }
    },
    [partner?.partnerCode, accountLinkingFormData, velocityMembershipId],
  );

  const handlePointsTransfer = useCallback(
    async (e) => {
      e.preventDefault();
      const pointsCrossPlatformTransferApiUri = '/loyalty/v2/points/cross-program-transfer';

      try {
        setIsAirlineTransferPosting(true);
        setIsAirlineTransferPosted(false);
        setIsAirlineTransferPostError(false);

        await api.vffV2Api.post(pointsCrossPlatformTransferApiUri, {
          data: {
            velocity: {
              membershipId: velocityMembershipId,
              points: {
                amount: pointsTransferAmount,
              },
            },
            partner: {
              membershipId: partnerMembershipId,
              partnerProgram: partner?.partnerCode,
            },
            termsAndConditionsAccepted: true, // no form field for tnc in this case
          },
        });

        setIsAirlineTransferPosting(false);
        setIsAirlineTransferPosted(true);
        updateUserPointsBalance(velocityPoints - pointsTransferAmount);
      } catch (err) {
        setIsAirlineTransferPosting(false);
        setIsAirlineTransferPostError(true);
        setPostError(getAuthorableErrorMsg(err, get(pointsTransferFormData, 'errorMessages')));

        sendToNewRelic(
          getApiActionName(api.vffV2Api.defaults.baseURL, pointsCrossPlatformTransferApiUri),
          getApiError(COMPONENT_NAME.connectedPartners, err),
        );
      }
    },
    [
      partner.partnerCode,
      partnerMembershipId,
      pointsTransferAmount,
      updateUserPointsBalance,
      velocityMembershipId,
      velocityPoints,
      pointsTransferFormData,
    ],
  );

  // For linking flow
  const airlineTransferLinkedOnDismiss = useCallback(() => {
    toggleAirlineTransferLinkFormShowing();
    setAnchorElement(toLower(partner.partnerCode));
    refreshPartnerList();
  }, [partner.partnerCode, refreshPartnerList, setAnchorElement, toggleAirlineTransferLinkFormShowing]);

  const airlineTransferLinkOnModalDismiss = useCallback(() => {
    if (isAirlineTransferLinking) {
      return noop;
    }

    return isAirlineTransferLinked ? airlineTransferLinkedOnDismiss() : toggleAirlineTransferLinkFormShowing();
  }, [
    isAirlineTransferLinked,
    isAirlineTransferLinking,
    airlineTransferLinkedOnDismiss,
    toggleAirlineTransferLinkFormShowing,
  ]);

  // For points transfer flow
  const airlineTransferPointsConfirmedOnDismiss = useCallback(() => {
    toggleAirlineTransferConfirmShowing();
    setIsAirlineTransferPosted(false);
    setIsAirlineTransferPostError(false);
  }, [toggleAirlineTransferConfirmShowing]);

  const airlineTransferPointsConfirmOnModalDismiss = useCallback(() => {
    if (isAirlineTransferPosting) {
      return noop;
    }

    return isAirlineTransferPosted ? airlineTransferPointsConfirmedOnDismiss() : toggleAirlineTransferConfirmShowing();
  }, [
    airlineTransferPointsConfirmedOnDismiss,
    isAirlineTransferPosted,
    isAirlineTransferPosting,
    toggleAirlineTransferConfirmShowing,
  ]);

  // For unlink
  const airlineTransferUnlinkedOnDismiss = useCallback(() => {
    toggleAirlineTransferUnlinkShowing();
    refreshPartnerList();
  }, [refreshPartnerList, toggleAirlineTransferUnlinkShowing]);

  const airlineTransferUnlinkOnModalDismiss = useCallback(() => {
    if (isAirlineTransferUnlinking) {
      return noop;
    }

    return isAirlineTransferUnlinked ? airlineTransferUnlinkedOnDismiss() : toggleAirlineTransferUnlinkShowing();
  }, [
    airlineTransferUnlinkedOnDismiss,
    isAirlineTransferUnlinked,
    isAirlineTransferUnlinking,
    toggleAirlineTransferUnlinkShowing,
  ]);

  const minimumPointsMessage = get(pointsTransferFormData, 'minimumPointsMessage.infoBoxDescription', '');
  const airlineTransferPartnerName = isAirlineTransfer
    ? partner?.loyaltyProgramName || partner?.partnerName
    : partner?.partnerName;

  return (
    <div className={styles.container} id={toLower(partner.partnerCode)}>
      <div className={styles.partnerInfoContainer}>
        <div className={styles.partnerInfo}>
          <div className={styles.partner}>
            <div className={styles.logoContainer}>
              <img src={partner.logo} className={styles.logo} alt={partner.partnerName} />
            </div>
            <div className={styles.partnerName}>{airlineTransferPartnerName}</div>
          </div>
          <div className={styles.partnerDescription}>
            {!consent ? (
              <>
                {!isAirlineTransfer && (
                  <span>Login to your {partner.partnerName} account and select Velocity to connect your account.</span>
                )}

                {isAirlineTransfer && (
                  <span>
                    Link your Accounts and transfer Points from Velocity to your {airlineTransferPartnerName} Account
                  </span>
                )}
              </>
            ) : (
              <span className={styles.successMessage}>
                <Icon name="TickCircleClosed" size="extra-small" className={styles.successIcon} />
                <span>You connected your account on {DateTime.fromISO(consent.startDate).toFormat('dd/MM/yyyy')}</span>
              </span>
            )}
          </div>

          <div className={styles.detailButtonContainer}>
            {partner.description && (
              <MoreContentToggleButton
                isShowingMore={isShowingMoreContent}
                aria-controls={contendId}
                displayMode="dark"
                readMoreLabel={consent && isAirlineTransfer ? 'transfer points' : partner.readMoreLabel}
                readLessLabel={consent && isAirlineTransfer ? 'transfer points' : partner.readLessLabel}
                onClick={handleShowMoreButtonClick}
              />
            )}
          </div>
        </div>

        <Collapse
          isOpen={isShowingMoreContent}
          id={contendId}
          role="region"
          aria-live="polite"
          aria-label={partner.readMoreLabel}
        >
          {!isAirlineTransfer && (
            <RichTextContent
              className={styles.moreDescription}
              content={!consent ? partner.nonConnectedDescription : partner.description}
            />
          )}

          {isAirlineTransfer && (
            <>
              {!consent && (
                <RichTextContent className={styles.moreDescription} content={partner.nonConnectedDescription} />
              )}

              {consent && (
                <div className={styles.airlineTransferContainer}>
                  <RichTextContent className={styles.airlineTransferLinkedDescription} content={partner.description} />

                  {velocityPoints >= minimumPointsToTransfer ? (
                    <KrisFlyerPointsTransferForm
                      pointsTransferFormData={pointsTransferFormData}
                      velocityPoints={velocityPoints}
                      partnerName={partner?.partnerName}
                      partnerMembershipId={partnerMembershipId}
                      onSubmit={(e, points) => {
                        e.preventDefault();
                        toggleAirlineTransferConfirmShowing();
                        setPointsTransferAmount(parseInt(points, 10));
                      }}
                    />
                  ) : (
                    <>
                      <AccountDetail
                        className={styles.marginTop24}
                        velocityPoints={velocityPoints}
                        partnerMembershipId={partnerMembershipId}
                      />

                      {minimumPointsMessage && (
                        <InfoTile className={styles.marginTop24} description={minimumPointsMessage} />
                      )}
                    </>
                  )}

                  {pointsTransferFormData?.secondaryDescription && (
                    <RichTextContent
                      className={cx(styles.airlineTransferLinkedDescription, styles.marginTop24)}
                      content={pointsTransferFormData?.secondaryDescription}
                    />
                  )}
                </div>
              )}
            </>
          )}
        </Collapse>
      </div>

      <div className={styles.callToActionContainer}>
        {!isAirlineTransfer && (
          <>
            {consent && partner.delinkDisplayMode === 'delinkFromUs' && (
              <Button buttonType="red-link" onClick={() => setConfirmRemoveConsent(true)}>
                Remove Access
              </Button>
            )}

            {consent && partner.delinkDisplayMode === 'info' && (
              <Button buttonType="red-link" onClick={() => setIsDelinkInfoVisible(true)}>
                Remove Access
              </Button>
            )}

            {consent && partner.delinkDisplayMode === 'delinkFromPartner' && (
              <Button buttonType="red-link" onClick={() => setIsDelinkFromPartnerVisible(true)}>
                Remove Access
              </Button>
            )}

            {!consent && (
              <A
                buttonType="purple-link"
                className={styles.connectLink}
                title={partner.partnerUrlLabel}
                href={partner.partnerUrl}
                target={partner.openPartnerUrlInNewTab ? '_blank' : '_self'}
                ctaAsLink={false}
              >
                {partner.partnerUrlLabel}
              </A>
            )}
          </>
        )}

        {isAirlineTransfer && (
          <>
            {!consent ? (
              <Button
                buttonType="purple-link"
                onClick={() => {
                  setIsAirlineTransferLinkError(false);
                  setIsAirlineTransferLinked(false);
                  toggleAirlineTransferLinkFormShowing();
                }}
              >
                {partner.partnerUrlLabel}
              </Button>
            ) : (
              <Button
                buttonType="red-link"
                onClick={() => {
                  setIsAirlineTransferUnlinkError(false);
                  setIsAirlineTransferLinked(false);
                  toggleAirlineTransferUnlinkShowing();
                }}
              >
                Unlink Account
              </Button>
            )}
          </>
        )}

        {airlineTransferLinkFormShowing && (
          <Modal onDismiss={airlineTransferLinkOnModalDismiss} aria-label="Confirm" theme={modalTheme.confirmV1}>
            {!isAirlineTransferLinked && (
              <KrisFlyerLinkForm
                user={user}
                accountLinkingFormData={accountLinkingFormData}
                isKrisFlyerLinking={isAirlineTransferLinking}
                isKrisFlyerLinkError={isAirlineTransferLinkError}
                krisFlyerErrorMessage={postError.description}
                onCancel={(e) => {
                  e.preventDefault();
                  return isAirlineTransferLinking ? noop : toggleAirlineTransferLinkFormShowing();
                }}
                onSubmit={handleAirlineTransferLink}
              />
            )}

            {isAirlineTransferLinked && (
              <ConfirmationTile
                cancelCtaContainer={get(accountLinkingFormData, 'confirmation.secondaryCtaContainer', null)}
                confirmCtaContainer={get(accountLinkingFormData, 'confirmation.ctaContainer', null)}
                onDismiss={airlineTransferLinkedOnDismiss}
                onSubmit={airlineTransferLinkedOnDismiss}
              >
                <SuccessMessageTile
                  isSmallSizeIcon
                  className={styles.accountLinkedSuccess}
                  iconPath={get(accountLinkingFormData, 'confirmation.iconUrl', '')}
                  title={get(accountLinkingFormData, 'confirmation.title', '')}
                  content={get(accountLinkingFormData, 'confirmation.description', '')}
                />
              </ConfirmationTile>
            )}
          </Modal>
        )}

        {airlineTransferConfirmShowing && (
          <Modal
            onDismiss={airlineTransferPointsConfirmOnModalDismiss}
            aria-label="airline points transfer"
            theme={modalTheme.confirmV1}
          >
            {!isAirlineTransferPosted && (
              <ConfirmationTile
                cancelCtaContainer={get(pointsTransferFormData, 'review.secondaryCtaContainer', null)}
                confirmCtaContainer={get(pointsTransferFormData, 'review.ctaContainer', null)}
                onDismiss={isAirlineTransferPosting ? noop : toggleAirlineTransferConfirmShowing}
                onSubmit={handlePointsTransfer}
                disabled={isAirlineTransferPosting}
              >
                {isAirlineTransferPostError && (
                  <MessageTile
                    className={styles.airlineTransferPostError}
                    theme={messageTileTheme.error}
                    description={postError.description}
                  />
                )}

                <SuccessMessageTile
                  iconPath={get(pointsTransferFormData, 'review.iconUrl')}
                  className={styles.airlineTransferConfirmModal}
                  title={get(pointsTransferFormData, 'review.title')}
                  subTitle={`${pointsTransferAmount} Velocity Points`}
                  content={`to your ${airlineTransferPartnerName} account ${partnerMembershipId}`}
                />
              </ConfirmationTile>
            )}

            {isAirlineTransferPosted && (
              <ConfirmationTile
                cancelCtaContainer={null}
                confirmCtaContainer={get(pointsTransferFormData, 'confirmation.ctaContainer')}
                onSubmit={airlineTransferPointsConfirmedOnDismiss}
              >
                <SuccessMessageTile
                  className={styles.airlineTransferConfirmModal}
                  iconPath={get(pointsTransferFormData, 'confirmation.iconUrl')}
                  title={get(pointsTransferFormData, 'confirmation.title')}
                  content={syncText(get(pointsTransferFormData, 'confirmation.description'), {
                    partnerMembershipId,
                    partnerName: airlineTransferPartnerName,
                  })}
                />
              </ConfirmationTile>
            )}
          </Modal>
        )}

        {airlineTransferUnlinkShowing && (
          <Modal
            onDismiss={airlineTransferUnlinkOnModalDismiss}
            aria-label="unlink account"
            theme={modalTheme.confirmV1}
          >
            {!isAirlineTransferUnlinked && (
              <ConfirmationTile
                cancelCtaContainer={get(accountLinkingFormData, 'accountUnlinking.secondaryCtaContainer')}
                confirmCtaContainer={get(accountLinkingFormData, 'accountUnlinking.primaryCtaContainer')}
                onDismiss={isAirlineTransferUnlinking ? noop : toggleAirlineTransferUnlinkShowing}
                onSubmit={handleAirlineTransferUnlink}
                disabled={isAirlineTransferUnlinking}
              >
                {isAirlineTransferUnlinkError && (
                  <MessageTile
                    className={styles.airlineTransferUnlinkError}
                    theme={messageTileTheme.error}
                    description={get(
                      accountLinkingFormData,
                      'accountUnlinking.errorMessages.defaultErrorMessage.description',
                    )}
                  />
                )}

                <SuccessMessageTile
                  iconPath={get(accountLinkingFormData, 'accountUnlinking.iconUrl')}
                  className={styles.airlineTransferConfirmModal}
                  title={get(accountLinkingFormData, 'accountUnlinking.title')}
                  content={syncText(get(accountLinkingFormData, 'accountUnlinking.description'), {
                    partnerName: airlineTransferPartnerName,
                  })}
                />
              </ConfirmationTile>
            )}

            {isAirlineTransferUnlinked && (
              <ConfirmationTile
                cancelCtaContainer={null}
                confirmCtaContainer={get(accountLinkingFormData, 'accountUnlinking.confirmation.ctaContainer')}
                onSubmit={airlineTransferUnlinkedOnDismiss}
              >
                <SuccessMessageTile
                  isSmallSizeIcon
                  iconPath={get(accountLinkingFormData, 'accountUnlinking.confirmation.iconUrl')}
                  className={styles.airlineTransferConfirmModal}
                  title={get(accountLinkingFormData, 'accountUnlinking.confirmation.title')}
                  content={syncText(get(accountLinkingFormData, 'accountUnlinking.confirmation.description'), {
                    partnerName: partner?.partnerName,
                  })}
                />
              </ConfirmationTile>
            )}
          </Modal>
        )}

        {isDelinkFromPartnerVisible ? (
          <Confirm
            onDismiss={() => setIsDelinkFromPartnerVisible(false)}
            onSubmit={() => {
              window.open(partnerCtaContainer.ctaUrl, partnerCtaContainer.ctaOpenInNewTab ? '_blank' : '_self');
              setIsDelinkFromPartnerVisible(false);
            }}
            submitText={partnerCtaContainer.ctaLabel}
            dismissText=""
          >
            <div className={styles.removeAccessContent}>
              <div className={styles.logoContainer}>
                <Logo />
              </div>
              <RichTextContent content={partner.delinkInfo} />
            </div>
          </Confirm>
        ) : null}

        {isDelinkInfoVisible ? (
          <Confirm
            onDismiss={() => setIsDelinkInfoVisible(false)}
            onSubmit={() => setIsDelinkInfoVisible(false)}
            submitText={partnerCtaContainer.ctaLabel}
            dismissText=""
            disabled={removingConsent}
          >
            <div className={styles.removeAccessContent}>
              <div className={styles.logoContainer}>
                <Logo />
              </div>
              <RichTextContent content={partner.delinkInfo} />
            </div>
          </Confirm>
        ) : null}

        {confirmRemoveConsent ? (
          <Confirm
            onDismiss={() => setConfirmRemoveConsent(false)}
            onSubmit={handleRemoveConsent}
            submitText={partnerCtaContainer.ctaLabel}
            dismissText="Cancel"
            disabled={removingConsent}
          >
            <div className={styles.removeAccessContent}>
              <div className={styles.logoContainer}>
                <Logo />
              </div>
              <RichTextContent className={styles.description} content={partner.delinkInfo} />
            </div>
          </Confirm>
        ) : null}
      </div>
    </div>
  );
};

ConnectedPartnerCard.propTypes = {
  updateUserPointsBalance: PropTypes.func,
  partner: PropTypes.shape({
    delinkDisplayMode: PropTypes.oneOf(['info', 'delinkFromPartner', 'delinkFromUs']),
    partnerUrlLabel: PropTypes.string,
    partnerUrl: PropTypes.string,
    nonConnectedDescription: PropTypes.string,
    description: PropTypes.string,
    delinkInfo: PropTypes.string,
    partnerCode: PropTypes.string,
    ctaContainer: PropTypes.shape({}),
    accountLinkingFormData: PropTypes.shape({}),
    pointsTransferFormData: PropTypes.shape({
      secondaryDescription: PropTypes.string,
    }),
    readMoreLabel: PropTypes.string,
    readLessLabel: PropTypes.string,
    partnerName: PropTypes.string,
    loyaltyProgramName: PropTypes.string,
    accountLinkingFormKey: PropTypes.string,
    pointsTransferFormKey: PropTypes.string,
    openPartnerUrlInNewTab: PropTypes.bool,
    isAirlineTransfer: PropTypes.bool,
    logo: PropTypes.string,
  }).isRequired,
  apiPartnerDetail: PropTypes.shape({}),
  consent: PropTypes.shape({
    startDate: PropTypes.string,
    partner: PropTypes.shape({
      partnerProgram: PropTypes.string,
    }),
  }),
  refreshPartnerList: PropTypes.func,
  setAnchorElement: PropTypes.func,
  anchorElement: PropTypes.string,
  contentIdPrefix: PropTypes.string,
  user: PropTypes.shape({}),
};

ConnectedPartnerCard.defaultProps = {
  updateUserPointsBalance: noop,
  apiPartnerDetail: null,
  consent: null,
  refreshPartnerList: null,
  setAnchorElement: null,
  anchorElement: '',
  contentIdPrefix: '',
  user: null,
};

const mapDispatchToProps = (dispatch) => ({
  updateUserPointsBalance: (payload) => {
    dispatch(updateUserPointsBalanceAction(payload));
  },
});

export default connect(null, mapDispatchToProps)(ConnectedPartnerCard);
