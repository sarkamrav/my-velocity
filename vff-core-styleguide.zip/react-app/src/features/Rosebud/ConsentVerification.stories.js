import React from 'react';
import MockAdapter from 'axios-mock-adapter';

import api from '../../utils/api';
import ConsentVerification from './ConsentVerification';
import ConsentVerificationMock from './mocks/ConsentVerification.mock.json';

export default {
  title: 'Velocity Connect Consent page',
};

export const ConsentVerificationSuccess = () => {
  const mockVff = new MockAdapter(api.velocityConnectPartnerApi, { delayResponse: 1000 });

  mockVff.onPost('/loyalty/partner/v2/partner-relationships').reply(200, {
    relationshipStatus: 'ACTIVE',
  });

  return <ConsentVerification {...ConsentVerificationMock} />;
};

ConsentVerificationSuccess.storyName = 'Consent Verification - success';
ConsentVerificationSuccess.parameters = {
  query: {
    'partner-code': 'SE',
    'redirect-uri': 'https://experience.velocityfrequentflyer.com/',
    token: 'fake-token',
  },
};

export const ConsentVerificationAccountError = () => {
  const mockVff = new MockAdapter(api.velocityConnectPartnerApi, { delayResponse: 1000 });

  mockVff.onPost('/loyalty/partner/v2/partner-relationships').reply(400, {
    code: 37926,
    title: 'Bad Request',
    detail: 'Member has already an active subscription.',
    status: 400,
  });

  return <ConsentVerification {...ConsentVerificationMock} />;
};

ConsentVerificationAccountError.storyName = 'Consent Verification - account error';
