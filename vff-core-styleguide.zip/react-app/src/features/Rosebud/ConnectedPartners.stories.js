import React from 'react';
import { Provider } from 'react-redux';
import MockAdapter from 'axios-mock-adapter';

import ConnectedPartners from './ConnectedPartners';
import api from '../../utils/api';
import { configureStore } from '../../stores';
import userData from '../Navigation/mocks/user.mock.json';
import connectedPartnersMock from './mocks/connected-partners.mock.json';
import accountLinkingFormData from './mocks/airline-points-transfer-linking-form.mock.json';
import pointsTransferFormData from './mocks/airline-points-transfer-transfer-form.mock.json';
import { getAirlineTransferData } from './ConnectedPartners.bootstrap';

export default {
  title: 'Connected partners',
};

const prepareWindowMockData = () => {
  window.vffCoreWebsite['aem-account-linking-form_xyz'] = accountLinkingFormData;
  window.vffCoreWebsite['aem-points-transfer-form_xyz'] = pointsTransferFormData;
  return getAirlineTransferData(connectedPartnersMock);
};

export const _ConnectedPartners = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api, { delayResponse: 1000 });
  mockVffV2.onGet('/loyalty/v2/partner-relationships?status=ACTIVE').reply(200, {
    data: [
      {
        partnerRelationshipId: '620c50ed2666b0e4a4770310',
        status: 'ACTIVE',
        startDate: '2021-05-23',
        endDate: '2050-12-31',
        partner: {
          partnerProgram: 'SE',
          membershipId: '1234567890',
        },
      },
      {
        partnerRelationshipId: '8765cd25469njhnbawq47767',
        status: 'ACTIVE',
        startDate: '2021-10-12',
        endDate: '2050-12-31',
        partner: {
          partnerProgram: 'FLYBUYSAS',
          membershipId: '99999999999',
        },
      },
    ],
  });

  const componentData = prepareWindowMockData();

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <ConnectedPartners {...componentData} />
    </Provider>
  );
};

export const ConnectedPartnersWithKrisFlyerNotConnected = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api, { delayResponse: 2000 });
  mockVffV2.onGet('/loyalty/v2/partner-relationships?status=ACTIVE').reply(200, {
    data: [
      {
        partnerRelationshipId: '620c50ed2666b0e4a4770310',
        status: 'ACTIVE',
        startDate: '2021-05-23',
        endDate: '2050-12-31',
        partner: {
          partnerProgram: 'SE',
          membershipId: '1234567890',
        },
      },
      {
        partnerRelationshipId: '8765cd25469njhnbawq47767',
        status: 'ACTIVE',
        startDate: '2021-10-12',
        endDate: '2050-12-31',
        partner: {
          partnerProgram: 'FLYBUYSAS',
          membershipId: '99999999999',
        },
      },
    ],
  });

  mockVffV2.onPost('/loyalty/v2/partner-relationships').reply(200);

  const componentData = prepareWindowMockData();

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <ConnectedPartners {...componentData} />
    </Provider>
  );
};
ConnectedPartnersWithKrisFlyerNotConnected.storyName = 'Connected Partners - KrisPartner not connected - link success';

export const ConnectedPartnersWithKrisFlyerNotConnectedLinkError = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api, { delayResponse: 1000 });
  mockVffV2.onGet('/loyalty/v2/partner-relationships?status=ACTIVE').reply(200, {
    data: [
      {
        partnerRelationshipId: '620c50ed2666b0e4a4770310',
        status: 'ACTIVE',
        startDate: '2021-05-23',
        endDate: '2050-12-31',
        partner: {
          partnerProgram: 'SE',
          membershipId: '1234567890',
        },
      },
      {
        partnerRelationshipId: '8765cd25469njhnbawq47767',
        status: 'ACTIVE',
        startDate: '2021-10-12',
        endDate: '2050-12-31',
        partner: {
          partnerProgram: 'FLYBUYSAS',
          membershipId: '99999999999',
        },
      },
    ],
  });

  mockVffV2.onPost('/loyalty/v2/partner-relationships').reply(500, {
    code: 4170,
    title: 'Validation Error',
    detail: 'Validation failed for below fields',
    status: 400,
  });

  const componentData = prepareWindowMockData();

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <ConnectedPartners {...componentData} />
    </Provider>
  );
};
ConnectedPartnersWithKrisFlyerNotConnectedLinkError.storyName =
  'Connected Partners - KrisPartner not connected - link error';

export const ConnectedPartnersWithKrisFlyerConnected = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api, { delayResponse: 1000 });
  mockVffV2.onGet('/loyalty/v2/partner-relationships?status=ACTIVE').reply(200, {
    data: [
      {
        partnerRelationshipId: '620c50ed2666b0e4a4770310',
        status: 'ACTIVE',
        startDate: '2021-05-23',
        endDate: '2050-12-31',
        partner: {
          partnerProgram: 'SE',
          membershipId: '1234567890',
        },
      },
      {
        partnerRelationshipId: '8765cd25469njhnbawq47767',
        status: 'ACTIVE',
        startDate: '2021-10-12',
        endDate: '2050-12-31',
        partner: {
          partnerProgram: 'FLYBUYSAS',
          membershipId: '99999999999',
        },
      },
      {
        partnerRelationshipId: '8765cd25469njhnbawq47761',
        status: 'ACTIVE',
        startDate: '2022-08-11',
        endDate: '2150-12-31',
        partner: {
          partnerProgram: 'KRISFLYER',
          membershipId: '8000008523',
        },
      },
    ],
  });

  mockVffV2.onPatch('/loyalty/v2/partner-relationships').reply(200);
  mockVffV2.onPost('/loyalty/v2/points/cross-program-transfer').reply(200, {
    data: {
      krisflyer: {
        reference: 'd2666b0e4a47620c50e70310',
      },
      velocity: {
        reference: '620c50ed2666b0e4a4770310',
      },
    },
  });

  const componentData = prepareWindowMockData();

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <ConnectedPartners {...componentData} />
    </Provider>
  );
};
ConnectedPartnersWithKrisFlyerConnected.storyName = 'Connected Partners - KrisPartner connected - success transfer';

export const ConnectedPartnersWithKrisFlyerConnectedError = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api, { delayResponse: 1000 });
  mockVffV2.onGet('/loyalty/v2/partner-relationships?status=ACTIVE').reply(200, {
    data: [
      {
        partnerRelationshipId: '620c50ed2666b0e4a4770310',
        status: 'ACTIVE',
        startDate: '2021-05-23',
        endDate: '2050-12-31',
        partner: {
          partnerProgram: 'SE',
          membershipId: '1234567890',
        },
      },
      {
        partnerRelationshipId: '8765cd25469njhnbawq47767',
        status: 'ACTIVE',
        startDate: '2021-10-12',
        endDate: '2050-12-31',
        partner: {
          partnerProgram: 'FLYBUYSAS',
          membershipId: '99999999999',
        },
      },
      {
        partnerRelationshipId: '8765cd25469njhnbawq47761',
        status: 'ACTIVE',
        startDate: '2022-08-11',
        endDate: '2150-12-31',
        partner: {
          partnerProgram: 'KRISFLYER',
          membershipId: '8000008523',
        },
      },
    ],
  });

  mockVffV2.onPatch('/loyalty/v2/partner-relationships').reply(200);
  mockVffV2.onPost('/loyalty/v2/points/cross-program-transfer').reply(400, {
    code: 4173,
    title: 'Validation Error',
    detail: 'Validation failed for below fields',
    status: 400,
  });

  const componentData = prepareWindowMockData();

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <ConnectedPartners {...componentData} />
    </Provider>
  );
};
ConnectedPartnersWithKrisFlyerConnectedError.storyName = 'Connected Partners - KrisPartner connected - Fail transfer';

export const ConnectedPartnersNone = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api);
  mockVffV2.onGet('/loyalty/v2/partner-relationships?status=ACTIVE').reply(200, []);

  const componentData = prepareWindowMockData();

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <ConnectedPartners {...componentData} />
    </Provider>
  );
};

ConnectedPartnersNone.storyName = 'Connected Partners - None';

export const ConnectedPartnersFailed = () => {
  const mockVffV2 = new MockAdapter(api.vffV2Api);
  mockVffV2.onGet('/loyalty/v2/partner-relationships?status=ACTIVE').reply(500);

  const componentData = prepareWindowMockData();

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <ConnectedPartners {...componentData} />
    </Provider>
  );
};

ConnectedPartnersFailed.storyName = 'Connected Partners - Failed';
