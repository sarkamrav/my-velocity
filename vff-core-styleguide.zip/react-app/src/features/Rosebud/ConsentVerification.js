/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import qs from 'qs';
import cx from 'classnames';

import Checkbox from '../../components/Form/Checkbox/Checkbox';
import A from '../../components/Button/A';
import Button from '../../components/Button/Button';
import Logo from '../../images/vff-logo.svg';
import Icon from '../../components/Icon/Icon';
import api from '../../utils/api';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import PolicyInfo from '../../components/PolicyInfo/PolicyInfo';
import syncText from '../../utils/syncText';
import { COMPONENT_NAME, getFamilyNameFromJwtToken, getGivenNameFromJwtToken } from '../../utils/common';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';

import styles from './ConsentVerification.css';

const ConsentVerification = ({ partners, description, accountErrorMessage, terms, ctaContainer }) => {
  const querystring = qs.parse(window.location.search, { ignoreQueryPrefix: true });
  const redirectUri = querystring['redirect-uri'];
  const partnerCode = querystring['partner-code'];
  const backButtonParameter = querystring['back-button'];
  const tokenInUrl = querystring.token;
  const apiKey = querystring?.apikey;

  const [error, setError] = useState(false);
  const [consentConfirmed, setConsentConfirmed] = useState(false);
  const [givingConsent, setGivingConsent] = useState(false);
  const [accountStatusError, setAccountStatusError] = useState(false);

  const partnerToConnect = _.find(partners, (partner) => _.toLower(partner.partnerCode) === _.toLower(partnerCode));

  useEffect(() => {
    api.velocityConnectPartnerApi.interceptors.request.use((config) => {
      try {
        const baseConfig = {
          ...config,
          headers: {
            ...config.headers,
            Authorization: `Bearer ${tokenInUrl}`,
            'X-Apikey': apiKey || partnerToConnect.apiKey,
            'Client-Channel': 'VELOCITY_CONNECT',
          },
        };

        return baseConfig;
      } catch (e) {
        return config;
      }
    });
  }, []);

  const getSuccessRedirectUri = useCallback(() => {
    const redirectUriArray = redirectUri.split('?');
    const parsedRedirectUriParameters = qs.parse(redirectUriArray[1], { ignoreQueryPrefix: true });

    return `${redirectUriArray[0]}${qs.stringify({ ...parsedRedirectUriParameters, result: true }, { addQueryPrefix: true })}`;
  }, [redirectUri]);

  const giveConsent = useCallback(async () => {
    const successRedirectUri = getSuccessRedirectUri();

    try {
      setGivingConsent(true);

      await api.velocityConnectPartnerApi.post('/loyalty/partner/v2/partner-relationships', {
        data: {
          partner: {
            partnerProgram: partnerCode,
            membershipId: partnerCode,
          },
          termsAndConditionsAccepted: consentConfirmed,
        },
      });

      window.location.href = successRedirectUri;
    } catch (err) {
      const errorCode = _.get(err, 'response.data.code');

      if (errorCode === 37926 || errorCode === 4177) {
        window.location.href = successRedirectUri;
      } else {
        setError(true);
        setGivingConsent(false);

        // Error Code 38935 and 38936 - Account Inactive
        if (errorCode === 38935 || errorCode === 38936) {
          setAccountStatusError(true);
        }
      }
    }
  }, [getSuccessRedirectUri, partnerCode, consentConfirmed]);

  if (error || !partnerToConnect || !redirectUri || !tokenInUrl) {
    return (
      <ErrorBoundary section={`${COMPONENT_NAME.partnerConsent}-error-screen`}>
        <div className={styles.container}>
          <div className={styles.header}>
            <Logo className={styles.logo} />
          </div>
          <div className={cx(styles.body, styles.error)}>
            <Icon name="ExclamationPoint" className={styles.icon} />
            <h1 className="heading heading--2 font-weight font-weight--bold">Something went wrong</h1>
            {accountStatusError && (
              <>
                <RichTextContent content={accountErrorMessage} className={styles.accountErrorMessage} />

                {ctaContainer && ctaContainer.ctaLabel ? (
                  <A
                    href={ctaContainer.ctaUrl}
                    title={ctaContainer.ctaTitle}
                    target={ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
                    buttonType={ctaContainer.ctaStyle}
                    ctaAsLink={ctaContainer.ctaAsLink}
                  >
                    {ctaContainer.ctaLabel}
                  </A>
                ) : null}
              </>
            )}

            {backButtonParameter !== 'hidden' && (
              <A buttonType="red-link" href={redirectUri}>
                Go Back
              </A>
            )}
          </div>
        </div>
      </ErrorBoundary>
    );
  }

  return (
    <ErrorBoundary section={COMPONENT_NAME.partnerConsent}>
      <div className={styles.container}>
        <div className={styles.header}>
          <Logo className={styles.logo} />
        </div>
        <div className={styles.body}>
          <RichTextContent
            className={cx('font-size font-size--medium font-weight', styles.bodyText)}
            content={syncText(description, {
              givenName: _.capitalize(getGivenNameFromJwtToken(tokenInUrl)),
              familyName: _.capitalize(getFamilyNameFromJwtToken(tokenInUrl)),
            })}
          />

          <PolicyInfo id="terms_and_conditions_header" title={terms.title} content={terms.text} />

          <Checkbox
            className={styles.checkbox}
            labelClassName={styles.checkboxLabel}
            label={
              <RichTextContent className="font-size font-size--extra-small font-weight" content={terms.buttonLabel} />
            }
            size="large"
            onChange={(e) => setConsentConfirmed(e.target.checked)}
            checked={consentConfirmed}
          />
        </div>
        <div className={styles.footer}>
          {backButtonParameter !== 'hidden' && (
            <A buttonType="red-link" href={redirectUri}>
              Go Back
            </A>
          )}

          <Button className={styles.continueButton} disabled={!consentConfirmed || givingConsent} onClick={giveConsent}>
            I agree <Icon name="Chevron" size="extra-small" className={styles.icon} />
          </Button>
        </div>
      </div>
    </ErrorBoundary>
  );
};

ConsentVerification.propTypes = {
  partners: PropTypes.arrayOf(PropTypes.shape({})),
  accountErrorMessage: PropTypes.string,
  description: PropTypes.string,
  terms: PropTypes.shape({
    title: PropTypes.string,
    text: PropTypes.string,
    buttonLabel: PropTypes.string,
  }),
  ctaContainer: PropTypes.shape({
    ctaUrl: PropTypes.string,
    ctaTitle: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaStyle: PropTypes.string,
    ctaAsLink: PropTypes.bool,
    ctaLabel: PropTypes.string,
  }),
};

ConsentVerification.defaultProps = {
  partners: [],
  accountErrorMessage: '',
  description: '',
  terms: {},
  ctaContainer: null,
};

export default ConsentVerification;
