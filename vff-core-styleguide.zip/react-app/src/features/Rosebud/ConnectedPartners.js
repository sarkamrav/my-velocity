import React, { useEffect, useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import find from 'lodash/find';
import _ from 'lodash';

import api from '../../utils/api';
import CallOut from '../CallOut/CallOut';
import ConnectedPartnerCard from './ConnectedPartnerCard';
import Container from '../../components/Container/Container';
import InformationAlert from '../../components/InformationAlert/InformationAlert';
import Loading from '../../components/Loading/Loading';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { COMPONENT_NAME, getParameterFromUrl, scrollToElement } from '../../utils/common';
import * as userData from '../../stores/utilities';
import { getHasLoggedIn } from '../../stores/utilities';

import styles from './ConnectedPartners.css';

const ConnectedPartners = ({
  user,
  availablePartnersTitle,
  connectedPartnersTitle,
  partners,
  noConnectedPartners,
  componentKey,
}) => {
  const [loading, setLoading] = useState(true);
  const [loaded, setLoaded] = useState(true);
  const [hasError, setHasError] = useState(false);

  const memberDataLoading = userData.getMemberDataLoading(user);
  const memberDataLoadError = userData.getMemberDataLoadError(user);
  const hasLoggedIn = getHasLoggedIn(user);

  const [connectedPartners, setConnectedPartners] = useState([]);
  const [availablePartners, setAvailablePartners] = useState([]);
  const [givenConsents, setGivenConsents] = useState([]);

  const [anchorElement, setAnchorElement] = useState(() => getParameterFromUrl('partnerCode'));

  const fetchConnectedPartners = useCallback(async () => {
    try {
      setLoaded(false);
      setLoading(true);
      const response = await api.vffV2Api.get('/loyalty/v2/partner-relationships?status=ACTIVE');
      const apiConnectedPartners = response.data.data;

      setGivenConsents(apiConnectedPartners);
      setConnectedPartners(
        _.filter(partners, (partner) =>
          _.some(apiConnectedPartners, {
            partner: {
              partnerProgram: partner.partnerCode,
            },
          }),
        ),
      );
      setAvailablePartners(
        _.reject(partners, (partner) =>
          _.some(apiConnectedPartners, {
            partner: {
              partnerProgram: partner.partnerCode,
            },
          }),
        ),
      );
      setLoading(false);
      setLoaded(true);
      setAnchorElement(null);
    } catch (err) {
      setHasError(true);
      setLoading(false);
    }
  }, [partners]);

  useEffect(() => {
    if (hasLoggedIn) {
      fetchConnectedPartners();
    }
  }, [fetchConnectedPartners, hasLoggedIn]);

  useEffect(() => {
    if (loaded && anchorElement) {
      const element = document.getElementById(anchorElement);
      scrollToElement(element, 32);
    }
  }, [loaded, anchorElement]);

  return (
    <ErrorBoundary section={COMPONENT_NAME.connectedPartners}>
      <Container>
        {((!hasLoggedIn && memberDataLoading) || loading) && <Loading containerClassName={styles.loading} />}

        {((!hasLoggedIn && memberDataLoadError) || hasError) && (
          <InformationAlert title="Something went wrong" content="" />
        )}

        {hasLoggedIn && loaded && (
          <>
            <h3 className={styles.title}>{connectedPartnersTitle}</h3>
            {_.size(connectedPartners) > 0 ? (
              <div className={styles.partners}>
                {_.map(connectedPartners, (partner) => (
                  <ConnectedPartnerCard
                    key={partner.partnerCode}
                    user={user}
                    setAnchorElement={setAnchorElement}
                    anchorElement={anchorElement}
                    partner={partner}
                    apiPartnerDetail={find(
                      givenConsents,
                      (consent) => consent?.partner?.partnerProgram === partner.partnerCode,
                    )}
                    consent={_.find(givenConsents, {
                      partner: {
                        partnerProgram: partner.partnerCode,
                      },
                      status: 'ACTIVE',
                    })}
                    refreshPartnerList={fetchConnectedPartners}
                    contentIdPrefix={componentKey}
                  />
                ))}
              </div>
            ) : (
              <CallOut
                className={styles.noMargin}
                iconUrl={_.get(noConnectedPartners, 'iconUrl')}
                title={_.get(noConnectedPartners, 'title', 'You have not connected to a Partner')}
                description={_.get(
                  noConnectedPartners,
                  'description',
                  'Get started by connecting next time you log into one of the partners below.',
                )}
              />
            )}

            {_.size(availablePartners) > 0 ? (
              <div className="vffutils__padding-top">
                <h3 className={styles.title}>{availablePartnersTitle}</h3>
                <div className={styles.partners}>
                  {_.map(availablePartners, (partner) => (
                    <ConnectedPartnerCard
                      anchorElement={anchorElement}
                      setAnchorElement={setAnchorElement}
                      key={partner.partnerCode}
                      user={user}
                      partner={partner}
                      contentIdPrefix={componentKey}
                      refreshPartnerList={fetchConnectedPartners}
                    />
                  ))}
                </div>
              </div>
            ) : null}
          </>
        )}
      </Container>
    </ErrorBoundary>
  );
};

ConnectedPartners.propTypes = {
  availablePartnersTitle: PropTypes.string,
  connectedPartnersTitle: PropTypes.string,
  componentKey: PropTypes.string,
  partners: PropTypes.arrayOf(PropTypes.shape({})),
  noConnectedPartners: PropTypes.shape({}),
  user: PropTypes.shape({}),
};

ConnectedPartners.defaultProps = {
  availablePartnersTitle: 'Available Partners',
  connectedPartnersTitle: 'Your Connected Partners',
  componentKey: '',
  partners: [],
  noConnectedPartners: {},
  user: null,
};

export default connect((state) => ({
  user: state.user,
}))(ConnectedPartners);
