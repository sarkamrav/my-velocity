export const minimumPointsToTransfer = 5000;

export const partnerMembershipIdFormField = 'partnerMembershipId';
