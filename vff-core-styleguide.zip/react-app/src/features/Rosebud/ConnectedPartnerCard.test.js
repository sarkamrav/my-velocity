import React from 'react';
import ConnectedPartnerCard from './ConnectedPartnerCard';
import 'regenerator-runtime/runtime';
import '../../unitTest/matchMedia.mock';
import { render } from '../../unitTest/test-utils';
import connectedPartnerSingle from './mocks/connected-partner-single/connected-partner-single.mock.json';
import connectedPartnerConsentMock from './mocks/connected-partner-single/connected-partner-consent.mock.json';

describe('ConnectedPartnerCard', () => {
  test('Should have a proper message with proper opt-in date', () => {
    const { container } = render(
      <ConnectedPartnerCard
        partner={connectedPartnerSingle}
        consent={connectedPartnerConsentMock}
        contentIdPrefix="myconnectedpartners_mTcUADEJ"
      />,
    );

    expect(container.querySelector('.src-features-Rosebud-ConnectedPartnerCard_successMessage').textContent).toEqual(
      'You connected your account on 14/11/2016',
    );
  });
});
