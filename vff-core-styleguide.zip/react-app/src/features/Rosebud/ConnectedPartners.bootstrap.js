import React from 'react';
import ReactDOM from 'react-dom';
import map from 'lodash/map';
import size from 'lodash/size';
import get from 'lodash/get';
import isEmpty from 'lodash/isEmpty';
import { Provider } from 'react-redux';
import store from '../../stores';
import ConnectedPartners from './ConnectedPartners';
import InformationAlert from '../../components/InformationAlert/InformationAlert';
import { COMPONENT_NAME } from '../../utils/common';

const ELEMENT_NAME = COMPONENT_NAME.connectedPartners;

export const getAirlineTransferData = (componentData) => {
  const partners = map(componentData.partners, (partner) => {
    const linkFormData = window.vffCoreWebsite[partner.accountLinkingFormKey];
    const transferFormData = window.vffCoreWebsite[partner.pointsTransferFormKey];

    return partner.isAirlineTransfer
      ? {
          ...partner,
          ...(!isEmpty(linkFormData) ? { accountLinkingFormData: linkFormData } : {}),
          ...(!isEmpty(transferFormData) ? { pointsTransferFormData: transferFormData } : {}),
        }
      : partner;
  });

  return { ...componentData, partners };
};

function renderComponent(elements) {
  map(elements, (element) => {
    const componentKey = element.getAttribute(ELEMENT_NAME);
    const props = window.vffCoreWebsite[componentKey];

    const componentData = getAirlineTransferData(props);

    if (props) {
      const component = (
        <Provider store={store}>
          <ConnectedPartners {...componentData} componentKey={componentKey} />
        </Provider>
      );

      ReactDOM.render(component, element);
    }
  });
}

function renderError(elements) {
  map(elements, (element) => {
    const component = (
      <Provider store={store}>
        <InformationAlert title="Something went wrong" content="" />
      </Provider>
    );

    ReactDOM.render(component, element);
  });
}

export default {
  elementName: ELEMENT_NAME,
  bootstrap: (id = null) => {
    const elements = document.querySelectorAll(`[${ELEMENT_NAME}${id ? `=${id}` : ''}]`);

    if (size(elements) > 0) {
      document.addEventListener('myProfile', (e) => {
        const { authenticated } = e.data;
        if (authenticated) {
          renderComponent(elements);
        } else {
          renderError(elements);
        }
      });

      if (get(window.vffCoreWebsite, 'websiteData.authoringMode')) {
        renderComponent(elements);
      }
    }
  },
};
