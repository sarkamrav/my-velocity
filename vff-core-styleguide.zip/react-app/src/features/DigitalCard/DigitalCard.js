import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { isIOS } from 'react-device-detect';

import Loading from '../../components/Loading/Loading';
import InformationAlert from '../../components/InformationAlert/InformationAlert';
import VffQrCode from '../../components/VffQrCode/VffQrCode';
import * as userData from '../../stores/utilities';
import A from '../../components/Button/A';

import styles from './DigitalCard.css';

const DigitalCard = ({ user, ctaContainer, digitalCardUrl }) => {
  const membershipId = userData.getLoyaltyMembershipID(user);
  const hasLoggedIn = userData.getHasLoggedIn(user);
  const memberDataLoadError = userData.getMemberDataLoadError(user);
  const downloadDigitalCardUrl = `${digitalCardUrl}${membershipId}`;

  return (
    <div className={styles.formContainer}>
      {!hasLoggedIn && memberDataLoadError && (
        <div>
          <InformationAlert
            title=""
            content="Sorry, we're having issues with our system."
            className={styles.errorContainer}
          />
        </div>
      )}

      {!hasLoggedIn && !memberDataLoadError && (
        <div className={styles.loadingContainer}>
          <Loading />
        </div>
      )}

      {hasLoggedIn && !isIOS && <VffQrCode url={downloadDigitalCardUrl} />}

      {hasLoggedIn && isIOS && (
        <A
          href={downloadDigitalCardUrl}
          title={ctaContainer.ctaTitle}
          buttonType={ctaContainer.ctaType}
          ctaImage={ctaContainer.ctaImage}
          target={ctaContainer.ctaOpenInNewTab ? '_blank' : '_self'}
          ctaAsLink={ctaContainer.ctaAsLink}
        >
          {ctaContainer.ctaLabel}
        </A>
      )}
    </div>
  );
};

DigitalCard.propTypes = {
  user: PropTypes.shape({}),
  ctaContainer: PropTypes.shape({
    ctaType: PropTypes.string,
    ctaLabel: PropTypes.string,
    ctaImage: PropTypes.string,
    ctaTitle: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaAsLink: PropTypes.bool,
  }),
  digitalCardUrl: PropTypes.string.isRequired,
};

DigitalCard.defaultProps = {
  user: null,
  ctaContainer: null,
};

export default connect((state) => ({
  user: state.user,
}))(DigitalCard);
