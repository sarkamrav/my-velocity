import React from 'react';
import { Provider } from 'react-redux';
import DigitalCard from './DigitalCard';
import { configureStore } from '../../stores';
import userData from '../Navigation/mocks/user.mock.json';
import digitalCardMock from './mocks/digitalCard.json';

export default {
  title: 'Digital Card',
};

export const DownloadDigitalCard = () => (
  <Provider
    store={configureStore({
      user: {
        memberDataLoaded: true,
        memberDataLoading: false,
        authenticated: true,
        ...userData.account,
      },
    })}
  >
    <DigitalCard {...digitalCardMock} />
  </Provider>
);
