import React, { useState, useEffect, useCallback, useRef } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import get from 'lodash/get';
import find from 'lodash/find';
import isEmpty from 'lodash/isEmpty';
import Loading from '../../components/Loading/Loading';
import { COMPONENT_NAME, getNavigationHeight, getParameterFromUrl, smoothScrollToElement } from '../../utils/common';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import api from '../../utils/api';
import RichTextContent from '../../components/RichTextContent/RichTextContent';
import Button from '../../components/Button/Button';
import A from '../../components/Button/A';
import syncText from '../../utils/syncText';
import Icon from '../../components/Icon/Icon';
import MessageTile, { messageTileTheme } from '../../components/MessageTile/MessageTile';
import styles from './Unsubscribe.css';

const unsubscribeClientChannel = {
  headers: {
    common: {
      'Client-Channel': 'EMAIL',
    },
  },
};

const Unsubscribe = ({
  iconUrl,
  title,
  description,
  ctaContainer,
  disclaimerText,
  secondaryDescription,
  secondaryCtaContainer,
  confirmation,
  errorMessages,
  unsubscribeCategories,
}) => {
  const submitErrorAlertId = useRef();
  const successInfoBoxId = useRef();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [consentFor, setConsentFor] = useState({});

  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [postError, setPostError] = useState('');

  const encryptId = getParameterFromUrl('encryptId');
  const unsubscribeApiUrl = `/loyalty/v2/members/consent/${encryptId}`;

  const getConsent = useCallback(async () => {
    try {
      setLoading(true);
      const apiResp = await api.vffV2NoKeycloak.get(unsubscribeApiUrl, unsubscribeClientChannel);
      setConsentFor(find(unsubscribeCategories, (list) => list.value === apiResp.data.data.consentFor).title);
      setLoading(false);
    } catch (err) {
      setError(get(errorMessages, 'defaultErrorMessage'));
      setLoading(false);
    }
  }, [errorMessages, unsubscribeApiUrl, unsubscribeCategories]);

  useEffect(() => {
    getConsent();
  }, [getConsent]);

  const onUnsubscribed = async (e) => {
    e.preventDefault();
    try {
      setSubmitting(true);
      setSubmitted(false);
      setPostError('');
      await api.vffV2NoKeycloak.delete(unsubscribeApiUrl, unsubscribeClientChannel);
      setSubmitting(false);
      setSubmitted(true);
    } catch (err) {
      setSubmitting(false);
      setPostError(get(errorMessages, 'defaultErrorMessage'));
    }
  };

  useEffect(() => {
    if (submitted) {
      smoothScrollToElement(successInfoBoxId.current, getNavigationHeight());
    }
  }, [submitted]);

  useEffect(() => {
    if (postError) {
      smoothScrollToElement(submitErrorAlertId.current, getNavigationHeight());
    }
  }, [postError]);

  const isContentReady = !loading && !error;

  return (
    <ErrorBoundary section={COMPONENT_NAME.unsubscribe}>
      {loading && (
        <div className={styles.loadingContainer}>
          <Loading />
        </div>
      )}

      {!loading && error && (
        <div className={styles.errorContainer}>
          <MessageTile theme={messageTileTheme.error} description={error.description} />
        </div>
      )}

      {isContentReady && (
        <div className={styles.container}>
          {submitted && (
            <div className={cx(styles.innerContainer, styles.successCont)} ref={successInfoBoxId}>
              {isEmpty(get(confirmation, 'iconUrl')) ? (
                <Icon name="VaTickCircleClosed" className={styles.tickIcon} />
              ) : (
                <div className={styles.icon}>
                  <img src={get(confirmation, 'iconUrl')} alt="" />
                </div>
              )}

              <div className={styles.title}>{get(confirmation, 'title')}</div>

              <RichTextContent
                className={styles.description}
                content={syncText(get(confirmation, 'description') || '', {
                  unsubscribeCategory: consentFor,
                })}
              />

              <RichTextContent
                className={cx(styles.marginBottomForty, styles.separator, styles.disclaimerTxt)}
                content={get(confirmation, 'secondaryDescription')}
              />
              <A
                className={styles.cta}
                href={get(confirmation, 'ctaContainer.ctaUrl')}
                title={get(confirmation, 'ctaContainer.ctaTitle')}
                target={get(confirmation, 'ctaContainer.ctaOpenInNewTab') ? '_blank' : '_self'}
                buttonType={get(confirmation, 'ctaContainer.ctaStyle')}
                type="submit"
              >
                {get(confirmation, 'ctaContainer.ctaLabel')}
              </A>
            </div>
          )}

          {!submitted && (
            <>
              {postError && (
                <div className={styles.apiErrorCont}>
                  <MessageTile
                    ref={submitErrorAlertId}
                    theme={messageTileTheme.error}
                    description={postError.description}
                  />
                </div>
              )}
              <div className={cx(styles.innerContainer, styles.gradient)}>
                <div className={styles.unsubscribeCont}>
                  <div className={styles.icon}>
                    <img src={iconUrl} alt="" />
                  </div>

                  <div className={styles.title}>{title}</div>

                  <RichTextContent className={styles.description} content={description} />

                  <p className={styles.consentFor}>{consentFor}</p>

                  <Button
                    className={cx(styles.cta, styles.marginTopForty, styles.marginBottomForty)}
                    title={get(ctaContainer, 'ctaTitle')}
                    target={get(ctaContainer, 'ctaOpenInNewTab') ? '_blank' : '_self'}
                    buttonType={get(ctaContainer, 'ctaStyle')}
                    type="submit"
                    onClick={onUnsubscribed}
                    disabled={submitting}
                    loading={submitting}
                  >
                    {get(ctaContainer, 'ctaLabel')}
                  </Button>

                  <RichTextContent className={styles.disclaimerTxt} content={disclaimerText} />

                  <RichTextContent
                    className={cx(styles.marginBottomForty, styles.separator)}
                    content={secondaryDescription}
                  />

                  <A
                    className={styles.cta}
                    href={get(secondaryCtaContainer, 'ctaUrl')}
                    title={get(secondaryCtaContainer, 'ctaTitle')}
                    target={get(secondaryCtaContainer, 'ctaOpenInNewTab') ? '_blank' : '_self'}
                    buttonType={get(secondaryCtaContainer, 'ctaStyle')}
                    type="submit"
                  >
                    {get(secondaryCtaContainer, 'ctaLabel')}
                  </A>
                </div>
              </div>
            </>
          )}
        </div>
      )}
    </ErrorBoundary>
  );
};

Unsubscribe.propTypes = {
  iconUrl: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
  ctaContainer: PropTypes.shape({}).isRequired,
  disclaimerText: PropTypes.string.isRequired,
  secondaryDescription: PropTypes.string.isRequired,
  secondaryCtaContainer: PropTypes.shape({}).isRequired,
  confirmation: PropTypes.shape({}).isRequired,
  errorMessages: PropTypes.shape({}).isRequired,
  unsubscribeCategories: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
};

export default Unsubscribe;
