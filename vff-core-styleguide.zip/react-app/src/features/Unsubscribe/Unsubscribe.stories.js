import React from 'react';
import { Provider } from 'react-redux';
import MockAdapter from 'axios-mock-adapter';
import { configureStore } from '../../stores';
import api from '../../utils/api';

import unsubscribeMock from './mocks/Unsubscribe.mock.json';
import Unsubscribe from './Unsubscribe';
import userData from '../Navigation/mocks/user.mock.json';

export default {
  title: 'Unsubscribe',
};

export const UnsubscribeSubmissionSuccess = () => {
  const mockVff = new MockAdapter(api.vffV2NoKeycloak, { delayResponse: 800 });

  mockVff.onGet('/loyalty/v2/members/consent/f5dbe49b106bafc1a7674754afc43ab4').reply(200, {
    data: {
      consentFor: 'MEMBER UPDATES',
    },
  });

  mockVff.onDelete('/loyalty/v2/members/consent/f5dbe49b106bafc1a7674754afc43ab4').reply(200, {});

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <Unsubscribe {...unsubscribeMock} />
      </Provider>
    </div>
  );
};

UnsubscribeSubmissionSuccess.parameters = {
  query: { encryptId: 'f5dbe49b106bafc1a7674754afc43ab4' },
};

UnsubscribeSubmissionSuccess.storyName = 'Unsubscribe - Submission Success';

export const UnsubscribeFormSubmissionFailed = () => {
  const mockVff = new MockAdapter(api.vffV2NoKeycloak, { delayResponse: 800 });

  mockVff.onGet('/loyalty/v2/members/consent/f5dbe49b106bafc1a7674754afc43ab4').reply(200, {
    data: {
      consentFor: 'STATEMENT',
    },
  });

  mockVff.onDelete('/loyalty/v2/members/consent/f5dbe49b106bafc1a7674754afc43ab4').reply(400, {
    code: 4001,
    title: 'Validation Error',
    detail: 'Validation failed for below fields',
    status: 400,
  });

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <Unsubscribe {...unsubscribeMock} />
      </Provider>
    </div>
  );
};

UnsubscribeFormSubmissionFailed.parameters = {
  query: { encryptId: 'f5dbe49b106bafc1a7674754afc43ab4' },
};

UnsubscribeFormSubmissionFailed.storyName = 'Unsubscribe - Submission Failed';

export const UnsubscribeApiError = () => {
  const mockVff = new MockAdapter(api.vffV2NoKeycloak, { delayResponse: 800 });

  mockVff.onGet('/loyalty/v2/members/consent/f5dbe49b106bafc1a7674754afc43ab4').reply(400, {
    code: 4001,
    title: 'Validation Error',
    detail: 'Validation failed for below fields',
    status: 400,
  });

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <Unsubscribe {...unsubscribeMock} />
      </Provider>
    </div>
  );
};

UnsubscribeApiError.storyName = 'Unsubscribe - API Failed';

export const UnsubscribeApiLoading = () => {
  const mockVff = new MockAdapter(api.vffV2NoKeycloak, { delayResponse: 800000 });

  mockVff.onGet('/loyalty/v2/members/consent/f5dbe49b106bafc1a7674754afc43ab4').reply(400, {});

  return (
    <div style={{ backgroundColor: '#f9f9f9' }}>
      <Provider
        store={configureStore({
          user: {
            memberDataLoaded: true,
            memberDataLoading: false,
            authenticated: true,
            ...userData,
          },
        })}
      >
        <Unsubscribe {...unsubscribeMock} />
      </Provider>
    </div>
  );
};
UnsubscribeApiLoading.storyName = 'Unsubscribe - API Loading';
