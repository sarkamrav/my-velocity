import _ from 'lodash';
import { DateTime } from 'luxon';

export const monthNames = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

export const monthOptions = monthNames.map((monthName, index) => ({
  label: monthName,
  value: `${index}`,
}));

export const yearOptions = _.range(DateTime.now().year, DateTime.now().minus({ years: 4 }).year, -1).map((year) => ({
  label: `${year}`,
  value: `${year}`,
}));

export const activityTypeOptions = [
  { label: 'Points earned', value: 'AP_EARNED' },
  { label: 'Points redeemed', value: 'AP_REDEEMED' },
  { label: 'Status credits earned', value: 'SC_EARNED' },
];

export const filterFieldNames = {
  month: 'statementPeriodMonth',
  year: 'statementPeriodYear',
  type: 'activityType',
};

export const dateFormat = 'yyyy-MM-dd';
export const dateFormatForDisplay = 'd-MMM-yyyy';
