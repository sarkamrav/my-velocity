import React from 'react';
import MockAdapter from 'axios-mock-adapter';
import { Provider } from 'react-redux';
import { DateTime } from 'luxon';

import MyActivityStatement from './MyActivityStatement';
import { dateFormat } from './constants';
import api from '../../utils/api';
import myActivityStatementMock from './mocks/my-activity-statement.mock.json';
import activitiesData from './mocks/get-activities-on-page-load.mock.json';
import typeFilteredData from './mocks/get-activities-from-type.mock.json';
import loadMoreActivitiesData from './mocks/get-activities-on-load-more.mock.json';
import categoriesFilteredData from './mocks/get-activities-from-catergories.mock.json';

import { configureStore } from '../../stores';
import userData from '../Navigation/mocks/user.mock.json';

export default {
  title: 'My Activity Statement',
};

export const Activities = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });
  const defaultEndDate = DateTime.now().toFormat(dateFormat);
  const defaultStartDate = DateTime.now().minus({ years: 3 }).toFormat(dateFormat);
  mockVff
    .onGet(
      `/loyalty/v2/experience/activities/me?startDate=${defaultStartDate}&endDate=${defaultEndDate}&pageOffset=0&pageLimit=30&include=categories`,
    )
    .reply(200, activitiesData);
  mockVff
    .onGet(
      `/loyalty/v2/experience/activities/me?startDate=${defaultStartDate}&endDate=${defaultEndDate}&pageOffset=0&pageLimit=30`,
    )
    .reply(200, activitiesData);
  mockVff
    .onGet(
      `/loyalty/v2/experience/activities/me?startDate=${defaultStartDate}&endDate=${defaultEndDate}&pageOffset=30&pageLimit=30`,
    )
    .reply(200, loadMoreActivitiesData);
  mockVff
    .onGet(
      `/loyalty/v2/experience/activities/me?startDate=${defaultStartDate}&endDate=${defaultEndDate}&partnerCode=VA&partnerCode=EK&pageOffset=0&pageLimit=30`,
    )
    .reply(200, categoriesFilteredData);
  mockVff
    .onGet(
      `/loyalty/v2/experience/activities/me?startDate=${defaultStartDate}&endDate=${defaultEndDate}&partnerCode=VA&pageOffset=0&pageLimit=30`,
    )
    .reply(200, categoriesFilteredData);
  mockVff
    .onGet(
      `/loyalty/v2/experience/activities/me?startDate=${defaultStartDate}&endDate=${defaultEndDate}&partnerCode=VA&partnerCode=EK&partnerCode=CBA&pageOffset=0&pageLimit=30`,
    )
    .reply(200, categoriesFilteredData);
  mockVff
    .onGet(
      `/loyalty/v2/experience/activities/me?startDate=${defaultStartDate}&endDate=${defaultEndDate}&activityOperation=AP_EARNED&pageOffset=0&pageLimit=30`,
    )
    .reply(200, typeFilteredData);
  mockVff
    .onGet(
      `/loyalty/v2/experience/activities/me?startDate=${defaultStartDate}&endDate=${defaultEndDate}&activityOperation=AP_EARNED&partnerCode=VA&partnerCode=EK&pageOffset=0&pageLimit=30`,
    )
    .reply(200, categoriesFilteredData);
  mockVff
    .onGet(
      '/loyalty/v2/experience/activities/me?startDate=2021-05-01&endDate=2021-05-31&activityOperation=AP_EARNED&pageOffset=0&pageLimit=30',
    )
    .reply(200, categoriesFilteredData);
  mockVff
    .onGet('/loyalty/v2/experience/activities/me?startDate=2021-05-01&endDate=2021-05-31&pageOffset=0&pageLimit=30')
    .reply(200, typeFilteredData);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <MyActivityStatement {...myActivityStatementMock} />
    </Provider>
  );
};

Activities.storyName = 'Activities';

export const NoActivities = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });

  mockVff.onGet(/\/v2\/experience\/activities\/me/).reply(200, []);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <MyActivityStatement {...myActivityStatementMock} />
    </Provider>
  );
};

NoActivities.storyName = 'No activities';

export const GetActivitiesError = () => {
  const mockVff = new MockAdapter(api.vffV2Api, { delayResponse: 800 });
  mockVff.onGet(/\/v2\/experience\/activities\/me/).reply(400);

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading: false,
          authenticated: true,
          ...userData,
        },
      })}
    >
      <MyActivityStatement {...myActivityStatementMock} />
    </Provider>
  );
};

GetActivitiesError.storyName = 'Get activities error';
