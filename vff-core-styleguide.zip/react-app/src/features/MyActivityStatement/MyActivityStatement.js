/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import reduce from 'lodash/reduce';
import camelCase from 'lodash/camelCase';
import get from 'lodash/get';
import map from 'lodash/map';
import size from 'lodash/size';
import uniq from 'lodash/uniq';
import cx from 'classnames';
import { connect } from 'react-redux';
import uniqBy from 'lodash/uniqBy';
import findIndex from 'lodash/findIndex';
import { filter } from 'lodash';

import { DateTime } from 'luxon';
import api from '../../utils/api';
import Loading from '../../components/Loading/Loading';
import InformationAlert from '../../components/InformationAlert/InformationAlert';
import CallOut from '../CallOut/CallOut';
import HorizontalScroll from '../../components/HorizontalScroll/HorizontalScroll';
import SingleHeaderTable from '../../components/SingleHeaderTable/SingleHeaderTable';

import { dateFormat, dateFormatForDisplay, filterFieldNames } from './constants';
import Button from '../../components/Button/Button';
import { COMPONENT_NAME, formatNumber } from '../../utils/common';
import * as userData from '../../stores/utilities';
import ActivityFilter from './ActivityFilter/ActivityFilter';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import { getApiActionName, getApiError, sendToNewRelic } from '../../utils/newRelic';

import styles from './MyActivityStatement.css';

const initialFilterValues = {
  [filterFieldNames.month]: null,
  [filterFieldNames.year]: null,
  [filterFieldNames.type]: '',
};

const getAvailablePartners = (categories) =>
  reduce(categories, (result, category) => [...result, ...category.partners], []);

const getPartners = (categories) => {
  const availablePartners = getAvailablePartners(categories);
  return uniqBy(availablePartners, (item) => item.name);
};
const prepareCheckboxFormFields = (items, fieldKey) =>
  reduce(
    items,
    (result, item) => ({
      ...result,
      [camelCase(item[fieldKey])]: false,
    }),
    {},
  );

const defaultEndDate = DateTime.now().toFormat(dateFormat);
const defaultStartDate = DateTime.now().minus({ years: 3 }).toFormat(dateFormat);
const recordPerPage = 30;
const MyActivityStatement = ({ user, callOut, defaultErrorMessage }) => {
  const hasLoggedIn = userData.getHasLoggedIn(user);
  const memberDataLoadError = userData.getMemberDataLoadError(user);
  const [activities, setActivities] = useState([]);
  const [activitiesLoading, setActivitiesLoading] = useState(true);
  const [activitiesLoadError, setActivitiesLoadError] = useState(false);
  const [categories, setCategories] = useState([]);
  const [moreActivitiesLoading, setMoreActivitiesLoading] = useState(false);

  const [filterValues, setFilterValues] = useState(initialFilterValues);
  const [activitiesTotalCount, setActivitiesTotalCount] = useState(0);
  const [pageCount, setPageCount] = useState(0);
  const [pageOffset, setPageOffset] = useState(0);

  function getDisplayPoints(points) {
    if (points) {
      return points > 0 ? `+${formatNumber(points)}` : formatNumber(points);
    }

    return '–';
  }

  function getCellElement(content, additionalCssClasses = '') {
    return <span className={cx(styles.centerCell, additionalCssClasses)}>{content}</span>;
  }

  const getBonusPointsCellElement = useCallback(
    (awardPoints) => getCellElement(getDisplayPoints(awardPoints), 'color color--purple font-weight font-weight--bold'),
    [],
  );

  function getDescription(description) {
    return <p className={styles.description}>{description}</p>;
  }

  const processActivitiesForTable = useCallback(
    (records) =>
      map(records || [], ({ id, activityDate, points, description }) => ({
        uniqueId: id,
        activityDate: DateTime.fromISO(activityDate).toFormat(dateFormatForDisplay),
        pointsPostedDate: DateTime.fromISO(points.postedDate).toFormat(dateFormatForDisplay),
        description: getDescription(description),
        bonusPoints: getBonusPointsCellElement(points.awardPoints),
        statusCredits: getCellElement(getDisplayPoints(points.statusCredits)),
      })),
    [getBonusPointsCellElement],
  );

  const getActivitiesParameterString = useCallback(
    (filterFormValueObject = null, areCategoriesRequired = false, offset = 0) => {
      const selectedPartnersByCategories = reduce(
        categories,
        (partners, category, index) =>
          filterFormValueObject[camelCase(category.name)]
            ? [...partners, ...get(categories[index], 'partners', [])]
            : partners,
        [],
      );

      const selectedPartnersByPartnerCheckbox = reduce(
        getPartners(categories),
        (partners, partner) => (filterFormValueObject[camelCase(partner.code)] ? [...partners, partner] : partners),
        [],
      );

      // find all partners by name to cater for partner with same name but different code
      const allAvailablePartners = getAvailablePartners(categories);
      const selectedPartnersByPartnerName = filter(
        allAvailablePartners,
        (partner) => findIndex(selectedPartnersByPartnerCheckbox, { name: partner?.name }) > -1,
      );

      const allSelectedPartners = uniq([...selectedPartnersByCategories, ...selectedPartnersByPartnerName]);

      let startDate = defaultStartDate;
      let endDate = defaultEndDate;
      let parameterString;

      const selectedMonthOption = filterFormValueObject[filterFieldNames.month];
      const selectedYearOption = filterFormValueObject[filterFieldNames.year];

      if (selectedMonthOption && selectedYearOption) {
        const selectedPeriod = DateTime.fromObject({
          year: parseInt(selectedYearOption.value, 10),
          month: parseInt(selectedMonthOption.value, 10) + 1,
        });

        startDate = selectedPeriod.startOf('month').toFormat(dateFormat);
        endDate = selectedPeriod.endOf('month').toFormat(dateFormat);
      }

      parameterString = `?startDate=${startDate}&endDate=${endDate}`;

      // Returns the activityOperation to the query params with respect to the type selected
      if (filterFormValueObject[filterFieldNames.type]) {
        parameterString = `${parameterString}&activityOperation=${encodeURIComponent(filterFormValueObject[filterFieldNames.type])}`;
      }
      // Returns the partnerCode to the query params with respect to the categories selected
      if (size(allSelectedPartners) > 0) {
        parameterString = `${parameterString}${allSelectedPartners.map((partners) => `&partnerCode=${partners.code}`).join('')}`;
      }

      parameterString = `${parameterString}&pageOffset=${offset}&pageLimit=${recordPerPage}`;

      // Returns the categories array to be displayed on the category dropdown on the page load only
      if (areCategoriesRequired) {
        parameterString = `${parameterString}&include=categories`;
      }

      return parameterString;
    },
    [categories],
  );

  const getPageCount = (response) => get(response, 'data.metaData.page.count', 0);
  const getPageOffset = (response) => get(response, 'data.metaData.page.offset', 0);
  const getActivitiesData = (response) => get(response, 'data.data.history', []);

  // `fetchMoreTransactions` To fetch the next set of the transactions at onClick of load more
  const fetchMoreActivities = useCallback(async () => {
    setMoreActivitiesLoading(true);
    const parameterString = getActivitiesParameterString(filterValues, false, pageOffset + pageCount);
    const moreTransactionsApiUri = `/loyalty/v2/experience/activities/me${parameterString}`;
    try {
      const response = await api.vffV2Api.get(moreTransactionsApiUri);
      setActivities((previousRecords) => [
        ...previousRecords,
        ...processActivitiesForTable(getActivitiesData(response)),
      ]);
      setPageCount(getPageCount(response));
      setPageOffset(getPageOffset(response));
      setMoreActivitiesLoading(false);
    } catch (error) {
      setActivitiesLoadError(true);
      setMoreActivitiesLoading(false);
      sendToNewRelic(
        getApiActionName(api.vffV2Api.defaults.baseURL, moreTransactionsApiUri),
        getApiError(COMPONENT_NAME.activityStatement, error),
      );
    }
  }, [filterValues, getActivitiesParameterString, pageCount, pageOffset, processActivitiesForTable]);

  // `fetchActivities` To fetch the experience activities response at page load and filter change handle
  const fetchActivities = useCallback(
    async (parameterString) => {
      setActivitiesLoading(true);
      const activitiesApiUri = `/loyalty/v2/experience/activities/me${parameterString}`;
      try {
        const response = await api.vffV2Api.get(activitiesApiUri);
        const categoriesData = get(response, 'data.included.categories', []);

        // In order to set the Categories values only at the initial page load
        if (size(categoriesData) > 0) {
          setCategories(categoriesData);
          setFilterValues((prevState) => ({
            ...prevState,
            ...prepareCheckboxFormFields(categoriesData, 'name'),
            ...prepareCheckboxFormFields(getPartners(categoriesData), 'code'),
          }));
        }
        setActivities(processActivitiesForTable(getActivitiesData(response)));
        setActivitiesTotalCount(get(response, 'data.metaData.count', 0));
        setPageCount(getPageCount(response));
        setPageOffset(getPageOffset(response));
        setActivitiesLoading(false);
      } catch (error) {
        setActivitiesLoadError(true);
        setActivitiesLoading(false);
        sendToNewRelic(
          getApiActionName(api.vffV2Api.defaults.baseURL, activitiesApiUri),
          getApiError(COMPONENT_NAME.activityStatement, error),
        );
      }
    },
    [processActivitiesForTable],
  );

  const handleFieldChange = useCallback(
    (fieldName) => (newValue) => {
      setFilterValues((previousValues) => ({
        ...previousValues,
        [fieldName]: newValue,
      }));

      switch (fieldName) {
        case filterFieldNames.month: {
          const yearOption = filterValues[filterFieldNames.year];

          if (yearOption) {
            const parameterString = getActivitiesParameterString({
              ...filterValues,
              [filterFieldNames.month]: newValue,
            });
            fetchActivities(parameterString);
          }
          break;
        }

        case filterFieldNames.year: {
          const monthOption = filterValues[filterFieldNames.month];

          if (monthOption) {
            const parameterString = getActivitiesParameterString({
              ...filterValues,
              [filterFieldNames.year]: newValue,
            });
            fetchActivities(parameterString);
          }
          break;
        }
        // Type radio button dropdown
        case filterFieldNames.type: {
          const parameterString = getActivitiesParameterString({
            ...filterValues,
            [filterFieldNames.type]: newValue,
          });
          fetchActivities(parameterString);
          break;
        }

        // Categories checkbox dropdown
        default: {
          const parameterString = getActivitiesParameterString({
            ...filterValues,
            [fieldName]: newValue,
          });
          fetchActivities(parameterString);
          break;
        }
      }
    },
    [fetchActivities, filterValues, getActivitiesParameterString],
  );

  const handleFieldChangeEvent = useCallback(
    (event) => {
      handleFieldChange(event.target.name)(event.target.value);
    },
    [handleFieldChange],
  );

  const handleClearFilter = useCallback(() => {
    const resetData = {
      ...initialFilterValues,
      ...prepareCheckboxFormFields(categories, 'name'),
      ...prepareCheckboxFormFields(getPartners(categories), 'code'),
    };

    setFilterValues(resetData);
    fetchActivities(getActivitiesParameterString(resetData));
  }, [categories, fetchActivities, getActivitiesParameterString]);

  useEffect(() => {
    if (hasLoggedIn) {
      // To fetch the activities and the categories data
      fetchActivities(getActivitiesParameterString(filterValues, true));
    }
  }, [hasLoggedIn]);

  const total = activitiesTotalCount || 0;
  const hasActivities = size(activities) > 0;
  const headers = [
    'Activity date',
    'Process date',
    'Description',
    <span className={cx(styles.centerCell, styles.velocityPointsHeader)}>Velocity Points</span>,
    getCellElement('Status Credits'),
  ];

  const categoriesOptions = map(categories, (category) => ({
    fieldName: camelCase(category.name),
    label: category.name,
  }));

  const partnersOptions = map(getPartners(categories), (partner) => ({
    fieldName: camelCase(partner.code),
    label: partner.name,
  }));

  return (
    <ErrorBoundary section={COMPONENT_NAME.activityStatement}>
      <section className={styles.container}>
        {!hasLoggedIn && memberDataLoadError && (
          <InformationAlert
            title=""
            content="Sorry, we're having issues with our system."
            className={styles.errorContainer}
          />
        )}

        {!hasLoggedIn && !memberDataLoadError && (
          <div className={styles.loadingContainer}>
            <Loading />
          </div>
        )}

        {hasLoggedIn && (
          <>
            {activitiesLoadError && (
              <InformationAlert title="" className={styles.errorContainer} content={defaultErrorMessage} />
            )}

            {!activitiesLoadError && (
              <>
                <ActivityFilter
                  categories={categoriesOptions}
                  partners={partnersOptions}
                  handleFieldChange={handleFieldChange}
                  handleFieldChangeEvent={handleFieldChangeEvent}
                  handleClearFilter={handleClearFilter}
                  values={filterValues}
                  monthFieldName={filterFieldNames.month}
                  yearFieldName={filterFieldNames.year}
                  typeFieldName={filterFieldNames.type}
                />

                {activitiesLoading && <Loading containerClassName={styles.loadingContainer} />}

                {!activitiesLoading && !hasActivities && <CallOut {...callOut} />}

                {!activitiesLoading && hasActivities && (
                  <>
                    {total > 0 && (
                      <span className={cx('font-size font-weight font-weight--bold', styles.total)}>
                        {total} result{total > 1 ? 's' : ''}
                      </span>
                    )}

                    <HorizontalScroll className={styles.activityScrollContainer}>
                      <SingleHeaderTable headers={headers} rows={activities} />
                    </HorizontalScroll>

                    <div className={cx('font-size font-weight', styles.summary)}>
                      <span className={styles.summaryText}>
                        Showing {activities.length} of {total} transaction{total > 1 ? 's' : ''}
                      </span>

                      {pageCount + pageOffset < total && (
                        <Button
                          buttonType="primary-transparent"
                          onClick={fetchMoreActivities}
                          disabled={moreActivitiesLoading}
                          loading={moreActivitiesLoading}
                        >
                          Load more
                        </Button>
                      )}
                    </div>
                  </>
                )}
              </>
            )}
          </>
        )}
      </section>
    </ErrorBoundary>
  );
};

MyActivityStatement.propTypes = {
  user: PropTypes.shape({}),
  defaultErrorMessage: PropTypes.string,
  callOut: PropTypes.shape({
    iconUrl: PropTypes.string,
    title: PropTypes.string,
    description: PropTypes.string,
    ctaContainer: PropTypes.shape({
      ctaLabel: PropTypes.string,
      ctaTitle: PropTypes.string,
      ctaUrl: PropTypes.string,
      ctaOpenInNewTab: PropTypes.bool,
      ctaStyle: PropTypes.string,
    }),
    renderMode: PropTypes.string,
    analyticsMetadata: PropTypes.shape({
      'analytics-metadata': PropTypes.string,
    }),
  }),
};

MyActivityStatement.defaultProps = {
  user: null,
  defaultErrorMessage: '',
  callOut: {},
};

export default connect((state) => ({
  user: state.user,
}))(MyActivityStatement);
