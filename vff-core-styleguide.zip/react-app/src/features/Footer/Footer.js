import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import map from 'lodash/map';
import cx from 'classnames';
import Icon from '../../components/Icon/Icon';
import Button from '../../components/Button/Button';
import ErrorBoundary from '../../components/ErrorBoundary/ErrorBoundary';
import RichTextContent from '../../components/RichTextContent/RichTextContent';

import { COMPONENT_NAME } from '../../utils/common';
import VisuallyHidden from '../../components/VisuallyHidden/VisuallyHidden';

import styles from './Footer.css';

const Footer = ({
  linkGroups,
  subFooterLinks,
  socialLinks,
  downloadApp,
  disclaimerText,
  analyticsMetadata,
  velocityLogo,
  virginLogo,
}) => {
  const analyticsMetadataKey = analyticsMetadata['analytics-metadata'];
  const [analyticsData, setAnalyticsData] = useState(analyticsMetadataKey);

  useEffect(() => {
    const commonAnalyticsData = window.vffCoreWebsite[analyticsMetadataKey] || {};

    setAnalyticsData({
      ...commonAnalyticsData,
      eventLocation: 'footer',
    });
  }, [analyticsMetadataKey]);

  const renderLogo = () => {
    const { logoPath: vaLogoPath, altText: vaAltText, url: vaUrl } = virginLogo;

    const { logoPath: vffLogoPath, altText: vffAltText, url: vffUrl } = velocityLogo;

    const velocityLogoElement = <img className={styles.rebrandLogo} src={vffLogoPath} alt={vffAltText} />;
    const virginLogoElement = <img className={styles.rebrandLogo} src={vaLogoPath} alt={vaAltText} />;

    return (
      <div className={styles.rebrandLogoContainer}>
        {vffUrl && vffLogoPath && (
          <a className={styles.logoWrapper} href={vffUrl}>
            {velocityLogoElement}
            <VisuallyHidden>Navigate to home page</VisuallyHidden>
          </a>
        )}

        {!vffUrl && vffLogoPath && <div className={styles.logoWrapper}>{velocityLogoElement}</div>}

        {vaUrl && vaLogoPath && (
          <a className={styles.logoWrapper} rel="noopener noreferrer" target="_blank" href={vaUrl}>
            {virginLogoElement}
            <VisuallyHidden>Navigate to Virgin Australia website</VisuallyHidden>
          </a>
        )}

        {!vaUrl && vaLogoPath && <div className={styles.logoWrapper}>{virginLogoElement}</div>}
      </div>
    );
  };

  return (
    <ErrorBoundary section={COMPONENT_NAME.footer}>
      <footer className={styles.footer} analytics-metadata={JSON.stringify(analyticsData)}>
        <div className={styles.contentContainer}>
          <Button
            buttonType="tertiary"
            className={styles.backToTopButton}
            onClick={() => window.scroll({ top: 0, behavior: 'smooth' })}
          >
            <Icon name="Chevron" className={styles.up} size="extra-small" />
            <VisuallyHidden>Jumb to top of the page</VisuallyHidden>
          </Button>
          <div className={styles.linkGroups}>
            {linkGroups.map((linkGroup) => (
              <div key={linkGroup.title} className={styles.linkGroup}>
                <div className={styles.linkTitle}>{linkGroup.title}</div>
                <div className={styles.links}>
                  {linkGroup.links.map((link) => (
                    <div key={link.label}>
                      <a
                        href={link.href}
                        title={link.title || link.label}
                        target={link.openInNewTab ? '_blank' : '_self'}
                        rel={link.openInNewTab ? 'noopener noreferrer' : ''}
                        className={styles.link}
                      >
                        {link?.backgroundImage ? (
                          <img className={styles.linkImage} src={link.backgroundImage} alt={link.label} />
                        ) : (
                          <>{link.label}</>
                        )}
                      </a>
                    </div>
                  ))}
                </div>
              </div>
            ))}

            <div className={cx(styles.linkGroup, styles.downloadGroup)}>
              <div className={styles.linkTitle}>{downloadApp.title}</div>
              <div className={styles.downloadLinks}>
                {downloadApp.links.map((link) => (
                  <div key={link.label}>
                    <a
                      href={link.href}
                      title={link.title || link.label}
                      target={link.openInNewTab ? '_blank' : '_self'}
                      rel={link.openInNewTab ? 'noopener noreferrer' : ''}
                      className={styles.link}
                    >
                      {link?.backgroundImage ? (
                        <img className={styles.linkImage} src={link.backgroundImage} alt={link.label} />
                      ) : (
                        <>{link.label}</>
                      )}
                    </a>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className={styles.subFooter}>
            <div className={styles.subFooterContent}>
              <div className={styles.socialLinks}>
                {socialLinks.map((socialLink) => (
                  <a
                    href={socialLink.href}
                    title={socialLink.title || socialLink.label}
                    target={socialLink.openInNewTab ? '_blank' : '_self'}
                    rel={socialLink.openInNewTab ? 'noopener noreferrer' : ''}
                    className={styles.socialLink}
                  >
                    {socialLink.iconUrl && (
                      <img src={socialLink.iconUrl} alt={socialLink.label} className={styles.socialIcon} />
                    )}
                    {socialLink.label}
                    <Icon className={styles.openIcon} name="Open" size="smallest" />
                  </a>
                ))}
              </div>
              <RichTextContent content={disclaimerText} className={styles.disclaimerText} />
              <ul className={styles.subFooterList}>
                <div className={styles.acn}>
                  <span>&copy; Velocity Frequent Flyer Pty Limited</span>
                  <span className={styles.noWrap}>ACN 601 408 824</span>
                </div>
                {map(subFooterLinks, (link) => (
                  <li key={link.label} className={styles.listItem}>
                    <a
                      href={link.href}
                      title={link.title || link.label}
                      target={link.openInNewTab ? '_blank' : '_self'}
                      rel={link.openInNewTab ? 'noopener noreferrer' : ''}
                      className={styles.link}
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
            <div className={styles.logoContainer}>{renderLogo()}</div>
          </div>
        </div>
      </footer>
    </ErrorBoundary>
  );
};

Footer.propTypes = {
  linkGroups: PropTypes.arrayOf(PropTypes.shape({})),
  subFooterLinks: PropTypes.arrayOf(PropTypes.shape({})),
  socialLinks: PropTypes.arrayOf(PropTypes.shape({})),
  downloadApp: PropTypes.shape({
    title: PropTypes.string,
    links: PropTypes.arrayOf(PropTypes.shape({})),
  }),
  disclaimerText: PropTypes.string,
  analyticsMetadata: PropTypes.shape({
    'analytics-metadata': PropTypes.string,
  }).isRequired,
  velocityLogo: PropTypes.shape({
    logoPath: PropTypes.string,
    altText: PropTypes.string,
    url: PropTypes.string,
  }),
  virginLogo: PropTypes.shape({
    logoPath: PropTypes.string,
    altText: PropTypes.string,
    url: PropTypes.string,
  }),
};

Footer.defaultProps = {
  linkGroups: [],
  subFooterLinks: [],
  socialLinks: [],
  downloadApp: {},
  disclaimerText: '',
  velocityLogo: {
    logoPath: '',
    altText: 'Velocity logo',
    url: '',
  },
  virginLogo: {
    logoPath: '',
    altText: 'Virgin australia logo',
    url: '',
  },
};

export default Footer;
