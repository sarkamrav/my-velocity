import React from 'react';
import Footer from './Footer';
import footerMock from './mocks/footer.mock.json';

export default {
  title: 'Footer',
};

export const Default = () => <Footer {...footerMock} />;
