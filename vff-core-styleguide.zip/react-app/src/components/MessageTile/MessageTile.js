import React, { forwardRef } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';

import RichTextContent from '../RichTextContent/RichTextContent';
import Icon from '../Icon/Icon';

import styles from './MessageTile.css';

export const messageTileTheme = {
  error: 'error',
  success: 'success',
  info: 'info',
};

const MessageTile = ({ theme, description, className, containerRef }) => (
  <div role="alert" ref={containerRef} className={cx(styles.container, styles[theme], className)}>
    {messageTileTheme.error === theme && (
      <Icon className={cx(styles.icon, styles.errorIcon)} name="VaWarningCircleClosed" size="extra-small" />
    )}

    {messageTileTheme.success === theme && (
      <Icon className={cx(styles.icon, styles.successIcon)} name="VaTickCircleClosed" size="extra-small" />
    )}

    {messageTileTheme.info === theme && (
      <Icon className={cx(styles.icon, styles.infoIcon)} name="Info" size="extra-small" />
    )}

    <RichTextContent className={cx(styles.description, styles[theme])} content={description} />
  </div>
);

MessageTile.propTypes = {
  theme: PropTypes.oneOf([messageTileTheme.error, messageTileTheme.success, messageTileTheme.info]),
  description: PropTypes.string,
  className: PropTypes.string,
  containerRef: PropTypes.shape({}),
};

MessageTile.defaultProps = {
  description: '',
  theme: null,
  className: null,
  containerRef: null,
};

export default forwardRef((props, ref) => <MessageTile {...props} containerRef={ref} />);
