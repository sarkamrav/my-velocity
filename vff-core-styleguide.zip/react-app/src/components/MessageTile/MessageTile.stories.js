import React from 'react';
import MessageTile, { messageTileTheme } from './MessageTile';

export default {
  title: 'Message Tile',
};

export const AllTypes = () => (
  <div style={{ padding: '16px', maxWidth: '732px' }}>
    <MessageTile
      theme={messageTileTheme.error}
      description="<p>Oops, something went wrong. Please try again later</p>"
    />
    <br />
    <MessageTile theme={messageTileTheme.success} description="<p>Your details have been updated</p>" />
    <br />
    <MessageTile
      theme={messageTileTheme.success}
      description="<p>Multiple lines: Your details have been updated. multiple lines. Your details have been updated. multiple lines Your details have been updated. multiple lines</p>"
    />
  </div>
);
