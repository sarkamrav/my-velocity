import PropTypes from 'prop-types';
import React, { useEffect, useRef, useState } from 'react';
import ReactDOM from 'react-dom';
import cx from 'classnames';

import ModalCloseButton, { modalButtonTheme } from './components/ModalCloseButton/ModalCloseButton';
import { useTrapFocus } from './utils';

import styles from './Modal.css';

export const modalTheme = {
  v2: 'v2',
  default: 'default', // TODO: tidy up version 1 on brand refresh
  confirmV1: 'confirmV1', // TODO: tidy up version 1 on brand refresh
  transitionScreen: 'transitionScreen',
};

const Modal = ({ children, withCloseButton, closeButtonText, theme, onDismiss, 'aria-label': ariaLabel }) => {
  const modalRef = useRef();
  const [isVisible, setIsVisible] = useState(false);

  // Handle keyboard shortcuts
  function handleKeyDown(event) {
    if (event.key === 'Escape') {
      onDismiss();
    }
  }

  useTrapFocus(modalRef);

  useEffect(() => {
    const scrollBarWidth = window.innerWidth - document.body.clientWidth;
    const header = document.querySelector('header.src-features-Navigation-Navigation_header');
    const businessFlyerHeader = document.querySelector(
      'header.src-features-BusinessFlyer-Navigation-Navigation_header',
    );
    const stickyFooter = document.querySelector('.src-features-Navigation-Navigation_stickyFooterContainer');

    function setPaddingRight(element, paddingWidth) {
      if (element) {
        // eslint-disable-next-line no-param-reassign
        element.style.paddingRight = `${paddingWidth}px`;
      }
    }

    document.body.classList.add('modal-open');
    if (scrollBarWidth) {
      setPaddingRight(document.body, scrollBarWidth);
      setPaddingRight(header, scrollBarWidth);
      setPaddingRight(businessFlyerHeader, scrollBarWidth);
      setPaddingRight(stickyFooter, scrollBarWidth);
    }
    setIsVisible(true);

    return () => {
      document.body.classList.remove('modal-open');
      if (scrollBarWidth) {
        setPaddingRight(document.body, 0);
        setPaddingRight(header, 0);
        setPaddingRight(businessFlyerHeader, 0);
        setPaddingRight(stickyFooter, 0);
      }
    };
  }, []);

  // Handle click outside
  useEffect(() => {
    const initiallyFocusedElement = document.activeElement;

    function handleClickOutside(e) {
      if (modalRef.current && !modalRef.current.contains(e.target) && !initiallyFocusedElement.contains(e.target)) {
        onDismiss();
      }
    }

    document.body.addEventListener('click', handleClickOutside);
    modalRef.current.focus();

    return () => {
      document.body.removeEventListener('click', handleClickOutside);

      if (initiallyFocusedElement) {
        initiallyFocusedElement.focus();
      }
    };
  }, [onDismiss]);

  const isVersionTwo = theme === modalTheme.v2 || theme === modalTheme.transitionScreen;

  return ReactDOM.createPortal(
    <div
      className={cx(styles.overlay, {
        [styles.versionTwo]: isVersionTwo,
        [styles.confirmV1]: theme === modalTheme.confirmV1,
        [styles.transitionScreen]: theme === modalTheme.transitionScreen,
        [styles.visible]: isVisible,
      })}
    >
      {/* eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex,jsx-a11y/no-noninteractive-element-interactions */}
      <div
        ref={modalRef}
        className={styles.modal}
        onKeyDown={handleKeyDown}
        tabIndex={-1}
        role="alertdialog"
        aria-modal="true"
        aria-label={ariaLabel}
      >
        {withCloseButton && (
          <ModalCloseButton
            className={styles.closeButton}
            aria-label={closeButtonText}
            onClick={onDismiss}
            theme={isVersionTwo ? modalButtonTheme.v2 : modalButtonTheme.default}
          />
        )}

        {children}
      </div>
    </div>,
    document.body,
  );
};

Modal.propTypes = {
  children: PropTypes.node.isRequired,
  withCloseButton: PropTypes.bool,
  onDismiss: PropTypes.func.isRequired,
  'aria-label': PropTypes.string.isRequired,
  theme: PropTypes.string,
  closeButtonText: PropTypes.string,
};

Modal.defaultProps = {
  withCloseButton: false,
  theme: modalTheme.default,
  closeButtonText: 'close modal',
};

export default Modal;
