import { useEffect } from 'react';
import { focusableCssSelector } from '../../utils/common';

/**
 * Traps focus within the given element
 *
 * @see https://hiddedevries.nl/en/blog/2017-01-29-using-javascript-to-trap-focus-in-an-element
 *
 * @param {React.Ref} elementRef
 */
export function useTrapFocus(elementRef) {
  const currentElRef = elementRef.current;
  useEffect(() => {
    const KEYCODE_TAB = 9;

    function handleKeyDown(e) {
      const focusableElements = currentElRef.querySelectorAll(focusableCssSelector);

      const firstFocusableEl = focusableElements[0];
      const lastFocusableEl = focusableElements[focusableElements.length - 1];

      const isTabPressed = e.key === 'Tab' || e.keyCode === KEYCODE_TAB;

      if (!isTabPressed) {
        return;
      }

      if (e.shiftKey) {
        // Shift + Tab
        if (document.activeElement === firstFocusableEl) {
          lastFocusableEl.focus();
          e.preventDefault();
        }

        // Tab
      } else if (document.activeElement === lastFocusableEl) {
        firstFocusableEl.focus();
        e.preventDefault();
      }
    }

    if (currentElRef) {
      currentElRef.addEventListener('keydown', handleKeyDown);
    }

    return () => {
      if (currentElRef) {
        currentElRef.removeEventListener('keydown', handleKeyDown);
      }
    };
  }, [currentElRef]);
}
