import React from 'react';
import noop from 'lodash/noop';
import Modal, { modalTheme } from './Modal';
import useModal from '../../hooks/useModal';
import ShadowContainer from './components/ShadowContainer/ShadowContainer';
import HeaderContentTile from './components/HeaderContentTile/HeaderContentTile';
import RichTextContent from '../RichTextContent/RichTextContent';
import TransitionScreenTile from './components/TransitionScreenTile/TransitionScreenTile';

export default {
  title: 'modal/default',
};

export const AllTypes = () => {
  const { isShowing, toggle } = useModal();
  const { isShowing: isLessVaContent, toggle: toggleLessVaContent } = useModal();
  const { isShowing: isVffModalShowing, toggle: toggleVffModal } = useModal();
  const { isShowing: isTransitionScreenShowing, toggle: toggleTransitionScreen } = useModal();

  return (
    <>
      <h3>VA style modal</h3>
      <button onClick={toggle}>with Scroll bar</button>
      <br />

      {isShowing && (
        <Modal onDismiss={toggle} aria-label="test" withCloseButton theme={modalTheme.v2}>
          <ShadowContainer>
            <HeaderContentTile title="AU$1 = from 5 Points at Snooze" subTitle="was AU$1 = 2 Points">
              <RichTextContent content="<p>Lorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but has no real</p>" />
            </HeaderContentTile>
          </ShadowContainer>
        </Modal>
      )}

      <button onClick={toggleLessVaContent}>without scrollbar</button>
      <br />

      {isLessVaContent && (
        <Modal onDismiss={toggleLessVaContent} aria-label="test" withCloseButton theme={modalTheme.v2}>
          <ShadowContainer>
            <HeaderContentTile title="AU$1 = from 5 Points at Snooze" subTitle="was AU$1 = 2 Points">
              <RichTextContent content="<p>Lorem Ipsum refers to a dummy </p>" />
            </HeaderContentTile>
          </ShadowContainer>
        </Modal>
      )}

      <h3>Transition Screen</h3>
      <button onClick={toggleTransitionScreen}>Transition Screen</button>
      {isTransitionScreenShowing && (
        <Modal onDismiss={noop} aria-label="test" withCloseButton={false} theme={modalTheme.transitionScreen}>
          <TransitionScreenTile
            title="<p>AU$1 = from 5 Points <br> at Snooze</p>"
            subTitle="was AU$1 = 2 Points"
            description="<p>Any purchases you make during this session will be tracked if you have enabled your cookies.</p>"
          />
        </Modal>
      )}

      <h3>VFF style modal (To be deprecated)</h3>
      <button onClick={toggleVffModal}>VFF style modal</button>

      {isVffModalShowing && (
        <Modal onDismiss={toggleVffModal} aria-label="test" withCloseButton>
          <div>
            Lorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill gaps
            in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but has
            no realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to
            fill gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin
            but has no realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic
            design to fill gaps in the page before the actual words are put into the finished product. Lorem ipsum
            resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in publishing
            and graphic design to fill gaps in the page before the actual words are put into the finished product. Lorem
            ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in
            publishing and graphic design to fill gaps in the page before the actual words are put into the finished
            product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is
            often used in publishing and graphic design to fill gaps in the page before the actual words are put into
            the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text
            that is often used in publishing and graphic design to fill gaps in the page before the actual words are put
            into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of
            text that is often used in publishing and graphic design to fill gaps in the page before the actual words
            are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy
            block of text that is often used in publishing and graphic design to fill gaps in the page before the actual
            words are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a
            dummy block of text that is often used in publishing and graphic design to fill gaps in the page before the
            actual words are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum
            refers to a dummy block of text that is often used in publishing and graphic design to fill gaps in the page
            before the actual words are put into the finished product. Lorem ipsum resembles Latin but has no realLorem
            Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill gaps in
            the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but has no
            realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design to fill
            gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles Latin but
            has no realLorem Ipsum refers to a dummy block of text that is often used in publishing and graphic design
            to fill gaps in the page before the actual words are put into the finished product. Lorem ipsum resembles
            Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in publishing and
            graphic design to fill gaps in the page before the actual words are put into the finished product. Lorem
            ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is often used in
            publishing and graphic design to fill gaps in the page before the actual words are put into the finished
            product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text that is
            often used in publishing and graphic design to fill gaps in the page before the actual words are put into
            the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of text
            that is often used in publishing and graphic design to fill gaps in the page before the actual words are put
            into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy block of
            text that is often used in publishing and graphic design to fill gaps in the page before the actual words
            are put into the finished product. Lorem ipsum resembles Latin but has no realLorem Ipsum refers to a dummy
            block of text that is often used in publishing and graphic design to fill gaps in the page before the actual
            words are put into the finished product. Lorem ipsum resembles Latin but has no real
          </div>
        </Modal>
      )}
    </>
  );
};
