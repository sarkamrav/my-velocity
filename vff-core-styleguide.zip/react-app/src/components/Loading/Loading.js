import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import styles from './Loading.css';
import LoadingSvg from './Loading.svg';
import LoadingV2 from './LoadingV2.svg';

const Loading = ({ className, containerClassName, ariaLabelText, isLoadingV2 }) => (
  <div className={cx(styles.loadingContainer, containerClassName)}>
    {isLoadingV2 ? (
      <LoadingV2 role="alert" aria-label={ariaLabelText} className={cx(styles.loading, className)} />
    ) : (
      <LoadingSvg role="alert" aria-label={ariaLabelText} className={cx(styles.loading, className)} />
    )}
  </div>
);

Loading.propTypes = {
  containerClassName: PropTypes.string,
  className: PropTypes.string,
  isLoadingV2: PropTypes.bool,
  ariaLabelText: PropTypes.string,
};

Loading.defaultProps = {
  containerClassName: '',
  className: '',
  isLoadingV2: false,
  ariaLabelText: 'loading',
};

export default Loading;
