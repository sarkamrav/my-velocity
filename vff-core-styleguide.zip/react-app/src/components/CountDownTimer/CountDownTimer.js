import React, { useState, useEffect } from 'react';
import { DateTime } from 'luxon';
import PropTypes from 'prop-types';
import noop from 'lodash/noop';
import { serverTimeZone } from '../../utils/common';
import styles from './CountDownTimer.css';

const CountDownTimer = ({ targetDate, callback }) => {
  const [days, setDays] = useState('00');
  const [hours, setHours] = useState('00');
  const [minutes, setMinutes] = useState('00');
  const [seconds, setSeconds] = useState('00');

  let interval;
  const formatTime = (time) => String(time).padStart(2, '0');
  const serverTime = DateTime.fromISO(targetDate, serverTimeZone).endOf('day');

  const startTimer = () => {
    interval = setInterval(() => {
      const currentTime = DateTime.fromObject({}, serverTimeZone);
      const distance = serverTime.diff(currentTime).milliseconds;

      const d = Math.floor(distance / (24 * 60 * 60 * 1000));
      const h = Math.floor((distance % (24 * 60 * 60 * 1000)) / (1000 * 60 * 60));
      const m = Math.floor((distance % (60 * 60 * 1000)) / (1000 * 60));
      const s = Math.floor((distance % (60 * 1000)) / 1000);

      // Stop Timer
      if (distance <= 0) {
        callback();
        clearInterval(interval);
      } else {
        // Update Timer
        setDays(formatTime(d));
        setHours(formatTime(h));
        setMinutes(formatTime(m));
        setSeconds(formatTime(s));
      }
    });
  };

  useEffect(() => {
    startTimer();
    return () => {
      clearInterval(interval);
    };
  });

  return (
    <div className={styles.timerWrapper}>
      <div className={styles.timerSegment}>
        <span className={styles.time}>{days}</span>
        <span className={styles.label}>Days</span>
      </div>
      <div className={styles.timerSegment}>
        <span className={styles.time}>{hours}</span>
        <span className={styles.label}>Hours</span>
      </div>
      <div className={styles.timerSegment}>
        <span className={styles.time}>{minutes}</span>
        <span className={styles.label}>Minutes</span>
      </div>
      <div className={styles.timerSegment}>
        <span className={styles.time}>{seconds}</span>
        <span className={styles.label}>Seconds</span>
      </div>
    </div>
  );
};

CountDownTimer.propTypes = {
  targetDate: PropTypes.string,
  callback: PropTypes.func,
};

CountDownTimer.defaultProps = {
  targetDate: DateTime.now().toString(),
  callback: noop,
};

export default CountDownTimer;
