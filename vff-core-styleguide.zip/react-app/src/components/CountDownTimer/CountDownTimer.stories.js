import React from 'react';
import CountDownTimer from './CountDownTimer';

export default {
  title: 'CountDownTimer',
};

export const CountDown = () => <CountDownTimer targetDate="2028-02-02" />;
