import React from 'react';
import PropTypes from 'prop-types';

import RichTextContent from '../RichTextContent/RichTextContent';
import styles from './PolicyInfo.css';

const PolicyInfo = ({ id, title, content }) => (
  <section className={styles.container}>
    <h3 className={styles.title} id={id}>
      {title}
    </h3>

    {/* eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex */}
    <div tabIndex={0} className={styles.content}>
      <RichTextContent content={content} className={styles.conditionsText} />
    </div>
  </section>
);

PolicyInfo.propTypes = {
  id: PropTypes.string,
  title: PropTypes.string,
  content: PropTypes.string,
};

PolicyInfo.defaultProps = {
  id: '',
  title: '',
  content: '',
};

export default PolicyInfo;
