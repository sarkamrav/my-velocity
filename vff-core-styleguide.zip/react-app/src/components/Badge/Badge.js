import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import _ from 'lodash';
import styles from './Badge.css';

const Badge = ({ number, loading, className }) => (
  <span
    className={cx(
      styles.container,
      {
        [styles.loading]: loading,
      },
      className,
    )}
    data-count={_.clamp(number, 0, 99)}
  />
);

Badge.propTypes = {
  number: PropTypes.number,
  loading: PropTypes.bool,
  className: PropTypes.string,
};

Badge.defaultProps = {
  number: 0,
  loading: false,
  className: '',
};

export default Badge;
