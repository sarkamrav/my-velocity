import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import styles from './MandatoryIndicator.css';

const MandatoryIndicator = ({ className }) => <div className={cx(styles.mandatoryIndicator, className)} />;

MandatoryIndicator.propTypes = {
  className: PropTypes.string,
};

MandatoryIndicator.defaultProps = {
  className: '',
};

export default MandatoryIndicator;
