import React from 'react';
import { Provider } from 'react-redux';
import MockAdapter from 'axios-mock-adapter';

import { configureStore } from '../../stores';
import BuyPointsCallToAction from './BuyPointsCallToAction';
import api from '../../utils/api';
import apiResponseMock from './mocks/api-response.mock.json';
import mock from './mocks/mock.json';

export default {
  title: 'BuyPointsCallToAction',
};

const Template = (args) => {
  const { authenticated = false, memberDataLoading = false, apiError, currentPointsBalance = 1, ...rest } = args;
  const mockVffPointsBoosterApi = new MockAdapter(api.vffPointsBoosterApi, {
    delayResponse: 1000,
  });

  if (apiError) {
    mockVffPointsBoosterApi.onPost('/loyalty/v2/pointsbooster/mvdelegate').reply(500, {
      code: 40084,
      title: 'Unknown Error',
      status: 500,
      detail: "An unknown error has occurred in one of Virgin Australia's systems.",
    });
  } else {
    mockVffPointsBoosterApi.onPost('/loyalty/v2/pointsbooster/mvdelegate').reply(200, {
      ...apiResponseMock,
    });
  }

  return (
    <Provider
      store={configureStore({
        user: {
          memberDataLoaded: true,
          memberDataLoading,
          memberDataLoadError: true,
          authenticated,
          account: {
            joinDate: '2019-06-01',
            currentPointsBalance,
          },
        },
      })}
    >
      <div>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis at nobis assumenda. Impedit laboriosam
        facilis, suscipit ducimus veniam architecto ratione, modi ab nisi officiis nobis ipsum, quidem adipisci saepe
        praesentium!
      </div>
      <BuyPointsCallToAction {...rest} />
    </Provider>
  );
};

export const authenticated = Template.bind({});
authenticated.args = {
  ...mock,
  authenticated: true,
};

export const unAuthenticated = Template.bind({});
unAuthenticated.args = {
  ...mock,
};

export const memberProfileLoading = Template.bind({});
memberProfileLoading.args = {
  ...mock,
  memberDataLoading: true,
};

export const error = Template.bind({});
error.args = {
  ...mock,
  authenticated: true,
  apiError: true,
};

export const errorCenterAligned = Template.bind({});
errorCenterAligned.args = {
  ...mock,
  authenticated: true,
  apiError: true,
  centreAligned: true,
};

export const ineligibleMember = Template.bind({});
ineligibleMember.args = {
  ...mock,
  authenticated: true,
  currentPointsBalance: 0,
};

export const ineligibleMemberCenterAligned = Template.bind({});
ineligibleMemberCenterAligned.args = {
  ...mock,
  authenticated: true,
  currentPointsBalance: 0,
  centreAligned: true,
};
