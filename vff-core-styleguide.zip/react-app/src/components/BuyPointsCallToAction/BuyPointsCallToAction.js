import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import cx from 'classnames';
import qs from 'qs';
import { isMobile } from 'react-device-detect';

import get from 'lodash/get';
import api from '../../utils/api';
import ssoHandler from '../../utils/ssoHandler';
import analyticsSend from '../../utils/analytics';
import Loading from '../Loading/Loading';
import * as userData from '../../stores/utilities';
import RichTextContent from '../RichTextContent/RichTextContent';
import Icon from '../Icon/Icon';
import BuyPointsMessageTile from './BuyPointsMessageTile/BuyPointsMessageTile';

import styles from './BuyPointsCallToAction.css';

const BuyPointsCallToAction = ({
  authenticatedCtaContainer,
  unauthenticatedCtaContainer,
  errorMessages,
  user,
  containerClass,
  className,
  centreAligned,
  ineligibleMemberMessage,
  ineligibleMemberCta,
  parameters,
}) => {
  const authenticated = userData.getHasLoggedIn(user);
  const memberDataLoading = userData.getMemberDataLoading(user);
  const joinDate = userData.getJoinDate(user);
  const currentPointsBalance = Boolean(userData.getCurrentPointsBalance(user));

  const ctaContainer = authenticated ? authenticatedCtaContainer : unauthenticatedCtaContainer;
  let timeOut;

  const [loading, setLoading] = useState(false);
  const [apiError, setApiError] = useState(false);

  useEffect(() => {
    if (apiError) {
      // eslint-disable-next-line react-hooks/exhaustive-deps
      timeOut = setTimeout(() => {
        setApiError(false);
      }, 5000);
    }

    return () => {
      if (timeOut) clearTimeout(timeOut);
    };
  }, [apiError]);

  const redirectToLoginScreen = () => {
    const keycloak = ssoHandler.keycloakAuth;
    const url = `${window.location.origin}${window.location.pathname}`;
    const querystring = qs.parse(window.location.search, {
      ignoreQueryPrefix: true,
    });

    analyticsSend({
      eventCategory: 'login',
      eventName: 'login',
      navigationElementName: ctaContainer?.ctaLabel,
    });

    const loginUrl = keycloak.createLoginUrl({
      redirectUri: `${url}${qs.stringify(
        {
          ...querystring,
          explicit_login: 'web',
        },
        { addQueryPrefix: true },
      )}`,
      loginHint: querystring.login_hint,
    });

    window.location.href = loginUrl;
  };

  const pointBoosterAPICall = async () => {
    setLoading(true);
    setApiError(false);

    try {
      const response = await api.vffPointsBoosterApi.post('/loyalty/v2/pointsbooster/mvdelegate', {
        data: {
          accountCreationDate: joinDate,
        },
      });
      const links = get(response, 'data.links');

      if (links) {
        const href = get(links, 'self.href', '');
        const storeFrontUrl = authenticatedCtaContainer?.ctaUrl || '';
        const pointsBoosterRedirectLink = `${storeFrontUrl}${qs.stringify(
          {
            token: href,
            ...(parameters ? { ...parameters, isMobile } : {}),
          },
          { addQueryPrefix: true },
        )}`;

        window.open(pointsBoosterRedirectLink, authenticatedCtaContainer?.ctaOpenInNewTab ? '_blank' : '_self');
      }

      setLoading(false);
    } catch (error) {
      setApiError(true);
      setLoading(false);
    }
  };

  const closeErrorInfo = () => {
    clearTimeout(timeOut);
    setApiError(false);
  };

  const handleClick = (e) => {
    e.preventDefault();

    if (!authenticated) {
      redirectToLoginScreen();
    } else {
      pointBoosterAPICall();
    }
  };

  const isButtonClicked = authenticated && loading;
  return (
    <>
      {authenticated && !currentPointsBalance && (
        <BuyPointsMessageTile
          className={cx({
            [styles.buyPointsMessageCenter]: centreAligned,
          })}
          ineligibleMemberMessage={ineligibleMemberMessage}
          ineligibleMemberCta={ineligibleMemberCta}
        />
      )}
      {(!authenticated || currentPointsBalance) && (
        <div
          className={cx(
            styles.buyPointsCallToActionContainer,
            {
              [styles.alignButtonCenter]: centreAligned,
            },
            containerClass,
          )}
        >
          <button
            onClick={handleClick}
            title={ctaContainer?.ctaTitle || ctaContainer?.ctaLabel}
            className={cx(styles.buyPointsCallToAction, styles['buttonType--secondary'], className)}
            disabled={isButtonClicked}
          >
            {(memberDataLoading || isButtonClicked) && (
              <Loading containerClassName={styles.loaderContainer} className={styles.loader} />
            )}
            {ctaContainer?.ctaLabel}
          </button>

          {apiError && (
            <div className={styles.errorInfoContainer}>
              <RichTextContent
                className={styles.errorInfo}
                content={`<h2>${errorMessages?.defaultErrorMessage?.title}</h2> ${errorMessages?.defaultErrorMessage?.description}`}
              />
              <button className={styles.errorCloseButton} onClick={closeErrorInfo}>
                <Icon className={styles.errorCloseIcon} name="Cross" size="smallest" />
              </button>
            </div>
          )}
        </div>
      )}
    </>
  );
};

BuyPointsCallToAction.propTypes = {
  authenticatedCtaContainer: PropTypes.shape({
    ctaType: PropTypes.string,
    ctaLabel: PropTypes.string,
    ctaImage: PropTypes.string,
    ctaTitle: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaAsLink: PropTypes.bool,
    ctaUrl: PropTypes.string,
  }),
  unauthenticatedCtaContainer: PropTypes.shape({
    ctaType: PropTypes.string,
    ctaLabel: PropTypes.string,
    ctaImage: PropTypes.string,
    ctaTitle: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaAsLink: PropTypes.bool,
  }),
  errorMessages: PropTypes.shape({
    defaultErrorMessage: PropTypes.shape({
      title: PropTypes.string,
      description: PropTypes.string,
    }),
  }),
  user: PropTypes.shape({
    authenticated: PropTypes.bool,
  }),
  containerClass: PropTypes.string,
  className: PropTypes.string,
  centreAligned: PropTypes.bool,
  ineligibleMemberMessage: PropTypes.string,
  ineligibleMemberCta: PropTypes.shape({}),
  parameters: PropTypes.shape({}),
};

BuyPointsCallToAction.defaultProps = {
  authenticatedCtaContainer: {
    ctaType: 'secondary',
    ctaLabel: 'Buy Points',
    ctaImage: '',
    ctaTitle: '',
    ctaOpenInNewTab: false,
    ctaAsLink: false,
    ctaUrl: 'https://storefront.points.com/velocity-frequent-flyer/sso/mv-delegate/buy',
  },
  unauthenticatedCtaContainer: {
    ctaType: 'secondary',
    ctaLabel: 'Login to buy points',
    ctaImage: '',
    ctaTitle: '',
    ctaOpenInNewTab: false,
    ctaAsLink: false,
  },
  errorMessages: {
    defaultErrorMessage: {
      title: 'Uh oh. Something when wrong...',
      description: '<p>Please wait a moment and try again.</p>',
    },
  },
  user: {
    authenticated: false,
  },
  containerClass: '',
  className: '',
  centreAligned: false,
  ineligibleMemberMessage: null,
  ineligibleMemberCta: null,
  parameters: null,
};

export default connect(({ user }) => ({ user }))(BuyPointsCallToAction);
