import get from 'lodash/get';
import PropTypes from 'prop-types';
import React from 'react';
import cx from 'classnames';
import Button from '../Button/Button';
import Modal from '../Modal/Modal';
import { isCtaAvailable } from '../../utils/common';
import styles from './Confirm.css';

const Confirm = ({
  onDismiss,
  onSubmit,
  disabled,
  children,
  cancelCtaContainer,
  confirmCtaContainer,
  submitText,
  dismissText,
}) => {
  const defaultCancelBtnStyle = 'purple-link';
  const defaultSubmitBtnStyle = 'secondary';
  const isCancelCtaAvailable = isCtaAvailable(cancelCtaContainer);
  const isConfirmCtaAvailable = isCtaAvailable(confirmCtaContainer);

  return (
    <Modal onDismiss={onDismiss} aria-label="Confirm">
      <div>
        <div className={styles.content}>{children}</div>
        <div className={styles.footer}>
          {!!dismissText && (
            <Button
              className={cx(styles.cancelBtnDefault, {
                [styles.spacingOnLeft]: isCancelCtaAvailable ? cancelCtaContainer?.ctaAsLink : true,
              })}
              onClick={onDismiss}
              buttonType={get(cancelCtaContainer, 'ctaStyle') || defaultCancelBtnStyle}
              title={get(cancelCtaContainer, 'ctaTitle') || dismissText}
            >
              {get(cancelCtaContainer, 'ctaLabel') || dismissText}
            </Button>
          )}

          <div className={styles.footerSpacer} />

          <Button
            className={cx({
              [styles.spacingOnRight]: isConfirmCtaAvailable ? confirmCtaContainer?.ctaAsLink : false,
            })}
            onClick={onSubmit}
            disabled={disabled}
            loading={disabled}
            buttonType={get(confirmCtaContainer, 'ctaStyle') || defaultSubmitBtnStyle}
            title={get(confirmCtaContainer, 'ctaTitle') || submitText}
          >
            {get(confirmCtaContainer, 'ctaLabel') || submitText}
          </Button>
        </div>
      </div>
    </Modal>
  );
};

Confirm.propTypes = {
  onDismiss: PropTypes.func.isRequired,
  onSubmit: PropTypes.func.isRequired,
  disabled: PropTypes.bool,
  children: PropTypes.node.isRequired,
  cancelCtaContainer: PropTypes.shape({
    ctaAsLink: PropTypes.bool,
  }),
  confirmCtaContainer: PropTypes.shape({
    ctaAsLink: PropTypes.bool,
  }),
  submitText: PropTypes.string,
  dismissText: PropTypes.string,
};

Confirm.defaultProps = {
  disabled: false,
  submitText: 'Accept',
  dismissText: 'Cancel',
  confirmCtaContainer: null,
  cancelCtaContainer: null,
};

export default Confirm;
