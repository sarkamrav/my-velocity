import React from 'react';
import PropTypes from 'prop-types';
import Button from './Button';
import A from './A';
import ssoHandler from '../../utils/ssoHandler';
import { analyticsEventAction, analyticsEventName } from '../../utils/common';

const CtaButton = ({ action, ctaContainer, ...rest }) => {
  const { ctaUrl, ctaTitle, ctaOpenInNewTab, ctaStyle, ctaLabel, ctaAsLink } = ctaContainer;
  const { ctaInteraction } = analyticsEventName;

  switch (action) {
    case 'logout':
      return (
        <Button onClick={ssoHandler.logout} buttonType={ctaStyle} {...rest}>
          {ctaLabel}
        </Button>
      );
    default:
      return (
        <A
          href={ctaUrl}
          title={ctaTitle}
          target={ctaOpenInNewTab ? '_blank' : '_self'}
          buttonType={ctaStyle}
          ctaAsLink={ctaAsLink}
          analytics-metadata={JSON.stringify({
            eventName: ctaInteraction,
            eventCategory: 'page-cta',
            eventAction: analyticsEventAction.click,
            eventElementName: ctaTitle || '',
            eventElementText: ctaLabel || '',
            hyperlinkElementDestination: ctaUrl || '',
          })}
          {...rest}
        >
          {ctaLabel}
        </A>
      );
  }
};

CtaButton.propTypes = {
  action: PropTypes.oneOf(['link', 'logout']),
  ctaContainer: PropTypes.shape({
    ctaUrl: PropTypes.string,
    ctaTitle: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaStyle: PropTypes.string,
    ctaAsLink: PropTypes.bool,
    ctaLabel: PropTypes.string,
  }),
};

CtaButton.defaultProps = {
  action: 'link',
  ctaContainer: {},
};

export default CtaButton;
