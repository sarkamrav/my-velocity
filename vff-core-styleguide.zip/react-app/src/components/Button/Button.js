import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import Loading from '../Loading/Loading';
import { BUTTON_TYPES } from './buttonConstants';

import styles from './Button.css';

const Button = ({
  children,
  buttonType,
  className,
  loading,
  ariaLabelText,
  hideBorder,
  condensed,
  shakeButton,
  ...rest
}) => (
  <button
    className={cx(
      styles.defaults,
      styles.button,
      [styles[`buttonType--${buttonType}`]],
      {
        [styles.hideBorder]: hideBorder,
        [styles.condensed]: condensed,
        [styles.shakeButton]: shakeButton,
      },

      className,
    )}
    {...rest}
  >
    {loading && (
      <Loading ariaLabelText={ariaLabelText} containerClassName={styles.loading} className={styles.loadingIndicator} />
    )}
    {children}
  </button>
);

Button.propTypes = {
  children: PropTypes.node.isRequired,
  buttonType: PropTypes.oneOf(BUTTON_TYPES),
  className: PropTypes.string,
  loading: PropTypes.bool,
  hideBorder: PropTypes.bool,
  condensed: PropTypes.bool,
  shakeButton: PropTypes.bool,
  ariaLabelText: PropTypes.string,
};

Button.defaultProps = {
  buttonType: 'secondary',
  className: '',
  loading: false,
  hideBorder: false,
  condensed: false,
  shakeButton: false,
  ariaLabelText: 'loading',
};

export default Button;
