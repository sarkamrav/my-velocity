import React from 'react';
import Button from './Button';
import A from './A';

export default {
  title: 'Button',
};

export const AllTypes = () => (
  <div>
    primary:
    <Button buttonType="primary" condensed>
      Button text
    </Button>
    primary-transparent:
    <Button buttonType="primary-transparent">Button text</Button>
    secondary:
    <Button buttonType="secondary">Button text</Button>
    secondary-transparent:
    <Button buttonType="secondary-transparent">Button text</Button>
    tertiary:
    <Button buttonType="tertiary">Button text</Button>
    tertiary-transparent:
    <Button buttonType="tertiary-transparent">Button text</Button>
    black-link:
    <Button buttonType="black-link">Button text</Button>
    red-link:
    <Button buttonType="red-link">Button text</Button>
    red-link cta:
    <A buttonType="red-link" ctaAsLink href="www.google.com">
      Button text
    </A>
    black-link cta:
    <A buttonType="black-link" ctaAsLink>
      Button text
    </A>
    purple-link cta:
    <A buttonType="purple-link" ctaAsLink>
      Button text
    </A>
  </div>
);
