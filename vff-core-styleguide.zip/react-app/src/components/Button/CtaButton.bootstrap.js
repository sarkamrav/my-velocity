import React from 'react';
import ReactDOM from 'react-dom';
import { map, size, get } from 'lodash';
import { Provider } from 'react-redux';
import store from '../../stores';
import CtaButton from './CtaButton';

const ELEMENT_NAME = 'aem-cta-button';

function renderComponent(elements, hydrate) {
  map(elements, (element) => {
    const props = window.vffCoreWebsite[element.getAttribute(ELEMENT_NAME)];

    if (props) {
      const { renderMode = 'both', ...rest } = props;

      const component = (
        <Provider store={store}>
          <CtaButton {...rest} />
        </Provider>
      );

      // Hydrate only for renderMode === 'both' or authoring mode
      if (get(window.vffCoreWebsite, 'websiteData.authoringMode') || (renderMode === 'both' && hydrate)) {
        ReactDOM.hydrate(component, element);
      } else {
        // Handle renderMode authenticated and unauthenticated based off dispatch events
        document.addEventListener('myProfile', (e) => {
          const { authenticated } = e.data;
          if (
            (authenticated && renderMode === 'authenticated') ||
            (!authenticated && renderMode === 'unauthenticated')
          ) {
            ReactDOM.render(component, element);
          }
        });
      }
    }
  });
}

export default {
  elementName: ELEMENT_NAME,
  bootstrap: (id = null, hydrate = true) => {
    const elements = document.querySelectorAll(`[${ELEMENT_NAME}${id ? `=${id}` : ''}]`);

    if (size(elements) > 0) {
      renderComponent(elements, hydrate);
    }
  },
};
