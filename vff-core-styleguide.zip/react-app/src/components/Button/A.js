import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import Icon from '../Icon/Icon';
import { BUTTON_TYPES } from './buttonConstants';
import useServerRendering from '../../hooks/useServerRendering';

import styles from './Button.css';

const A = ({
  children,
  buttonType,
  className,
  linkClassName,
  ctaAsLink,
  target,
  ctaImage,
  'analytics-metadata': analyticsMetadataAttribute,
  icon,
  ...rest
}) => {
  const { rendered } = useServerRendering();

  return (
    <a
      className={cx(styles.defaults, [styles[`buttonType--${buttonType}`]], ctaAsLink ? linkClassName : className)}
      target={target}
      rel={target === '_blank' ? 'noopener noreferrer' : null}
      {...(rendered && analyticsMetadataAttribute ? { 'analytics-metadata': analyticsMetadataAttribute } : {})}
      {...rest}
    >
      {buttonType === 'image' && ctaImage ? (
        <>
          <div className={styles.imageContainer}>
            <img className={styles.image} src={ctaImage} alt="" />
          </div>
          <span className="sr-only">{children}</span>
        </>
      ) : (
        children
      )}

      {ctaAsLink && buttonType !== 'image' ? (
        <Icon className={styles.chevron} name={icon ?? 'ChevronNew'} size="smallest" />
      ) : null}
    </a>
  );
};

A.propTypes = {
  children: PropTypes.node.isRequired,
  buttonType: PropTypes.oneOf(BUTTON_TYPES),
  className: PropTypes.string,
  linkClassName: PropTypes.string,
  ctaAsLink: PropTypes.bool,
  target: PropTypes.string,
  ctaImage: PropTypes.string,
  'analytics-metadata': PropTypes.string,
  icon: PropTypes.string,
};

A.defaultProps = {
  buttonType: 'secondary',
  className: '',
  linkClassName: '',
  ctaAsLink: false,
  target: '_self',
  ctaImage: '',
  'analytics-metadata': '',
  icon: '',
};

export default A;
