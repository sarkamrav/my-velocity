import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import Icon from '../Icon/Icon';
import RichTextContent from '../RichTextContent/RichTextContent';
import A from '../Button/A';
import styles from './SuccessMessageTile.css';
import { isCtaAvailable } from '../../utils/common';

export const successMessageTheme = {
  shadow: 'shadow',
  noShadow: 'noShadow',
};

const SuccessMessageTile = ({
  id,
  title,
  subTitle,
  isSmallSizeIcon,
  iconPath,
  className,
  icon,
  content,
  ctaContainer,
  theme,
}) => (
  <div role="alert" id={id} className={cx(styles.container, styles[theme], className)}>
    {!iconPath && <Icon name={icon} className={styles.icon} />}
    {iconPath && (
      <div
        className={cx(styles.imageContainer, {
          [styles.smallSize]: isSmallSizeIcon,
        })}
      >
        <img className={styles.image} src={iconPath} alt="" />
      </div>
    )}
    {title && <div className={styles.title}>{title}</div>}
    {subTitle && <div className={styles.subTitle}>{subTitle}</div>}
    {content && <RichTextContent className={styles.description} content={content} />}
    {isCtaAvailable(ctaContainer) && (
      <A
        className={styles.buttonWrapper}
        href={ctaContainer?.ctaUrl}
        title={ctaContainer?.ctaTitle}
        target={ctaContainer?.ctaOpenInNewTab ? '_blank' : '_self'}
        buttonType={ctaContainer?.ctaStyle}
        ctaAsLink={ctaContainer?.ctaAsLink}
        ctaImage={ctaContainer?.ctaImage}
      >
        {ctaContainer?.ctaLabel}
      </A>
    )}
  </div>
);

SuccessMessageTile.propTypes = {
  id: PropTypes.string,
  icon: PropTypes.string,
  title: PropTypes.string,
  subTitle: PropTypes.string,
  className: PropTypes.string,
  content: PropTypes.string,
  iconPath: PropTypes.string,
  isSmallSizeIcon: PropTypes.bool,
  ctaContainer: PropTypes.shape({
    ctaUrl: PropTypes.string,
    ctaTitle: PropTypes.string,
    ctaOpenInNewTab: PropTypes.bool,
    ctaStyle: PropTypes.string,
    ctaAsLink: PropTypes.bool,
    ctaLabel: PropTypes.string,
    ctaImage: PropTypes.string,
  }),
  theme: PropTypes.oneOf([successMessageTheme.shadow, successMessageTheme.noShadow]),
};

SuccessMessageTile.defaultProps = {
  id: null,
  className: null,
  title: '',
  subTitle: '',
  content: '',
  iconPath: '',
  isSmallSizeIcon: false,
  icon: 'VaTickCircleClosed',
  ctaContainer: {},
  theme: successMessageTheme.noShadow,
};

export default SuccessMessageTile;
