import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import styles from './FakeLink.css';
import Icon from '../Icon/Icon';

const FakeLink = ({ children, className }) => (
  <span className={cx(styles.container, className)}>
    {children}
    <Icon className={styles.chevron} name="ChevronNew" size="smallest" />
  </span>
);

FakeLink.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
};

FakeLink.defaultProps = {
  children: '',
  className: '',
};

export default FakeLink;
