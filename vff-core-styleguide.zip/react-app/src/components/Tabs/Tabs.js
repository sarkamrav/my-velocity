import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import { map } from 'lodash';
import styles from './Tabs.css';

const Tabs = ({ tabs, selectedTab, onChangeTab, children, showTabs }) => (
  <>
    <div className={styles.tabs}>
      {showTabs
        ? map(tabs, (tab) => (
            <button
              key={tab.id}
              className={cx(styles.tab, {
                [styles.selected]: selectedTab.id === tab.id,
              })}
              onClick={() => onChangeTab(tab)}
            >
              <span>{tab.label}</span>
              {tab.count ? <span className={styles.count}>{tab.count}</span> : null}
            </button>
          ))
        : null}
    </div>
    {children}
  </>
);

Tabs.propTypes = {
  tabs: PropTypes.arrayOf(PropTypes.shape()),
  selectedTab: PropTypes.shape(),
  onChangeTab: PropTypes.func.isRequired,
  children: PropTypes.node.isRequired,
  showTabs: PropTypes.bool,
};

Tabs.defaultProps = {
  tabs: [],
  selectedTab: {},
  showTabs: true,
};

export default Tabs;
