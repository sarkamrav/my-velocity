import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import Icon from '../Icon/Icon';
import RichTextContent from '../RichTextContent/RichTextContent';
import styles from './InformationAlert.css';

export const informationAlertTheme = {
  error: 'error',
  success: 'success',
  info: 'info',
};

const InformationAlert = ({ id, className, title, content, status, iconName }) => (
  <div id={id} className={cx(styles.container, styles[status], className)}>
    <Icon name={iconName || 'Important'} size="small" className={styles.icon} />
    <div className={styles.content}>
      {title && <div className={styles.title}>{title}</div>}
      {content && <RichTextContent content={content} />}
    </div>
  </div>
);

InformationAlert.propTypes = {
  className: PropTypes.string,
  iconName: PropTypes.string,
  id: PropTypes.string,
  title: PropTypes.string,
  content: PropTypes.string,
  status: PropTypes.oneOf([informationAlertTheme.error, informationAlertTheme.info, informationAlertTheme.success]),
};

InformationAlert.defaultProps = {
  className: '',
  iconName: null,
  content: '',
  title: '',
  id: null,
  status: informationAlertTheme.error,
};

export default InformationAlert;
