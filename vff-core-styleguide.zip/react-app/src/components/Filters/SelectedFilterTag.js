import React from 'react';
import PropTypes from 'prop-types';
import styles from './SelectedFilterTag.css';
import Button from '../Button/Button';
import Icon from '../Icon/Icon';

const SelectedFilterTag = ({ filter, removeSelectedFilter }) => (
  <Button buttonType="primary-transparent" onClick={removeSelectedFilter} className={styles.button}>
    <span>{filter} </span>
    <Icon name="CrossOpenCircle" size="extra-small" className={styles.icon} />
  </Button>
);

SelectedFilterTag.propTypes = {
  filter: PropTypes.string.isRequired,
  removeSelectedFilter: PropTypes.func.isRequired,
};

export default SelectedFilterTag;
