import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import Button from '../Button/Button';
import Icon from '../Icon/Icon';
import useServerRendering from '../../hooks/useServerRendering';
import styles from './MultiSelectFilter.css';

const MultiSelectFilter = ({ children, label, onAnalytics }) => {
  const modalRef = useRef();
  const [open, setOpen] = useState(false);
  const { rendered } = useServerRendering();

  function handleClickOutside(e) {
    if (!modalRef.current.contains(e.target)) {
      setOpen(false);
    }
  }

  useEffect(() => {
    if (rendered) {
      onAnalytics(open);
    }
  }, [onAnalytics, open, rendered]);

  useEffect(() => {
    document.addEventListener('click', handleClickOutside, false);

    return () => {
      document.removeEventListener('click', handleClickOutside, false);
    };
  }, []);

  return (
    <div className={styles.container} ref={modalRef}>
      <Button onClick={() => setOpen((prev) => !prev)} buttonType="primary-transparent" className={styles.filterButton}>
        <span className={styles.ellipsis}>{label}</span>
        <Icon name={`Accordion${open ? 'Open' : 'Closed'}`} className={styles.icon} />
      </Button>
      {open ? <div className={styles.portal}>{children(setOpen)}</div> : null}
    </div>
  );
};

MultiSelectFilter.propTypes = {
  children: PropTypes.func.isRequired,
  label: PropTypes.string.isRequired,
  onAnalytics: PropTypes.func.isRequired,
};

export default MultiSelectFilter;
