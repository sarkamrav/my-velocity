import _ from 'lodash';
import { securityQuestionOptions } from '../../features/JoinPage/referenceData';

function isValidName(value) {
  return /^[A-Za-z\s'-]+$/.test(value);
}

export function required(message = 'This field is required') {
  return (newValue) => {
    let parsedNewValue = newValue;

    // Dropdown items
    if (_.hasIn(newValue, 'value')) {
      parsedNewValue = newValue.value;

      // eg. Empty dropdown items
    } else if (_.isNil(newValue)) {
      parsedNewValue = '';
    }

    const hasValue = !!parsedNewValue;

    return hasValue ? '' : message;
  };
}

export function matchesField(otherField, message) {
  return (newValue, allValues) => {
    const otherFieldValue = allValues[otherField];

    return otherFieldValue === newValue ? '' : message;
  };
}

export function name(message) {
  return (newValue) => {
    const newValueAsString = _.toString(newValue);

    const hasValidChars = isValidName(newValue);
    const isMin2Chars = newValueAsString.length >= 1;
    const isMax32Chars = newValueAsString.length <= 32;

    const isValid = hasValidChars && isMin2Chars && isMax32Chars;

    return isValid ? '' : message;
  };
}

export function reservationNumber(message) {
  return (newValue) => {
    const newValueAsString = _.toString(newValue);

    const isMin1Chars = newValueAsString.length >= 1;
    const isMax5Chars = newValueAsString.length <= 5;

    const isValid = isMin1Chars && isMax5Chars;

    return isValid ? message : '';
  };
}

export function nameValidCharacterCheck(message) {
  return (newValue) => (isValidName(newValue) ? '' : message);
}

export function minCharacters(message, characterLimit = 1) {
  return (newValue) => {
    const newValueAsString = _.toString(newValue);

    const isValid = characterLimit <= newValueAsString.length;

    return isValid ? '' : message;
  };
}

export function maxCharacters(message, characterLimit = 256) {
  return (newValue) => {
    const newValueAsString = _.toString(newValue);

    const hasReachLimit = newValueAsString.length > characterLimit;

    return hasReachLimit ? message : '';
  };
}

export function email(message = 'Please enter a valid email') {
  return (newValue) => {
    const isValidFormat = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(newValue);

    if (!isValidFormat) return message;

    const domain = newValue.split('@')[1];
    const doesBeginWithDot = /^\./.test(newValue);
    const doesEndWithDot = /\.$/.test(newValue);
    const hasConsecutiveDots = /\.\./.test(newValue);
    const domainStartsWithDot = /@\./.test(newValue);

    const isDomainValid = domain.length <= 255;
    const isDotsValid = !doesBeginWithDot && !doesEndWithDot && !hasConsecutiveDots && !domainStartsWithDot;

    const isValid = isValidFormat && isDomainValid && isDotsValid;

    return isValid ? '' : message;
  };
}

export function passwordMinCharacterCount(newValue) {
  return newValue.length >= 8 ? '' : 'Password must contain at least 8 characters';
}

export function passwordMaxCharacterCount(newValue) {
  return newValue.length <= 16 ? '' : 'Password cannot be longer than 16 characters';
}

export function passwordUpperCaseCheck(value) {
  const hasOneUpperCaseChar = /[A-Z]+/.test(value);

  return hasOneUpperCaseChar ? '' : 'Password must contain at least one upper case character';
}

export function passwordOneDigitOrSpecialChar(newValue) {
  const hasOneDigit = /[0-9]+/.test(newValue);
  const hasOneSpecialChar = /[^A-Za-z0-9]/.test(newValue);

  return hasOneDigit || hasOneSpecialChar ? '' : 'Password must contain at least one digit or special character';
}

export function validCharacterCheck(message) {
  return (newValue) => {
    const hasInvalidCharacter = /[^A-Za-z0-9.'\-*!~@#$%^&()_+=`]+/.test(newValue);

    return hasInvalidCharacter ? message : '';
  };
}

export function validSecurityAnswerCharacterCheck(message) {
  return (newValue) => {
    const hasInvalidSecurityAnswerCharacter = /[^A-Za-z0-9\\[\].;: ",/[<>/?{}|'[\-*!~@#$%^&()_+=`]+/.test(newValue);

    return hasInvalidSecurityAnswerCharacter ? message : '';
  };
}

export function passwordValidCharactersCheck(message, newValue) {
  return validCharacterCheck(message)(newValue);
}

export function password(message = 'The password contains invalid characters') {
  return (newValue) =>
    passwordMinCharacterCount(newValue) ||
    passwordMaxCharacterCount(newValue) ||
    passwordUpperCaseCheck(newValue) ||
    passwordOneDigitOrSpecialChar(newValue) ||
    passwordValidCharactersCheck(message, newValue);
}

export function dateOfBirth(message) {
  return (newValue) => {
    const isValidFormat = /^[0-9]{2}\/[0-9]{2}\/[0-9]{4}$/.test(newValue);

    if (!isValidFormat) return message;

    const pieces = newValue.split('/');
    const [day, month, year] = pieces;

    const currentDate = new Date();
    const enteredDate = new Date(year, month - 1, day);

    const isValidDay = day >= 1 && day <= 31;
    const isValidMonth = month >= 1 && month <= 12;
    const isValidYear = year >= 1901;
    const isValidDate = enteredDate <= currentDate;

    const isValid = isValidDay && isValidMonth && isValidYear && isValidDate;

    return isValid ? '' : message;
  };
}

export function pin(newValue) {
  const isValidFormat = /^[0-9]{4}$/.test(newValue);
  const hasRepeatedDigits = /(\d+?)\1/.test(newValue); // eg. 1133, 1156
  const hasIncreasingConsecutiveDigits = '0123456789'.includes(newValue); // eg. 1234
  const hasDecreasingConsecutiveDigits = '9876543210'.includes(newValue); // eg. 9876,
  const hasRepeatedPattern = newValue.substr(0, 2) === newValue.substr(2, 2); // eg. 1010, 1313

  const isValid =
    isValidFormat &&
    !hasRepeatedDigits &&
    !hasIncreasingConsecutiveDigits &&
    !hasDecreasingConsecutiveDigits &&
    !hasRepeatedPattern;

  return isValid
    ? ''
    : 'Invalid entry. PIN must be 4 digits which are not sequential (1234, 9876) or repeated (e.g. 6666, 1212, 1122)';
}

// returns flag to validate security answer min length for few security questions
export const acceptSingleCharacterSecurityAnswer = (question) => {
  const questionsAcceptingSingleChar = [
    securityQuestionOptions[1].value,
    securityQuestionOptions[3].value,
    securityQuestionOptions[6].value,
    securityQuestionOptions[7].value,
  ];
  if (question?.value) {
    if (questionsAcceptingSingleChar.includes(question.value?.toString())) {
      return true;
    }
    return false;
  }
  return false;
};

export function securityAnswer(acceptSingleCharacter = false) {
  return (newValue) => {
    const newValueAsString = _.toString(newValue);
    let isUnder2Chars = newValueAsString.length <= 2;
    if (acceptSingleCharacter) {
      isUnder2Chars = false;
    }
    const isOver50Chars = newValueAsString.length > 50;
    if (isUnder2Chars) return 'Answer must be more than 2 characters';
    if (isOver50Chars) return 'Answer must be under 50 characters';

    return '';
  };
}

export function postCode(newValue) {
  const newValueAsString = _.toString(newValue);

  const isValidFormat = /^[0-9]+$/.test(newValueAsString);
  const isMax10Chars = newValueAsString.length <= 10;

  const isValid = isValidFormat && isMax10Chars;

  return isValid ? '' : 'Invalid postcode entered';
}

export function consentConfirmation(newValue) {
  return newValue === true ? '' : 'Cannot continue until consent is given';
}

export function velocityNumber(message) {
  return (newValue) => {
    const isValidFormat = /^[0-9]{10}$/.test(newValue);

    return isValidFormat ? '' : message;
  };
}

export function krisFlyerMembershipNumber(message) {
  return (newValue) => {
    const isValidFormat = /^[0-9]{10}$/.test(newValue);

    return isValidFormat ? '' : message;
  };
}

export function airlineTransferLimit(min = 5000, max = 3000000) {
  return (newValue) => {
    const points = parseInt(newValue, 10);

    if (points < min) {
      return `You must transfer a minimum of ${min} Velocity Points`;
    }

    if (points > max) {
      return "You don't have sufficient Velocity Points to make this transfer";
    }

    return '';
  };
}

export function selfVelocityNumber(velocityId, message) {
  return (newValue) => (newValue === velocityId ? message : '');
}

export function phoneNumber(message) {
  return (newValue) => {
    const isValidFormat = /^([+]?\d{1,2}[-\s]?|)\d{3}[-\s]?\d{3}[-\s]?\d{4}$/.test(newValue);

    return isValidFormat ? '' : message;
  };
}

export function pointsToTransfer(newValue) {
  const isUnder5kPoints = newValue < 5000;
  const isOver125kPints = newValue > 125000;

  if (isUnder5kPoints)
    return 'You have entered less than the allowed minimum of 5,000 Points. Please enter a greater amount.';
  if (isOver125kPints)
    return 'You have entered more than the allowed maximum of 125,000 Points. Please enter a lesser amount.';

  return '';
}

/*
 optional validators below:
*/

export function optionalVelocityNumber(message) {
  return (newValue) => {
    if (!newValue) {
      return '';
    }

    return velocityNumber(message)(newValue);
  };
}

export function optionalMaxCharacters(message, limit = 256) {
  return (newValue) => {
    if (!newValue) {
      return '';
    }

    return maxCharacters(message, limit)(newValue);
  };
}

export function optionalPhoneNumber(message) {
  return (newValue) => {
    if (!newValue) {
      return '';
    }
    const isValid = /^\+?\d{0,14}$/.test(newValue);

    return isValid ? '' : message;
  };
}

export function optionalName(message) {
  return (newValue) => {
    if (!newValue) {
      return '';
    }
    const newValueAsString = _.toString(newValue);

    const hasValidChars = isValidName(newValue);
    const isMin2Chars = newValueAsString.length >= 1;
    const isMax32Chars = newValueAsString.length <= 32;

    const isValid = hasValidChars && isMin2Chars && isMax32Chars;

    return isValid ? '' : message;
  };
}

export function eTicketNumber(message) {
  return (newValue) => {
    const isValid = /^(\d{13})?$/.test(newValue);
    return isValid ? '' : message;
  };
}
