import _ from 'lodash';

export function fieldId(fieldName, fieldValue = '') {
  return `field_${fieldName}${fieldValue ? `_${_.snakeCase(fieldValue)}` : ''}`;
}

/**
 * Runs the given normalizer functions on the given value
 *
 * @param {*} fieldValue - Value to normalize
 * @param {function[]} normalizers - Normalizer functions
 * @returns {*} - The normalized value
 */
export function normalizeFormField(fieldValue, normalizers = []) {
  return _.reduce(normalizers, (prevValue, normalizer) => normalizer(prevValue), fieldValue);
}

/**
 * Validates a form field, returning an error message if validate fails.
 *
 * @param {string} fieldValue - The current value for the field being validated
 * @param {function[]} validators - Validator functions for the field being validated
 * @param {Object} currentFormValues - Current form values object
 * @returns {string} - An error message if there was an error, otherwise an empty string
 */
export function validateFormField(fieldValue, validators = [], currentFormValues) {
  let error = '';

  // eslint-disable-next-line consistent-return
  _.forEach(validators || [], (validator) => {
    error = validator(fieldValue, currentFormValues);

    if (error) {
      // Exit early on first found error
      return false;
    }
  });

  return error;
}
