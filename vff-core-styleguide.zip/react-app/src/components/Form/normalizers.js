export function onlyNumbers(newValue) {
  return newValue.replace(/[^\d]/g, '');
}

export function onlyText(newValue) {
  return newValue.replace(/[^A-Za-z]/g, '');
}

export function maxLength(count) {
  return (newValue) => newValue.substr(0, count);
}

export function phoneNumber(newValue) {
  const hasLeadingPlusChar = /^\+/.test(newValue);

  if (hasLeadingPlusChar) {
    // Don't remove the leading plus
    return `+${onlyNumbers(newValue.substr(1))}`;
  }

  return onlyNumbers(newValue);
}
