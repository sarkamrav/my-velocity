import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import * as Icons from './icons/_IconList';

import styles from './Icon.css';

const Icon = (props) => {
  const { name, className, size, ...rest } = props;
  const IconComponent = Icons[name];

  return IconComponent ? (
    <IconComponent className={cx(styles.icon, styles[`size--${size}`], className)} {...rest} />
  ) : null;
};

Icon.propTypes = {
  name: PropTypes.string.isRequired,
  className: PropTypes.string,
  size: PropTypes.oneOf(['default', 'small', 'extra-small', 'smallest']),
};

Icon.defaultProps = {
  className: '',
  size: 'default',
};

export default Icon;
