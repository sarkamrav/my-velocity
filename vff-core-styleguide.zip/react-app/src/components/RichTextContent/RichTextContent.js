import React, { useState, useEffect, useRef, useCallback } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import { createPopper } from '@popperjs/core';

import Collapse from '../Collapse/Collapse';
import Button from '../Button/Button';
import Icon from '../Icon/Icon';
import { focusableCssSelector } from '../../utils/common';
import RichTextTooltip from './RichTextTooltip/RichTextTooltip';

import styles from './RichTextContent.css';

// We will be using this component specifically for the AEM RTE.
// RichTextView will be continued to be used internally on components for the time being, until we migrate over to this completely.
const RichTextContent = ({
  content,
  className,
  truncateTextHeight,
  isExpandable,
  readMoreLabel,
  readLessLabel,
  jsObjectKey,
  'analytics-metadata': analyticsMetadataAttribute,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [currentTooltipId, setCurrentTooltipId] = useState(null);
  const elementRef = useRef();
  const tooltipRef = useRef({});

  const richText = (
    <div
      ref={elementRef}
      className={cx('vff__rte', className)}
      dangerouslySetInnerHTML={{ __html: content }}
      analytics-metadata={analyticsMetadataAttribute}
    />
  );

  const onReadMoreClick = useCallback(() => {
    setIsExpanded((prevState) => !prevState);
  }, []);

  useEffect(() => {
    if (isExpandable) {
      const focusableElements = elementRef.current.querySelectorAll(focusableCssSelector);

      for (let i = 0, max = focusableElements.length; i < max; i += 1) {
        if (!isExpanded) {
          focusableElements[i].tabIndex = -1;
        } else {
          focusableElements[i].tabIndex = 0;
        }
      }
    }
  }, [isExpanded, content, isExpandable]);

  useEffect(() => {
    const elementRefCurrent = elementRef.current;
    function handleTooltipClick(e) {
      const tooltipId = e.target.getAttribute('data-tooltip-id');

      if (tooltipId) {
        setCurrentTooltipId(tooltipId);
      }
    }

    if (elementRefCurrent) {
      elementRefCurrent.addEventListener('click', handleTooltipClick);
      elementRefCurrent.addEventListener('focusin', handleTooltipClick);
    }

    return () => {
      if (elementRefCurrent) {
        elementRefCurrent.removeEventListener('click', handleTooltipClick);
        elementRefCurrent.removeEventListener('focusin', handleTooltipClick);
      }
    };
  }, [content]);

  useEffect(() => {
    const tooltipButton = elementRef.current.querySelector(`[data-tooltip-id="${currentTooltipId}"]`);
    const tooltip = document.getElementById(currentTooltipId);

    function cleanUpTooltipInstance() {
      if (tooltipRef && tooltipRef.current && tooltipRef.current.destroy) {
        tooltipRef.current.destroy();
        tooltipRef.current = null;
      }
    }

    function handleBlur() {
      setCurrentTooltipId('');
    }

    function handleKeyDown(event) {
      if (event.key === 'Escape') {
        setCurrentTooltipId('');
      }
    }

    if (tooltipButton && tooltip) {
      tooltipButton.addEventListener('blur', handleBlur);
      tooltipButton.addEventListener('keydown', handleKeyDown);

      const isMobile = window.matchMedia('(max-width: 767px)').matches;

      tooltipRef.current = createPopper(tooltipButton, tooltip, {
        strategy: 'fixed',
        placement: isMobile ? 'bottom' : 'right',
        modifiers: [
          {
            name: 'arrow',
            options: {
              padding: 5,
            },
          },
          {
            name: 'offset',
            options: {
              offset: [16, 16],
            },
          },
          {
            name: 'preventOverflow',
            options: {
              altAxis: true,
              padding: 20,
            },
          },
        ],
      });
    }

    return () => {
      if (tooltipButton) {
        tooltipButton.removeEventListener('blur', handleBlur);
        tooltipButton.removeEventListener('keydown', handleKeyDown);
      }
      cleanUpTooltipInstance();
    };
  }, [currentTooltipId]);

  return (
    <>
      {isExpandable ? (
        <Collapse
          className={cx(styles.richTextContainer, {
            [styles.isExpanded]: isExpanded,
          })}
          initialHeight={truncateTextHeight}
          isOpen={isExpanded}
          id={jsObjectKey}
          duration={100}
        >
          {richText}

          {isExpandable && (
            <div className={styles.buttonContainer}>
              <Button
                buttonType="red-link"
                onClick={onReadMoreClick}
                aria-controls={jsObjectKey}
                aria-expanded={isExpanded}
              >
                {isExpanded ? readLessLabel : readMoreLabel}
                <Icon name="Chevron" size="smallest" />
              </Button>
            </div>
          )}
        </Collapse>
      ) : (
        richText
      )}

      {currentTooltipId && <RichTextTooltip id={currentTooltipId} />}
    </>
  );
};

RichTextContent.propTypes = {
  content: PropTypes.string.isRequired,
  className: PropTypes.string,
  readLessLabel: PropTypes.string,
  readMoreLabel: PropTypes.string,
  jsObjectKey: PropTypes.string,
  truncateTextHeight: PropTypes.number,
  isExpandable: PropTypes.bool,
  analyticsMetadata: PropTypes.shape({}),
  'analytics-metadata': PropTypes.string,
};

RichTextContent.defaultProps = {
  className: '',
  isExpandable: false,
  analyticsMetadata: null,
  truncateTextHeight: 95,
  readLessLabel: 'Read less',
  readMoreLabel: 'Read more',
  jsObjectKey: '',
  'analytics-metadata': null,
};

export default RichTextContent;
