import React from 'react';
import RichTextContent from './RichTextContent';
import richTextMock from './mocks/rich-text.mock.json';
import richTextExpandableMock from './mocks/rich-text--expandable.mock.json';
import tooltipMock from './mocks/rich-text--tooltip.mock.json';

export default {
  title: 'Rich Text Content',
};

export const Default = () => <RichTextContent {...richTextMock} jsObjectKey="rich-text-dXNKBYrH" />;
export const ExpandableMode = () => <RichTextContent {...richTextExpandableMock} jsObjectKey="rich-text-dXNKBYrb" />;
export const Tooltip = () => <RichTextContent {...tooltipMock} jsObjectKey="rich-text-dXNKBYrc" />;
