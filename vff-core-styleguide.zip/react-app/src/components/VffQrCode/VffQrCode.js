import React from 'react';
import PropTypes from 'prop-types';
import QRCode from 'qrcode.react';

const VffQrCode = ({ url, imageSettings, size, level }) => (
  <QRCode value={url} imageSettings={imageSettings} size={size} level={level} renderAs="svg" includeMargin={false} />
);

VffQrCode.propTypes = {
  url: PropTypes.string,
  imageSettings: PropTypes.shape({
    src: PropTypes.string,
    x: PropTypes.number,
    y: PropTypes.number,
    height: PropTypes.number,
    width: PropTypes.number,
    excavate: PropTypes.bool,
  }),
  size: PropTypes.number,
  level: PropTypes.string,
};

VffQrCode.defaultProps = {
  url: '',
  size: 128,
  imageSettings: {
    src: 'https://experience.velocityfrequentflyer.com/etc.clientlibs/vff-core/clientlibs/site/head/resources/favicon.ico',
    x: null,
    y: null,
    excavate: true,
    height: 24,
    width: 24,
  },
  level: 'L',
};
export default VffQrCode;
