import PropTypes from 'prop-types';
import React from 'react';
import cx from 'classnames';
import Modal from '../Modal/Modal';
import RichTextContent from '../RichTextContent/RichTextContent';

import styles from './ErrorModal.css';

const ErrorModal = ({ onDismiss, errorMessage, header, ariaLabel }) => (
  <Modal withCloseButton onDismiss={onDismiss} aria-label={ariaLabel}>
    <div className={styles.header}>
      {React.cloneElement(header, {
        className: cx(header.props.className, styles.headerTitle),
      })}
    </div>

    <RichTextContent className={styles.content} content={errorMessage} />
  </Modal>
);

ErrorModal.propTypes = {
  ariaLabel: PropTypes.string.isRequired,
  onDismiss: PropTypes.func.isRequired,
  errorMessage: PropTypes.string.isRequired,
  header: PropTypes.node.isRequired,
};

export default ErrorModal;
