import React from 'react';
import PropTypes from 'prop-types';

const TextHighlighter = ({ text, pattern }) => {
  const regRex = new RegExp(pattern, 'gi');
  const textArray = text.split(regRex);

  if (textArray.length <= 1) {
    return text;
  }

  const matches = text.match(regRex);

  return textArray.reduce(
    (result, current, index) =>
      matches[index] ? [...result, current, <b key={current}>{matches[index]}</b>] : [...result, current],
    [],
  );
};

TextHighlighter.propTypes = {
  text: PropTypes.string,
  pattern: PropTypes.string,
};

TextHighlighter.defaultProps = {
  text: '',
  pattern: '',
};

export default TextHighlighter;
