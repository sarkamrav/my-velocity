import React, { useState } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import noop from 'lodash/noop';
import uniqueId from 'lodash/uniqueId';

import Icon from '../Icon/Icon';
import RichTextContent from '../RichTextContent/RichTextContent';

import styles from './RadioSelector.css';

const Radio = ({
  id,
  checked,
  value,
  className,
  name,
  imageUrl,
  onChange,
  onFocus,
  onBlur,
  title,
  description,
  disabled,
}) => {
  const [radioId] = useState(id || uniqueId('radioSelector_'));
  const [focused, setFocused] = useState(false);

  function onRadioFocus() {
    setFocused(true);
    onFocus();
  }

  function onRadioBlur() {
    setFocused(false);
    onBlur();
  }

  return (
    <div
      className={cx(styles.container, className, {
        [styles.focused]: focused,
      })}
    >
      <input
        id={radioId}
        type="radio"
        name={name}
        className="sr-only"
        value={value}
        onChange={onChange}
        onFocus={onRadioFocus}
        onBlur={onRadioBlur}
        checked={checked}
        aria-checked={checked}
        disabled={disabled}
      />
      <label
        className={cx(styles.label, {
          [styles.disabled]: disabled,
          [styles.selected]: checked,
        })}
        htmlFor={radioId}
      >
        {imageUrl && (
          <div className={styles.imageColumn}>
            <div className={styles.imageContainer}>
              <img className={styles.image} src={imageUrl} alt="" />
            </div>

            {checked && <Icon name="TickCircleClosed" className={styles.tickIcon} size="small" />}
          </div>
        )}
        <span className={styles.content}>
          <RichTextContent className={styles.title} content={title} />
          <RichTextContent className={styles.description} content={description} />
        </span>

        {!checked && disabled && <div className={styles.overlay} />}
      </label>
    </div>
  );
};

Radio.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
  id: PropTypes.string,
  name: PropTypes.string,
  className: PropTypes.string,
  value: PropTypes.string,
  checked: PropTypes.bool,
  imageUrl: PropTypes.string,
  onChange: PropTypes.func,
  onFocus: PropTypes.func,
  onBlur: PropTypes.func,
  disabled: PropTypes.bool,
};

Radio.defaultProps = {
  title: null,
  description: null,
  id: '',
  name: '',
  className: '',
  value: '',
  checked: false,
  imageUrl: '',
  onChange: noop,
  onFocus: noop,
  onBlur: noop,
  disabled: false,
};

export default Radio;
