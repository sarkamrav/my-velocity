import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import Icon from '../Icon/Icon';
import RichTextContent from '../RichTextContent/RichTextContent';

import styles from './SuccessMessage.css';

const SuccessMessage = ({ className, title, description }) => (
  <div className={cx(styles.container, className)}>
    <Icon name="TickCircleOpen" className={styles.icon} />

    {title && <RichTextContent className={styles.title} content={title} />}

    {description && <RichTextContent content={description} />}
  </div>
);

SuccessMessage.propTypes = {
  className: PropTypes.string,
  title: PropTypes.string,
  description: PropTypes.string,
};

SuccessMessage.defaultProps = {
  className: '',
  title: '',
  description: '',
};

export default SuccessMessage;
