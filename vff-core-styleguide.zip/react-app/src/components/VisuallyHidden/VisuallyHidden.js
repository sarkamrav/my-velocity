import React from 'react';
import PropTypes from 'prop-types';

const VisuallyHidden = ({ children }) => <span className="sr-only">{children}</span>;

VisuallyHidden.propTypes = {
  children: PropTypes.string,
};

VisuallyHidden.defaultProps = {
  children: '',
};

export default VisuallyHidden;
