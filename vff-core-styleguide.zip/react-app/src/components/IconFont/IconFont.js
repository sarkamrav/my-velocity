import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';

const IconFont = ({ name, className, ariaLabel }) => {
  const iconCssClasses = cx('vffutils__font-icon', `icon--${name}`, ariaLabel ? '' : className);
  const icon = <i aria-hidden className={iconCssClasses} />;

  return !ariaLabel ? (
    icon
  ) : (
    <span className={className}>
      {icon}
      <span className="sr-only">{ariaLabel}</span>
    </span>
  );
};

IconFont.propTypes = {
  name: PropTypes.string,
  className: PropTypes.string,
  ariaLabel: PropTypes.string,
};

IconFont.defaultProps = {
  name: '',
  className: null,
  ariaLabel: null,
};

export default IconFont;
