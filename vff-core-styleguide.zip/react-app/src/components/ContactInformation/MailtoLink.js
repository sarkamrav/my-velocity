import React from 'react';
import PropTypes from 'prop-types';
import Icon from '../Icon/Icon';
import styles from './MailtoLink.css';

const MailtoLink = ({ email, label, ...rest }) => (
  <a href={`mailto:${email}`} className={styles.mailtoLink} {...rest}>
    <Icon name="Email" size="extra-small" />
    {label || email}
  </a>
);

MailtoLink.propTypes = {
  email: PropTypes.string.isRequired,
  label: PropTypes.string,
};

MailtoLink.defaultProps = {
  label: null,
};

export default MailtoLink;
