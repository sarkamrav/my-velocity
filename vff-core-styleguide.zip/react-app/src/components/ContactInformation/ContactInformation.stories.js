import React from 'react';
import ContactInformation from './ContactInformation';
import contactInfoMock from './mocks/contact-info.mock.json';

export default {
  title: 'Contact Information',
};

export const Default = () => <ContactInformation {...contactInfoMock} />;
