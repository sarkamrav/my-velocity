import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { map } from 'lodash';
import Icon from '../Icon/Icon';
import TelLink from './TelLink';
import Message from './Message.svg';
import MailtoLink from './MailtoLink';
import Container from '../Container/Container';
import RichTextContent from '../RichTextContent/RichTextContent';
import styles from './ContactInformation.css';

const ContactInformation = ({ title, contacts, tooltip, analyticsMetadata, analyticsDataFromParent }) => {
  const analyticsMetadataKey = analyticsMetadata['analytics-metadata'];
  const [analyticsData, setAnalyticsData] = useState(analyticsMetadataKey);

  useEffect(() => {
    const commonAnalyticsData = window.vffCoreWebsite[analyticsMetadataKey] || {};

    setAnalyticsData({
      ...commonAnalyticsData,
      ...analyticsDataFromParent,
    });
  }, [analyticsMetadataKey, analyticsDataFromParent]);

  return (
    <Container className={styles.container} analytics-metadata={JSON.stringify(analyticsData)}>
      {title ? (
        <div className={styles.header}>
          <Icon name="Important" className={styles.icon} size="small" />
          <RichTextContent
            content={title}
            className={styles.title}
            analytics-metadata={JSON.stringify({
              ...analyticsData,
              eventName: 'hyperlink-interaction',
              eventCategory: 'hyperlink',
            })}
          />
        </div>
      ) : null}

      <div className={styles.contactNumbers}>
        {map(contacts, (contact) => (
          <div key={contact.title} className={styles.contact}>
            {contact.title ? <div>{contact.title}</div> : null}
            {contact.phone ? (
              <TelLink
                number={contact.phone}
                analytics-metadata={JSON.stringify({
                  ...analyticsData,
                  eventName: 'contact-us',
                  eventCategory: 'member-support',
                  contactType: 'phone',
                })}
              />
            ) : null}
            {contact.email ? (
              <MailtoLink
                email={contact.email}
                analytics-metadata={JSON.stringify({
                  ...analyticsData,
                  eventName: 'contact-us',
                  eventCategory: 'member-support',
                  contactType: 'email',
                })}
              />
            ) : null}
          </div>
        ))}
      </div>

      {tooltip && (tooltip.title || tooltip.text) ? (
        <div className={styles.tooltipContainer}>
          {tooltip.title ? (
            <div className={styles.left}>
              <Message />
              <span className={styles.title}>{tooltip.title}</span>
            </div>
          ) : null}
          {tooltip.text ? (
            <RichTextContent
              content={tooltip.text}
              analytics-metadata={JSON.stringify({
                ...analyticsData,
                eventName: 'hyperlink-interaction',
                eventCategory: 'hyperlink',
              })}
            />
          ) : null}
        </div>
      ) : null}
    </Container>
  );
};

ContactInformation.propTypes = {
  title: PropTypes.string.isRequired,
  contacts: PropTypes.arrayOf(
    PropTypes.shape({
      title: PropTypes.string.isRequired,
      phone: PropTypes.string,
      email: PropTypes.string,
    }),
  ),
  tooltip: PropTypes.shape({
    title: PropTypes.string.isRequired,
    text: PropTypes.string.isRequired,
  }).isRequired,
  analyticsMetadata: PropTypes.shape({
    'analytics-metadata': PropTypes.string,
  }),
  analyticsDataFromParent: PropTypes.shape({}),
};

ContactInformation.defaultProps = {
  contacts: [],
  analyticsMetadata: {},
  analyticsDataFromParent: {},
};

export default ContactInformation;
