import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import Icon from '../Icon/Icon';
import styles from './TelLink.css';

const TelLink = ({ number, className, ...rest }) => (
  <a href={`tel:${number}`} className={cx(styles.telLink, className)} {...rest}>
    <Icon name="Telephone" size="extra-small" />
    {number}
  </a>
);

TelLink.propTypes = {
  number: PropTypes.string.isRequired,
  className: PropTypes.string,
};

TelLink.defaultProps = {
  className: '',
};

export default TelLink;
