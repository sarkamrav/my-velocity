import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import Modal from '../Modal/Modal';

import styles from './TermsModal.css';

const TermsModal = ({ isShowing, hide, header, children, 'aria-label': ariaLabel }) =>
  isShowing && (
    <Modal onDismiss={hide} aria-label={ariaLabel} withCloseButton>
      {header && <div className={styles.modalHeader}>{header}</div>}
      <div className={styles.modalContent}>{children}</div>
    </Modal>
  );

TermsModal.propTypes = {
  isShowing: PropTypes.bool,
  hide: PropTypes.func,
  header: PropTypes.node,
  children: PropTypes.node.isRequired,
  'aria-label': PropTypes.string.isRequired,
};

TermsModal.defaultProps = {
  isShowing: false,
  hide: _.noop,
  header: null,
};

export default TermsModal;
