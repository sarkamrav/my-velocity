import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import styles from './Grid.css';

const Grid = ({ children, className }) => <div className={cx(styles.grid, className)}>{children}</div>;

Grid.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
};

Grid.defaultProps = {
  className: '',
};

export default Grid;
