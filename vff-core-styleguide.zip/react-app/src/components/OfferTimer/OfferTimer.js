import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { DateTime } from 'luxon';
import cx from 'classnames';

import Icon from '../Icon/Icon';
import { millisecondsToTime, getDurationBetween, getDistanceInWords } from '../../utils/duration';
import { capType } from '../../features/ActivatedOffer/constants';
import { serverTimeZone } from '../../utils/common';

import styles from './OfferTimer.css';

const OfferTimer = ({
  className,
  time,
  showCapType,
  registrationEndDate,
  activationCapMax,
  activationCapAvail,
  capOfferLabel,
  expirationDateLabel,
}) => {
  const convertedTime = DateTime.fromISO(time, serverTimeZone); // All promotions run on AEST, and should be compared as such
  const inclusiveRegistrationEndDate = DateTime.fromISO(registrationEndDate, serverTimeZone).plus({ days: 1 }); // All promotions are inclusive of the date
  const { duration, hours } = getDurationBetween(convertedTime, inclusiveRegistrationEndDate);
  const offerHasNotEnded = convertedTime < inclusiveRegistrationEndDate;

  function displayCap(capNumber, label) {
    return (
      <span className={styles.offerAvailable}>
        <span className={styles.emphasis}>{capNumber}</span> {label}
      </span>
    );
  }

  return (
    <div className={cx(styles.timer, className)}>
      {showCapType === capType.showMaxCap && !!activationCapMax && displayCap(activationCapMax, capOfferLabel)}

      {showCapType === capType.showMaxAvail && !!activationCapAvail && displayCap(activationCapAvail, capOfferLabel)}

      {offerHasNotEnded ? (
        <span className={styles.timeRemaining}>
          <Icon name="Clock" size="small" className={styles.icon} />
          <span className={styles.timerLabel}>
            {offerHasNotEnded ? `${expirationDateLabel} ` : 'Ended '}
            <span className={styles.emphasis}>
              {hours < 24
                ? millisecondsToTime(duration)
                : getDistanceInWords(convertedTime, inclusiveRegistrationEndDate)}
            </span>
          </span>
        </span>
      ) : null}
    </div>
  );
};

OfferTimer.propTypes = {
  registrationEndDate: PropTypes.string,
  activationCapMax: PropTypes.string,
  activationCapAvail: PropTypes.string,
  capOfferLabel: PropTypes.string.isRequired,
  expirationDateLabel: PropTypes.string.isRequired,
  time: PropTypes.string.isRequired,
  className: PropTypes.string,
  showCapType: PropTypes.oneOf([capType.none, capType.showMaxCap, capType.showMaxAvail]),
};

OfferTimer.defaultProps = {
  className: '',
  registrationEndDate: null,
  showCapType: null,
  activationCapAvail: null,
  activationCapMax: null,
};

export default connect((state) => ({
  user: state.user,
  time: state.time,
}))(OfferTimer);
