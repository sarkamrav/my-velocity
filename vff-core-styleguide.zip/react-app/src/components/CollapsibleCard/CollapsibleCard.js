import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import styles from './CollapsibleCard.css';
import Icon from '../Icon/Icon';

const CollapsibleCard = ({ count, title, collapsed, children, className, completed, onClick, transparent }) => (
  <div
    className={cx(styles.container, {
      [styles.collapsed]: collapsed,
      [styles.transparent]: transparent,
    })}
  >
    <div
      className={cx(styles.header, {
        [styles.clickable]: onClick,
      })}
      onClick={onClick}
      role="presentation"
    >
      <div className={styles.left}>
        <span
          className={cx(styles.count, {
            [styles.completed]: completed,
          })}
        >
          {completed ? <Icon name="Tick" size="extra-small" /> : count}
        </span>
        <span className={styles.title}>{title}</span>
      </div>
      <Icon name="Chevron" size="extra-small" className={styles.icon} />
    </div>

    <div className={cx(styles.content, className)}>{children}</div>
  </div>
);

CollapsibleCard.propTypes = {
  count: PropTypes.number.isRequired,
  title: PropTypes.string,
  collapsed: PropTypes.bool,
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
  completed: PropTypes.bool,
  onClick: PropTypes.func,
  transparent: PropTypes.bool,
};

CollapsibleCard.defaultProps = {
  title: '',
  collapsed: false,
  className: null,
  completed: false,
  onClick: null,
  transparent: false,
};

export default CollapsibleCard;
