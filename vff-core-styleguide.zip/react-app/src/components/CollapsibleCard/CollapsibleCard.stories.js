import React, { useState } from 'react';
import CollapsibleCard from './CollapsibleCard';

export default {
  title: 'CollapsibleCard/CollapsibleCard V1',
};

export const AllTypes = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <h3>CollapsibleCard V1</h3>
      <CollapsibleCard title="Password" count={1} collapsed={visible} onClick={() => setVisible((prev) => !prev)}>
        <div>Clicking Step 1 header open or close the content panel</div>
      </CollapsibleCard>

      <br />

      <CollapsibleCard count={2} title="Security Question">
        <div>test</div>
      </CollapsibleCard>

      <br />

      <CollapsibleCard count={3} title="My Details">
        <div>test</div>
      </CollapsibleCard>

      <br />

      <CollapsibleCard count={3} title="My Details" completed collapsed>
        <div>test</div>
      </CollapsibleCard>

      <br />

      <CollapsibleCard count={3} title="My Details" collapsed transparent>
        <div>test</div>
      </CollapsibleCard>
    </>
  );
};
