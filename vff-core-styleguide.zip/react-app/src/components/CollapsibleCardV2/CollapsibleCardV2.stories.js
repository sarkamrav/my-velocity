import React, { useState } from 'react';
import CollapsibleCardV2 from './CollapsibleCardV2';

export default {
  title: 'CollapsibleCard/CollapsibleCard V2',
};

export const AllTypes = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <h3>CollapsibleCard V2</h3>
      <CollapsibleCardV2 title="Password" count={1} collapsed={visible} onClick={() => setVisible((prev) => !prev)}>
        <div>Clicking Step 1 header open or close the content panel</div>
      </CollapsibleCardV2>

      <br />

      <CollapsibleCardV2 count={2} title="Security Question">
        <div>test</div>
      </CollapsibleCardV2>

      <br />

      <CollapsibleCardV2 count={3} title="My Details">
        <div>test</div>
      </CollapsibleCardV2>

      <br />

      <CollapsibleCardV2 count={3} title="My Details" completed collapsed>
        <div>test</div>
      </CollapsibleCardV2>

      <br />

      <CollapsibleCardV2 count={3} title="My Details" collapsed transparent>
        <div>test</div>
      </CollapsibleCardV2>
    </>
  );
};
