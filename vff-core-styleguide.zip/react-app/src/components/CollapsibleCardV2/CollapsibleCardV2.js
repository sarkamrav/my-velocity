import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import Icon from '../Icon/Icon';
import styles from './CollapsibleCardV2.css';

const CollapsibleCardV2 = ({ count, title, collapsed, children, className, completed, onClick, transparent }) => (
  <div
    className={cx(styles.container, {
      [styles.collapsed]: collapsed,
      [styles.transparent]: transparent,
    })}
  >
    <div
      className={cx(styles.header, {
        [styles.clickable]: onClick,
        [styles.completed]: completed,
      })}
      onClick={onClick}
      role="presentation"
    >
      <div className={styles.left}>
        <span className={styles.icon}>{completed ? <Icon name="VaTickCircleClosed" size="default" /> : count}</span>
        <span className={styles.title}>{title}</span>
      </div>
    </div>

    <div className={cx(styles.content, className)}>{children}</div>
  </div>
);

CollapsibleCardV2.propTypes = {
  count: PropTypes.number.isRequired,
  title: PropTypes.string,
  collapsed: PropTypes.bool,
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
  completed: PropTypes.bool,
  onClick: PropTypes.func,
  transparent: PropTypes.bool,
};

CollapsibleCardV2.defaultProps = {
  title: '',
  collapsed: false,
  className: null,
  completed: false,
  onClick: null,
  transparent: false,
};

export default CollapsibleCardV2;
