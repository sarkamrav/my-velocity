export function getHeadingId(accordionItemId) {
  return `accordion-heading-${accordionItemId}`;
}

export function getContentId(accordionItemId) {
  return `accordion-content-${accordionItemId}`;
}

export function isElementInAccordionItem(element, accordionItemId) {
  const accordionItemContentElement = document.getElementById(getContentId(accordionItemId));

  if (!accordionItemContentElement) return false;

  return accordionItemContentElement.contains(element);
}
