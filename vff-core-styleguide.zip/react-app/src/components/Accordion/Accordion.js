import cx from 'classnames';
import _ from 'lodash';
import PropTypes from 'prop-types';
import React, { useEffect, useState, useRef, useCallback } from 'react';

import ErrorBoundary from '../ErrorBoundary/ErrorBoundary';
import Icon from '../Icon/Icon';
import { COMPONENT_NAME, getHashId, getNavigationHeight, smoothScrollToElement } from '../../utils/common';
import { getContentId, getHeadingId, isElementInAccordionItem } from './utils';

import styles from './Accordion.css';

const Accordion = ({ title, accordionItems, className, isTitleLeftAligned }) => {
  const [openedItems, setOpenedItems] = useState(
    _.reduce(
      accordionItems,
      (result, accordionItem) => ({
        ...result,
        [getContentId(accordionItem.id)]: accordionItem.openByDefault,
      }),
      {},
    ),
  );
  const accordionContainerRef = useRef();
  const accordionContainerRefCurrent = accordionContainerRef.current;

  useEffect(() => {
    const accordionItemIdInUrl = _.some(accordionItems, { id: getHashId() })
      ? window.location.hash.replace('#', '')
      : null;
    if (accordionItemIdInUrl) {
      setOpenedItems((prevState) => ({
        ...prevState,
        [getContentId(accordionItemIdInUrl)]: true,
      }));
    }
  }, [accordionItems]);

  const isItemContentOpened = useCallback(
    (accordionItemId) => !!openedItems[getContentId(accordionItemId)],
    [openedItems],
  );

  function toggleContent(event, accordionItemId) {
    event.preventDefault();
    const contentId = getContentId(accordionItemId);
    const isOpening = !openedItems[contentId];

    window.location.hash = `#${accordionItemId}`;

    // For a nice UX, only scroll when opening an accordion section
    if (isOpening) {
      smoothScrollToElement(document.getElementById(getHeadingId(accordionItemId)), getNavigationHeight());
    }

    setOpenedItems((prevState) => ({
      ...prevState,
      [contentId]: !openedItems[contentId],
    }));
  }

  useEffect(() => {
    function openAccordionItem(contentId) {
      setOpenedItems((prevState) => ({
        ...prevState,
        [contentId]: true,
      }));
    }

    function handleEnsureElementIsVisible(event) {
      const targetElement = event.target;
      const hashId = getHashId();
      const isHashIdAccordionItem = _.findIndex(accordionItems, (accordionItem) => accordionItem.id === hashId) !== -1;
      let isTargetElementInAClosedSection = false;

      if (isHashIdAccordionItem) {
        openAccordionItem(getContentId(hashId));
        return;
      }

      const accordionItemThatHasTargetElement = accordionItems.find((item) =>
        isElementInAccordionItem(targetElement, item.id),
      );

      if (accordionItemThatHasTargetElement) {
        isTargetElementInAClosedSection = !isItemContentOpened(accordionItemThatHasTargetElement.id);

        if (isTargetElementInAClosedSection) {
          openAccordionItem(getContentId(accordionItemThatHasTargetElement.id));
        }
      }
    }

    if (accordionContainerRefCurrent) {
      accordionContainerRefCurrent.addEventListener('ensureElementIsVisible', handleEnsureElementIsVisible);
    }

    return () => {
      if (accordionContainerRefCurrent) {
        accordionContainerRefCurrent.removeEventListener('ensureElementIsVisible', handleEnsureElementIsVisible);
      }
    };
  }, [accordionContainerRefCurrent, accordionItems, isItemContentOpened]);

  return (
    <ErrorBoundary section={COMPONENT_NAME.accordion}>
      <div className={cx(styles.container, className)} data-allow-multiple>
        {title && (
          <h3 className={cx('heading heading--3 color color--purple', { [styles.leftAlignTitle]: isTitleLeftAligned })}>
            {title}
          </h3>
        )}
        <ul ref={accordionContainerRef} className={styles.list} aria-label={`${title} accordion`}>
          {_.map(accordionItems, (item) => (
            <li className={styles.listItem} key={item.id}>
              <button
                className={styles.listHeading}
                id={getHeadingId(item.id)}
                aria-controls={getContentId(item.id)}
                aria-expanded={isItemContentOpened(item.id)}
                onClick={(event) => toggleContent(event, item.id)}
              >
                <span className={styles.listHeadingText}>{item.title}</span>
                <div className={styles.iconWrapper}>
                  <Icon
                    name="Chevron"
                    size="extra-small"
                    className={cx(styles.icon, {
                      [styles.isOpen]: isItemContentOpened(item.id),
                    })}
                  />
                </div>
              </button>
              <div
                className={cx(styles.listContent, {
                  [styles.isOpened]: isItemContentOpened(item.id),
                })}
                id={getContentId(item.id)}
                aria-labelledby={getHeadingId(item.id)}
                aria-hidden={!isItemContentOpened(item.id)}
                role="region"
                {...(_.isString(item.content)
                  ? { dangerouslySetInnerHTML: { __html: item.content } }
                  : { children: item.content })}
              />
            </li>
          ))}
        </ul>
      </div>
    </ErrorBoundary>
  );
};

Accordion.propTypes = {
  title: PropTypes.string,
  className: PropTypes.string,
  accordionItems: PropTypes.arrayOf(
    PropTypes.shape({
      title: PropTypes.string,
      id: PropTypes.string,
      openByDefault: PropTypes.bool,
      content: PropTypes.node,
    }),
  ),
  isTitleLeftAligned: PropTypes.bool,
  analyticsMetadata: PropTypes.shape({}),
};

Accordion.defaultProps = {
  title: '',
  className: '',
  accordionItems: [],
  analyticsMetadata: {},
  isTitleLeftAligned: false,
};

export default Accordion;
