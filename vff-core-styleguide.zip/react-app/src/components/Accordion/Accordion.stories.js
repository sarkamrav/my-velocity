import React from 'react';
import Accordion from './Accordion';
import accordionMock from './mocks/accordion.mock.json';

export default {
  title: 'Accordion',
};

export const Default = () => <Accordion {...accordionMock} />;
