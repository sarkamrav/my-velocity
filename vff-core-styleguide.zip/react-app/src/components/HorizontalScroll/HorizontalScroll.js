import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import styles from './HorizontalScroll.css';

const HorizontalScroll = ({ children, className }) => <div className={cx(styles.container, className)}>{children}</div>;

HorizontalScroll.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
};

HorizontalScroll.defaultProps = {
  className: '',
};

export default HorizontalScroll;
