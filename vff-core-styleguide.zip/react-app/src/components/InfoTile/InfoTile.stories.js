import React from 'react';
import InfoTile from './InfoTile';

import sampleMock1 from './mocks/info-tile-mock--sample-text-1.json';
import sampleMock2 from './mocks/info-tile-mock--sample-text-2.json';

export default {
  title: 'Info Tile',
};

export const AllTypes = () => (
  <div style={{ padding: '16px', maxWidth: '732px' }}>
    <InfoTile {...sampleMock1} />
    <br />
    <InfoTile {...sampleMock2} />
  </div>
);
