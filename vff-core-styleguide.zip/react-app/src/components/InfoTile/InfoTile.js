import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';

import RichTextContent from '../RichTextContent/RichTextContent';
import Icon from '../Icon/Icon';

import styles from './InfoTile.css';

const InfoTile = ({ title, description, className }) => (
  <div className={cx(styles.container, className)}>
    <Icon className={styles.icon} name="VaInfoCircleClosed" size="extra-small" />

    <div className={styles.content}>
      {title && <div className={styles.title}>{title}</div>}
      {description && <RichTextContent content={description} />}
    </div>
  </div>
);

InfoTile.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
  className: PropTypes.string,
};

InfoTile.defaultProps = {
  title: null,
  description: null,
  className: null,
};

export default InfoTile;
