import React, { useState, useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import styles from './ReadMoreContainer.css';

const ReadMoreContainer = ({ children }) => {
  const [expanded, setExpanded] = useState(false);
  const [hasExpandButton, setHasExpandButton] = useState(false);
  const childrenRef = useRef(null);

  useEffect(() => {
    if (childrenRef.current && childrenRef.current.offsetHeight > 65) {
      setHasExpandButton(true);
    }
  }, []);

  return (
    <div
      className={cx(styles.container, {
        [styles.containerExpanded]: expanded,
      })}
    >
      <div ref={childrenRef}>{children}</div>

      {hasExpandButton ? (
        <button className={styles.expandButton} onClick={() => setExpanded((prevState) => !prevState)}>
          {expanded ? 'Less' : 'More'}
        </button>
      ) : null}
    </div>
  );
};

ReadMoreContainer.propTypes = {
  children: PropTypes.node.isRequired,
};

ReadMoreContainer.defaultProps = {};

export default ReadMoreContainer;
