import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import { isEmpty } from 'lodash';
import { DateTime } from 'luxon';
import styles from './HintLabel.css';

const HintLabel = ({ label, className }) => {
  const { text, backgroundColor, validUntil } = label;
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (!validUntil) {
      setIsVisible(true);
    }

    if (validUntil && DateTime.now() < DateTime.fromISO(validUntil)) {
      setIsVisible(true);
    }
  }, [validUntil]);

  return (
    !isEmpty(label) &&
    isVisible && (
      <span className={cx(styles.hintLabel, className)} style={{ backgroundColor }}>
        {text}
      </span>
    )
  );
};

HintLabel.propTypes = {
  label: PropTypes.shape({
    text: PropTypes.string,
    backgroundColor: PropTypes.string,
    validUntil: PropTypes.string,
  }),
  className: PropTypes.string,
};

HintLabel.defaultProps = {
  label: {},
  className: '',
};

export default HintLabel;
