import React from 'react';
import PropTypes from 'prop-types';
import styles from './SingleHeaderTable.css';

const SingleHeaderTable = ({ headers, rows }) =>
  rows && rows.length > 0 ? (
    <table className={styles.table}>
      {headers && headers.length > 0 ? (
        <thead>
          <tr>
            {headers.map((header) => (
              <th
                scope="col"
                className={styles.header}
                key={React.isValidElement(header) ? header.props.children : header}
              >
                {header}
              </th>
            ))}
          </tr>
        </thead>
      ) : null}

      <tbody>
        {rows.map((row) => (
          <tr key={row.uniqueId}>
            {Object.keys(row).map((key) =>
              key !== 'uniqueId' ? (
                <td key={key} className={styles.cell}>
                  {row[key]}
                </td>
              ) : null,
            )}
          </tr>
        ))}
      </tbody>
    </table>
  ) : null;

SingleHeaderTable.propTypes = {
  headers: PropTypes.arrayOf(PropTypes.node),
  rows: PropTypes.arrayOf(
    PropTypes.shape({
      uniqueId: PropTypes.string.isRequired,
    }),
  ),
};

SingleHeaderTable.defaultProps = {
  headers: [],
  rows: [],
};

export default SingleHeaderTable;
