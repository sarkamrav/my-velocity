import cx from 'classnames';
import PropTypes from 'prop-types';
import React from 'react';
import Icon from '../Icon/Icon';
import styles from './MoreContentToggleButton.css';

export const TOGGLE_BUTTON_DISPLAY_MODE = {
  light: 'light',
  dark: 'dark',
};

const MoreContentToggleButton = ({
  isShowingMore,
  readMoreLabel,
  readLessLabel,
  onClick,
  displayMode,
  ...restProps
}) => (
  <div className={styles.container}>
    <button
      className={cx('font-size font-size--small font-weight font-weight--bold', styles.button, {
        [styles.dark]: displayMode === TOGGLE_BUTTON_DISPLAY_MODE.dark,
      })}
      onClick={onClick}
      aria-expanded={isShowingMore}
      aria-label={readMoreLabel}
      {...restProps}
    >
      {isShowingMore ? readLessLabel : readMoreLabel}

      <Icon className={styles.icon} name={isShowingMore ? 'AccordionOpen' : 'AccordionClosed'} size="extra-small" />
    </button>
  </div>
);

MoreContentToggleButton.propTypes = {
  isShowingMore: PropTypes.bool.isRequired,
  readMoreLabel: PropTypes.string,
  readLessLabel: PropTypes.string,
  onClick: PropTypes.func.isRequired,
  displayMode: PropTypes.oneOf([TOGGLE_BUTTON_DISPLAY_MODE.light, TOGGLE_BUTTON_DISPLAY_MODE.dark]),
};

MoreContentToggleButton.defaultProps = {
  displayMode: TOGGLE_BUTTON_DISPLAY_MODE.light,
  readMoreLabel: 'More',
  readLessLabel: 'Less',
};

export default MoreContentToggleButton;
