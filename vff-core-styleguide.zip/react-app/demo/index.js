import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import store from '../src/stores';
import DeeplyNestedContent from './DeeplyNestedContent';
// import AccordionTest from './AccordionTest';

const App = () => (
  <Provider store={store}>
    <DeeplyNestedContent />
    {/*<AccordionTest />*/}
  </Provider>
);

ReactDOM.render(<App />, document.getElementById('demo'));
