export const tncForm = (tabId, merchant) => {
  const tncModalId = 'shop-and-earn_tnc';
  const tncModalShadowDomClass = 'velocityfrequentflyer__shop-and-earn-tnc-modal';
  const modalStyles = chrome.runtime.getURL('modal.css');
  let shadowDom;

  const modalTemplate = ({
    id, content, crossBtn = true, name = ''
  }) => {
    const logoImgPath = chrome.runtime.getURL('images/vff_logo.png');
    const crossBtnIcon = chrome.runtime.getURL('images/cross-icon.png');

    return `
      <div
        id=${id}
        class="shop-and-earn-modal-container opacity-scale-up-center"
      >
        <div class="shop-and-earn-modal slide-top">
          <div class="shop-and-earn-modal-header dis_flex">
            ${name && `<div class="shop-and-earn-modal-header__userName"> Hi, ${name}</div>`}

            <div class="shop-and-earn-modal-header__logo">
              <img src=${logoImgPath} alt="logo" />
            </div>

            ${crossBtn ? `<img id="shop-and-earn-modal-header__cross-btn" src=${crossBtnIcon} alt="close modal" />` : ''}
          </div>

          <div class="shop-and-earn-modal-body scrollable">
            ${content}
          </div>
        </div>
      </div>`;
  };

  const getModalElement = () => document.querySelector(`.${tncModalShadowDomClass}`);

  const modelEventHandler = (event: any) => {
    const tncFormModal = getModalElement();

    if (event.target === tncFormModal) {
      tncFormModal.remove();
      document.removeEventListener('click', modelEventHandler);
    }
  };

  const initialize = () => {
    const tncFormModal = getModalElement();

    if (!tncFormModal) {
      const tncModalBody = `
        <div class="tnc-header">
          Purchase conditions
        </div>
        <div class="tnc-body">${merchant.terms}</div>
      `;

      const modalContent = {
        id: tncModalId,
        content: tncModalBody,
      };

      // shadowDom implementation
      const parentElement = document.body;

      const createShadowRoot = (className) => {
        const shadowRoot = document.createElement('div');
        shadowRoot.setAttribute('class', className);
        shadowRoot.attachShadow({ mode: 'open' });
        return shadowRoot;
      };

      if (parentElement) {
        const sRoot = createShadowRoot(tncModalShadowDomClass);
        sRoot.shadowRoot.innerHTML = `${modalTemplate(modalContent)}`;
        const link = document.createElement('link');
        link.setAttribute('rel', 'stylesheet');
        link.setAttribute('href', modalStyles);
        sRoot.shadowRoot.appendChild(link);
        shadowDom = parentElement.appendChild(sRoot);
      }

      const crossBtn = shadowDom?.shadowRoot.getElementById('shop-and-earn-modal-header__cross-btn');
      crossBtn.addEventListener('click', () => {
        getModalElement().remove();
      });

      document.addEventListener('click', modelEventHandler);
    }
  };

  initialize();
};
