export const inPageExtension = (tabId, merchant) => {
  let timeoutId;
  let inPageExt;
  let shadowDom;
  const inPageExtensionId = 'sne_inpage_modal';
  const logoImgPath = chrome.runtime.getURL('images/vff_logo.png');
  const crossBtnImgPath = chrome.runtime.getURL('images/cross-icon.png');
  const errorBtnImgPath = chrome.runtime.getURL('images/error-close.png');
  const shadowRootContainerStyle = chrome.runtime.getURL('shadowRootContainer.css');
  const shadowRootStyles = chrome.runtime.getURL('popup.css');

  const getInPageErrorPopup = () => shadowDom?.shadowRoot.querySelector('#sneError');
  const getMainCta = () => shadowDom?.shadowRoot.querySelector('.sne_ext_cta');
  const getInPageExtension = () => shadowDom?.shadowRoot.getElementById(inPageExtensionId);

  function createShadowRoot(className) {
    const sRoot = document.createElement('div');
    sRoot.setAttribute('class', className);
    sRoot.attachShadow({ mode: 'open' });
    return sRoot;
  }


  const now = new Date();
  const oneHour = 1000 * 60 * 60; // milliseconds in one hour
  now.setTime(now.getTime() + oneHour);
  console.log(now); 



  const injectInPageExtension = (logo, errorIcon, crossIcon, conversion_rate, name) => {
    inPageExt = `
     <div id="${inPageExtensionId}" class="shop-and-earn">
        <div class="shop-and-earn-wrapper">
          <div class="shop-and-earn-header dis_flex">
            <div class="shop-and-earn-header__logo"><img src=${logo} alt="logo"></div>
            <img class="shop-and-earn-header__cross-btn" src=${crossIcon}>
          </div>

          <div id="sneError" class="sneErrorDetail">
            <div class="sneErrorDetail_info">
              <div class="sneErrorDetail_info--title">Uh oh. Something when wrong...
                <img class="sneErrorDetail_info--cross-btn" src=${errorIcon} alt="close">
              </div>
              <div class="sneErrorDetail_info--description">Please wait for a moment and try again</div>
            </div>
          </div>

          <div class="shop-and-earn-body">
            <div class="shop-and-earn-offer-details">
              <div class="shop-and-earn-merchant-offer">
                <div class="shop-and-earn-merchant-offer__detail--name">Earn Points at <span id="sne_ext_merchant_name">${name}</span></div>
                <div class="shop-and-earn-merchant-offer__detail--points" id="sne_ext_conversion_rate">${conversion_rate}</div>
                <button class="shop-and-earn-merchant-offer__tnc sne_ext_tnc-cta">Terms, conditions &amp; exclusions apply</button>
                <button class="sne_ext_cta shop-and-earn-merchant-offer__action-cta" disabled></button>
              </div>
            </div>
          </div>
       </div>
    </div>`;

    const parentElement = document.body;

    const getShadowRoot = parentElement && createShadowRoot('velocityfrequentflyer__shop-and-earn-extension');
    getShadowRoot.shadowRoot.innerHTML = inPageExt;
    const link = document.createElement('link');
    link.setAttribute('rel', 'stylesheet');
    link.setAttribute('href', shadowRootStyles);
    getShadowRoot.shadowRoot.appendChild(link);
    shadowDom = parentElement && parentElement.appendChild(getShadowRoot);
  };

  const injectCss = (style) => {
    const linkTag = document.createElement('link');
    linkTag.rel = 'stylesheet';
    linkTag.href = style;
    const head = document.getElementsByTagName('head')[0];
    head.appendChild(linkTag);
  };

  // < ---- smart position starts ----- >
  const getExtensionElement = (nextSibling) => {
    switch (nextSibling.id) {
      case 'cr-notification':
        return nextSibling.children[0]?.children[0];

      case 'shopback-cashback-notifier':
        return nextSibling.children[0];

      default:
        return nextSibling;
    }
  };

  const getOffsetPosition = (offset, element) => {
    if (element) {
      const elementStyles = window.getComputedStyle(element);
      const isPositionFixed = elementStyles?.getPropertyValue('position') === 'fixed';
      const positionTopValue = parseInt(elementStyles?.getPropertyValue('top'), 10);

      if (isPositionFixed && positionTopValue < 100) {
        const el = element as HTMLElement;
        const isDisplayNone = elementStyles.display === 'none';
        const isVisibilityHidden = elementStyles.visibility === 'hidden';
        const isOpacityZero = elementStyles.opacity === '0';
        const { bottom } = el.getBoundingClientRect();
        const isOffset = bottom > offset;

        if (!isDisplayNone && !isVisibilityHidden && !isOpacityZero && isOffset) {
          return bottom;
        }
      }
    }

    return offset;
  };

  const smartPositioning = () => {
    const nodeList = document.body.children;
    let offset = 0;

    // for elements inside the body
    for (let i = 0; i < nodeList.length; i += 1) {
      const childNode = getExtensionElement(nodeList[i]);

      offset = getOffsetPosition(offset, childNode);
    }

    // gets sibling element
    let nextSibling = document.body.nextElementSibling;

    while (nextSibling) {
      const siblingElement = getExtensionElement(nextSibling);

      offset = getOffsetPosition(offset, siblingElement);

      nextSibling = nextSibling.nextElementSibling;
    }

    const extensionPosition = offset + 10;

    if (shadowDom && !!offset) {
      shadowDom.shadowRoot.getElementById(inPageExtensionId).style.top = `${extensionPosition}px`;
    }
  };
  // < ---- smart position ends ----- >

  const enableTncButton = () => {
    const tncModal = () => {
      chrome.runtime.sendMessage({
        action: 'tnc',
        data: {
          tabId,
          merchant,
        }
      });
    };

    const show_tnc = shadowDom?.shadowRoot.querySelector('.sne_ext_tnc-cta');
    show_tnc.addEventListener('click', tncModal);
  };

  const enableCloseButton = () => {
    chrome.storage.local.get(['userClosedMerchantPopup'], (res) => {
      const userClosedMerchantPopup = res?.userClosedMerchantPopup || [];

      const crossBtn = shadowDom?.shadowRoot.querySelector('.shop-and-earn-header__cross-btn');
      crossBtn.addEventListener('click', () => {
        chrome.storage.local.set({
          userClosedMerchantPopup: [
            ...userClosedMerchantPopup,
            merchant.homepage_url,
          ]
        });
        shadowDom?.shadowRoot.getElementById(inPageExtensionId).remove();
      });
    });
  };

  const enableInPageErrorCloseButton = () => {
    const closeButton = shadowDom?.shadowRoot.querySelector('.sneErrorDetail_info--cross-btn');
    const inPageErrorPopup = getInPageErrorPopup();

    closeButton.addEventListener('click', () => {
      inPageErrorPopup.style.display = 'none';
    });
  };

  const hideInPageErrorPopup = () => {
    const inPageErrorPopup = getInPageErrorPopup();

    inPageErrorPopup.style.display = 'none';
    clearTimeout(timeoutId);
  };

  const showInPageErrorPopup = () => {
    const inPageErrorPopup = getInPageErrorPopup();

    inPageErrorPopup.style.display = 'block';
    timeoutId = setTimeout(hideInPageErrorPopup, 5000);
  };

  const enableMainCta = () => {
    const ctaBtn = getMainCta();
    const inPageErrorPopup = getInPageErrorPopup();

    const activateExtension = () => {
      inPageErrorPopup.style.display = 'none';
      clearTimeout(timeoutId);

      chrome.storage.sync.get(['access_token'], (res) => {
        const isAuthenticated = !!res.access_token;

        ctaBtn.classList.add('loader');
        ctaBtn.disabled = true;
        if (isAuthenticated) {
          // Enable Tracking
          chrome.runtime.sendMessage({
            action: 'activate-offer',
            data: {
              merchant,
              tabId,
            }
          }, (response) => {
            ctaBtn.classList.remove('loader');
            if (response) {
              ctaBtn.classList.add('shop-and-earn-merchant-offer__action-cta--success');
              ctaBtn.innerHTML = 'Offer activated';
            } else {
              ctaBtn.disabled = false;
              showInPageErrorPopup();
            }
          });
        } else if (!navigator.onLine) {
          ctaBtn.disabled = false;
          ctaBtn.classList.remove('loader');
          showInPageErrorPopup();
        } else {
          chrome.runtime.sendMessage({ action: 'login' }, (response) => {
            ctaBtn.classList.remove('loader');
            ctaBtn.disabled = false;
            if (response?.isLoggedIn) {
              ctaBtn.classList.add('shop-and-earn-merchant-offer__action-cta');
              ctaBtn.innerHTML = 'Activate Offer';
            }
          });
        }
      });
    };

    ctaBtn.addEventListener('click', activateExtension);
  };

  const initialize = () => {
    const ctaBtn = getMainCta();

    chrome.storage.sync.get(['access_token'], (res) => {
      const isAuthenticated = !!res.access_token;

      chrome.storage.local.get(['tracking_enabled_sites'], (resp) => {
        const offerActivationInfo = resp.tracking_enabled_sites?.find((item) => item.url === merchant.homepage_url);

        if (offerActivationInfo) {
          ctaBtn.classList.add('shop-and-earn-merchant-offer__action-cta--success');
          ctaBtn.innerHTML = 'Offer activated';
          ctaBtn.disabled = true;
        } else {
          ctaBtn.innerHTML = isAuthenticated
            ? 'Activate Offer'
            : 'Log in to activate';
          ctaBtn.disabled = false;
        }
      });
    });
  };

  chrome.storage.onChanged.addListener((changes, namespace) => {
    const changedItems = Object.keys(changes);

    chrome.storage.local.get(['tracking_enabled_sites'], (res) => {
      const offerActivationInfo = res.tracking_enabled_sites?.find((item) => item.url === merchant.homepage_url);

      for (const item of changedItems) {
        if (
          namespace === 'sync'
            && item === 'access_token'
            && !offerActivationInfo
        ) {
          initialize();
          break;
        }
      }
    });
  });

  if (getInPageExtension()) {
    return;
  }

  injectCss(shadowRootContainerStyle);
  injectInPageExtension(logoImgPath, errorBtnImgPath, crossBtnImgPath, merchant.conversion_rate, merchant.name);
  initialize();
  enableInPageErrorCloseButton();
  enableTncButton();
  enableCloseButton();
  enableMainCta();
  smartPositioning();
};
