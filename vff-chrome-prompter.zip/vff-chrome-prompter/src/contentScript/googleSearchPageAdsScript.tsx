const fetchGoogleSearchResults = document.querySelectorAll('.yuRUbf');
const imgPath = chrome.runtime.getURL('icon.png');

// const validMerchantsUrl = [
//   {url: "https://www.123inkjets.com.au/"},
//   {url: "https://www.adidas.com.au/"},
//   {url: "https://www.asics.com/in/en-in"},
//   {url: "https://www.asics.com/"},
// ];
// let fetchMerchantList = [];

chrome.storage.local.get(({ merchantList }) => {
  const fetchMerchantList = merchantList;
  // let conversionRate = '';
  const extensionTemplate = (rate) => `
  <div class="pp-search-result"
    style="padding-top: 50px; display: flex; align-items: center; font-family: Ciutadella-Regular, Helvetica; font-weight: 700; font-size: 14px; line-height: 16px; color: #E10A0A;">
    <img src=${imgPath} style="margin-right: 7px; width: 24px; height: 24px;">
    <span>Earn ${rate} per $1 spent via Velocity Shop & Earn</span>
  </div>
  `;

  for (let i = 0; i < fetchMerchantList.length; i += 1) {
    const merchantUrl = fetchMerchantList[i].homepage_url;
    if (merchantUrl !== undefined) {
      for (const result of fetchGoogleSearchResults) {
        const currentElement = result.querySelector('a');
        const currentHostName = new URL(currentElement.getAttribute('href')).hostname;
        if (merchantUrl.includes(currentHostName)) {
          currentElement.querySelector('br')?.remove();

          if (result.parentElement.contains(currentElement)) {
            if (result.parentElement.getElementsByClassName('pp-search-result')?.length < 1) {
              result.parentElement.insertAdjacentHTML(
                'afterbegin',
                extensionTemplate(fetchMerchantList[i].per_dollar_rate)
              );
              break;
            }
          }
        }
      }
    }
  }
});
