const logoImgPath = chrome.runtime.getURL('images/vff_logo.png');
const crossBtnIcon = chrome.runtime.getURL('images/cross-icon.png');

const modalTemplate = ({
  id, content, crossBtn = true, name = ''
}) => `
    <div
      id=${id}
      class="shop-and-earn-modal-container opacity-scale-up-center"
    >
      <div class="shop-and-earn-modal slide-top">
        <div class="shop-and-earn-modal-header dis_flex">
          ${name
            && `<div class="shop-and-earn-modal-header__userName">
                  Hi, ${name}
                </div>`}
          
          <div class="shop-and-earn-modal-header__logo">
            <img src=${logoImgPath} alt="logo" />
          </div>
        
          ${crossBtn ? `<img id="shop-and-earn-modal-header__cross-btn" src=${crossBtnIcon} alt="X" />` : ''}
        </div>       
        <div class="shop-and-earn-modal-body">
          ${content}
        </div>
      </div>
    </div>
  `;

export default modalTemplate;
