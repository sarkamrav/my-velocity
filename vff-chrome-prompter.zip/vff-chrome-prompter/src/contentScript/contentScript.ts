
import { injectCss } from '../common/helpers';

const modal_style = chrome.runtime.getURL('modal.css');

injectCss(modal_style); // Appending Modal CSS on load
