export const redirectLoadingModal = (tabId, merchant, givenName) => {
  const modalStyles = chrome.runtime.getURL('modal.css');

  const modalTemplate = ({
    id, content, crossBtn = true, name = ''
  }) => {
    const logoImgPath = chrome.runtime.getURL('images/vff_logo.png');
    const crossBtnIcon = chrome.runtime.getURL('images/cross-icon.png');

    return `
    <div
      id=${id}
      class="shop-and-earn-modal-container opacity-scale-up-center"
    >
      <div class="shop-and-earn-modal slide-top">
        <div class="shop-and-earn-modal-header dis_flex">
          ${name && `<div class="shop-and-earn-modal-header__userName"> Hi, ${name}</div>`}

          <div class="shop-and-earn-modal-header__logo">
            <img src=${logoImgPath} alt="logo" />
          </div>

          ${crossBtn ? `<img id="shop-and-earn-modal-header__cross-btn" src=${crossBtnIcon} alt="X" />` : ''}
        </div>

        <div class="shop-and-earn-modal-body">
          ${content}
        </div>
      </div>
    </div>`;
  };

  const activatingOfferLoader = `<div class="shop-and-ean-modal-loader-wrapper">
    <div class="shop-and-ean-modal-loader"></div>
    <div class="shop-and-ean-modal-loader-text">Activating offer...</div>
  </div>`;

  const redirectModalBody = `
    <div class="shop-and-ean-cnfrm-scr-heading">You're on your way to earning Velocity Points!</div>
    <div class="shop-and-ean-cnfrm-scr-conversion-rate">${merchant.conversion_rate}</div>
    <div class="shop-and-ean-cnfrm-scr-merchant">
      at <span class="shop-and-ean-cnfrm-scr-merchant__name">${merchant.name}</span>
    </div>
    <div class="shop-and-ean-cnfrm-scr-todo-title">
    To ensure you earn Points:
    </div>
    <ul class="shop-and-ean-cnfrm-scr-points-todo">
      <li><span>Complete your shop within this browser tab;</span></li>
      <li><span>Don't activate offers from other coupon or loyalty sites;</span></li>
      <li><span>Make sure cookies are enabled;</span></li>
      <li><span>Exclusions may apply - check retailer terms & conditions to find out more.</span></li>
    </ul>
    ${activatingOfferLoader}
  `;

  const modalContent = {
    id: 'shop-and-earn_confirmation_src',
    content: redirectModalBody,
    crossBtn: false,
    name: givenName,
  };

  // shadowDom implementation
  const parentElement = document.body;

  function createShadowRoot(className) {
    const shadowRoot = document.createElement('div');
    shadowRoot.setAttribute('class', className);
    shadowRoot.attachShadow({ mode: 'open' });
    return shadowRoot;
  }

  if (parentElement) {
    const sRoot = createShadowRoot('velocityfrequentflyer__shop-and-earn-modal');
    sRoot.shadowRoot.innerHTML = `${modalTemplate(modalContent)}`;
    const link = document.createElement('link');
    link.setAttribute('rel', 'stylesheet');
    link.setAttribute('href', modalStyles);
    sRoot.shadowRoot.appendChild(link);
    parentElement.appendChild(sRoot);
  }
};

export const removeRedirectLoadingModal = () => {
  const modal = document.querySelector('.velocityfrequentflyer__shop-and-earn-modal');
  if (modal) {
    modal.remove();
  }
};
