import modalTemplate from './modal';
import { qualtricsSurveyUrl } from '../common/constants';

const feedbackForm = document.getElementById('shop-and-earn_feedback_form');
const formBody = `<iframe src="${qualtricsSurveyUrl}"></iframe>`;

if (!feedbackForm) {
  const modalContent = {
    id: 'shop-and-earn_feedback_form',
    content: formBody,
  };
  document.body.insertAdjacentHTML('afterend', modalTemplate(modalContent));

  const crossBtn = document.getElementById(
    'shop-and-earn-modal-header__cross-btn'
  );
  crossBtn.addEventListener('click', () => {
    document.getElementById('shop-and-earn_feedback_form').remove();
  });
}
