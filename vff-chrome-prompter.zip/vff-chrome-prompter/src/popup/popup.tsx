import React, { useEffect, useState } from 'react';
import { findMerchantByTabInfo, getMemberGivenName } from '../common/helpers';
import { qualtricsSurveyUrl, eStoreAllStoreUrl, landingPageOnInstall } from '../common/constants';
import './popup.css';

const crossBtnImgPath = chrome.runtime.getURL('images/error-close.png');

function Popup() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [givenName, setGivenName] = useState('');
  const [hasError, setHasError] = useState(false);

  const [loading, setLoading] = useState(false);
  const [merchant, setMerchant] = useState(null);
  const [tab, setTab] = useState(null);
  const [isTrackingEnabled, setIsTrackingEnabled] = useState(false);

  useEffect(() => {
    chrome.storage.sync.get(['access_token'], (result) => {
      setIsLoggedIn(!!result?.access_token);
      setGivenName(getMemberGivenName(result.access_token));
    });
  }, []);

  useEffect(() => {
    chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
      // eslint-disable-next-line @typescript-eslint/no-shadow
      const [tab] = tabs;
      setTab(tab);

      if (tab && tab.url && (tab.url.startsWith('http://') || tab.url.startsWith('https://'))) {
        chrome.storage.local.get(
          [
            'tracking_enabled_sites', // list of sites who tracking are enabled
            'merchantList',
          ],
          (result) => {
            const merchantByTabInfo = findMerchantByTabInfo(tab, result.merchantList);
            if (merchantByTabInfo) {
              const offerActivationInfo = result?.tracking_enabled_sites?.find((item) => item.url === merchantByTabInfo.homepage_url);
              setMerchant(merchantByTabInfo);
              setIsTrackingEnabled(!!offerActivationInfo);
            }
          }
        );
      } // end if
    }); // end tabs.query
  }, []);

  useEffect(() => {
    const timeId = setTimeout(() => {
      setHasError(false);
    }, 5000);

    return () => {
      clearTimeout(timeId);
    };
  }, [hasError]);

  useEffect(() => {
    chrome.storage.onChanged.addListener((changes, namespace) => {
      const changedItems = Object.keys(changes);

      for (const item of changedItems) {
        if (
          namespace === 'sync'
          && item === 'access_token'
        ) {
          const accessToken = changes[item]?.newValue;
          setIsLoggedIn(!!accessToken);
          setGivenName(getMemberGivenName(accessToken));
          break;
        }
      }
    });
  }, []);

  function logIn() {
    setLoading(true);
    setHasError(false);
    chrome.runtime.sendMessage({ action: 'login' }, (response) => {
      setIsLoggedIn(response.isLoggedIn);
      setLoading(response.loading);
      setGivenName(response.name);
      setHasError(response?.hasError);
    });
  }

  function logOut() {
    setLoading(true);
    setHasError(false);
    chrome.runtime.sendMessage({ action: 'logout' }, (response) => {
      if (response?.hasError) {
        setHasError(response?.hasError);
      } else {
        setIsLoggedIn(response?.isLoggedIn);
      }
      setLoading(false);
    });
  }

  function enableTracking(e) {
    e.preventDefault();
    setLoading(true);
    setHasError(false);

    chrome.runtime.sendMessage({
      action: 'activate-offer',
      data: {
        merchant,
        tabId: tab.id,
      }
    }, (response) => {
      setLoading(false);
      if (response) {
        setIsTrackingEnabled(true);
      } else {
        setHasError(true);
      }
    });
  }

  function tncModal() {
    chrome.runtime.sendMessage({
      action: 'tnc',
      data: {
        tabId: tab.id,
        merchant,
      }
    }, (response) => {
      if (response.close) {
        window.close();
      }
    });
  }

  return (
    <div className="shop-and-earn-wrapper">
      <div className="shop-and-earn-header">
        <div className="shop-and-earn-header__logo">
          <img src="./images/vff_logo.png" alt="logo" />
        </div>
      </div>
      {hasError && (
        <div className="sneErrorDetail">
          <div className="sneErrorDetail_info">
            <div className="sneErrorDetail_info--title">
              Uh oh. Something when wrong...
              <img
                className="sneErrorDetail_info--cross-btn"
                src={crossBtnImgPath}
                alt="cross-btn-icon"
                onClick={() => setHasError(false)}
              />
            </div>
            <div className="sneErrorDetail_info--description">
              Please wait for a moment and try again
            </div>
          </div>
        </div>
      )}
      <div className="shop-and-earn-body">
        <div
          className={`shop-and-earn-nav dis_flex ${isLoggedIn && 'logged-in'}`}
        >
          <div className="shop-and-earn-nav__user-name">
            <span>{isLoggedIn ? givenName : 'Welcome back!'}</span>
          </div>
          <button
            className={`shop-and-earn-nav__login-module ${
              loading ? 'authLoader' : ''
            }`}
            disabled={loading}
            onClick={isLoggedIn ? logOut : logIn}
          >
            {isLoggedIn ? 'Log out' : 'Log in'}
          </button>
        </div>
        <div className="shop-and-earn-offer-details">
          {merchant ? (
            <div className="shop-and-earn-merchant-offer">
              <div className="shop-and-earn-merchant-offer__detail">
                <div className="shop-and-earn-merchant-offer__detail--name">
                  Earn Points at <span>{merchant.name}</span>
                </div>
                <div className="shop-and-earn-merchant-offer__detail--points">
                  {merchant.conversion_rate}
                </div>
                {isTrackingEnabled && (
                  <div className="shop-and-earn-merchant-offer__detail--status">
                    Activated
                  </div>
                )}
              </div>
              <button
                onClick={tncModal}
                className="shop-and-earn-merchant-offer__tnc"
              >
                Terms, conditions & exclusions apply
              </button>
              {isLoggedIn ? (
                <>
                  {isTrackingEnabled ? (
                    <button className="shop-and-earn-merchant-offer__action-cta--success">
                      Offer activated
                    </button>
                  ) : (
                    <button
                      onClick={enableTracking}
                      className={`shop-and-earn-merchant-offer__action-cta ${
                        loading && 'loader'
                      }`}
                    >
                      Activate offer
                    </button>
                  )}
                </>
              ) : (
                !isTrackingEnabled && (
                  <button
                    onClick={logIn}
                    disabled={loading}
                    className={`shop-and-earn-merchant-offer__action-cta ${
                      loading && 'loader'
                    }`}
                  >
                    Log in to activate
                  </button>
                )
              )}
            </div>
          ) : (
            <div className="shop-and-earn-non-merchant-offer">
              <h1 className="shop-and-earn-non-merchant-offer__heading">
                Never miss an offer!
              </h1>
              <p className="shop-and-earn-non-merchant-offer__sub-heading">
                We'll let you know when you can earn Velocity Points on websites
                you visit.
              </p>
              <div className="shop-and-earn-non-merchant-offer__banner">
                <div className="shop-and-earn-non-merchant-offer__banner--heading">
                  Earn points shopping online
                </div>
                <div className="shop-and-earn-non-merchant-offer__banner--sub-heading">
                  At more than 300 brands.
                </div>
                <div className="shop-and-earn-non-merchant-offer__banner--cta">
                  <a
                    href={eStoreAllStoreUrl}
                    target="_blank"
                    className="shop-and-earn-non-merchant-offer__banner--cta--text"
                    rel="noreferrer"
                  >
                    Find stores
                  </a>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      <div className="shop-and-earn-footer dis_flex">
        <a href={eStoreAllStoreUrl} target="_blank" rel="noreferrer">
          All Stores
        </a>
        <a href={landingPageOnInstall} target="_blank" rel="noreferrer">
          How it works
        </a>
        <a href={qualtricsSurveyUrl} target="_blank" rel="noreferrer">
          Feedback
        </a>
      </div>
    </div>
  );
}

export default Popup;
