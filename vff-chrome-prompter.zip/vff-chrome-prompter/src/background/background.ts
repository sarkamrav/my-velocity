import fetchMerchantAPI from '../common/fetchMerchantAPI';

import {
  buildSetting,
  apiErrorType,
  isKeycloakUpgraded,
  landingPageOnInstall,
  qualtricsSurveyPostUninstallUrl,
} from '../common/constants';

import {
  readSyncStorage,
  readLocalStorage,
  relativeTimeDifference,
  sleeper,
  refreshAccessToken,
  trackingGetUser,
  trackingGetClicks,
  setSyncStorage,
  findMerchantByTabInfo,
  getMemberGivenName,
  getValidHostnameByUrl,
  chromeTabsGet,
  sneError,
  logoutV2,
  cherryPickTokens,
  isOptedInMerchant,
} from '../common/helpers';

import { inPageExtension } from '../contentScript/inPagePopupScript';
import { redirectLoadingModal, removeRedirectLoadingModal } from '../contentScript/redirectConfirmModalScript';
import { tncForm } from '../contentScript/tncModalScript';

// Global Values
const { keycloak } = buildSetting;

const logout = (sendResponse?) => {
  chrome.storage.sync.get(['id_token'], (result) => {
    const logoutUrl = `${keycloak.oidcUrl}/logout${isKeycloakUpgraded ? `?id_token_hint=${result.id_token}` : ''}`;
    const options = {
      method: 'GET',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    };

    // Send logout request to Keycloak
    fetch(logoutUrl, options)
      .then(() => {
        chrome.identity.clearAllCachedAuthTokens(() => {
          chrome.storage.sync.remove([
            'access_token',
            'refresh_token',
            'id_token',
          ]);

          if (sendResponse) {
            sendResponse({ isLoggedIn: false, loading: false });
          }
        });
      })
      .catch(() => {
        sendResponse({ hasError: true });
      });
  });
};

const onMessageHandler = async (result, sender, sendResponse) => {
  if (result.action === 'login') {
    const redirectURL = encodeURIComponent(chrome.identity.getRedirectURL());

    chrome.identity.clearAllCachedAuthTokens(() => {
      chrome.storage.sync.remove([
        'access_token',
        'refresh_token',
        'id_token',
      ]);
    });
    let loginURL = `${keycloak.oidcUrl}/auth`;
    loginURL += `?client_id=${keycloak.clientID}`;
    loginURL += `&redirect_uri=${redirectURL}`;
    loginURL += '&explicit_login=web';
    loginURL += '&response_mode=fragment';
    loginURL += '&response_type=code';
    loginURL += `&scope=${encodeURIComponent(keycloak.scope)}`;

    try {
      if (!navigator.onLine) {
        sendResponse(({ hasError: true }));
      } else {
        chrome.identity.launchWebAuthFlow(
          {
            interactive: true,
            url: loginURL,
          },
          (redirect_url) => {
            if (!chrome?.runtime?.lastError) {
              const url = redirect_url;
              const getCode = url.slice(url.indexOf('?') + 1).split('&')[1];
              if (getCode) {
                fetch(`${keycloak.oidcUrl}/token`, {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                  },
                  body: `redirect_uri=${redirectURL}&client_id=${keycloak.clientID}&grant_type=${keycloak.grantType}&${getCode}&scope=${keycloak.scope}`,
                })
                  .then((response) => response.json())
                  .then((response) => {
                    chrome.storage.sync.set(
                      {
                        access_token: response.access_token,
                        refresh_token: response.refresh_token,
                        id_token: response.id_token,
                      },
                      () => {
                        sendResponse({
                          isLoggedIn: true,
                          loading: false,
                          name: getMemberGivenName(response?.access_token),
                        });
                      }
                    );
                    return response;
                  })
                  .catch(() => {
                    sendResponse({ isLoggedIn: false, loading: false });
                  });
              }
            } else {
              sendResponse({ isLoggedIn: false, loading: false });
            }
          }
        );
      }
    } catch (err) {
      throw new Error(chrome.i18n.getMessage('error', err));
    }

    return true;
  } if (result.action === 'logout') {
    logout(sendResponse);

    return true;
  } if (result.action === 'activate-offer') {
    let accessToken = await readSyncStorage('access_token');

    try {
      const start = Date.now();
      await chrome.scripting.executeScript({
        target: { tabId: result?.data?.tabId },
        func: redirectLoadingModal,
        args: [result?.data?.tabId, result?.data?.merchant, getMemberGivenName(accessToken)]
      });

      // Start Collinson User API
      const userResponse = await trackingGetUser(accessToken);
      let userResponseData = await userResponse.json();

      if (!userResponse.ok && userResponse.status === 401) {
        const refreshToken = await readSyncStorage('refresh_token');
        const refreshTokenResponse = await refreshAccessToken(refreshToken);
        const refreshTokenResponseData = await refreshTokenResponse.json();

        if (!refreshTokenResponse.ok) {
          logoutV2();
          throw sneError({
            type: apiErrorType.keycloak,
            errorResponse: refreshTokenResponseData,
          });
        }

        await setSyncStorage(cherryPickTokens(refreshTokenResponseData));
        accessToken = refreshTokenResponseData.access_token;

        const retryUserResponse = await trackingGetUser(refreshTokenResponseData.access_token);
        const retryUserResponseData = await retryUserResponse.json();

        if (!retryUserResponse.ok) {
          throw sneError({
            type: apiErrorType.collinson,
            errorResponse: retryUserResponseData,
          });
        }

        userResponseData = retryUserResponseData;
      }

      if (!userResponse.ok && userResponse.status !== 401) {
        throw sneError({
          type: apiErrorType.collinson,
          errorResponse: userResponseData,
        });
      }

      // Start Collinson Tracking API
      const trackingApiResponse = await trackingGetClicks(accessToken, userResponseData?.data?.id, result?.data?.merchant.id);
      let trackingResponseData = await trackingApiResponse.json();

      if (!trackingApiResponse.ok && trackingApiResponse.status === 401) {
        const refreshToken = await readSyncStorage('refresh_token');
        const refreshTokenResponse = await refreshAccessToken(refreshToken);
        const refreshTokenResponseData = await refreshTokenResponse.json();

        if (!refreshTokenResponse.ok) {
          logoutV2();
          throw sneError({
            type: apiErrorType.keycloak,
            errorResponse: refreshTokenResponseData,
          });
        }

        await setSyncStorage(cherryPickTokens(refreshTokenResponseData));
        const retryTrackingApiResponse = await trackingGetClicks(refreshTokenResponseData.access_token, userResponseData?.data?.id, result?.data?.merchant?.id);
        const retryTrackingApiResponseData = await retryTrackingApiResponse.json();

        if (!retryTrackingApiResponse.ok) {
          throw sneError({
            type: apiErrorType.collinson,
            errorResponse: retryTrackingApiResponseData,
          });
        }

        trackingResponseData = retryTrackingApiResponseData;
      }

      if (!trackingApiResponse.ok && trackingApiResponse.status !== 401) {
        throw sneError({
          type: apiErrorType.collinson,
          errorResponse: trackingResponseData,
        });
      }

      const end = Date.now();
      const additionalAnimationTime = relativeTimeDifference(start, end, 6000);
      const trackingEnabledSites = await readLocalStorage('tracking_enabled_sites') || [];
      if (additionalAnimationTime) {
        await sleeper(additionalAnimationTime);
      }

      chrome.tabs.update(
        result.data.tabId,
        { url: trackingResponseData?.data?.tracking_url },
        () => {
          chrome.storage.local.set(
            {
              tracking_enabled_sites: [
                ...trackingEnabledSites,
                {
                  url: result?.data?.merchant?.homepage_url,
                  activatedTime: Date.now(),
                },
              ],
            },
            () => {
              sendResponse(true);
            }
          );
        }
      );
      sendResponse(true);
    } catch (e) {
      chrome.scripting.executeScript({
        target: { tabId: result.data.tabId },
        func: removeRedirectLoadingModal,
      });
      sendResponse(false);
    }

    return true;
  } if (result.action === 'tnc') {
    chrome.scripting.executeScript({
      target: { tabId: result?.data?.tabId },
      func: tncForm,
      args: [result?.data?.tabId, result?.data?.merchant]
    }, () => {
      sendResponse({ close: true });
    });
    return true;
  }
};

const executeMerchantPopUpScript = (tab, result, tabId, merchant) => {
  const { tracking_enabled_sites, userClosedMerchantPopup = [] } = result;
  const parsedCurrentUrl = new URL(tab.url);
  const currTabUrl = parsedCurrentUrl?.hostname;
  const offerActivationInfo = tracking_enabled_sites?.find((item) => isOptedInMerchant(currTabUrl, item.url));
  const offerActivatedTime = new Date(offerActivationInfo?.activatedTime);
  const isOfferRequiredReActivation = offerActivationInfo
    ? Date.now() > offerActivatedTime.setHours(offerActivatedTime.getHours() + 1)
    : false;

  const isCurrentTabPopupClosed = userClosedMerchantPopup?.find((item) => isOptedInMerchant(currTabUrl, item));

  chrome.action.setIcon({
    path: offerActivationInfo && !isOfferRequiredReActivation ? '/icon-active.png' : '/icon-enable.png',
    tabId: tab.id,
  });

  if (isOfferRequiredReActivation) {
    chrome.storage.local.set({
      userClosedMerchantPopup: userClosedMerchantPopup.filter(
        (item) => !isOptedInMerchant(currTabUrl, item)
      ),
      tracking_enabled_sites: (result?.tracking_enabled_sites || []).filter(
        (item) => !isOptedInMerchant(currTabUrl, item.url)
      ),
    });
  }

  if (!isCurrentTabPopupClosed || isOfferRequiredReActivation) {
    chrome.scripting.executeScript({
      target: { tabId },
      func: inPageExtension,
      args: [tabId, merchant],
    });
  }
};

const onUpdatedHandler = async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete') {
    chrome.storage.local.get((result) => {
      const { merchantList_fetched_at } = result;

      if (merchantList_fetched_at) {
        const merchantListFetchedTime = new Date(merchantList_fetched_at);
        const refreshMerchantListTime = merchantListFetchedTime.setHours(merchantListFetchedTime.getHours() + 6);
        const refreshMerchantList = Date.now() > refreshMerchantListTime;

        if (refreshMerchantList) fetchMerchantAPI();
      }

      if (result.merchantList) {
        const merchant = findMerchantByTabInfo(tab, result.merchantList);

        if (merchant) executeMerchantPopUpScript(tab, result, tabId, merchant);
      } else {
        chrome.storage.onChanged.addListener((changes, namespace) => {
          for (const item of Object.keys(changes)) {
            if (namespace === 'local' && item === 'merchantList') {
              const merchant = findMerchantByTabInfo(tab, changes[item]);

              if (merchant) executeMerchantPopUpScript(tab, result, tabId, merchant);
              break;
            }
          }
        });
      }
    });
  }

  if (
    changeInfo.status === 'complete'
    && tab.status === 'complete'
    && tab.url !== undefined
  ) {
    const parsedCurrentUrl = new URL(tab.url);
    const { origin, pathname } = parsedCurrentUrl;

    // Google Search Result Page
    if (origin === 'https://www.google.com' && pathname === '/search') {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['googleSearchPageAdsScript.js'],
      });
    }

    // Detect VA Domain
    if ([
      'https://staging.velocityfrequentflyer.com',
      'https://experience.velocityfrequentflyer.com',
      'https://www.velocityfrequentflyer.com'
    ].includes(origin)) {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => document.body.setAttribute('shop-and-earn-extension-id', chrome.runtime.id),
      });
    }
  }
};

const onActivatedHandler = async (activeInfo) => {
  const tab = await chromeTabsGet(activeInfo.tabId);
  const currTabUrl = getValidHostnameByUrl(tab.url);

  if (currTabUrl) {
    const trackingEnabledSites = await readLocalStorage('tracking_enabled_sites') || [];
    const merchantList = await readLocalStorage('merchantList') || [];
    const merchant = findMerchantByTabInfo(tab, merchantList);

    const offerActivationInfo = trackingEnabledSites?.find((item) => isOptedInMerchant(currTabUrl, item.url));

    if (offerActivationInfo) {
      chrome.action.setIcon({
        path: '/icon-active.png',
        tabId: tab.id,
      });
    }

    if (!offerActivationInfo && merchant) {
      chrome.action.setIcon({
        path: '/icon-enable.png',
        tabId: tab.id,
      });
    }
  }
};

chrome.storage.local.get(['merchantList'], ({ merchantList }) => {
  if (!merchantList) fetchMerchantAPI();
});

// call this function when extension got installed
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === chrome.runtime.OnInstalledReason.INSTALL) {
    chrome.tabs.create({ url: landingPageOnInstall });

    chrome.runtime.setUninstallURL(qualtricsSurveyPostUninstallUrl);
  }
});

chrome.runtime.onMessage.addListener((result, sender, sendResponse) => {
  onMessageHandler(result, sender, sendResponse);
  return true;
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  onUpdatedHandler(tabId, changeInfo, tab);
});

chrome.tabs.onActivated.addListener((activeInfo) => {
  onActivatedHandler(activeInfo);
});

chrome.runtime.onUpdateAvailable.addListener((details) => {
  // eslint-disable-next-line no-console
  console.info('S&E version update details', details, new Date());
});
