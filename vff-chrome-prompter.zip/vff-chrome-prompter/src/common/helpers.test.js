import { isOptedInMerchant } from './helpers';

describe('helpers', () => {
  describe('isOptedInMerchant', () => {
    test('should NOT treat craft.co as a merchant when the domain is www.sportscraft.com.au', () => {
      expect(isOptedInMerchant('craft.co', 'www.sportscraft.com.au')).toBe(false);
    });
  });
});
