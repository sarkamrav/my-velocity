import { buildSetting } from './constants';
import { fixUrl } from './helpers';

const { collisionApi } = buildSetting;
const ebayDetails = {
  conversion_rate: '',
  country_id: '',
  description: '',
  homepage_url: 'www.ebay.com',
  id: '123445',
  logo: '',
  name: '',
  per_dollar_rate: '',
  rate: '',
  rate_numeric: '',
  terms: ''
};

const formatMerchantList = (merchantData = []) => merchantData?.map((merchant) => ({
  id: merchant.id,
  logo: merchant.logo,
  name: merchant.name.toLowerCase(),
  description: merchant.description,
  country_id: merchant.country_id,
  terms: merchant.terms,
  rate_numeric: merchant.rate_numeric,
  rate: merchant.rate,
  homepage_url: fixUrl(merchant.homepage_url?.toLowerCase()),
  per_dollar_rate: merchant.rate?.split('=')[1]?.trim(),
  conversion_rate: merchant.rate,
}));

// Merchant API data into local storage
async function getMerchantList() {
  const options = {
    method: 'GET',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-APIKey': collisionApi.apiKey,
    },
  };

  await fetch(`${collisionApi.merchants}?limit=500`, options)
    .then((response) => response?.json())
    .then(({ data }) => {
      const formatedMerchantList = formatMerchantList(data?.filter((el) => el.homepage_url));
      chrome.storage.local.set({
        merchantList: [...formatedMerchantList, ebayDetails],
        merchantList_fetched_at: Date.now()
      });
    })
    .catch(() => {
    });
}
export default getMerchantList;