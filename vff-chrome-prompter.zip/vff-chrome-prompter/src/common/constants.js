const env = {
  test: 'test',
  stage: 'stage',
  prod: 'prod',
};

// Build config for test | stage | prod environments
const buildEnv = env.prod;

export const isKeycloakUpgraded = true;

const keycloakDomain = {
  [env.test]: 'https://accounts-test.velocityfrequentflyer.com',
  [env.stage]: 'https://accounts-test.velocityfrequentflyer.com',
  [env.prod]: 'https://accounts.velocityfrequentflyer.com',
};

const collisionApiDomain = {
  [env.test]: 'https://qa-api.velocityfrequentflyer.com',
  [env.stage]: 'https://staging-api.velocityfrequentflyer.com',
  [env.prod]: 'https://api.velocityfrequentflyer.com',
};

const collisionApiKey = {
  [env.test]: 'PepGHvewAuSPczDmJ2bZXeocav5xKVzK',
  [env.stage]: 'U6NMxeW9n6tkCqMUUFDX7u12p5N385r3',
  [env.prod]: 'T08bKXJG585x3dYriliMOJEMjJnODiiw',
};

const commonKeycloakSetting = {
  clientID: 'vff-chrome-plugin-client',
  scope: 'openid offline_access',
  grantType: 'authorization_code',
};

// eslint-disable-next-line  @typescript-eslint/no-shadow
const getSettings = (env) => ({
  keycloak: {
    ...commonKeycloakSetting,
    oidcUrl: `${keycloakDomain[env]}/auth/realms/velocity/protocol/openid-connect`,
    domain: `${keycloakDomain[env]}`,
  },
  collisionApi: {
    merchants: `${collisionApiDomain[env]}/loyalty/v1/estore/api/merchants`,
    tracking: `${collisionApiDomain[env]}/loyalty/v1/estore/api/users`,
    apiKey: collisionApiKey[env],
  },
});

export const landingPageOnInstall = 'https://experience.velocityfrequentflyer.com/shopping-online/velocity-shop-and-earn-chrome-extension';

export const qualtricsSurveyUrl = 'https://feedback.virginaustralia.com/jfe/form/SV_cZ904WxEn80Iwqq';
export const qualtricsSurveyPostUninstallUrl = 'https://feedback.virginaustralia.com/jfe/form/SV_0Tcvz87wVHOMdaC';

export const eStoreAllStoreUrl = 'https://estore.velocityfrequentflyer.com/az';

export const apiErrorType = {
  keycloak: 'keycloak',
  collinson: 'collinson',
};

export const buildSetting = getSettings(buildEnv);

