import { buildSetting, isKeycloakUpgraded } from './constants';

const parseAccessToken = (accessToken) => (accessToken ? JSON.parse(atob(accessToken.split('.')[1])) : null);

export const readLocalStorage = async (key) => new Promise((resolve) => chrome.storage.local.get([key], (result) => {
  if (!result || !result[key]) {
    resolve(null);
  } else {
    resolve(result[key]);
  }
}));

export const chromeTabsGet = async (tabId) => new Promise((resolve) => {
  chrome.tabs.get(tabId, (tab) => (tab ? resolve(tab) : resolve(null)));
});

export const readSyncStorage = async (key) => new Promise((resolve) => {
  chrome.storage.sync.get([key], (result) => {
    if (!result[key]) {
      resolve(null);
    } else {
      resolve(result[key]);
    }
  });
});

export const removeSyncStorage = async (keys) => new Promise((resolve) => {
  chrome.storage.sync.remove(keys, () => resolve());
});

export const setSyncStorage = async (data) => new Promise((resolve, reject) => chrome.storage.sync.set(
  data,
  () => (chrome.runtime.lastError
    ? reject(Error(chrome.runtime.lastError.message))
    : resolve())
));

export const sleeper = (ms = 1000) => new Promise((resolve) => setTimeout(resolve, ms));

export const relativeTimeDifference = (startTime, endTime, totalTime = 3000) => {
  const timeDifference = endTime - startTime;
  return timeDifference <= totalTime ? totalTime - timeDifference : 0;
};

export const getValidHostnameByUrl = (url) => {
  try {
    if (url && (url.startsWith('http://') || url.startsWith('https://'))) {
      return new URL(url).hostname;
    }
  } catch (e) {
    return null;
  }
};

export const isOptedInMerchant = (tabHostname, merchantHomeUrl) => (tabHostname === merchantHomeUrl);

export const findMerchantByTabInfo = (tab, merchantList = []) => {
  const tabHostname = getValidHostnameByUrl(tab.url);

  return (tabHostname && merchantList?.length > 0)
    ? merchantList.find((item) => isOptedInMerchant(tabHostname, item.homepage_url))
    : null;
};

export const getMembershipId = (accessToken) => parseAccessToken(accessToken)?.preferred_username;
export const getMemberGivenName = (accessToken) => parseAccessToken(accessToken)?.given_name;

export const refreshAccessToken = async (refreshToken) => {
  const { keycloak } = buildSetting;

  return await fetch(
    `${keycloak.oidcUrl}/token`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: `grant_type=refresh_token&refresh_token=${encodeURIComponent(
        refreshToken
      )}&client_id=${keycloak.clientID}`,
    }
  );
};

export const trackingGetUser = async (accessToken) => {
  const { collisionApi } = buildSetting;

  return await fetch(
    collisionApi.tracking,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        Authorization: `Bearer ${accessToken}`,
        'X-APIKey': collisionApi.apiKey,
      },
      body: `external_id=${getMembershipId(accessToken)}`,
    }
  );
};

export const trackingGetClicks = async (accessToken, userId, merchantId) => {
  const { collisionApi } = buildSetting;

  return await fetch(
    `${collisionApi.tracking}/${userId}/clicks`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        Authorization: `Bearer ${accessToken}`,
        'X-APIKey': collisionApi.apiKey,
      },
      body: `merchant_id=${merchantId}&extra[source]=toolbar`,
    }
  );
};

export const sneError = (error = {}) => {
  const sneErr = new Error();
  sneErr.detail = error;
  return sneErr;
};

export const logoutV2 = async () => {
  const { keycloak } = buildSetting;
  const idToken = await readSyncStorage('id_token');

  if (idToken) {
    const logoutUrl = `${keycloak.oidcUrl}/logout${isKeycloakUpgraded ? `?id_token_hint=${idToken}` : ''}`;
    const options = {
      method: 'GET',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    };

    const response = await fetch(logoutUrl, options);

    if (response.ok) {
      chrome.identity.clearAllCachedAuthTokens(() => {
        chrome.storage.sync.remove([
          'access_token',
          'refresh_token',
          'id_token',
        ]);
      });
    }
  }
};

export const cherryPickTokens = ({ access_token, id_token, refresh_token }) => ({
  access_token,
  id_token,
  refresh_token,
});

export const injectCss = (style) => {
  const linkTag = document.createElement('link');
  linkTag.rel = 'stylesheet';
  linkTag.href = style;
  const head = document.getElementsByTagName('head')[0];
  head.appendChild(linkTag);
};

// Fix web urls to avoid any url errors
export function fixUrl(url = '') {
  if (url) {
    if (url.startsWith('http://') || url.startsWith('https://')) {
      return new URL(url).hostname;
    } if (url.startsWith('www.')) {
      const newUrl = `https://${url}`;
      return new URL(newUrl).hostname;
    }
  }
}
